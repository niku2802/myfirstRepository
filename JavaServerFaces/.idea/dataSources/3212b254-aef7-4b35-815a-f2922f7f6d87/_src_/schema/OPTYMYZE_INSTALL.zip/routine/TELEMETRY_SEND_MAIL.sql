CREATE PROCEDURE TELEMETRY_SEND_MAIL(
    pi_sender    IN VARCHAR2 DEFAULT 'donotreply@optymyze.com',
    pi_reciever  IN VARCHAR2 ,
    pi_cc        IN VARCHAR2 DEFAULT NULL,
    pi_bcc       IN VARCHAR2 DEFAULT NULL,
    pi_subject   IN VARCHAR2 ,
    PI_MAILBODY  IN VARCHAR2 ,
    pi_mime_type IN VARCHAR2 DEFAULT 'text/html',
    pi_priority  IN NUMBER DEFAULT 3,
    pi_replyto   IN VARCHAR2 DEFAULT NULL )
AS
  v_mail_id NUMBER:=0;
BEGIN
  v_mail_id:=TELEMETRY_SEND_MAIL_SEQ.nextval;
  
  INSERT INTO TELEMETRY_MAIL_LOGS(tel_mail_id,TEL_MAIL_SENDER,TEL_MAIL_RECIEVER,TEL_MAIL_SUBJECT,TEL_MAIL_CC,TEL_MAIL_BCC,TEL_MAIL_SENT,tel_mail_error )
  VALUES (v_mail_id,pi_sender,pi_reciever,pi_subject,PI_CC,pi_bcc,'N',NULL);
  
  COMMIT;
  
  BEGIN
    SYS.UTL_MAIL.SEND
                    (SENDER=>PI_SENDER, 
                    RECIPIENTS=>PI_RECIEVER, 
                    CC=>PI_CC, 
                    BCC=>PI_BCC, 
                    SUBJECT=> PI_SUBJECT, 
                    MESSAGE=> PI_MAILBODY, 
                    MIME_TYPE =>'text/html', 
                    PRIORITY =>3, 
                    REPLYTO =>NULL );
    
    
    DBMS_OUTPUT.PUT_LINE('DONE!!!');
	
    UPDATE TELEMETRY_MAIL_LOGS SET TEL_MAIL_SENT ='Y',TEL_MAIL_SENT_ON =sysdate  WHERE tel_mail_id=v_mail_id;
	
  EXCEPTION
  WHEN OTHERS THEN
  
    UPDATE TELEMETRY_MAIL_LOGS
    SET tel_mail_error =DBMS_UTILITY.FORMAT_ERROR_STACK 
    WHERE tel_mail_id=v_mail_id;
  
	COMMIT;
  END;
  
EXCEPTION
WHEN OTHERS THEN
  NULL;
END;
/
