CREATE TRIGGER DATA_TABLES_AU_TRG
AFTER UPDATE OF DT_NAME, DT_FOL_ID
  ON DATA_TABLES
FOR EACH ROW
  BEGIN
	SYSTEM_DATA.MODIFY_REGISTRATION
	(	pi_or_id => :new.DT_ID,
        pi_or_name => :new.DT_NAME,
        pi_or_container_id => :new.DT_FOL_ID);
END ;
/
