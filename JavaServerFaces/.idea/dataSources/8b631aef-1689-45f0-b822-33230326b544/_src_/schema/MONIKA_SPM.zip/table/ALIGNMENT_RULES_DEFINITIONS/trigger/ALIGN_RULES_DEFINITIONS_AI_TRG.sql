CREATE TRIGGER ALIGN_RULES_DEFINITIONS_AI_TRG
AFTER INSERT
  ON ALIGNMENT_RULES_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.ARD_ID,
      pi_or_name => :new.ARD_NAME,
      pi_or_type => 142,
	  pi_or_container_id => :new.ARD_FOL_ID);
  END;
/
