CREATE TRIGGER REPORTS_EXPORT_PROCESS_AI_TRG
AFTER INSERT
  ON REPORTS_EXPORT_PROCESSES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.REP_ID,
      pi_or_name => :new.REP_NAME,
      pi_or_type => 54,
	  pi_or_container_id => :new.REP_FOL_ID);
  END;
/
