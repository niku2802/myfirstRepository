CREATE TRIGGER DATA_SOURCES_AI_TRG
AFTER INSERT
  ON DATA_SOURCES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.DS_ID,
      pi_or_name => :new.DS_NAME,
      pi_or_type => 51,
	  pi_or_container_id => NULL);
  END;
/
