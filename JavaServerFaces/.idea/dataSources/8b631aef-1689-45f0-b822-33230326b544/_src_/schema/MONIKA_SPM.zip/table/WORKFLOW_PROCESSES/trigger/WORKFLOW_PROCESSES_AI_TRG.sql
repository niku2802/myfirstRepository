CREATE TRIGGER WORKFLOW_PROCESSES_AI_TRG
AFTER INSERT
  ON WORKFLOW_PROCESSES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.WP_ID,
      pi_or_name => :new.WP_NAME,
      pi_or_type => 29,
	  pi_or_container_id => :new.WP_WA_ID);
  END;
/
