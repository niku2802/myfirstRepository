CREATE TRIGGER TU_PERIODS_AU_TRG
AFTER UPDATE OF TUP_NAME
  ON TU_PERIODS
FOR EACH ROW
  BEGIN
SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id => :new.TUP_ID,
                                         pi_or_name => :new.TUP_NAME);


END ;
/
