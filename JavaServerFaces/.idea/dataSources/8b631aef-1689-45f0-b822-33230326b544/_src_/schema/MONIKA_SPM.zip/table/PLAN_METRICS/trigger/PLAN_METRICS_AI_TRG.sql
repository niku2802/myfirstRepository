CREATE TRIGGER PLAN_METRICS_AI_TRG
AFTER INSERT
  ON PLAN_METRICS
FOR EACH ROW
  BEGIN
                      SYSTEM_DATA.register_object(pi_or_id => :new.PM_ID,
                                         pi_or_name => :new.PM_NAME,
                                         pi_or_type => 8,
                                         PI_OR_CONTAINER_ID => :new.PM_VER_OBJECT_ID);
         END;
/
