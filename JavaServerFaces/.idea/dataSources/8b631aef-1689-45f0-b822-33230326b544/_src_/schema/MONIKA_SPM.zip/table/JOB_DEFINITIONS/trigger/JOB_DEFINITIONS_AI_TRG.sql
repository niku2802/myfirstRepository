CREATE TRIGGER JOB_DEFINITIONS_AI_TRG
AFTER INSERT
  ON JOB_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.JD_ID,
      pi_or_name => :new.JD_NAME,
      pi_or_type => 20,
	  pi_or_container_id => :new.JD_FOL_ID);
  END;
/
