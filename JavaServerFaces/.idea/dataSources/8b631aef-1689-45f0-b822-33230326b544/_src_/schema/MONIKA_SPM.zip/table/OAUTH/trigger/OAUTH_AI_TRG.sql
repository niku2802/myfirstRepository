CREATE TRIGGER OAUTH_AI_TRG
AFTER INSERT
  ON OAUTH
FOR EACH ROW
  BEGIN
                      SYSTEM_DATA.REGISTER_OBJECT(pi_or_id           => :new.OAUTH_ID,
                                                  pi_or_name         => :new.OAUTH_NAME,
                                                  pi_or_type         => 132,
                                                  pi_or_container_id => :new.OAUTH_FOLDER_ID);
                    END;
/
