CREATE TRIGGER DT_PROCESSES_AI_TRG
AFTER INSERT
  ON DT_PROCESSES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.DTP_ID,
      pi_or_name => :new.DTP_NAME,
      pi_or_type => 40,
	  pi_or_container_id => :new.DTP_FOLDER_ID);
  END;
/
