CREATE TRIGGER OBJ_DEFINITIONS_AI_TRG
AFTER INSERT
  ON OBJ_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.OBD_ID,
      pi_or_name => :new.OBD_NAME,
      pi_or_type => 62,
	  pi_or_container_id => :new.OBD_FOL_ID);
  END;
/
