CREATE TRIGGER ROLES_AI_TRG
AFTER INSERT
  ON ROLES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.ROL_ID,
      pi_or_name => :new.ROL_NAME,
      pi_or_type => 26,
	  pi_or_container_id => :new.ROL_FOLDER_ID);
  END;
/
