CREATE TRIGGER PLAN_PARAMETERS_DEFS_AI_TRG
AFTER INSERT
  ON PLAN_PARAMETERS_DEFINITIONS
FOR EACH ROW
  BEGIN
							  SYSTEM_DATA.REGISTER_OBJECT
							  ( pi_or_id           => :new.PPD_ID,
								pi_or_name         => :new.PPD_NAME,
								pi_or_type         => 115,
							    pi_or_container_id => :new.PPD_FOL_ID);
							END;
/
