CREATE TRIGGER PV_RRV_AI_TRG
AFTER INSERT
  ON PV_RETURN_TO_REQUEST_VIEWS
FOR EACH ROW
  declare
  v_name varchar2(250 char);
begin
  select PVV_NAME
    into v_name
    from PV_VIEWS
   where PVV_ID = :new.PVRRV_PVV_ID;
  system_data.register_object(pi_or_id           => :new.PVRRV_REQ_CONT_ID,
                              pi_or_name         => v_name || ' (related requests table)',
                              pi_or_type         => 88,
                              pi_or_container_id => null);
  system_data.register_object(pi_or_id           => :new.PVRRV_TASK_CONT_ID,
                              pi_or_name         => v_name || ' (related tasks table)',
                              pi_or_type         => 89,
                              pi_or_container_id => null);
end;
/
