CREATE TRIGGER ACCEPTANCE_AGREEMENTS_AI_TRG
AFTER INSERT
  ON ACCEPTANCE_AGREEMENTS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.AA_ID,
      pi_or_name => :new.AA_NAME,
      pi_or_type => 43,
	  pi_or_container_id => :new.AA_FOLDER_ID);
  END;
/
