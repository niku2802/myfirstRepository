CREATE TRIGGER PV_VIEWS_BD_TRG
BEFORE DELETE
  ON PV_VIEWS
FOR EACH ROW
  begin
  system_data.deregister_object(pi_or_id => :old.PVV_ID);
end;
/
