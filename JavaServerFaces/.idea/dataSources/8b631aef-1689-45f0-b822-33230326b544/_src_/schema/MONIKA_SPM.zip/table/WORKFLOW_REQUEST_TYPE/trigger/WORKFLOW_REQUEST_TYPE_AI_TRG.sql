CREATE TRIGGER WORKFLOW_REQUEST_TYPE_AI_TRG
AFTER INSERT
  ON WORKFLOW_REQUEST_TYPE
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.WRT_ID,
      pi_or_name => :new.WRT_NAME,
      pi_or_type => 27,
	  pi_or_container_id => :new.WRT_WA_ID);
  END;
/
