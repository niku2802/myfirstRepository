CREATE TRIGGER ALIGNMENT_AI_TRG
AFTER INSERT
  ON ALIGNMENT_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.ALIGNMENT_ID,
      pi_or_name => :new.ALIGNMENT_NAME,
      pi_or_type => 70,
	  pi_or_container_id => :new.ALIGNMENT_FOL_ID);
  END;
/
