CREATE TRIGGER SALES_PLANNING_MODELS_AI_TRG
AFTER INSERT
  ON SALES_PLANNING_MODELS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.SPM_ID,
      pi_or_name => :new.SPM_NAME,
      pi_or_type => 117,
	  pi_or_container_id => :new.SPM_FOL_ID);
  END;
/
