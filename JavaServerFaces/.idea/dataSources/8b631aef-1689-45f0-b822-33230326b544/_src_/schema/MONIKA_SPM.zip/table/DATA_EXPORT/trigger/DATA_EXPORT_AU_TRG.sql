CREATE TRIGGER DATA_EXPORT_AU_TRG
AFTER UPDATE OF DE_NAME, DE_FOL_ID
  ON DATA_EXPORT
FOR EACH ROW
  BEGIN
	SYSTEM_DATA.MODIFY_REGISTRATION
	(	pi_or_id => :new.DE_ID,
        pi_or_name => :new.DE_NAME,
        pi_or_container_id => :new.DE_FOL_ID);
END ;
/
