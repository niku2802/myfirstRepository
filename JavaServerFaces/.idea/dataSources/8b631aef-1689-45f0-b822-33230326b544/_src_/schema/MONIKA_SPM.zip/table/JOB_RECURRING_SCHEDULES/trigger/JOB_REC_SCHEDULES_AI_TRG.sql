CREATE TRIGGER JOB_REC_SCHEDULES_AI_TRG
AFTER INSERT
  ON JOB_RECURRING_SCHEDULES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.JRS_ID,
      pi_or_name => :new.JRS_NAME,
      pi_or_type => 21,
	  pi_or_container_id => :new.JRS_FOL_ID);
  END;
/
