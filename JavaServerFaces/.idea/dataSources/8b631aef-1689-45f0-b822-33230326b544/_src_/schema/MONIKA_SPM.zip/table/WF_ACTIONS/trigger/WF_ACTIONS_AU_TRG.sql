CREATE TRIGGER WF_ACTIONS_AU_TRG
AFTER UPDATE OF WFA_NAME
  ON WF_ACTIONS
FOR EACH ROW
  BEGIN
SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id => :new.WFA_ID,
                                         pi_or_name => :new.WFA_NAME);


END ;
/
