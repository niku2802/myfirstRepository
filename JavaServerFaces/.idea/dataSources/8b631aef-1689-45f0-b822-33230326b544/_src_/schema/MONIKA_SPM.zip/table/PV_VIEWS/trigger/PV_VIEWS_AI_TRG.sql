CREATE TRIGGER PV_VIEWS_AI_TRG
AFTER INSERT
  ON PV_VIEWS
FOR EACH ROW
  begin
  system_data.register_object(pi_or_id           => :new.PVV_ID,
                              pi_or_name         => case :new.PVV_DEFINITION_TYPE_ID
                                                      when 61 then :new.PVV_NAME || ' (tasks table)'
                                                      when 76 then :new.PVV_NAME || ' (returned requests table)'
                                                      else :new.PVV_NAME end,
                              pi_or_type         => NVL(:new.PVV_DEFINITION_TYPE_ID, 93),
                              pi_or_container_id => null);
end;
/
