CREATE TRIGGER WORKFLOW_REQ_STATUS_AI_TRG
AFTER INSERT
  ON WORKFLOW_REQUEST_STATUS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.WRS_ID,
      pi_or_name => :new.WRS_NAME,
      pi_or_type => 35,
	  pi_or_container_id => :new.WRS_WA_ID);
  END;
/
