CREATE TRIGGER FOLDERS_AU_TRG
AFTER UPDATE OF FOL_NAME, FOL_CONTAINER_ID
  ON FOLDERS
FOR EACH ROW
  BEGIN
                          SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id => :new.FOL_ID,
                                                          pi_or_name => :new.FOL_NAME,
                                                          pi_or_container_id => :new.FOL_CONTAINER_ID);

                        END ;
/
