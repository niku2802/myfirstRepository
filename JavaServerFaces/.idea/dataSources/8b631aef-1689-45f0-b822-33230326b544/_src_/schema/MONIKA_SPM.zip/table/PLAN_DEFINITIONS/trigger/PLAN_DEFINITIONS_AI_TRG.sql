CREATE TRIGGER PLAN_DEFINITIONS_AI_TRG
AFTER INSERT
  ON PLAN_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.PD_ID,
      pi_or_name => :new.PD_NAME,
      pi_or_type => 4,
	  pi_or_container_id => :new.PD_FOL_ID);
  END;
/
