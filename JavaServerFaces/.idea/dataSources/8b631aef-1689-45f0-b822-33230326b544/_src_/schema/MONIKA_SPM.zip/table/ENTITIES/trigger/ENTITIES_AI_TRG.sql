CREATE TRIGGER ENTITIES_AI_TRG
AFTER INSERT
  ON ENTITIES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.ENTITY_ID,
      pi_or_name => :new.ENTITY_NAME,
      pi_or_type => 12,
	  pi_or_container_id => :new.ENTITY_FOL_ID);
  END;
/
