CREATE TRIGGER OBJECT_DEFINITIONS_AI_TRG
AFTER INSERT
  ON OBJECT_DEFINITIONS
FOR EACH ROW
  BEGIN
                          IF :new.OD_NAME IS NOT NULL THEN
                            SYSTEM_DATA.REGISTER_OBJECT
                            (  pi_or_id => :new.OD_ID,
                              pi_or_name => :new.OD_NAME,
                              pi_or_type => :new.OD_TYPE,
                            pi_or_container_id => :new.OD_CONTAINER_ID);
                          END IF;
                          END;
/
