CREATE TRIGGER ENTITY_ASSIGNMENTS_AI_TRG
AFTER INSERT
  ON ENTITY_ASSIGNMENTS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.EA_ID,
      pi_or_name => :new.EA_NAME,
      pi_or_type => 9,
	  pi_or_container_id => :new.EA_FOL_ID);
  END;
/
