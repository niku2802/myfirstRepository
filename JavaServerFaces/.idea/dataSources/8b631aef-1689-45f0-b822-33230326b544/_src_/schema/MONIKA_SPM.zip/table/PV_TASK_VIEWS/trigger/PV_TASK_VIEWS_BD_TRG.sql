CREATE TRIGGER PV_TASK_VIEWS_BD_TRG
BEFORE DELETE
  ON PV_TASK_VIEWS
FOR EACH ROW
  begin
  system_data.deregister_object(pi_or_id => :old.PVTV_REQ_CONT_ID);
end;
/
