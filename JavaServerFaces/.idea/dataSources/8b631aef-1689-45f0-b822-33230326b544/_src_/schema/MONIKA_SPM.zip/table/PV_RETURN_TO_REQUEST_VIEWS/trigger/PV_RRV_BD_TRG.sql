CREATE TRIGGER PV_RRV_BD_TRG
BEFORE DELETE
  ON PV_RETURN_TO_REQUEST_VIEWS
FOR EACH ROW
  begin
  system_data.deregister_object(pi_or_id => :old.PVRRV_REQ_CONT_ID);
  system_data.deregister_object(pi_or_id => :old.PVRRV_TASK_CONT_ID);
end;
/
