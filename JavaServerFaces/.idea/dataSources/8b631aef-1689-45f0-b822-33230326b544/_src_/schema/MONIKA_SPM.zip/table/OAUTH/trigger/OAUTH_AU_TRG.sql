CREATE TRIGGER OAUTH_AU_TRG
AFTER UPDATE OF OAUTH_NAME
  ON OAUTH
FOR EACH ROW
  BEGIN
                      SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id           => :new.OAUTH_ID,
                                                      pi_or_name         => :new.OAUTH_NAME,
                                                      pi_or_container_id => :new.OAUTH_FOLDER_ID);
                    END;
/
