CREATE TRIGGER PV_PORTAL_VIEWS_AI_TRG
AFTER INSERT
  ON PV_PORTAL_VIEWS
FOR EACH ROW
  BEGIN
                              SYSTEM_DATA.REGISTER_OBJECT
                              (  pi_or_id => :new.PVPV_ID,
                                pi_or_name => :new.PVPV_NAME,
                                pi_or_type => 53,
                              pi_or_container_id => :new.PVPV_PF_ID);
                            END;
/
