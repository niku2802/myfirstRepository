CREATE TRIGGER CREDITING_AI_TRG
AFTER INSERT
  ON CREDITING_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.CREDITING_ID,
      pi_or_name => :new.CREDITING_NAME,
      pi_or_type => 69,
	  pi_or_container_id => :new.CREDITING_FOL_ID);
  END;
/
