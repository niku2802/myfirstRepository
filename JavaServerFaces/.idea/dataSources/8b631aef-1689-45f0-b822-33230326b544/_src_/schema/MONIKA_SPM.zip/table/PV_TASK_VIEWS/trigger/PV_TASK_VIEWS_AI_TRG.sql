CREATE TRIGGER PV_TASK_VIEWS_AI_TRG
AFTER INSERT
  ON PV_TASK_VIEWS
FOR EACH ROW
  declare
  v_name varchar2(250 char);
begin
  select PVV_NAME
    into v_name
    from PV_VIEWS
   where PVV_ID = :new.PVTV_PVV_ID;
  system_data.register_object(pi_or_id           => :new.PVTV_REQ_CONT_ID,
                              pi_or_name         => v_name || ' (related requests table)',
                              pi_or_type         => 87,
                              pi_or_container_id => null);
end;
/
