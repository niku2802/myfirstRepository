CREATE TRIGGER PORTAL_FOLDERS_AU_TRG
AFTER UPDATE OF PF_NAME
  ON PORTAL_FOLDERS
FOR EACH ROW
  BEGIN
                            SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id => :new.PF_ID,
                                                                     pi_or_name => :new.PF_NAME,
                                                                     pi_or_container_id => :new.PF_PA_ID);


                            END ;
/
