CREATE TRIGGER WF_AUTOMATION_PROCESS_AI_TRG
AFTER INSERT
  ON WORKFLOW_AUTOMATION_PROCESS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.WAP_ID,
      pi_or_name => :new.WAP_NAME,
      pi_or_type => 90,
	  pi_or_container_id => NULL);
  END;
/
