CREATE TRIGGER PLAN_METRICS_AU_TRG
AFTER UPDATE OF PM_NAME
  ON PLAN_METRICS
FOR EACH ROW
  BEGIN
                   SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id => :new.PM_ID,
                                         pi_or_name => :new.PM_NAME,
                                         PI_OR_CONTAINER_ID => :new.PM_VER_OBJECT_ID);
          END ;
/
