CREATE FUNCTION COMPARE_LOGS(pin_spm_schema IN VARCHAR2,
                                        pin_log_id_1   IN NUMBER,
                                        pin_log_id_2   IN NUMBER) RETURN VARCHAR2
AS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_table_name VARCHAR2(30);
BEGIN
  SELECT 'RC' || UID_SEQUENCE.NEXTVAL
    INTO v_table_name
    FROM dual;

  DECLARE
    table_does_not_exist exception;
    pragma exception_init( table_does_not_exist, -942 );
  begin
    EXECUTE IMMEDIATE '
      INSERT INTO ' || pin_spm_schema || '.RUN_COMPARE VALUES (' || v_table_name || ', ' || pin_log_id_1 || ', ' || pin_log_id_2 || ', sysdate)';
  exception
    when table_does_not_exist then null;
  end;

  EXECUTE IMMEDIATE '
  CREATE TABLE ' || pin_spm_schema || '.' || v_table_name || ' TABLESPACE ' || pin_spm_schema || '_DTS as

  SELECT  ROWNUM AS ROW_IDENTIFIER
           ,RD1.RD_LOG_ID_ZERO_FILL
          ,RD1.PROCESS_DEF_NAME
          ,RD1.PROCESS_TYPE
          ,RD1.DURATION AS DURATION_1
          ,RD2.DURATION AS DURATION_2
          ,RD1.DURATION_SEC AS DURATION_SEC1
          ,RD2.DURATION_SEC AS DURATION_SEC2
          ,TO_CHAR(TRUNC((RD2.DURATION_SEC - RD1.DURATION_SEC)/CASE WHEN RD1.DURATION_SEC = 0 THEN 1 ELSE RD1.DURATION_SEC END* 100))
           ||CASE WHEN RD2.DURATION_SEC IS NOT NULL AND RD2.DURATION_SEC IS NOT NULL THEN ''%'' ELSE NULL END AS PERCENT_CHANGE_IN_DURATION
          ,TRUNC((RD2.DURATION_SEC - RD1.DURATION_SEC)/CASE WHEN RD1.DURATION_SEC = 0 THEN 1 ELSE RD1.DURATION_SEC END * 100) PERCENT_CHANGE
          ,RD1.DSC AS DSC_1
          ,RD2.DSC AS DSC_2
          ,RD1.PROCESS_PERIOD AS PROCESS_PERIOD_1
          ,RD1.RUN_STATUS AS RUN_STATUS_1
          ,RD1.EXECUTION_STATUS AS EXECUTION_STATUS_1
          ,RD1.START_TIME AS START_TIME_1
          ,RD1.END_TIME AS END_TIME_1
          ,RD2.PROCESS_PERIOD AS PROCESS_PERIOD_2
          ,RD2.RUN_STATUS AS RUN_STATUS_2
          ,RD2.EXECUTION_STATUS AS EXECUTION_STATUS_2
          ,RD2.START_TIME AS START_TIME_2
          ,RD2.END_TIME AS END_TIME_2
          ,RD2.DURATION_SEC - RD1.DURATION_SEC AS DURATION_DIFFERENCE
  FROM                (SELECT   RDR.RD_ID                              AS ROOT_RD_ID
              ,RDR.RD_DEFINITION_ID                   AS ROOT_PROCESS_DEF_ID
              ,RDR.RD_NAME                            AS ROOT_PROCESS_DEF_NAME
              ,RD.RD_ID
              --,RD.RD_FULL_PATH
              ,RD.RD_LOG_ID_ZERO_FILL
              ,RD.RD_DEFINITION_ID                    AS PROCESS_DEF_ID
              ,RD.RD_NAME                             AS PROCESS_DEF_NAME
              ,UPT.PROCESS_TYPE_NAME                  AS PROCESS_TYPE
              --,RD.RD_PERIOD_TYPE                      AS PROCESS_PERIOD_TYPE
              ,CASE RD.RD_PERIOD_TYPE WHEN 0 THEN ''None''
                                      WHEN 1 THEN TO_CHAR(RD.RD_DAY_TO_RUN, ''DD-MON-YYYY'')
                                      WHEN 2 THEN TPR.TUPR_PERIOD_RANGE_NAME
                                      ELSE NULL END   AS PROCESS_PERIOD
              --,RS.RS_STATUS                           AS RUN_STATUS_NO
              ,CASE RS.RS_STATUS  WHEN 1 THEN ''RUN_SUBMITTED''
                                  WHEN 2 THEN ''RUN_EXECUTION_STARTED''
                                  WHEN 3 THEN ''RUN_WAITING_FOR_CHILDREN''
                                  WHEN 4 THEN ''RUN_POST_EXECUTION_STARTED''
                                  WHEN 5 THEN ''RUN_COMPLETED''
                                  ELSE NULL END       AS RUN_STATUS
              --,RS.RS_COMPLETION_TYPE                  AS EXECUTION_STATUS_NO
              ,CASE RS.RS_COMPLETION_TYPE WHEN 0 THEN ''NOT_RUN_SUCCESSFUL/NOT_APPLICABLE''
                                          WHEN 1 THEN ''SUCCESSFUL''
                                          WHEN 2 THEN ''WITH_WARNINGS''
                                          WHEN 3 THEN ''WITH_ERRORS''
                                          WHEN 4 THEN ''FAILED''
                                          WHEN 5 THEN ''ABORTED''
                                          WHEN 6 THEN ''NOT_RUN''
                                          WHEN 7 THEN ''NOT_RUN_FAILED/DUE_TO_PREDECESSORS''
                                          ELSE NULL END AS EXECUTION_STATUS
              ,RS.RS_EXECUTION_START_TIME             AS START_TIME
              ,RS.RS_EXECUTION_END_TIME               AS END_TIME
              ,(RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) AS DURATION
              , (EXTRACT (DAY FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) * 86400)
               +(EXTRACT (HOUR FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) * 3600)
               +(EXTRACT (MINUTE FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) * 60)
               +(EXTRACT (SECOND FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME)) AS DURATION_SEC
              ,CARD.DSC
      FROM    (SELECT *
                                FROM ' || pin_spm_schema || '.RUN_DATA
                               START WITH RD_ID = ' || pin_log_id_1 || '
                              CONNECT BY PRIOR RD_ID = RD_PARENT_ID)                        RD
              INNER JOIN ' || pin_spm_schema || '.RUN_STATUS_DATA      RS ON RD.RD_ID = RS.RS_ID
              INNER JOIN ' || pin_spm_schema || '.UTL_PROCESS_TYPE     UPT ON RD.RD_TYPE = UPT.PROCESS_TYPE_ID
              INNER JOIN ' || pin_spm_schema || '.RUN_DATA             RDR ON RD.RD_ROOT_ID = RDR.RD_ID
              LEFT JOIN ' || pin_spm_schema || '.TU_PERIODS_RANGE      TPR ON RDR.RD_TUPR_ID = TPR.TUPR_ID
              LEFT JOIN
              (   SELECT  RD_ID
                         ,LISTAGG(DSC, CHR(10)) WITHIN GROUP (ORDER BY DSC) DSC
                  FROM (  -- outputs
                          SELECT   RD.RD_ID
                                  ,''Output Generated <OutputId:''||O.DTOUT_ID||''><Type:''||OT.DTOUTT_NAME||''><InsRecs:''||TO_CHAR(RDP.RDP_CARDINALITY)||''>'' AS DSC
                          FROM    ' || pin_spm_schema || '.RUN_DATA RD
                                  INNER JOIN ' || pin_spm_schema || '.DT_OUTPUTS O ON RD.RD_DEFINITION_ID = O.DTOUT_DTO_ID
                                  INNER JOIN ' || pin_spm_schema || '.DT_OUTPUT_TYPES OT ON O.DTOUT_DTOUTT_ID = DTOUTT_ID
                                  INNER JOIN ' || pin_spm_schema || '.RUN_DATA_PROFILE RDP ON RD.RD_ID = RDP.RDP_ID AND O.DTOUT_ID = RDP.RDP_OUTPUT_ID
                          UNION ALL
                          -- tables modified by Post Records/Delete Records
                          SELECT   RD.RD_ID
                                  ,''Table Modified <TableId:''||DS.DST_TABLE_ID||''><InitRecs:''||DS.DST_RECORDS_NUM_BEFORE||''>''
                                   ||CASE WHEN RD.RD_TYPE = 16 THEN ''<UpdRecs:''||DS.DST_RECORDS_UPDATED||''><InsRecs:''||CASE WHEN DS.DST_OPERATION_TYPE = 1 THEN DS.DST_NUM_IP_RECORDS_POST_FILTER ELSE DS.DST_RECORDS_INSERTED END||''>''
                                          WHEN RD.RD_TYPE = 27 THEN ''<DelRecs:''||DS.DST_RECORDS_DELETED||''>'' END AS DSC
                          FROM    ' || pin_spm_schema || '.RUN_DATA RD
                                  INNER JOIN ' || pin_spm_schema || '.UTL_PROCESS_TYPE UPT ON UPT.PROCESS_TYPE_ID = RD.RD_TYPE
                                  INNER JOIN ' || pin_spm_schema || '.DATA_STATISTICS DS ON RD.RD_ID = DS.DST_RD_ID
                          ) T
                  GROUP BY RD_ID
              ) CARD ON RD.RD_ID = CARD.RD_ID
  ) RD1
      FULL OUTER JOIN (   SELECT   RDR.RD_ID                              AS ROOT_RD_ID
              ,RDR.RD_DEFINITION_ID                   AS ROOT_PROCESS_DEF_ID
              ,RDR.RD_NAME                            AS ROOT_PROCESS_DEF_NAME
              ,RD.RD_ID
              --,RD.RD_FULL_PATH
              ,RD.RD_LOG_ID_ZERO_FILL
              ,RD.RD_DEFINITION_ID                    AS PROCESS_DEF_ID
              ,RD.RD_NAME                             AS PROCESS_DEF_NAME
              ,UPT.PROCESS_TYPE_NAME                  AS PROCESS_TYPE
              --,RD.RD_PERIOD_TYPE                      AS PROCESS_PERIOD_TYPE
              ,CASE RD.RD_PERIOD_TYPE WHEN 0 THEN ''None''
                                      WHEN 1 THEN TO_CHAR(RD.RD_DAY_TO_RUN, ''DD-MON-YYYY'')
                                      WHEN 2 THEN TPR.TUPR_PERIOD_RANGE_NAME
                                      ELSE NULL END   AS PROCESS_PERIOD
              --,RS.RS_STATUS                           AS RUN_STATUS_NO
              ,CASE RS.RS_STATUS  WHEN 1 THEN ''RUN_SUBMITTED''
                                  WHEN 2 THEN ''RUN_EXECUTION_STARTED''
                                  WHEN 3 THEN ''RUN_WAITING_FOR_CHILDREN''
                                  WHEN 4 THEN ''RUN_POST_EXECUTION_STARTED''
                                  WHEN 5 THEN ''RUN_COMPLETED''
                                  ELSE NULL END       AS RUN_STATUS
              --,RS.RS_COMPLETION_TYPE                  AS EXECUTION_STATUS_NO
              ,CASE RS.RS_COMPLETION_TYPE WHEN 0 THEN ''NOT_RUN_SUCCESSFUL/NOT_APPLICABLE''
                                          WHEN 1 THEN ''SUCCESSFUL''
                                          WHEN 2 THEN ''WITH_WARNINGS''
                                          WHEN 3 THEN ''WITH_ERRORS''
                                          WHEN 4 THEN ''FAILED''
                                          WHEN 5 THEN ''ABORTED''
                                          WHEN 6 THEN ''NOT_RUN''
                                          WHEN 7 THEN ''NOT_RUN_FAILED/DUE_TO_PREDECESSORS''
                                          ELSE NULL END AS EXECUTION_STATUS
              ,RS.RS_EXECUTION_START_TIME             AS START_TIME
              ,RS.RS_EXECUTION_END_TIME               AS END_TIME
              ,(RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) AS DURATION
              , (EXTRACT (DAY FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) * 86400)
               +(EXTRACT (HOUR FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) * 3600)
               +(EXTRACT (MINUTE FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME) * 60)
               +(EXTRACT (SECOND FROM RS.RS_EXECUTION_END_TIME - RS.RS_EXECUTION_START_TIME)) AS DURATION_SEC
              ,CARD.DSC
      FROM    (SELECT *
                                FROM ' || pin_spm_schema || '.RUN_DATA
                               START WITH RD_ID = ' || pin_log_id_2 || '
                              CONNECT BY PRIOR RD_ID = RD_PARENT_ID)                        RD
              INNER JOIN ' || pin_spm_schema || '.RUN_STATUS_DATA      RS ON RD.RD_ID = RS.RS_ID
              INNER JOIN ' || pin_spm_schema || '.UTL_PROCESS_TYPE     UPT ON RD.RD_TYPE = UPT.PROCESS_TYPE_ID
              INNER JOIN ' || pin_spm_schema || '.RUN_DATA             RDR ON RD.RD_ROOT_ID = RDR.RD_ID
              LEFT JOIN ' || pin_spm_schema || '.TU_PERIODS_RANGE      TPR ON RDR.RD_TUPR_ID = TPR.TUPR_ID
              LEFT JOIN
              (   SELECT  RD_ID
                         ,LISTAGG(DSC, CHR(10)) WITHIN GROUP (ORDER BY DSC) DSC
                  FROM (  -- outputs
                          SELECT   RD.RD_ID
                                  ,''Output Generated <OutputId:''||O.DTOUT_ID||''><Type:''||OT.DTOUTT_NAME||''><InsRecs:''||TO_CHAR(RDP.RDP_CARDINALITY)||''>'' AS DSC
                          FROM    ' || pin_spm_schema || '.RUN_DATA RD
                                  INNER JOIN ' || pin_spm_schema || '.DT_OUTPUTS O ON RD.RD_DEFINITION_ID = O.DTOUT_DTO_ID
                                  INNER JOIN ' || pin_spm_schema || '.DT_OUTPUT_TYPES OT ON O.DTOUT_DTOUTT_ID = DTOUTT_ID
                                  INNER JOIN ' || pin_spm_schema || '.RUN_DATA_PROFILE RDP ON RD.RD_ID = RDP.RDP_ID AND O.DTOUT_ID = RDP.RDP_OUTPUT_ID
                          UNION ALL
                          -- tables modified by Post Records/Delete Records
                          SELECT   RD.RD_ID
                                  ,''Table Modified <TableId:''||DS.DST_TABLE_ID||''><InitRecs:''||DS.DST_RECORDS_NUM_BEFORE||''>''
                                   ||CASE WHEN RD.RD_TYPE = 16 THEN ''<UpdRecs:''||DS.DST_RECORDS_UPDATED||''><InsRecs:''||CASE WHEN DS.DST_OPERATION_TYPE = 1 THEN DS.DST_NUM_IP_RECORDS_POST_FILTER ELSE DS.DST_RECORDS_INSERTED END||''>''
                                          WHEN RD.RD_TYPE = 27 THEN ''<DelRecs:''||DS.DST_RECORDS_DELETED||''>'' END AS DSC
                          FROM    ' || pin_spm_schema || '.RUN_DATA RD
                                  INNER JOIN ' || pin_spm_schema || '.UTL_PROCESS_TYPE UPT ON UPT.PROCESS_TYPE_ID = RD.RD_TYPE
                                  INNER JOIN ' || pin_spm_schema || '.DATA_STATISTICS DS ON RD.RD_ID = DS.DST_RD_ID
                          ) T
                  GROUP BY RD_ID
              ) CARD ON RD.RD_ID = CARD.RD_ID
  ) RD2 ON RD1.PROCESS_DEF_ID = RD2.PROCESS_DEF_ID AND RD1.PROCESS_DEF_NAME = RD2.PROCESS_DEF_NAME
  ORDER BY RD1.RD_LOG_ID_ZERO_FILL ASC';

  RETURN v_table_name;

END COMPARE_LOGS;
/
