CREATE procedure GET_DIRECTORY_FOR_PATH(path IN VARCHAR2, root IN VARCHAR2,dirId OUT number) AS
LANGUAGE JAVA NAME 'DirectoryCreator.getDirectoryForPath(java.lang.String , java.lang.String , java.lang.Long[] )';
/
