CREATE procedure PVFiltersDuplicationToolFixed(cursor_value in sys_refcursor) as
  LANGUAGE JAVA NAME 'PVFiltersDuplicationToolFixed.updateFilters(java.sql.ResultSet)';
/
