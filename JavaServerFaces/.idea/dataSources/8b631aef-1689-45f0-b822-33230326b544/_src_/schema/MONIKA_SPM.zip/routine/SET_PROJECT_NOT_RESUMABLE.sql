CREATE procedure set_project_not_resumable is
						  pragma autonomous_transaction;
					   begin
						  execute immediate 'update PROPERTIES set PR_VALUE = 0 where PR_NAME= ''RESUMABLE'' ';
						  commit;
					   end set_project_not_resumable;
/
