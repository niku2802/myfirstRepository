CREATE PROCEDURE UserAndTimeFrameFilterMigrator
  AS LANGUAGE JAVA NAME 'UserAndTimeFrameFilterMigrator.migrate()';
/
