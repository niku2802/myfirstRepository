CREATE PROCEDURE SRVPrimaryViewFilterMigrator
 AS LANGUAGE JAVA NAME  'SRVPrimaryViewFilterMigrator.migrate()';
/
