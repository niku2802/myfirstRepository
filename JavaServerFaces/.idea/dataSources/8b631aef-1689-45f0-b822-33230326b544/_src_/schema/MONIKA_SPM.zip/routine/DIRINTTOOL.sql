CREATE procedure DIRINTTOOL  IS
   LANGUAGE JAVA NAME 'DirectoriesIntegrationTool.run () ';
/
