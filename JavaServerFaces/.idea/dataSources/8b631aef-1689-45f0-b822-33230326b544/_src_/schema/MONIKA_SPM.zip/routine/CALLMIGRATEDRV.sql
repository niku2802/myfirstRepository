CREATE Function CallMigrateDRV(pin_server_path in out VARCHAR2)
  return widgets_t aS
  LANGUAGE JAVA NAME 'MigrateDRV.migrate(java.lang.String[])
                             return java.sql.Array';
/
