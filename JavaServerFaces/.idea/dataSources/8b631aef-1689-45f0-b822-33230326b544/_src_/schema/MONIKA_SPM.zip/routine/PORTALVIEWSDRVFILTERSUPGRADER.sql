CREATE procedure PortalViewsDRVFiltersUpgrader(cursor_value in sys_refcursor) as
  LANGUAGE JAVA NAME 'PortalViewsDRVFiltersUpgrader.updateFilters(java.sql.ResultSet)';
/
