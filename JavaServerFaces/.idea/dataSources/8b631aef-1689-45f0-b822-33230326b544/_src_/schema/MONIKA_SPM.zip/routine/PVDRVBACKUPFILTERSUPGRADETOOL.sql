CREATE procedure PVDRVBackupFiltersUpgradeTool(cursor_value in sys_refcursor) as
  LANGUAGE JAVA NAME 'PVDRVBackupFiltersUpgradeTool.updateFilters(java.sql.ResultSet)';
/
