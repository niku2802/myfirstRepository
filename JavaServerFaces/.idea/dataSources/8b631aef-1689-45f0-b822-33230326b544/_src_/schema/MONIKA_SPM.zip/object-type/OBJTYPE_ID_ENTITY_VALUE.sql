CREATE TYPE              "OBJTYPE_ID_ENTITY_VALUE" FORCE AS OBJECT
      (
        ID                       NUMBER(10),
        ENTITY_ID                NUMBER(10),
        ENTITY_E_INTERNAL_ID     NUMBER(10),
        VALUE                    NUMBER,
        OUTSTANDING_ALLOCATION   NUMBER(10),
        IS_PARENT_MODIFIED       NUMBER(1)
      )
/
