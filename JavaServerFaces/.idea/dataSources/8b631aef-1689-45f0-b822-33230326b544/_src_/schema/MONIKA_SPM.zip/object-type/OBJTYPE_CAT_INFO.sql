CREATE TYPE              "OBJTYPE_CAT_INFO" /*CreditingApproachTable */
   FORCE AS OBJECT
   (
      CAT_TYPE NUMBER (1),                               		 -- 1 = Alignment Table, 2  = Assignment Table --- OF-a
      CAT_NAME VARCHAR2 (30 CHAR),                               -- creditingApproachTableName either ALignment result table name or Assignment table name
      CAT_ALIAS VARCHAR2 (30 CHAR),                              -- Alias for creditingApproachTableName
      CAT_ENTITY_COL_NAME VARCHAR2 (30 CHAR),                    -- Crediting entity column name
      CAT_START_COL_NAME VARCHAR2 (30 CHAR),                     -- StartColumnNameInCAT (Date or Period)
      CAT_END_COL_NAME VARCHAR2 (30 CHAR),                       -- EndColumnNameInCAT(Date or Period)
      CAT_ALLOCATION_COL_NAME VARCHAR2 (30 CHAR),                -- Allocation column name
      CAT_IS_ALLOCATION_APPLICABLE NUMBER (1)                    -- 0 - No, 1 - Yes
   )
/
