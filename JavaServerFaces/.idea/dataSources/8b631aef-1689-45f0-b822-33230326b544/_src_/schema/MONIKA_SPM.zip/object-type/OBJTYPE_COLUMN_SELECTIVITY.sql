CREATE TYPE              "OBJTYPE_COLUMN_SELECTIVITY" 
                            FORCE AS OBJECT
                            (
                               TABLE_NAME         VARCHAR2 (30 CHAR),
                               COLUMN_NAME        VARCHAR2 (30 CHAR),
                               COLUMN_SELECTIVITY NUMBER(10,5)
                            )
/
