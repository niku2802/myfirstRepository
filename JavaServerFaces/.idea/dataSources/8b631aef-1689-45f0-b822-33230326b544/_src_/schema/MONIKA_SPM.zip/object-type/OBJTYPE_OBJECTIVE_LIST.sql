CREATE TYPE              "OBJTYPE_OBJECTIVE_LIST" FORCE AS OBJECT
                        (
                          PERIOD_RANGE_ID   NUMBER(10),
                          OBJECTIVE_ID      NUMBER(10),
                          OBJECTIVE         VARCHAR2(250 CHAR),
                          OBJECTIVE_PRIVACY VARCHAR2(30 CHAR),
                          ORGANIZATION_ID   NUMBER,
                          TARGET_VALUE      NUMBER,
                          ATTAINMENT        NUMBER,
                          WEIGHT            NUMBER,
                          ASSIGNEES_NUMBER  NUMBER
                        )
/
