CREATE TYPE              "OBJTYPE_LISTAGG_JAVA" AS OBJECT
	(
		 wordlist	CLOB
		,wordcount	NUMBER(10)
		,delimiter	VARCHAR2(4000)
		,maxcount	NUMBER(10)

		,STATIC FUNCTION odciaggregateinitialize
		 (
			pinout_aggobj	IN OUT OBJTYPE_LISTAGG_JAVA
		 ) RETURN NUMBER

		,MEMBER FUNCTION odciaggregateiterate
		 (
			 SELF			IN OUT OBJTYPE_LISTAGG_JAVA
			,pin_word_dlm	IN OBJTYPE_WORD_DLM
		 ) RETURN NUMBER

		,MEMBER FUNCTION odciaggregateterminate
		 (
			 SELF			IN OBJTYPE_LISTAGG_JAVA
			,pout_retval	OUT CLOB
			,pin_flags		IN NUMBER
		 ) RETURN NUMBER

		,MEMBER FUNCTION odciaggregatemerge
		 (
			 SELF			IN OUT OBJTYPE_LISTAGG_JAVA
			,pin_aggobj1	IN OBJTYPE_LISTAGG_JAVA
		 ) RETURN NUMBER
	)
/
