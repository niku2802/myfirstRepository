CREATE TYPE              "OBJTYPE_OBJECTIVE_ASSIGNEE" FORCE AS OBJECT
                        (
                          ENTITY_ID       NUMBER(10),
                          WEIGHT          NUMBER
                        )
/
