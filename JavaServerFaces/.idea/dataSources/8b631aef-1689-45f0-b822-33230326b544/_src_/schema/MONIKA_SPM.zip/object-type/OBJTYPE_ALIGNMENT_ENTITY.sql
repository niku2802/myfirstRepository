CREATE TYPE              "OBJTYPE_ALIGNMENT_ENTITY" 
    FORCE AS OBJECT
    (
        ENTITY_COLUMN_NAME                VARCHAR2 (30 CHAR),                     -- NULL
        ENTITY_TABLE_NAME                   VARCHAR2 (30 CHAR),                     -- NOT NULL
        ENTITY_TABLE_ALIAS                   VARCHAR2 (30 CHAR),                     -- NOT NULL
        IS_ALLOCATION_APPLICABLE          NUMBER (1),                                  -- NOT NULL
        ALLOW_DUAL_ALIGNMENTS           NUMBER (1),                                  -- NOT NULL
        IS_HIERARCHY_BASED                   NUMBER (1),                                  -- NOT NULL     ALIGNMENT ENTITY VALUES BASED ON HIERARCHY: 1 = YES, 0 = NO                                          -- OF-7722
        ENTITY_HIERARCHY_INFO             COLTYPE_ENTITY_HIERARCHY_INFO,  -- NULL             -- NULL WHEN IS_HIERARCHY_BASED = 0                                                                                          -- OF-7722
        DATE_RANGE_OPTION                  NUMBER(1)                                     -- NULL           -- NULL WHEN IS_HIERARCHY_BASED = 0, ELSE -- 1 - FIRST DAY, 2 - LAST DAY, 3 - ANY DAY, 4 - EVERY DAY    -- OF-7722
    )
/
