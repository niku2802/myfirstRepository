CREATE TYPE              "OBJTYPE_CRED_CONDITIONS_INFO" 
     FORCE AS OBJECT
   (
      CC_IS_APPLICABLE NUMBER (1),               -- NOT NULL,    -- 0 = No, 1 = Yes
      CC_AT_VALUES_APPLY_TO NUMBER (1),          -- NOT NULL     -- Conditions Apply to: 1 = ALL, 2 = Specified values : of AT (Approach Table) Entities
      CC_DATE_RANGE_OPTION  NUMBER(1),           -- NULL         -- 1 = FIRST DAY, 2 = LAST DAY, 3 = ANY DAY, 4 = EVERY DAY
      CC_JOIN_CLAUSE_AT CLOB,          -- NULL, when IS_CRED_CONDITION_APPLICABLE = 0
      CC_JOIN_CLAUSE_DT CLOB           -- NULL, when IS_CRED_CONDITION_APPLICABLE = 0
   )
/
