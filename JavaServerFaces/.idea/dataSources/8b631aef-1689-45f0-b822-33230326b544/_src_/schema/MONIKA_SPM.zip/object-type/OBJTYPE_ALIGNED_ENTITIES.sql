CREATE TYPE              "OBJTYPE_ALIGNED_ENTITIES" 
    FORCE AS OBJECT
    (
        ENTITY_COLUMN_NAME                       VARCHAR2 (30 CHAR),                     -- NULL
        ENTITY_TABLE_NAME                          VARCHAR2 (30 CHAR),                     -- NOT NULL
        ENTITY_TABLE_ALIAS                          VARCHAR2 (30 CHAR),                     -- NOT NULL
        ALIGNMENT_METHOD_OPTION               NUMBER(1),                                   -- NOT NULL     -- ALIGNED ENTITY VALUES BASED ON: 1 = SPECIFIED VALUES, 2 = ASSIGNMENT TABLE BETWEEN ALIGNED ENTITY AND ALIGNMENT ENTITY, 3 = ASSIGNMENT TABLE BETWEEN ALIGNED ENTITY AND OTHER ENTITY, 4 = HIERARCHY -- OF-7722
        ASSIGNMENT_TABLE_NAME                   VARCHAR2 (30 CHAR),                     -- NULL
        ASSIGNED_ENTITY_COLUMN_NAME         VARCHAR2 (30 CHAR),                     -- NULL
        ASSIGNED_ENTITY_TABLE_NAME            VARCHAR2 (30 CHAR),                     -- NULL
        ASSIGNED_ENTITY_TABLE_ALIAS            VARCHAR2 (30 CHAR),                     -- NULL
        ENTITY_HIERARCHY_INFO                     COLTYPE_ENTITY_HIERARCHY_INFO,  -- NULL    -- NULL WHEN ALIGNMENT_METHOD_OPTION = 4                                     -- OF-7722
        DATE_RANGE_OPTION                          NUMBER(1)                                     -- NULL    -- NULL WHEN ALIGNMENT_METHOD_OPTION = 1 OR NON-DATED ASSIGNMENT TABLE OR HIERARCHY IS USED, ELSE NOT NULL : 1 - FIRST DAY, 2 - LAST DAY, 3 - ANY DAY, 4 - EVERY DAY
    )
/
