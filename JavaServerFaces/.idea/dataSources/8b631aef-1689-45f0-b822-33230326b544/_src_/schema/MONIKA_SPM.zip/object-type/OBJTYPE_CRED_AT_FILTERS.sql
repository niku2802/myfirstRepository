CREATE TYPE              "OBJTYPE_CRED_AT_FILTERS" 
        FORCE AS OBJECT
      (
         -- CAF_ENTITY_NAME VARCHAR2 (30 CHAR), -- NOT NULL -- OF-aa  Get this added from Java and till then use CAF_ENTITY_TABLE_NAME || _ent_name
         CAF_ENTITY_TABLE_NAME                   VARCHAR2 (30 CHAR),                     -- NOT NULL
         CAF_ENTITY_TABLE_ALIAS                  VARCHAR2 (30 CHAR),                     -- NOT NULL
         CAF_FILTER_EVALUATION                   CLOB                          -- NULL            -- NULL WHEN FILTER_CRITERIA = 0
      )
/
