CREATE TYPE              "OBJTYPE_HIER_COLS_SDM" AS OBJECT
                                                                                (
                                                                                  HIER_ORDER  NUMBER,
                                                                                  HIER_FIELDS CLOB
                                                                                )
/
