CREATE PACKAGE BODY commons_timeunits AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    :  SPM
-- Product          :  commons
-- Module           :  timeunits-commons
-- Requester        :  Katti, Anuja
-- Author           :  Rohit, Maxim
-- Reviewer         :  Sharma, Pooja
-- Review date      :  13-Apr-2011
-- Description      :  This package adds and modify system Time Unit and their correspondance
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************

-- deshmukha commented all the system fiscal time units as part of TU CDM changes OF-77315
TYPE COLTYPE_TIME_UNIT IS TABLE OF OBJTYPE_TIME_UNITS;
GVCOL_TIME_UNITS COLTYPE_TIME_UNIT := COLTYPE_TIME_UNIT(
OBJTYPE_TIME_UNITS(1, 'Year',     0, 12, 1),   /* OBJTYPE_TIME_UNITS(2, 'Year (Fiscal)',     1, 12, 1),*/
OBJTYPE_TIME_UNITS(3, 'Semester',   0, 6, 2),   /* OBJTYPE_TIME_UNITS(4, 'Semester (Fiscal)',   1, 6, 2),*/
OBJTYPE_TIME_UNITS(5, 'Trimester',   0, 4, 3),   /* OBJTYPE_TIME_UNITS(6, 'Trimester (Fiscal)', 1, 4, 3),*/
OBJTYPE_TIME_UNITS(7, 'Quarter',   0, 3, 4),   /* OBJTYPE_TIME_UNITS(8, 'Quarter (Fiscal)',   1, 3, 4),*/
OBJTYPE_TIME_UNITS(9, 'Month',     0, 1, 12));

-- deshmukha commented all the system fiscal time unit periods as part of TU CDM changes OF-77315
TYPE COLTYPE_TU_PERIODS IS TABLE OF OBJTYPE_TIME_PERIODS;
GVCOL_TU_PERIODS COLTYPE_TU_PERIODS := COLTYPE_TU_PERIODS(
OBJTYPE_TIME_PERIODS(1,  1, 'Year', 1, 1, 1, 0),
/*OBJTYPE_TIME_PERIODS(2,  2, 'Fiscal Year', 4, 1, 4, 0),      OBJTYPE_TIME_PERIODS(34, 2, 'Fiscal Year', 7, 1, 7, 0),      OBJTYPE_TIME_PERIODS(35, 2, 'Fiscal Year', 10, 1, 10, 0),*/
OBJTYPE_TIME_PERIODS(3,  9, 'January', 1, 1, 1, 0),        OBJTYPE_TIME_PERIODS(4,  9, 'February', 2, 2, 2, 0),        OBJTYPE_TIME_PERIODS(5,  9, 'March', 3, 3, 3, 0),
OBJTYPE_TIME_PERIODS(6,  9, 'April', 4, 4, 4, 0),          OBJTYPE_TIME_PERIODS(7,  9, 'May', 5, 5, 5, 0),          OBJTYPE_TIME_PERIODS(8,  9, 'June', 6, 6, 6, 0),
OBJTYPE_TIME_PERIODS(9,  9, 'July', 7, 7, 7, 0),          OBJTYPE_TIME_PERIODS(10, 9, 'August', 8, 8, 8, 0),        OBJTYPE_TIME_PERIODS(11, 9, 'September', 9, 9, 9, 0),
OBJTYPE_TIME_PERIODS(12, 9, 'October', 10, 10, 10, 0),      OBJTYPE_TIME_PERIODS(13, 9, 'November', 11, 11, 11, 0),      OBJTYPE_TIME_PERIODS(14, 9, 'December', 12, 12, 12, 0),
OBJTYPE_TIME_PERIODS(16, 5, 'Trimester 1', 1, 1, 1, 0),      OBJTYPE_TIME_PERIODS(17, 5, 'Trimester 2', 5, 2, 1, 0),      OBJTYPE_TIME_PERIODS(18, 5, 'Trimester 3', 9, 3, 1, 0),
/*OBJTYPE_TIME_PERIODS(19, 6, 'Fiscal Trimester 1', 4, 1, 4, 0),  OBJTYPE_TIME_PERIODS(20, 6, 'Fiscal Trimester 2', 8, 2, 4, 0),  OBJTYPE_TIME_PERIODS(21, 6, 'Fiscal Trimester 3', 12, 3, 4, 0),
OBJTYPE_TIME_PERIODS(36, 6, 'Fiscal Trimester 1', 7, 1, 7, 0),  OBJTYPE_TIME_PERIODS(37, 6, 'Fiscal Trimester 2', 11, 2, 7, 0), OBJTYPE_TIME_PERIODS(38, 6, 'Fiscal Trimester 3', 3, 3, 7, 1),
OBJTYPE_TIME_PERIODS(39, 6, 'Fiscal Trimester 1', 10, 1, 10, 0),OBJTYPE_TIME_PERIODS(40, 6, 'Fiscal Trimester 2', 2, 2, 10, 1), OBJTYPE_TIME_PERIODS(41, 6, 'Fiscal Trimester 3', 6, 3, 10, 1),
*/OBJTYPE_TIME_PERIODS(22, 7, 'Quarter 1', 1, 1, 1, 0),        OBJTYPE_TIME_PERIODS(23, 7, 'Quarter 2', 4, 2, 1, 0),        OBJTYPE_TIME_PERIODS(24, 7, 'Quarter 3', 7, 3, 1, 0),
OBJTYPE_TIME_PERIODS(25, 7, 'Quarter 4', 10, 4, 1, 0),      /*OBJTYPE_TIME_PERIODS(26, 8, 'Fiscal Quarter 1', 4, 1, 4, 0),    OBJTYPE_TIME_PERIODS(27, 8, 'Fiscal Quarter 2', 7, 2, 4, 0),
OBJTYPE_TIME_PERIODS(28, 8, 'Fiscal Quarter 3', 10, 3, 4, 0),    OBJTYPE_TIME_PERIODS(29, 8, 'Fiscal Quarter 4', 1, 4, 4, 1),    OBJTYPE_TIME_PERIODS(42, 8, 'Fiscal Quarter 1', 7, 1, 7, 0),
OBJTYPE_TIME_PERIODS(43, 8, 'Fiscal Quarter 2', 10, 2, 7, 0),    OBJTYPE_TIME_PERIODS(44, 8, 'Fiscal Quarter 3', 1, 3, 7, 1),    OBJTYPE_TIME_PERIODS(45, 8, 'Fiscal Quarter 4', 4, 4, 7, 1),
OBJTYPE_TIME_PERIODS(46, 8, 'Fiscal Quarter 1', 10, 1, 10, 0),  OBJTYPE_TIME_PERIODS(47, 8, 'Fiscal Quarter 2', 1, 2, 10, 1),    OBJTYPE_TIME_PERIODS(48, 8, 'Fiscal Quarter 3', 4, 3, 10, 1),
OBJTYPE_TIME_PERIODS(49, 8, 'Fiscal Quarter 4', 7, 4, 10, 1),*/    OBJTYPE_TIME_PERIODS(30, 3, 'Semester 1', 1, 1, 1, 0),      OBJTYPE_TIME_PERIODS(31, 3, 'Semester 2', 7, 2, 1, 0)/*,
OBJTYPE_TIME_PERIODS(32, 4, 'Fiscal Semester 1', 4, 1, 4, 0),    OBJTYPE_TIME_PERIODS(33, 4, 'Fiscal Semester 2', 10, 2, 4, 0),  OBJTYPE_TIME_PERIODS(50, 4, 'Fiscal Semester 1', 7, 1, 7, 0),
OBJTYPE_TIME_PERIODS(51, 4, 'Fiscal Semester 2', 1, 2, 7, 1),    OBJTYPE_TIME_PERIODS(52, 4, 'Fiscal Semester 1', 10, 1, 10, 0), OBJTYPE_TIME_PERIODS(53, 4, 'Fiscal Semester 2', 4, 2, 10, 1)*/);

-- deshmukha commented all the correspondense related to system fiscal time units part of TU CDM changes OF-77315
TYPE COLTYPE_TU_CORR IS TABLE OF OBJTYPE_TU_CORR;
GVCOL_TU_CORR COLTYPE_TU_CORR := COLTYPE_TU_CORR(
OBJTYPE_TU_CORR(1,  'Trimester',      'Year'),/*        OBJTYPE_TU_CORR(2, 'Trimester (Fiscal)','Year (Fiscal)'),      OBJTYPE_TU_CORR(3, 'Semester',      'Semester (Fiscal)'),*/


OBJTYPE_TU_CORR(4,  'Semester',      'Year'),       /* OBJTYPE_TU_CORR(5, 'Semester',      'Year (Fiscal)'), */     /*OBJTYPE_TU_CORR(6, 'Semester (Fiscal)', 'Year (Fiscal)'),*/
/*OBJTYPE_TU_CORR(7,  'Semester (Fiscal)','Semester'),      OBJTYPE_TU_CORR(8, 'Semester (Fiscal)', 'Year'),          OBJTYPE_TU_CORR(9, 'Quarter',        'Quarter (Fiscal)'),*/
OBJTYPE_TU_CORR(10, 'Quarter',      'Semester'),      /*OBJTYPE_TU_CORR(11, 'Quarter',      'Semester (Fiscal)'),*/    OBJTYPE_TU_CORR(12, 'Quarter',      'Year'),
/*OBJTYPE_TU_CORR(13, 'Quarter',      'Year (Fiscal)'),    OBJTYPE_TU_CORR(14, 'Quarter (Fiscal)', 'Quarter'),        OBJTYPE_TU_CORR(15, 'Quarter (Fiscal)', 'Semester'),*/
/*OBJTYPE_TU_CORR(16, 'Quarter (Fiscal)',  'Year'),        OBJTYPE_TU_CORR(17, 'Quarter (Fiscal)', 'Year (Fiscal)'), */     OBJTYPE_TU_CORR(18, 'Month',        'Quarter'),
/*OBJTYPE_TU_CORR(19, 'Month',        'Quarter (Fiscal)'),*/OBJTYPE_TU_CORR(20, 'Month',        'Semester'),       /* OBJTYPE_TU_CORR(21, 'Month',        'Semester (Fiscal)'),*/
OBJTYPE_TU_CORR(22, 'Month',        'Trimester'),      /*OBJTYPE_TU_CORR(23, 'Month',        'Trimester (Fiscal)'),*/  OBJTYPE_TU_CORR(24, 'Month',        'Year')
/*OBJTYPE_TU_CORR(25, 'Month',        'Year (Fiscal)'),OBJTYPE_TU_CORR(26, 'Quarter (Fiscal)', 'Semester (Fiscal)')*/);


-- deshmukha commented all the correspondense related to system fiscal time units part of TU CDM changes OF-77315
TYPE COLTYPE_TU_C0RR_PERIODS IS TABLE OF OBJTYPE_TU_PERIODS_CORR;

GVCOL_TU_CORR_PERIODS COLTYPE_TU_C0RR_PERIODS := COLTYPE_TU_C0RR_PERIODS(

OBJTYPE_TU_PERIODS_CORR(1,   'Trimester 1', 'Year', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(2,   'Trimester 2', 'Year', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(3,   'Trimester 3', 'Year', 1, 1, 3, 1, 2),



/*OBJTYPE_TU_PERIODS_CORR(4,   'Fiscal Trimester 1', 'Fiscal Year', 4, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(5,   'Fiscal Trimester 2', 'Fiscal Year', 4, 4, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(6,   'Fiscal Trimester 3', 'Fiscal Year', 4, 4, 3, 1, 2),


OBJTYPE_TU_PERIODS_CORR(7,   'Fiscal Trimester 1', 'Fiscal Year', 7, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(8,   'Fiscal Trimester 2', 'Fiscal Year', 7, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(9,   'Fiscal Trimester 3', 'Fiscal Year', 7, 7, 3, 1, 2),

OBJTYPE_TU_PERIODS_CORR(10,  'Fiscal Trimester 1', 'Fiscal Year', 10, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(11,  'Fiscal Trimester 2', 'Fiscal Year', 10, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(12,  'Fiscal Trimester 3', 'Fiscal Year', 10, 10, 3, 1, 2),*/

/*OBJTYPE_TU_PERIODS_CORR(13,  'Semester 1', 'Fiscal Semester 2', 1, 7, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(14,  'Semester 2', 'Fiscal Semester 1', 1, 7, 2, 1, 3),
*/
OBJTYPE_TU_PERIODS_CORR(15,  'Semester 1', 'Year', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(16,  'Semester 2', 'Year', 1, 1, 2, 1, 2),

/*OBJTYPE_TU_PERIODS_CORR(17,  'Semester 1', 'Fiscal Year', 1, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(18,  'Semester 2', 'Fiscal Year', 1, 7, 2, 1, 3),*/

/*OBJTYPE_TU_PERIODS_CORR(19,  'Fiscal Semester 1', 'Fiscal Year', 4, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(20,  'Fiscal Semester 2', 'Fiscal Year', 4, 4, 2, 1, 2),

OBJTYPE_TU_PERIODS_CORR(21,  'Fiscal Semester 1', 'Fiscal Year', 4, 10, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(22,  'Fiscal Semester 2', 'Fiscal Year', 4, 10, 2, 1, 2),

OBJTYPE_TU_PERIODS_CORR(23,  'Fiscal Semester 1', 'Semester 2', 7, 1, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(24,  'Fiscal Semester 2', 'Semester 1', 7, 1, 2, 1, 2),

OBJTYPE_TU_PERIODS_CORR(25,  'Fiscal Semester 1', 'Year', 7, 1, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(26,  'Fiscal Semester 2', 'Year', 7, 1, 2, 1, 2),

OBJTYPE_TU_PERIODS_CORR(27,  'Fiscal Semester 1', 'Fiscal Year', 7, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(28,  'Fiscal Semester 2', 'Fiscal Year', 7, 7, 2, 1, 2),

OBJTYPE_TU_PERIODS_CORR(29,  'Fiscal Semester 1', 'Fiscal Year', 10, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(30,  'Fiscal Semester 2', 'Fiscal Year', 10, 4, 2, 1, 3),

OBJTYPE_TU_PERIODS_CORR(31,  'Fiscal Semester 1', 'Fiscal Year', 10, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(32,  'Fiscal Semester 2', 'Fiscal Year', 10, 10, 2, 1, 2),

OBJTYPE_TU_PERIODS_CORR(33,  'Quarter 1', 'Fiscal Quarter 4', 1, 4, 1, 4, 2),
OBJTYPE_TU_PERIODS_CORR(34,  'Quarter 2', 'Fiscal Quarter 1', 1, 4, 2, 1, 3),
OBJTYPE_TU_PERIODS_CORR(35,  'Quarter 3', 'Fiscal Quarter 2', 1, 4, 3, 2, 3),
OBJTYPE_TU_PERIODS_CORR(36,  'Quarter 4', 'Fiscal Quarter 3', 1, 4, 4, 3, 3),


OBJTYPE_TU_PERIODS_CORR(37,  'Quarter 1', 'Fiscal Quarter 3', 1, 7, 1, 3, 2),
OBJTYPE_TU_PERIODS_CORR(38,  'Quarter 2', 'Fiscal Quarter 4', 1, 7, 2, 4, 2),
OBJTYPE_TU_PERIODS_CORR(39,  'Quarter 3', 'Fiscal Quarter 1', 1, 7, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(40,  'Quarter 4', 'Fiscal Quarter 2', 1, 7, 4, 2, 3),


OBJTYPE_TU_PERIODS_CORR(41,  'Quarter 1', 'Fiscal Quarter 2', 1, 10, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(42,  'Quarter 2', 'Fiscal Quarter 3', 1, 10, 2, 3, 2),
OBJTYPE_TU_PERIODS_CORR(43,  'Quarter 3', 'Fiscal Quarter 4', 1, 10, 3, 4, 2),
OBJTYPE_TU_PERIODS_CORR(44,  'Quarter 4', 'Fiscal Quarter 1', 1, 10, 4, 1, 3),*/

OBJTYPE_TU_PERIODS_CORR(45,  'Quarter 1', 'Semester 1', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(46,  'Quarter 2', 'Semester 1', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(47,  'Quarter 3', 'Semester 2', 1, 1, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(48,  'Quarter 4', 'Semester 2', 1, 1, 4, 2, 2),

/*OBJTYPE_TU_PERIODS_CORR(49,  'Quarter 1', 'Fiscal Semester 2', 1, 4, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(50,  'Quarter 2', 'Fiscal Semester 1', 1, 4, 2, 1, 3),
OBJTYPE_TU_PERIODS_CORR(51,  'Quarter 3', 'Fiscal Semester 1', 1, 4, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(52,  'Quarter 4', 'Fiscal Semester 2', 1, 4, 4, 2, 3),*/


/*OBJTYPE_TU_PERIODS_CORR(53,  'Quarter 1', 'Fiscal Semester 2', 1, 7, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(54,  'Quarter 2', 'Fiscal Semester 2', 1, 7, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(55,  'Quarter 3', 'Fiscal Semester 1', 1, 7, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(56,  'Quarter 4', 'Fiscal Semester 1', 1, 7, 4, 1, 3),

OBJTYPE_TU_PERIODS_CORR(57,  'Quarter 1', 'Fiscal Semester 1', 1, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(58,  'Quarter 2', 'Fiscal Semester 2', 1, 10, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(59,  'Quarter 3', 'Fiscal Semester 2', 1, 10, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(60,  'Quarter 4', 'Fiscal Semester 1', 1, 10, 4, 1, 3),*/

OBJTYPE_TU_PERIODS_CORR(61,  'Quarter 1', 'Year', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(62,  'Quarter 2', 'Year', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(63,  'Quarter 3', 'Year', 1, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(64,  'Quarter 4', 'Year', 1, 1, 4, 1, 2),

/*OBJTYPE_TU_PERIODS_CORR(65,  'Quarter 1', 'Fiscal Year', 1, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(66,  'Quarter 2', 'Fiscal Year', 1, 4, 2, 1, 3),
OBJTYPE_TU_PERIODS_CORR(67,  'Quarter 3', 'Fiscal Year', 1, 4, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(68,  'Quarter 4', 'Fiscal Year', 1, 4, 4, 1, 3),

OBJTYPE_TU_PERIODS_CORR(69,  'Quarter 1', 'Fiscal Year', 1, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(70,  'Quarter 2', 'Fiscal Year', 1, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(71,  'Quarter 3', 'Fiscal Year', 1, 7, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(72,  'Quarter 4', 'Fiscal Year', 1, 7, 4, 1, 3),


OBJTYPE_TU_PERIODS_CORR(77,  'Quarter 1', 'Fiscal Year', 1, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(78,  'Quarter 2', 'Fiscal Year', 1, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(79,  'Quarter 3', 'Fiscal Year', 1, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(80,  'Quarter 4', 'Fiscal Year', 1, 10, 4, 1, 3),

OBJTYPE_TU_PERIODS_CORR(81,  'Fiscal Quarter 1','Quarter 2', 4, 1, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(82,  'Fiscal Quarter 2','Quarter 3', 4, 1, 2, 3, 1),
OBJTYPE_TU_PERIODS_CORR(83,  'Fiscal Quarter 3','Quarter 4', 4, 1, 3, 4, 1),
OBJTYPE_TU_PERIODS_CORR(84,  'Fiscal Quarter 4','Quarter 1', 4, 1, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(85,  'Fiscal Quarter 1', 'Semester 1', 4, 1, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(86,  'Fiscal Quarter 2', 'Semester 2', 4, 1, 2, 2, 1),
OBJTYPE_TU_PERIODS_CORR(87,  'Fiscal Quarter 3', 'Semester 2', 4, 1, 3, 2, 1),
OBJTYPE_TU_PERIODS_CORR(88,  'Fiscal Quarter 4', 'Semester 1', 4, 1, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(89,  'Fiscal Quarter 1', 'Fiscal Semester 1', 4, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(90,  'Fiscal Quarter 2', 'Fiscal Semester 1', 4, 4, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(91,  'Fiscal Quarter 3', 'Fiscal Semester 2', 4, 4, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(92,  'Fiscal Quarter 4', 'Fiscal Semester 2', 4, 4, 4, 2, 2),


OBJTYPE_TU_PERIODS_CORR(93,  'Fiscal Quarter 1', 'Fiscal Semester 2', 4, 7, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(94,  'Fiscal Quarter 2', 'Fiscal Semester 1', 4, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(95,  'Fiscal Quarter 3', 'Fiscal Semester 1', 4, 7, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(96,  'Fiscal Quarter 4', 'Fiscal Semester 2', 4, 7, 4, 2, 2),

OBJTYPE_TU_PERIODS_CORR(97,  'Fiscal Quarter 1', 'Fiscal Semester 2', 4, 10, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(98,  'Fiscal Quarter 2', 'Fiscal Semester 2', 4, 10, 2, 2, 1),
OBJTYPE_TU_PERIODS_CORR(99,  'Fiscal Quarter 3', 'Fiscal Semester 1', 4, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(100, 'Fiscal Quarter 4', 'Fiscal Semester 1', 4, 10, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(101, 'Fiscal Quarter 1', 'Year', 4, 1, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(102, 'Fiscal Quarter 2', 'Year', 4, 1, 2, 1, 1),
OBJTYPE_TU_PERIODS_CORR(103, 'Fiscal Quarter 3', 'Year', 4, 1, 3, 1, 1),
OBJTYPE_TU_PERIODS_CORR(104, 'Fiscal Quarter 4', 'Year', 4, 1, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(105, 'Fiscal Quarter 1', 'Fiscal Year', 4, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(106, 'Fiscal Quarter 2', 'Fiscal Year', 4, 4, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(107, 'Fiscal Quarter 3', 'Fiscal Year', 4, 4, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(108, 'Fiscal Quarter 4', 'Fiscal Year', 4, 4, 4, 1, 2),


OBJTYPE_TU_PERIODS_CORR(109, 'Fiscal Quarter 1', 'Fiscal Year', 4, 7, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(110, 'Fiscal Quarter 2', 'Fiscal Year', 4, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(111, 'Fiscal Quarter 3', 'Fiscal Year', 4, 7, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(112, 'Fiscal Quarter 4', 'Fiscal Year', 4, 7, 4, 1, 2),


OBJTYPE_TU_PERIODS_CORR(113, 'Fiscal Quarter 1', 'Fiscal Year', 4, 10, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(114, 'Fiscal Quarter 2', 'Fiscal Year', 4, 10, 2, 1, 1),
OBJTYPE_TU_PERIODS_CORR(115, 'Fiscal Quarter 3', 'Fiscal Year', 4, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(116, 'Fiscal Quarter 4', 'Fiscal Year', 4, 10, 4, 1, 2),


OBJTYPE_TU_PERIODS_CORR(117,  'Fiscal Quarter 1', 'Quarter 3', 7, 1, 1, 3, 1),
OBJTYPE_TU_PERIODS_CORR(118, 'Fiscal Quarter 2',  'Quarter 4', 7, 1, 2, 4, 1),
OBJTYPE_TU_PERIODS_CORR(119, 'Fiscal Quarter 3',  'Quarter 1', 7, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(120, 'Fiscal Quarter 4',  'Quarter 2', 7, 1, 4, 2, 2),

OBJTYPE_TU_PERIODS_CORR(121, 'Fiscal Quarter 1', 'Semester 2', 7, 1, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(122, 'Fiscal Quarter 2', 'Semester 2', 7, 1, 2, 2, 1),
OBJTYPE_TU_PERIODS_CORR(123, 'Fiscal Quarter 3', 'Semester 1', 7, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(124, 'Fiscal Quarter 4', 'Semester 1', 7, 1, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(125, 'Fiscal Quarter 1', 'Fiscal Semester 1', 7, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(126, 'Fiscal Quarter 2', 'Fiscal Semester 2', 7, 4, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(127, 'Fiscal Quarter 3', 'Fiscal Semester 2', 7, 4, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(128, 'Fiscal Quarter 4', 'Fiscal Semester 1', 7, 4, 4, 1, 3),


OBJTYPE_TU_PERIODS_CORR(129, 'Fiscal Quarter 1', 'Fiscal Semester 1', 7, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(130, 'Fiscal Quarter 2', 'Fiscal Semester 1', 7, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(131, 'Fiscal Quarter 3', 'Fiscal Semester 2', 7, 7, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(132, 'Fiscal Quarter 4', 'Fiscal Semester 2', 7, 7, 4, 2, 2),


OBJTYPE_TU_PERIODS_CORR(133, 'Fiscal Quarter 1', 'Fiscal Semester 2', 7, 10, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(134, 'Fiscal Quarter 2', 'Fiscal Semester 1', 7, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(135, 'Fiscal Quarter 3', 'Fiscal Semester 1', 7, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(136, 'Fiscal Quarter 4', 'Fiscal Semester 2', 7, 10, 4, 2, 2),

OBJTYPE_TU_PERIODS_CORR(137, 'Fiscal Quarter 1', 'Year', 7, 1, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(138, 'Fiscal Quarter 2', 'Year', 7, 1, 2, 1, 1),
OBJTYPE_TU_PERIODS_CORR(139, 'Fiscal Quarter 3', 'Year', 7, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(140, 'Fiscal Quarter 4', 'Year', 7, 1, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(141, 'Fiscal Quarter 1', 'Fiscal Year', 7, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(142, 'Fiscal Quarter 2', 'Fiscal Year', 7, 4, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(143, 'Fiscal Quarter 3', 'Fiscal Year', 7, 4, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(144, 'Fiscal Quarter 4', 'Fiscal Year', 7, 4, 4, 1, 3),


OBJTYPE_TU_PERIODS_CORR(145, 'Fiscal Quarter 1', 'Fiscal Year', 7, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(146, 'Fiscal Quarter 2', 'Fiscal Year', 7, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(147, 'Fiscal Quarter 3', 'Fiscal Year', 7, 7, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(148, 'Fiscal Quarter 4', 'Fiscal Year', 7, 7, 4, 1, 2),


OBJTYPE_TU_PERIODS_CORR(149, 'Fiscal Quarter 1', 'Fiscal Year', 7, 10, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(150, 'Fiscal Quarter 2', 'Fiscal Year', 7, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(151, 'Fiscal Quarter 3', 'Fiscal Year', 7, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(152, 'Fiscal Quarter 4', 'Fiscal Year', 7, 10, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(153, 'Fiscal Quarter 1', 'Quarter 4', 10, 1, 1, 4, 1),
OBJTYPE_TU_PERIODS_CORR(154, 'Fiscal Quarter 2', 'Quarter 1', 10, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(155, 'Fiscal Quarter 3', 'Quarter 2', 10, 1, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(156, 'Fiscal Quarter 4', 'Quarter 3', 10, 1, 4, 3, 2),

OBJTYPE_TU_PERIODS_CORR(157, 'Fiscal Quarter 1', 'Semester 2', 10, 1, 1, 2, 1),
OBJTYPE_TU_PERIODS_CORR(158, 'Fiscal Quarter 2', 'Semester 1', 10, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(159, 'Fiscal Quarter 3', 'Semester 1', 10, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(160, 'Fiscal Quarter 4', 'Semester 2', 10, 1, 4, 2, 2),

OBJTYPE_TU_PERIODS_CORR(161, 'Fiscal Quarter 1', 'Fiscal Semester 2', 10, 4, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(162, 'Fiscal Quarter 2', 'Fiscal Semester 2', 10, 4, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(163, 'Fiscal Quarter 3', 'Fiscal Semester 1', 10, 4, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(164, 'Fiscal Quarter 4', 'Fiscal Semester 1', 10, 4, 4, 1, 3),


OBJTYPE_TU_PERIODS_CORR(165, 'Fiscal Quarter 1', 'Fiscal Semester 1', 10, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(166, 'Fiscal Quarter 2', 'Fiscal Semester 2', 10, 7, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(167, 'Fiscal Quarter 3', 'Fiscal Semester 2', 10, 7, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(168, 'Fiscal Quarter 4', 'Fiscal Semester 1', 10, 7, 4, 1, 3),

OBJTYPE_TU_PERIODS_CORR(169, 'Fiscal Quarter 1', 'Fiscal Semester 1', 10, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(170, 'Fiscal Quarter 2', 'Fiscal Semester 1', 10, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(171, 'Fiscal Quarter 3', 'Fiscal Semester 2', 10, 10, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(172, 'Fiscal Quarter 4', 'Fiscal Semester 2', 10, 10, 4, 2, 2),

OBJTYPE_TU_PERIODS_CORR(173, 'Fiscal Quarter 1', 'Year', 10, 1, 1, 1, 1),
OBJTYPE_TU_PERIODS_CORR(174, 'Fiscal Quarter 2', 'Year', 10, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(175, 'Fiscal Quarter 3', 'Year', 10, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(176, 'Fiscal Quarter 4', 'Year', 10, 1, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(177, 'Fiscal Quarter 1', 'Fiscal Year', 10, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(178, 'Fiscal Quarter 2', 'Fiscal Year', 10, 4, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(179, 'Fiscal Quarter 3', 'Fiscal Year', 10, 4, 3, 1, 3),
OBJTYPE_TU_PERIODS_CORR(180, 'Fiscal Quarter 4', 'Fiscal Year', 10, 4, 4, 1, 3),


OBJTYPE_TU_PERIODS_CORR(181, 'Fiscal Quarter 1', 'Fiscal Year', 10, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(182, 'Fiscal Quarter 2', 'Fiscal Year', 10, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(183, 'Fiscal Quarter 3', 'Fiscal Year', 10, 7, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(184, 'Fiscal Quarter 4', 'Fiscal Year', 10, 7, 4, 1, 3),


OBJTYPE_TU_PERIODS_CORR(185, 'Fiscal Quarter 1', 'Fiscal Year', 10, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(186, 'Fiscal Quarter 2', 'Fiscal Year', 10, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(187, 'Fiscal Quarter 3', 'Fiscal Year', 10, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(189, 'Fiscal Quarter 4', 'Fiscal Year', 10, 10, 4, 1, 2),

OBJTYPE_TU_PERIODS_CORR(190, 'January',  'Fiscal Trimester 3', 1, 4, 1, 3, 2),
OBJTYPE_TU_PERIODS_CORR(191, 'February', 'Fiscal Trimester 3', 1, 4, 2, 3, 2),
OBJTYPE_TU_PERIODS_CORR(192, 'March',    'Fiscal Trimester 3', 1, 4, 3, 3, 2),
OBJTYPE_TU_PERIODS_CORR(193, 'April',    'Fiscal Trimester 1', 1, 4, 4, 1, 3),
OBJTYPE_TU_PERIODS_CORR(194, 'May',      'Fiscal Trimester 1', 1, 4, 5, 1, 3),
OBJTYPE_TU_PERIODS_CORR(195, 'June',     'Fiscal Trimester 1', 1, 4, 6, 1, 3),
OBJTYPE_TU_PERIODS_CORR(196, 'July',     'Fiscal Trimester 1', 1, 4, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(197, 'August',   'Fiscal Trimester 2', 1, 4, 8, 2, 3),
OBJTYPE_TU_PERIODS_CORR(198, 'September','Fiscal Trimester 2', 1, 4, 9, 2, 3),
OBJTYPE_TU_PERIODS_CORR(199, 'October',  'Fiscal Trimester 2', 1, 4, 10, 2, 3),
OBJTYPE_TU_PERIODS_CORR(200, 'November', 'Fiscal Trimester 2', 1, 4, 11, 2, 3),
OBJTYPE_TU_PERIODS_CORR(201, 'December', 'Fiscal Trimester 3', 1, 4, 12, 3, 3),

OBJTYPE_TU_PERIODS_CORR(202, 'January',   'Fiscal Trimester 2', 1, 7, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(203, 'February',   'Fiscal Trimester 2', 1, 7, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(204, 'March',     'Fiscal Trimester 3', 1, 7, 3, 3, 2),
OBJTYPE_TU_PERIODS_CORR(205, 'April',     'Fiscal Trimester 3', 1, 7, 4, 3, 2),
OBJTYPE_TU_PERIODS_CORR(206, 'May',     'Fiscal Trimester 3', 1, 7, 5, 3, 2),
OBJTYPE_TU_PERIODS_CORR(207, 'June',     'Fiscal Trimester 3', 1, 7, 6, 3, 2),
OBJTYPE_TU_PERIODS_CORR(208, 'July',     'Fiscal Trimester 1', 1, 7, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(209, 'August',     'Fiscal Trimester 1', 1, 7, 8, 1, 3),
OBJTYPE_TU_PERIODS_CORR(210, 'September',   'Fiscal Trimester 1', 1, 7, 9, 1, 3),
OBJTYPE_TU_PERIODS_CORR(211, 'October',   'Fiscal Trimester 1', 1, 7, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(212, 'November',   'Fiscal Trimester 2', 1, 7, 11, 2, 3),
OBJTYPE_TU_PERIODS_CORR(213, 'December',   'Fiscal Trimester 2', 1, 7, 12, 2, 3),


OBJTYPE_TU_PERIODS_CORR(214, 'January',   'Fiscal Trimester 1', 1, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(215, 'February',   'Fiscal Trimester 2', 1, 10, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(216, 'March',     'Fiscal Trimester 2', 1, 10, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(217, 'April',     'Fiscal Trimester 2', 1, 10, 4, 2, 2),
OBJTYPE_TU_PERIODS_CORR(218, 'May',     'Fiscal Trimester 2', 1, 10, 5, 2, 2),
OBJTYPE_TU_PERIODS_CORR(219, 'June',     'Fiscal Trimester 3', 1, 10, 6, 3, 2),
OBJTYPE_TU_PERIODS_CORR(220, 'July',     'Fiscal Trimester 3', 1, 10, 7, 3, 2),
OBJTYPE_TU_PERIODS_CORR(221, 'August',     'Fiscal Trimester 3', 1, 10, 8, 3, 2),
OBJTYPE_TU_PERIODS_CORR(222, 'September',   'Fiscal Trimester 3', 1, 10, 9, 3, 2),
OBJTYPE_TU_PERIODS_CORR(223, 'October',   'Fiscal Trimester 1', 1, 10, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(224, 'November',   'Fiscal Trimester 1', 1, 10, 11, 1, 3),
OBJTYPE_TU_PERIODS_CORR(225, 'December',   'Fiscal Trimester 1', 1, 10, 12, 1, 3),
*/
OBJTYPE_TU_PERIODS_CORR(226, 'January',   'Year', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(227, 'February',   'Year', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(228, 'March',     'Year', 1, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(229, 'April',     'Year', 1, 1, 4, 1, 2),
OBJTYPE_TU_PERIODS_CORR(230, 'May',     'Year', 1, 1, 5, 1, 2),
OBJTYPE_TU_PERIODS_CORR(231, 'June',     'Year', 1, 1, 6, 1, 2),
OBJTYPE_TU_PERIODS_CORR(232, 'July',     'Year', 1, 1, 7, 1, 2),
OBJTYPE_TU_PERIODS_CORR(233, 'August',     'Year', 1, 1, 8, 1, 2),
OBJTYPE_TU_PERIODS_CORR(234, 'September',   'Year', 1, 1, 9, 1, 2),
OBJTYPE_TU_PERIODS_CORR(235, 'October',   'Year', 1, 1, 10, 1, 2),
OBJTYPE_TU_PERIODS_CORR(236, 'November',   'Year', 1, 1, 11, 1, 2),
OBJTYPE_TU_PERIODS_CORR(237, 'December',   'Year', 1, 1, 12, 1, 2),

/*OBJTYPE_TU_PERIODS_CORR(238, 'January', 'Fiscal Year', 1, 4, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(239, 'February','Fiscal Year', 1, 4, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(240, 'March',     'Fiscal Year', 1, 4, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(241, 'April',     'Fiscal Year', 1, 4, 4, 1, 3),
OBJTYPE_TU_PERIODS_CORR(242, 'May',     'Fiscal Year', 1, 4, 5, 1, 3),
OBJTYPE_TU_PERIODS_CORR(243, 'June',     'Fiscal Year', 1, 4, 6, 1, 3),
OBJTYPE_TU_PERIODS_CORR(244, 'July',     'Fiscal Year', 1, 4, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(245, 'August',     'Fiscal Year', 1, 4, 8, 1, 3),
OBJTYPE_TU_PERIODS_CORR(246, 'September',   'Fiscal Year', 1, 4, 9, 1, 3),
OBJTYPE_TU_PERIODS_CORR(247, 'October',   'Fiscal Year', 1, 4, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(248, 'November',   'Fiscal Year', 1, 4, 11, 1, 3),


OBJTYPE_TU_PERIODS_CORR(249, 'December',   'Fiscal Year', 1, 4, 12, 1, 3),
OBJTYPE_TU_PERIODS_CORR(250, 'January',   'Fiscal Year', 1, 7, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(251, 'February',   'Fiscal Year', 1, 7, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(252, 'March',     'Fiscal Year', 1, 7, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(253, 'April',     'Fiscal Year', 1, 7, 4, 1, 2),
OBJTYPE_TU_PERIODS_CORR(254, 'May',     'Fiscal Year', 1, 7, 5, 1, 2),
OBJTYPE_TU_PERIODS_CORR(255, 'June',     'Fiscal Year', 1, 7, 6, 1, 2),
OBJTYPE_TU_PERIODS_CORR(256, 'July',     'Fiscal Year', 1, 7, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(257, 'August',     'Fiscal Year', 1, 7, 8, 1, 3),
OBJTYPE_TU_PERIODS_CORR(258, 'September',   'Fiscal Year', 1, 7, 9, 1, 3),
OBJTYPE_TU_PERIODS_CORR(259, 'October',   'Fiscal Year', 1, 7, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(260, 'November',   'Fiscal Year', 1, 7, 11, 1, 3),
OBJTYPE_TU_PERIODS_CORR(261, 'December',   'Fiscal Year', 1, 7, 12, 1, 3),

OBJTYPE_TU_PERIODS_CORR(262, 'January',   'Fiscal Year', 1, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(263, 'February',   'Fiscal Year', 1, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(264, 'March',     'Fiscal Year', 1, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(265, 'April',     'Fiscal Year', 1, 10, 4, 1, 2),
OBJTYPE_TU_PERIODS_CORR(266, 'May',     'Fiscal Year', 1, 10, 5, 1, 2),
OBJTYPE_TU_PERIODS_CORR(267, 'June',     'Fiscal Year', 1, 10, 6, 1, 2),
OBJTYPE_TU_PERIODS_CORR(268, 'July',     'Fiscal Year', 1, 10, 7, 1, 2),
OBJTYPE_TU_PERIODS_CORR(269, 'August',     'Fiscal Year', 1, 10, 8, 1, 2),
OBJTYPE_TU_PERIODS_CORR(270, 'September',   'Fiscal Year', 1, 10, 9, 1, 2),
OBJTYPE_TU_PERIODS_CORR(271, 'October',   'Fiscal Year', 1, 10, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(272, 'November',   'Fiscal Year', 1, 10, 11, 1, 3),
OBJTYPE_TU_PERIODS_CORR(273, 'December',   'Fiscal Year', 1, 10, 12, 1, 3),*/

OBJTYPE_TU_PERIODS_CORR(274, 'January',   'Quarter 1', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(275, 'February',   'Quarter 1', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(276, 'March',     'Quarter 1', 1, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(277, 'April',     'Quarter 2', 1, 1, 4, 2, 2),
OBJTYPE_TU_PERIODS_CORR(278, 'May',     'Quarter 2', 1, 1, 5, 2, 2),
OBJTYPE_TU_PERIODS_CORR(279, 'June',     'Quarter 2', 1, 1, 6, 2, 2),
OBJTYPE_TU_PERIODS_CORR(280, 'July',     'Quarter 3', 1, 1, 7, 3, 2),
OBJTYPE_TU_PERIODS_CORR(281, 'August',     'Quarter 3', 1, 1, 8, 3, 2),
OBJTYPE_TU_PERIODS_CORR(282, 'September',   'Quarter 3', 1, 1, 9, 3, 2),
OBJTYPE_TU_PERIODS_CORR(283, 'October',   'Quarter 4', 1, 1, 10, 4, 2),
OBJTYPE_TU_PERIODS_CORR(284, 'November',   'Quarter 4', 1, 1, 11, 4, 2),
OBJTYPE_TU_PERIODS_CORR(285, 'December',   'Quarter 4', 1, 1, 12, 4, 2),

/*OBJTYPE_TU_PERIODS_CORR(286, 'January',   'Fiscal Quarter 4', 1, 4, 1, 4, 2),
OBJTYPE_TU_PERIODS_CORR(287, 'February',   'Fiscal Quarter 4', 1, 4, 2, 4, 2),
OBJTYPE_TU_PERIODS_CORR(288, 'March',     'Fiscal Quarter 4', 1, 4, 3, 4, 2),
OBJTYPE_TU_PERIODS_CORR(289, 'April',     'Fiscal Quarter 1', 1, 4, 4, 1, 3),
OBJTYPE_TU_PERIODS_CORR(290, 'May',     'Fiscal Quarter 1', 1, 4, 5, 1, 3),
OBJTYPE_TU_PERIODS_CORR(291, 'June',     'Fiscal Quarter 1', 1, 4, 6, 1, 3),
OBJTYPE_TU_PERIODS_CORR(292, 'July',     'Fiscal Quarter 2', 1, 4, 7, 2, 3),
OBJTYPE_TU_PERIODS_CORR(293, 'August',     'Fiscal Quarter 2', 1, 4, 8, 2, 3),
OBJTYPE_TU_PERIODS_CORR(294, 'September',   'Fiscal Quarter 2', 1, 4, 9, 2, 3),
OBJTYPE_TU_PERIODS_CORR(295, 'October',   'Fiscal Quarter 3', 1, 4, 10, 3, 3),
OBJTYPE_TU_PERIODS_CORR(296, 'November',   'Fiscal Quarter 3', 1, 4, 11, 3, 3),
OBJTYPE_TU_PERIODS_CORR(297, 'December',   'Fiscal Quarter 3', 1, 4, 12, 3, 3),

OBJTYPE_TU_PERIODS_CORR(298, 'January',   'Fiscal Quarter 3', 1, 7, 1, 3, 2),
OBJTYPE_TU_PERIODS_CORR(299, 'February',   'Fiscal Quarter 3', 1, 7, 2, 3, 2),
OBJTYPE_TU_PERIODS_CORR(300, 'March',     'Fiscal Quarter 3', 1, 7, 3, 3, 2),
OBJTYPE_TU_PERIODS_CORR(301, 'April',     'Fiscal Quarter 4', 1, 7, 4, 4, 2),
OBJTYPE_TU_PERIODS_CORR(302, 'May',     'Fiscal Quarter 4', 1, 7, 5, 4, 2),
OBJTYPE_TU_PERIODS_CORR(303, 'June',     'Fiscal Quarter 4', 1, 7, 6, 4, 2),
OBJTYPE_TU_PERIODS_CORR(304, 'July',     'Fiscal Quarter 1', 1, 7, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(305, 'August',     'Fiscal Quarter 1', 1, 7, 8, 1, 3),
OBJTYPE_TU_PERIODS_CORR(306, 'September',   'Fiscal Quarter 1', 1, 7, 9, 1, 3),
OBJTYPE_TU_PERIODS_CORR(307, 'October',   'Fiscal Quarter 2', 1, 7, 10, 2, 3),
OBJTYPE_TU_PERIODS_CORR(308, 'November',   'Fiscal Quarter 2', 1, 7, 11, 2, 3),
OBJTYPE_TU_PERIODS_CORR(309, 'December',   'Fiscal Quarter 2', 1, 7, 12, 2, 3),

OBJTYPE_TU_PERIODS_CORR(310, 'January',   'Fiscal Quarter 2', 1, 10, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(311, 'February',   'Fiscal Quarter 2', 1, 10, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(312, 'March',     'Fiscal Quarter 2', 1, 10, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(313, 'April',     'Fiscal Quarter 3', 1, 10, 4, 3, 2),
OBJTYPE_TU_PERIODS_CORR(314, 'May',     'Fiscal Quarter 3', 1, 10, 5, 3, 2),
OBJTYPE_TU_PERIODS_CORR(315, 'June',     'Fiscal Quarter 3', 1, 10, 6, 3, 2),
OBJTYPE_TU_PERIODS_CORR(316, 'July',     'Fiscal Quarter 4', 1, 10, 7, 4, 2),
OBJTYPE_TU_PERIODS_CORR(317, 'August',     'Fiscal Quarter 4', 1, 10, 8, 4, 2),
OBJTYPE_TU_PERIODS_CORR(318, 'September',   'Fiscal Quarter 4', 1, 10, 9, 4, 2),
OBJTYPE_TU_PERIODS_CORR(319, 'October',   'Fiscal Quarter 1', 1, 10, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(320, 'November',   'Fiscal Quarter 1', 1, 10, 11, 1, 3),
OBJTYPE_TU_PERIODS_CORR(321, 'December',   'Fiscal Quarter 1', 1, 10, 12, 1, 3),*/

OBJTYPE_TU_PERIODS_CORR(322, 'January',   'Semester 1', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(323, 'February',   'Semester 1', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(324, 'March',     'Semester 1', 1, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(325, 'April',     'Semester 1', 1, 1, 4, 1, 2),
OBJTYPE_TU_PERIODS_CORR(326, 'May',     'Semester 1', 1, 1, 5, 1, 2),
OBJTYPE_TU_PERIODS_CORR(327, 'June',     'Semester 1', 1, 1, 6, 1, 2),
OBJTYPE_TU_PERIODS_CORR(328, 'July',     'Semester 2', 1, 1, 7, 2, 2),
OBJTYPE_TU_PERIODS_CORR(329, 'August',     'Semester 2', 1, 1, 8, 2, 2),
OBJTYPE_TU_PERIODS_CORR(330, 'September',   'Semester 2', 1, 1, 9, 2, 2),
OBJTYPE_TU_PERIODS_CORR(331, 'October',   'Semester 2', 1, 1, 10, 2, 2),
OBJTYPE_TU_PERIODS_CORR(332, 'November',   'Semester 2', 1, 1, 11, 2, 2),
OBJTYPE_TU_PERIODS_CORR(333, 'December',   'Semester 2', 1, 1, 12, 2, 2),

/*OBJTYPE_TU_PERIODS_CORR(334, 'January',   'Fiscal Semester 2', 1, 4, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(335, 'February',   'Fiscal Semester 2', 1, 4, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(336, 'March',     'Fiscal Semester 2', 1, 4, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(337, 'April',     'Fiscal Semester 1', 1, 4, 4, 1, 3),
OBJTYPE_TU_PERIODS_CORR(338, 'May',     'Fiscal Semester 1', 1, 4, 5, 1, 3),
OBJTYPE_TU_PERIODS_CORR(339, 'June',     'Fiscal Semester 1', 1, 4, 6, 1, 3),
OBJTYPE_TU_PERIODS_CORR(340, 'July',     'Fiscal Semester 1', 1, 4, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(341, 'August',     'Fiscal Semester 1', 1, 4, 8, 1, 3),
OBJTYPE_TU_PERIODS_CORR(342, 'September',   'Fiscal Semester 1', 1, 4, 9, 1, 3),
OBJTYPE_TU_PERIODS_CORR(343, 'October',   'Fiscal Semester 2', 1, 4, 10, 2, 3),
OBJTYPE_TU_PERIODS_CORR(344, 'November',   'Fiscal Semester 2', 1, 4, 11, 2, 3),
OBJTYPE_TU_PERIODS_CORR(345, 'December',   'Fiscal Semester 2', 1, 4, 12, 2, 3),

OBJTYPE_TU_PERIODS_CORR(346, 'January',   'Fiscal Semester 2', 1, 7, 1, 2, 2),
OBJTYPE_TU_PERIODS_CORR(347, 'February',   'Fiscal Semester 2', 1, 7, 2, 2, 2),
OBJTYPE_TU_PERIODS_CORR(348, 'March',     'Fiscal Semester 2', 1, 7, 3, 2, 2),
OBJTYPE_TU_PERIODS_CORR(349, 'April',     'Fiscal Semester 2', 1, 7, 4, 2, 2),
OBJTYPE_TU_PERIODS_CORR(350, 'May',     'Fiscal Semester 2', 1, 7, 5, 2, 2),
OBJTYPE_TU_PERIODS_CORR(351, 'June',     'Fiscal Semester 2', 1, 7, 6, 2, 2),
OBJTYPE_TU_PERIODS_CORR(352, 'July',     'Fiscal Semester 1', 1, 7, 7, 1, 3),
OBJTYPE_TU_PERIODS_CORR(353, 'August',     'Fiscal Semester 1', 1, 7, 8, 1, 3),
OBJTYPE_TU_PERIODS_CORR(354, 'September',   'Fiscal Semester 1', 1, 7, 9, 1, 3),
OBJTYPE_TU_PERIODS_CORR(355, 'October',   'Fiscal Semester 1', 1, 7, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(356, 'November',   'Fiscal Semester 1', 1, 7, 11, 1, 3),
OBJTYPE_TU_PERIODS_CORR(357, 'December',   'Fiscal Semester 1', 1, 7, 12, 1, 3),

OBJTYPE_TU_PERIODS_CORR(358, 'January',   'Fiscal Semester 1', 1, 10, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(359, 'February',   'Fiscal Semester 1', 1, 10, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(360, 'March',     'Fiscal Semester 1', 1, 10, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(361, 'April',     'Fiscal Semester 2', 1, 10, 4, 2, 2),
OBJTYPE_TU_PERIODS_CORR(362, 'May',     'Fiscal Semester 2', 1, 10, 5, 2, 2),
OBJTYPE_TU_PERIODS_CORR(363, 'June',     'Fiscal Semester 2', 1, 10, 6, 2, 2),
OBJTYPE_TU_PERIODS_CORR(364, 'July',     'Fiscal Semester 2', 1, 10, 7, 2, 2),
OBJTYPE_TU_PERIODS_CORR(365, 'August',     'Fiscal Semester 2', 1, 10, 8, 2, 2),
OBJTYPE_TU_PERIODS_CORR(366, 'September',   'Fiscal Semester 2', 1, 10, 9, 2, 2),
OBJTYPE_TU_PERIODS_CORR(367, 'October',   'Fiscal Semester 1', 1, 10, 10, 1, 3),
OBJTYPE_TU_PERIODS_CORR(368, 'November',   'Fiscal Semester 1', 1, 10, 11, 1, 3),
OBJTYPE_TU_PERIODS_CORR(369, 'December',   'Fiscal Semester 1', 1, 10, 12, 1, 3),*/


OBJTYPE_TU_PERIODS_CORR(382, 'January',   'Trimester 1', 1, 1, 1, 1, 2),
OBJTYPE_TU_PERIODS_CORR(383, 'February',   'Trimester 1', 1, 1, 2, 1, 2),
OBJTYPE_TU_PERIODS_CORR(384, 'March',     'Trimester 1', 1, 1, 3, 1, 2),
OBJTYPE_TU_PERIODS_CORR(385, 'April',     'Trimester 1', 1, 1, 4, 1, 2),
OBJTYPE_TU_PERIODS_CORR(386, 'May',     'Trimester 2', 1, 1, 5, 2, 2),
OBJTYPE_TU_PERIODS_CORR(387, 'June',     'Trimester 2', 1, 1, 6, 2, 2),
OBJTYPE_TU_PERIODS_CORR(388, 'July',     'Trimester 2', 1, 1, 7, 2, 2),
OBJTYPE_TU_PERIODS_CORR(389, 'August',     'Trimester 2', 1, 1, 8, 2, 2),
OBJTYPE_TU_PERIODS_CORR(390, 'September',   'Trimester 3', 1, 1, 9, 3, 2),
OBJTYPE_TU_PERIODS_CORR(391, 'October',   'Trimester 3', 1, 1, 10, 3, 2),
OBJTYPE_TU_PERIODS_CORR(392, 'November',   'Trimester 3', 1, 1, 11, 3, 2),
OBJTYPE_TU_PERIODS_CORR(393, 'December',   'Trimester 3', 1, 1, 12, 3, 2));
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END       *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START                    *******************************

PROCEDURE ADD_SYSTEM_TIME_UNIT_CORR(PI_TU_NAME in VARCHAR2) is

CURSOR C_GET_TU_LHS(P_TU_NAME varchar2) IS
SELECT * FROM TIME_UNITS WHERE TU_NAME = P_TU_NAME;

CURSOR C_GET_TU_RHS(P_TU_NAME varchar2) IS
SELECT * FROM TIME_UNITS WHERE TU_NAME = P_TU_NAME;

V_TUP_ID   NUMBER(10);
V_TUP_NAME VARCHAR(30);

V_TUP_ID_CORR   NUMBER(10);
V_TUP_NAME_CORR VARCHAR(30);

V_OFFSET      NUMBER(10);
V_OFFSET_CORR NUMBER(10);

CURSOR C_GET_TU_PERIOD_LHS(P_TU_ID varchar2) IS
SELECT TUP_ID, TUP_NAME /*INTO V_TUP_ID,V_TUP_NAME*/
FROM TU_PERIODS TUP
WHERE TUP.TUP_TU_ID = P_TU_ID;

CURSOR C_GET_TU_PERIOD_RHS(P_TU_ID varchar2) IS
SELECT TUP_ID, TUP_NAME /*INTO V_TUP_ID_CORR,V_TUP_NAME_CORR */
FROM TU_PERIODS TUP
WHERE TUP.TUP_TU_ID = P_TU_ID;

V_TUC_ID    NUMBER(10);
v_TU_status NUMBER(1) := 0;
V_TPC_ID    NUMBER(10);
BEGIN

/*GVCOL_TU_CORR -----GVCOL_TU_CORR_PERIODS*/
--------------Primary TU CORRESPONDANCE
----external loop to check if the TU is added to the system
FOR C_LHS IN C_GET_TU_LHS(PI_TU_NAME) LOOP
-----Loop to iterate though the internal collection that defines basic correspondence
FOR C IN 1 .. GVCOL_TU_CORR.COUNT LOOP
v_TU_status := 0;
-----checking if the TU is a primary

IF (GVCOL_TU_CORR(C).OTC_NAME = PI_TU_NAME) THEN

/* --dbms_output.put_line(GVCOL_TU_CORR(C).OTC_NAME);*/
------if TU is primary then check its correspondance secondary TU is defined in the system
FOR C_RHS IN C_GET_TU_RHS(GVCOL_TU_CORR(C).OTC_NAME_CORR) LOOP


----take out periods for the primary TU defined in the system
for C_TU_PERIOD_LHS IN C_GET_TU_PERIOD_LHS(C_LHS.TU_ID) LOOP

V_TUP_ID   := C_TU_PERIOD_LHS.TUP_ID;
V_TUP_NAME := C_TU_PERIOD_LHS.TUP_NAME;
/* --dbms_output.put_line(V_TUP_NAME);*/

----default offset for Month TU type is 1
if (C_LHS.TU_NAME = 'Month') then
V_OFFSET := 1;
else
---get the starting month offset of primary TU
SELECT TO_NUMBER(TO_CHAR(MIN(TUYR_START_DATE), 'MM'))
INTO V_OFFSET
FROM TU_YEARS_RANGE TUPR
WHERE TUPR.TUYR_TU_ID = C_LHS.TU_ID;

end if;
-----take out periods for the secondary TU defined in the system
for C_TU_PERIOD_RHS IN C_GET_TU_PERIOD_RHS(C_RHS.TU_ID) LOOP
V_TUP_ID_CORR   := C_TU_PERIOD_RHS.TUP_ID;
V_TUP_NAME_CORR := C_TU_PERIOD_RHS.TUP_NAME;
/*--dbms_output.put_line(V_TUP_NAME_CORR);*/

----default offset for Month TU type is 1
if (C_RHS.TU_NAME = 'Month') then
V_OFFSET_CORR := 1;
else
---get the starting month offset of secondary TU
SELECT TO_NUMBER(TO_CHAR(MIN(TUYR_START_DATE), 'MM'))
INTO V_OFFSET_CORR
FROM TU_YEARS_RANGE TUYR
WHERE TUYR.TUYR_TU_ID = C_RHS.TU_ID;
end if;

-----iterate through our object structure to find the correct set to insert
FOR CTP IN 1 .. GVCOL_TU_CORR_PERIODS.COUNT LOOP

IF (GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_NAME = V_TUP_NAME AND GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_CORR_NAME = V_TUP_NAME_CORR AND GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_START = V_OFFSET AND GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_CORR_START = V_OFFSET_CORR) THEN
if (v_TU_status = 0) then
V_TUC_ID := uid_sequence.Nextval;
----insert tu correspondance
insert into TU_CORRESPONDENCE
(TUC_ID,
TUC_TU_ID,
TUC_TU_ID_CORR,
TUC_DEFINED_TYPE,
OBJECT_VERSION)
values
(V_TUC_ID, C_LHS.TU_ID, C_RHS.TU_ID, 2, 0);
v_TU_status := 1;
end if;

V_TPC_ID := uid_sequence.Nextval;
insert into TU_PERIODS_CORRESPONDENCE
(TUPC_ID,
TUPC_TUC_ID,
TUPC_CORRESPONDENCE_TYPE,
TUPC_TUP_ID,
TUPC_TUP_ID_CORR,
TUPC_YEAR_OFFSET,
TUPC_PERIOD_NUMBER,
TUPC_PERIOD_NUMBER_CORR,
OBJECT_VERSION)
values
(V_TPC_ID,
V_TUC_ID,
1,
V_TUP_ID,
V_TUP_ID_CORR,
GVCOL_TU_CORR_PERIODS(CTP).OTPC_YEAR_OFFSET,
null,
null,
0);
END IF;

END LOOP;
END LOOP;
END LOOP;

END LOOP;

END IF;

END LOOP;

END LOOP;

/* --dbms_output.put_line(1);*/
--------------secondary FOR TU CORRESPONDANCE
--------------external loop to check if the TU is added to the system
FOR C_LHS IN C_GET_TU_LHS(PI_TU_NAME) LOOP
-----Loop to iterate though the internal collection that defines basic correspondence
FOR C IN 1 .. GVCOL_TU_CORR.COUNT LOOP

v_TU_status := 0;
-----checking if the TU is a secondary
IF (GVCOL_TU_CORR(C).OTC_NAME_CORR = PI_TU_NAME) THEN
------if TU is secondary then check its correspondance  primary TU is defined in the system
FOR C_RHS IN C_GET_TU_RHS(GVCOL_TU_CORR(C).OTC_NAME) LOOP


----take out periods for the primary TU defined in the system
for C_TU_PERIOD_LHS IN C_GET_TU_PERIOD_LHS(C_RHS.TU_ID) LOOP
V_TUP_ID   := C_TU_PERIOD_LHS.TUP_ID;
V_TUP_NAME := C_TU_PERIOD_LHS.TUP_NAME;

----default offset for Month TU type is 1
if (C_RHS.TU_NAME = 'Month') then
V_OFFSET := 1;
else
----get the starting month offset of primary TU
SELECT TO_NUMBER(TO_CHAR(MIN(TUYR_START_DATE), 'MM'))
INTO V_OFFSET
FROM TU_YEARS_RANGE TUYR
WHERE TUYR.TUYR_TU_ID = C_RHS.TU_ID;
end if;

----take out periods for the secondary TU defined in the system
for C_TU_PERIOD_RHS IN C_GET_TU_PERIOD_RHS(C_LHS.TU_ID) LOOP
V_TUP_ID_CORR   := C_TU_PERIOD_RHS.TUP_ID;
V_TUP_NAME_CORR := C_TU_PERIOD_RHS.TUP_NAME;

----default offset for Month TU type is 1
if (C_LHS.TU_NAME = 'Month') then
V_OFFSET_CORR := 1;
else
---get the starting month offset of secondary TU
SELECT TO_NUMBER(TO_CHAR(MIN(TUYR_START_DATE), 'MM'))
INTO V_OFFSET_CORR
FROM TU_YEARS_RANGE TUYR
WHERE TUYR.TUYR_TU_ID = C_LHS.TU_ID;
end if;

-----iterate through our object structure to find the correct set to insert
FOR CTP IN 1 .. GVCOL_TU_CORR_PERIODS.COUNT LOOP

IF (GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_NAME = V_TUP_NAME AND GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_CORR_NAME = V_TUP_NAME_CORR AND GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_START = V_OFFSET AND GVCOL_TU_CORR_PERIODS(CTP)
.OTPC_CORR_START = V_OFFSET_CORR) THEN
if (v_TU_status = 0) then
V_TUC_ID := uid_sequence.Nextval;
----insert tu correspondance
insert into TU_CORRESPONDENCE
(TUC_ID,
TUC_TU_ID,
TUC_TU_ID_CORR,
TUC_DEFINED_TYPE,
OBJECT_VERSION)
values
(V_TUC_ID, C_RHS.TU_ID, C_LHS.TU_ID, 2, 0);
v_TU_status := 1;
end if;

V_TPC_ID := uid_sequence.Nextval;
insert into TU_PERIODS_CORRESPONDENCE
(TUPC_ID,
TUPC_TUC_ID,
TUPC_CORRESPONDENCE_TYPE,
TUPC_TUP_ID,
TUPC_TUP_ID_CORR,
TUPC_YEAR_OFFSET,
TUPC_PERIOD_NUMBER,
TUPC_PERIOD_NUMBER_CORR,
OBJECT_VERSION)
values
(V_TPC_ID,
V_TUC_ID,
1,
V_TUP_ID,
V_TUP_ID_CORR,
GVCOL_TU_CORR_PERIODS(CTP).OTPC_YEAR_OFFSET,
null,
null,
0);
END IF;

END LOOP;

END LOOP;
END LOOP;

END LOOP;

END IF;

END LOOP;

END LOOP;

end ADD_SYSTEM_TIME_UNIT_CORR;


PROCEDURE GET_CURRENT_PERIOD_BY_DATE
(   pi_tu_id      NUMBER
  ,pi_date      DATE
  ,po_tupr_id      OUT NUMBER
  ,po_start_date    OUT DATE
  ,po_end_date    OUT DATE
  ,po_year      OUT NUMBER
  ,po_period_number  OUT NUMBER
) AS
BEGIN
  /*  get the period where pi_date falls within the period bounds */
  SELECT  TUPR_ID, TUPR_START_DATE, TUPR_END_DATE, TUPR_YEAR, TUPR_PERIOD_NUMBER
  INTO  po_tupr_id, po_start_date, po_end_date, po_year, po_period_number
  FROM  TU_PERIODS_RANGE
  WHERE  TUPR_TU_ID = pi_tu_id
      AND pi_date BETWEEN TUPR_START_DATE AND TUPR_END_DATE;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    po_tupr_id := NULL;
    po_start_date := NULL;
    po_end_date := NULL;
    po_year := NULL;
    po_period_number := NULL;
  WHEN OTHERS THEN
    RAISE;
END GET_CURRENT_PERIOD_BY_DATE;


PROCEDURE GET_PRIOR_PERIOD_BY_RANGE
(   pi_tu_id      NUMBER
  ,pi_year      NUMBER
  ,pi_period_number  NUMBER
  ,pi_range_size    NUMBER
  ,po_tupr_id      OUT NUMBER
  ,po_start_date    OUT DATE
  ,po_end_date    OUT DATE
  ,po_year      OUT NUMBER
  ,po_period_number  OUT NUMBER
) AS
  v_per_cnt      NUMBER;
  v_min_tupr_id    NUMBER;
  v_min_start_date  DATE;
  v_min_end_date    DATE;
  v_min_year      NUMBER;
  v_min_period_number  NUMBER;
BEGIN
  IF (pi_year IS NULL OR pi_period_number IS NULL)
  THEN
    po_tupr_id := NULL;
    po_start_date := NULL;
    po_end_date := NULL;
    po_year := NULL;
    po_period_number := NULL;
  ELSE
    SELECT COUNT(*) INTO v_per_cnt
    FROM TU_PERIODS WHERE TUP_TU_ID = pi_tu_id;

    BEGIN
      /*  in case N is too big and N periods ago falls on a period not existent in the system,
        get the smallest period of pi_tu_id */
      SELECT  TUPR_ID, TUPR_START_DATE, TUPR_END_DATE, TUPR_YEAR, TUPR_PERIOD_NUMBER
      INTO  v_min_tupr_id, v_min_start_date, v_min_end_date, v_min_year, v_min_period_number
      FROM  TU_PERIODS_RANGE
      WHERE  TUPR_ID =
          (SELECT  MIN(TUPR_ID) KEEP (DENSE_RANK FIRST ORDER BY (TUPR_YEAR * v_per_cnt) + TUPR_PERIOD_NUMBER ASC NULLS LAST)
          FROM  TU_PERIODS_RANGE
          WHERE  TUPR_TU_ID = pi_tu_id);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'There is no minimum period number in the system for the selected timeunit.');
      WHEN OTHERS THEN
        RAISE;
    END;

    BEGIN
      /*  get the period which is N periods ago from the one described by the input params.
        do not count for any periods not defined in the system */
      SELECT  TUPR_ID,TUPR_START_DATE,TUPR_END_DATE,TUPR_YEAR,TUPR_PERIOD_NUMBER
      INTO  po_tupr_id, po_start_date, po_end_date, po_year, po_period_number
      FROM  (SELECT  TUPR_ID,TUPR_START_DATE,TUPR_END_DATE,TUPR_YEAR,TUPR_PERIOD_NUMBER
              ,ROW_NUMBER() OVER (ORDER BY (TUPR_YEAR * v_per_cnt) + TUPR_PERIOD_NUMBER DESC) RN
          FROM  TU_PERIODS_RANGE
          WHERE  TUPR_TU_ID = pi_tu_id
              AND (TUPR_YEAR * v_per_cnt) + TUPR_PERIOD_NUMBER <= (pi_year * v_per_cnt) + pi_period_number
          )
      WHERE  RN = pi_range_size;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        po_tupr_id      := v_min_tupr_id;
        po_start_date    := v_min_start_date;
        po_end_date      := v_min_end_date;
        po_year        := v_min_year;
        po_period_number  := v_min_period_number;
      WHEN OTHERS THEN
        RAISE;
    END;
  END IF;
END GET_PRIOR_PERIOD_BY_RANGE;


PROCEDURE GET_PERIOD_RANGE_BY_CORR
(   pi_large_base_tu_id  NUMBER
  ,pi_small_corr_tu_id  NUMBER
  ,pi_large_fst_year    NUMBER
  ,pi_large_fst_per_num  NUMBER
  ,pi_large_lst_year    NUMBER
  ,pi_large_lst_per_num  NUMBER
  ,po_fst_tupr_id      OUT NUMBER
  ,po_fst_start_date    OUT DATE
  ,po_fst_end_date    OUT DATE
  ,po_fst_year      OUT NUMBER
  ,po_fst_period_number  OUT NUMBER
  ,po_lst_tupr_id      OUT NUMBER
  ,po_lst_start_date    OUT DATE
  ,po_lst_end_date    OUT DATE
  ,po_lst_year      OUT NUMBER
  ,po_lst_period_number  OUT NUMBER
) AS
  v_per_cnt_large    NUMBER;
  v_per_cnt_small    NUMBER;
  v_min_small_per    NUMBER;
  v_max_small_per    NUMBER;
BEGIN
  IF (pi_large_fst_year IS NULL OR pi_large_fst_per_num IS NULL
    OR pi_large_lst_year IS NULL OR pi_large_lst_per_num IS NULL)
  THEN
    po_fst_tupr_id      := NULL;
    po_fst_start_date    := NULL;
    po_fst_end_date      := NULL;
    po_fst_year        := NULL;
    po_fst_period_number  := NULL;
    po_lst_tupr_id      := NULL;
    po_lst_start_date    := NULL;
    po_lst_end_date      := NULL;
    po_lst_year        := NULL;
    po_lst_period_number  := NULL;
  ELSE
    SELECT COUNT(*) INTO v_per_cnt_large
    FROM TU_PERIODS WHERE TUP_TU_ID = pi_large_base_tu_id;

    SELECT COUNT(*) INTO v_per_cnt_small
    FROM TU_PERIODS WHERE TUP_TU_ID = pi_small_corr_tu_id;

    /*  based on the bounds of the range of larger periods,
      get the period numbers for the upper and lower corresponding periods  */
    SELECT   MIN((TUPR.TUPR_YEAR * v_per_cnt_small) + TUPR.TUPR_PERIOD_NUMBER) MIN_P
        ,MAX((TUPR.TUPR_YEAR * v_per_cnt_small) + TUPR.TUPR_PERIOD_NUMBER) MAX_P
        /* TUPR_CORR.TUPR_PERIOD_RANGE_NAME PER_L_NAME
        ,TUPR_CORR.TUPR_YEAR PER_L_YEAR
        ,TUPR_CORR.TUPR_PERIOD_NUMBER PER_L_NUMBER
        ,TUPC.TUP_NAME PER_I_NAME
        ,TUPC.TUPC_PERIOD_NUMBER PER_I_NUMBER
        ,CASE  WHEN TUPC.TUPC_YEAR_OFFSET = 1 THEN TUPR_CORR.TUPR_YEAR + 1
            WHEN TUPC.TUPC_YEAR_OFFSET = 2 THEN TUPR_CORR.TUPR_YEAR
            WHEN TUPC.TUPC_YEAR_OFFSET = 3 THEN TUPR_CORR.TUPR_YEAR - 1
            ELSE NULL END PER_I_YEAR
        ,TUPR.TUPR_PERIOD_RANGE_NAME PER_S_NAME
        ,TUPR.TUPR_YEAR PER_S_YEAR
        ,TUPR.TUPR_PERIOD_NUMBER PER_S_NUMBER*/
    INTO  v_min_small_per, v_max_small_per
    FROM  TU_PERIODS_RANGE TUPR_CORR
        LEFT JOIN
        (SELECT   TUPC_CORRESPONDENCE_TYPE
            ,TUPC_TUP_ID
            ,TUPC_TUP_ID_CORR
            ,TUPC_PERIOD_NUMBER
            ,TUPC_PERIOD_NUMBER_CORR
            ,TUPC_YEAR_OFFSET
        FROM  TU_CORRESPONDENCE
            INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
        WHERE  TUC_TU_ID_CORR = pi_large_base_tu_id
            AND TUC_TU_ID = pi_small_corr_tu_id
        ) TUPC ON (TUPC.TUPC_CORRESPONDENCE_TYPE = 1 AND TUPR_CORR.TUPR_TUP_ID = TUPC.TUPC_TUP_ID_CORR)
            OR (TUPC.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_CORR.TUPR_PERIOD_NUMBER = TUPC.TUPC_PERIOD_NUMBER_CORR)
        LEFT JOIN TU_PERIODS_RANGE TUPR ON ((TUPC.TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC.TUPC_TUP_ID = TUPR.TUPR_TUP_ID)
                          OR (TUPC.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR.TUPR_TU_ID = pi_small_corr_tu_id AND TUPC.TUPC_PERIOD_NUMBER = TUPR.TUPR_PERIOD_NUMBER))
                          AND CASE  WHEN TUPC.TUPC_YEAR_OFFSET = 1 THEN TUPR_CORR.TUPR_YEAR + 1
                                WHEN TUPC.TUPC_YEAR_OFFSET = 2 THEN TUPR_CORR.TUPR_YEAR
                                WHEN TUPC.TUPC_YEAR_OFFSET = 3 THEN TUPR_CORR.TUPR_YEAR - 1
                                ELSE NULL END = TUPR.TUPR_YEAR
    WHERE  TUPR_CORR.TUPR_TU_ID = pi_large_base_tu_id
        AND (TUPR_CORR.TUPR_YEAR * v_per_cnt_large) + TUPR_CORR.TUPR_PERIOD_NUMBER
          BETWEEN (pi_large_fst_year * v_per_cnt_large) + pi_large_fst_per_num
          AND (pi_large_lst_year * v_per_cnt_large) + pi_large_lst_per_num;

    BEGIN
      /*  get details for the corresponding lower bound period */
      SELECT  TUPR_ID, TUPR_START_DATE, TUPR_END_DATE, TUPR_YEAR, TUPR_PERIOD_NUMBER
      INTO  po_fst_tupr_id, po_fst_start_date, po_fst_end_date, po_fst_year, po_fst_period_number
      FROM  TU_PERIODS_RANGE
      WHERE  TUPR_TU_ID = pi_small_corr_tu_id
          AND (TUPR_YEAR * v_per_cnt_small) + TUPR_PERIOD_NUMBER = v_min_small_per;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        po_fst_tupr_id      := NULL;
        po_fst_start_date    := NULL;
        po_fst_end_date      := NULL;
        po_fst_year        := NULL;
        po_fst_period_number  := NULL;
      WHEN OTHERS THEN
        RAISE;
    END;

    BEGIN
      /*  get details for the corresponding upper bound period */
      SELECT  TUPR_ID, TUPR_START_DATE, TUPR_END_DATE, TUPR_YEAR, TUPR_PERIOD_NUMBER
      INTO  po_lst_tupr_id, po_lst_start_date, po_lst_end_date, po_lst_year, po_lst_period_number
      FROM  TU_PERIODS_RANGE
      WHERE  TUPR_TU_ID = pi_small_corr_tu_id
          AND (TUPR_YEAR * v_per_cnt_small) + TUPR_PERIOD_NUMBER = v_max_small_per;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        po_lst_tupr_id      := NULL;
        po_lst_start_date    := NULL;
        po_lst_end_date      := NULL;
        po_lst_year        := NULL;
        po_lst_period_number  := NULL;
      WHEN OTHERS THEN
        RAISE;
    END;
  END IF;
END GET_PERIOD_RANGE_BY_CORR;

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START                    *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START                    *******************************

--PUBLIC PROCEDURES  ADD_SYSTEM_TIME_UNIT START
procedure ADD_SYSTEM_TIME_UNIT(PI_TU_NAME    in VARCHAR2,
PI_START_YEAR in NUMBER,
PI_END_YEAR   in NUMBER,
PO_TU_ID      out NUMBER) is

V_IS_FISCAL NUMBER(10);
V_TUS_ID    NUMBER(10);
V_TU_ID     NUMBER(10);
V_TUP_ID    NUMBER(10);
V_TUPR_ID   NUMBER(10);
V_ORDER     NUMBER(10) := 0;

V_YEAR_COUNTER   NUMBER(10) := PI_START_YEAR;
V_DIVISON_FACTOR NUMBER(10);
V_OFFSET         NUMBER(10);
V_FISCAL_OFFSET  NUMBER(10) := 9;
TYPE TYPE_COUNTER IS TABLE OF NUMBER(10);
V_COUNTER TYPE_COUNTER := TYPE_COUNTER();
TYPE TYPE_NAME_COUNTER IS TABLE OF varchar2(50);
V_NAME_COUNTER TYPE_NAME_COUNTER := TYPE_NAME_COUNTER();
V_TUYR_ID      number(10);
v_string       varchar(30);
V_CURRENT_YEAR NUMBER(10);
v_exists       number(1);
v_is_valid     number(1):=0;
v_namespace_id      number;
v_namespace_prefix  varchar2(50);
begin

 select NAMESPACE_ID, NAMESPACE_PREFIX
    into v_namespace_id, v_namespace_prefix
    from NAMESPACES
   where NAMESPACE_NAME = 'System';

select count(*)
into v_exists
from TIME_UNITS
where TU_NAME = PI_TU_NAME;
--updating into TIME_UNITS
---check if time unit exixts
if (v_exists = 1) then

raise_application_error(-20001, 'Time unit already exist');
end if;

----dbms_output.put_line('START');
--Inserting into TIME_UNITS
-----iterate through the collection to find the TU to be added
for c in 1 .. GVCOL_TIME_UNITS.COUNT loop
----if TU is found
IF (GVCOL_TIME_UNITS(C).OTU_NAME = PI_TU_NAME) THEN

--V_IS_FISCAL      := GVCOL_TIME_UNITS(C).OTU_IS_FISCAL;
v_is_valid := 1;
V_TUS_ID         := GVCOL_TIME_UNITS(C).OTU_ID;
V_DIVISON_FACTOR := GVCOL_TIME_UNITS(C).OTU_DIVISON_FACTOR - 1;
V_OFFSET         := GVCOL_TIME_UNITS(C).OTU_OFFSET;

/*--dbms_output.put_line(PI_TU_NAME);*/
V_TU_ID  := uid_sequence.Nextval;
PO_TU_ID := V_TU_ID;

/*if (V_IS_FISCAL = 0) then*/

insert into TIME_UNITS
(TU_ID,
TU_NAME,
TU_DEFINED_TYPE,
TU_PERIOD_START_TYPE,
TU_YEAR_FORMAT,
--TU_FISCAL_YEAR_START_DAY,
TU_CUSTOM_VERSION,
OBJECT_VERSION,
TU_NAMESPACE_ID,
TU_TECHNICAL_NAME,
TU_LABEL)
values
(V_TU_ID, PI_TU_NAME, 2, 1, 1, 0, 0,v_namespace_id,PI_TU_NAME|| '_' || v_namespace_prefix,PI_TU_NAME);

/*elsif (V_IS_FISCAL = 1) then

----dbms_output.put_line(PI_TU_NAME);
insert into TIME_UNITS
(TU_ID,
TU_NAME,
TU_DEFINED_TYPE,
TU_PERIOD_START_TYPE,
TU_YEAR_FORMAT,
--TU_FISCAL_YEAR_START_DAY,
TU_CUSTOM_VERSION,
OBJECT_VERSION)
values
(V_TU_ID, PI_TU_NAME, 3, 1, 2, 0, 0);

end if;*/

end if;

end loop;

/*if (V_IS_FISCAL is null) then*/
if (v_is_valid = 0) then
raise_application_error(-20001, 'Invalid system time unit name');
end if;

-----iterate through the collection to find the TU Period to be added
---INSERT INTO TIME_PERIODS
for c in 1 .. GVCOL_TU_PERIODS.COUNT loop

IF (GVCOL_TU_PERIODS(C).OTP_VTU_ID = V_TUS_ID) THEN
---if the TU is fiscal then it has to start in april for as per add TU defn
/*IF (V_IS_FISCAL = 1 AND GVCOL_TU_PERIODS(C).OTP_START_MONTH = 10) then

V_TUP_ID := uid_sequence.Nextval;
----store TUP_ID for addition in TU_PERIODS_RANGE
V_ORDER := V_ORDER + 1;
V_COUNTER.EXTEND;
V_COUNTER(V_ORDER) := V_TUP_ID;
V_NAME_COUNTER.EXTEND;
V_NAME_COUNTER(V_ORDER) := GVCOL_TU_PERIODS(C).OTP_NAME;


insert into TU_PERIODS
(TUP_ID, TUP_NAME, TUP_TU_ID, TUP_ORDER, OBJECT_VERSION)
values
(V_TUP_ID,
GVCOL_TU_PERIODS(C).OTP_NAME,
V_TU_ID,
GVCOL_TU_PERIODS(C).OTP_ORDER,
0);

elsIF (V_IS_FISCAL = 0) THEN*/

V_TUP_ID := uid_sequence.Nextval;
V_ORDER  := V_ORDER + 1;
V_COUNTER.EXTEND;
V_COUNTER(V_ORDER) := V_TUP_ID;
V_NAME_COUNTER.EXTEND;
V_NAME_COUNTER(V_ORDER) := GVCOL_TU_PERIODS(C).OTP_NAME;


insert into TU_PERIODS
(TUP_ID, TUP_NAME, TUP_TU_ID, TUP_ORDER, OBJECT_VERSION)
values
(V_TUP_ID,
GVCOL_TU_PERIODS(C).OTP_NAME,
V_TU_ID,
GVCOL_TU_PERIODS(C).OTP_ORDER,
0);
/*
END IF;*/

END IF;

END LOOP;

--for loop for each year

while (TRUE) loop


--start from the start year and exit after adding till PI_END_YEAR
exit when(V_YEAR_COUNTER > PI_END_YEAR);

----add for TU_YEARS_RANGE

V_TUYR_ID := uid_sequence.Nextval;

/*if (V_IS_FISCAL = 0) then*/

insert into TU_YEARS_RANGE
(TUYR_ID,
TUYR_TU_ID,
TUYR_YEAR,
TUYR_START_DATE,
TUYR_END_DATE,
OBJECT_VERSION)
values
(V_TUYR_ID,
V_TU_ID,
V_YEAR_COUNTER,
trunc(TO_DATE(V_YEAR_COUNTER, 'YYYY'), 'YYYY'),
trunc(TO_DATE(V_YEAR_COUNTER + 1, 'YYYY'), 'YYYY') - 1,
0);

/*elsif (V_IS_FISCAL = 1) then
--if yeat is fiscal it start on april as per add TU defn
--change in TUYR_START_DATE and TUYR_END_DATE to push fiscal time units back by a year
insert into TU_YEARS_RANGE
(TUYR_ID,
TUYR_TU_ID,
TUYR_YEAR,
TUYR_START_DATE,
TUYR_END_DATE,
OBJECT_VERSION)
values
(V_TUYR_ID,
V_TU_ID,
V_YEAR_COUNTER,
add_months(trunc(TO_DATE(V_YEAR_COUNTER - 1, 'YYYY'), 'YYYY'),
V_FISCAL_OFFSET),
add_months(trunc(TO_DATE(V_YEAR_COUNTER , 'YYYY'), 'YYYY') - 1,
V_FISCAL_OFFSET),
0);

\*       insert into TU_YEARS_RANGE
(TUYR_ID,
TUYR_TU_ID,
TUYR_YEAR,
TUYR_START_DATE,
TUYR_END_DATE,
OBJECT_VERSION)
values
(V_TUYR_ID,
V_TU_ID,
V_YEAR_COUNTER,
add_months(trunc(TO_DATE(V_YEAR_COUNTER , 'YYYY'), 'YYYY'),
V_FISCAL_OFFSET),
add_months(trunc(TO_DATE(V_YEAR_COUNTER + 1, 'YYYY'), 'YYYY') - 1,
V_FISCAL_OFFSET),
0);*\




END IF;*/

----reset v_order to start pulling out TUP_ID
v_order := 1;
----
for c in 1 .. GVCOL_TU_PERIODS.COUNT loop



IF (GVCOL_TU_PERIODS(C).OTP_VTU_ID = V_TUS_ID) THEN

/*if (V_IS_FISCAL = 0) then*/

V_TUPR_ID := uid_sequence.Nextval;

V_CURRENT_YEAR := V_YEAR_COUNTER + GVCOL_TU_PERIODS(C)
.OTP_YEAR_OFFSET;
v_string       := GVCOL_TU_PERIODS(C)
.OTP_MONTH_OFFSET || '/' || V_CURRENT_YEAR;
                                       insert into TU_PERIODS_RANGE
                                                                           (TUPR_ID,
                                                                           TUPR_TUP_ID,
                                                                           TUPR_TU_ID,
                                                                           TUPR_START_DATE,
                                                                           TUPR_END_DATE,
                                                                           TUPR_TUYR_ID,
                                                                           TUPR_PERIOD_NUMBER,
                                                                           TUPR_YEAR,
                                                                           TUPR_PERIOD_RANGE_NAME,
                                                                           OBJECT_VERSION)
                                                                           values
                                                                           (V_TUPR_ID,
                                                                           V_COUNTER(v_order),
                                                                            V_TU_ID,
                                                                           to_date(v_string, 'mm/yyyy'),
                                                                           last_day(add_months(to_date(v_string, 'mm/yyyy'),
                                                                           V_DIVISON_FACTOR)),
                                                                           V_TUYR_ID,
                                                                           GVCOL_TU_PERIODS(C).OTP_ORDER,
                                                                           V_YEAR_COUNTER,
                                                                           V_NAME_COUNTER(V_ORDER) || ' ' || V_YEAR_COUNTER,
                                                                           0);

v_order := v_order + 1;
/*elsif (V_IS_FISCAL = 1 AND GVCOL_TU_PERIODS(C)
.OTP_START_MONTH = 10) then

V_TUPR_ID      := uid_sequence.Nextval;
--change in V_CURRENT_YEAR to push fiscal time units back by a year
\*    V_CURRENT_YEAR := V_YEAR_COUNTER + GVCOL_TU_PERIODS(C)
.OTP_YEAR_OFFSET;*\

V_CURRENT_YEAR := V_YEAR_COUNTER + GVCOL_TU_PERIODS(C)
.OTP_YEAR_OFFSET - 1;
v_string       := GVCOL_TU_PERIODS(C)
.OTP_MONTH_OFFSET || '/' || V_CURRENT_YEAR;

                                                                            insert into TU_PERIODS_RANGE
                                                                           (TUPR_ID,
                                                                           TUPR_TUP_ID,
                                                                           TUPR_TU_ID,
                                                                           TUPR_START_DATE,
                                                                           TUPR_END_DATE,
                                                                           TUPR_TUYR_ID,
                                                                           TUPR_PERIOD_NUMBER,
                                                                           TUPR_YEAR,
                                                                           TUPR_PERIOD_RANGE_NAME,
                                                                           OBJECT_VERSION)
                                                                           values
                                                                           (V_TUPR_ID,
                                                                           V_COUNTER(v_order),
                                                                            V_TU_ID,
                                                                           to_date(v_string, 'mm/yyyy'),
                                                                           last_day(add_months(to_date(v_string, 'mm/yyyy'),
                                                                           V_DIVISON_FACTOR)),
                                                                           V_TUYR_ID,
                                                                           GVCOL_TU_PERIODS(C).OTP_ORDER,
                                                                           V_YEAR_COUNTER,
                                                                           V_NAME_COUNTER(V_ORDER) || ' FY-' ||
                                                                           substr(to_char(V_YEAR_COUNTER), -2, 2),
                                                                           0);
v_order := v_order + 1;
END IF;*/

end if;

end loop;

V_YEAR_COUNTER := V_YEAR_COUNTER + 1;

end loop;
ADD_SYSTEM_TIME_UNIT_CORR(PI_TU_NAME);

end ADD_SYSTEM_TIME_UNIT;

--PUBLIC PROCEDURES UPDATE_SYSTEM_TIME_UNIT START
/*procedure UPDATE_SYSTEM_TIME_UNIT(PI_TU_NAME       in VARCHAR2,
PI_FISCAL_OFFSET in NUMBER,
PI_FISCAL_CHANGE in number,
PI_FORMAT_CHANGE IN NUMBER,
PI_FORMAT_TYPE   in NUMBER) AS

v_exists number;

V_CURRENT_YEAR NUMBER;
v_string       VARCHAR2(50);

CURSOR C_TIME_UNIT IS
select * from TIME_UNITS where TU_NAME = PI_TU_NAME;

V_IS_FISCAL      number(10);
V_TUS_ID         number(10);
V_DIVISON_FACTOR number(10);
V_OFFSET         number(10);
begin
---check if fiscal offset provided is correct
if (PI_FISCAL_OFFSET NOT IN (4, 7, 10) AND PI_FISCAL_CHANGE = 1) then

raise_application_error(-20001, 'Invalid fiscal offset provided');

ELSIF (PI_FISCAL_OFFSET IN (4, 7, 10) AND PI_FISCAL_CHANGE = 1) THEN

select count(*)
into v_exists
from TIME_UNITS
where TU_NAME = PI_TU_NAME;
--updating into TIME_UNITS
---check if time unit exixts
if (v_exists = 0) then

raise_application_error(-20001,
'Time unit doesn''t exist or wrong Time unit name');

elsif (v_exists = 1) then

for c in 1 .. GVCOL_TIME_UNITS.COUNT loop
----if TU is found
IF (GVCOL_TIME_UNITS(C).OTU_NAME = PI_TU_NAME) THEN

V_IS_FISCAL      := GVCOL_TIME_UNITS(C).OTU_IS_FISCAL;
V_TUS_ID         := GVCOL_TIME_UNITS(C).OTU_ID;
V_DIVISON_FACTOR := GVCOL_TIME_UNITS(C).OTU_DIVISON_FACTOR - 1;
V_OFFSET         := GVCOL_TIME_UNITS(C).OTU_OFFSET;

end if;

end loop;

end if;

FOR C_TU IN C_TIME_UNIT LOOP

--UPDATE TU_YEARS_RANGE
UPDATE TU_YEARS_RANGE
SET TUYR_START_DATE = TO_DATE(TO_CHAR(PI_FISCAL_OFFSET) || '/' ||
(TO_CHAR(TUYR_START_DATE, 'YYYY')),
'MM/YYYY'),
TUYR_END_DATE   = LAST_DAY(TO_DATE(TO_CHAR(PI_FISCAL_OFFSET - 1) || '/' ||
(TO_CHAR(TUYR_END_DATE,
 'YYYY')),
'MM/YYYY')),
OBJECT_VERSION  = OBJECT_VERSION + 1
WHERE TUYR_TU_ID = C_TU.TU_ID;
---Iterate through time period for tup_id
FOR C_TP IN (SELECT * FROM TU_PERIODS WHERE TUP_TU_ID = C_TU.TU_ID) LOOP
--Iterate through TU_PERIODS_RANGE to update ranges
FOR C_TPR IN (SELECT *
FROM TU_PERIODS_RANGE
WHERE TUPR_TUP_ID = C_TP.TUP_ID) LOOP
----Iterate through our internal structure to search for the right set of time periods
FOR C_ITP IN 1 .. GVCOL_TU_PERIODS.COUNT LOOP
---match the name and the offset
IF (C_TP.TUP_NAME = GVCOL_TU_PERIODS(C_ITP).OTP_NAME AND GVCOL_TU_PERIODS(C_ITP)
.OTP_START_MONTH = PI_FISCAL_OFFSET) THEN
----search for the years for which the tu period ranhges are to be defined
FOR C_TYR IN (SELECT *
FROM TU_YEARS_RANGE
WHERE TUYR_ID = C_TPR.TUPR_TUYR_ID) LOOP
--change in V_CURRENT_YEAR to push fiscal time units back by a year
V_CURRENT_YEAR := C_TYR.TUYR_YEAR + GVCOL_TU_PERIODS(C_ITP)
.OTP_YEAR_OFFSET-1;

\*  V_CURRENT_YEAR := C_TYR.TUYR_YEAR + GVCOL_TU_PERIODS(C_ITP)
.OTP_YEAR_OFFSET-1;*\
v_string       := GVCOL_TU_PERIODS(C_ITP).OTP_MONTH_OFFSET || '/' ||
V_CURRENT_YEAR;

----UPDATE TU_PERIODS_RANGE
IF (PI_FORMAT_CHANGE = 1 AND PI_FORMAT_TYPE IS NOT NULL) THEN
UPDATE TU_PERIODS_RANGE
SET TUPR_START_DATE        = to_date(v_string,
  'mm/yyyy'),
TUPR_END_DATE          = last_day(add_months(to_date(v_string,
            'mm/yyyy'),
        V_DIVISON_FACTOR)),
TUPR_PERIOD_NUMBER     = GVCOL_TU_PERIODS(C_ITP)
.OTP_ORDER,
TUPR_YEAR              = C_TYR.TUYR_YEAR,
TUPR_PERIOD_RANGE_NAME = GVCOL_TU_PERIODS(C_ITP)
.OTP_NAME || ' ' ||
Case PI_FORMAT_TYPE
when 1 then
'20' ||
substr(to_char(C_TYR.TUYR_YEAR),
   -2,
   2)
when 2 then
'FY-' ||
substr(to_char(C_TYR.TUYR_YEAR),
   -2,
   2)
when 3 then
TO_NUMBER(substr(to_char(C_TYR.TUYR_YEAR),
         -2,
         2)) - 1 || '-' ||
substr(to_char(C_TYR.TUYR_YEAR),
   -2,
   2)
end,
OBJECT_VERSION         = OBJECT_VERSION + 1
where TUPR_ID = C_TPR.TUPR_ID;

ELSIF (PI_FORMAT_CHANGE = 0) THEN
UPDATE TU_PERIODS_RANGE
SET TUPR_START_DATE    = to_date(v_string, 'mm/yyyy'),
TUPR_END_DATE      = last_day(add_months(to_date(v_string,
          'mm/yyyy'),
      V_DIVISON_FACTOR)),
TUPR_PERIOD_NUMBER = GVCOL_TU_PERIODS(C_ITP)
.OTP_ORDER,
OBJECT_VERSION     = OBJECT_VERSION + 1
where TUPR_ID = C_TPR.TUPR_ID;

END IF;

END LOOP;
END IF;

END LOOP;

END LOOP;

END LOOP;

delete from TU_CORRESPONDENCE
where C_TU.TU_ID = TUC_TU_ID
OR C_TU.TU_ID = TUC_TU_ID_CORR;
END LOOP;

ADD_SYSTEM_TIME_UNIT_CORR(PI_TU_NAME);

ELSIF (PI_FORMAT_CHANGE = 1 AND PI_FORMAT_TYPE IS NOT NULL) THEN

UPDATE TU_PERIODS_RANGE
SET TUPR_PERIOD_RANGE_NAME =
(Select (SELECT TUP_NAME
FROM TU_PERIODS
WHERE TUP_ID = TUPR_TUP_ID) || ' ' ||
Case PI_FORMAT_TYPE
when 1 then
'20' ||
substr(to_char(TUPR_PERIOD_RANGE_NAME), -2, 2)
when 2 then
'FY-' ||
substr(to_char(TUPR_PERIOD_RANGE_NAME), -2, 2)
when 3 then
TO_NUMBER(substr(to_char(TUPR_PERIOD_RANGE_NAME),
-2,
2)) - 1 || '-' ||
substr(to_char(TUPR_PERIOD_RANGE_NAME), -2, 2)
end
FROM DUAL),

OBJECT_VERSION = OBJECT_VERSION + 1
where TUPR_ID IN
(SELECT TUPR.TUPR_ID
FROM TU_PERIODS_RANGE TUPR, TU_PERIODS TUP, TIME_UNITS TU
WHERE tu.TU_NAME = PI_TU_NAME
AND tup.TUP_TU_ID = tu.TU_ID
AND tupr.TUPR_TUP_ID = tup.TUP_ID);

else

raise_application_error(-20001,
'Invalid combination of Input Parameters');

end if;

end UPDATE_SYSTEM_TIME_UNIT;*/

--PUBLIC FUNCTION UPDATE_SYSTEM_TIME_UNIT START
FUNCTION GET_PERIOD_YEAR_RANGE_ID(PI_PERIOD_STRING  in VARCHAR2,
PI_TU_ID          in NUMBER,
PI_TU_YEAR_FORMAT in number)
return number as

v_space_location     number(10);
v_year_part          varchar2(50);
v_period_part        varchar2(50);
v_number_check       number(10);
v_reverse_string     varchar2(250);
TU_PERIODS_ROW       TU_PERIODS%ROWTYPE;
TU_YEARS_RANGE_ROW   TU_YEARS_RANGE%ROWTYPE;
TU_PERIODS_RANGE_ROW TU_PERIODS_RANGE%ROWTYPE;


begin

if(PI_PERIOD_STRING is null) then
return null;
end if;

select REVERSE(PI_PERIOD_STRING) into v_reverse_string from dual;
v_space_location := instr(v_reverse_string, ' ');

if (v_space_location = 0) then

raise_application_error(-20001,
'Invalid format for ' || PI_PERIOD_STRING);

end if;

v_year_part := substr(PI_PERIOD_STRING, -v_space_location);

if (PI_TU_YEAR_FORMAT = 1) then

begin
v_number_check := to_number(v_year_part);

exception
when invalid_number then
raise_application_error(-20001,
'Invalid year format for ' || v_year_part);

end;
elsif (PI_TU_YEAR_FORMAT = 2) then

if (substr(v_year_part, 1, 2) = 'FY') then

raise_application_error(-20001,
'Invalid year format for ' || v_year_part);

end if;

begin
v_number_check := to_number('20' || substr(v_year_part, -2, 2));

exception
when invalid_number then
raise_application_error(-20001,
'Invalid year format for ' || v_year_part);

end;

elsif (PI_TU_YEAR_FORMAT = 3) then
if (substr(v_year_part, 1, 2) = 'PY') then

raise_application_error(-20001,
'Invalid year format for ' || v_year_part);
end if;

begin
v_number_check := to_number('20' || substr(v_year_part, -2, 2));

exception
when invalid_number then
raise_application_error(-20001,
'Invalid year format for ' || v_year_part);

end;

end if;

---get the month

select substr(PI_PERIOD_STRING,
1,
length(PI_PERIOD_STRING) -
instr(reverse(PI_PERIOD_STRING), ' '))
into v_period_part
from dual;

begin

select *
into TU_PERIODS_ROW
from TU_PERIODS
where TUP_TU_ID = PI_TU_ID
and UPPER(TUP_NAME) = UPPER(v_period_part);

exception
when no_data_found then
raise_application_error(-20001,
'Invalid Period format or the period does not exist for this TU, period name is' ||
v_period_part);
end;

begin

select *
into TU_YEARS_RANGE_ROW
from TU_YEARS_RANGE
where TUYR_TU_ID = PI_TU_ID
and UPPER(TUYR_YEAR) = UPPER(v_number_check);

exception
when no_data_found then
raise_application_error(-20001,
'Invalid Year format or the Year does not exist for this TU, Year name is' ||
v_period_part);
end;

begin

select *
into TU_PERIODS_RANGE_ROW
from TU_PERIODS_RANGE
where TUPR_TUYR_ID = TU_YEARS_RANGE_ROW.TUYR_ID
and TUPR_TUP_ID = TU_PERIODS_ROW.TUP_ID;

exception
when no_data_found then
raise_application_error(-20001,
'Period range not found for this combination of year and period or the period does not exist for this TU, period and year are ' ||
v_period_part || ' and ' || v_year_part);
RETURN -1;
end;

RETURN TU_PERIODS_RANGE_ROW.TUPR_ID;

exception

when others then
RETURN -1;

end GET_PERIOD_YEAR_RANGE_ID;

--PUBLIC FUNCTION get_period_range_id_within START
function get_period_range_id_within(pi_tu_id         number,
                                    pi_tupr_id_start number,
                                    pi_tupr_id_end   number) return COLTYPE_ID deterministic
as
    v_sql                      varchar(2048);
    v_list_tupr_ids            COLTYPE_ID;
    v_tupr_id_start            number(10):=pi_tupr_id_start;
    v_tupr_id_end              number(10):=pi_tupr_id_end;

    v_start_TUPR_PERIOD_NUMBER TU_PERIODS_RANGE.TUPR_PERIOD_NUMBER%type;
    v_start_TUPR_TUYR_ID       TU_PERIODS_RANGE.TUPR_TUYR_ID%type;
    v_start_TUYR_YEAR          TU_YEARS_RANGE.TUYR_YEAR%type;
    v_end_TUPR_PERIOD_NUMBER   TU_PERIODS_RANGE.TUPR_PERIOD_NUMBER%type;
    v_end_TUPR_TUYR_ID         TU_PERIODS_RANGE.TUPR_TUYR_ID%type;
    v_end_TUYR_YEAR            TU_YEARS_RANGE.TUYR_YEAR%type;
begin
    if (pi_tupr_id_start is null) then
       select tupr_id
              into v_tupr_id_start
       from tu_periods_range
       where tupr_start_date in (
                                 select min(tupr_start_date)
                                 from tu_periods_range
                                 where tupr_tuyr_id in (
                                                        select tuyr_id
                                                        from tu_years_range
                                                        where (tuyr_tu_id, tuyr_start_date) in (
                                                                                                select tuyr_tu_id, min(tuyr_start_date)
                                                                                                from tu_years_range
                                                                                                where tuyr_tu_id = pi_tu_id
                                                                                                group by tuyr_tu_id
                                                                                               )
                                                       )
                                )
             and tupr_tup_id in (
                                 select TUP_ID
                                 from tu_periods
                                 where tup_tu_id = pi_tu_id
                                );
    end if;

    if (pi_tupr_id_end is null) then
       select tupr_id
              into v_tupr_id_end
       from tu_periods_range
       where tupr_start_date in (
                                 select max(tupr_start_date)
                                 from tu_periods_range
                                 where tupr_tuyr_id in (
                                                        select tuyr_id
                                                        from tu_years_range
                                                        where (tuyr_tu_id, tuyr_start_date) in (
                                                                                                select tuyr_tu_id, max(tuyr_start_date)
                                                                                                from tu_years_range
                                                                                                where tuyr_tu_id = pi_tu_id
                                                                                                group by tuyr_tu_id
                                                                                               )
                                                       )
                                )
             and tupr_tup_id in (
                                 select TUP_ID
                                 from tu_periods
                                 where tup_tu_id = pi_tu_id
                                );
    end if;



    /* start */
    select TUPR_PERIOD_NUMBER, TUPR_TUYR_ID, TUYR_YEAR
           into v_start_TUPR_PERIOD_NUMBER, v_start_TUPR_TUYR_ID, v_start_TUYR_YEAR
    from tu_periods_range
    inner join TU_YEARS_RANGE on TUYR_ID = TUPR_TUYR_ID
    where tupr_id = v_tupr_id_start;

    /* end */
    if v_tupr_id_start <> v_tupr_id_end then
        select TUPR_PERIOD_NUMBER, TUPR_TUYR_ID, TUYR_YEAR
               into v_end_TUPR_PERIOD_NUMBER, v_end_TUPR_TUYR_ID, v_end_TUYR_YEAR
        from tu_periods_range
        inner join TU_YEARS_RANGE on TUYR_ID = TUPR_TUYR_ID
        where tupr_id = v_tupr_id_end;
    else
        v_end_TUPR_PERIOD_NUMBER := v_start_TUPR_PERIOD_NUMBER;
        v_end_TUPR_TUYR_ID       := v_start_TUPR_TUYR_ID;
        v_end_TUYR_YEAR          := v_start_TUYR_YEAR;
    end if;

    v_sql:='select cast(multiset(
                     select tupr.tupr_id
                     from tu_periods_range tupr
                     inner join tu_periods tup on (tup.TUP_ID = tupr.tupr_TUP_ID)
                     where tup.tup_tu_id = :1
                           and (' || case when v_start_TUPR_TUYR_ID = v_end_TUPR_TUYR_ID
                                     then '
                                     (      tupr.TUPR_TUYR_ID = :2
                                        and tupr.TUPR_PERIOD_NUMBER >= :3
                                        and tupr.TUPR_PERIOD_NUMBER <= :4
                                     ) '
                                     else '
                                     (
                                         (    tupr.TUPR_TUYR_ID = :5
                                          and tupr.TUPR_PERIOD_NUMBER >= :6
                                         )
                                      or (   tupr.TUPR_TUYR_ID = :7
                                          and tupr.TUPR_PERIOD_NUMBER <= :8
                                         )
                                     )'
                                 end ||
                 case when NVL(v_start_TUYR_YEAR,1900) <> NVL(v_end_TUYR_YEAR, 1900)
                           then
                             	   '
                                 or (
                                     tupr.TUPR_TUYR_ID in (
                                                           select TUYR_ID
                                                           from   TU_YEARS_RANGE
                                                           where  TUYR_YEAR > :9
                                                                  and TUYR_YEAR < :10
                                                          )
                                    )'
                           else ''
                end
                || '
                               )
                     order by tupr.tupr_start_date
                   ) as coltype_id)
              from dual';

    --dbms_output.put_line(v_sql);
    if v_start_TUPR_TUYR_ID = v_end_TUPR_TUYR_ID then
        if NVL(v_start_TUYR_YEAR,1900) <> NVL(v_end_TUYR_YEAR, 1900) then
           execute immediate v_sql into v_list_tupr_ids using   pi_tu_id,                       --1
                                                                v_start_TUPR_TUYR_ID,           --2
                                                                v_start_TUPR_PERIOD_NUMBER,     --3
                                                                v_end_TUPR_PERIOD_NUMBER,       --4
                                                                v_start_TUYR_YEAR,              --9
                                                                v_end_TUYR_YEAR;                --10
        else
           execute immediate v_sql into v_list_tupr_ids using   pi_tu_id,                       --1
                                                                v_start_TUPR_TUYR_ID,           --2
                                                                v_start_TUPR_PERIOD_NUMBER,     --3
                                                                v_end_TUPR_PERIOD_NUMBER;       --4
        end if;
    else
        if NVL(v_start_TUYR_YEAR,1900) <> NVL(v_end_TUYR_YEAR, 1900) then
           execute immediate v_sql into v_list_tupr_ids using   pi_tu_id,                       --1
                                                                v_start_TUPR_TUYR_ID,           --5
                                                                v_start_TUPR_PERIOD_NUMBER,     --6
                                                                v_end_TUPR_TUYR_ID,             --7
                                                                v_end_TUPR_PERIOD_NUMBER,       --8
                                                                v_start_TUYR_YEAR,              --9
                                                                v_end_TUYR_YEAR;                --10
        else
           execute immediate v_sql into v_list_tupr_ids using   pi_tu_id,                       --1
                                                                v_start_TUPR_TUYR_ID,           --5
                                                                v_start_TUPR_PERIOD_NUMBER,     --6
                                                                v_end_TUPR_TUYR_ID,             --7
                                                                v_end_TUPR_PERIOD_NUMBER;       --8
        end if;
    end if;

    return v_list_tupr_ids;
end get_period_range_id_within;

--PUBLIC FUNCTION get_period_start_end_date START
procedure get_period_start_end_date(pi_tupr_id    in number,
po_start_date OUT date,
po_end_date   OUT date) as

begin

if (pi_tupr_id is null) then

po_start_date := null;--to_date('01/01/0001', 'dd/mm/yyyy');
po_end_date   := null;--to_date('31/12/9999', 'dd/mm/yyyy');
-- if the above NULL values change, please update everyone as they are expected in other modules (instead of 01/01/0001 and 31/12/9999)

else

begin
select TUPR_START_DATE, TUPR_END_DATE
into po_start_date, po_end_date
from tu_periods_range where tupr_id=pi_tupr_id;
exception
WHEN no_data_found THEN
raise_application_error(-20001,
'TUPR_ID provided doesn''t exist ');

end;


end if;

end get_period_start_end_date;


procedure get_Correspondence(pi_base_tupr_id in number,
pi_base_tu_id   in number,
pi_corr_tu_id   in number,
PI_START_YEAR   in NUMBER,
PI_END_YEAR     in NUMBER,
po_error_code   OUT number,
po_list_tupr_id OUT COLTYPE_ID) as

v_tuc_id       number(10);
v_tup_id_corr  number(10);
v_year_offset  number(1);
v_tuyr_id      number(10);
v_year_corr    number(4);
v_tupc_period_number number(10);
v_temp_tupr_id number(10);
begin

-- if base and corr TU are same
if(pi_base_tu_id=pi_corr_tu_id ) then

select max(tupr_id) into v_temp_tupr_id
  from tu_periods_range
 where tupr_tu_id = pi_base_tu_id
   and tupr_id = pi_base_tupr_id;

if (v_temp_tupr_id is not null) then
po_list_tupr_id:=COLTYPE_ID(pi_base_tupr_id);
po_error_code:=0;
else
po_list_tupr_id := COLTYPE_ID();
po_error_code:=100;

end if;
return;

end if;


---checking correspondace between the TU
begin
select tuc_id
into v_tuc_id
from tu_correspondence
where tuc_tu_id = pi_base_tu_id
and tuc_tu_id_corr = pi_corr_tu_id;
exception
WHEN no_data_found THEN

po_error_code := 100;
raise;
end;
--dbms_output.put_line('v_tuc_id:'||v_tuc_id);
---loop to query tu_period range to take out the base period details
for tupr_base in (select tupr_ID,
tupr_TUP_ID,
TUPR_PERIOD_NUMBER,
TUPR_TUYR_ID,
tupr_year
from tu_periods_range
where tupr_ID = pi_base_tupr_id) loop

begin

---check if the correspondance exist at period level
select nvl(tupc_tup_id_corr,-1),nvl(tupc_period_number_corr,-1), decode(tupc_year_offset, 1, -1, 2, 0, 3, 1)
into v_tup_id_corr,v_tupc_period_number, v_year_offset
from tu_periods_correspondence
where tupc_tuc_id = v_tuc_id
and ((tupc_tup_id = tupr_base.tupr_TUP_ID and
       tupc_tup_id_corr is not null)

       or (tupc_period_number = tupr_base.TUPR_PERIOD_NUMBER and
       tupc_period_number_corr is not null));
exception
WHEN no_data_found THEN


po_error_code := 100;
raise;
end;
--dbms_output.put_line('v_tup_id_corr:'||v_tup_id_corr);
--dbms_output.put_line('v_tupc_period_number:'||v_tupc_period_number);
--dbms_output.put_line('v_year_offset:'||v_year_offset);
--calculate year of correspondence
v_year_corr := v_year_offset + tupr_base.tupr_year;
--dbms_output.put_line('New_v_year_corr:'||v_year_corr);
if (v_year_corr not between PI_START_YEAR and PI_END_YEAR) then

po_error_code := 200;

raise_application_error(-20001, '');
end if;

begin
----check if the calculates year exist for corresponding year
select tuyr_id
into v_tuyr_id
from tu_years_range
where tuyr_year = v_year_corr
and tuyr_tu_id = pi_corr_tu_id;



exception

WHEN no_data_found THEN
po_error_code := 300;
raise;


end;
--dbms_output.put_line('v_tuyr_id:'||v_tuyr_id);




end loop;




----take out the corresponding tupr id
select cast(multiset (select tupr_id
from (select tupr_id
/*into v_tuyr_id_corr*/
from tu_periods_range
where tupr_tuyr_id = v_tuyr_id
and (

tupr_tup_id =v_tup_id_corr

or
(
tupr_period_number =v_tupc_period_number
and
tupr_tup_id in

(select tup_id  from tu_periods where
tup_tu_id=pi_corr_tu_id )

)
)
)) as coltype_id)
into po_list_tupr_id
from dual;

if (po_list_tupr_id.count=0) then
po_error_code := 400;
raise_application_error(-20001, '');
end if;


po_error_code := 0;
exception
WHEN others THEN
po_list_tupr_id := COLTYPE_ID();

end get_Correspondence;


procedure get_reverse_Correspondence(pi_corr_tupr_id in number,
pi_base_tu_id   in number,
pi_corr_tu_id   in number,
PI_START_YEAR   in NUMBER,
PI_END_YEAR     in NUMBER,
po_error_code   OUT number,
po_list_tupr_id OUT COLTYPE_ID) as

type coltype_tup_id_corr is table of number(10);
type coltype_year_offset is table of number(1);
type coltype_period_number is table of number(1);

v_tuc_id       number(10);
v_tup_id_corr  coltype_tup_id_corr;
v_where        clob;
v_year_offset  coltype_year_offset;
v_tupc_period_number_corr coltype_period_number;
v_tuyr_id      number(10);
v_year_corr    number(4);
v_temp_tupr_id  number(10);


begin

-- if base and corr TU are same
if(pi_base_tu_id=pi_corr_tu_id ) then

select max(tupr_id) into v_temp_tupr_id
  from tu_periods_range
 where tupr_tu_id = pi_corr_tu_id
   and tupr_id = pi_corr_tupr_id;

if (v_temp_tupr_id is not null) then
po_list_tupr_id:=COLTYPE_ID(pi_corr_tupr_id);
po_error_code:=0;
else
po_list_tupr_id := COLTYPE_ID();
po_error_code:=100;

end if;
return;

end if;


---checking correspondace between the TU
begin
select tuc_id
into v_tuc_id
from tu_correspondence
where tuc_tu_id = pi_base_tu_id
and tuc_tu_id_corr = pi_corr_tu_id;
exception
WHEN no_data_found THEN
--dbms_output.put_line('TU level');
po_error_code := 100;
raise;
end;
--dbms_output.put_line('TU level');

---loop to query tu_period range to take out the base period details
for tupr_base in (select tupr_ID,
tupr_TUP_ID,
TUPR_PERIOD_NUMBER,
TUPR_TUYR_ID,
tupr_year
from tu_periods_range
where tupr_ID = pi_corr_tupr_id) loop

/*begin*/

---check if the correspondance exist at period level
select nvl(tupc_tup_id,-1),nvl(tupc_period_number,-1),
decode(tupc_year_offset, 1, 1, 2, 0, 3, -1) bulk collect
into v_tup_id_corr,v_tupc_period_number_corr, v_year_offset
from tu_periods_correspondence
where tupc_tuc_id = v_tuc_id
and (tupc_tup_id_corr = tupr_base.tupr_TUP_ID or
tupc_period_number_corr = tupr_base.TUPR_PERIOD_NUMBER);


if(v_tup_id_corr.count=0) then
po_error_code := 100;
raise_application_error(-20001,'Correspondance doesn''t exist at period level ');
end if;
/*exception
WHEN no_data_found THEN
--dbms_output.put_line('Period level');
po_error_code := 100;
raise;
end;*/
--dbms_output.put_line('Period level');
for i in 1 .. v_tup_id_corr.count loop

---calculate year of correspondence
v_year_corr := v_year_offset(i) + tupr_base.tupr_year;

if (v_year_corr not between PI_START_YEAR and PI_END_YEAR) then

po_error_code := 200;

raise_application_error(-20001, '');
end if;

begin
----check if the calculates year exist for base year
select tuyr_id
into v_tuyr_id
from tu_years_range
where tuyr_year = v_year_corr
and tuyr_tu_id = pi_base_tu_id;

exception

WHEN no_data_found THEN
po_error_code := 300;
raise;

end;

v_where := v_where
|| ' (
tupr_tuyr_id = ' || v_tuyr_id ||
' and ( tupr_tup_id = ' || v_tup_id_corr(i) || ' or
tupr_period_number ='||v_tupc_period_number_corr(i)||')
) or';

end loop;

end loop;
v_where := substr(v_where, 1, length(v_where) - 2);

----take out the base tupr id's
EXECUTE IMMEDIATE 'select cast(multiset (select tupr_id
from (select tupr_id,tupr_start_date

from tu_periods_range
where ' || v_where ||
' and  tupr_tup_id in

(select tup_id  from tu_periods where
tup_tu_id='||pi_base_tu_id||' ) )order by tupr_start_date) as coltype_id) from dual'
into po_list_tupr_id;

if (po_list_tupr_id.count=0) then
po_error_code := 400;
raise_application_error(-20001, '');
end if;



po_error_code := 0;
exception
WHEN others THEN
po_list_tupr_id := COLTYPE_ID();

end get_reverse_Correspondence;


function get_tupr_Correspondence(pi_base_tupr_id_start in number,
pi_corr_tupr_id_start in number,
pi_base_tupr_id_end in number default null,
pi_corr_tupr_id_end in number default null,
pi_base_tu_id       in number,
pi_corr_tu_id       in number,
pi_type  number -- 1 = single period correspondence, 2 = single period to a range of period correspondence---3 range of period to single period correspondence
) return number deterministic as

v_list_tupr_id coltype_id;
v_range_tupr_id COLTYPE_ID;
v_error_code   number;

begin

if (pi_type is null) then


raise_application_error(-20001, '');
else



if (pi_type=1) then

COMMONS_TIMEUNITS.GET_CORRESPONDENCE(PI_BASE_TUPR_ID => pi_base_tupr_id_start,
PI_BASE_TU_ID   => pi_base_tu_id,
PI_CORR_TU_ID   => pi_corr_tu_id,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => v_error_code,
po_list_tupr_id => v_list_tupr_id);


if (v_list_tupr_id.count<>0 and v_error_code=0) then
for i in 1..v_list_tupr_id.count  loop

if (v_list_tupr_id(i)=pi_corr_tupr_id_start) then
RETURN 1;
end if;
end loop;

else

RETURN 0;
end if;


elsif (pi_type=2  ) then

v_range_tupr_id:=COMMONS_TIMEUNITS.get_period_range_id_within(pi_tu_id  =>pi_base_tu_id,
pi_tupr_id_start =>pi_base_tupr_id_start,
pi_tupr_id_end  =>pi_base_tupr_id_end);


for i in 1..v_range_tupr_id.count  loop


COMMONS_TIMEUNITS.GET_CORRESPONDENCE(PI_BASE_TUPR_ID => v_range_tupr_id(i),
PI_BASE_TU_ID   => pi_base_tu_id,
PI_CORR_TU_ID   => pi_corr_tu_id,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => v_error_code,
po_list_tupr_id => v_list_tupr_id);

if (v_list_tupr_id.count<>0 and v_error_code=0) then
for i in 1..v_list_tupr_id.count  loop

if (v_list_tupr_id(i)=pi_corr_tupr_id_start) then
RETURN 1;
end if;
end loop;


end if;
end loop;


elsif (pi_type=3 ) then
--dbms_output.put_line('inside three');
v_range_tupr_id:=COMMONS_TIMEUNITS.get_period_range_id_within(pi_tu_id  =>pi_corr_tu_id,
pi_tupr_id_start =>pi_corr_tupr_id_start,
pi_tupr_id_end  =>pi_corr_tupr_id_end);


COMMONS_TIMEUNITS.GET_CORRESPONDENCE(PI_BASE_TUPR_ID => pi_base_tupr_id_start,
PI_BASE_TU_ID   => pi_base_tu_id,
PI_CORR_TU_ID   => pi_corr_tu_id,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => v_error_code,
po_list_tupr_id => v_list_tupr_id);

if (v_list_tupr_id.count<>0 and v_error_code=0) then
for i in 1..v_range_tupr_id.count  loop




for j in 1..v_list_tupr_id.count  loop
if(v_list_tupr_id(j)=v_range_tupr_id(i)) then
--dbms_output.put_line(v_range_tupr_id(i));
--dbms_output.put_line(v_list_tupr_id(j));

RETURN 1;
end if;

end loop;

end loop;
end if;
end if ;

end if;

return 0;
exception
WHEN others THEN
RETURN 0;

end get_tupr_Correspondence;


function get_tupr_rev_Correspondence(pi_base_tupr_id_start in number,
pi_corr_tupr_id_start in number,
pi_base_tupr_id_end in number default null,
pi_corr_tupr_id_end in number default null,
pi_base_tu_id  in number,
pi_corr_tu_id  in number,
pi_type  number -- 1 = single period correspondence, 2 = single period to a range of period correspondence
) return number as


v_list_tupr_id coltype_id;
v_range_tupr_id COLTYPE_ID;
v_error_code   number;

begin

if (pi_base_tupr_id_start is null or pi_corr_tupr_id_start is null or  pi_type is null) then


raise_application_error(-20001, '');
else


if (pi_type=1) then

commons_timeunits.get_reverse_correspondence(pi_corr_tupr_id => pi_corr_tupr_id_start,
PI_BASE_TU_ID   => pi_base_tu_id,
pi_corr_tu_id   => pi_corr_tu_id,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => v_error_code,
po_list_tupr_id => v_list_tupr_id);


if (v_list_tupr_id.count<>0 and v_error_code=0) then
for i in 1..v_list_tupr_id.count  loop

if (v_list_tupr_id(i)=pi_base_tupr_id_start) then
RETURN 1;
end if;
end loop;

else

RETURN 0;
end if;


elsif (pi_type=2 and pi_base_tupr_id_end is  not null ) then

v_range_tupr_id:=COMMONS_TIMEUNITS.get_period_range_id_within(pi_tu_id  =>pi_base_tu_id,
pi_tupr_id_start =>pi_base_tupr_id_start,
pi_tupr_id_end  =>pi_base_tupr_id_end);


commons_timeunits.get_reverse_correspondence(pi_corr_tupr_id => pi_corr_tupr_id_start,
PI_BASE_TU_ID   => pi_base_tu_id,
pi_corr_tu_id   => pi_corr_tu_id,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => v_error_code,
po_list_tupr_id => v_list_tupr_id);

if (v_list_tupr_id.count<>0 and v_error_code=0) then




for i in 1..v_range_tupr_id.count  loop

for j in 1..v_list_tupr_id.count  loop

if (v_list_tupr_id(j)=v_range_tupr_id(i)) then
RETURN 1;
end if;

end loop;




end loop;


end if;

elsif (pi_type=3 and pi_corr_tupr_id_end is  not null ) then


v_range_tupr_id:=COMMONS_TIMEUNITS.get_period_range_id_within(pi_tu_id  =>pi_corr_tu_id,
pi_tupr_id_start =>pi_corr_tupr_id_start,
pi_tupr_id_end  =>pi_corr_tupr_id_end);

for i in 1..v_range_tupr_id.count  loop
commons_timeunits.get_reverse_correspondence(pi_corr_tupr_id => v_range_tupr_id(i),
PI_BASE_TU_ID   => pi_base_tu_id,
pi_corr_tu_id   => pi_corr_tu_id,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => v_error_code,
po_list_tupr_id => v_list_tupr_id);

if (v_list_tupr_id.count<>0 and v_error_code=0) then



for j in 1..v_list_tupr_id.count  loop

if (v_list_tupr_id(j)=pi_base_tupr_id_start) then
RETURN 1;
end if;

end loop;

end if;


end loop;







end if ;

end if;

return 0;
exception
WHEN others THEN
RETURN 0;

end get_tupr_rev_Correspondence;


procedure get_prior_period(pi_tu_id      in number,
              pi_tupr_id    in number,
              pi_offset     in number,
              pi_start_year in NUMBER,
              pi_end_year   in NUMBER,
              po_error_code OUT number,
              po_tupr_id    OUT number) as

 v_result          coltype_id;
 v_first_tupr      number;
 v_first_tupr_year number;
 v_diff            number;
 v_flag            number;
 v_no_period       number;
begin

--dbms_output.put_line('test');
 begin
 -- Call the function
 v_result := commons_timeunits.get_period_range_id_within(pi_tu_id         => pi_tu_id,
                              pi_tupr_id_start => null,
                              pi_tupr_id_end   => pi_tupr_id);
exception
 when no_data_found then
  po_error_code := 200;

end;

 --dbms_output.put_line('count=' || v_result.count);
 if (v_result.count <= pi_offset) then

   v_first_tupr := v_result(1);
   v_diff       := pi_offset - v_result.count;
   --dbms_output.put_line('v_first_tupr ='||v_first_tupr);
  --dbms_output.put_line('v_diff ='||v_diff);
   select count(tup_id)
   into v_no_period
   from tu_periods
  where tup_tu_id = pi_tu_id;
  --dbms_output.put_line('v_no_period ='||v_no_period);
   select tupr_year
   into v_first_tupr_year
   from tu_periods_range
  where tupr_id = v_first_tupr;
  --dbms_output.put_line('v_first_tupr_year ='||v_first_tupr_year);
   v_flag := v_first_tupr_year - (v_diff / v_no_period);
   --dbms_output.put_line('v_flag ='||v_flag);
   if (v_flag <= pi_start_year) then
   po_error_code := 200;
   elsif (v_flag > pi_start_year) then
   po_error_code := 300;
   end if;

 else
 /*  for i in 1 .. v_result.count loop
   --dbms_output.put_line(v_result(i));
   end loop;*/
   --dbms_output.put_line('retrun value');
   --dbms_output.put_line(v_result(v_result.count - pi_offset));

   po_tupr_id    := v_result(v_result.count - pi_offset);
   po_error_code := 500;
 end if;
end;


procedure Get_nth_prior_period(pi_tu_id      in number,
              pi_tupr_id    in number,
              pi_offset     in number,
              pi_start_year in NUMBER,
              pi_end_year   in NUMBER,
              po_error_code OUT number,
              po_tupr_id    OUT number) as

 v_result          coltype_id;
 v_position        number;
 v_first_tupr      number;
 v_first_tupr_year number;
 v_diff            number;
 v_flag            number;
 v_no_period       number;
begin

--dbms_output.put_line('test');
 begin
 -- Call the function
select tupr_id bulk collect into v_result
 from (
select  tupr.tupr_id tupr_id, tupr.tupr_start_date tupr_start_date
from tu_periods tp
inner join tu_periods_range tupr
      on tp.tup_id = tupr.tupr_tup_id
where  tp.tup_tu_id=pi_tu_id
order by 2);

exception
 when no_data_found then
  po_error_code := 200;

end;

for i in 1..v_result.count loop
 if(v_result(i)=pi_tupr_id) then
 v_position:=i;
 end if;

end loop;





-- dbms_output.put_line('count=' || v_result.count);
 if (v_position <= pi_offset) then

   v_first_tupr := v_result(1);
  -- v_diff       := pi_offset - v_result.count;
  v_diff       := pi_offset -v_position;
   --dbms_output.put_line('v_first_tupr ='||v_first_tupr);
  --dbms_output.put_line('v_diff ='||v_diff);
   select count(tup_id)
   into v_no_period
   from tu_periods
  where tup_tu_id = pi_tu_id;
  --dbms_output.put_line('v_no_period ='||v_no_period);
   select tupr_year
   into v_first_tupr_year
   from tu_periods_range
  where tupr_id = v_first_tupr;
  --dbms_output.put_line('v_first_tupr_year ='||v_first_tupr_year);
   v_flag := v_first_tupr_year - (v_diff / v_no_period);
   --dbms_output.put_line('v_flag ='||v_flag);
   if (v_flag <= pi_start_year) then
   po_error_code := 200;
   elsif (v_flag > pi_start_year) then
   po_error_code := 300;
   end if;

 else
/*   for i in 1 .. v_result.count loop
   --dbms_output.put_line(v_result(i));
   end loop;*/
   --dbms_output.put_line('retrun value');
   --dbms_output.put_line(v_result(v_position - pi_offset));

   po_tupr_id    := v_result(v_position - pi_offset);
   po_error_code := 500;
 end if;
end;


procedure Get_n_prior_periods(pi_tu_id      in number,
              pi_tupr_id    in number,
              pi_offset     in number,
              po_tupr_id    OUT coltype_id) as

 v_result          coltype_id;
 v_position        number;

 v_counter         number:=1;
begin
po_tupr_id:=coltype_id();

 -- Call the function
select tupr_id bulk collect into v_result
 from (
select  tupr.tupr_id tupr_id, tupr.tupr_start_date tupr_start_date
from tu_periods tp
inner join tu_periods_range tupr
      on tp.tup_id = tupr.tupr_tup_id
where  tp.tup_tu_id=pi_tu_id
order by 2);





for i in 1..v_result.count loop
 if(v_result(i)=pi_tupr_id) then
 v_position:=i;
 exit;
 end if;

end loop;





 --dbms_output.put_line('count=' || v_result.count);
 if (v_position <= pi_offset) then

 for i in 1..v_position-1 loop
   po_tupr_id.extend(1);
   po_tupr_id(i):=v_result(i);
 end loop;

 /*  v_first_tupr := v_result(1);
   v_diff       := pi_offset - v_result.count;
   --dbms_output.put_line('v_first_tupr ='||v_first_tupr);
  --dbms_output.put_line('v_diff ='||v_diff);
   select count(tup_id)
   into v_no_period
   from tu_periods
  where tup_tu_id = pi_tu_id;
  --dbms_output.put_line('v_no_period ='||v_no_period);
   select tupr_year
   into v_first_tupr_year
   from tu_periods_range
  where tupr_id = v_first_tupr;
  --dbms_output.put_line('v_first_tupr_year ='||v_first_tupr_year);
   v_flag := v_first_tupr_year - (v_diff / v_no_period);
   --dbms_output.put_line('v_flag ='||v_flag);
   if (v_flag <= pi_start_year) then
   po_error_code := 200;
   elsif (v_flag > pi_start_year) then
   po_error_code := 300;
   end if;*/

 else
 /*  for i in 1 .. v_result.count loop
   --dbms_output.put_line(v_result(i));
   end loop;*/
   --dbms_output.put_line('retrun value');
   --dbms_output.put_line(v_result(v_result.count - pi_offset));
   for i in (v_position - pi_offset)..v_position-1 loop
   po_tupr_id.extend(1);
   po_tupr_id(v_counter):=v_result(i);
   v_counter:=v_counter+1;
   end loop;
  /* po_tupr_id    := v_result(v_position - pi_offset);
   po_error_code := 500;*/
 end if;
end;


procedure Get_nth_post_period(/*pi_tu_id      in number,*/
                              pi_tupr_id    in number,
                              pi_offset     in number,
                              pi_start_year in NUMBER,
                              pi_end_year   in NUMBER,
                              po_error_code OUT number,
                              po_tupr_id    OUT number) as

  v_result          coltype_id;
  v_position        number;
  v_first_tupr      number;
  v_first_tupr_year number;
  v_diff            number;
  v_flag            number;
  v_tu_id           number;
  v_no_period       number;
begin

select tupr_tu_id into v_tu_id from  tu_periods_range where tupr_id=pi_tupr_id;

  --dbms_output.put_line('test');
  begin
    -- Call the function
    select tupr_id bulk collect
      into v_result
      from (select tupr.tupr_id         tupr_id,
                   tupr.tupr_start_date tupr_start_date
              from tu_periods_range tupr
             where tupr.tupr_tu_id = v_tu_id
             order by 2);

  exception
    ----period is outside of the defined range of years in the system
    when no_data_found then
      po_error_code := 200;

  end;

  --period is outside of the defined range of years in the system
  if (v_result.count < pi_offset) then
    po_error_code := 200;

  else

    for i in 1 .. v_result.count loop
      if (v_result(i) = pi_tupr_id) then
        v_position := i;
        exit;

      end if;

    end loop;

 --dbms_output.put_line('count=' || v_result.count);
    if (v_result.count - v_position < pi_offset) then

      v_first_tupr := v_result(1);
      -- v_diff       := pi_offset - v_result.count;
      v_diff := pi_offset + v_position;
     --dbms_output.put_line('v_first_tupr ='||v_first_tupr);
      --dbms_output.put_line('v_diff ='||v_diff);
      select count(tup_id)
        into v_no_period
        from tu_periods
       where tup_tu_id = v_tu_id;
      --dbms_output.put_line('v_no_period ='||v_no_period);
      select tupr_year
        into v_first_tupr_year
        from tu_periods_range
       where tupr_id = v_first_tupr;
      --dbms_output.put_line('v_first_tupr_year ='||v_first_tupr_year);
      v_flag := v_first_tupr_year + (v_diff / v_no_period)-1;
      --dbms_output.put_line('v_flag ='||v_flag);
      if (v_flag > pi_end_year) then
        po_error_code := 200;
      elsif (v_flag <= pi_end_year) then
        po_error_code := 300;
      end if;

    else
        /* for i in 1 .. v_result.count loop
     dbms_output.put_line(v_result(i));
      end loop;*/
     --dbms_output.put_line('retrun value');
     --dbms_output.put_line(v_result(v_position - pi_offset));

      po_tupr_id    := v_result(v_position + pi_offset);
      po_error_code := 500;
    end if;

  end if;

end;


PROCEDURE GET_RANGE_OF_PERIODS_BOUNDS
(   pi_large_base_tu_id  NUMBER
  ,pi_small_corr_tu_id  NUMBER
  ,pi_date        DATE
  ,pi_range_size      NUMBER
  ,po_fst_tupr_id      OUT NUMBER
  ,po_fst_start_date    OUT DATE
  ,po_fst_end_date    OUT DATE
  ,po_fst_year      OUT NUMBER
  ,po_fst_period_number  OUT NUMBER
  ,po_lst_tupr_id      OUT NUMBER
  ,po_lst_start_date    OUT DATE
  ,po_lst_end_date    OUT DATE
  ,po_lst_year      OUT NUMBER
  ,po_lst_period_number  OUT NUMBER
) AS
  v_bcurr_tupr_id      NUMBER;
  v_bcurr_start_date    DATE;
  v_bcurr_end_date    DATE;
  v_bcurr_year      NUMBER;
  v_bcurr_period_number  NUMBER;
  v_bprior_tupr_id    NUMBER;
  v_bprior_start_date    DATE;
  v_bprior_end_date    DATE;
  v_bprior_year      NUMBER;
  v_bprior_period_number  NUMBER;
BEGIN
  /*  get the current period for pi_large_base_tu_id*/
  GET_CURRENT_PERIOD_BY_DATE
  (   pi_tu_id      => pi_large_base_tu_id
    ,pi_date      => pi_date
    ,po_tupr_id      => v_bcurr_tupr_id
    ,po_start_date    => v_bcurr_start_date
    ,po_end_date    => v_bcurr_end_date
    ,po_year      => v_bcurr_year
    ,po_period_number  => v_bcurr_period_number
  );

  /*  if N = 1 this means we only need one period ago which means that first period = last period
    else calculate which is the bound for N periods ago */
  IF (pi_range_size = 1)
  THEN
    v_bprior_tupr_id    := v_bcurr_tupr_id;
    v_bprior_start_date    := v_bcurr_start_date;
    v_bprior_end_date    := v_bcurr_end_date;
    v_bprior_year      := v_bcurr_year;
    v_bprior_period_number  := v_bcurr_period_number;
  ELSE
    GET_PRIOR_PERIOD_BY_RANGE
    (   pi_tu_id      => pi_large_base_tu_id
      ,pi_year      => v_bcurr_year
      ,pi_period_number  => v_bcurr_period_number
      ,pi_range_size    => pi_range_size
      ,po_tupr_id      => v_bprior_tupr_id
      ,po_start_date    => v_bprior_start_date
      ,po_end_date    => v_bprior_end_date
      ,po_year      => v_bprior_year
      ,po_period_number  => v_bprior_period_number
    );
  END IF;

  /*  if "base" and "corr" timeunits are the same the calculated bounds are the desired result
    else we need to calculate the bounds of the corresponding smaller timeunit based on the bounds of the larger one */
  IF (pi_large_base_tu_id = pi_small_corr_tu_id)
  THEN
    po_fst_tupr_id      := v_bprior_tupr_id;
    po_fst_start_date    := v_bprior_start_date;
    po_fst_end_date      := v_bprior_end_date;
    po_fst_year        := v_bprior_year;
    po_fst_period_number  := v_bprior_period_number;
    po_lst_tupr_id      := v_bcurr_tupr_id;
    po_lst_start_date    := v_bcurr_start_date;
    po_lst_end_date      := v_bcurr_end_date;
    po_lst_year        := v_bcurr_year;
    po_lst_period_number  := v_bcurr_period_number;
  ELSE
    GET_PERIOD_RANGE_BY_CORR
    (   pi_large_base_tu_id  => pi_large_base_tu_id
      ,pi_small_corr_tu_id  => pi_small_corr_tu_id
      ,pi_large_fst_year    => v_bprior_year
      ,pi_large_fst_per_num  => v_bprior_period_number
      ,pi_large_lst_year    => v_bcurr_year
      ,pi_large_lst_per_num  => v_bcurr_period_number
      ,po_fst_tupr_id      => po_fst_tupr_id
      ,po_fst_start_date    => po_fst_start_date
      ,po_fst_end_date    => po_fst_end_date
      ,po_fst_year      => po_fst_year
      ,po_fst_period_number  => po_fst_period_number
      ,po_lst_tupr_id      => po_lst_tupr_id
      ,po_lst_start_date    => po_lst_start_date
      ,po_lst_end_date    => po_lst_end_date
      ,po_lst_year      => po_lst_year
      ,po_lst_period_number  => po_lst_period_number
    );
  END IF;
END GET_RANGE_OF_PERIODS_BOUNDS;


function Get_nth_prior_period(pi_tu_id      in number,
                              pi_tupr_id    in number,
                              pi_offset     in number,
                              pi_start_year in NUMBER,
                              pi_end_year   in NUMBER) return number as

  v_result          coltype_id;
  v_position        number;
  v_first_tupr      number;
  v_first_tupr_year number;
  v_diff            number;
  v_flag            number;
  v_no_period       number;
  v_tupr_id         number;
begin

  --dbms_output.put_line('test');
  begin
    -- Call the function
  /*  select tupr_id bulk collect
      into v_result
      from (select tupr.tupr_id         tupr_id,
                   tupr.tupr_start_date tupr_start_date
              from tu_periods tp
             inner join tu_periods_range tupr
                on tp.tup_id = tupr.tupr_tup_id
             where tp.tup_tu_id = pi_tu_id
             order by 2);*/
    execute immediate 'select tupr_id
      from (select tupr.tupr_id         tupr_id,
                   tupr.tupr_start_date tupr_start_date
              from tu_periods tp
             inner join tu_periods_range tupr
                on tp.tup_id = tupr.tupr_tup_id
             where tp.tup_tu_id = '||pi_tu_id||'
             order by 2)' bulk collect
      into v_result;

  exception
    when no_data_found then
      /* po_error_code := 200;*/
      return - 1;

  end;

  for i in 1 .. v_result.count loop
    if (v_result(i) = pi_tupr_id) then
      v_position := i;
    end if;

  end loop;

  --dbms_output.put_line('count=' || v_result.count);
  if (v_position <= pi_offset) then

    v_first_tupr := v_result(1);
    -- v_diff       := pi_offset - v_result.count;
    v_diff := pi_offset - v_position;
    --dbms_output.put_line('v_first_tupr =' || v_first_tupr);
    --dbms_output.put_line('v_diff =' || v_diff);
    /*select count(tup_id)
      into v_no_period
      from tu_periods
     where tup_tu_id = pi_tu_id;*/
     execute immediate 'select count(tup_id)
      from tu_periods
     where tup_tu_id = '||pi_tu_id
      into v_no_period;
    --dbms_output.put_line('v_no_period =' || v_no_period);
  /*  select tupr_year
      into v_first_tupr_year
      from tu_periods_range
     where tupr_id = v_first_tupr;*/
     execute immediate 'select tupr_year
      from tu_periods_range
     where tupr_id = '||v_first_tupr
      into v_first_tupr_year;
    --dbms_output.put_line('v_first_tupr_year =' || v_first_tupr_year);
    v_flag := v_first_tupr_year - (v_diff / v_no_period);
    --dbms_output.put_line('v_flag =' || v_flag);
    if (v_flag <= pi_start_year) then
      /*po_error_code := 200;*/
      return - 1;
    elsif (v_flag > pi_start_year) then
      /*   po_error_code := 300;*/
      return - 1;
    end if;

  else
   /* for i in 1 .. v_result.count loop
      dbms_output.put_line(v_result(i));
    end loop;*/
    --dbms_output.put_line('retrun value');
    --dbms_output.put_line(v_result(v_result.count - pi_offset));

    v_tupr_id := v_result(v_position - pi_offset);
    /*   po_error_code := 500;*/
    return v_tupr_id;

  end if;

exception
  when others then
    return - 1;
end;


PROCEDURE GET_CORRESPONDENCE_BULK(pi_base_tupr_ids in COLTYPE_ID,
                                  pi_base_tu_id    in NUMBER,
                                  pi_corr_tu_id    in NUMBER,
                                  po_resultset    out sys_refcursor) is
  v_tuc_id NUMBER;
BEGIN



-- if base and corr TU are same
if(pi_base_tu_id=pi_corr_tu_id ) then


open po_resultset for
        SELECT COLUMN_VALUE as BASE_TUPR_ID,
               decode(tupr_id, null, null, COLUMN_VALUE) as CORR_TUPR_ID,
                decode(tupr_id, null, 100, 0) as ERROR_CODE
          from table(pi_base_tupr_ids)
          left outer join tu_periods_range
            on COLUMN_VALUE = tupr_id
         and tupr_tu_id = pi_base_tu_id;

return;



end if;






  --check if input supplied is not null
  if pi_base_tupr_ids is not null and pi_base_tu_id is not null and
     pi_corr_tu_id is not null then

      SELECT max(TUC_ID)
        into v_tuc_id
        from TU_CORRESPONDENCE
       where TUC_TU_ID = pi_base_tu_id
         and TUC_TU_ID_CORR = pi_corr_tu_id;

    if v_tuc_id is null then
      open po_resultset for
        SELECT COLUMN_VALUE as BASE_TUPR_ID,
               null         as CORR_TUPR_ID,
               100          as ERROR_CODE
          from table(pi_base_tupr_ids);

    elsif v_tuc_id is not null then
      open po_resultset for
        WITH  CORRESPONDING_TIME_UNIT AS
         (SELECT distinct TUPR_BASE.TUPR_ID as BASE_TUPR_ID,
                          TUPC_TUP_ID       as BASE_TUP_ID,
                          (SELECT TUPR_ID
                             FROM TU_PERIODS_RANGE
                            WHERE TUPR_TU_ID = pi_corr_tu_id
                              and (NVL(TUPR_TUP_ID, 0) =
                                  TUPC.TUPC_TUP_ID_CORR or
                                  NVL(TUPR_PERIOD_NUMBER, 1) =
                                  TUPC.TUPC_PERIOD_NUMBER_CORR)
                              and TUPR_YEAR = TUPR_BASE.TUPR_YEAR +
                                  (select decode(TUPC.TUPC_YEAR_OFFSET,
                                                             1,
                                                             -1,
                                                             2,
                                                             0,
                                                             3,
                                                             1)
                                                 from dual)) as CORR_TUPR_ID,
                          TUPC_TUP_ID_CORR as CORR_TUP_ID,
                          TUPR_BASE.TUPR_YEAR as BASE_TUPR_YEAR,
                          TUPR_BASE.TUPR_YEAR +
                          (select decode(TUPC.TUPC_YEAR_OFFSET,
                                         1,
                                         -1,
                                         2,
                                         0,
                                         3,
                                         1)
                             from dual) as CORR_TUPR_YEAR,
                          TUC.TUC_ID,
                          TUPC_PERIOD_NUMBER,
                          TUPC_PERIOD_NUMBER_CORR,
                          TUPC_YEAR_OFFSET,
                          TUPC_CORRESPONDENCE_TYPE
            from TU_PERIODS_CORRESPONDENCE TUPC
           inner join TU_CORRESPONDENCE TUC
              on TUPC.TUPC_TUC_ID = TUC.TUC_ID
             and TUPC.TUPC_TUC_ID = v_tuc_id
             AND TUC.TUC_ID is not null

            LEFT OUTER JOIN TU_PERIODS_RANGE TUPR_BASE
              on TUC.TUC_TU_ID = TUPR_BASE.TUPR_TU_ID
             and TUC.TUC_TU_ID = pi_base_tu_id
             and TUPR_BASE.TUPR_ID in
                 (SELECT * FROM TABLE(pi_base_tupr_ids))
             and TUC.TUC_TU_ID is not null
             and TUPR_BASE.TUPR_TUP_ID is not null
             AND CASE
                   WHEN TUPC.TUPC_CORRESPONDENCE_TYPE = 1 AND
                        (NVL(TUPC.TUPC_PERIOD_NUMBER, 0) = TUPR_BASE.TUPR_PERIOD_NUMBER or
                        NVL(TUPC.TUPC_TUP_ID, 1) = NVL(TUPR_BASE.TUPR_TUP_ID, 1)) THEN
                    1
                   WHEN TUPC.TUPC_CORRESPONDENCE_TYPE = 2 AND
                        (NVL(TUPC.TUPC_TUP_ID, 0) = TUPR_BASE.TUPR_TUP_ID or
                        NVL(TUPC.TUPC_PERIOD_NUMBER, 1) =
                        NVL(TUPR_BASE.TUPR_PERIOD_NUMBER, 1)) then
                    1
                   ELSE
                    0
                 END = 1)
        SELECT distinct BASE_TUPR_ID,
                        CORR_TUPR_ID,
                        CASE
                          WHEN TUPC_CORRESPONDENCE_TYPE = 1 THEN
                           (CASE
                             WHEN CORR_TUPR_ID is null and CORR_TUP_ID is null then
                              100
                             WHEN (CORR_TUPR_ID is null) and
                                  (CORR_TUPR_YEAR not between 2010 and 2025) THEN
                              200
                             WHEN (CORR_TUPR_ID is null) and (CORR_TUPR_YEAR between 2010 and 2025) and
                                  not exists (SELECT null
                                     from TU_PERIODS_RANGE
                                    where TUPR_TU_ID = pi_corr_tu_id
                                      and TUPR_YEAR = CORR_TUPR_YEAR) then
                              300
                             WHEN (CORR_TUPR_ID is null) and (CORR_TUPR_YEAR between 2010 and 2025) and
                                  (CORR_TUP_ID is not null) and not exists
                              (SELECT null
                                     from TU_PERIODS_RANGE
                                    WHERE TUPR_TU_ID = pi_corr_tu_id
                                      and TUPR_YEAR = CORR_TUPR_YEAR
                                      and TUPR_TUP_ID = CORR_TUP_ID) then
                              400
                             ELSE
                              0
                           end)
                          WHEN TUPC_CORRESPONDENCE_TYPE = 2 THEN
                           (CASE
                             WHEN (CORR_TUPR_ID is null) and (TUPC_PERIOD_NUMBER_CORR is null) then
                              100
                             WHEN (CORR_TUPR_ID is null) and
                                  (CORR_TUPR_YEAR not between 2010 and 2025) THEN
                              200
                             WHEN (CORR_TUPR_ID is null) and (CORR_TUPR_YEAR between 2010 and 2025) and
                                  not exists (SELECT null
                                     from TU_PERIODS_RANGE
                                    where TUPR_TU_ID = pi_corr_tu_id
                                      and TUPR_YEAR = CORR_TUPR_YEAR) then
                              300
                             WHEN (CORR_TUPR_ID is null) and (CORR_TUPR_YEAR between 2010 and 2025) and
                                  (TUPC_PERIOD_NUMBER_CORR is not null) and not exists
                              (SELECT null
                                     from TU_PERIODS_RANGE
                                    WHERE TUPR_TU_ID = pi_corr_tu_id
                                      and TUPR_YEAR = CORR_TUPR_YEAR
                                      and TUPR_PERIOD_NUMBER = TUPC_PERIOD_NUMBER_CORR) then
                              400
                             ELSE
                              0
                           end)
                        END ERROR_CODE
          FROM CORRESPONDING_TIME_UNIT
         where BASE_TUPR_ID is not null;

    end if;
  end if;
END GET_CORRESPONDENCE_BULK;


FUNCTION GET_CORR_PERIOD_FROM_SMALL_PER
(   pi_small_period_id    IN NUMBER
  ,pi_large_corr_tu_id  IN NUMBER
) RETURN NUMBER
AS
  v_period NUMBER;
BEGIN
  WITH CORR AS
  (  SELECT   TUC_TU_ID          TPR_TU_ID
        ,TP.TUPR_ID          TPR_ID
        ,TP.TUPR_PERIOD_RANGE_NAME  TPR_PERIOD_RANGE_NAME
        ,TP.TUPR_START_DATE      TPR_START_DATE
        ,TP.TUPR_END_DATE      TPR_END_DATE
        ,TP.TUPR_PERIOD_NUMBER    TPR_PERIOD_NUMBER
        ,TP.TUPR_YEAR        TPR_YEAR
        ,TUC_TU_ID_CORR        TPRC_TU_ID
        ,TPC.TUPR_ID        TPRC_ID
        ,TPC.TUPR_PERIOD_RANGE_NAME  TPRC_PERIOD_RANGE_NAME
        ,TPC.TUPR_START_DATE    TPRC_START_DATE
        ,TPC.TUPR_END_DATE      TPRC_END_DATE
        ,TPC.TUPR_PERIOD_NUMBER    TPRC_PERIOD_NUMBER
        ,TPC.TUPR_YEAR        TPRC_YEAR
    FROM    TU_CORRESPONDENCE
        INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
        INNER JOIN TU_PERIODS_RANGE TP ON  (  TUC_TU_ID = TP.TUPR_TU_ID
                          AND  (  (TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC_TUP_ID = TP.TUPR_TUP_ID)
                            OR  (TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPC_PERIOD_NUMBER = TP.TUPR_PERIOD_NUMBER)))
        INNER JOIN TU_PERIODS_RANGE TPC ON  (  TUC_TU_ID_CORR = TPC.TUPR_TU_ID
                          AND  (  (TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC_TUP_ID_CORR = TPC.TUPR_TUP_ID)
                              OR  (TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPC_PERIOD_NUMBER_CORR = TPC.TUPR_PERIOD_NUMBER))
                          AND CASE  WHEN TUPC_YEAR_OFFSET = 1 THEN TP.TUPR_YEAR - 1
                                WHEN TUPC_YEAR_OFFSET = 2 THEN TP.TUPR_YEAR
                                WHEN TUPC_YEAR_OFFSET = 3 THEN TP.TUPR_YEAR + 1
                                ELSE NULL END = TPC.TUPR_YEAR)
  )
  SELECT TPRC_ID
  INTO v_period
  FROM CORR
  WHERE TPR_ID = pi_small_period_id
    AND TPRC_TU_ID = pi_large_corr_tu_id;

  RETURN v_period;
EXCEPTION
WHEN NO_DATA_FOUND THEN
  RAISE_APPLICATION_ERROR(-20001, ',' || GET_TIME_UNIT_NAME_FROM_ID(pi_large_corr_tu_id) || ',' || GET_PERIOD_NAME_FROM_ID(pi_small_period_id));
END;


FUNCTION GET_LAST_PERIOD_FROM_CORR_PER
(   pi_large_corr_period_id  IN NUMBER
  ,pi_small_tu_id        IN NUMBER
) RETURN NUMBER
AS
  v_period NUMBER;
  v_tu_id  NUMBER;
BEGIN
  IF (pi_large_corr_period_id IS NULL) THEN
    RETURN NULL;
  ELSE
    SELECT TUPR_TU_ID INTO v_tu_id
    FROM TU_PERIODS_RANGE WHERE TUPR_ID = pi_large_corr_period_id;

    IF (pi_small_tu_id = v_tu_id)
    THEN
      RETURN pi_large_corr_period_id;
    ELSE
      WITH CORR AS
      (  SELECT   TUC_TU_ID          TPR_TU_ID
            ,TP.TUPR_ID          TPR_ID
            ,TP.TUPR_PERIOD_RANGE_NAME  TPR_PERIOD_RANGE_NAME
            ,TP.TUPR_START_DATE      TPR_START_DATE
            ,TP.TUPR_END_DATE      TPR_END_DATE
            ,TP.TUPR_PERIOD_NUMBER    TPR_PERIOD_NUMBER
            ,TP.TUPR_YEAR        TPR_YEAR
            ,TUC_TU_ID_CORR        TPRC_TU_ID
            ,TPC.TUPR_ID        TPRC_ID
            ,TPC.TUPR_PERIOD_RANGE_NAME  TPRC_PERIOD_RANGE_NAME
            ,TPC.TUPR_START_DATE    TPRC_START_DATE
            ,TPC.TUPR_END_DATE      TPRC_END_DATE
            ,TPC.TUPR_PERIOD_NUMBER    TPRC_PERIOD_NUMBER
            ,TPC.TUPR_YEAR        TPRC_YEAR
        FROM    TU_CORRESPONDENCE
            INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
            INNER JOIN TU_PERIODS_RANGE TP ON  (  TUC_TU_ID = TP.TUPR_TU_ID
                              AND  (  (TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC_TUP_ID = TP.TUPR_TUP_ID)
                                OR  (TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPC_PERIOD_NUMBER = TP.TUPR_PERIOD_NUMBER)))
            INNER JOIN TU_PERIODS_RANGE TPC ON  (  TUC_TU_ID_CORR = TPC.TUPR_TU_ID
                              AND  (  (TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC_TUP_ID_CORR = TPC.TUPR_TUP_ID)
                                  OR  (TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPC_PERIOD_NUMBER_CORR = TPC.TUPR_PERIOD_NUMBER))
                              AND CASE  WHEN TUPC_YEAR_OFFSET = 1 THEN TP.TUPR_YEAR - 1
                                    WHEN TUPC_YEAR_OFFSET = 2 THEN TP.TUPR_YEAR
                                    WHEN TUPC_YEAR_OFFSET = 3 THEN TP.TUPR_YEAR + 1
                                    ELSE NULL END = TPC.TUPR_YEAR)
      )
      SELECT MAX(TPR_ID) KEEP (DENSE_RANK FIRST ORDER BY TPR_START_DATE DESC NULLS LAST)
      INTO v_period
      FROM CORR
      WHERE TPRC_ID = pi_large_corr_period_id
        AND TPR_TU_ID = pi_small_tu_id;

      IF (v_period IS NULL) THEN
         RAISE_APPLICATION_ERROR(-20001, ',' || GET_TIME_UNIT_NAME_FROM_ID(pi_small_tu_id) || ',' || GET_PERIOD_NAME_FROM_ID(pi_large_corr_period_id));
      ELSE
         RETURN v_period;
      END IF;
    END IF;
  END IF;
END;

--
--

FUNCTION GET_FIRST_PERIOD_FROM_CORR_PER
(   pi_large_corr_period_id  IN NUMBER
  ,pi_small_tu_id        IN NUMBER
) RETURN NUMBER
AS
  v_period NUMBER;
  v_tu_id  NUMBER;
BEGIN
  IF (pi_large_corr_period_id IS NULL) THEN
    RETURN NULL;
  ELSE
    SELECT TUPR_TU_ID INTO v_tu_id
    FROM TU_PERIODS_RANGE WHERE TUPR_ID = pi_large_corr_period_id;

    IF (pi_small_tu_id = v_tu_id)
    THEN
      RETURN pi_large_corr_period_id;
    ELSE
      WITH CORR AS
      (  SELECT   TUC_TU_ID          TPR_TU_ID
            ,TP.TUPR_ID          TPR_ID
            ,TP.TUPR_PERIOD_RANGE_NAME  TPR_PERIOD_RANGE_NAME
            ,TP.TUPR_START_DATE      TPR_START_DATE
            ,TP.TUPR_END_DATE      TPR_END_DATE
            ,TP.TUPR_PERIOD_NUMBER    TPR_PERIOD_NUMBER
            ,TP.TUPR_YEAR        TPR_YEAR
            ,TUC_TU_ID_CORR        TPRC_TU_ID
            ,TPC.TUPR_ID        TPRC_ID
            ,TPC.TUPR_PERIOD_RANGE_NAME  TPRC_PERIOD_RANGE_NAME
            ,TPC.TUPR_START_DATE    TPRC_START_DATE
            ,TPC.TUPR_END_DATE      TPRC_END_DATE
            ,TPC.TUPR_PERIOD_NUMBER    TPRC_PERIOD_NUMBER
            ,TPC.TUPR_YEAR        TPRC_YEAR
        FROM    TU_CORRESPONDENCE
            INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
            INNER JOIN TU_PERIODS_RANGE TP ON  (  TUC_TU_ID = TP.TUPR_TU_ID
                              AND  (  (TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC_TUP_ID = TP.TUPR_TUP_ID)
                                OR  (TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPC_PERIOD_NUMBER = TP.TUPR_PERIOD_NUMBER)))
            INNER JOIN TU_PERIODS_RANGE TPC ON  (  TUC_TU_ID_CORR = TPC.TUPR_TU_ID
                              AND  (  (TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC_TUP_ID_CORR = TPC.TUPR_TUP_ID)
                                  OR  (TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPC_PERIOD_NUMBER_CORR = TPC.TUPR_PERIOD_NUMBER))
                              AND CASE  WHEN TUPC_YEAR_OFFSET = 1 THEN TP.TUPR_YEAR - 1
                                    WHEN TUPC_YEAR_OFFSET = 2 THEN TP.TUPR_YEAR
                                    WHEN TUPC_YEAR_OFFSET = 3 THEN TP.TUPR_YEAR + 1
                                    ELSE NULL END = TPC.TUPR_YEAR)
      )
      SELECT MAX(TPR_ID) KEEP (DENSE_RANK FIRST ORDER BY TPR_START_DATE ASC NULLS LAST)
      INTO v_period
      FROM CORR
      WHERE TPRC_ID = pi_large_corr_period_id
        AND TPR_TU_ID = pi_small_tu_id;

      IF (v_period IS NULL) THEN
         RAISE_APPLICATION_ERROR(-20001, ',' || GET_TIME_UNIT_NAME_FROM_ID(pi_small_tu_id) || ',' || GET_PERIOD_NAME_FROM_ID(pi_large_corr_period_id));
      ELSE
         RETURN v_period;
      END IF;
    END IF;
  END IF;
END;

--
--

FUNCTION GET_TIME_UNIT_NAME_FROM_ID(pin_time_unit_id in NUMBER)
RETURN VARCHAR2
AS
V_TIME_UNIT_NAME VARCHAR2(30);
BEGIN
  select tu_name into V_TIME_UNIT_NAME from time_units where tu_id = pin_time_unit_id;
  return V_TIME_UNIT_NAME;
  exception
    when NO_DATA_FOUND then
             RAISE_APPLICATION_ERROR(-20000, 'Invalid time unit ID given to the function');
END;

--
--

FUNCTION GET_PERIOD_NAME_FROM_ID(pin_period_id in NUMBER)
RETURN VARCHAR2
AS
V_PERIOD_NAME VARCHAR2(36);
BEGIN
  select tupr_period_range_name into V_PERIOD_NAME from tu_periods_range where tupr_id = pin_period_id;
  return V_PERIOD_NAME;
  exception
    when NO_DATA_FOUND then
             RAISE_APPLICATION_ERROR(-20000, 'Invalid period ID given to the function');
END;

--
--

FUNCTION GET_TIME_UNIT_NAME_FROM_PERIOD(pin_period_id in NUMBER)
RETURN VARCHAR2
AS
V_TIME_UNIT_NAME VARCHAR2(30);
BEGIN
  select tu.tu_name
    into V_TIME_UNIT_NAME
    from tu_periods_range tupr
   inner join time_units tu
      on tupr.tupr_tu_id = tu.tu_id
   where tupr.tupr_id = pin_period_id;
  return V_TIME_UNIT_NAME;
  exception
    when NO_DATA_FOUND then
             RAISE_APPLICATION_ERROR(-20000, 'Invalid period ID given to the function');
END;


function get_period_start_date (PI_TUPR_ID number) return date as
v_date date;
begin
select max(tupr_start_date) into v_date from tu_periods_range where tupr_id=PI_TUPR_ID;
return v_date;
end get_period_start_date;

function get_period_end_date (PI_TUPR_ID number) return date as
v_date date;
begin
select max(tupr_end_date) into v_date from tu_periods_range where tupr_id=PI_TUPR_ID;
return v_date;
end get_period_end_date;
-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END commons_timeunits;
/
