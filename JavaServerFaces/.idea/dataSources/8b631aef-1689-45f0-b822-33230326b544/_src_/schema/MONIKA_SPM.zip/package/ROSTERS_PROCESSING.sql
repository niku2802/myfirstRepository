CREATE package rosters_processing is
  -- -----------------------------------------------------------------------------
  -- Copyright 2011, SPM Software LP. All Rights Reserved.
  -- This program belongs to SPM Software LP.  It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from SPM Software LP.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   compensation
  -- Module    :  compensation-processing
  -- Requester    :  Obreja, Petru
  -- Author    :  Lazar, Lucian
  -- Reviewer    :  Cozac, Tudor
  -- Review date    :  20110530
  -- Description    :  Used for roster processing. Call in one serializable transaction the functions/procedures in this order:
                         -- update_earnings_roster
                         -- update_payment_roster (only if payment roster exists)
                         -- validate_roster (only if there are validations, once or twice if both rosters exist)
                    -- If the run is issued for selected records then call in one serializable transaction the functions/procedures in this order:
                         -- compensation_processing.create_temporary_roster_table (only if the run is for selected records)
                         -- check_selected_earnings_roster (only if the run is for selected records)
                         -- check_selected_payment_roster (only if the run is for selected records, only if payment roster exists)
                         -- recreate_temp_roster (only if the run is for selected records, once or twice if both rosters exist)
                         -- update_earnings_roster
                         -- update_payment_roster (only if payment roster exists)
                         -- validate_roster (only if there are validations, once or twice if both rosters exist)
                    -- If the run is triggered for selected records from a job then call in one serializable transaction the functions/procedures in this order:
                         -- create_temp_earnings_for_jobs
                         -- create_temp_payment_for_jobs (only if payment roster exists)
                         -- update_earnings_roster
                         -- update_payment_roster (only if payment roster exists)
                         -- validate_roster (only if there are validations, once or twice if both rosters exist)
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC FUNCTIONS START         *******************************

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20120906
  -- Description: Checks if all selected records can be reinserted in the earning roster table
  --              Returns 0 if the check fails and process should be aborted
  --              Returns 1 if the check passes and process should continue
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_table     VARCHAR2  NOT NULL  Name of the earnings entity table
     pi_earning_entity_id        NUMBER    NOT NULL  Id of the earnings entity
     pi_assignment_table         VARCHAR2  NULL      Name of the assignment table
     pi_assignment_entity_table  VARCHAR2  NULL      Name of the assignment entity table
     pi_assignment_entity_id     NUMBER    NULL      Id of the assignment entity
     pi_filter                   VARCHAR2  NULL      Filter on fields from the earnings entity table, assignment table and assignment entity table
     pi_date_filter              VARCHAR2  NULL      Filter on dates or periods effective for the assignment table
     pi_selected_earning_roster  VARCHAR2  NOT NULL  Name of the temporary roster holding selected records from earning roster
     pi_master_roster_table      VARCHAR2  NULL      Name of the master roster table
     pi_plan_id                  NUMBER    NOT NULL  Id of the plan being run
     pi_payment_period_id        NUMBER    NOT NULL  Value for the timeunit column in the roster table
     pi_projected_period_id      NUMBER    NULL      Value for the projected timeunit column in the roster table
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    select
    rosters_processing.check_selected_earnings_roster(pi_earning_entity_table      => 'T764',
                                                      pi_earning_entity_id         => 764,
                                                      pi_assignment_table          => 'T1013',
                                                      pi_assignment_entity_table   => 'T1002',
                                                      pi_assignment_entity_id      => 1001,
                                                      pi_filter                    => '(T764.F999 = ''Iasi'' and T1002.F1000 = 1)',
                                                      pi_date_filter               => '(255 in (select column_value from table(commons_timeunits.get_period_range_id_within(PI_TU_ID => 241,pi_tupr_id_start => T1013.F463,pi_tupr_id_end => T1013.F464))) or
                                                                                      (commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => T1013.F463 , pi_corr_tupr_id_start =>255,  pi_base_tupr_id_end => T1013.F464,pi_corr_tupr_id_end => null,  pi_type => 2)=1) or
                                                                                      (commons_timeunits.get_tupr_correspondence(pi_corr_tupr_id_start => T1013.F463 , pi_base_tupr_id_start =>255,  pi_corr_tupr_id_end => T1013.F464, pi_base_tupr_id_end => null, pi_type => 3)=1) )',
                                                      pi_selected_earning_roster   => 'ER_104',
                                                      pi_master_roster_table       => 'T1016',
                                                      pi_plan_id                   => 1034,
                                                      pi_payment_period_id         => 255,
                                                      pi_projected_period_id       => 256)
    from dual
  */
  -----------------------------------------------------------------------------------------
  function check_selected_earnings_roster(pi_earning_entity_table    in varchar2,
                                          pi_earning_entity_id       in number,
                                          pi_assignment_table        in varchar2,
                                          pi_assignment_entity_table in varchar2,
                                          pi_assignment_entity_id    in number,
                                          pi_filter                  in varchar2,
                                          pi_date_filter             in varchar2,
                                          pi_selected_earning_roster in varchar2,
                                          pi_master_roster_table     in varchar2,
                                          pi_plan_id                 in number,
                                          pi_payment_period_id       in number,
                                          pi_projected_period_id     in number) return number;
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20120906
  -- Description: Checks if all selected records can be reinserted in the payment roster table
  --              Returns 0 if the check fails and process should be aborted
  --              Returns 1 if the check passes and process should continue
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_table       VARCHAR2            NOT NULL  Name of the earnings entity table
     pi_earning_entity_id          NUMBER              NOT NULL  Id of the earnings entity
     pi_payment_assignment_table   VARCHAR2            NULL      Name of the assignment table
     pi_payment_entity_table       VARCHAR2            NULL      Name of the assignment entity table
     pi_payment_entity_id          NUMBER              NULL      Id of the payments entity
     pi_filter                     VARCHAR2            NULL      Filter on fields from the earnings entity table, assignment table and assignment entity table
     pi_date_filter                VARCHAR2            NULL      Filter on dates or periods effective for the assignment table
     pi_selected_payment_roster    VARCHAR2            NOT NULL  Name of the temporary roster holding selected records from payment roster
     pi_earning_roster_table       VARCHAR2            NULL      Name of the earnings entity roster table
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    select
    rosters_processing.check_selected_payment_roster(pi_earning_entity_table      => 'T824',
                                                     pi_earning_entity_id         => 824,
                                                     pi_payment_assignment_table  => 'T875',
                                                     pi_payment_entity_table      => 'T867',
                                                     pi_payment_entity_id         => 867,
                                                     pi_filter                    => '(T824.F1003 = ''Iasi'')',
                                                     pi_date_filter               => '(255 in (select column_value from table(commons_timeunits.get_period_range_id_within(PI_TU_ID => 241,pi_tupr_id_start => T1013.F463,pi_tupr_id_end => T1013.F464))) or
                                                                                    (commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => T1013.F463 , pi_corr_tupr_id_start =>255,  pi_base_tupr_id_end => T1013.F464,pi_corr_tupr_id_end => null,  pi_type => 2)=1) or
                                                                                    (commons_timeunits.get_tupr_correspondence(pi_corr_tupr_id_start => T1013.F463 , pi_base_tupr_id_start =>255,  pi_corr_tupr_id_end => T1013.F464, pi_base_tupr_id_end => null, pi_type => 3)=1) )',
                                                     pi_selected_payment_roster   => 'PR_105',
                                                     pi_earning_roster_table      => 'T1061')
    from dual
  */
  -----------------------------------------------------------------------------------------
  function check_selected_payment_roster(pi_earning_entity_table      in varchar2,
                                         pi_earning_entity_id         in number,
                                         pi_payment_assignment_table  in varchar2,
                                         pi_payment_entity_table      in varchar2,
                                         pi_payment_entity_id         in number,
                                         pi_filter                    in varchar2,
                                         pi_date_filter               in varchar2,
                                         pi_selected_payment_roster   in varchar2,
                                         pi_earning_roster_table      in varchar2) return number;
  -- ========================================================

  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20111129
  -- Description: Recreates the temporary roster table
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_id          NUMBER    NOT NULL  Id of the earnings entity
     pi_payment_entity_id          NUMBER    NULL      Id of the payments entity
     pi_run_id                     NUMBER    NOT NULL  Run id of the process used to get the selected filter and temporary roster from PLAN_RUN_DATA
     pi_selected_earning_roster    VARCHAR2  NOT NULL  Name of the temporary roster holding selected records from earning roster
     pi_selected_payment_roster    VARCHAR2  NOT NULL  Name of the temporary roster holding selected records from payment roster
     pi_roster_table               VARCHAR2  NULL      Name of the roster table
     pi_roster_type                NUMBER    NOT NULL  Type of the roster table (1 - earnings entity roster, 2 - payment to earnings entity roster)
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    rosters_processing.recreate_temp_roster(pi_earning_entity_id         => 764,
                                            pi_payment_entity_id         => 768,
                                            pi_run_id                    => 1024,
                                            pi_selected_earning_roster   => 'ER_104',
                                            pi_selected_payment_roster   => 'PR_105',
                                            pi_roster_table              => 'T1061',
                                            pi_roster_type               => 1);
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     - Java should call the procedure only if the run is for selected records with the earnings entity roster table if only this roster exists
     or with the earnings entity roster table and then with the payment to earnings entity roster table if both rosters exist
  */
  -----------------------------------------------------------------------------------------
  procedure recreate_temp_roster(pi_earning_entity_id         in number,
                                 pi_payment_entity_id         in number,
                                 pi_run_id                    in number,
                                 pi_selected_earning_roster   in varchar2,
                                 pi_selected_payment_roster   in varchar2,
                                 pi_roster_table              in varchar2,
                                 pi_roster_type               in number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110610
  -- Description: Updates the earnings entity roster table
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_table       VARCHAR2            NOT NULL  Name of the earnings entity table
     pi_earning_entity_id          NUMBER              NOT NULL  Id of the earnings entity
     pi_assignment_table           VARCHAR2            NULL      Name of the assignment table
     pi_assignment_entity_table    VARCHAR2            NULL      Name of the assignment entity table
     pi_assignment_entity_id       NUMBER              NOT NULL  Id of the assignment entity
     pi_columns_list               TABLETYPE_NAME_MAP  NOT NULL  Fields from the earnings entity table and assignment entity table included in the roster table; fields should be
                                                                 prefixed with the source table (earnings entity table or assignment entity table) except the entity ids, timeunit,
                                                                 projected, projected timeunit, row identifier and row version; if there are no extra fields in the roster table
                                                                 collection should be empty and not null
     pi_payment_timeunit_column    VARCHAR2            NOT NULL  Name of the timeunit column in the roster table
     pi_projected_timeunit_column  VARCHAR2            NULL      Name of the projected timeunit column in the roster table
     pi_projected_field_column     VARCHAR2            NULL      Name of the projected column in the roster table
     pi_payment_period_id          NUMBER              NOT NULL  Value for the timeunit column in the roster table
     pi_projected_period_id        NUMBER              NULL      Value for the projected timeunit column in the roster table
     pi_projected_field_value      NUMBER              NULL      Value for the projected column in the roster table
     pi_filter                     VARCHAR2            NULL      Filter on fields from the earnings entity table, assignment table and assignment entity table
     pi_date_filter                VARCHAR2            NULL      Filter on dates or periods effective for the assignment table
     pi_run_id                     NUMBER              NOT NULL  Run id of the process used to get the selected flag, filter and temporary roster from PLAN_RUN_DATA
     pi_selected_earning_roster    VARCHAR2            NOT NULL  Name of the temporary roster holding selected records from earning roster
     pi_earning_roster_table       VARCHAR2            NULL      Name of the earnings entity roster table
     pi_master_roster_table        VARCHAR2            NULL      Name of the master roster table
     pi_plan_id                    NUMBER              NOT NULL  Id of the plan being run
     pi_selected_from_job          NUMBER              NULL      Flag for running a plan from Jobs for selected records: 1 - yes, 0 - no
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    rosters_processing.update_earnings_roster(pi_earning_entity_table      => 'T764',
                                              pi_earning_entity_id         => 764,
                                              pi_assignment_table          => 'T1013',
                                              pi_assignment_entity_table   => 'T1002',
                                              pi_assignment_entity_id      => 1002,
                                              pi_columns_list              => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T764','F999'),
                                                                                                 OBJTYPE_NAME_MAP('T1002','F1000')),

                                              pi_payment_timeunit_column   => 'F462',
                                              pi_projected_timeunit_column => null,
                                              pi_projected_field_column    => 'F1001',
                                              pi_payment_period_id         => 255,
                                              pi_projected_period_id       => null,
                                              pi_projected_field_value     => 1,
                                              pi_filter                    => '(T764.F999 = ''Iasi'' and T1002.F1000 = 1)',
                                              pi_date_filter               => '(255 in (select column_value from table(commons_timeunits.get_period_range_id_within(PI_TU_ID => 241,pi_tupr_id_start => T1013.F463,pi_tupr_id_end => T1013.F464))) or
                                                                              (commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => T1013.F463 , pi_corr_tupr_id_start =>255,  pi_base_tupr_id_end => T1013.F464,pi_corr_tupr_id_end => null,  pi_type => 2)=1) or
                                                                              (commons_timeunits.get_tupr_correspondence(pi_corr_tupr_id_start => T1013.F463 , pi_base_tupr_id_start =>255,  pi_corr_tupr_id_end => T1013.F464, pi_base_tupr_id_end => null, pi_type => 3)=1) )',
                                              pi_run_id                    => 1024,
                                              pi_selected_earning_roster   => 'ER_104',
                                              pi_earning_roster_table      => 'T1061',
                                              pi_master_roster_table       => 'T1016',
                                              pi_plan_id                   => 1034,
                                              pi_selected_from_job         => 0);
  */
  -----------------------------------------------------------------------------------------
  procedure update_earnings_roster(pi_earning_entity_table      in varchar2,
                                   pi_earning_entity_id         in number,
                                   pi_assignment_table          in varchar2,
                                   pi_assignment_entity_table   in varchar2,
                                   pi_assignment_entity_id      in number,
                                   pi_columns_list              in TABLETYPE_NAME_MAP,
                                   pi_payment_timeunit_column   in varchar2,
                                   pi_projected_timeunit_column in varchar2,
                                   pi_projected_field_column    in varchar2,
                                   pi_payment_period_id         in number,
                                   pi_projected_period_id       in number,
                                   pi_projected_field_value     in number,
                                   pi_filter                    in varchar2,
                                   pi_date_filter               in varchar2,
                                   pi_run_id                    in number,
                                   pi_selected_earning_roster   in varchar2,
                                   pi_earning_roster_table      in varchar2,
                                   pi_master_roster_table       in varchar2,
                                   pi_plan_id                   in number,
                                   pi_selected_from_job         in number,
                                   po_processed_records         out number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110610
  -- Description: Updates the payment to earnings entity roster table
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_table       VARCHAR2            NOT NULL  Name of the earnings entity table
     pi_earning_entity_id          NUMBER              NOT NULL  Id of the earnings entity
     pi_payment_assignment_table   VARCHAR2            NULL      Name of the assignment table
     pi_payment_entity_table       VARCHAR2            NULL      Name of the assignment entity table
     pi_payment_entity_id          NUMBER              NULL      Id of the payments entity
     pi_columns_list               TABLETYPE_NAME_MAP  NOT NULL  Fields from the earnings entity table and assignment entity table included in the roster table; fields should be
                                                                 prefixed with the source table (earnings entity table or assignment entity table) except the entity ids, timeunit,
                                                                 projected, projected timeunit, row identifier and row version; if there are no extra fields in the roster table
                                                                 collection should be empty and not null
     pi_payment_timeunit_column    VARCHAR2            NOT NULL  Name of the timeunit column in the roster table
     pi_projected_timeunit_column  VARCHAR2            NULL      Name of the projected timeunit column in the roster table
     pi_projected_field_column     VARCHAR2            NULL      Name of the projected column in the roster table
     pi_payment_period_id          NUMBER              NOT NULL  Value for the timeunit column in the roster table
     pi_projected_period_id        NUMBER              NULL      Value for the projected timeunit column in the roster table
     pi_projected_field_value      NUMBER              NULL      Value for the projected column in the roster table
     pi_filter                     VARCHAR2            NULL      Filter on fields from the earnings entity table, assignment table and assignment entity table
     pi_date_filter                VARCHAR2            NULL      Filter on dates or periods effective for the assignment table
     pi_run_id                     NUMBER              NOT NULL  Run id of the process used to get the selected flag, filter and temporary roster from PLAN_RUN_DATA
     pi_selected_payment_roster    VARCHAR2            NOT NULL  Name of the temporary roster holding selected records from payment roster
     pi_earning_roster_table       VARCHAR2            NULL      Name of the earnings entity roster table
     pi_payment_roster_table       VARCHAR2            NOT NULL  Name of the payment to earnings entity roster table
     pi_selected_from_job          NUMBER              NULL      Flag for running a plan from Jobs for selected records: 1 - yes, 0 - no
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    rosters_processing.update_payment_roster(pi_earning_entity_table      => 'T824',
                                             pi_earning_entity_id         => 824,
                                             pi_payment_assignment_table  => 'T875',
                                             pi_payment_entity_table      => 'T867',
                                             pi_payment_entity_id         => 867,
                                             pi_columns_list              => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T824','F1003'),
                                                                                                OBJTYPE_NAME_MAP('T867','F1005')),
                                             pi_payment_timeunit_column   => 'F462',
                                             pi_projected_timeunit_column => null,
                                             pi_projected_field_column    => 'F999',
                                             pi_payment_period_id         => 255,
                                             pi_projected_period_id       => null,
                                             pi_projected_field_value     => 1,
                                             pi_filter                    => '(T824.F1003 = ''Iasi'')',
                                             pi_date_filter               => '(255 in (select column_value from table(commons_timeunits.get_period_range_id_within(PI_TU_ID => 241,pi_tupr_id_start => T1013.F463,pi_tupr_id_end => T1013.F464))) or
                                                                            (commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => T1013.F463 , pi_corr_tupr_id_start =>255,  pi_base_tupr_id_end => T1013.F464,pi_corr_tupr_id_end => null,  pi_type => 2)=1) or
                                                                            (commons_timeunits.get_tupr_correspondence(pi_corr_tupr_id_start => T1013.F463 , pi_base_tupr_id_start =>255,  pi_corr_tupr_id_end => T1013.F464, pi_base_tupr_id_end => null, pi_type => 3)=1) )',
                                             pi_run_id                    => 1026,
                                             pi_selected_payment_roster   => 'PR_105',
                                             pi_earning_roster_table      => 'T1061',
                                             pi_payment_roster_table      => 'T1064',
                                             pi_selected_from_job         => 0);
  */
  -----------------------------------------------------------------------------------------
  procedure update_payment_roster(pi_earning_entity_table      in varchar2,
                                  pi_earning_entity_id         in number,
                                  pi_payment_assignment_table  in varchar2,
                                  pi_payment_entity_table      in varchar2,
                                  pi_payment_entity_id         in number,
                                  pi_columns_list              in TABLETYPE_NAME_MAP,
                                  pi_payment_timeunit_column   in varchar2,
                                  pi_projected_timeunit_column in varchar2,
                                  pi_projected_field_column    in varchar2,
                                  pi_payment_period_id         in number,
                                  pi_projected_period_id       in number,
                                  pi_projected_field_value     in number,
                                  pi_filter                    in varchar2,
                                  pi_date_filter               in varchar2,
                                  pi_run_id                    in number,
                                  pi_selected_payment_roster   in varchar2,
                                  pi_earning_roster_table      in varchar2,
                                  pi_payment_roster_table      in varchar2,
                                  pi_selected_from_job         in number,
                                  po_processed_records         out number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110830
  -- Description: Performs the Roster validations
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_column       VARCHAR2  NOT NULL  Name of the earning entity column in the roster table
     pi_payment_entity_column       VARCHAR2  NULL      Name of the payment entity column in the roster table, not null for a payment to earnings entity roster table
     pi_payment_prior_period_id     NUMBER    NULL      Prior value for the timeunit column or projected timeunit column in the roster table if the plan has projected payments
     pi_roster_table                VARCHAR2  NOT NULL  Name of the earnings entity roster table or payment to earnings entity roster table (if this roster exists)
     pi_prior_roster_table          VARCHAR2  NOT NULL  Name of the earnings entity roster table or payment to earnings entity roster table from prior run (if this roster exists)
     pi_selected_roster_table       VARCHAR2  NULL      Name of the temporary earnings entity roster table or temporary payment to earnings entity roster table (if this roster exists)
                                                        if the plan is being run for selected records
     pi_added_validation            NUMBER    NOT NULL  Flag for performing the added earning or payment entities validation (1 or 0)
     pi_removed_validation          NUMBER    NOT NULL  Flag for performing the removed earning or payment  entities validation (1 or 0)
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_validations_results  CURSOR  Cursor with two columns (VALIDATION, ENTITY) containing the records that failed the required validations
                                     - if there are no records for the prior period and the validations are skipped: VALIDATION = 0, ENTITY = null
                                     - if the validations are performed: VALIDATION = 1 (Earning entity added) or 2 (Earning entity removed) or 3 (Payment entity added)
                                       or 4 (Payment entity removed), ENTITY = entity id's that fail the validation
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     - Java should call the procedure with the earnings entity roster table if only this roster exists or with the earnings entity roster table and then
       with the payment to earnings entity roster table if both rosters exist
     - at least one of pi_added_validation or pi_removed_validation should be 1
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    rosters_processing.validate_roster(pi_earning_entity_column => 'E864',
                                       pi_payment_entity_column => 'E865',
                                       pi_payment_prior_period_id => 267,
                                       pi_roster_table => 'T5013',
                                       pi_prior_roster_table => 'T5010',
                                       pi_selected_roster_table => 'T5013_sel',
                                       pi_added_validation => 1,
                                       pi_removed_validation => 1,
                                       po_validations_results => :po_validations_results);
  */
  -----------------------------------------------------------------------------------------
  procedure validate_roster(pi_earning_entity_column      in varchar2,
                            pi_payment_entity_column      in varchar2,
                            pi_payment_prior_period_id    in number,
                            pi_roster_table               in varchar2,
                            pi_prior_roster_table         in varchar2,
                            pi_selected_roster_table      in varchar2,
                            pi_added_validation           in number,
                            pi_removed_validation         in number,
                            po_validations_results        out sys_refcursor);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20140401
  -- Description: Creates the temporary earnings roster table at the beginning of the processing
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_table       VARCHAR2            NOT NULL  Name of the earnings entity table
     pi_earning_entity_id          NUMBER              NOT NULL  Id of the earnings entity
     pi_assignment_table           VARCHAR2            NULL      Name of the assignment table
     pi_assignment_entity_table    VARCHAR2            NULL      Name of the assignment entity table
     pi_assignment_entity_id       NUMBER              NOT NULL  Id of the assignment entity
     pi_columns_list               TABLETYPE_NAME_MAP  NOT NULL  Fields from the earnings entity table and assignment entity table included in the roster table; fields should be
                                                                 prefixed with the source table (earnings entity table or assignment entity table) except the entity ids, timeunit,
                                                                 projected, projected timeunit, row identifier and row version; if there are no extra fields in the roster table
                                                                 collection should be empty and not null
     pi_payment_timeunit_column    VARCHAR2            NOT NULL  Name of the timeunit column in the roster table
     pi_projected_timeunit_column  VARCHAR2            NULL      Name of the projected timeunit column in the roster table
     pi_projected_field_column     VARCHAR2            NULL      Name of the projected column in the roster table
     pi_payment_period_id          NUMBER              NOT NULL  Value for the timeunit column in the roster table
     pi_projected_period_id        NUMBER              NULL      Value for the projected timeunit column in the roster table
     pi_projected_field_value      NUMBER              NULL      Value for the projected column in the roster table
     pi_filter                     VARCHAR2            NULL      Filter on fields from the earnings entity table, assignment table and assignment entity table
     pi_date_filter                VARCHAR2            NULL      Filter on dates or periods effective for the assignment table
     pi_run_id                     NUMBER              NOT NULL  Run id of the process used to get the selected flag, filter and temporary roster from PLAN_RUN_DATA
     pi_earning_roster_table       VARCHAR2            NULL      Name of the earnings entity roster table
     pi_master_roster_table        VARCHAR2            NULL      Name of the master roster table
     pi_plan_id                    NUMBER              NOT NULL  Id of the plan being run
     pi_temp_earnings_roster_table VARCHAR2            NOT NULL  Name of the temporary earnings entity roster table that is created by this procedure
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    rosters_processing.create_temp_earnings_for_jobs(pi_earning_entity_table       => 'T764',
                                                     pi_earning_entity_id          => 764,
                                                     pi_assignment_table           => 'T1013',
                                                     pi_assignment_entity_table    => 'T1002',
                                                     pi_assignment_entity_id       => 1002,
                                                     pi_columns_list               => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T764','F999'),
                                                                                                         OBJTYPE_NAME_MAP('T1002','F1000')),
                                                     pi_payment_timeunit_column    => 'F462',
                                                     pi_projected_timeunit_column  => null,
                                                     pi_projected_field_column     => 'F1001',
                                                     pi_payment_period_id          => 255,
                                                     pi_projected_period_id        => null,
                                                     pi_projected_field_value      => 1,
                                                     pi_filter                     => '(T764.F999 = ''Iasi'' and T1002.F1000 = 1)',
                                                     pi_date_filter                => '(255 in (select column_value from table(commons_timeunits.get_period_range_id_within(PI_TU_ID => 241,pi_tupr_id_start => T1013.F463,pi_tupr_id_end => T1013.F464))) or
                                                                                      (commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => T1013.F463 , pi_corr_tupr_id_start =>255,  pi_base_tupr_id_end => T1013.F464,pi_corr_tupr_id_end => null,  pi_type => 2)=1) or
                                                                                      (commons_timeunits.get_tupr_correspondence(pi_corr_tupr_id_start => T1013.F463 , pi_base_tupr_id_start =>255,  pi_corr_tupr_id_end => T1013.F464, pi_base_tupr_id_end => null, pi_type => 3)=1) )',
                                                     pi_run_id                     => 1024,
                                                     pi_earning_roster_table       => 'T1061',
                                                     pi_master_roster_table        => 'T1016',
                                                     pi_plan_id                    => 1034,
                                                     pi_temp_earnings_roster_table => 'ER_104');
  */
  -----------------------------------------------------------------------------------------
  procedure create_temp_earnings_for_jobs(pi_earning_entity_table       in varchar2,
                                          pi_earning_entity_id          in number,
                                          pi_assignment_table           in varchar2,
                                          pi_assignment_entity_table    in varchar2,
                                          pi_assignment_entity_id       in number,
                                          pi_columns_list               in TABLETYPE_NAME_MAP,
                                          pi_payment_timeunit_column    in varchar2,
                                          pi_projected_timeunit_column  in varchar2,
                                          pi_projected_field_column     in varchar2,
                                          pi_payment_period_id          in number,
                                          pi_projected_period_id        in number,
                                          pi_projected_field_value      in number,
                                          pi_run_id                     in number,
                                          pi_earning_roster_table       in varchar2,
                                          pi_master_roster_table        in varchar2,
                                          pi_plan_id                    in number,
                                          pi_temp_earnings_roster_table in varchar2);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20140401
  -- Description: Creates the temporary payment roster table at the beginning of the processing
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_earning_entity_table       VARCHAR2            NOT NULL  Name of the earnings entity table
     pi_earning_entity_id          NUMBER              NOT NULL  Id of the earnings entity
     pi_payment_assignment_table   VARCHAR2            NULL      Name of the assignment table
     pi_payment_entity_table       VARCHAR2            NULL      Name of the assignment entity table
     pi_payment_entity_id          NUMBER              NULL      Id of the payments entity
     pi_columns_list               TABLETYPE_NAME_MAP  NOT NULL  Fields from the earnings entity table and assignment entity table included in the roster table; fields should be
                                                                 prefixed with the source table (earnings entity table or assignment entity table) except the entity ids, timeunit,
                                                                 projected, projected timeunit, row identifier and row version; if there are no extra fields in the roster table
                                                                 collection should be empty and not null
     pi_payment_timeunit_column    VARCHAR2            NOT NULL  Name of the timeunit column in the roster table
     pi_projected_timeunit_column  VARCHAR2            NULL      Name of the projected timeunit column in the roster table
     pi_projected_field_column     VARCHAR2            NULL      Name of the projected column in the roster table
     pi_payment_period_id          NUMBER              NOT NULL  Value for the timeunit column in the roster table
     pi_projected_period_id        NUMBER              NULL      Value for the projected timeunit column in the roster table
     pi_projected_field_value      NUMBER              NULL      Value for the projected column in the roster table
     pi_filter                     VARCHAR2            NULL      Filter on fields from the earnings entity table, assignment table and assignment entity table
     pi_date_filter                VARCHAR2            NULL      Filter on dates or periods effective for the assignment table
     pi_run_id                     NUMBER              NOT NULL  Run id of the process used to get the selected flag, filter and temporary roster from PLAN_RUN_DATA
     pi_temp_earnings_roster_table VARCHAR2            NOT NULL  Name of the temporary earnings entity roster table
     pi_payment_roster_table       VARCHAR2            NOT NULL  Name of the payment to earnings entity roster table
     pi_temp_payment_roster_table  VARCHAR2            NOT NULL  Name of the temporary payment entity roster table that is created by this procedure
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    rosters_processing.create_temp_payment_for_jobs(pi_earning_entity_id          => 824,
                                                    pi_payment_assignment_table   => 'T875',
                                                    pi_payment_entity_table       => 'T867',
                                                    pi_payment_entity_id          => 867,
                                                    pi_columns_list               => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T824','F1003'),
                                                                                                        OBJTYPE_NAME_MAP('T867','F1005')),
                                                    pi_payment_timeunit_column    => 'F462',
                                                    pi_projected_timeunit_column  => null,
                                                    pi_projected_field_column     => 'F999',
                                                    pi_payment_period_id          => 255,
                                                    pi_projected_period_id        => null,
                                                    pi_projected_field_value      => 1,
                                                    pi_run_id                     => 1026,
                                                    pi_temp_earnings_roster_table => 'ER_105',
                                                    pi_payment_roster_table       => 'T1064',
                                                    pi_temp_payment_roster_table  => 'PR_105');
  */
  -----------------------------------------------------------------------------------------
  procedure create_temp_payment_for_jobs(pi_earning_entity_id          in number,
                                         pi_payment_assignment_table   in varchar2,
                                         pi_payment_entity_table       in varchar2,
                                         pi_payment_entity_id          in number,
                                         pi_columns_list               in TABLETYPE_NAME_MAP,
                                         pi_payment_timeunit_column    in varchar2,
                                         pi_projected_timeunit_column  in varchar2,
                                         pi_projected_field_column     in varchar2,
                                         pi_payment_period_id          in number,
                                         pi_projected_period_id        in number,
                                         pi_projected_field_value      in number,
                                         pi_run_id                     in number,
                                         pi_temp_earnings_roster_table in varchar2,
                                         pi_payment_roster_table       in varchar2,
                                         pi_temp_payment_roster_table  in varchar2);
  -- ========================================================

  procedure check_earnings_roster(pi_earning_entity_table      in varchar2,
                                  pi_earning_entity_id         in number,
                                  pi_assignment_table          in varchar2,
                                  pi_assignment_entity_table   in varchar2,
                                  pi_assignment_entity_id      in number,
                                  pi_projected_timeunit_column in varchar2,
                                  pi_payment_period_id         in number,
                                  pi_projected_period_id       in number,
                                  pi_filter                    in varchar2,
                                  pi_date_filter               in varchar2,
                                  pi_master_roster_table       in varchar2,
                                  pi_plan_id                   in number,
                                  po_records_exist            out number);

  procedure check_payment_roster(pi_earning_entity_table      in varchar2,
                                 pi_earning_entity_id         in number,
                                 pi_payment_assignment_table  in varchar2,
                                 pi_payment_entity_table      in varchar2,
                                 pi_payment_entity_id         in number,
                                 pi_filter                    in varchar2,
                                 pi_date_filter               in varchar2,
                                 pi_earning_roster_table      in varchar2,
                                 po_records_exist            out number);

-- *******************************    PUBLIC PROCEDURES END         *******************************

end rosters_processing;
/
