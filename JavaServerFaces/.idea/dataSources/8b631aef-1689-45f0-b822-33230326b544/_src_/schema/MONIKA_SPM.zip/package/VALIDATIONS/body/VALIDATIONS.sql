CREATE PACKAGE BODY VALIDATIONS AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: COMPENSATION
-- Module			: COMPENSATION-PROCESSING
-- Description		: All validations related items.
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************

/*	GET_PREV_FROM_STRING START */
FUNCTION GET_PREV_FROM_STRING
(	 pin_curr_table_alias	IN VARCHAR2
	,pin_entity_cols		IN TABLETYPE_NAME_MAP
	,pin_prior_tables		IN TCOL_PRIOR_TABLES
) RETURN CLOB
IS
	v_tab_indx				PLS_INTEGER;
	v_col_indx				PLS_INTEGER;
	v_join_col_list			CLOB;
	v_join_sql				CLOB;
BEGIN
	v_tab_indx := pin_prior_tables.FIRST;
	WHILE (v_tab_indx IS NOT NULL)
	LOOP
		/*	build the join column list I.E10 = VLD_PP1.E10 and I.E45 = VLD_PP1.E45 ...*/
		v_join_col_list := NULL;
		v_col_indx := pin_entity_cols.FIRST;
		WHILE (v_col_indx IS NOT NULL)
		LOOP
			v_join_col_list := v_join_col_list
				||'('||pin_curr_table_alias||'.'||pin_entity_cols(v_col_indx).NAME1||' = VLD_PP'||TO_CHAR(v_tab_indx)||'.'||pin_entity_cols(v_col_indx).NAME1
				||' OR ('||pin_curr_table_alias||'.'||pin_entity_cols(v_col_indx).NAME1||' IS NULL AND VLD_PP'||TO_CHAR(v_tab_indx)||'.'||pin_entity_cols(v_col_indx).NAME1||' IS NULL))'
				||' AND ';

			v_col_indx := pin_entity_cols.NEXT(v_col_indx);
		END LOOP;

		/*	get rid of the last " AND " at the end of the string */
		v_join_col_list := SUBSTR(v_join_col_list, 1, LENGTH(v_join_col_list) - 5);

		v_join_sql := v_join_sql || '
		LEFT JOIN '
			|| CASE	WHEN pin_prior_tables(v_tab_indx).WHERE_CLAUSE IS NOT NULL
					THEN '(SELECT * FROM ' || pin_prior_tables(v_tab_indx).TABLE_NAME
						|| ' WHERE ' || pin_prior_tables(v_tab_indx).WHERE_CLAUSE || ')'
					ELSE pin_prior_tables(v_tab_indx).TABLE_NAME END
			|| ' VLD_PP' || TO_CHAR(v_tab_indx) || ' ON ' || v_join_col_list;

		v_tab_indx := pin_prior_tables.NEXT(v_tab_indx);
	END LOOP;

	RETURN v_join_sql;
END GET_PREV_FROM_STRING;


/*	GET_TARGET_FROM_STRING START */
FUNCTION GET_TARGET_FROM_STRING
(	 pin_curr_table_alias	IN VARCHAR2
	,pin_entity_cols		IN TABLETYPE_NAME_MAP
	,pin_target_table		IN OBJTYPE_INPUT_TABLE_LIST
	,pin_target_agg_type	IN NUMBER
) RETURN CLOB
IS
	v_indx					PLS_INTEGER;
	v_trgt_select_col_list	CLOB;
	v_trgt_join_col_list	CLOB;
	v_trgt_agg_function		CLOB;
	v_join_sql				CLOB;
BEGIN
	/*	compute the columns list in the join and select clauses */
	v_indx := pin_entity_cols.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		v_trgt_select_col_list := v_trgt_select_col_list || pin_entity_cols(v_indx).NAME1 || ',';

		v_trgt_join_col_list := v_trgt_join_col_list
			||'('||pin_curr_table_alias||'.'||pin_entity_cols(v_indx).NAME1||' = VLD_TRGT.'||pin_entity_cols(v_indx).NAME1
			||' OR ('||pin_curr_table_alias||'.'||pin_entity_cols(v_indx).NAME1||' IS NULL AND VLD_TRGT.'||pin_entity_cols(v_indx).NAME1||' IS NULL))'
			||' AND ';

		v_indx := pin_entity_cols.NEXT(v_indx);
	END LOOP;

	v_trgt_select_col_list := SUBSTR(v_trgt_select_col_list, 1, LENGTH(v_trgt_select_col_list) - 1);
	v_trgt_join_col_list := SUBSTR(v_trgt_join_col_list, 1, LENGTH(v_trgt_join_col_list) - 5);

	v_trgt_agg_function := CASE pin_target_agg_type
			WHEN 1 THEN 'SUM(TARGET_EARNINGS) TARGET_EARNINGS'
			WHEN 2 THEN 'AVG(TARGET_EARNINGS) TARGET_EARNINGS'
			WHEN 3 THEN 'MIN(TARGET_EARNINGS) KEEP (DENSE_RANK FIRST ORDER BY DETAILED_EARNINGS ASC NULLS LAST) TARGET_EARNINGS'
			WHEN 4 THEN 'MAX(TARGET_EARNINGS) KEEP (DENSE_RANK FIRST ORDER BY DETAILED_EARNINGS DESC NULLS LAST) TARGET_EARNINGS'
			ELSE NULL END;

	IF (v_trgt_agg_function IS NOT NULL)
	THEN
		v_join_sql := '
		LEFT JOIN
		(	SELECT ' || v_trgt_select_col_list || ',' || v_trgt_agg_function || '
			FROM ' || pin_target_table.TABLE_NAME
			|| CASE	WHEN pin_target_table.WHERE_CLAUSE IS NOT NULL THEN '
			WHERE ' || pin_target_table.WHERE_CLAUSE
					ELSE NULL END || '
			GROUP BY ' || v_trgt_select_col_list || '
		) VLD_TRGT ON ' || v_trgt_join_col_list;
	ELSE
		v_join_sql := '
		LEFT JOIN '
			|| CASE	WHEN pin_target_table.WHERE_CLAUSE IS NOT NULL
					THEN '(SELECT * FROM ' || pin_target_table.TABLE_NAME
						|| ' WHERE ' || pin_target_table.WHERE_CLAUSE || ')'
					ELSE pin_target_table.TABLE_NAME END
			|| ' VLD_TRGT ON ' || v_trgt_join_col_list;
	END IF;

	RETURN v_join_sql;
END GET_TARGET_FROM_STRING;


/*	GET_ROW_ID_COLUMNS_STRING START */
FUNCTION GET_ROW_ID_COLUMNS_STRING
(	pin_entity_cols		IN TABLETYPE_NAME_MAP
) RETURN CLOB
IS
	v_indx				PLS_INTEGER;
	v_column_id			PLS_INTEGER;
	v_insert_col_list	CLOB;
BEGIN
	v_column_id := 1;
	v_indx := pin_entity_cols.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		v_insert_col_list := v_insert_col_list || ',C' || TO_CHAR(v_column_id);
		v_column_id := v_column_id + 1;

		v_indx := pin_entity_cols.NEXT(v_indx);
	END LOOP;

	IF (LENGTH(v_insert_col_list) >= 2)
	THEN
		v_insert_col_list := SUBSTR(v_insert_col_list, 2, LENGTH(v_insert_col_list));
	END IF;

	RETURN v_insert_col_list;
END GET_ROW_ID_COLUMNS_STRING;


/*	GET_ROW_ID_VALUES_STRING START */
FUNCTION GET_ROW_ID_VALUES_STRING
(	pin_entity_cols		IN TABLETYPE_NAME_MAP
) RETURN CLOB
IS
	v_indx				PLS_INTEGER;
	v_insert_val_list	CLOB;
BEGIN
	v_indx := pin_entity_cols.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		v_insert_val_list := v_insert_val_list || ','
			|| CASE	WHEN pin_entity_cols(v_indx).NAME2 IS NOT NULL THEN pin_entity_cols(v_indx).NAME2
					ELSE pin_entity_cols(v_indx).NAME1 END;

		v_indx := pin_entity_cols.NEXT(v_indx);
	END LOOP;

	IF (LENGTH(v_insert_val_list) >= 2)
	THEN
		v_insert_val_list := SUBSTR(v_insert_val_list, 2, LENGTH(v_insert_val_list));
	END IF;

	RETURN v_insert_val_list;
END GET_ROW_ID_VALUES_STRING;


/*	GET_ENT_ID_COLUMNS_STRING START */
FUNCTION GET_ENT_ID_COLUMNS_STRING
(	pin_entity_cols		IN TABLETYPE_NAME_MAP
) RETURN CLOB
IS
	v_indx				PLS_INTEGER;
	v_column_id			PLS_INTEGER;
	v_get_vld_col_list	CLOB;
BEGIN
	v_column_id := 1;
	v_indx := pin_entity_cols.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		/*  ||','||'"'||C2||'"'  */
		v_get_vld_col_list := v_get_vld_col_list || '||'',''||''"''||C' || TO_CHAR(v_column_id) || '||''"''';
		v_column_id := v_column_id + 1;

		v_indx := pin_entity_cols.NEXT(v_indx);
	END LOOP;

	IF (LENGTH(v_get_vld_col_list) >= 8)
	THEN
		v_get_vld_col_list := SUBSTR(v_get_vld_col_list, 8, LENGTH(v_get_vld_col_list));
	END IF;

	RETURN v_get_vld_col_list;
END GET_ENT_ID_COLUMNS_STRING;


/*	GET_WHEN_STRING START */
FUNCTION GET_WHEN_STRING
(	 pin_validation_def		IN OBJTYPE_VALIDATION_DEF
	,pin_insert_col_list	IN CLOB
	,pin_insert_val_list	IN CLOB
) RETURN CLOB
IS
	v_insert_sql 			CLOB;
BEGIN
	v_insert_sql := '
		WHEN VALIDATION' || pin_validation_def.ID || ' = 1 THEN INTO TEMP_UI_VALIDATION_VALUES (VALIDATION_ID, ' || pin_insert_col_list || ') '
			|| 'VALUES (' || pin_validation_def.ID || ', ' || pin_insert_val_list || ')';

	RETURN v_insert_sql;
END GET_WHEN_STRING;


/*	GET_SELECT_STRING START */
FUNCTION GET_SELECT_STRING
(	 pin_validation_def		IN OBJTYPE_VALIDATION_DEF
	,pin_curr_val			IN VARCHAR2
	,pin_prior_val			IN VARCHAR2
	,pin_trgt_val			IN VARCHAR2
	,pin_avg_val			IN VARCHAR2
) RETURN CLOB
IS
	v_select_sql 			CLOB;
	v_condition				VARCHAR(2000);
BEGIN
	v_condition := CASE pin_validation_def.COMPARISON_CONDITION
					WHEN 0 THEN ' > '
					WHEN 1 THEN ' >= '
					WHEN 2 THEN ' < '
					WHEN 3 THEN ' <= '
					ELSE NULL END;

	/*	if value_of_column >,>=,<,<= condition_value */
	IF (pin_validation_def.VALUE_TO_VALIDATE = 0)
	THEN
		v_select_sql := '
		,CASE	WHEN '	|| pin_curr_val
						|| v_condition
						|| TO_CHAR(pin_validation_def.COMPARISON_VALUE)	|| ' THEN 1
				ELSE 0 END VALIDATION' || pin_validation_def.ID;

	/*	if change in value_of_column >,>=,<,<= condition_value */
	ELSIF (pin_validation_def.VALUE_TO_VALIDATE = 1)
	THEN
		v_select_sql := '
		,CASE	WHEN '	|| pin_prior_val || ' IS NOT NULL AND '
						|| '(' || pin_curr_val || ' - ' || pin_prior_val || ')'
						|| v_condition
						|| TO_CHAR(pin_validation_def.COMPARISON_VALUE) || ' THEN 1
				ELSE 0 END VALIDATION' || pin_validation_def.ID;

	/*	if percent change in value_of_column >,>=,<,<= condition_value */
	ELSIF (pin_validation_def.VALUE_TO_VALIDATE = 2)
	THEN
		v_select_sql := '
		,CASE	WHEN '	|| pin_prior_val || ' = 0 AND ' || pin_curr_val || ' = 0'
						|| CASE	WHEN v_condition = ' > ' AND 0 > TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								WHEN v_condition = ' >= ' AND 0 >= TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								WHEN v_condition = ' < ' AND 0 < TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								WHEN v_condition = ' <= ' AND 0 <= TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								ELSE ' THEN 0' END || '
				WHEN '	|| pin_prior_val || ' = 0 AND ' || pin_curr_val || ' > 0'
						|| CASE	WHEN v_condition IN (' > ',' >= ') THEN ' THEN 1'
								ELSE ' THEN 0' END || '
				WHEN '	|| pin_prior_val || ' = 0 AND ' || pin_curr_val || ' < 0'
						|| CASE	WHEN v_condition IN (' < ',' <= ') THEN ' THEN 1'
								ELSE ' THEN 0' END || '
				WHEN '	|| pin_prior_val || ' IS NOT NULL AND ' || pin_prior_val || ' <> 0 AND '
						|| '(' || pin_curr_val || ' - ' || pin_prior_val || ') * 100 / ABS(' || pin_prior_val || ')'
						|| v_condition
						|| TO_CHAR(pin_validation_def.COMPARISON_VALUE)	|| ' THEN 1
				ELSE 0 END VALIDATION' || pin_validation_def.ID;

	/*	if value_of_column percent of target >,>=,<,<= condition_value */
	ELSIF (pin_validation_def.VALUE_TO_VALIDATE = 3)
	THEN
		v_select_sql := '
		,CASE	WHEN '	|| pin_trgt_val || ' = 0 AND ' || pin_curr_val || ' = 0'
						|| CASE	WHEN v_condition = ' > ' AND 0 > TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								WHEN v_condition = ' >= ' AND 0 >= TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								WHEN v_condition = ' < ' AND 0 < TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								WHEN v_condition = ' <= ' AND 0 <= TO_CHAR(pin_validation_def.COMPARISON_VALUE) THEN ' THEN 1'
								ELSE ' THEN 0' END || '
				WHEN '	|| pin_trgt_val || ' = 0 AND ' || pin_curr_val || ' > 0'
						|| CASE	WHEN v_condition IN (' > ',' >= ') THEN ' THEN 1'
								ELSE ' THEN 0' END || '
				WHEN '	|| pin_trgt_val || ' = 0 AND ' || pin_curr_val || ' < 0'
						|| CASE	WHEN v_condition IN (' < ',' <= ') THEN ' THEN 1'
								ELSE ' THEN 0' END || '
				WHEN '	|| pin_trgt_val || ' <> 0 AND '
						|| pin_curr_val || ' * 100 / ' || pin_trgt_val
						|| v_condition
						|| TO_CHAR(pin_validation_def.COMPARISON_VALUE)	|| ' THEN 1
				ELSE 0 END VALIDATION' || pin_validation_def.ID;

	/*	if value_of_column minus average value >,>=,<,<= condition_value */
	ELSIF (pin_validation_def.VALUE_TO_VALIDATE = 4)
	THEN
		v_select_sql := '
		,CASE	WHEN '	|| '(' || pin_curr_val || ' - ' || pin_avg_val || ')'
						|| v_condition
						|| TO_CHAR(pin_validation_def.COMPARISON_VALUE) || ' THEN 1
				ELSE 0 END VALIDATION' || pin_validation_def.ID;
	END IF;

	RETURN v_select_sql;
END GET_SELECT_STRING;


/*	GET_VLD_STRING START */
FUNCTION GET_VLD_STRING
(	 pin_validation_def		IN OBJTYPE_VALIDATION_DEF
) RETURN CLOB
IS
	v_vld_sql 				CLOB;
	v_severity				VARCHAR2(2000);
BEGIN
	v_severity := CASE pin_validation_def.SEVERITY
					WHEN 0 THEN '''WARNING'''
					WHEN 1 THEN '''ERROR'''
					ELSE NULL END;

	/*	any records */
	IF (pin_validation_def.TRIGGER_CONDITION_TYPE = 0)
	THEN
		v_vld_sql := '
		WHEN VALIDATION_ID = ' || pin_validation_def.ID
			|| ' AND ENTITIES_TRG > 0 THEN ' || v_severity;

	/*	<value> or more records */
	ELSIF (pin_validation_def.TRIGGER_CONDITION_TYPE = 1)
	THEN
		v_vld_sql := '
		WHEN VALIDATION_ID = ' || pin_validation_def.ID
			|| ' AND ENTITIES_TRG >= ' || TO_CHAR(pin_validation_def.TRIGGER_CONDITION_VALUE) || ' THEN ' || v_severity;

	/*	<value>% of records */
	ELSIF (pin_validation_def.TRIGGER_CONDITION_TYPE = 2)
	THEN
		v_vld_sql := '
		WHEN VALIDATION_ID = ' || pin_validation_def.ID
			|| ' AND ((ENTITIES_TRG * 100) / ENTITIES_ALL) >= ' || TO_CHAR(pin_validation_def.TRIGGER_CONDITION_VALUE) || ' THEN ' || v_severity;
	END IF;

	RETURN v_vld_sql;
END GET_VLD_STRING;

-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************

/*	PREPARE_PREREQUISITES START */
PROCEDURE PREPARE_PREREQUISITES
(	 pin_prior_tables			IN TABLETYPE_INPUT_TABLE_LIST
	,pin_prior_values_cols		IN TABLETYPE_ID_NAME
    ,pio_validation_defs		IN OUT NOCOPY TABLETYPE_VALIDATION_DEF
	,pout_prior_tables			OUT TCOL_PRIOR_TABLES
    ,pout_prior_values_cols		OUT TCOL_PRIOR_VALUES_COLS
) IS
	v_indx					PLS_INTEGER;
	v_indx2					PLS_INTEGER;
	v_indx_new				PLS_INTEGER;
    v_indx_prior            PLS_INTEGER;
    v_col_name              VARCHAR2(200 CHAR);
    vrec_prior_table        TREC_PRIOR_TABLE;
    v_prior_values_cols     TABLETYPE_ID_NAME;
BEGIN
	/*	java collections start from 0, Oracle starts from 1;
		because in pio_validation_defs we reference prior_tables by index, we have to add 1 in order to match;
        the same is for pin_prior_values_cols; */
	v_indx := pio_validation_defs.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		pio_validation_defs(v_indx).PRIOR_TABLE_ID := pio_validation_defs(v_indx).PRIOR_TABLE_ID + 1;
		v_indx := pio_validation_defs.NEXT(v_indx);
	END LOOP;

    v_prior_values_cols := pin_prior_values_cols;
    v_indx := v_prior_values_cols.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		v_prior_values_cols(v_indx).ID := v_prior_values_cols(v_indx).ID + 1;
		v_indx := v_prior_values_cols.NEXT(v_indx);
	END LOOP;

    /*	remove the duplicates in prior period tables;
		loop through each prior table sent by Java in "pin_prior_tables" and insert only distinct elements
		into the new collection "vtab_prior_tables";
		this is to avoid multiple joins with the same period data; */
	v_indx_prior := 1;
	v_indx := pin_prior_tables.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
		/*	check to see if there is any element in the distinct collection
			that matches the current loop table */
		v_indx_new := NULL;
		v_indx2 := pout_prior_tables.FIRST;
		WHILE (v_indx2 IS NOT NULL)
		LOOP
			IF (	NVL(pin_prior_tables(v_indx).TABLE_NAME, 'NULL') = NVL(pout_prior_tables(v_indx2).TABLE_NAME, 'NULL')
				AND	NVL(pin_prior_tables(v_indx).WHERE_CLAUSE, 'NULL') = NVL(pout_prior_tables(v_indx2).WHERE_CLAUSE, 'NULL'))
			THEN
				/*	a match has been found - all defs that reference the old "pin_prior_tables"
					will now be switched to the index of the corresponding unique table from "vtab_prior_tables" */
				v_indx_new := v_indx2;
			END IF;

			v_indx2 := pout_prior_tables.NEXT(v_indx2);
		END LOOP;

		/*	if no match has been found than we have to insert this table into the new collection */
		IF (v_indx_new IS NULL)
		THEN
			vrec_prior_table.TABLE_NAME     := pin_prior_tables(v_indx).TABLE_NAME;
            vrec_prior_table.WHERE_CLAUSE   := pin_prior_tables(v_indx).WHERE_CLAUSE;
            pout_prior_tables(v_indx_prior) := vrec_prior_table;

            /* and we need to get the column_name*/
            BEGIN
                SELECT NAME INTO v_col_name FROM TABLE(v_prior_values_cols) WHERE ID = v_indx;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
                raise_application_error(-20001, 'No prior values column name was found for table with index: '||TO_CHAR(v_indx));
            WHEN OTHERS THEN
                RAISE;
            END;
            pout_prior_values_cols(v_indx_prior) := v_col_name;

			/*	again, all defs that reference this table will have to point to the index of the new coll*/
			v_indx_new := v_indx_prior;
            v_indx_prior := v_indx_prior + 1;
		END IF;

		/*	update validation defs to point to the index of the table from the new collection */
		v_indx2 := pio_validation_defs.FIRST;
		WHILE (v_indx2 IS NOT NULL)
		LOOP
			IF (pio_validation_defs(v_indx2).PRIOR_TABLE_ID = v_indx)
			THEN
				pio_validation_defs(v_indx2).PRIOR_TABLE_ID := v_indx_new;
			END IF;

			v_indx2 := pio_validation_defs.NEXT(v_indx2);
		END LOOP;

		v_indx := pin_prior_tables.NEXT(v_indx);
	END LOOP;
END PREPARE_PREREQUISITES;


/*	GET_VALIDATIONS_VALUES START */
PROCEDURE GET_VALIDATIONS_VALUES
(	 pin_validation_defs		IN TABLETYPE_VALIDATION_DEF
	,pin_curr_table_alias		IN VARCHAR2
	,pin_curr_values_col		IN VARCHAR2
	,pin_entity_cols			IN TABLETYPE_NAME_MAP
	,pin_prior_tables			IN TABLETYPE_INPUT_TABLE_LIST
	,pin_prior_values_col		IN TABLETYPE_ID_NAME
	,pin_target_table			IN OBJTYPE_INPUT_TABLE_LIST
	,pin_target_agg_type		IN NUMBER
	,pout_vld_when				OUT CLOB
	,pout_vld_select			OUT CLOB
	,pout_vld_from				OUT CLOB
	,pout_vld_get_values		OUT CLOB
) IS
	vtab_validation_defs	TABLETYPE_VALIDATION_DEF;
	vtab_prior_tables		TCOL_PRIOR_TABLES;
    vtab_prior_values_cols  TCOL_PRIOR_VALUES_COLS;
	v_indx					PLS_INTEGER;
	v_trgt_val				VARCHAR2(2000);
	v_curr_val				VARCHAR2(2000);
	v_prior_val				VARCHAR2(2000);
	v_avg_val				VARCHAR2(2000);
	v_insert_col_list		CLOB;
	v_insert_val_list		CLOB;
	v_get_vld_col_list		CLOB;
	v_insert_sql			CLOB;
	v_select_sql			CLOB;
	v_join_sql				CLOB;
	v_get_vld_sql			CLOB;
	v_stamp					VARCHAR2(250);
BEGIN
	v_stamp := 'VALIDATIONS.GET_VALIDATIONS_VALUES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

	/*	log input parameters */
	BEGIN
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_validation_defs),	',pin_validation_defs => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_curr_table_alias),	',pin_curr_table_alias => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_curr_values_col),	',pin_curr_values_col => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_entity_cols),		',pin_entity_cols => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_prior_tables),	',pin_prior_tables => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_prior_values_col),',pin_prior_values_col => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_target_table),		',pin_target_table => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_target_agg_type),		',pin_target_agg_type => <value>', v_stamp);
	END;

    vtab_validation_defs := pin_validation_defs;

    PREPARE_PREREQUISITES(	 pin_prior_tables		=> pin_prior_tables
                            ,pin_prior_values_cols  => pin_prior_values_col
                            ,pio_validation_defs	=> vtab_validation_defs
                            ,pout_prior_tables		=> vtab_prior_tables
                            ,pout_prior_values_cols => vtab_prior_values_cols);

	/*	build the JOIN clause that will allign the previous periods to the current period;
		one LEFT JOIN for each previous period:
		LEFT JOIN (SELECT * FROM T100200 WHERE F10 = 10) VLD_PP1 ON T100200.E10 = VLD_PP1.E10 AND T100200.E20 = VLD_PP1.E20
		LEFT JOIN (SELECT * FROM T100200 WHERE F10 = 9) VLD_PP3 ON T100200.E10 = VLD_PP3.E10 AND T100200.E20 = VLD_PP1.E20 */
	v_join_sql := GET_PREV_FROM_STRING(	 pin_curr_table_alias	=> pin_curr_table_alias
										,pin_entity_cols		=> pin_entity_cols
										,pin_prior_tables		=> vtab_prior_tables);

	/*	finish the JOIN clause with the target table if this is necessary */
	IF (pin_target_table IS NOT NULL)
	THEN
		v_join_sql := v_join_sql || GET_TARGET_FROM_STRING(	 pin_curr_table_alias	=> pin_curr_table_alias
															,pin_entity_cols		=> pin_entity_cols
															,pin_target_table		=> pin_target_table
															,pin_target_agg_type	=> pin_target_agg_type);
	END IF;

	/*	compute the list of columns which identify a row - to be inserted into the TEMP_UI_VALIDATION_VALUES */
	v_insert_col_list := GET_ROW_ID_COLUMNS_STRING(pin_entity_cols => pin_entity_cols);
	v_insert_val_list := GET_ROW_ID_VALUES_STRING(pin_entity_cols => pin_entity_cols);
	v_get_vld_col_list := GET_ENT_ID_COLUMNS_STRING(pin_entity_cols => pin_entity_cols);

	v_curr_val := pin_curr_table_alias || '.' || pin_curr_values_col;
	v_avg_val := '(AVG(' || pin_curr_table_alias || '.' || pin_curr_values_col || ') OVER())';
	IF (pin_target_table IS NOT NULL)
	THEN
		v_trgt_val := 'VLD_TRGT.TARGET_EARNINGS';
	ELSE
		v_trgt_val := pin_curr_table_alias || '.TARGET_EARNINGS';
	END IF;

	v_indx := vtab_validation_defs.FIRST;
	WHILE (v_indx IS NOT NULL)
	LOOP
        IF (vtab_validation_defs(v_indx).PRIOR_TABLE_ID IS NOT NULL)
        THEN
		    v_prior_val := 'VLD_PP' || TO_CHAR(vtab_validation_defs(v_indx).PRIOR_TABLE_ID) || '.' || vtab_prior_values_cols(vtab_validation_defs(v_indx).PRIOR_TABLE_ID);
		END IF;

		/*	build the INSERT ALL clause to save the rows that meet the validation conditions
			WHEN VALIDATION1 = 1 THEN INTO TEMP_UI_VALIDATION_VALUES (VALIDATION_ID, C1) VALUES (1, F10)
			WHEN VALIDATION2 = 1 THEN INTO TEMP_UI_VALIDATION_VALUES (VALIDATION_ID, C1) VALUES (2, F10) ...*/
		v_insert_sql := v_insert_sql || GET_WHEN_STRING( pin_validation_def		=> vtab_validation_defs(v_indx)
														,pin_insert_col_list	=> v_insert_col_list
														,pin_insert_val_list	=> v_insert_val_list);

		/*	build the SELECT list which puts 1 if the row meets a validation condition, or 0 otherwise
			,CASE WHEN curr.AGGREGATED_EARNINGS > 500 THEN 1 ELSE 0 END VALIDATION1
			,CASE WHEN ABS(curr_alias.AGGREGATED_EARNINGS - VLD_PP2.AGGREGATED_EARNINGS) > 200 THEN 1 ELSE 0 END VALIDATION2 */
		v_select_sql := v_select_sql || GET_SELECT_STRING(	 pin_validation_def	=> vtab_validation_defs(v_indx)
															,pin_curr_val		=> v_curr_val
															,pin_prior_val		=> v_prior_val
															,pin_trgt_val		=> v_trgt_val
															,pin_avg_val		=> v_avg_val);

		/*	build the string to get the triggered validations from PLAN_VALIDATION_RESULTS
			WHEN VALIDATION_ID = 1 AND COUNT(*) >= 100 THEN 'WARNING'
			WHEN VALIDATION_ID = 2 AND ((COUNT(*) * 100) / TOTAL_ROWCOUNT) >=  THEN 'ERROR' ...*/
		v_get_vld_sql := v_get_vld_sql || GET_VLD_STRING(pin_validation_def	=> vtab_validation_defs(v_indx));

		v_indx := vtab_validation_defs.NEXT(v_indx);
	END LOOP;

	pout_vld_when		:= v_insert_sql;
	pout_vld_select		:= v_select_sql;
	pout_vld_from		:= v_join_sql;
	pout_vld_get_values	:= CASE	WHEN v_get_vld_sql IS NOT NULL THEN '
		SELECT
			 VALIDATION_ID
			,VALIDATION_TYPE
			,VALIDATION_ENT_CNT
			,CAST(MULTISET	(SELECT ' || v_get_vld_col_list || '
							FROM TEMP_UI_VALIDATION_VALUES I
							WHERE I.VALIDATION_ID = O.VALIDATION_ID
								AND ROWNUM <= 1000
							) AS TABLETYPE_CHARMAX) VALIDATION_DETAILS
		FROM
			(SELECT
				 VALIDATION_ID
				,ENTITIES_TRG VALIDATION_ENT_CNT
				,CASE	' || v_get_vld_sql || '
						ELSE NULL END VALIDATION_TYPE
			FROM
				(SELECT
					 VALIDATION_ID
					,COUNT(*) ENTITIES_TRG
					,:v_current_period_count ENTITIES_ALL
				FROM TEMP_UI_VALIDATION_VALUES
				GROUP BY VALIDATION_ID
				)
			) O
		WHERE VALIDATION_TYPE IS NOT NULL'
								ELSE NULL END;

	/*	log output parameters */
	BEGIN
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_vld_when),			',pout_vld_when => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_vld_select),		',pout_vld_select => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_vld_from),			',pout_vld_from => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_vld_get_values),	',pout_vld_get_values => <value>', v_stamp);
	END;
EXCEPTION
WHEN OTHERS THEN
	L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
	RAISE;
END GET_VALIDATIONS_VALUES;


/*	GET_VALIDATIONS_RESULTS START */
PROCEDURE GET_VALIDATIONS_RESULTS
(	 pin_vld_query		IN CLOB
	,pin_curr_rowcount	IN NUMBER
	,pout_vld_results	OUT SYS_REFCURSOR
) IS
	v_stamp				VARCHAR2(250);
BEGIN
	v_stamp := 'VALIDATIONS.GET_VALIDATIONS_RESULTS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_vld_query),			',pin_vld_query => <value>', v_stamp);
	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_curr_rowcount),	',pin_curr_rowcount => <value>', v_stamp);

	OPEN pout_vld_results FOR pin_vld_query
	USING pin_curr_rowcount;
EXCEPTION
WHEN OTHERS THEN
	L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
	RAISE;
END GET_VALIDATIONS_RESULTS;

-- *******************************    PUBLIC PROCEDURES END         *******************************
END VALIDATIONS;
/
