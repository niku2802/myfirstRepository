CREATE PACKAGE COMMONS_INDEXING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : tables-commons
  -- Requester      : Pooja Sharma
  -- Author         : Hardika Bhate, Shriniket Pimparkar
  -- Create date    : 20130115
  -- Reviewer       : Maxim Rohit
  -- Review date    : 20130220
  -- Description    : package used to handle all operations for indexes
  --ls
  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************

  TYPE TYPE_INDEX_NAME IS TABLE OF USER_INDEXES.INDEX_NAME%TYPE INDEX BY PLS_INTEGER;

  TYPE TYPE_CONSTRAINT_NAME IS TABLE OF USER_CONSTRAINTS.CONSTRAINT_NAME%TYPE INDEX BY PLS_INTEGER;

  TYPE TYPE_INDEX_DDL_COMP IS RECORD(
    DDL_STMT   CLOB,
    INDEX_NAME VARCHAR2(50));

  TYPE TYPE_INDEX_DDL_INFO IS TABLE OF TYPE_INDEX_DDL_COMP; -- INDEX BY PLS_INTEGER; -- 11.JUL.2013
  TYPE TYPE_INDEX_DDL_COMPOSITE IS TABLE OF TYPE_INDEX_DDL_COMP INDEX BY PLS_INTEGER;

  TYPE TYPE_CONSTRAINT_DDL_COMP IS RECORD(
    DDL_STMT   CLOB,
    CONST_NAME VARCHAR2(50));

  TYPE TYPE_CONSTRAINT_DDL_COMPOSITE IS TABLE OF TYPE_CONSTRAINT_DDL_COMP INDEX BY PLS_INTEGER;

  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  FUNCTION GET_INDEX_TABLESPACE(PI_TABLES_ID IN NUMBER) RETURN VARCHAR2;

  /*FUNCTION GET_COVERING_INDEX_1(PI_TABLE_NAME  IN VARCHAR2,
                                PI_COLUMN_LIST IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION CREATE_CLOB(PI_TABLE_NAME      IN VARCHAR2,
                       PI_INDEX_NAME      IN VARCHAR2,
                       PI_COL_LIST        IN VARCHAR2,
                       PI_BUSINESS_NAME   IN VARCHAR2,
                       PI_IS_PRIMARY_KEY  IN NUMBER,
                       PI_UNIQUENESS      IN NUMBER,
                       PI_TABLESPACE_NAME IN VARCHAR2,
                       PI_RUN_ID          IN NUMBER DEFAULT NULL)
    RETURN VARCHAR2;

  FUNCTION UPDATE_CLOB(PI_TABLE_NAME      IN VARCHAR2,
                       PI_INDEX_NAME      IN VARCHAR2,
                       PI_COL_LIST        IN VARCHAR2,
                       PI_BUSINESS_NAME   IN VARCHAR2,
                       PI_IS_PRIMARY_KEY  IN NUMBER,
                       PI_UNIQUENESS      IN NUMBER,
                       PI_TABLESPACE_NAME IN VARCHAR2,
                       PI_RUN_ID          IN NUMBER DEFAULT NULL)
    RETURN VARCHAR2;*/

  FUNCTION CREATE_CLOB2(PI_TABLE_NAME      IN VARCHAR2,
                        PI_INDEX_NAME      IN VARCHAR2,
                        PI_COL_LIST        IN VARCHAR2,
                        PI_BUSINESS_NAME   IN VARCHAR2,
                        PI_IS_PRIMARY_KEY  IN NUMBER,
                        PI_UNIQUENESS      IN NUMBER,
                        PI_TABLESPACE_NAME IN VARCHAR2,
                        PI_RUN_ID          IN NUMBER DEFAULT NULL,
                        PI_TRANSACTION_ID  IN VARCHAR2) RETURN CLOB;

  FUNCTION UPDATE_CLOB2(PI_TABLE_NAME      IN VARCHAR2,
                        PI_INDEX_NAME      IN VARCHAR2,
                        PI_COL_LIST        IN VARCHAR2,
                        PI_BUSINESS_NAME   IN VARCHAR2,
                        PI_IS_PRIMARY_KEY  IN NUMBER,
                        PI_UNIQUENESS      IN NUMBER,
                        PI_TABLESPACE_NAME IN VARCHAR2,
                        PI_RUN_ID          IN NUMBER DEFAULT NULL,
                        PI_TRANSACTION_ID  IN VARCHAR2) RETURN VARCHAR2;
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  PROCEDURE CREATE_INDEX(PI_TABLE_NAME        IN VARCHAR2,
                         PI_INDEX_NAME        IN VARCHAR2,
                         PI_COLUMN_LIST       IN SYS.HSBLKNAMLST,
                         PI_UNIQUENESS        IN NUMBER,
                         PI_COL_IS_PRIMARYKEY IN NUMBER,
                         PI_INITRANS          IN NUMBER DEFAULT 5,
                         PI_INDEX_TABLESPACE  IN VARCHAR2,
                         PI_RUN_ID            IN NUMBER DEFAULT NULL,
                         PI_TRANSACTION_ID    IN VARCHAR2,
                         PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded, 5 - Invalid Identifier
                         PO_INDEX_NAME        OUT VARCHAR2,
                         PO_IS_UNIQUE         OUT VARCHAR2);

  PROCEDURE CREATE_INDEX1(PI_TABLE_NAME        IN VARCHAR2,
                          PI_INDEX_NAME        IN VARCHAR2,
                          PI_COL_LIST          IN SYS.HSBLKNAMLST,
                          PI_UNIQUENESS        IN NUMBER,
                          PI_COL_IS_PRIMARYKEY IN NUMBER,
                          PI_INITRANS          IN NUMBER DEFAULT 5,
                          PI_INDEX_TABLESPACE  IN VARCHAR2,
                          PI_RUN_ID            IN NUMBER DEFAULT NULL,
                          PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded, 5 - Invalid Identifier
                          PO_INDEX_NAME        OUT VARCHAR2,
                          PO_IS_UNIQUE         OUT VARCHAR2,
                          PO_CREATE_DDL        OUT CLOB);

  PROCEDURE INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID              IN NUMBER,
                                        PI_INDEX_NAME                 IN VARCHAR2,
                                        PI_TABLE_NAME                 IN VARCHAR2,
                                        PI_COLUMN_LIST                IN COLTYPE_INDEXED_COLUMNS_LIST,
                                        PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                        PI_BUSINESS_NAME              IN VARCHAR2,
                                        PI_IS_UNIQUE                  IN NUMBER,
                                        PI_INDEX_TYPE                 IN NUMBER);

  PROCEDURE INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              IN NUMBER,
                                         PI_INDEX_NAME                 IN VARCHAR2,
                                         PI_TABLE_NAME                 IN VARCHAR2,
                                         PI_COLUMN_LIST                IN COLTYPE_INDEXED_COLUMNS_LIST,
                                         PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                         PI_BUSINESS_NAME              IN VARCHAR2,
                                         PI_IS_UNIQUE                  IN NUMBER,
                                         PI_INDEX_TYPE                 IN NUMBER,
                                         PI_INDEX_INSERT_DDL           IN CLOB,
                                         PI_IS_PRIMARY                 IN NUMBER DEFAULT NULL);

  PROCEDURE CREATE_CORE_INDEXES(PI_TABLES_ID                 IN NUMBER,
                                PI_RUN_ID                    IN NUMBER DEFAULT NULL,
                                pi_process_id                IN NUMBER DEFAULT NULL,
                                PI_TABLE_NAME                IN VARCHAR2,
                                PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX,
                                PI_INDEX_TABLESPACE          IN NUMBER,
                                PI_TRANSACTION_ID            IN VARCHAR2,
                                PO_LOG_MSG                   OUT VARCHAR2);
  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : RENAME_INDEX
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Index Name, unique id (Rownum of the index from DELETE_INDEXES SP) ,process_id and run id
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Renames the index to IDX_<unique id>_<process id>_<run id>
  *                     and any constraint associated with it to CON_<unique id>_<process id>_<run id>
  * Example           :
  BEGIN
    COMMONS_INDEXING.RENAME_INDEX(PK_T3126,1,123456,45678);
  END;

  Renames the index PK_T3126 to IDX_1_123456_45678 and constraint associated with  PK_T3126 to CON_1_123456_45678
  *********************************************************************************************************************/
  PROCEDURE RENAME_INDEX(PI_INDEX_NAME     IN VARCHAR2,
                         PI_UNIQUE_ID      IN NUMBER DEFAULT NULL,
                         PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                         PI_RUN_ID         IN NUMBER DEFAULT NULL,
                         PI_TRANSACTION_ID IN VARCHAR2,
                         PI_NEW_INDEX_NAME IN VARCHAR2 DEFAULT NULL);

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DELETE_INDEXES
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, process_id and run id
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Renames the indexes to <index_name>_BKP  and any constraint associated with it to <constraint_name>_BKP
  * Example           :
  BEGIN
    COMMONS_INDEXING.DELETE_INDEXES(3126);
  END;

  Renames the indexes of table T3126 by calling RENAME_INDEX procedure
  *********************************************************************************************************************/

  PROCEDURE DELETE_INDEXES(PI_TABLE_NAME     IN VARCHAR2,
                           PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                           PI_RUN_ID         IN NUMBER DEFAULT NULL,
                           PI_TRANSACTION_ID IN VARCHAR2,
                           PO_LOG_MSG        OUT VARCHAR2);

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : UPDATE_INDEXES
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, process_id and run id
  * OUTPUT PARAMETERS : po_log_msg
  * DESCRIPTION       : Updates the indexes
  * Example           :
  BEGIN
    COMMONS_INDEXING.UPDATE_INDEXES(3126, po_log_msg);
  END;

  If TABLE T3126 has an additional entity column which is added after creating the table, this column is indexed.
  Same applies for TUPR  columns.
  If key columns are no longer valid, the concatenated index already present on the previous key columns is dropped
  and new index is created for the new key columns.
  *********************************************************************************************************************/

  PROCEDURE UPDATE_INDEXES(PI_TABLES_ID                 IN NUMBER,
                           PI_PROCESS_ID                IN NUMBER DEFAULT NULL,
                           PI_RUN_ID                    IN NUMBER DEFAULT NULL,
                           PI_TRANSACTION_ID            IN VARCHAR2,
                           PI_TABLE_NAME                IN VARCHAR2,
                           PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX, --sales change
                           PI_INDEX_TABLESPACE          IN NUMBER,
                           PI_RENAMED_INDEX_NAME        IN VARCHAR2, --sales change
                           PO_LOG_MSG                   OUT VARCHAR2);

  PROCEDURE UPDATE_CORE_INDEXES(PI_TABLES_ID                 IN NUMBER,
                                PI_PROCESS_ID                IN NUMBER DEFAULT NULL,
                                PI_RUN_ID                    IN NUMBER DEFAULT NULL,
                                PI_TABLE_NAME                IN VARCHAR2,
                                PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX,
                                PI_INDEX_TABLESPACE          IN VARCHAR2,
                                PI_TRANSACTION_ID            IN VARCHAR2,
                                PI_RENAME_INDX_NAME          IN VARCHAR2, --sales change
                                PO_RENAMED_BK_INDEX_NAME     OUT VARCHAR2,
                                PO_LOG_MSG                   OUT VARCHAR2);

  PROCEDURE UPDATE_APP_INDEX(PI_TABLE_NAME         IN VARCHAR2,
                             PI_RENAMED_INDEX_NAME IN VARCHAR2,
                             PI_TRANSACTION_ID     IN VARCHAR2,
                             -- PI_INDEX_UPDATE_MODE determines whether update happens from UPDATE_INDEXES call
                             -- or DELETE_APP_INDEXES call
                             PI_INDEX_UPDATE_MODE  IN NUMBER, --1 - Update_indexes 2. DELETE_APP_INDEXES
                             PI_DELETED_INDEX_NAME IN VARCHAR2,
                             PI_TABLESPACE_NAME    IN VARCHAR2,
                             PI_RUN_ID             IN NUMBER DEFAULT NULL,
                             PI_TABLES_ID          IN NUMBER);

  PROCEDURE CREATE_APP_INDEX(PI_TABLES_ID                  IN NUMBER,
                             PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                             PI_IS_UNIQUE                  IN NUMBER,
                             PI_DEF_ID                     IN NUMBER,
                             PI_BUSINESS_NAME              IN VARCHAR2,
                             PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                             PI_PROCESS_ID                 IN NUMBER DEFAULT NULL,
                             PI_RUN_ID                     IN NUMBER DEFAULT NULL,
                             PI_TABLE_NAME                 IN VARCHAR2, --sales change
                             PI_TRANSACTION_ID             IN VARCHAR2, --sales change
                             PI_INDEX_TABLESPACE_NAME      IN VARCHAR2, --sales change
                             PO_INDEX_CREATION_STATUS      OUT NUMBER);

  PROCEDURE DELETE_APP_INDEX(PI_TABLES_ID             IN NUMBER,
                             PI_DEF_ID                IN NUMBER,
                             PI_BUSINESS_NAME         IN VARCHAR2,
                             PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                             PI_RUN_ID                IN NUMBER DEFAULT NULL,
                             PI_TABLE_NAME            IN VARCHAR2,
                             PI_INDEX_TABLESPACE_NAME IN VARCHAR2,
                             PI_TRANSACTION_ID        IN VARCHAR2);
  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DISABLE_ALL_INDEXES
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, Process_Id (Optional), Run_Id (Optional)
  * OUTPUT PARAMETERS : PO_LOG_MSG
  * DESCRIPTION       : Disables ALL Non-Unique Indexes and Drops ALL Unique Indexes including Primary Key
  * Example           :

  BEGIN
    COMMONS_INDEXING.DISABLE_ALL_INDEXES(11298);
  END;

  if table T11298 has indexes
    PK_T11298 (Primary key )
    APP_T11298_42_SI
    T11298_BUSINESSKEY_UI
    T11298_E7623_SI
    T11298_E7624_SI
    T11298_E7625_SI

  The above example disables indexes:
    PK_T11298 (Primary key )
    APP_T11298_42_SI
    T11298_E7623_SI
    T11298_E7624_SI
    T11298_E7625_SI
  and drops unique index:
    T11298_BUSINESSKEY_UI

  **********************************************************************************************************/

  PROCEDURE DISABLE_ALL_INDEXES(PI_TABLES_ID  IN NUMBER,
                                PI_PROCESS_ID IN NUMBER DEFAULT NULL,
                                PI_RUN_ID     IN NUMBER DEFAULT NULL,
                                PO_LOG_MSG    OUT CLOB);

  PROCEDURE DISABLE_ALL_INDEXES(PI_TABLES_ID      IN NUMBER,
                                PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                                PI_RUN_ID         IN NUMBER DEFAULT NULL,
                                PI_TRANSACTION_ID IN VARCHAR2 /* DEFAULT NULL*/,
                                PO_LOG_MSG        OUT CLOB);

  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : ENABLE_ALL_INDEXES
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, Process_Id (Optional), Run_Id (Optional)
  * OUTPUT PARAMETERS : PO_LOG_MSG
  * DESCRIPTION       : Enables All Non-Unique Indexes and Recreates ALL Unique Indexes including Primary Key
  * Example           :

  BEGIN
    COMMONS_INDEXING.ENABLE_ALL_INDEXES(11298);
  END;

  if table T11298 has indexes
    PK_T11298 (Primary key Disabled)
    APP_T11298_42_SI (Disabled)
    T11298_BUSINESSKEY_UI (Not present)
    T11298_E7623_SI (Disabled)
    T11298_E7624_SI (Disabled)
    T11298_E7625_SI (Disabled)

  the disabled indexes are enabled and unique index is recreated:
    PK_T11298 (Primary key Enabled)
    APP_T11298_42_SI
    T11298_E7623_SI
    T11298_E7624_SI
    T11298_E7625_SI
    T11298_BUSINESSKEY_UI
  **********************************************************************************************************/
  PROCEDURE ENABLE_ALL_INDEXES(PI_TABLES_ID      IN NUMBER,
                               PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                               PI_RUN_ID         IN NUMBER DEFAULT NULL,
                               PI_TRANSACTION_ID IN VARCHAR2 /*DEFAULT NULL*/,
                               PI_GATHER_STATS   IN NUMBER DEFAULT 1, -- 0- No, 1- Yes
                               PO_LOG_MSG        OUT CLOB);

  PROCEDURE ENABLE_ALL_INDEXES(PI_TABLES_ID  IN NUMBER,
                               PI_PROCESS_ID IN NUMBER DEFAULT NULL,
                               PI_RUN_ID     IN NUMBER DEFAULT NULL,
                               PO_LOG_MSG    OUT CLOB);

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : PRESERVE_ALL_INDEXES
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, Process Id (Optional), Run Id (Optional), Transaction Id (Optional)
  * OUTPUT PARAMETERS : PO_LOG_MSG
  * DESCRIPTION       : This procedure will preserve the DDL of ALL the Indexes on the table.
  * Example           :
  BEGIN
    COMMONS_INDEXING.REAPPLY_ALL_DROPPED_INDEXES(3126);
  END;

  Creates All Indexes which were dropped for the given table, with tables_id = 3126.
  *********************************************************************************************************************/
  PROCEDURE PRESERVE_ALL_INDEXES(PI_TABLES_ID             IN NUMBER,
                                 PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                                 PI_RUN_ID                IN NUMBER DEFAULT NULL,
                                 PI_TRANSACTION_ID        IN VARCHAR2,
                                 PI_TEMP_TABLE_NAME       IN VARCHAR2 DEFAULT NULL, /*OF-7798*/
                                 PI_TABLE_NAME            IN VARCHAR2,
                                 PI_INDEX_TABLESPACE_NAME IN VARCHAR2,
                                 PO_LOG_MSG               OUT CLOB);

  PROCEDURE PRESERVE_ALL_INDEXES(PI_TABLES_ID        IN NUMBER,
                                 PI_PROCESS_ID       IN NUMBER DEFAULT NULL,
                                 PI_RUN_ID           IN NUMBER DEFAULT NULL,
                                 PI_TEMP_TABLE_NAME  IN VARCHAR2 DEFAULT NULL, /*OF-7798*/
                                 PI_TABLE_NAME       IN VARCHAR2,
                                 PI_INDEX_TABLESPACE IN NUMBER,
                                 PI_TRANSACTION_ID   IN VARCHAR2,
                                 PO_LOG_MSG          OUT CLOB);

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : REAPPLY_ALL_DROPPED_INDEXES
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, Process Id (Optional), Run Id (Optional), Transaction Id (Optional)
  * OUTPUT PARAMETERS : PO_LOG_MSG
  * DESCRIPTION       : This procedure is a wrapper; to be used by Java.
  *                     Will internally call COMMONS_INDEXING.RECREATE_ALL_DROPPED_INDEXES.
  * Example           :
  BEGIN
    COMMONS_INDEXING.REAPPLY_ALL_DROPPED_INDEXES(3126);
  END;

  Creates All Indexes which were dropped for the given table, with tables_id = 3126.
  *********************************************************************************************************************/
  PROCEDURE REAPPLY_ALL_DROPPED_INDEXES(PI_TABLES_ID             IN NUMBER,
                                        PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                                        PI_RUN_ID                IN NUMBER DEFAULT NULL,
                                        PI_TRANSACTION_ID        IN VARCHAR2 /* DEFAULT NULL*/,
                                        PI_TABLE_NAME            IN VARCHAR2,
                                        PI_INDEX_TABLESPACE_NAME IN VARCHAR2,
                                        PO_LOG_MSG               OUT CLOB);

  PROCEDURE REAPPLY_ALL_DROPPED_INDEXES(PI_TABLES_ID        IN NUMBER,
                                        PI_PROCESS_ID       IN NUMBER DEFAULT NULL,
                                        PI_RUN_ID           IN NUMBER DEFAULT NULL,
                                        PI_TRANSACTION_ID   IN VARCHAR2,
                                        PI_TABLE_NAME       IN VARCHAR2,
                                        PI_INDEX_TABLESPACE IN NUMBER,
                                        PO_LOG_MSG          OUT CLOB);

  PROCEDURE GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST IN COMMONS_INDEXING.TYPE_CONSTRAINT_NAME,
                                   PO_INDEX_DDL  OUT COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE);

  PROCEDURE CREATE_SPECIFIED_APP_INDEX(PI_TABLES_ID                  IN NUMBER,
                                       PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                                       PI_IS_UNIQUE                  IN NUMBER,
                                       PI_DEF_ID                     IN NUMBER,
                                       PI_BUSINESS_NAME              IN VARCHAR2,
                                       PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                       PI_PROCESS_ID                 IN NUMBER DEFAULT null,
                                       PI_RUN_ID                     IN NUMBER DEFAULT NULL,
                                       PO_INDEX_CREATION_STATUS      OUT NUMBER);

  PROCEDURE DELETE_SPECIFIED_APP_INDEX(PI_TABLES_ID     IN NUMBER,
                                       PI_DEF_ID        IN NUMBER,
                                       PI_BUSINESS_NAME IN VARCHAR2,
                                       PI_PROCESS_ID    IN NUMBER DEFAULT NULL,
                                       PI_RUN_ID        IN NUMBER DEFAULT NULL);

  PROCEDURE COMBINED_DELETE_SPEC_APP_INDEX(PI_TABLES_ID           IN NUMBER,
                                           PI_DELETE_INDEX_OBJECT IN COLTYPE_DELETE_INDEX,
                                           PI_PROCESS_ID          IN NUMBER DEFAULT NULL,
                                           PI_RUN_ID              IN NUMBER DEFAULT NULL);

  PROCEDURE INSERT_APP_INDEXES_METADATA2(PI_DEFINITION_ID              IN NUMBER,
                                         PI_INDEX_NAME                 IN VARCHAR2,
                                         PI_TABLE_NAME                 IN VARCHAR2,
                                         PI_COLUMN_LIST                IN COLTYPE_INDEXED_COLUMNS_LIST1,
                                         PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                         PI_BUSINESS_NAME              IN VARCHAR2,
                                         PI_IS_UNIQUE                  IN NUMBER,
                                         PI_INDEX_TYPE                 IN NUMBER,
                                         PI_INDEX_INSERT_DDL           IN CLOB,
                                         PI_IS_PRIMARY                 IN NUMBER DEFAULT NULL);

  PROCEDURE CREATE_USER_SPECIFIED_INDEX(PI_TABLE_NAME        IN VARCHAR2,
                                        PI_INDEX_NAME        IN VARCHAR2,
                                        PI_COL_LIST          IN tabletype_charmax,
                                        PI_UNIQUENESS        IN NUMBER,
                                        PI_COL_IS_PRIMARYKEY IN NUMBER,
                                        PI_INITRANS          IN NUMBER DEFAULT 5,
                                        PI_INDEX_TABLESPACE  IN VARCHAR2,
                                        PI_RUN_ID            IN NUMBER DEFAULT NULL,
                                        PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded
                                        PO_INDEX_NAME        OUT VARCHAR2,
                                        PO_IS_UNIQUE         OUT VARCHAR2,
                                        PO_CREATE_DDL        OUT CLOB);

  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : CHECK_INDEX_EXISTS
    * AUTHOR            : Abhivyakti Mirajkar
    * REVIEWER          :
    * INPUT PARAMETERS  : Tables_id,
    * OUTPUT PARAMETERS : N/A
    * DESCRIPTION       : This procedure is to be used by Java for identifying if any required index is missing (related to Data Views). If its missing, then an alert will be sent.
    *                     Will internally call COMMONS_INDEXING.RECREATE_ALL_DROPPED_INDEXES.
    * Example           :
  *
  * DECLARE
  * V_NUM NUMBER;
  * BEGIN
  * CHECK_INDEX_EXISTS2(PI_TABLES_ID  => 1234,
  *            PI_DEF_ID    => 382204,
  *            PI_BUSINESS_NAME => 'DV_FILTER_T381541_F380810',
               PO_INDEX_STATUS  =>  V_NUM);
  * DBMS_OUTPUT.PUT_LINE (to_char(V_NUM));
  * END;
  *
  */
  PROCEDURE CHECK_INDEX_EXISTS(PI_TABLES_ID     IN NUMBER,
                               PI_DEF_ID        IN NUMBER,
                               PI_BUSINESS_NAME IN VARCHAR2,
                               PO_INDEX_STATUS  OUT NUMBER);

  /********************************************************************************************************************
  * TYPE              : FUNCTION
  * FUNCTION NAME     : GET_COLUMNS_FOR_INDEX
  * AUTHOR            : Banea, Elena
  * REVIEWER          : Hrubaru, Ionut; Stefan, Andrei
  * INPUT PARAMETERS  : pi_table_info =  a list of <table_name, column name>
  * OUTPUT PARAMETERS : -
  * DESCRIPTION       : The purpose of the function is to return the most selective column(s) from the list of columns
  *                   : received in input.
  * Example           :
    select commons_indexing.get_columns_for_index( pi_table_info => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T2305','ROW_IDENTIFIER'),
                                                                                       OBJTYPE_NAME_MAP('T1110961602','E2303'),
                                                                                       OBJTYPE_NAME_MAP('T2305','E25834')
                                                                                       )
                                                 )
    from dual;

  Creates All Indexes which were dropped for the given table, with tables_id = 3126.
  *********************************************************************************************************************/
  FUNCTION get_columns_for_index(pi_table_info IN TABLETYPE_NAME_MAP)
    RETURN TABLETYPE_COLUMN_SELECTIVITY;

  /********************************************************************************************************************
  * TYPE              : FUNCTION
  * PROCEDURE NAME    : IS_INDEX_LIMIT_EXCEEDING
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, Process Id (Optional), Run Id (Optional), Transaction Id (Optional), PI_IS_FORCE_INDEX_CREATE, PI_CREATE_INDEX_OBJECT, PI_DELETE_INDEX_OBJECT
  * OUTPUT PARAMETERS : NONE
  * DESCRIPTION       : OF-27498 - This will provide warning if the total number of indexes as per the request for index creation exceeds the warning limit
  * Example           :
  BEGIN
    COMMONS_INDEXING.IS_INDEX_LIMIT_EXCEEDING (
   PI_TABLES_ID               IN     NUMBER,
   PI_PROCESS_ID              IN     NUMBER DEFAULT NULL,
   PI_RUN_ID                  IN     NUMBER DEFAULT NULL,
   PI_CREATE_INDEX_OBJECT     IN     COLTYPE_CREATE_INDEX,
   PI_DELETE_INDEX_OBJECT     IN     COLTYPE_DELETE_INDEX);
  END;
  *********************************************************************************************************************/
  FUNCTION IS_INDEX_LIMIT_EXCEEDING(PI_TABLES_ID           IN NUMBER,
                                    PI_PROCESS_ID          IN NUMBER DEFAULT NULL,
                                    PI_RUN_ID              IN NUMBER DEFAULT NULL,
                                    PI_CREATE_INDEX_OBJECT IN COLTYPE_CREATE_INDEX,
                                    PI_DELETE_INDEX_OBJECT IN COLTYPE_DELETE_INDEX)
    RETURN NUMBER -- 1 = Yes, 0 = No; Warning for the proposed indexes modification (Created and/or Dropped) for the relevant App Indexes vis-a-vis the INDEX_LIMIT property
  ;

  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : MODIFY_APP_INDEXES
    * AUTHOR            : Abhishek Vijaywargiya
    * REVIEWER          : Pooja Sharma
    * INPUT PARAMETERS  : Tables_id, Process Id (Optional), Run Id (Optional), Transaction Id (Optional), PI_IS_FORCE_INDEX_CREATE, PI_CREATE_INDEX_OBJECT, PI_DELETE_INDEX_OBJECT
    * OUTPUT PARAMETERS : PO_SAVE_STATUS
    * DESCRIPTION       : OF-22882 -- OF-26355 and OF-26356 - This will provide warning if the total number of indexes as per the request for index creation exceeds the warning limit, and would create only if either:
    *                     1. The warning is not reached or,
    *                     2. User choses to override the warning.
    * Example           :
    BEGIN
      COMMONS_INDEXING.MODIFY_APP_INDEXES (
     PI_TABLES_ID,
     PI_BUSINESS_NAME,
     PI_PROCESS_ID,
     PI_RUN_ID,
     PI_IS_FORCE_INDEX_CREATE,
     PI_CREATE_INDEX_OBJECT,
     PI_DELETE_INDEX_OBJECT,
     PO_SAVE_STATUS                OUT NUMBER -- 0 = Warning, 1 = Successfully Updated (Created and/or Dropped) the relevant App Indexes
  );
    END;
    *********************************************************************************************************************/
  PROCEDURE MODIFY_SPECIFIED_APP_INDEXES(PI_TABLES_ID             IN NUMBER,
                                         PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                                         PI_RUN_ID                IN NUMBER DEFAULT NULL,
                                         PI_IS_FORCE_INDEX_CREATE IN NUMBER DEFAULT 0,
                                         PI_CREATE_INDEX_OBJECT   IN COLTYPE_CREATE_INDEX,
                                         PI_DELETE_INDEX_OBJECT   IN COLTYPE_DELETE_INDEX,
                                         PO_SAVE_STATUS           OUT NUMBER -- 0 = Warning, 1 = Successfully Updated (Created and/or Dropped) the relevant App Indexes
                                         );

  -- OF-27120 - START
  PROCEDURE CREATE_PRIMARY_KEY_INDEX(PI_TABLES_ID IN NUMBER,
                                     PI_RUN_ID    IN NUMBER DEFAULT NULL,
                                     PO_STATUS    OUT NUMBER,
                                     PO_LOG_MSG   OUT VARCHAR2);
  -- OF-27120 - END
  -- OF-30537 START
  PROCEDURE CREATE_INDEX2(PI_TABLE_NAME        IN VARCHAR2,
                          PI_INDEX_NAME        IN VARCHAR2,
                          PI_COLUMN_LIST       IN SYS.HSBLKNAMLST,
                          PI_UNIQUENESS        IN NUMBER,
                          PI_COL_IS_PRIMARYKEY IN NUMBER,
                          PI_INITRANS          IN NUMBER DEFAULT 5,
                          PI_INDEX_TABLESPACE  IN VARCHAR2, /*OF-11821*/
                          PI_TRANSACTION_ID    IN VARCHAR2,
                          PI_RUN_ID            IN NUMBER DEFAULT NULL,
                          PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded, 5 - Invalid Identifier
                          PO_INDEX_NAME        OUT VARCHAR2,
                          PO_IS_UNIQUE         OUT VARCHAR2,
                          PO_CREATE_DDL        OUT CLOB);
  PROCEDURE GET_INDEX_DETAILS(PI_TABLE_NAME   IN VARCHAR2,
                              PI_COL_LIST     IN SYS.HSBLKNAMLST,
                              PO_INDEX_NAME   OUT VARCHAR2,
                              PO_INDEX_EXISTS OUT NUMBER,
                              PO_IS_UNIQUE    OUT VARCHAR2);
  -- OF-30537 END
  --  OF-31450 sTART
  PROCEDURE GET_INDEX_NAME(PI_TABLE_NAME   IN VARCHAR2,
                           PI_COL_LIST     IN SYS.HSBLKNAMLST,
                           PO_INDEX_NAME   OUT VARCHAR2,
                           PO_INDEX_EXISTS OUT NUMBER);
  --  OF-31450 end

/* OF-69424 starts
  PROCEDURE RENAME_BK_INDEX(PI_INDEX_NAME     IN VARCHAR2,
                            PI_UNIQUE_ID      IN NUMBER DEFAULT NULL,
                            PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                            PI_RUN_ID         IN NUMBER DEFAULT NULL,
                            PI_TRANSACTION_ID IN VARCHAR2);
 OF-69424 ends */
  PROCEDURE ASYNC_PLSQL_RUN(PI_PLSQL_CODE IN VARCHAR2,
                            PI_IDENTIFIER IN VARCHAR2,
                            PI_COMMENT    IN VARCHAR2,
                            PI_START_DATE DATE DEFAULT NULL);

  PROCEDURE MERGE_AIR(PI_DEFINITION_ID              IN NUMBER,
                      PI_INDEX_NAME                 IN VARCHAR2,
                      PI_TABLE_NAME                 IN VARCHAR2,
                      PI_COLUMN_LIST                IN VARCHAR2,
                      PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                      PI_BUSINESS_NAME              IN VARCHAR2,
                      PI_IS_UNIQUE                  IN NUMBER,
                      PI_INDEX_TYPE                 IN NUMBER,
                      PI_STATUS                     IN NUMBER);
  PROCEDURE CREATE_USAGE_INDEX(PI_TABLES_ID                  IN NUMBER,
                               PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                               PI_IS_UNIQUE                  IN NUMBER,
                               PI_DEF_ID                     IN NUMBER,
                               PI_BUSINESS_NAME              IN VARCHAR2,
                               PI_INDEX_CREATION_LOGIC_FLAG  IN NUMBER,
                               PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                               PO_INDEX_CREATION_STATUS      OUT NUMBER,
                               PO_INDEX_NAME_RETURNED        OUT VARCHAR2);
  PROCEDURE DELETE_USAGE_INDEX(PI_TABLES_ID     IN NUMBER,
                               PI_DEF_ID        IN NUMBER,
                               PI_BUSINESS_NAME IN VARCHAR2);
  PROCEDURE CREATE_DBA_INDEX(PI_TABLES_NAME           IN VARCHAR2,
                             PI_COLUMN_LIST           IN TABLETYPE_CHARMAX,
                             PI_IS_UNIQUE             IN NUMBER,
                             PO_INDEX_CREATION_STATUS OUT NUMBER,
                             PO_INDEX_NAME_RETURNED   OUT VARCHAR2);
  PROCEDURE DELETE_DBA_INDEX(PI_TABLES_NAME IN VARCHAR2,
                             PI_INDEX_NAME  IN VARCHAR2);

  /********************************************************************************************************************
  * TYPE              : FUNCTION
  * FUNCTION NAME     : CORE_COLS_MINUS_INDEX_COLS
  * AUTHOR            : Hardika Bhate
  * REVIEWER          : Maxim , Rohit
  * INPUT PARAMETERS  : pi_tables_id , pi_table_name
  * OUTPUT PARAMETERS : -
  * DESCRIPTION       : The purpose of the function is to find difference between core and index cols;if difference is found then return 1 else 0
  * Example           :
    select commons_indexing.CORE_COLS_MINUS_INDEX_COLS(4529955,'T4529955')
    from dual;

  *********************************************************************************************************************/

  FUNCTION CORE_COLS_MINUS_INDEX_COLS(pi_tables_id                 IN NUMBER,
                                      PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX,
                                      pi_table_name                IN VARCHAR2)
    RETURN NUMBER;

  /********************************************************************************************************************
  * TYPE              : FUNCTION
  * FUNCTION NAME     : INDEX_COLS_MINUS_CORE_COLS
  * AUTHOR            : Hardika Bhate
  * REVIEWER          : Maxim , Rohit
  * INPUT PARAMETERS  : pi_tables_id , pi_table_name
  * OUTPUT PARAMETERS : -
  * DESCRIPTION       : The purpose of the function is to find difference between index and core cols; if difference is found then return 1 else 0
  * Example           :
    select commons_indexing.INDEX_COLS_MINUS_CORE_COLS(4529955,'T4529955')
    from dual;

  *********************************************************************************************************************/

  FUNCTION INDEX_COLS_MINUS_CORE_COLS(pi_tables_id                 IN NUMBER,
                                      PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX,
                                      pi_table_name                IN VARCHAR2)
    RETURN NUMBER;

  /********************************************************************************************************************
  * TYPE              : FUNCTION
  * FUNCTION NAME     : INDEX_COL_MINUS_APP_COL
  * AUTHOR            : Hardika Bhate
  * REVIEWER          : Maxim , Rohit
  * INPUT PARAMETERS  : pi_table_name
  * OUTPUT PARAMETERS : -
  * DESCRIPTION       : The purpose of the function is to find difference between user and app cols; if difference is found then return 1 else 0
  * Example           :
    select commons_indexing.INDEX_COL_MINUS_APP_COL('T4529955')
    from dual;

  *********************************************************************************************************************/

  FUNCTION INDEX_COL_MINUS_APP_COL(pi_table_name IN VARCHAR2) RETURN NUMBER;

  /********************************************************************************************************************
  * TYPE              : FUNCTION
  * FUNCTION NAME     : APP_COL_MINUS_USER_COL
  * AUTHOR            : Hardika Bhate
  * REVIEWER          : Maxim , Rohit
  * INPUT PARAMETERS  : pi_table_name
  * OUTPUT PARAMETERS : -
  * DESCRIPTION       : The purpose of the function is to find difference between app and user cols; if difference is found then return 1 else 0
  * Example           :
    select commons_indexing.APP_COL_MINUS_INDEX_COL('T4529955')
    from dual;

  *********************************************************************************************************************/

  FUNCTION APP_COL_MINUS_INDEX_COL(pi_table_name IN VARCHAR2) RETURN NUMBER;

  /* ********************************************************************************************************
  * TYPE              : FUNCTION
  * PROCEDURE NAME    : GET_DEF_APP_INDEX
  * AUTHOR            : Hardika Bhate
  * REVIEWER          : Pimparkar Shriniket
  * INPUT PARAMETERS  : pi_def_id
  * OUTPUT PARAMETERS : po_app_index
  * DESCRIPTION       : A new bulk method in IndexingService needed for Data Views indexes
  * Example           :

    DECLARE
     c SYS_REFCURSOR;
     v1 APP_SPECIFIC_INDEXES_METADATA.asim_business_name%TYPE;
     v2 APP_SPECIFIC_INDEXES_METADATA.asim_table_name%TYPE;
    BEGIN
     c := commons_indexing.GET_DEF_APP_INDEX(5717505);   -- Get ref cursor from function
     LOOP
       FETCH c into v1,v2;
       EXIT WHEN c%NOTFOUND;
       dbms_output.put_line('Value from cursor: '||v1||' '||v2);
     END LOOP;
    END;

  **********************************************************************************************************/

  FUNCTION GET_DEF_APP_INDEX(pi_def_id IN NUMBER) RETURN sys_refcursor;
END COMMONS_INDEXING;
/
