CREATE PACKAGE commons_dataimport AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type     :  SPM
  -- Product           :  commons
  -- Module            :  dataimport-commons
  -- Requester       :  Agarwal, Ankita
  -- Author          :  Rohit, Maxim
  -- Reviewer          :  Homeuca, Victor-Stefan
  -- Review date       :  12-April-2011
  -- Description       :  This package handles raplace and merger mode of data import.

  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  TYPE type_index_name IS TABLE OF user_indexes.index_name%type INDEX BY PLS_INTEGER;

  TYPE type_data_import_row IS TABLE OF TEMP_DATA_IMPORT_RENAME%rowtype INDEX BY PLS_INTEGER;
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  -- Author     : Maxim Rohit
  -- Create date: 25 FEB 2011
  -- Module     : DATA IMPORT
  -- Description: This SP will accept  two table names, their owner and a process ID, It will
  --merger the data of dump table into data table with or w/o rebuilding the indexes.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary

  -- Return : NA

  --Example
  /*

      MAIN_REPLACE.MAIN_MERGE(pi_data_table => 'T621045_1900_1_1',
                     pi_dump_table => 'TEMP_DATA_BKP',
                     pi_process_id => 344778);
  */

  PROCEDURE MAIN_MERGE(pi_data_table      varchar2,
                       pi_dump_table      varchar2,
                       pi_process_id      varchar2,
                       pi_id_column_name  VARCHAR2,
                       pi_seq_used_for_id VARCHAR2,
                       po_index_created   out number);

  -- Author     : Maxim Rohit
  -- Create date: 1 FEB 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure is the entry point to the replace scenario, data and dump table are passed along with the process id.
  -- This procdure populates TEMP_DATA_IMPORT_RENAME with session based information, all perform all steps of data import replace one by one.
  -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME

  --  Table structure of temprory table
  /*  CREATE GLOBAL TEMPORARY TABLE TEMP_DATA_IMPORT_RENAME (
      DIR_Original_name  varchar(50),
      DIR_DDL_statement  clob,
      DIR_Dump_name  varchar(50),
      DIR_Backup_name  varchar(50),
      DIR_object_type varchar2(50)
      );
  */

  /* --Example
   begin
  -- Call the procedure
  MAIN_REPLACE.MAIN_REPLACE(pi_data_table => 'T621045_1900_1_1',
                     pi_dump_table => 'TEMP_DATA_BKP',
                     pi_process_id => 344778);

    end;
  */

  /*PROCEDURE MAIN_REPLACE(pi_data_table      varchar2,
                         pi_dump_table      varchar2,
                         pi_process_id      varchar2,
                         pi_id_column_name  VARCHAR2,
                         pi_seq_used_for_id VARCHAR2);*/

  -- Author     : Maxim Rohit
  -- Create date: 11 APRIL 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure check for ovelapping values in key fields.
  -- Assumptions: NA
  /* PROCEDURE DI_OVERLAP_CHECK(    pi_DATA_TABLE       IN VARCHAR2,
                                                                 pi_DUMP_TABLE       IN VARCHAR2,
                                                                 pi_IMPORT_MODE      IN NUMBER,
                                                                 pi_KEY_FIELDS       IN CLOB,
                                                                 pi_START_DATE_FIELD IN VARCHAR2,
                                                                 pi_END_DATE_FIELD   IN VARCHAR2,
                                                                po_OVERLAP_CHK_RES   OUT NUMBER
                                                                ) ;
  */

  -- Author     : Maxim Rohit
  -- Create date: 11 APRIL 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure check for unique values in key fields.
  -- Assumptions: NA
  /*   PROCEDURE DI_UNIQUE_CHECK(    pi_DATA_TABLE       IN VARCHAR2,
   pi_DUMP_TABLE       IN VARCHAR2,
   pi_IMPORT_MODE      IN NUMBER,
   pi_KEY_FIELDS       IN CLOB,
   pi_START_DATE_FIELD IN VARCHAR2,
   pi_END_DATE_FIELD   IN VARCHAR2,
    pi_EFF_DATED_TABLE  IN NUMBER,

   po_UNIQUE_CHK_RES   OUT NUMBER
  ) ;*/

  -- Author     : Maxim Rohit
  -- Create date: 11 APRIL 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure does start/end date validation for an effective dated table.

  -- Assumptions: NA
  /*
  PROCEDURE DI_DATE_RANGE_CHECK(    pi_DATA_TABLE       IN VARCHAR2,
                                                               pi_DUMP_TABLE       IN VARCHAR2,
                                                               pi_IMPORT_MODE      IN NUMBER,
                                                               pi_KEY_FIELDS       IN CLOB,
                                                               pi_START_DATE_FIELD IN VARCHAR2,
                                                               pi_END_DATE_FIELD   IN VARCHAR2,
                                                               po_DATE_RANGE_RES   OUT NUMBER
                                                              ) ;*/

  -- Author     : Maxim Rohit
  -- Create date: 11 APRIL 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure checks for any unmapped entities.
  -- Assumptions: NA

  PROCEDURE DI_ENTITY_CHECK(pi_DUMP_TABLE    IN VARCHAR2,
                            pi_ENTITY_FIELDS IN CLOB,
                            po_ENTITY_RES    OUT varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 20 APRIL 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure checks for any unmapped TU.
  -- Assumptions: NA

  PROCEDURE DI_PERIOD_CHECK(pi_DUMP_TABLE    IN VARCHAR2,
                            pi_period_FIELDS IN CLOB,
                            po_PERIOD_RES    OUT varchar2);



  PROCEDURE DI_OBJECT_CHECK(pi_DUMP_TABLE    IN VARCHAR2,
                            pi_FIELDS IN CLOB,
                            po_RES    OUT varchar2);

-- *******************************    PUBLIC PROCEDURES END         *******************************
END commons_dataimport;
/
