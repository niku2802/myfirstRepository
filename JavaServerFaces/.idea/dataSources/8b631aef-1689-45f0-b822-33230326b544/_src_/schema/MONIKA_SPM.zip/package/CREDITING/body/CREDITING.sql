CREATE PACKAGE BODY CREDITING AS
  -- --------------------------------------------------------------------------
  -- Copyright c 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd.  It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : compensation-product
  -- Module         : crediting
  -- Requester      : Sharma, Pooja
  -- Author         : Rohit,Maxim
  -- Create date    : 29-Oct-2013
  -- Reviewer       : Sharma, Pooja
  -- Review date    :
  -- Description    : Package for Crediting
  --ls
  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- tabletype used

  TYPE RTYPE_COLUMN IS RECORD(
    COLUMN_NAME VARCHAR2(30),
    COLUMN_TYPE NUMBER);

  TYPE TABLETYPE_COLUMN IS TABLE OF RTYPE_COLUMN;
  V_ENTITY_IS_NUMBER NUMBER(2);

  v_stamp VARCHAR2(250);

  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

  /*
    -- Description:
       Private Procedure to log the variables. It will internally call the procedure L4O_LOG_VARIABLES.
      -----**************************************************************************************------------------------
      -- Return : NA
      -----**************************************************************************************------------------------
       -- Input Parameters:
          pi_log_level        L4O_LOGS.L4OL_LEVEL%TYPE                    : log level to use
          pi_variable        ANYDATA                                      : variable to be logged
          pi_message_format  VARCHAR2 DEFAULT NULL                        : a template for message format, "<value>" will be replaced with the actual computed value of the variable
          pi_identifier      L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL   : if multiple messages of the same type must be logged from concurrent sessions, this identifier can help developers
                                                                            identify the parent session/transaction of a particular message.

       --Out parameter :
          NA
       Example :
        DECLARE v_e1 VARCHAR2(200);
        BEGIN v_e1 := 'asd';
            L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_e1), 'v_e1 := <value>;', 'Crediting.evaluate_crediting');
        END;
  */
  --Logging changes start
  PROCEDURE L4O_LOG_VARIABLES(pi_log_level      L4O_LOGS.L4OL_LEVEL%TYPE,
                              pi_variable       ANYDATA,
                              pi_message_format VARCHAR2 DEFAULT NULL,
                              pi_identifier     L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL) IS

  BEGIN
    L4O_LOGGING.LOG_VARIABLE(pi_log_level      => pi_log_level,
                             pi_variable       => pi_variable,
                             pi_message_format => pi_message_format,
                             pi_identifier     => pi_identifier);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END L4O_LOG_VARIABLES;
  --Logging changes end.

  /*
  -- Description:
       Procedure performs an overlap check on the data set being passed. It will delete the overlappig records from source table and it will
       optionally insert those records in overlap set table depending upon whether this table name is passed in the input parameter 'PI_OVERLAP_SET_TABLE_NAME'.
       If the parameter 'PI_OVERLAP_SET_TABLE_NAME' is NULL then overlapping records will not be inserted into any table, they will be only deleted from
       source table. If there exists any overlapping record then parameter 'po_OVERLAP_CHK_RES' will be set to 0 else it will be set to 1.

    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
     -- Input Parameters:
       PI_SOURCE_TABLE_NAME                IN  VARCHAR2   The name of source table for which overlap check is to be performed.
                                                          Overlapping records will be deleted from this table.
       PI_OVERLAP_SET_TABLE_NAME           IN  VARCHAR2   The name of overlap set table. Overlapping records will be inserted into this table if this parameter
                                                          is not NULL.
       pi_KEY_FIELDS                       IN  clob       comma separated list key fields values
       PI_effective_start                  IN  VARCHAR2   name of the efffective start date/period columns
       PI_effective_end                    IN  VARCHAR2   name of the efffective end date/period columns
       PI_is_Period                        IN  number     PI_is_Period       number   -- Period range then 1, date range than 0
       PI_ID_COLUMN                        IN  VARCHAR2   name of the ID column of source table

     --Out parameter :-
      po_DATE_RANGE_RES        out NUMBER if 1 then pass (i.e. NO Overlap, if 0 (Overlap) then fail

  example:-
       declare
           po_OVERLAP_CHK_RES NUMBER;
         begin
              ISOLATE_OVERLAPPING_RECORDS(PI_SOURCE_TABLE_NAME       => 't3',
                                          PI_OVERLAP_SET_TABLE_NAME  => 't5'
                                          PI_KEY_FIELDS              => 't3,t2_number',
                                          PI_EFFECTIVE_START         => 'effective_start_date',
                                          PI_EFFECTIVE_END           => 'effective_end_date',
                                          PI_IS_PERIOD               => 0,
                                          PI_ID_COLUMN               => 'ROW_IDENTIFIER',
         end;                             PO_OVERLAP_CHK_RES         => po_OVERLAP_CHK_RES);

  */
  ---------------------------------------
  ---------------------------------------
  ---------------------------------------
  PROCEDURE CR_CREATE_INDEX(pin_index IN CLOB) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    /*commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INDEX -- pin_index = ' ||
                              pin_index);*/
    EXECUTE IMMEDIATE pin_index;
    -- INSERT_LOGS ('Out CREDITING.CR_CREATE_INDEX -- pin_index = ' || pin_index);
    COMMIT;
  END CR_CREATE_INDEX;

  PROCEDURE CR_RETURN_TIME_UNITS(pin_date_period_column  IN VARCHAR2,
                                 pin_start_period_column IN VARCHAR2,

                                 pio_time_unit_id   IN OUT NUMBER,
                                 pio_hr_timeunit_id IN OUT NUMBER) AS
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_RETURN_TIME_UNITS -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_start_period_column = ' || pin_start_period_column);
    -- INSERT_LOGS ('   -- Before -- pio_time_unit_id = ' || pio_time_unit_id || ' -- pio_hr_timeunit_id = ' || pio_hr_timeunit_id);
    -- select the time unit id of the input column
    SELECT FLD_TIMEUNIT
      INTO pio_TIME_UNIT_ID
      FROM FIELDS
     WHERE FLD_COLUMN_NAME = pin_date_period_column
       AND ROWNUM = 1;

    -- select the time unit id of the hierarchy column
    SELECT FLD_TIMEUNIT
      INTO pio_HR_TIMEUNIT_ID
      FROM FIELDS
     WHERE FLD_COLUMN_NAME = pin_start_period_column
       AND ROWNUM = 1;
    -- INSERT_LOGS ('   -- After1 -- pio_time_unit_id = ' || pio_time_unit_id || ' -- pio_hr_timeunit_id = ' || pio_hr_timeunit_id);
    -- INSERT_LOGS ('Out1 CREDITING.CR_RETURN_TIME_UNITS - Successful ');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL;
      -- INSERT_LOGS ('   -- After2 -- pio_time_unit_id = ' || pio_time_unit_id || ' -- pio_hr_timeunit_id = ' || pio_hr_timeunit_id);
    -- INSERT_LOGS ('Out2 CREDITING.CR_RETURN_TIME_UNITS - Exception -- WHEN NO_DATA_FOUND');
  END CR_RETURN_TIME_UNITS;

  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  PROCEDURE CR_RETURN_CORRESP(pin_period_run_for      IN NUMBER,
                              pin_start_period_column IN VARCHAR2,

                              pio_time_unit_id    IN OUT NUMBER,
                              pio_hr_timeunit_id  IN OUT NUMBER,
                              pio_corresp_RUN_FOR IN OUT NUMBER) AS
    v_CORRESP NUMBER(10);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_RETURN_CORRESP -- pin_period_run_for = ' || pin_period_run_for || ' -- pin_start_period_column = ' || pin_start_period_column);
    -- INSERT_LOGS ('   -- Before -- pio_time_unit_id = ' || pio_time_unit_id || ' -- pio_hr_timeunit_id = ' || pio_hr_timeunit_id || ' -- pio_corresp_RUN_FOR = ' || pio_corresp_RUN_FOR);
    -- select the time unit id of the period for which the process is ran
    SELECT TU_PERIODS_RANGE.TUPR_TU_ID
      INTO pio_TIME_UNIT_ID
      FROM TU_PERIODS_RANGE
     WHERE TUPR_ID = pin_period_run_for;

    -- select the time unit id of the column
    SELECT FLD_TIMEUNIT
      INTO pio_HR_TIMEUNIT_ID
      FROM FIELDS
     WHERE FLD_COLUMN_NAME = pin_start_period_column
       AND ROWNUM = 1;

    IF (pio_TIME_UNIT_ID <> pio_HR_TIMEUNIT_ID) THEN
      -- check the correspondence of the time units
      SELECT COUNT(*)
        INTO v_CORRESP
        FROM TU_CORRESPONDENCE
       WHERE TUC_TU_ID = pio_TIME_UNIT_ID
         AND TUC_TU_ID_CORR = pio_HR_TIMEUNIT_ID;

      IF (v_CORRESP = 1) THEN
        -- get the corresponding period for which the process is ran
        WITH CORR AS
         (SELECT TUC_TU_ID_CORR, TUPR_ID, TUPR_ID_CORR FROM TU_CORR_MAT_VIEW)
        SELECT TUPR_ID_CORR
          INTO pio_CORRESP_RUN_FOR
          FROM CORR
         WHERE TUPR_ID = pin_period_run_for
           AND TUC_TU_ID_CORR = pio_HR_TIMEUNIT_ID;

      END IF;
    END IF;
    -- INSERT_LOGS ('   -- After1 -- pio_time_unit_id = ' || pio_time_unit_id || ' -- pio_hr_timeunit_id = ' || pio_hr_timeunit_id || ' -- pio_corresp_RUN_FOR = ' || pio_corresp_RUN_FOR);
    -- INSERT_LOGS ('Out CREDITING.CR_RETURN_CORRESP - Successful');

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL;
      -- INSERT_LOGS ('   -- After2 -- pio_time_unit_id = ' || pio_time_unit_id || ' -- pio_hr_timeunit_id = ' || pio_hr_timeunit_id || ' -- pio_corresp_RUN_FOR = ' || pio_corresp_RUN_FOR);
    -- INSERT_LOGS ('Out CREDITING.CR_RETURN_CORRESP - Exception -- WHEN NO_DATA_FOUND');
  END CR_RETURN_CORRESP;

  ----------
  ----------

  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  FUNCTION CR_RETURN_SELECT_IN(pin_process_run_for IN number,
                               pin_entity_col      IN varchar2,
                               pin_input_data      IN VARCHAR2) RETURN CLOB AS
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_RETURN_SELECT_IN');
    -- INSERT_LOGS ('   -- Before -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_entity_col = ' || pin_entity_col || ' -- pin_input_data = ' || pin_input_data);
    -- case for the 4 kinds of process runs posibble

    CASE (pin_process_run_for)
    -- first day
      WHEN 0 THEN
        RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_input_data || ' INPUT_DATA) AND (INPUT_DATA.START_DATEE BETWEEN HIERARCHY_INPUT.START_DATE AND HIERARCHY_INPUT.END_DATE)';
        -- last day
      WHEN 1 THEN
        RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_INPUT_DATA || ' INPUT_DATA) AND (INPUT_DATA.END_DATEE BETWEEN HIERARCHY_INPUT.START_DATE AND HIERARCHY_INPUT.END_DATE)';
        -- any day
      WHEN 2 THEN
        RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_INPUT_DATA || ' INPUT_DATA) AND (INPUT_DATA.END_DATEE >= HIERARCHY_INPUT.START_DATE AND INPUT_DATA.START_DATEE <= HIERARCHY_INPUT.END_DATE)';
        -- all days
      WHEN 3 THEN
        RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_INPUT_DATA || ' INPUT_DATA) AND (INPUT_DATA.START_DATEE >= HIERARCHY_INPUT.START_DATE AND INPUT_DATA.END_DATEE <= HIERARCHY_INPUT.END_DATE)';
      ELSE
        RETURN NULL;
    END CASE;
    -- INSERT_LOGS ('Out CREDITING.CR_RETURN_SELECT_IN');
  END CR_RETURN_SELECT_IN;

  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  PROCEDURE CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for IN NUMBER,

                                        pio_select IN OUT NOCOPY CLOB) AS
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_RETURN_SELECT_CONNECT_BY -- pin_process_run_for = ' || pin_process_run_for);
    -- INSERT_LOGS ('   -- Before -- pio_select = ' || pio_select);
    -- case for the 4 kinds of process runs posibble
    CASE (pin_process_run_for)
    -- first day
      WHEN 0 THEN
        pio_select := pio_select ||
                      ' AND START_DATEE BETWEEN MAX_START_DATE AND MIN_END_DATE';
        -- last day
      WHEN 1 THEN
        pio_select := pio_select ||
                      ' AND END_DATEE BETWEEN MAX_START_DATE AND MIN_END_DATE';
        -- any day
      WHEN 2 THEN
        pio_select := pio_select ||
                      ' AND (START_DATEE <= MIN_END_DATE AND (END_DATEE >= MAX_START_DATE)
                            AND (MIN_END_DATE >= MAX_START_DATE))';
        -- all days
      WHEN 3 THEN
        pio_select := pio_select ||
                      ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
      ELSE
        NULL;
    END CASE;
    -- INSERT_LOGS ('   -- After -- pio_select = ' || pio_select);
    -- INSERT_LOGS ('Out CREDITING.CR_RETURN_SELECT_CONNECT_BY');
  END CR_RETURN_SELECT_CONNECT_BY;

  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  PROCEDURE CR_RETURN_FILTER_NO(pin_process_run_for IN NUMBER,
                                pio_select          IN OUT NOCOPY CLOB) AS
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_RETURN_FILTER_NO -- pin_process_run_for = ' || pin_process_run_for);
    -- INSERT_LOGS ('   -- Before -- pio_select = ' || pio_select);
    -- case for the 4 kinds of process runs posibble
    CASE (pin_process_run_for)
    -- first day
      WHEN 0 THEN
        pio_select := pio_select ||
                      ' AND INPUT_DATA.START_DATEE BETWEEN HI.START_DATE AND HI.END_DATE';
        -- last day
      WHEN 1 THEN
        pio_select := pio_select ||
                      ' AND INPUT_DATA.END_DATEE BETWEEN HI.START_DATE AND HI.END_DATE';
        -- any day
      WHEN 2 THEN
        pio_select := pio_select ||
                      ' AND (INPUT_DATA.START_DATEE <= HI.END_DATE AND (INPUT_DATA.END_DATEE >= HI.START_DATE)
                            AND (HI.END_DATE >= HI.START_DATE))';
        -- all days
      WHEN 3 THEN
        pio_select := pio_select ||
                      ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
      ELSE
        NULL;
    END CASE;
    -- INSERT_LOGS ('   -- After -- pio_select = ' || pio_select);
    -- INSERT_LOGS ('Out CREDITING.CR_RETURN_FILTER_NO');
  END CR_RETURN_FILTER_NO;

  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  FUNCTION CR_CREATE_DATE_PERIOD_FILTER(pin_ENTITY_FIELD        IN BOOLEAN,
                                        pin_is_effective_period IN NUMBER,
                                        pin_process_run_for     IN NUMBER,
                                        pin_date_period_column  IN VARCHAR2,
                                        pin_start_period_column IN VARCHAR2)
    RETURN CLOB AS
    V_SELECT         CLOB;
    v_corresp        NUMBER(10);
    v_field_type     NUMBER(10);
    v_time_unit_id   NUMBER(10);
    v_hr_timeunit_id NUMBER(10);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- pin_ENTITY_FIELD = ' || CASE WHEN pin_ENTITY_FIELD THEN 1 ELSE 0 END || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_start_period_column = ' || pin_start_period_column);

    BEGIN
      SELECT FIELDS.fld_data_type
        INTO V_FIELD_TYPE
        FROM FIELDS
       WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column
         AND ROWNUM = 1;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 1S -- V_FIELD_TYPE = ' || V_FIELD_TYPE);
    EXCEPTION
      when OTHERS THEN
        NULL;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 1E_Others -- V_FIELD_TYPE = ' || V_FIELD_TYPE);
    END;
    IF (pin_ENTITY_FIELD) THEN
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2 -- IF (pin_ENTITY_FIELD) THEN ');
      CASE
      -- if the run is made for a date and the hierarchy is date effective
        WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case1 -- WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN ');
          V_SELECT := ' AND DATE_FIELD BETWEEN MAX_START_DATE AND MIN_END_DATE';
          -- if the run is made for a period and the hierarchy is date effective
        WHEN (pin_is_effective_period = 0) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case2 -- WHEN (pin_is_effective_period = 0) THEN -- CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);');
          -- case for the 4 choices for the records to be selected
          CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for,
                                                V_SELECT);
          -- if the run is made for a period and the hierarchy is period effective
        ELSE
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case3 -- ELSE -- CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column, pin_start_period_column, v_time_unit_id, v_hr_timeunit_id);');
          -- select the time unit ids
          CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column,
                                         pin_start_period_column,
                                         v_time_unit_id,
                                         v_hr_timeunit_id);
          -- if the run is made for the same periods or corresponding periods
          IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case3_1 -- IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN');
            -- if the run is made for the same periods
            V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
            -- if the run is made for corresponding periods
          ELSE
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case3_2 -- ELSE');
            SELECT COUNT(*)
              INTO v_corresp
              FROM TU_CORRESPONDENCE
             WHERE TUC_TU_ID = v_TIME_UNIT_ID
               AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

            IF (v_corresp = 1) THEN
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case3_2_1 -- IF (v_corresp = 1) THEN');
              -- if the used time unit corresponds
              V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
            ELSE
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_case3_2_2 -- ELSE -- CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);');
              -- case for the 4 kinds of process runs posibble
              CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for,
                                                    V_SELECT);
            END IF;
          END IF;
      END CASE;
    ELSE
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2 -- IF (pin_ENTITY_FIELD) -- ELSE ');
      CASE
      -- if the run is made for a date and the hierarchy is date effective
        WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case1 -- WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN ');
          V_SELECT := ' AND DATE_FIELD BETWEEN MAX_START_DATE AND MIN_END_DATE';
          -- if the run is made for a period and the hierarchy is date effective
        WHEN (pin_is_effective_period = 0) THEN
          -- case for the 4 choices for the records to be selected
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case2 -- WHEN (pin_is_effective_period = 0) THEN -- CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);');
          CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for,
                                                V_SELECT);
          -- if the run is made for a period and the hierarchy is period effective
        ELSE
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case3 -- ELSE -- CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column, pin_start_period_column, v_time_unit_id, v_hr_timeunit_id);');
          -- select the time unit ids
          CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column,
                                         pin_start_period_column,
                                         v_time_unit_id,
                                         v_hr_timeunit_id);
          -- if the run is made for the same periods or corresponding periods
          IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case3_1 -- IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN');
            -- if the run is made for the same periods
            V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
            -- if the run is made for corresponding periods
          ELSE
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case3_2 -- ELSE');
            SELECT COUNT(*)
              INTO v_corresp
              FROM TU_CORRESPONDENCE
             WHERE TUC_TU_ID = v_TIME_UNIT_ID
               AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

            IF (v_corresp = 1) THEN
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case3_2_1 -- IF (v_corresp = 1) THEN');
              -- if the used time unit corresponds
              V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';

            ELSE
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- 2_E_case3_2_2 -- ELSE -- CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);');
              -- case for the 4 kinds of process runs posibble
              CREDITING.CR_RETURN_SELECT_CONNECT_BY(pin_process_run_for,
                                                    V_SELECT);
            END IF;
          END IF;

      END CASE;
    END IF;

    -- return the value
    -- INSERT_LOGS ('Out CREDITING.CR_CREATE_DATE_PERIOD_FILTER -- V_SELECT =' || V_SELECT);
    RETURN V_SELECT;
  END CR_CREATE_DATE_PERIOD_FILTER;

  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  FUNCTION CR_CREATE_DATE_PERIOD_NO(pin_ENTITY_FIELD        IN BOOLEAN,
                                    pin_is_effective_period IN NUMBER,
                                    pin_process_run_for     IN NUMBER,
                                    pin_date_period_column  IN VARCHAR2,
                                    pin_start_period_column IN VARCHAR2)
    RETURN CLOB AS
    V_SELECT         CLOB;
    v_corresp        NUMBER(10);
    v_field_type     NUMBER(10);
    v_time_unit_id   NUMBER(10);
    v_hr_timeunit_id NUMBER(10);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- pin_ENTITY_FIELD = ' || CASE WHEN pin_ENTITY_FIELD THEN 1 ELSE 0 END || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_start_period_column = ' || pin_start_period_column);

    BEGIN
      SELECT FIELDS.fld_data_type
        INTO V_FIELD_TYPE
        FROM FIELDS
       WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column
         AND ROWNUM = 1;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 1S -- V_FIELD_TYPE = ' || V_FIELD_TYPE);
    EXCEPTION
      when OTHERS THEN
        NULL;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 1E_Others -- V_FIELD_TYPE = ' || V_FIELD_TYPE);
    END;
    IF (pin_ENTITY_FIELD) THEN
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2 -- IF (pin_ENTITY_FIELD) THEN ');
      CASE
      -- if the run is made for a date and the hierarchy is date effective
        WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case1 -- WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN ');
          V_SELECT := ' AND INPUT_DATA.DATE_FIELD BETWEEN HI.START_DATE AND HI.END_DATE';
          -- if the run is made for a period and the hierarchy is date effective
        WHEN (pin_is_effective_period = 0) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case2 -- WHEN (pin_is_effective_period = 0) THEN -- CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);');
          -- case for the 4 choices for the records to be selected
          CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
          -- if the run is made for a period and the hierarchy is period effective
        ELSE
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case3 -- ELSE -- CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column, pin_start_period_column, v_time_unit_id, v_hr_timeunit_id);');
          -- select the time unit ids
          CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column,
                                         pin_start_period_column,
                                         v_time_unit_id,
                                         v_hr_timeunit_id);
          -- if the run is made for the same periods or corresponding periods
          IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case3_1 -- IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN');
            -- if the run is made for the same periods
            V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
            -- if the run is made for corresponding periods
          ELSE
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case3_2 -- ELSE');
            SELECT COUNT(*)
              INTO v_corresp
              FROM TU_CORRESPONDENCE
             WHERE TUC_TU_ID = v_TIME_UNIT_ID
               AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

            IF (v_corresp = 1) THEN
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case3_2_1 -- IF (v_corresp = 1) THEN');
              -- if the used time unit corresponds
              V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
            ELSE
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_case3_2_2 -- ELSE -- CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);');
              -- case for the 4 kinds of process runs posibble
              CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
            END IF;
          END IF;
      END CASE;
    ELSE
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2 -- IF (pin_ENTITY_FIELD) -- ELSE ');
      CASE
      -- if the run is made for a date and the hierarchy is date effective
        WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case1 -- WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN ');
          V_SELECT := ' AND INPUT_DATA.DATE_FIELD BETWEEN HI.START_DATE AND HI.END_DATE';
          -- if the run is made for a period and the hierarchy is date effective
        WHEN (pin_is_effective_period = 0) THEN
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case2 -- WHEN (pin_is_effective_period = 0) THEN -- CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);');
          -- case for the 4 choices for the records to be selected
          CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
          -- if the run is made for a period and the hierarchy is period effective
        ELSE
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case3 -- ELSE -- CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column, pin_start_period_column, v_time_unit_id, v_hr_timeunit_id);');
          -- select the time unit ids
          CREDITING.CR_RETURN_TIME_UNITS(pin_date_period_column,
                                         pin_start_period_column,
                                         v_time_unit_id,
                                         v_hr_timeunit_id);
          -- if the run is made for the same periods or corresponding periods
          IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case3_1 -- IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN');
            -- if the run is made for the same periods
            V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
            -- if the run is made for corresponding periods
          ELSE
            -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case3_2 -- ELSE');
            SELECT COUNT(*)
              INTO v_corresp
              FROM TU_CORRESPONDENCE
             WHERE TUC_TU_ID = v_TIME_UNIT_ID
               AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

            IF (v_corresp = 1) THEN
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case3_2_1 -- IF (v_corresp = 1) THEN');
              -- if the used time unit corresponds
              V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';

            ELSE
              -- INSERT_LOGS ('In CREDITING.CR_CREATE_DATE_PERIOD_NO -- 2_E_case3_2_2 -- ELSE -- CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);');
              -- case for the 4 kinds of process runs posibble
              CREDITING.CR_RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
            END IF;
          END IF;

      END CASE;
    END IF;

    -- return the value
    -- INSERT_LOGS ('Out CREDITING.CR_CREATE_DATE_PERIOD_NO -- V_SELECT =' || V_SELECT);
    RETURN V_SELECT;
  END CR_CREATE_DATE_PERIOD_NO;

  -----------------------------------------------------------------------------------------
  -----------------------------------------------------------------------------------------

  FUNCTION CR_CREATE_HIERARCHY(pin_relationship_tables IN TABLETYPE_RELATIONSHIP_TABLES,
                               pin_start_period_column IN varchar2,
                               pin_end_period_column   IN varchar2)
    RETURN CLOB AS
    V_HIERARCHY CLOB;
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY  -- pin_start_period_column = ' || pin_start_period_column || ' -- pin_end_period_column = ' || pin_end_period_column || ' -- PIN_RELATIONSHIP_TABLES.COUNT = ' || PIN_RELATIONSHIP_TABLES.COUNT);
    -- if the hierarchy is date or period effective
    IF (pin_start_period_column IS NULL) THEN
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 1_I -- IF (pin_start_period_column IS NULL) THEN -- V_HIERARCHY = ' || V_HIERARCHY);
      V_HIERARCHY := 'SELECT ' || PIN_RELATIONSHIP_TABLES(1)
                    .VALUE_LOWER_COL || ' AS ENT_LOWER, ' || PIN_RELATIONSHIP_TABLES(1)
                    .VALUE_UPPER_COL || ' AS ENT_UPPER, ' || PIN_RELATIONSHIP_TABLES(1)
                    .ENTITY_LOWER || ' AS ENT_LOWER_TYPE, ' || PIN_RELATIONSHIP_TABLES(1)
                    .ENTITY_UPPER || ' AS ENT_UPPER_TYPE FROM ' || PIN_RELATIONSHIP_TABLES(1)
                    .TABLE_NAME;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 1_O -- IF (pin_start_period_column IS NULL) THEN -- V_HIERARCHY = ' || V_HIERARCHY);

      -- iterate the rest of the hierarchies

      FOR I IN pin_relationship_tables.FIRST + 1 .. pin_relationship_tables.LAST LOOP
        V_HIERARCHY := V_HIERARCHY || ' UNION SELECT ' || PIN_RELATIONSHIP_TABLES(I)
                      .VALUE_LOWER_COL || ', ' || PIN_RELATIONSHIP_TABLES(I)
                      .VALUE_UPPER_COL || ', ' || PIN_RELATIONSHIP_TABLES(I)
                      .ENTITY_LOWER || ', ' || PIN_RELATIONSHIP_TABLES(I)
                      .ENTITY_UPPER || ' FROM ' || PIN_RELATIONSHIP_TABLES(I)
                      .TABLE_NAME;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 2_O -- FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST -- I = ' || I || ' -- V_HIERARCHY = ' || V_HIERARCHY);
      END LOOP;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 2_O -- FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST -- FINAL V_HIERARCHY = ' || V_HIERARCHY);
      -- if the hierarchy is non effective
    ELSE
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 1_E_I -- IF (pin_start_period_column IS NULL) -- ELSE -- V_HIERARCHY = ' || V_HIERARCHY);
      V_HIERARCHY := 'SELECT ' || PIN_RELATIONSHIP_TABLES(1)
                    .VALUE_LOWER_COL || ' AS ENT_LOWER, ' || PIN_RELATIONSHIP_TABLES(1)
                    .VALUE_UPPER_COL || ' AS ENT_UPPER, ' || PIN_RELATIONSHIP_TABLES(1)
                    .ENTITY_LOWER || ' AS ENT_LOWER_TYPE, ' || PIN_RELATIONSHIP_TABLES(1)
                    .ENTITY_UPPER || ' AS ENT_UPPER_TYPE, ' ||
                     pin_start_period_column || ', ' ||
                     pin_end_period_column || ' FROM ' || PIN_RELATIONSHIP_TABLES(1)
                    .TABLE_NAME;

      -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 1_E_O -- IF (pin_start_period_column IS NULL) -- ELSE -- V_HIERARCHY = ' || V_HIERARCHY);

      -- iterate the rest of the hierarchies

      FOR I IN pin_relationship_tables.FIRST + 1 .. pin_relationship_tables.LAST LOOP

        V_HIERARCHY := V_HIERARCHY || ' UNION ALL SELECT ' || PIN_RELATIONSHIP_TABLES(I)
                      .VALUE_LOWER_COL || ', ' || PIN_RELATIONSHIP_TABLES(I)
                      .VALUE_UPPER_COL || ', ' || PIN_RELATIONSHIP_TABLES(I)
                      .ENTITY_LOWER || ', ' || PIN_RELATIONSHIP_TABLES(I)
                      .ENTITY_UPPER || ', ' || pin_start_period_column || ', ' ||
                       pin_end_period_column || ' FROM ' || PIN_RELATIONSHIP_TABLES(I)
                      .TABLE_NAME;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 2_E_O -- FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST -- I = ' || I || ' -- V_HIERARCHY = ' || V_HIERARCHY);
      END LOOP;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY -- 2_E_O -- FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST -- FINAL V_HIERARCHY = ' || V_HIERARCHY);
    END IF;

    RETURN V_HIERARCHY;
  END CR_CREATE_HIERARCHY;

  ------------------------------------------------------------------------------------------------
  -----------------------------------------------------------------------------------------------
  PROCEDURE CR_CREATE_HIERARCHY_INPUT(pin_is_effective_period IN NUMBER,
                                      pin_date_period_column  IN VARCHAR2,
                                      pin_date_run_for        IN DATE,
                                      pin_relationship_tables IN TABLETYPE_RELATIONSHIP_TABLES,
                                      pin_process_run_for     IN NUMBER,
                                      pin_start_period_column IN VARCHAR2,
                                      pin_end_period_column   IN VARCHAR2,
                                      pin_period_run_for      IN NUMBER,
                                      pin_run_id              IN NUMBER,
                                      pin_operation_id        IN NUMBER) AS

    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_START_DATE           CONSTANT VARCHAR2(12) := '''01/01/1900''';
    CON_END_DATE             CONSTANT VARCHAR2(12) := '''12/31/9999''';
    V_START_DATE      DATE;
    V_END_DATE        DATE;
    V_CORRESP         NUMBER;
    V_CREATE_HTABLE   CLOB;
    V_SELECT_HINT     CLOB;
    v_hr_timeunit_id  NUMBER;
    v_time_unit_id    NUMBER;
    v_corresp_run_for NUMBER;

  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_date_run_for = ' || pin_date_run_for || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_start_period_column = ' || pin_start_period_column || ' -- pin_end_period_column = ' || pin_end_period_column || ' -- pin_period_run_for = ' || pin_period_run_for || ' -- pin_run_id = ' || pin_run_id || ' -- pin_operation_id = ' || pin_operation_id);
    -- add the hint framework
    v_select_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_HIERARCHY_INPUT',
                                                               pin_operation_id) ||
                     'SELECT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_HIERARCHY_INPUT',
                                                  pin_operation_id);
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- v_select_hint = ' || v_select_hint);
    CREDITING.CR_RETURN_CORRESP(pin_period_run_for,
                                pin_start_period_column,
                                v_TIME_UNIT_ID,
                                v_HR_TIMEUNIT_ID,
                                V_CORRESP_RUN_FOR);
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- AFTER -- CREDITING.CR_RETURN_CORRESP(pin_period_run_for, pin_start_period_column, v_TIME_UNIT_ID, v_HR_TIMEUNIT_ID, V_CORRESP_RUN_FOR);');

    IF (V_CORRESP_RUN_FOR IS NULL) THEN
      V_CORRESP_RUN_FOR := pin_period_run_for;
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- V_CORRESP_RUN_FOR = ' || V_CORRESP_RUN_FOR);
    -- concatenate the with containing the hierarchy

    CASE (pin_is_effective_period)
    -- when the hierarchy is date effective
      WHEN 4 THEN

        v_create_htable := 'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME ||
                           ' TABLESPACE ' || USER || '_OUT AS (' ||
                           v_select_hint ||
                           ' ent_upper_type, ent_lower_type, ent_upper, ent_lower, NVL(START_DATE, TO_DATE(' ||
                           CON_START_DATE ||
                           ', ''mm/dd/yyyy'')) AS START_DATE, NVL(END_DATE, TO_DATE(' ||
                           CON_END_DATE ||
                           ', ''mm/dd/yyyy'')) AS END_DATE FROM (' ||
                           CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables,
                                                         'START_DATE',
                                                         'END_DATE') || ')';
        /* IF (pin_date_period_column IS NULL) THEN
          v_create_htable :=
                  'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower FROM ('
                  || CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables, 'START_DATE', 'END_DATE') ||
                  ')';
        ELSE
          v_create_htable :=
                  'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower, NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ''mm/dd/yyyy'')) AS START_DATE, NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ''mm/dd/yyyy'')) AS END_DATE FROM ('
                  || CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables, 'START_DATE', 'END_DATE') ||
                  ')';
        END IF; */
    -- when the hierarchy is period effective
      WHEN 5 THEN

        v_create_htable := 'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME ||
                           ' TABLESPACE ' || USER || '_OUT AS (' ||
                           v_select_hint ||
                           ' ent_upper_type, ent_lower_type, ent_upper, ent_lower, NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                           CON_START_DATE ||
                           ', ''mm/dd/yyyy'')) AS START_DATE, NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                           CON_END_DATE || ', ''mm/dd/yyyy'')) AS END_DATE
                      ,' ||
                           pin_start_period_column || ',' ||
                           pin_end_period_column || '
                      FROM (' ||
                           CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables,
                                                         pin_start_period_column,
                                                         pin_end_period_column) ||
                           ') LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                           PIN_START_PERIOD_COLUMN ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                           PIN_END_PERIOD_COLUMN;

    /*IF (pin_date_period_column IS NULL) THEN
                          v_create_htable :=
                                  'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower FROM ('
                                  || CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables, pin_start_period_column, pin_end_period_column) ||
                                  ')';
                        ELSE
                          v_create_htable :=
                                  'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower, NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ''mm/dd/yyyy'')) AS START_DATE, NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ''mm/dd/yyyy'')) AS END_DATE FROM ('
                                  || CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables, pin_start_period_column, pin_end_period_column) ||
                                  ') LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                  || PIN_START_PERIOD_COLUMN ||
                                  ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                  || PIN_END_PERIOD_COLUMN;
                        END IF; */
    -- when the hierarchy is not effective dated
      ELSE
        v_create_htable := 'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME ||
                           ' TABLESPACE ' || USER || '_OUT AS (' ||
                           v_select_hint ||
                           ' ent_upper_type, ent_lower_type, ent_upper, ent_lower FROM (' ||
                           CREDITING.CR_CREATE_HIERARCHY(pin_relationship_tables,
                                                         NULL,
                                                         NULL) || ')';

    END CASE;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- v_create_htable = ' || v_create_htable);

    -- enter the where clause in case the query is run for a given date or period
    CASE
    -- if the run is made for a date and the hierarchy is date effective
      WHEN (pin_date_run_for IS NOT NULL --AND pin_date_period_column IS NULL
           ) AND (pin_is_effective_period = 4) THEN
        v_create_htable := v_create_htable || ' WHERE TO_DATE(''' ||
                           pin_date_run_for ||
                           ''') BETWEEN NVL(START_DATE, TO_DATE(' ||
                           CON_START_DATE ||
                           ', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(' ||
                           CON_END_DATE || ', ''mm/dd/yyyy''))';
        -- if the run is made for a date and the hierarchy is period effective
      WHEN (pin_date_run_for IS NOT NULL --AND pin_date_period_column IS NULL
           ) AND (pin_is_effective_period = 5) THEN
        v_create_htable := v_create_htable ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                           PIN_START_PERIOD_COLUMN ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                           PIN_END_PERIOD_COLUMN || ' WHERE TO_DATE(''' ||
                           pin_date_run_for ||
                           ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                           CON_START_DATE ||
                           ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                           CON_END_DATE || ', ''mm/dd/yyyy''))';
        -- if the run is made for a period and the hierarchy is date effective
      WHEN (v_CORRESP_RUN_FOR IS NOT NULL --AND pin_date_period_column IS NULL
           ) AND (pin_is_effective_period = 4) THEN
        -- case for the 4 choices for the records to be selected
        CASE (pin_process_run_for)
        -- first day
          WHEN 1 THEN
            SELECT TU_PERIODS_RANGE.TUPR_START_DATE
              INTO V_START_DATE
              FROM TU_PERIODS_RANGE
             WHERE TUPR_ID = v_CORRESP_RUN_FOR;

            v_create_htable := v_create_htable || ' WHERE TO_DATE(''' ||
                               V_START_DATE ||
                               ''') BETWEEN NVL(START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(' ||
                               CON_END_DATE || ', ''mm/dd/yyyy''))';
            -- last day
          WHEN 2 THEN
            SELECT TU_PERIODS_RANGE.TUPR_END_DATE
              INTO V_END_DATE
              FROM TU_PERIODS_RANGE
             WHERE TUPR_ID = v_CORRESP_RUN_FOR;

            v_create_htable := v_create_htable || ' WHERE TO_DATE(''' ||
                               V_END_DATE ||
                               ''') BETWEEN NVL(START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(' ||
                               CON_END_DATE || ', ''mm/dd/yyyy''))';

          WHEN 3 THEN
            SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                   TU_PERIODS_RANGE.TUPR_END_DATE
              INTO V_START_DATE, V_END_DATE
              FROM TU_PERIODS_RANGE
             WHERE TUPR_ID = v_CORRESP_RUN_FOR;
            -- any days
            v_create_htable := v_create_htable || ' WHERE (TO_DATE(''' ||
                               V_START_DATE ||
                               ''') BETWEEN NVL(START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(' ||
                               CON_END_DATE ||
                               ', ''mm/dd/yyyy''))) OR (TO_DATE(''' ||
                               V_END_DATE ||
                               ''') BETWEEN NVL(START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(' ||
                               CON_END_DATE ||
                               ', ''mm/dd/yyyy''))) OR (TO_DATE(''' ||
                               V_START_DATE ||
                               ''') < NVL(START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                               V_END_DATE || ''') > NVL(END_DATE, TO_DATE(' ||
                               CON_END_DATE || ', ''mm/dd/yyyy'')))';
            -- all days
          WHEN 4 THEN
            SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                   TU_PERIODS_RANGE.TUPR_END_DATE
              INTO V_START_DATE, V_END_DATE
              FROM TU_PERIODS_RANGE
             WHERE TUPR_ID = v_CORRESP_RUN_FOR;

            v_create_htable := v_create_htable || ' WHERE TO_DATE(''' ||
                               V_START_DATE ||
                               ''') >= NVL(START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                               V_END_DATE ||
                               ''') <= NVL(END_DATE, TO_DATE(' ||
                               CON_END_DATE || ', ''mm/dd/yyyy''))';
          ELSE

            v_create_htable := v_create_htable;
        END CASE;
        -- if the run is made for a period and the hierarchy is period effective
      WHEN (v_CORRESP_RUN_FOR IS NOT NULL --AND pin_date_period_column IS NULL
           ) AND (pin_is_effective_period = 5) THEN
        -- if the run is made for the same periods or non corresponding periods
        IF (v_hr_timeunit_id = v_time_unit_id) THEN
          -- if the run is made for the same periods
          SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                 TU_PERIODS_RANGE.TUPR_END_DATE
            INTO V_START_DATE, V_END_DATE
            FROM TU_PERIODS_RANGE
           WHERE TUPR_ID = v_CORRESP_RUN_FOR;

          v_create_htable := v_create_htable ||
                             ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                             PIN_START_PERIOD_COLUMN ||
                             ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                             PIN_END_PERIOD_COLUMN || ' WHERE TO_DATE(''' ||
                             V_START_DATE ||
                             ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                             CON_START_DATE ||
                             ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                             V_END_DATE ||
                             ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                             CON_END_DATE || ', ''mm/dd/yyyy''))';
          -- if the run is made for corresponding periods
        ELSE
          SELECT COUNT(*)
            INTO V_CORRESP
            FROM TU_CORRESPONDENCE
           WHERE TUC_TU_ID = v_time_unit_id
             AND TUC_TU_ID_CORR = v_hr_timeunit_id;

          IF (V_CORRESP = 1) THEN
            -- if the used time unit corresponds
            SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                   TU_PERIODS_RANGE.TUPR_END_DATE
              INTO V_START_DATE, V_END_DATE
              FROM TU_PERIODS_RANGE
             WHERE TUPR_ID = v_CORRESP_RUN_FOR;

            v_create_htable := v_create_htable ||
                               ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                               PIN_START_PERIOD_COLUMN ||
                               ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                               PIN_END_PERIOD_COLUMN || ' WHERE TO_DATE(''' ||
                               V_START_DATE ||
                               ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                               CON_START_DATE ||
                               ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                               V_END_DATE ||
                               ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                               CON_END_DATE || ', ''mm/dd/yyyy''))';

          ELSE
            SELECT COUNT(*)
              INTO V_CORRESP
              FROM TU_CORRESPONDENCE
             WHERE TUC_TU_ID = v_hr_timeunit_id
               AND TUC_TU_ID_CORR = v_time_unit_id;
            IF (V_CORRESP = 0) THEN
              -- if the process time unit corresponds or there is no time unit correspondence
              SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                     TU_PERIODS_RANGE.TUPR_END_DATE
                INTO V_START_DATE, V_END_DATE
                FROM TU_PERIODS_RANGE
               WHERE TUPR_ID = v_CORRESP_RUN_FOR;
              -- case for the 4 kinds of process runs posibble
              CASE (pin_process_run_for)
              -- first day
                WHEN 1 THEN
                  SELECT TU_PERIODS_RANGE.TUPR_START_DATE
                    INTO V_START_DATE
                    FROM TU_PERIODS_RANGE
                   WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE TO_DATE(''' || V_START_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy''))';
                  -- last day
                WHEN 2 THEN
                  SELECT TU_PERIODS_RANGE.TUPR_END_DATE
                    INTO V_END_DATE
                    FROM TU_PERIODS_RANGE
                   WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE TO_DATE(''' || V_END_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy''))';

                WHEN 3 THEN
                  SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                         TU_PERIODS_RANGE.TUPR_END_DATE
                    INTO V_START_DATE, V_END_DATE
                    FROM TU_PERIODS_RANGE
                   WHERE TUPR_ID = v_CORRESP_RUN_FOR;
                  -- any days
                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE (TO_DATE(''' || V_START_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE ||
                                     ', ''mm/dd/yyyy''))) OR (TO_DATE(''' ||
                                     V_END_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE ||
                                     ', ''mm/dd/yyyy''))) OR (TO_DATE(''' ||
                                     V_START_DATE ||
                                     ''') < NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                                     V_END_DATE ||
                                     ''') > NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy'')))';
                  -- all days
                WHEN 4 THEN
                  SELECT TU_PERIODS_RANGE.TUPR_START_DATE,
                         TU_PERIODS_RANGE.TUPR_END_DATE
                    INTO V_START_DATE, V_END_DATE
                    FROM TU_PERIODS_RANGE
                   WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE TO_DATE(''' || V_START_DATE ||
                                     ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                                     V_END_DATE ||
                                     ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy''))';
                ELSE
                  v_create_htable := v_create_htable;
              END CASE;

            ELSE
              -- if the process time unit corresponds or there is no time unit correspondence
              WITH CORR AS
               (SELECT TUC_TU_ID,
                       TUC_TU_ID_CORR,
                       TUPR_ID,
                       TUPR_ID_CORR,
                       TUPR_START_DATE,
                       TUPR_END_DATE
                  FROM TU_CORR_MAT_VIEW)
              SELECT MIN(TUPR_START_DATE), MAX(TUPR_END_DATE)
                INTO V_START_DATE, V_END_DATE
                FROM CORR
               WHERE TUPR_ID_CORR = pin_period_run_for
                 AND TUC_TU_ID = v_hr_timeunit_id;
            -- case for the 4 kinds of process runs posibble
              -- INSERT_LOGS(' -- pin_process_run_for = ' || pin_process_run_for);
              CASE (pin_process_run_for)
              -- first day
                WHEN 1 THEN

                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE TO_DATE(''' || V_START_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy''))';
                  -- last day
                WHEN 2 THEN

                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE TO_DATE(''' || V_END_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy''))';

                WHEN 3 THEN
                  -- any days
                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE (TO_DATE(''' || V_START_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE ||
                                     ', ''mm/dd/yyyy''))) OR (TO_DATE(''' ||
                                     V_END_DATE ||
                                     ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE ||
                                     ', ''mm/dd/yyyy''))) OR (TO_DATE(''' ||
                                     V_START_DATE ||
                                     ''') < NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                                     V_END_DATE ||
                                     ''') > NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy'')))';
                  -- all days
                WHEN 4 THEN

                  v_create_htable := v_create_htable ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = ' ||
                                     PIN_START_PERIOD_COLUMN ||
                                     ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = ' ||
                                     PIN_END_PERIOD_COLUMN ||
                                     ' WHERE TO_DATE(''' || V_START_DATE ||
                                     ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' ||
                                     CON_START_DATE ||
                                     ', ''mm/dd/yyyy'')) AND TO_DATE(''' ||
                                     V_END_DATE ||
                                     ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' ||
                                     CON_END_DATE || ', ''mm/dd/yyyy''))';
                ELSE
                  NULL;
              END CASE;
            END IF;
          END IF;
        END IF;
      ELSE
        NULL;

    END CASE;

    v_create_htable := v_create_htable || ')';

    v_stamp := 'CREDITING.CR_ROLLUP - create hierarchy table - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(v_create_htable),
                               ',v_create_htable => <value>',
                               v_stamp);
    END;

 /*   commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- BEFORE -- COMMONS_DDL_HANDLING.execute_ddl -- v_create_htable = ' ||
                              v_create_htable);*/
    COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => COMMONS_DDL_HANDLING.get_transaction_id,
                                     pi_description    => 'CREATE ROLL UP HIERARCHY TABLE',
                                     pi_ddl            => v_create_htable,
                                     pi_undo_ddl       => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' ||
                                                          CON_HIERARCHY_TABLE_NAME ||
                                                          ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' ||
                                                          CON_HIERARCHY_TABLE_NAME ||
                                                          '''; END LOOP; END;',
                                     pi_run_id         => pin_run_id);
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_HIERARCHY_INPUT  -- AFTER SUCCESS');

  END CR_CREATE_HIERARCHY_INPUT;

  ----------------------------------------------------------
  ----------------------------------------------------------

  PROCEDURE CR_CREATE_INPUT_DATA(pin_roll_up_from_type          IN NUMBER,
                                 pin_rollup_alias_columns       IN VARCHAR2,
                                 pin_inputview_ent_fld          IN varchar2,
                                 pin_inputview                  IN CLOB,
                                 pin_date_period_column         IN varchar2,
                                 pin_new_date_period_column     IN VARCHAR2,
                                 pin_fields_columns             IN VARCHAR2,
                                 pin_INPUTVIEW_NOROLLUP_COLUMNS IN VARCHAR2,
                                 pin_A_INPUTVIEW_NOROLLUP_COLS  IN VARCHAR2,
                                 pin_input_data_entity          IN VARCHAR2,
                                 pin_run_id                     IN NUMBER,

                                 pio_INPUT_VIEW_COLUMNS_NA IN OUT TABLETYPE_COLUMN,
                                 pio_INPUT_VIEW_COLUMNS    IN OUT TABLETYPE_COLUMN) AS

    CON_INPUT_DATA_TABLE       CONSTANT VARCHAR2(30) := 'INPD' ||
                                                        pin_run_id ||
                                                        CR_SEQ.CURRVAL;
    CON_INPUT_DATA_TABLE_INDEX CONSTANT VARCHAR2(30) := 'IDIP' ||
                                                        pin_run_id ||
                                                        CR_SEQ.CURRVAL;
    CON_START_DATE             CONSTANT VARCHAR2(12) := '''01/01/1900''';
    CON_END_DATE               CONSTANT VARCHAR2(12) := '''12/31/9999''';

    V_CR_CREATE_INPUT_DATA CLOB;
    V_INPUTVIEW_COLUMNS    VARCHAR2(32767);
    V_FIELD_TYPE           NUMBER;
    V_ENT_BUS_COLUMN       VARCHAR2(30);
    V_ENTITY_FIELD         BOOLEAN;
    V_ROW_IDENTIFIER       VARCHAR2(45);
    V_rollup_alias_columns VARCHAR2(32767);
    V_IS_FIELD             NUMBER(1);
    V_INNER_JOIN           VARCHAR2(150);

  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INPUT_DATA  -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_rollup_alias_columns = ' || pin_rollup_alias_columns || ' -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_inputview = ' || pin_inputview || ' -- pin_date_period_column = ' ||  pin_date_period_column || ' -- pin_new_date_period_column = ' || pin_new_date_period_column || ' -- pin_fields_columns = ' || pin_fields_columns || ' -- pin_INPUTVIEW_NOROLLUP_COLUMNS = ' || pin_INPUTVIEW_NOROLLUP_COLUMNS || ' -- pin_A_INPUTVIEW_NOROLLUP_COLS = ' || pin_A_INPUTVIEW_NOROLLUP_COLS || ' -- pin_input_data_entity = ' || pin_input_data_entity || ' -- pin_run_id = ' || pin_run_id);

    -- if the entity/field column is Exxxx type
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');
    -- get the business key column of the entity
    IF (V_ENTITY_FIELD) THEN
      V_ENT_BUS_COLUMN := commons.FIND_ENT_BUSINESS_KEY_BY_NAME(pin_inputview_ent_fld);
    ELSE
      V_ENT_BUS_COLUMN := commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                pin_roll_up_from_type);
    END IF;

    -- set the join between the input table and entity table
    IF (V_ENTITY_IS_NUMBER = 6) THEN
      V_INNER_JOIN := ' LEFT JOIN ' ||
                      commons.FIND_ENT_TABLE_NAME('E' ||
                                                  pin_roll_up_from_type) ||
                      ' b ON b.' || V_ENT_BUS_COLUMN || ' = a.' ||
                      pin_INPUT_DATA_ENTITY;
    ELSE
      V_INNER_JOIN := ' LEFT JOIN ' ||
                      commons.FIND_ENT_TABLE_NAME('E' ||
                                                  pin_roll_up_from_type) ||
                      ' b ON UPPER(b.' || V_ENT_BUS_COLUMN ||
                      ') = UPPER(a.' || pin_INPUT_DATA_ENTITY || ')';
    END IF;

    IF (pin_fields_columns IS NULL) THEN
      -- check if the first column is of field type
      BEGIN
        SELECT 1
          INTO V_IS_FIELD
          FROM fields f
         WHERE f.fld_column_name = pin_rollup_alias_columns
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_IS_FIELD := 0;
      END;
      -- get the row_identifier alias
      IF (substr(pin_rollup_alias_columns, 1, 1) = 'E' OR (V_IS_FIELD = 1)) THEN
        V_ROW_IDENTIFIER := 'ROW_IDENTIFIER';
      ELSE
        V_ROW_IDENTIFIER := substr(replace(pin_rollup_alias_columns, ' '),
                                   1,
                                   instr(replace(pin_rollup_alias_columns,
                                                 ' '),
                                         ',') - 1) || ' ROW_IDENTIFIER';
      END IF;

      -- get the column aliases without the row_identifier
      IF (instr(pin_rollup_alias_columns, ',') IS NULL) THEN
        v_rollup_alias_columns := '';
      ELSE
        IF (substr(pin_rollup_alias_columns, 1, 1) = 'E' OR
           (V_IS_FIELD = 1)) THEN
          V_rollup_alias_columns := replace(pin_rollup_alias_columns, ' ');
        ELSE
          V_rollup_alias_columns := substr(replace(pin_rollup_alias_columns,
                                                   ' '),
                                           instr(replace(pin_rollup_alias_columns,
                                                         ' '),
                                                 ',') + 1);
        END IF;
      END IF;

      -- if the there is no date/period field to filter by
      IF (pin_date_period_column IS NOT NULL) THEN
        SELECT FIELDS.fld_data_type
          INTO V_FIELD_TYPE
          FROM FIELDS
         WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column
           AND ROWNUM = 1;
        -- if the field is date type
        IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          IF (V_ENTITY_FIELD) THEN
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT b.' ||
                                      V_ENT_BUS_COLUMN ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                         a.' ||
                                      pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                      ', a.' || pin_new_date_period_column ||
                                      ' AS DATE_FIELD, a.' ||
                                      V_ROW_IDENTIFIER || '
                                         FROM (' ||
                                      pin_InputView || ') a LEFT JOIN ' ||
                                      commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) ||
                                      ' b ON b.E_INTERNAL_ID = a.' ||
                                      pin_INPUT_DATA_ENTITY;
            -- if the field is period type
          ELSE
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT a.' ||
                                      pin_INPUT_DATA_ENTITY ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID
                                        , a.' ||
                                      pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                      ', a.' || pin_new_date_period_column ||
                                      ' AS DATE_FIELD, a.' ||
                                      V_ROW_IDENTIFIER || '
                                         FROM (' ||
                                      pin_InputView || ') a ' ||
                                      V_INNER_JOIN;
          END IF;
          -- if the field is not date type
        ELSE
          -- if the roll up it's done by entity
          IF (V_ENTITY_FIELD) THEN
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT b.' ||
                                      V_ENT_BUS_COLUMN ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.' ||
                                      pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                      ', CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' ||
                                      CON_START_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE TO_DATE(' ||
                                      CON_START_DATE ||
                                      ', ''mm/dd/yyyy'') END AS START_DATEE, CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' ||
                                      CON_END_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE TO_DATE(' ||
                                      CON_END_DATE ||
                                      ', ''mm/dd/yyyy'') END AS END_DATEE, a.' ||
                                      V_ROW_IDENTIFIER || ' FROM (' ||
                                      pin_InputView || ') a LEFT JOIN ' ||
                                      commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) ||
                                      ' b ON b.E_INTERNAL_ID = a.' ||
                                      pin_INPUT_DATA_ENTITY ||
                                      ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID';
            -- if the roll up it's not done by entity
          ELSE
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT a.' ||
                                      pin_INPUT_DATA_ENTITY ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.' ||
                                      pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                      ', CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' ||
                                      CON_START_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE TO_DATE(' ||
                                      CON_START_DATE ||
                                      ', ''mm/dd/yyyy'') END AS START_DATEE, CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' ||
                                      CON_END_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE TO_DATE(' ||
                                      CON_END_DATE ||
                                      ', ''mm/dd/yyyy'') END AS END_DATEE, a.' ||
                                      V_ROW_IDENTIFIER || ' FROM (' ||
                                      pin_InputView || ') a ' ||
                                      V_INNER_JOIN ||
                                      ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID';
          END IF;
        END IF;
        -- if there is a date/period field to filter by
      ELSE
        IF (V_ENTITY_FIELD) THEN
          V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA_TABLE ||
                                    ' TABLESPACE ' || USER ||
                                    '_OUT AS (SELECT b.' ||
                                    V_ENT_BUS_COLUMN ||
                                    ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                      a.' ||
                                    pin_A_INPUTVIEW_NOROLLUP_COLS || ', a.' ||
                                    V_ROW_IDENTIFIER || ' FROM (' ||
                                    pin_InputView || ') a LEFT JOIN ' ||
                                    commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) ||
                                    ' b ON b.E_INTERNAL_ID = a.' ||
                                    pin_INPUT_DATA_ENTITY;
        ELSE
          V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA_TABLE ||
                                    ' TABLESPACE ' || USER ||
                                    '_OUT AS (SELECT a.' ||
                                    pin_INPUT_DATA_ENTITY ||
                                    ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                      a.' ||
                                    pin_A_INPUTVIEW_NOROLLUP_COLS || ', a.' ||
                                    V_ROW_IDENTIFIER || ' FROM (' ||
                                    pin_InputView || ') a ' || V_INNER_JOIN;
        END IF;

      END IF;

      -- if there exists values to roll up
    ELSE
      -- check if the first column is of field type
      BEGIN
        SELECT 1
          INTO V_IS_FIELD
          FROM fields f
         WHERE f.fld_column_name =
               substr(pin_rollup_alias_columns,
                      1,
                      instr(pin_rollup_alias_columns, ',') - 1)
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_IS_FIELD := 0;
      END;
      -- get the row_identifier alias
      IF (substr(pin_rollup_alias_columns, 1, 1) = 'E' OR (V_IS_FIELD = 1)) THEN
        V_ROW_IDENTIFIER := 'ROW_IDENTIFIER';
      ELSE
        V_ROW_IDENTIFIER := substr(replace(pin_rollup_alias_columns, ' '),
                                   1,
                                   instr(replace(pin_rollup_alias_columns,
                                                 ' '),
                                         ',') - 1) || ' ROW_IDENTIFIER';
      END IF;

      -- get the column aliases without the row_identifier
      IF (instr(pin_rollup_alias_columns, ',') IS NULL) THEN
        v_rollup_alias_columns := '';
      ELSE
        IF (substr(pin_rollup_alias_columns, 1, 1) = 'E' OR
           (V_IS_FIELD = 1)) THEN
          V_rollup_alias_columns := replace(pin_rollup_alias_columns, ' ');
        ELSE
          V_rollup_alias_columns := substr(replace(pin_rollup_alias_columns,
                                                   ' '),
                                           instr(replace(pin_rollup_alias_columns,
                                                         ' '),
                                                 ',') + 1);
        END IF;
      END IF;

      -- get the alias field column names into an array
      select BB.AA, 6 BULK COLLECT
        INTO pio_INPUT_VIEW_COLUMNS
        FROM (select regexp_substr(v_rollup_alias_columns,
                                   '[^ ,]+',
                                   1,
                                   level) AA,
                     level as LVL
                from dual
              connect by regexp_substr(v_rollup_alias_columns,
                                       '[^ ,]+',
                                       1,
                                       level) is not null) BB
       order by BB.LVL;

      -- get the field column names into an array
      SELECT BB.AA, NVL(fields.fld_Data_Type, 6) BULK COLLECT
        INTO pio_INPUT_VIEW_COLUMNS_NA
        FROM (select regexp_substr(PIN_FIELDS_COLUMNS, '[^ ,]+', 1, level) AA,
                     level as LVL
                from dual
              connect by regexp_substr(PIN_FIELDS_COLUMNS,
                                       '[^ ,]+',
                                       1,
                                       level) is not null) BB
        left outer join fields
          on BB.AA = fields.fld_column_name
       order by BB.LVL;

      V_INPUTVIEW_COLUMNS := '';

      IF (V_ENTITY_FIELD) THEN
        -- add the field columns
        FOR i IN pio_INPUT_VIEW_COLUMNS.FIRST .. pio_INPUT_VIEW_COLUMNS.LAST LOOP
          V_INPUTVIEW_COLUMNS := V_INPUTVIEW_COLUMNS || 'A.' || pio_INPUT_VIEW_COLUMNS(i)
                                .COLUMN_NAME || ' AS VALUE' || i || ',';
        END LOOP;
      ELSE
        -- add the field columns
        FOR i IN pio_INPUT_VIEW_COLUMNS.FIRST .. pio_INPUT_VIEW_COLUMNS.LAST LOOP
          V_INPUTVIEW_COLUMNS := V_INPUTVIEW_COLUMNS || pio_INPUT_VIEW_COLUMNS(i)
                                .COLUMN_NAME || ' AS VALUE' || i || ',';
        END LOOP;
      END IF;

      V_INPUTVIEW_COLUMNS := substr(V_INPUTVIEW_COLUMNS,
                                    1,
                                    length(V_INPUTVIEW_COLUMNS) - 1); -- if the there is no date/period field to filter by
      IF (V_ENTITY_FIELD) THEN
        IF (pin_date_period_column IS NOT NULL) THEN
          SELECT FIELDS.fld_data_type
            INTO V_FIELD_TYPE
            FROM FIELDS
           WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column
             AND ROWNUM = 1;
          -- if the field is date type
          IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT b.' ||
                                      V_ENT_BUS_COLUMN ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.' ||
                                      pin_INPUT_DATA_ENTITY || ', ' ||
                                      V_INPUTVIEW_COLUMNS || ', a.' ||
                                      pin_new_date_period_column ||
                                      ' AS DATE_FIELD, a.' ||
                                      V_ROW_IDENTIFIER || ' ' ||
                                      PIN_INPUTVIEW_NOROLLUP_COLUMNS ||
                                      ' FROM (' || pin_InputView ||
                                      ') a LEFT JOIN ' ||
                                      commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) ||
                                      ' b ON b.E_INTERNAL_ID = a.' ||
                                      pin_INPUT_DATA_ENTITY;
            -- if the field is not date type
          ELSE
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT b.' ||
                                      V_ENT_BUS_COLUMN ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.' ||
                                      pin_A_INPUTVIEW_NOROLLUP_COLS || ', ' ||
                                      V_INPUTVIEW_COLUMNS ||
                                      ', CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' ||
                                      CON_START_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE NULL END AS START_DATEE, CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' ||
                                      CON_END_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE NULL END AS END_DATEE, a.' ||
                                      V_ROW_IDENTIFIER || ' FROM (' ||
                                      pin_InputView || ') a LEFT JOIN ' ||
                                      commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) ||
                                      ' b ON b.E_INTERNAL_ID = a.' ||
                                      pin_INPUT_DATA_ENTITY ||
                                      ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID';
          END IF;
          -- if there is a date/period field to filter by
        ELSE
          V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA_TABLE ||
                                    ' TABLESPACE ' || USER ||
                                    '_OUT AS (SELECT b.' ||
                                    V_ENT_BUS_COLUMN ||
                                    ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.' ||
                                    pin_A_INPUTVIEW_NOROLLUP_COLS || ', a.' ||
                                    V_ROW_IDENTIFIER || ', ' ||
                                    V_INPUTVIEW_COLUMNS || ' FROM (' ||
                                    pin_InputView || ') a LEFT JOIN ' ||
                                    commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) ||
                                    ' b ON b.E_INTERNAL_ID = a.' ||
                                    pin_INPUT_DATA_ENTITY;
        END IF;
      ELSE
        IF (pin_date_period_column IS NOT NULL) THEN
          SELECT FIELDS.fld_data_type
            INTO V_FIELD_TYPE
            FROM FIELDS
           WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column
             AND ROWNUM = 1;

          -- if the field is date type
          IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT a.' ||
                                      pin_INPUT_DATA_ENTITY ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.' ||
                                      pin_INPUT_DATA_ENTITY || ', ' ||
                                      V_INPUTVIEW_COLUMNS || ', a.' ||
                                      pin_new_date_period_column ||
                                      ' AS DATE_FIELD, a.' ||
                                      V_ROW_IDENTIFIER || ' ' ||
                                      PIN_INPUTVIEW_NOROLLUP_COLUMNS ||
                                      ' FROM (' || pin_InputView || ') a ' ||
                                      V_INNER_JOIN;
            -- if the field is not date type
          ELSE
            V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' ||
                                      CON_INPUT_DATA_TABLE ||
                                      ' TABLESPACE ' || USER ||
                                      '_OUT AS (SELECT a.' ||
                                      pin_INPUT_DATA_ENTITY ||
                                      ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.' ||
                                      pin_A_INPUTVIEW_NOROLLUP_COLS || ', ' ||
                                      V_INPUTVIEW_COLUMNS ||
                                      ', CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' ||
                                      CON_START_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE NULL END AS START_DATEE, CASE WHEN a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' ||
                                      CON_END_DATE ||
                                      ', ''mm/dd/yyyy'')) ELSE NULL END AS END_DATEE, a.' ||
                                      V_ROW_IDENTIFIER || ' FROM (' ||
                                      pin_InputView || ') a ' ||
                                      V_INNER_JOIN ||
                                      ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.' ||
                                      pin_new_date_period_column ||
                                      ' = TU_PERIODS_RANGE.TUPR_ID';
          END IF;
          -- if there is a date/period field to filter by
        ELSE
          V_CR_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA_TABLE ||
                                    ' TABLESPACE ' || USER ||
                                    '_OUT AS (SELECT a.' ||
                                    pin_INPUT_DATA_ENTITY ||
                                    ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.' ||
                                    pin_A_INPUTVIEW_NOROLLUP_COLS || ', a.' ||
                                    V_ROW_IDENTIFIER || ', ' ||
                                    V_INPUTVIEW_COLUMNS || ' FROM (' ||
                                    pin_InputView || ') a ' || V_INNER_JOIN;
        END IF;
      END IF;
    END IF;

    V_CR_CREATE_INPUT_DATA := V_CR_CREATE_INPUT_DATA || ')';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INPUT_DATA -- V_CR_CREATE_INPUT_DATA = ' || V_CR_CREATE_INPUT_DATA);

    v_stamp := 'CREDITING.CR_ROLLUP - create input data table - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_CR_CREATE_INPUT_DATA),
                               ',V_CR_CREATE_INPUT_DATA => <value>',
                               v_stamp);
    END;
  /*
    commons_utils.INSERT_LOGS('V_CR_CREATE_INPUT_DATA in cr_create_input_data = ' ||
                              V_CR_CREATE_INPUT_DATA);*/
    COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => COMMONS_DDL_HANDLING.get_transaction_id,
                                     pi_description    => 'CREATE ROLL UP INPUT DATA TABLE',
                                     pi_ddl            => V_CR_CREATE_INPUT_DATA,
                                     pi_undo_ddl       => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' ||
                                                          CON_INPUT_DATA_TABLE ||
                                                          ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' ||
                                                          CON_INPUT_DATA_TABLE ||
                                                          '''; END LOOP; END;',
                                     pi_run_id         => pin_run_id);

    -- create index
    IF (pin_date_period_column IS NOT NULL) THEN
      -- if the entity key field is number type
      IF (V_ENTITY_IS_NUMBER = 6) THEN
        IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          CREDITING.CR_CREATE_INDEX('CREATE INDEX ' ||
                                    CON_INPUT_DATA_TABLE_INDEX || ' ON ' ||
                                    CON_INPUT_DATA_TABLE ||
                                    '(ENTITY, DATE_FIELD) TABLESPACE ' || USER ||
                                    '_IND');
        ELSE
          CREDITING.CR_CREATE_INDEX('CREATE INDEX ' ||
                                    CON_INPUT_DATA_TABLE_INDEX || ' ON ' ||
                                    CON_INPUT_DATA_TABLE ||
                                    '(ENTITY, START_DATEE, END_DATEE) TABLESPACE ' || USER ||
                                    '_IND');
        END IF;
      ELSE
        IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
          CREDITING.CR_CREATE_INDEX('CREATE INDEX ' ||
                                    CON_INPUT_DATA_TABLE_INDEX || ' ON ' ||
                                    CON_INPUT_DATA_TABLE ||
                                    '(UPPER(ENTITY), DATE_FIELD) TABLESPACE ' || USER ||
                                    '_IND');
        ELSE
          CREDITING.CR_CREATE_INDEX('CREATE INDEX ' ||
                                    CON_INPUT_DATA_TABLE_INDEX || ' ON ' ||
                                    CON_INPUT_DATA_TABLE ||
                                    '(UPPER(ENTITY), START_DATEE, END_DATEE) TABLESPACE ' || USER ||
                                    '_IND');
        END IF;
      END IF;
    END IF;

    -- INSERT_LOGS ('OUT CREDITING.CR_CREATE_INPUT_DATA  -- FINAL -- CREDITING.CR_CREATE_INDEX DONE');

  END CR_CREATE_INPUT_DATA;

  -----------------------------------------------------------
  -----------------------------------------------------------

  PROCEDURE CR_CREATE_CBS_DATA(pin_roll_up_to_type        IN NUMBER,
                               pin_roll_up_from_type      IN NUMBER,
                               pin_level_to               IN NUMBER,
                               pin_date_period_column     IN VARCHAR2,
                               pin_RECORD_BASED_ON_OPTION in number,
                               pin_RECORDS_BETWEEN_OPTION in number,
                               pin_Field_To_Match         in varchar2,
                               pin_start_period_column    IN varchar2,
                               pin_end_period_column      IN varchar2,
                               pin_operation_id           IN NUMBER,
                               pin_run_id                 IN NUMBER) AS
    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_CONN_BY_SELECT_NAME  CONSTANT VARCHAR2(30) := 'CBS' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    v_select_hierarchy    VARCHAR2(32767);
    v_select_in_hierarchy VARCHAR2(32767);
    v_select              CLOB;
    vt_FLD_TIMEUNIT       number;
    v_where_end           VARCHAR2(32767);
    v_join_select         VARCHAR2(32767);
    v_FLD_TIMEUNIT        number;
    v_corr                boolean;
    v_corr_number         number;
    v_corr_alias  VARCHAR2(10);
    v_select_hier         VARCHAR2(32767);
    v_start               VARCHAR2(32767);
    v_mid                 VARCHAR2(32767);
    v_end                 VARCHAR2(32767);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- pin_roll_up_to_type = ' || pin_roll_up_to_type || ' -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_level_to = ' || pin_level_to || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_operation_id = ' || pin_operation_id || ' -- pin_run_id = ' || pin_run_id);

    -- add the inner select
    IF (pin_date_period_column IS NULL) THEN
      -- add the hint framework
      v_select_hierarchy := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                                      'ROLLUP_CONNECT_BY',
                                                                      pin_operation_id) ||
                            'SELECT ' ||
                            COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                         'ROLLUP_CONNECT_BY',
                                                         pin_operation_id);

      v_select := '(' || v_select_hierarchy ||
                  ' LEVEL LVL, ROWNUM AS ROW_NUM,
                                                                    CONNECT_BY_ROOT HIERARCHY_INPUT.ENT_UPPER AS ROOT,
                                                                    HIERARCHY_INPUT.ENT_UPPER,
                                                                    HIERARCHY_INPUT.ENT_LOWER' || case
                    when pin_RECORD_BASED_ON_OPTION = 2 then
                     ', HIERARCHY_INPUT.' || pin_start_period_column || ' ' ||
                     pin_start_period_column || ', HIERARCHY_INPUT.' ||
                     pin_end_period_column || ' ' || pin_end_period_column
                  end;
    ELSE
      -- add the hint framework
      v_select_hierarchy    := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                                         'ROLLUP_CONNECT_BY',
                                                                         pin_operation_id) ||
                               'SELECT ' ||
                               COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                            'ROLLUP_CONNECT_BY',
                                                            pin_operation_id);
      v_select_in_hierarchy := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                                         'ROLLUP_CONNECT_BY_IN',
                                                                         pin_operation_id) ||
                               'SELECT ' ||
                               COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                            'ROLLUP_CONNECT_BY_IN',
                                                            pin_operation_id);

      -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- v_select_hierarchy = ' || v_select_hierarchy || ' -- v_select_in_hierarchy = ' || v_select_in_hierarchy);
      v_select := '(' || v_select_hierarchy ||
                  ' LVL,
                                                           ROOT_START,
                                                           ROOT_END,
                                                           (SELECT MAX(TO_DATE(NEW_STR, ''mm/dd/yyyy''))
                                                            FROM XMLTABLE(''R/C'' PASSING
                                                                          XMLTYPE(NVL(PATH_START_DATE, ''<R></R>'')) COLUMNS
                                                                          NEW_STR VARCHAR2(100) PATH ''.'')) MAX_START_DATE,
                                                           (SELECT MIN(TO_DATE(NEW_STR, ''mm/dd/yyyy''))
                                                            FROM XMLTABLE(''R/C'' PASSING
                                                                          XMLTYPE(NVL(PATH_END_DATE, ''<R></R>'')) COLUMNS
                                                                          NEW_STR VARCHAR2(100) PATH ''.'')) MIN_END_DATE,
                                                           ROWNUM ROW_NUM,
                                                           ROOT,
                                                           ENT_UPPER,
                                                           ENT_LOWER
                                              FROM (' ||
                  v_select_in_hierarchy ||
                  ' LEVEL LVL,
                                                    CONNECT_BY_ROOT HIERARCHY_INPUT.START_DATE ROOT_START,
                                                    CONNECT_BY_ROOT HIERARCHY_INPUT.END_DATE ROOT_END,
                                                    CONNECT_BY_ROOT HIERARCHY_INPUT.ENT_UPPER AS ROOT,
                                                    HIERARCHY_INPUT.ENT_UPPER,
                                                    HIERARCHY_INPUT.ENT_LOWER,
                                                    ''<R><C>'' || SUBSTR(SYS_CONNECT_BY_PATH(NVL(TO_CHAR(HIERARCHY_INPUT.START_DATE, ''mm/dd/yyyy''), ''01/01/1900''), ''</C><C>''), 8) || ''</C></R>'' PATH_START_DATE,
                                                    ''<R><C>'' || SUBSTR(SYS_CONNECT_BY_PATH(NVL(TO_CHAR(HIERARCHY_INPUT.END_DATE, ''mm/dd/yyyy''), ''12/31/1900''), ''</C><C>''), 8) || ''</C></R>'' PATH_END_DATE';
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- 1. v_select = ' || v_select);
    ---add teh field based chekc here
    if pin_RECORD_BASED_ON_OPTION = 2 then
      select max(FLD_TIMEUNIT)
        into vt_FLD_TIMEUNIT
        from fields
       where FLD_COLUMN_NAME = pin_start_period_column;

      select max(FLD_TIMEUNIT)
        into v_FLD_TIMEUNIT
        from fields
       where FLD_COLUMN_NAME = pin_Field_To_Match;

      v_join_select := v_join_select || '  left join INPD' || pin_run_id ||
                       CR_SEQ.CURRVAL ||
                       ' IP on IP.ENTITY_INT_ID = HIERARCHY_INPUT.ENT_LOWER
                      and HIERARCHY_INPUT.ENT_LOWER_TYPE = ' ||
                       pin_roll_up_from_type;

      if v_FLD_TIMEUNIT is not null then
        v_join_select := v_join_select ||
                         ' left outer join tu_periods_range tupr_cre on IP.C_0_0_' ||
                         pin_Field_To_Match || ' = tupr_cre.tupr_id ';
      end if;

      if vt_FLD_TIMEUNIT is not null then
        if (v_FLD_TIMEUNIT is not null) then
          select count(*)
            into v_corr_number
            from dual
           where exists (select *
                    from TU_CORR_MAT_VIEW
                   where ((tuc_tu_id = vt_FLD_TIMEUNIT and
                         tuc_tu_id_corr = v_FLD_TIMEUNIT) /* or
                                                                                                                     (tuc_tu_id = v_FLD_TIMEUNIT and tuc_tu_id_corr = vt_FLD_TIMEUNIT)*/
                         )
                     and rownum = 1);
      /*    commons_utils.insert_logs('v_corr_number '||v_corr_number);*/
          v_corr := case
                      when v_corr_number = 1 then
                       true
                      else
                       false
                    end;

      v_corr_alias :=  case
                      when v_corr_number = 1 then
                       '_corr'
                      else
                       null
                    end;
        end if;

        if v_corr then

          v_join_select := v_join_select ||
                           ' left outer join TU_CORR_MAT_VIEW tuprs on  tuprs.tupr_id=' ||
                           'HIERARCHY_INPUT' || '.' ||
                           pin_start_period_column ||
                           '   and tuprs.TUC_TU_ID=' || vt_FLD_TIMEUNIT ||
                           ' and tuprs.TUC_TU_ID_CORR=' || v_FLD_TIMEUNIT;
          v_join_select := v_join_select ||
                           ' left outer join TU_CORR_MAT_VIEW tupre on  tupre.tupr_id=' ||
                           'HIERARCHY_INPUT' || '.' ||
                           pin_end_period_column ||
                           '   and tupre.TUC_TU_ID=' || vt_FLD_TIMEUNIT ||
                           ' and tupre.TUC_TU_ID_CORR=' || v_FLD_TIMEUNIT;
        else

          v_join_select := v_join_select ||
                           ' left outer join tu_periods_range tuprs
                   on HIERARCHY_INPUT.' ||
                           pin_start_period_column || ' = tuprs.tupr_id';

          v_join_select := v_join_select ||
                           ' left outer join tu_periods_range tupre
                   on HIERARCHY_INPUT.' ||
                           pin_end_period_column || ' = tupre.tupr_id';

        end if;
      end if;

      if pin_RECORDS_BETWEEN_OPTION in (1, 2) or
         pin_RECORDS_BETWEEN_OPTION is null then
        v_start := v_start ||
                   ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                     when v_FLD_TIMEUNIT is not null then
                      case
                        when pin_RECORDS_BETWEEN_OPTION = 1 or pin_RECORDS_BETWEEN_OPTION is null then
                         'tupr_cre.tupr_start_date'
                        else
                         'tupr_cre.tupr_end_date'
                      end
                     else
                      'IP.C_0_0_' || pin_Field_To_Match
                   end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) between ';

        v_mid := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tuprs.tupr_start_date' ||v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_start_period_column
                 end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy'')) and ';

        v_end := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tupre.tupr_end_date' || v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_end_period_column
                 end || ',
                                to_date(''31/12/9999'', ''dd/mm/yyyy''))

           ';

        v_where_end   := v_start || ' prior ' || v_mid || ' prior ' ||
                         v_end;
        v_select_hier := v_start || v_mid || v_end;
        v_start       := null;
        v_mid         := null;
        v_end         := null;
      elsif (pin_RECORDS_BETWEEN_OPTION = 3) then
       /* v_start := ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                     when v_FLD_TIMEUNIT is not null then
                      'tupr_cre.tupr_start_date'
                     else
                      'IP.C_0_0_' || pin_Field_To_Match
                   end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) between ';

        \*   ||'prior '||*\

        v_mid := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tuprs.tupr_start_date' || v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_start_period_column
                 end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy'')) and ';
        \*   ||'prior '||*\

        v_end := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tupre.tupr_end_date' ||v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_end_period_column
                 end || ',
                                to_date(''31/12/9999'', ''dd/mm/yyyy''))

           ';*/
            v_start := ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                     when v_FLD_TIMEUNIT is not null then
                      'tupr_cre.tupr_start_date'
                     else
                      'IP.C_0_0_' || pin_Field_To_Match
                   end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) <= ';
        /*   ||'prior '||*/

        v_mid := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tupre.tupr_end_date' ||v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_start_period_column
                 end || ',
                                to_date(''31/12/1999'', ''dd/mm/yyyy''))' ||
                 ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                   when v_FLD_TIMEUNIT is not null then
                    'tupr_cre.tupr_end_date'
                   else
                    'IP.C_0_0_' || pin_Field_To_Match
                 end || ',
                                to_date(''31/12/1999'', ''dd/mm/yyyy''))) >=';

        /*  ' prior '*/

        v_end := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tuprs.tupr_start_date' || v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_end_period_column
                 end || ',
                                to_date(''01/01/1900'', ''dd/mm/yyyy''))

           ';

        v_where_end   := v_start || ' prior ' || v_mid || ' prior ' ||
                         v_end;
        v_select_hier := v_start || v_mid || v_end;
        v_start       := null;
        v_mid         := null;
        v_end         := null;

      elsif (pin_RECORDS_BETWEEN_OPTION = 4) then
        v_start := ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                     when v_FLD_TIMEUNIT is not null then
                      'tupr_cre.tupr_start_date'
                     else
                      'IP.C_0_0_' || pin_Field_To_Match
                   end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) >= ';
        /*   ||'prior '||*/

        v_mid := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tuprs.tupr_start_date' ||v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_start_period_column
                 end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))' ||
                 ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                   when v_FLD_TIMEUNIT is not null then
                    'tupr_cre.tupr_end_date'
                   else
                    'IP.C_0_0_' || pin_Field_To_Match
                 end || ',
                                to_date(''31/12/1999'', ''dd/mm/yyyy''))) <=';

        /*  ' prior '*/

        v_end := ' nvl(' || case
                   when vt_FLD_TIMEUNIT is not null then
                    ' tupre.tupr_end_date' || v_corr_alias
                   else
                    ' HIERARCHY_INPUT.' || pin_end_period_column
                 end || ',
                                to_date(''31/12/9999'', ''dd/mm/yyyy''))

           ';

        v_where_end   := v_start || ' prior ' || v_mid || ' prior ' ||
                         v_end;
        v_select_hier := v_start || v_mid || v_end;
        v_start       := null;
        v_mid         := null;
        v_end         := null;

      end if;

    end if;

    -- add the from, where and connect by clauses
    v_select := v_select || ' FROM ' || CON_HIERARCHY_TABLE_NAME ||
                ' HIERARCHY_INPUT ' || v_join_select || ' WHERE ';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- 2. v_select = ' || v_select);
    -- if the level to roll up to is given as input
    IF (pin_level_to <> 0) THEN
      v_select := v_select || 'LEVEL <= ' || pin_level_to || ' AND ';
    END IF;
    v_select := v_select || ' HIERARCHY_INPUT.ENT_LOWER_TYPE = ' ||
                pin_roll_up_from_type;
    v_select := v_select || v_select_hier;

   /* if pin_RECORD_BASED_ON_OPTION = 2 then

      if pin_RECORDS_BETWEEN_OPTION in (1, 2) or
         pin_RECORDS_BETWEEN_OPTION is null then
        v_select := v_select ||
                    ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                      when v_FLD_TIMEUNIT is not null then
                       case
                         when pin_RECORDS_BETWEEN_OPTION = 1 or pin_RECORDS_BETWEEN_OPTION is null then
                          'tupr_cre.tupr_start_date'
                         else
                          'tupr_cre.tupr_end_date'
                       end
                      else
                       'IP.C_0_0_' || pin_Field_To_Match
                    end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) between  nvl(' || case
                      when vt_FLD_TIMEUNIT is not null then
                       ' tuprs.tupr_start_date' || case
                         when v_corr then
                          '_corr'
                       end
                      else
                       ' HIERARCHY_INPUT.' || pin_start_period_column
                    end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy'')) and  nvl(' || case
                      when vt_FLD_TIMEUNIT is not null then
                       ' tupre.tupr_end_date' || case
                         when v_corr then
                          '_corr'
                       end
                      else
                       ' HIERARCHY_INPUT.' || pin_end_period_column
                    end || ',
                                to_date(''31/12/9999'', ''dd/mm/yyyy''))

           ';
      elsif (pin_RECORDS_BETWEEN_OPTION = 3) then
        v_select := v_select ||
                    ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                      when v_FLD_TIMEUNIT is not null then
                       'tupr_cre.tupr_start_date'
                      else
                       'IP.C_0_0_' || pin_Field_To_Match
                    end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) between  nvl(' || case
                      when vt_FLD_TIMEUNIT is not null then
                       ' tuprs.tupr_start_date' || case
                         when v_corr then
                          '_corr'
                       end
                      else
                       ' HIERARCHY_INPUT.' || pin_start_period_column
                    end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy'')) and  nvl(' || case
                      when vt_FLD_TIMEUNIT is not null then
                       ' tupre.tupr_end_date' || case
                         when v_corr then
                          '_corr'
                       end
                      else
                       ' HIERARCHY_INPUT.' || pin_end_period_column
                    end || ',
                                to_date(''31/12/9999'', ''dd/mm/yyyy''))

           ';
      elsif (pin_RECORDS_BETWEEN_OPTION = 4) then
        v_select := v_select ||
                    ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                      when v_FLD_TIMEUNIT is not null then
                       'tupr_cre.tupr_start_date'
                      else
                       'IP.C_0_0_' || pin_Field_To_Match
                    end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))) >=  nvl(' || case
                      when vt_FLD_TIMEUNIT is not null then
                       ' tuprs.tupr_start_date' || case
                         when v_corr then
                          '_corr'
                       end
                      else
                       ' HIERARCHY_INPUT.' || pin_start_period_column
                    end || ',
                                to_date(''1/1/1900'', ''dd/mm/yyyy''))' ||
                    ' and  decode( IP.ENTITY_INT_ID, null,null,nvl(' || case
                      when v_FLD_TIMEUNIT is not null then
                       'tupr_cre.tupr_end_date'
                      else
                       'IP.C_0_0_' || pin_Field_To_Match
                    end || ',
                                to_date(''31/12/1999'', ''dd/mm/yyyy''))) <=' ||
                    '  nvl(' || case
                      when vt_FLD_TIMEUNIT is not null then
                       ' tupre.tupr_end_date' || case
                         when v_corr then
                          '_corr'
                       end
                      else
                       ' HIERARCHY_INPUT.' || pin_end_period_column
                    end || ',
                                to_date(''31/12/9999'', ''dd/mm/yyyy''))

           ';

      end if;

    end if;*/
    ---insert check here
    v_select := v_select || ' START WITH HIERARCHY_INPUT.ENT_UPPER_TYPE = ' ||
                pin_roll_up_to_type ||
                ' CONNECT BY NOCYCLE PRIOR HIERARCHY_INPUT.ent_lower = HIERARCHY_INPUT.ent_upper
                                               AND PRIOR HIERARCHY_INPUT.ent_lower_type = HIERARCHY_INPUT.ent_upper_Type';
    v_select := v_select || v_where_end || ')';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- 3. v_select = ' || v_select);

    -- add the entity key field
    v_select := 'SELECT CBS.*, E.' ||
                commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                      pin_roll_up_from_type) ||
                ' ENTI_KEY_FIELD FROM (' || v_select || ') CBS INNER JOIN ' ||
                commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                      ON E.E_INTERNAL_ID = CBS.ENT_LOWER';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- 4. v_select = ' || v_select);

    -- create the connect by table
    v_select := 'CREATE TABLE ' || CON_CONN_BY_SELECT_NAME || ' TABLESPACE ' || USER ||
                '_OUT AS ' || v_select || CASE
                  WHEN pin_date_period_column IS NULL THEN
                   ''
                  ELSE
                   ')'
                END;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_CBS_DATA  -- 5. v_select = ' || v_select);

    v_stamp := 'CREDITING.CR_ROLLUP - create connect by table - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(v_select),
                               ',v_create_htable => <value>',
                               v_stamp);
    END;
 /*   commons_utils.INSERT_LOGS('v_select in cr_create_cbs_data ' ||
                              v_select);*/
    COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => COMMONS_DDL_HANDLING.get_transaction_id,
                                     pi_description    => 'CREATE ROLL UP CONNECT BY TABLE',
                                     pi_ddl            => v_select,
                                     pi_undo_ddl       => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' ||
                                                          CON_CONN_BY_SELECT_NAME ||
                                                          ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' ||
                                                          CON_CONN_BY_SELECT_NAME ||
                                                          '''; END LOOP; END;',
                                     pi_run_id         => pin_run_id);

    -- INSERT_LOGS ('OUT CREDITING.CR_CREATE_CBS_DATA  -- FINAL -- CREATE TABLE DONE for v_select = ' || v_select);
  END CR_CREATE_CBS_DATA;
  -----------------------------------------------------------
  procedure CR_Timebased_filtering(pin_Field_To_Match      in varchar2,
                                   PIN_CRSTRUCT_TABLE      in varchar2,
                                   PIN_CR_TABLE            in varchar2, /* INPUT_DATA*/
                                   pin_start_period_column in varchar2,
                                   pin_end_period_column   in varchar2,
                                   PIN_FILTER_TABLE        in varchar2,
                                   RECORDS_BETWEEN_OPTION  in number,
                                   POUT_Query              out clob,
                                   POUT_JOIN               out boolean,
                                   POUT_JOIN_CR_TABLE      OUT VARCHAR2,
                                   POUT_JOIN_FILTER_TABLE  OUT VARCHAR2) as
    v_FLD_TIMEUNIT  number;
    vt_FLD_TIMEUNIT number;
    v_FLD_NVL       varchar2(100);
    v_select        clob;
    v_corr_number   number;
    v_corr          boolean;
    /*  v_Join number:=0;*/
  begin

  /*  commons_utils.INSERT_LOGS('In CR_Timebased_filtering ');*/
    /*  select max(FLD_TIMEUNIT), max(FLD_IS_PREDEFINED)
     into v_FLD_TIMEUNIT, v_FLD_IS_PREDEFINED
     from fields
    where FLD_COLUMN_NAME = pin_Field_To_Match;*/

    select max(fields.FLD_TIMEUNIT),
           max(decode(TC_LOGIC_TYPE,
                      3,
                      '1/1/1900',
                      6,
                      '1/1/1900',
                      4,
                      '31/12/9999',
                      7,
                      '31/12/9999',
                      '01/01/1800'))
      into v_FLD_TIMEUNIT, v_FLD_NVL
      from table_columns

     inner join fields
        on table_columns.tc_fld_id = fields.fld_id
     inner join tables
        on table_columns.tc_tables_id = tables.tables_id
     where tables.tables_physical_name = PIN_CRSTRUCT_TABLE
       and table_columns.tc_physical_name = pin_Field_To_Match;

    select max(FLD_TIMEUNIT)
      into vt_FLD_TIMEUNIT
      from fields
     where FLD_COLUMN_NAME = pin_start_period_column;

    select count(*)
      into v_corr_number
      from dual
     where exists (select *
              from TU_CORR_MAT_VIEW
             where ((tuc_tu_id = nvl(vt_FLD_TIMEUNIT, -1) and
                   tuc_tu_id_corr = nvl(v_FLD_TIMEUNIT, -1) /* or
                                                                                                   (tuc_tu_id = v_FLD_TIMEUNIT and tuc_tu_id_corr = vt_FLD_TIMEUNIT)*/
                   ))
               and rownum = 1);
    v_corr := case
                when v_corr_number = 1 then
                 true
                else
                 false
              end;

/*    commons_utils.INSERT_LOGS('v_FLD_TIMEUNIT ' || v_FLD_TIMEUNIT);
    commons_utils.INSERT_LOGS('v_FLD_NVL ' || v_FLD_NVL);
    commons_utils.INSERT_LOGS('vt_FLD_TIMEUNIT ' || vt_FLD_TIMEUNIT);
    commons_utils.INSERT_LOGS('RECORDS_BETWEEN_OPTION ' ||
                              RECORDS_BETWEEN_OPTION);*/

   /* if (v_FLD_TIMEUNIT is not null and vt_FLD_TIMEUNIT is not null and
       v_corr = false) then
      POUT_JOIN := true;
   \*   commons_utils.INSERT_LOGS('here date-period');*\
      v_select           := v_select || ' left outer join tu_periods_range tupr_cre
                   on ' || PIN_CR_TABLE ||
                            '.C_0_0_' || pin_Field_To_Match ||
                            ' = tupr_cre.tupr_id';
      POUT_JOIN_CR_TABLE := v_select;

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hrst on  tupr_hrst.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_start_period_column;
      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hren on  tupr_hren.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_end_period_column;

      \*  v_select:=v_select||POUT_JOIN_FILTER_TABLE;*\

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where ' ||
                                ' nvl(tupr_cre.TUPR_START_DATE,to_date(''' ||
                                v_FLD_NVL ||
                                ''',''dd/mm/yyyy'')) BETWEEN nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy''))
                    AND nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy''))';

      \* ||'nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy'')) < =
      nvl(tupr_cre.TUPR_END_DATE,to_date(''' || case
         when v_FLD_IS_PREDEFINED = 1 then
          '31/12/9999'
         else
          '01/01/1800'
       end ||
       ''',''dd/mm/yyyy'')) OR
       nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy'')) >=
       nvl(tupr_cre.TUPR_START_DATE,to_date(''' || case
         when v_FLD_IS_PREDEFINED = 1 then
          '1/1/1900'
         else
          '01/01/1800'
       end || ''',''dd/mm/yyyy''))'*\
      \* ;*\
      v_select := v_select || POUT_JOIN_FILTER_TABLE;

      --match timeunits
    els*/if (nvl(v_FLD_TIMEUNIT, -1) = nvl(vt_FLD_TIMEUNIT, -1)) then
      ----if tehre was a match and one was nul means other was null too which implies we are comparing dates
      if (v_FLD_TIMEUNIT is null) then
    /*    commons_utils.INSERT_LOGS('here dates');*/
        POUT_JOIN              := false;
        POUT_JOIN_FILTER_TABLE := v_select || '  nvl(' || PIN_CR_TABLE ||
                                  '.C_0_0_' || pin_Field_To_Match ||
                                  ',to_date(''' || v_FLD_NVL ||
                                  ''',''dd/mm/yyyy''))
                   between nvl(' ||
                                  PIN_FILTER_TABLE || '.' ||
                                  pin_start_period_column ||
                                  ',to_date(''1/1/1900'',''dd/mm/yyyy''))
                    and nvl(' ||
                                  PIN_FILTER_TABLE || '.' ||
                                  pin_end_period_column ||
                                  ',to_date(''31/12/9999'',''dd/mm/yyyy''))';

        v_select := v_select || POUT_JOIN_FILTER_TABLE;
      else
        --both time same tiem units
        POUT_JOIN := true;
       /* commons_utils.INSERT_LOGS('here date-period');*/
        v_select           := v_select || ' left outer join tu_periods_range tupr_cre
                   on ' || PIN_CR_TABLE ||
                              '.C_0_0_' || pin_Field_To_Match ||
                              ' = tupr_cre.tupr_id';
        POUT_JOIN_CR_TABLE := v_select;

        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  ' left outer join tu_periods_range tupr_hrst on  tupr_hrst.tupr_id=' ||
                                  PIN_FILTER_TABLE || '.' ||
                                  pin_start_period_column;
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  ' left outer join tu_periods_range tupr_hren on  tupr_hren.tupr_id=' ||
                                  PIN_FILTER_TABLE || '.' ||
                                  pin_end_period_column;

        /*  v_select:=v_select||POUT_JOIN_FILTER_TABLE;*/

        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where ' ||
                                  ' nvl(tupr_cre.TUPR_START_DATE,to_date(''' ||
                                  v_FLD_NVL ||
                                  ''',''dd/mm/yyyy'')) BETWEEN nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy''))
                    AND nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy''))';

        /* ||'nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy'')) < =
        nvl(tupr_cre.TUPR_END_DATE,to_date(''' || case
           when v_FLD_IS_PREDEFINED = 1 then
            '31/12/9999'
           else
            '01/01/1800'
         end ||
         ''',''dd/mm/yyyy'')) OR
         nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy'')) >=
         nvl(tupr_cre.TUPR_START_DATE,to_date(''' || case
           when v_FLD_IS_PREDEFINED = 1 then
            '1/1/1900'
           else
            '01/01/1800'
         end || ''',''dd/mm/yyyy''))'*/
        /* ;*/
        v_select := v_select || POUT_JOIN_FILTER_TABLE;

      end if;

    elsif
    -----field tu is corresponding to hirarchy tu hence RECORDS_BETWEEN_OPTION is null
     (RECORDS_BETWEEN_OPTION is null and v_FLD_TIMEUNIT is not null and
     vt_FLD_TIMEUNIT is not null) then
      POUT_JOIN := true;
      v_select  := v_select || ' left outer join TU_CORR_MAT_VIEW tupr_cre
                   on ' || PIN_CR_TABLE || '.C_0_0_' ||
                   pin_Field_To_Match ||
                   ' = tupr_cre.tupr_id
                     and tupr_cre.TUC_TU_ID=' ||
                   v_FLD_TIMEUNIT || ' and tupr_cre.TUC_TU_ID_CORR=' ||
                   vt_FLD_TIMEUNIT /*||
                                                       ' TUPR_START_DATE'*/
       ;
      /*  v_select  := v_select || ' left outer join tu_periods_range tupr_cre
      on ' || PIN_CR_TABLE || '.C_0_0_' ||
        pin_Field_To_Match || ' = tupr_cre.tupr_id';
      */

      POUT_JOIN_CR_TABLE := v_select;

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hrst on  tupr_hrst.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_start_period_column;

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hren on  tupr_hren.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_end_period_column;
      v_select               := v_select || POUT_JOIN_FILTER_TABLE;

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where ' ||
                                ' nvl(tupr_cre.TUPR_START_DATE_CORR,to_date(''' ||
                                v_FLD_NVL ||
                                ''',''dd/mm/yyyy'')) BETWEEN nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy''))
                    AND nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy''))';

      v_select := v_select || POUT_JOIN_FILTER_TABLE;
      /* ||

      'nvl(tupr_hrst.TUPR_START_DATE_CORR,to_date(''1/1/1900'',''dd/mm/yyyy'')) <
      nvl(tupr_cre.TUPR_END_DATE,to_date(''' || case
         when v_FLD_IS_PREDEFINED = 1 then
          '31/12/9999'
         else
          '01/01/1800'
       end ||
       ''',''dd/mm/yyyy'')) and
       nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy'')) >
       nvl(tupr_cre.TUPR_START_DATE,to_date(''' || case
         when v_FLD_IS_PREDEFINED = 1 then
          '1/1/1900'
         else
          '01/01/1800'
       end || ''',''dd/mm/yyyy''))'*/
      /*  ;*/

      /*end if;*/
    elsif

    ---check if correspondace exists

    ----- hirarchy tu  is corresponding to field tu hence RECORDS_BETWEEN_OPTION is has  value
     (RECORDS_BETWEEN_OPTION is not null and v_FLD_TIMEUNIT is not null and
     vt_FLD_TIMEUNIT is not null /*and v_corr*/) then
      POUT_JOIN := true;

      /*      v_select  := v_select || ' left outer join TU_CORR_MAT_VIEW tupr_cre
      on ' || PIN_CR_TABLE || '.C_0_0_' ||
      pin_Field_To_Match ||
      ' = tupr_cre.tupr_id
        and tupr_cre.TUC_TU_ID=' ||vt_FLD_TIMEUNIT  ||
      ' and tupr_cre.TUC_TU_ID_CORR=' || v_FLD_TIMEUNIT
      ;*/

      v_select := v_select || ' left outer join tu_periods_range tupr_cre
                   on ' || PIN_CR_TABLE || '.C_0_0_' ||
                  pin_Field_To_Match || ' = tupr_cre.tupr_id';

      POUT_JOIN_CR_TABLE     := v_select;
      if(v_corr) then
      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join TU_CORR_MAT_VIEW tupr_hrst on  tupr_hrst.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_start_period_column ||
                                '   and tupr_hrst.TUC_TU_ID=' ||
                                vt_FLD_TIMEUNIT ||
                                ' and tupr_hrst.TUC_TU_ID_CORR=' ||
                                v_FLD_TIMEUNIT;
       else
          POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hrst on  tupr_hrst.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_start_period_column ||' ';
                               /* '   and tupr_hrst.TUC_TU_ID=' ||
                                vt_FLD_TIMEUNIT ||
                                ' and tupr_hrst.TUC_TU_ID_CORR=' ||
                                v_FLD_TIMEUNIT;*/
       end if;
         if(v_corr) then
      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join TU_CORR_MAT_VIEW tupr_hren on  tupr_hren.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_end_period_column ||
                                '   and tupr_hren.TUC_TU_ID=' ||
                                vt_FLD_TIMEUNIT ||
                                ' and tupr_hren.TUC_TU_ID_CORR=' ||
                                v_FLD_TIMEUNIT;

         else
            POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hren on  tupr_hren.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_end_period_column ||' ';
                              /*  '   and tupr_hren.TUC_TU_ID=' ||
                                vt_FLD_TIMEUNIT ||
                                ' and tupr_hren.TUC_TU_ID_CORR=' ||
                                v_FLD_TIMEUNIT;*/
         end if;

      /* v_select:=v_select||POUT_JOIN_FILTER_TABLE;*/
      ----FIRST(1),LAST(2),Any(3),EVERY(4);
      if (RECORDS_BETWEEN_OPTION in (1, 2)) then
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where ' ||
                                  ' nvl(tupr_cre.' || case
                                    when RECORDS_BETWEEN_OPTION = 1 then
                                     'TUPR_START_DATE'
                                    when RECORDS_BETWEEN_OPTION = 2 then
                                     'TUPR_END_DATE'
                                  end || ',to_date(''' || v_FLD_NVL ||
                                  ''',''dd/mm/yyyy'')) ';
        POUT_JOIN_CR_TABLE     := v_select;
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  ' BETWEEN nvl(tupr_hrst.TUPR_START_DATE'||case when v_corr then '_CORR' else '' end||',to_date(''1/1/1900'',''dd/mm/yyyy''))
                    AND nvl(tupr_hren.TUPR_END_DATE'||case when v_corr then '_CORR' else '' end||',to_date(''31/12/9999'',''dd/mm/yyyy''))';

        v_select := v_select || POUT_JOIN_FILTER_TABLE;

      elsif (RECORDS_BETWEEN_OPTION in (3)) then

        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where ' ||
                                  ' nvl(tupr_cre.' || 'TUPR_START_DATE' ||
                                  ',to_date(''' || v_FLD_NVL ||
                                  ''',''dd/mm/yyyy'')) ';

        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  '<= nvl(tupr_hren.TUPR_END_DATE'||case when v_corr then '_CORR' else '' end||',to_date(''31/12/9999'',''dd/mm/yyyy''))';
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  ' and   nvl(tupr_cre.' || 'TUPR_END_DATE' ||
                                  ',to_date(''' || v_FLD_NVL ||
                                  ''',''dd/mm/yyyy'')) ';
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  '>= nvl(tupr_hrst.TUPR_START_DATE'||case when v_corr then '_CORR' else '' end||',to_date(''1/1/1900'',''dd/mm/yyyy''))';

        v_select := v_select || POUT_JOIN_FILTER_TABLE;

      elsif (RECORDS_BETWEEN_OPTION in (4)) then
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where ' ||
                                  ' nvl(tupr_cre.' || 'TUPR_END_DATE' ||
                                  ',to_date(''' || v_FLD_NVL ||
                                  ''',''dd/mm/yyyy'')) ';

        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  '<= nvl(tupr_hren.TUPR_END_DATE'||case when v_corr then '_CORR' else '' end||',to_date(''31/12/9999'',''dd/mm/yyyy''))';
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  ' and   nvl(tupr_cre.' ||
                                  'TUPR_START_DATE' || ',to_date(''' ||
                                  v_FLD_NVL || ''',''dd/mm/yyyy'')) ';
        POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                  '>= nvl(tupr_hren.TUPR_START_DATE'||case when v_corr then '_CORR' else '' end||',to_date(''31/12/9999'',''dd/mm/yyyy''))';

        v_select := v_select || POUT_JOIN_FILTER_TABLE;
      end if;

    elsif (v_FLD_TIMEUNIT is null and vt_FLD_TIMEUNIT is not null) then
      POUT_JOIN := true;
      /*v_select  := v_select || ' left outer join tu_periods_range tupr_cre
      on ' || PIN_CR_TABLE || '.C_0_0_' ||
      pin_Field_To_Match || ' = tupr_cre.tupr_id';*/

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hrst on  tupr_hrst.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_start_period_column;
      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE ||
                                ' left outer join tu_periods_range tupr_hren on  tupr_hren.tupr_id=' ||
                                PIN_FILTER_TABLE || '.' ||
                                pin_end_period_column;

      /* v_select := v_select || ' where ' ||
      ' nvl(tupr_cre.TUPR_START_DATE,to_date(''' || v_FLD_NVL||
      ''',''dd/mm/yyyy'')) BETWEEN nvl(tupr_hrst.TUPR_START_DATE_CORR,to_date(''1/1/1900'',''dd/mm/yyyy''))
      AND nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy''))'*/

      POUT_JOIN_FILTER_TABLE := POUT_JOIN_FILTER_TABLE || ' where  nvl( ' ||
                                PIN_CR_TABLE || '.C_0_0_' ||
                                pin_Field_To_Match || ',to_date(''' ||
                                v_FLD_NVL ||
                                ''',''dd/mm/yyyy''))
                   between nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy''))
                    and nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy''))';
      v_select               := v_select || POUT_JOIN_FILTER_TABLE;
    end if;

    POUT_Query := v_select;

  /*  commons_utils.INSERT_LOGS('POUT_Query ' || POUT_Query);*/

  exception
    when others then
    null;
     /* commons_utils.INSERT_LOGS(to_char(SQLCODE));
      commons_utils.INSERT_LOGS(SQLERRM);*/
  end CR_Timebased_filtering;


  -----------------------------------------------------------
  PROCEDURE CR_CREATE_INSERT_DATA(pin_entity_field               IN BOOLEAN,
                                  pin_entity_roll_up_from_column IN VARCHAR2,
                                  pin_inputview_columns          IN VARCHAR2,
                                  pin_roll_up_from_type          IN NUMBER,
                                  pin_roll_up_to_type            IN NUMBER,
                                  pin_level_from                 IN NUMBER,
                                  pin_date_period_column         IN VARCHAR2,
                                  pin_INPUT_DATA_VALUES_NO       IN NUMBER,
                                  pin_INPUTDATA_NOROLLUP_COLUMNS IN VARCHAR2,
                                  pin_is_effective_period        IN NUMBER,
                                  pin_process_run_for            IN NUMBER,
                                  pin_RECORDS_BETWEEN_OPTION     IN number,
                                  pin_RECORD_BASED_ON_OPTION     IN number,
                                  pin_Field_To_Match             in varchar2,
                                  pin_start_period_column        in varchar2,
                                  pin_end_period_column          in varchar2,
                                  /* pin_start_period_column          IN VARCHAR2,*/
                                  PIN_CRSTRUCT_TABLE in varchar2,
                                  pin_operation_id      IN NUMBER,
                                  pin_run_id            IN NUMBER,
                                  pin_input_data_entity IN VARCHAR2,
                                  pin_aggregate_values  IN NUMBER) AS
    CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_CONN_BY_SELECT_NAME  CONSTANT VARCHAR2(30) := 'CBS' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    v_select            CLOB;
    V_FIELD_TYPE        NUMBER(10);
    v_filter            CLOB;
    v_insert_data_hint  VARCHAR2(32767);
    v_FLD_TIMEUNIT      number;
    vt_FLD_TIMEUNIT     number;
    v_FLD_IS_PREDEFINED number;
    v_return_clause     clob;
    v_join              boolean;
     v_JOIN_CR_TABLE VARCHAR2(1000);
                                   v_JOIN_FILTER_TABLE VARCHAR2(1000);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- pin_ENTITY_FIELD = ' || CASE WHEN pin_ENTITY_FIELD THEN 1 ELSE 0 END || ' -- pin_entity_roll_up_from_column = ' || pin_entity_roll_up_from_column || ' -- pin_inputview_columns = ' || pin_inputview_columns || '-- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_roll_up_to_type = ' || pin_roll_up_to_type || ' -- pin_level_from = ' || pin_level_from || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_INPUT_DATA_VALUES_NO = ' || pin_INPUT_DATA_VALUES_NO || ' -- pin_INPUTDATA_NOROLLUP_COLUMNS = ' || pin_INPUTDATA_NOROLLUP_COLUMNS || ' -- pin_is_effective_period = ' || pin_is_effective_period  || ' -- pin_process_run_for = ' || pin_process_run_for  || ' -- pin_start_period_column = ' || pin_start_period_column || ' -- pin_operation_id = ' || pin_operation_id || ' -- pin_run_id = ' || pin_run_id);

    v_insert_data_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                                    'ROLLUP_INSERT_DATA',
                                                                    pin_operation_id) ||
                          'SELECT ' ||
                          COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                       'ROLLUP_INSERT_DATA',
                                                       pin_operation_id);
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- v_insert_data_hint = ' || v_insert_data_hint);

    -- performance edit row_identifier only for pin_aggregate_values = 1 or pin_no_match for level_from = 0
    v_select := v_insert_data_hint ||
                ' CBS.ROW_NUM, input_data.row_identifier, CBS.root, CBS.ent_lower, CBS.LVL, ' || case
                  WHEN pin_roll_up_from_type = pin_roll_up_to_type THEN
                   'CBS.ENTI_KEY_FIELD ENTITY'
                  ELSE
                   'INPUT_DATA.ENTITY_INT_ID ENTITY'
                END || CASE
                  WHEN (pin_roll_up_from_type = pin_roll_up_to_type) AND
                       (pin_entity_roll_up_from_column IS NOT NULL) AND
                       (instr(',' || pin_inputview_columns || ',',
                              ',' || pin_entity_roll_up_from_column || ',') < 3 AND
                       pin_ENTITY_FIELD) THEN
                   ', INPUT_DATA.ENTITY ENTITY_INT_ID'
                  ELSE
                   ''
                END;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 1 -- v_select = ' || v_select);

    -- if the entities are of the same type
    IF (pin_roll_up_from_type = pin_roll_up_to_type) THEN
      -- add the columns for the values
      FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO LOOP
        v_select := v_select || ', VALUE' || i || ' as VALUE' || i || '';
      END LOOP;
      -- if the entities are of different types
    ELSE
      -- add the columns for the values
      FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO LOOP
        v_select := v_select || ',VALUE' || i;
      END LOOP;
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 2 -- v_select = ' || v_select);

    IF (pin_date_period_column IS NOT NULL) THEN
      SELECT FIELDS.fld_data_type
        INTO V_FIELD_TYPE
        FROM FIELDS
       WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column
         AND ROWNUM = 1;
      v_select := v_select || case
                    when (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) then
                     ', DATE_FIELD'
                    else
                     ', START_DATEE, END_DATEE'
                  END ||
                  ', NVL(MAX_START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) MAX_START_DATE, NVL(MIN_END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) MIN_END_DATE';
    END IF;
    -- add the rows needed by the additional tables
    if (pin_aggregate_values = 0) then
      v_select := v_select || ',' || pin_input_data_entity ||
                  pin_INPUTDATA_NOROLLUP_COLUMNS;
    end if;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 3 -- v_select = ' || v_select);

    -- add the from clause
    if (V_ENTITY_IS_NUMBER = 6) THEN
      -- if the entity key field is number type
      v_select := v_select || ' FROM ' || CON_CONN_BY_SELECT_NAME ||
                  ' CBS
                                      INNER JOIN
                                     ' ||
                  CON_INPUT_DATA_TABLE ||
                  ' INPUT_DATA
                                      ON INPUT_DATA.ENTITY = CBS.ENTI_KEY_FIELD';
    ELSE
      -- if the entity key field is number type
      v_select := v_select || ' FROM ' || CON_CONN_BY_SELECT_NAME ||
                  ' CBS
                                      INNER JOIN
                                     ' ||
                  CON_INPUT_DATA_TABLE ||
                  ' INPUT_DATA
                                      ON UPPER(INPUT_DATA.ENTITY) = UPPER(CBS.ENTI_KEY_FIELD)';
    END IF;

    ---add teh join condition here for teh date

    if (pin_RECORD_BASED_ON_OPTION = 2) then
      /*  TO_DATE(''01/01/1800'',''MM/DD/sYYYY'')*/

      CR_Timebased_filtering(pin_Field_To_Match      => pin_Field_To_Match,
      PIN_CRSTRUCT_TABLE      =>PIN_CRSTRUCT_TABLE,
                             PIN_CR_TABLE            => 'INPUT_DATA',
                             pin_start_period_column => pin_start_period_column,
                             pin_end_period_column   => pin_end_period_column,
                             PIN_FILTER_TABLE        => 'CBS',
                             RECORDS_BETWEEN_OPTION  => pin_RECORDS_BETWEEN_OPTION,
                             POUT_Query              => v_return_clause,
                             POUT_join               => v_join,
                             POUT_JOIN_CR_TABLE=>V_JOIN_CR_TABLE,
                                   POUT_JOIN_FILTER_TABLE=>V_JOIN_FILTER_TABLE);
      v_select := v_select || case
                    when v_join then
                     ' '
                    else
                     ' and '
                  end || v_return_clause;

      /*
      select max(FLD_TIMEUNIT),max(FLD_IS_PREDEFINED) into v_FLD_TIMEUNIT,v_FLD_IS_PREDEFINED from fields where FLD_COLUMN_NAME=pin_Field_To_Match;
        select max(FLD_TIMEUNIT) into vt_FLD_TIMEUNIT from fields where FLD_COLUMN_NAME=pin_start_period_column;

                  if (nvl(v_FLD_TIMEUNIT,-1)=nvl(vt_FLD_TIMEUNIT,-1) ) then

                  if (v_FLD_TIMEUNIT is null) then
                    v_select:=v_select||' and  nvl(INPUT_DATA.C_0_0_'||pin_Field_To_Match||',to_date(''1/1/1900'',''dd/mm/yyyy''))
                    between nvl(CBS.'||pin_start_period_column||',to_date(''1/1/1900'',''dd/mm/yyyy''))
                     and nvl(CBS.'||pin_end_period_column||'''31/12/9999'',''dd/mm/yyyy''))';
                  else
                   v_select:=v_select||' left outer join tu_periods_range tupr_cre
                    on INPUT_DATA.C_0_0_'||pin_Field_To_Match||' = tupr_cre.tupr_id' ;
                   v_select:=v_select||' left outer join tu_periods_range tupr_hrst on  tupr_hrst.tupr_id=cbs.'||pin_start_period_column;
                   v_select:=v_select||' left outer join tu_periods_range tupr_hren on  tupr_hren.tupr_id=cbs.'||pin_end_period_column;
                    v_select:=v_select||' where
                    nvl(tupr_hrst.TUPR_START_DATE,to_date(''1/1/1900'',''dd/mm/yyyy'')) <
                    nvl(tupr_cre.TUPR_END_DATE,to_date('''||case when v_FLD_IS_PREDEFINED=1 then '31/12/9999' else '01/01/1800' end ||''',''dd/mm/yyyy'')) and
                     nvl(tupr_hren.TUPR_END_DATE,to_date(''31/12/9999'',''dd/mm/yyyy'')) >
                     nvl(tupr_cre.TUPR_START_DATE,to_date('''||case when v_FLD_IS_PREDEFINED=1 then '1/1/1900' else '01/01/1800' end||''',''dd/mm/yyyy''))';


                     v_select:=v_select||'left outer join (
                     select
                     decode(CBS.'||pin_start_period_column||' ,null,null,min(TUPR_START_DATE)) TUPR_START_DATE_MIN,
                     decode(CBS.'||pin_end_period_column||' ,null,null,max(TUPR_END_DATE))  TUPR_END_DATE_MAX
                     from  tu_periods_range TUPR_MAX_MIN where TUPR_MAX_MIN.TUPR_ID in (CBS.'||pin_start_period_column||',CBS.'||pin_end_period_column||') )TUPR_MAX_MIN'||
                     ' on TUPR_MAX_MIN.TUPR_ID in (CBS.'||pin_start_period_column||',CBS.'||pin_end_period_column||')'||
                     ' inner join
                     (select tupr_id from tu_periods_range
                     TUPR_ID where
                     TUPR_ID.TUPR_START_DATE<TUPR_MAX_MIN.TUPR_END_DATE_MAX and
                     TUPR_ID.TUPR_END_DATE>TUPR_MAX_MIN.TUPR_START_DATE_MIN
                     and TUPR.TUPR_TU_ID='||v_FLD_TIMEUNIT||') TUPR_ID on TUPR_ID.TUPR_ID=INPUT_DATA.'||pin_Field_To_Match||'

                     )  ';

                    end if;

                  elsif(1=1) then
                  null;


                  end if;*/

    end if;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 4 -- v_select = ' || v_select);

    IF (pin_date_period_column IS NOT NULL) THEN

      v_filter := CREDITING.CR_CREATE_DATE_PERIOD_FILTER(pin_ENTITY_FIELD        => pin_ENTITY_FIELD,
                                                         pin_is_effective_period => pin_is_effective_period,
                                                         pin_process_run_for     => pin_process_run_for,
                                                         pin_date_period_column  => pin_date_period_column,
                                                         pin_start_period_column => pin_start_period_column);
      -- add the filter
      v_select := v_select || v_filter;
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 5 -- v_select = ' || v_select);

    -- if lowest value is selected
    IF (pin_level_from = 0) THEN
      -- remove the rows that do not match
      IF (pin_date_period_column IS NULL) THEN
        v_select := v_select ||
                    ' WHERE NOT EXISTS (SELECT 1
                                                      FROM ' ||
                    CON_HIERARCHY_TABLE_NAME || ' i
                                                      INNER JOIN ' ||
                    commons.FIND_ENT_TABLE_NAME('E' ||
                                                pin_roll_up_from_type) || ' E
                                                      ON E.E_INTERNAL_ID = i.ENT_UPPER
                                                      AND i.ent_upper_type = ' ||
                    pin_roll_up_from_type || '
                                                      WHERE ' || CASE
                      WHEN V_ENTITY_IS_NUMBER = 6 THEN
                       'INPUT_DATA.ENTITY = E.' ||
                       commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')'
                      ELSE
                       'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                       commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || '))'
                    END;
      ELSE
        v_filter := CREDITING.CR_CREATE_DATE_PERIOD_FILTER(pin_ENTITY_FIELD        => pin_ENTITY_FIELD,
                                                           pin_is_effective_period => pin_is_effective_period,
                                                           pin_process_run_for     => pin_process_run_for,
                                                           pin_date_period_column  => pin_date_period_column,
                                                           pin_start_period_column => pin_start_period_column);

        v_select := v_select ||
                    ' WHERE NOT EXISTS (SELECT 1
                                                      FROM ' ||
                    CON_HIERARCHY_TABLE_NAME || ' i
                                                      INNER JOIN ' ||
                    commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                                                      ON E.E_INTERNAL_ID = i.ENT_UPPER
                                                      AND i.ent_upper_type = ' ||
                    pin_roll_up_from_type || '
                                                      WHERE ' || CASE
                      WHEN V_ENTITY_IS_NUMBER = 6 THEN
                       'INPUT_DATA.ENTITY = E.' ||
                       commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                             pin_roll_up_from_type) ||
                       v_filter || ')'
                      ELSE
                       'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                       commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                             pin_roll_up_from_type) || ')' ||
                       v_filter || ')'
                    END;
      END IF;
    END IF;

    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 6 -- v_select = ' || v_select);

    -- create the connect by table
    v_select := 'CREATE TABLE ' || CON_INSERT_DATA_TABLE || ' TABLESPACE ' || USER ||
                '_OUT AS (' || v_select || ')';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_DATA -- 7 -- v_select = ' || v_select);

    v_stamp := 'CREDITING.CR_ROLLUP - create insert data table - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(v_select),
                               ',v_insert_data_table => <value>',
                               v_stamp);
    END;
  /*  commons_utils.INSERT_LOGS('v_select in cr_create_insert_data  ' ||
                              v_select);*/
    COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => COMMONS_DDL_HANDLING.get_transaction_id,
                                     pi_description    => 'CREATE ROLL UP INSERT DATA TABLE',
                                     pi_ddl            => v_select,
                                     pi_undo_ddl       => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' ||
                                                          CON_INSERT_DATA_TABLE ||
                                                          ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' ||
                                                          CON_INSERT_DATA_TABLE ||
                                                          '''; END LOOP; END;',
                                     pi_run_id         => pin_run_id);
    -- INSERT_LOGS ('OUT CREDITING.CR_CREATE_INSERT_DATA');

 /*   exception
    when others then

      commons_utils.INSERT_LOGS(to_char(SQLCODE));
      commons_utils.INSERT_LOGS(SQLERRM);*/
  END CR_CREATE_INSERT_DATA;

  PROCEDURE CR_CREATE_MAIN_SELECT(pin_roll_up_from_type          IN NUMBER,
                                  pin_roll_up_to_type            IN NUMBER,
                                  pin_level_from                 IN NUMBER,
                                  pin_entity_roll_up_from_column IN VARCHAR2,
                                  pin_inputview_columns          IN VARCHAR2,
                                  pin_entity_field               IN BOOLEAN,
                                  pin_aggregate_values           IN NUMBER,
                                  pin_input_data_values_no       IN NUMBER,
                                  pin_INPUT_VIEW_COLUMNS_NA      IN TABLETYPE_COLUMN,
                                  pin_include_input_records      IN NUMBER,
                                  pin_run_id                     IN NUMBER,
                                  pin_operation_id               IN NUMBER,
                                  PIN_INPUTDATA_NOROLLUP_COLUMNS IN VARCHAR2,
                                  pin_input_data_entity          IN VARCHAR2,
                                  pio_select                     IN OUT NOCOPY CLOB) AS
    CON_INSERT_DATA_TABLE CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                   CR_SEQ.CURRVAL;

    v_select_hint CLOB;
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- pin_ENTITY_FIELD = ' || CASE WHEN pin_ENTITY_FIELD THEN 1 ELSE 0 END || ' -- pin_entity_roll_up_from_column = ' || pin_entity_roll_up_from_column || ' -- pin_inputview_columns = ' || pin_inputview_columns || '-- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_roll_up_to_type = ' || pin_roll_up_to_type || ' -- pin_level_from = ' || pin_level_from || ' -- pin_aggregate_values = ' || pin_aggregate_values || ' -- pin_INPUT_DATA_VALUES_NO = ' || pin_INPUT_DATA_VALUES_NO || ' -- pin_include_input_records = ' || pin_include_input_records || ' -- pin_operation_id = ' || pin_operation_id || ' -- pin_run_id = ' || pin_run_id);
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 1 -- pio_select = ' || pio_select);

    -- add the hint framework
    v_select_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_MAIN_SELECT',
                                                               pin_operation_id) ||
                     'SELECT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_MAIN_SELECT',
                                                  pin_operation_id);
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 2 -- pio_select = ' || pio_select);

    -- create the main select
    --
    pio_select := pio_select || v_select_hint ||
                  ' INSERT_DATA.ROW_NUM, INSERT_DATA.ROOT, INSERT_DATA.ENT_LOWER, INSERT_DATA.LVL, INSERT_DATA.ENTITY, ROWNUM ROW_IDENTIFIER';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 3 -- pio_select = ' || pio_select);

    IF (pin_level_from = 0) THEN
      pio_select := pio_select ||
                    ',max(ROWNUM) over (partition by INSERT_DATA.ROW_IDENTIFIER) as MAX_ROW_IDENTIFIER ';
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 4 -- pio_select = ' || pio_select);
    --
    -- if the entities used in the operation are the same and the roll up from column is used in the output table
    IF (pin_roll_up_from_type = pin_roll_up_to_type) AND
       (pin_entity_roll_up_from_column IS NOT NULL) AND
       (instr(',' || pin_inputview_columns || ',',
              ',' || pin_entity_roll_up_from_column || ',') < 3 AND
       pin_ENTITY_FIELD) THEN
      pio_select := pio_select || ', INSERT_DATA.ENTITY_INT_ID ' ||
                    pin_entity_roll_up_from_column;
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 5 -- pio_select = ' || pio_select);
    -- add the selected columns if the rows are aggregated
    IF (pin_aggregate_values = 1) THEN

      -- get the max row num so only one row is inserted
      -- if the lowest value is selected
      pio_select := pio_select ||
                    ', max(ROWNUM) over (partition by INSERT_DATA.root) as MAX_ROW_NUM, ROWNUM ROWNO ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 6_IF -- pio_select = ' || pio_select);

      FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO LOOP
        -- if the values are numeric type
        IF (pin_INPUT_VIEW_COLUMNS_NA(I).COLUMN_TYPE = 6) THEN
          pio_select := pio_select || ', sum(VALUE' || i ||
                        ') over (partition by INSERT_DATA.root) as TO_SUM' || i || '';
          -- if the values are not numeric type
        ELSE
          pio_select := pio_select || ', min(VALUE' || i ||
                        ') keep (DENSE_RANK last order by INSERT_DATA.ROW_IDENTIFIER) over (partition by INSERT_DATA.root) as TO_SUM' || i || '';
        END IF;
      END LOOP;
    ELSE
      -- add the selected columns if the rows are not aggregated
      FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO LOOP
        pio_select := pio_select || ', INSERT_DATA.VALUE' || i;
      end loop;

      if (pin_aggregate_values = 0) then
        if pin_input_data_entity is not null then
          pio_select := pio_select || ',INSERT_DATA.' ||
                        pin_input_data_entity;
        end if;

        if PIN_INPUTDATA_NOROLLUP_COLUMNS is not null then
          pio_select := pio_select || replace(PIN_INPUTDATA_NOROLLUP_COLUMNS,
                                              'INPUT_DATA',
                                              'INSERT_DATA'); --pramod
        end if;
      end if;

      -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 6_ELSE -- pio_select = ' || pio_select);
    END IF;

    -- add the from clause
    pio_select := pio_select || ' FROM ' || CON_INSERT_DATA_TABLE ||
                  ' INSERT_DATA';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7 -- pio_select = ' || pio_select);

    -- if the roll up is done only for leaves
    IF (pin_level_from = 0) THEN

      -- if include input records option is selected
      IF (pin_include_input_records = 1) THEN

        -- add the hint framework
        v_select_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                                   'ROLLUP_MAIN_UNION_LOW',
                                                                   pin_operation_id) ||
                         'SELECT ' ||
                         COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                      'ROLLUP_MAIN_UNION_LOW',
                                                      pin_operation_id);

        pio_select := pio_select || ' UNION ALL ' || v_select_hint ||
                      ' DISTINCT ';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_IF_IF_PART1 -- pio_select = ' || pio_select);

        -- add the main columns
        pio_select := pio_select ||
                      'NULL ROW_NUM, NULL ROOT, INSERT_DATA.ENT_LOWER, NULL LVL, INSERT_DATA.ENTITY, NULL ROW_IDENTIFIER';
        -- if the lowest value is selected
        IF (pin_level_from = 0) THEN
          pio_select := pio_select || ', NULL MAX_ROW_IDENTIFIER';
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_IF_IF_IF1 -- pio_select = ' || pio_select);
        END IF;
        -- if the entities used in the operation are the same and the roll up from column is used in the output table
        IF (pin_roll_up_from_type = pin_roll_up_to_type) AND
           (pin_entity_roll_up_from_column IS NOT NULL) AND
           (instr(',' || pin_inputview_columns || ',',
                  ',' || pin_entity_roll_up_from_column || ',') < 3 AND
           pin_ENTITY_FIELD) THEN
          pio_select := pio_select || ', INSERT_DATA.ENTITY_INT_ID ' ||
                        pin_entity_roll_up_from_column;
          -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_IF_IF_IF2 -- pio_select = ' || pio_select);
        END IF;
        -- add the selected columns if the rows are not aggregated
        FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO LOOP
          pio_select := pio_select || ', INSERT_DATA.VALUE' || i;
        end LOOP;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_IF_IF_PART2 -- pio_select = ' || pio_select);

        pio_select := pio_select || ' FROM (SELECT * FROM ' ||
                      CON_INSERT_DATA_TABLE ||
                      ' INSERT_DATA
                                        WHERE ROOT IS NOT NULL) INSERT_DATA ';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_IF_IF_PART3 -- pio_select = ' || pio_select);

      END IF;
    ELSE

      -- if include input records option is selected
      IF (pin_include_input_records = 1) THEN
        -- add the hint framework
        v_select_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                                   'ROLLUP_MAIN_UNION',
                                                                   pin_operation_id) ||
                         'SELECT ' ||
                         COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                      'ROLLUP_MAIN_UNION',
                                                      pin_operation_id);

        pio_select := pio_select || ' UNION ALL ' || v_select_hint ||
                      ' DISTINCT ';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_ELSE_IF_PART1 -- pio_select = ' || pio_select);

        -- add the main columns
        pio_select := pio_select ||
                      'NULL ROW_NUM, NULL ROOT, INSERT_DATA.ENT_LOWER, NULL LVL, INSERT_DATA.ENTITY, NULL ROW_IDENTIFIER';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_ELSE_IF_PART2 -- pio_select = ' || pio_select);
        -- if the entities used in the operation are the same and the roll up from column is used in the output table
        IF (pin_roll_up_from_type = pin_roll_up_to_type) AND
           (pin_entity_roll_up_from_column IS NOT NULL) AND
           (instr(',' || pin_inputview_columns || ',',
                  ',' || pin_entity_roll_up_from_column || ',') < 3 AND
           pin_ENTITY_FIELD) THEN
          pio_select := pio_select || ', INSERT_DATA.ENTITY_INT_ID ' ||
                        pin_entity_roll_up_from_column;
      /*    commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_ELSE_IF_IF1 -- pio_select = ' ||
                                    pio_select);*/
        END IF;
        -- add the selected columns if the rows are not aggregated
        FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO LOOP
          pio_select := pio_select || ', INSERT_DATA.VALUE' || i;
        end LOOP;
    /*    commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_ELSE_IF_PART3 -- pio_select = ' ||
                                  pio_select);*/

        -- filter the records
        pio_select := pio_select || ' FROM ' || CON_INSERT_DATA_TABLE ||
                      ' INSERT_DATA
                             WHERE ROOT IS NOT NULL';
     /*   commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_MAIN_SELECT -- 7_ELSE_IF_PART4 -- pio_select = ' ||
                                  pio_select);*/

      END IF;
    END IF;

    -- add the order by
    pio_select := pio_select || ' ORDER BY ENT_LOWER, ROW_NUM NULLS FIRST';
 /*   commons_utils.INSERT_LOGS('OUT CREDITING.CR_CREATE_MAIN_SELECT -- FINAL -- pio_select = ' ||
                              pio_select);*/
  END CR_CREATE_MAIN_SELECT;

  ---------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------

  PROCEDURE CR_CREATE_INSERT_NO_MATCH_ROLL(pin_inputview_columns        IN VARCHAR2,
                                           pin_no_match_table_columns   IN VARCHAR2,
                                           pin_no_roll_up_table_columns IN VARCHAR2,
                                           pin_roll_up_from_type        IN NUMBER,
                                           pin_run_id                   IN NUMBER,
                                           pin_date_period_column       IN VARCHAR2,
                                           pin_is_effective_period      IN NUMBER,
                                           pin_process_run_for          IN NUMBER,
                                           pin_start_period_column      IN VARCHAR2,
                                           pin_end_period_column        IN VARCHAR2,
                                           pin_inputview_ent_fld        IN VARCHAR2,
                                           pin_period_run_for           IN NUMBER,
                                           pin_operation_id             IN NUMBER,
                                           pin_RECORD_BASED_ON_OPTION   IN NUMBER,
                                           pin_RECORDS_BETWEEN_OPTION   IN NUMBER,
                                           pin_Field_To_Match           IN VARCHAR2,
                                           pin_nm_non_ent_col           IN varchar2,
                                           pin_nm_non_ent_col_alias     IN varchar2,
                                           pin_nm_ent_col               IN varchar2,
                                              PIN_CRSTRUCT_TABLE  IN varchar2,
                                           pin_nm_ent_col_alias         IN varchar2,
                                           pin_nr_non_ent_col           IN varchar2,
                                           pin_nr_non_ent_col_alias     IN varchar2,
                                           pin_nr_ent_col               IN varchar2,
                                           pin_nr_ent_col_alias         IN varchar2) AS
    CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    V_INSERT                  CLOB;
    v_entity_field            BOOLEAN;
    v_time_unit_id            NUMBER;
    v_hr_timeunit_id          NUMBER;
    V_CORRESP_RUN_FOR         NUMBER;
    v_filter                  CLOB;
    v_insert_hint             CLOB;
    V_INPUT_DATA_ENTITY       VARCHAR2(30);
    v_sql_to_remove_duplicate VARCHAR2(1300 CHAR);
    v_return_clause           clob;
    v_join                    boolean;
         v_JOIN_CR_TABLE VARCHAR2(1000);
                                   v_JOIN_FILTER_TABLE VARCHAR2(1000);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- pin_inputview_columns = ' || pin_inputview_columns || '-- pin_no_match_table_columns = ' || pin_no_match_table_columns || ' -- pin_no_roll_up_table_columns = ' || pin_no_roll_up_table_columns || ' -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_run_id = ' || pin_run_id || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_start_period_column = ' || pin_start_period_column || ' -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_period_run_for = ' || pin_period_run_for || ' -- pin_operation_id = ' || pin_operation_id);

    IF (instr(pin_inputview_columns, ',') = 0) THEN
      V_INPUT_DATA_ENTITY := pin_inputview_columns;
    ELSE
      V_INPUT_DATA_ENTITY := substr(pin_inputview_columns,
                                    1,
                                    instr(replace(pin_inputview_columns || ',',
                                                  ' '),
                                          ',') - 1);
    END IF;
    -- check if the roll up is done by entity or field
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');
    -- create inner query filter
    IF (pin_date_period_column IS NULL) THEN
      v_filter := '(SELECT 1
                          FROM ' ||
                  CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' ||
                  commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' ||
                  pin_roll_up_from_type;

      --##--

         if (pin_RECORD_BASED_ON_OPTION = 2) then
        /*  TO_DATE(''01/01/1800'',''MM/DD/sYYYY'')*/

        CR_Timebased_filtering(pin_Field_To_Match      => pin_Field_To_Match,
          PIN_CRSTRUCT_TABLE    =>PIN_CRSTRUCT_TABLE,
                               PIN_CR_TABLE            => 'INPUT_DATA',
                               pin_start_period_column => pin_start_period_column,
                               pin_end_period_column   => pin_end_period_column,
                               PIN_FILTER_TABLE        => 'hi',
                                 RECORDS_BETWEEN_OPTION  => pin_RECORDS_BETWEEN_OPTION,
                               POUT_Query              => v_return_clause,
                               pout_join               => v_join,
                                POUT_JOIN_CR_TABLE  =>V_JOIN_CR_TABLE,
                                   POUT_JOIN_FILTER_TABLE  =>V_JOIN_FILTER_TABLE);
       -- v_filter := v_filter || ' where ' || v_return_clause;
        -- case when v_join then ' ' else ' and ' end
      end if;
      v_filter := v_filter || case
                    when V_JOIN_FILTER_TABLE is not null then
                     case
                       when v_join /* pin_RECORD_BASED_ON_OPTION = 2 */
                        then
                        V_JOIN_FILTER_TABLE ||' and '
                       else
                        ' where ' || V_JOIN_FILTER_TABLE || ' and '
                     end
                    else
                     ' where '
                  end || case
                    WHEN V_ENTITY_IS_NUMBER = 6 THEN
                     'INPUT_DATA.ENTITY = E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                           pin_roll_up_from_type) || ')'
                    ELSE
                     'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                           pin_roll_up_from_type) || '))'
                  END;

    ELSE

      -- get the time units
      CREDITING.CR_RETURN_CORRESP(pin_period_run_for,
                                  pin_start_period_column,
                                  V_TIME_UNIT_ID,
                                  V_HR_TIMEUNIT_ID,
                                  V_CORRESP_RUN_FOR);
      -- get the filter
      v_filter := CREDITING.CR_CREATE_DATE_PERIOD_NO(pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                                     pin_is_effective_period => pin_is_effective_period,
                                                     pin_process_run_for     => pin_process_run_for,
                                                     pin_date_period_column  => pin_date_period_column,
                                                     pin_start_period_column => pin_start_period_column);
      -- create the inner select
      v_filter := '(SELECT 1
                          FROM ' ||
                  CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' ||
                  commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' ||
                  pin_roll_up_from_type;

      --##--
       if (pin_RECORD_BASED_ON_OPTION = 2) then
        /*  TO_DATE(''01/01/1800'',''MM/DD/sYYYY'')*/

        CR_Timebased_filtering(pin_Field_To_Match      => pin_Field_To_Match,
        PIN_CRSTRUCT_TABLE    =>PIN_CRSTRUCT_TABLE,
                               PIN_CR_TABLE            => 'INPUT_DATA',
                               pin_start_period_column => pin_start_period_column,
                               pin_end_period_column   => pin_end_period_column,
                               PIN_FILTER_TABLE        => 'hi',
                                 RECORDS_BETWEEN_OPTION  => pin_RECORDS_BETWEEN_OPTION,
                               POUT_Query              => v_return_clause,
                               pout_join               => v_join,
                                POUT_JOIN_CR_TABLE  =>V_JOIN_CR_TABLE,
                                   POUT_JOIN_FILTER_TABLE  =>V_JOIN_FILTER_TABLE);
       /* v_filter := v_filter || ' where ' || v_return_clause;*/

      end if;

      v_filter := v_filter || case
                    when V_JOIN_FILTER_TABLE is not null then
                     case
                       when v_join /* pin_RECORD_BASED_ON_OPTION = 2 */
                        then
                        V_JOIN_FILTER_TABLE ||' and '
                       else
                        ' where ' || V_JOIN_FILTER_TABLE || ' and '
                     end
                    else
                     ' where '
                  end || case
                    WHEN V_ENTITY_IS_NUMBER = 6 THEN
                     'INPUT_DATA.ENTITY = E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                           pin_roll_up_from_type) ||
                     v_filter || ')'
                    ELSE
                     'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                           pin_roll_up_from_type) || ')' ||
                     v_filter || ')'
                  END;
    END IF;

    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_NO_MATCH',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_NO_MATCH',
                                                  pin_operation_id);

    IF (pin_no_match_table_columns IS NOT NULL) THEN
      -- create the main insert for no match
      V_INSERT := V_INSERT_hint || ' INTO ' ||
                  substr(pin_no_match_table_columns,
                         1,
                         instr(pin_no_match_table_columns, ',') - 1) ||
                  ' (ROW_IDENTIFIER, ROW_VERSION, ';

      v_sql_to_remove_duplicate := 'MINUS select ROW_VERSION,';
      if (pin_nm_ent_col is not null) then
        V_INSERT                  := V_INSERT || pin_nm_ent_col;
        v_sql_to_remove_duplicate := v_sql_to_remove_duplicate ||
                                     pin_nm_ent_col;
        if pin_nm_non_ent_col is not null then
          V_INSERT                  := V_INSERT || ',' ||
                                       pin_nm_non_ent_col;
          v_sql_to_remove_duplicate := v_sql_to_remove_duplicate || ',' ||
                                       pin_nm_non_ent_col;
        end if;
      else
        if (pin_nm_non_ent_col is not null) then
          V_INSERT                  := V_INSERT || pin_nm_non_ent_col;
          v_sql_to_remove_duplicate := v_sql_to_remove_duplicate ||
                                       pin_nm_non_ent_col;
        end if;
      end if;

      V_INSERT := V_INSERT || ') select ' ||
                  substr(pin_no_match_table_columns,
                         1,
                         instr(pin_no_match_table_columns, ',') - 1) ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL ' ||
                  ',unq.* from (SELECT  0 ROW_VER, ';
      /*|| V_INPUT_DATA_ENTITY*/

      if (pin_nm_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nm_ent_col_alias;

        if pin_nm_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_nm_non_ent_col_alias;

        end if;
      else
        if (pin_nm_non_ent_col_alias is not null) then
          V_INSERT := V_INSERT || pin_nm_non_ent_col_alias;

        end if;
      end if;

      V_INSERT := V_INSERT || ' FROM ' || CON_INPUT_DATA_TABLE ||
                  ' INPUT_DATA '||V_JOIN_CR_TABLE ||
              ' WHERE NOT EXISTS ';

      v_sql_to_remove_duplicate := v_sql_to_remove_duplicate || ' FROM ' ||
                                   substr(pin_no_match_table_columns,
                                          1,
                                          instr(pin_no_match_table_columns,
                                                ',') - 1);
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 1 -- V_INSERT = ' || V_INSERT);
      -- add the same filter
      v_insert := v_insert || v_filter;

      v_insert := v_insert || v_sql_to_remove_duplicate || ')  unq ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 2A -- V_INSERT = ' || V_INSERT);
      -- log the query
      v_stamp := 'CREDITING.CR_ROLLUP - v_insert_no_match - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
      BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                 ANYDATA.CONVERTCLOB(V_INSERT),
                                 ',v_insert_no_match => <value>',
                                 v_stamp);
      END;

   /*   commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 2B -- SUCCESSFUL EXEC IMMEDIATE V_INSERT = ' ||
                                V_INSERT);*/
      EXECUTE IMMEDIATE V_INSERT;

      -- save the execution plan
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                        pi_query_identifier => 'ADDITIONAL_NO_MATCH');
      COMMIT;
/*      commons_utils.INSERT_LOGS('check1');*/
    END IF;

    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_NO_ROLL',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_NO_ROLL',
                                                  pin_operation_id);

    IF (pin_no_roll_up_table_columns IS NOT NULL) THEN
      -- create the main insert for no roll up
      V_INSERT := v_insert_hint || ' INTO ' ||
                  substr(pin_no_roll_up_table_columns,
                         1,
                         instr(pin_no_roll_up_table_columns, ',') - 1) ||
                  ' (ROW_IDENTIFIER, ROW_VERSION, ';

      if (pin_nr_ent_col is not null) then
        V_INSERT := V_INSERT || pin_nr_ent_col;
        if pin_nr_non_ent_col is not null then
          V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col;
        end if;
      else
        if (pin_nr_non_ent_col is not null) then
          V_INSERT := V_INSERT || pin_nr_non_ent_col;
        end if;
      end if;
      --|| pin_nr_ent_col ||','|| pin_nr_non_ent_col ||
      V_INSERT := V_INSERT || ') SELECT ' ||
                  substr(pin_no_roll_up_table_columns,
                         1,
                         instr(pin_no_roll_up_table_columns, ',') - 1) ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, ';
      /*|| case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END*/

      if (pin_nr_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nr_ent_col_alias;
        if pin_nr_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col_alias;
        end if;
      else
        if (pin_nr_non_ent_col_alias is not null) then
          V_INSERT := V_INSERT || pin_nr_non_ent_col_alias;
        end if;
      end if;

      --|| pin_nr_ent_col_alias ||','|| pin_nr_non_ent_col_alias ||
      V_INSERT := V_INSERT || ' FROM ' || CON_INPUT_DATA_TABLE ||
                  ' INPUT_DATA '||V_JOIN_CR_TABLE ||
            ' WHERE EXISTS ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 3 -- V_INSERT = ' || V_INSERT);

      -- add the same filter
      v_insert := v_insert || v_filter;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 4 -- V_INSERT = ' || V_INSERT);

      -- add the row_identifier filter
      v_insert := v_insert || ' AND NOT EXISTS (SELECT 1 FROM ' ||
                  CON_INSERT_DATA_TABLE ||
                  ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 5A -- V_INSERT = ' || V_INSERT);

      -- log the query
      v_stamp := 'CREDITING.CR_ROLLUP - v_insert_no_roll - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

      BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                 ANYDATA.CONVERTCLOB(V_INSERT),
                                 ',v_insert_no_roll => <value>',
                                 v_stamp);
      END;
  /*    commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL -- 5B -- AFTER SUCCESSFUL EXEC IMMEDIATE for V_INSERT = ' ||
                                V_INSERT);*/

      EXECUTE IMMEDIATE V_INSERT;

      -- save the execution plan
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                        pi_query_identifier => 'ADDITIONAL_NO_ROLL');
      COMMIT;
/*      commons_utils.INSERT_LOGS('check2');*/
    END IF;
    -- INSERT_LOGS ('OUT CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL');
/*  exception
    when others then

      commons_utils.INSERT_LOGS(to_char(SQLCODE));
      commons_utils.INSERT_LOGS(SQLERRM);*/

  END CR_CREATE_INSERT_NO_MATCH_ROLL;

  ---------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------

  PROCEDURE CR_CREATE_INSERT_LOWEST(pin_inputview_ent_fld        IN VARCHAR2,
                                    pin_inputview_columns        IN VARCHAR2,
                                    pin_no_match_table_columns   IN VARCHAR2,
                                    pin_no_roll_up_table_columns IN VARCHAR2,
                                    pin_roll_up_from_type        IN NUMBER,
                                    pin_run_id                   IN NUMBER,
                                    pin_date_period_column       IN VARCHAR2,
                                    pin_is_effective_period      IN NUMBER,
                                    pin_process_run_for          IN NUMBER,
                                    pin_start_period_column      IN VARCHAR2,
                                    pin_operation_id             IN NUMBER,
                                    pin_nm_non_ent_col           IN varchar2,
                                    pin_nm_non_ent_col_alias     IN varchar2,
                                    pin_nm_ent_col               IN varchar2,
                                    pin_nm_ent_col_alias         IN varchar2,
                                    pin_nr_non_ent_col           IN varchar2,
                                    pin_nr_non_ent_col_alias     IN varchar2,
                                    pin_nr_ent_col               IN varchar2,
                                    pin_nr_ent_col_alias         IN varchar2) AS
    CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    V_INSERT            CLOB;
    v_entity_field      BOOLEAN;
    v_filter            CLOB;
    v_filter_select     CLOB;
    v_insert_hint       CLOB;
    v_period_filter     CLOB;
    V_INPUT_DATA_ENTITY VARCHAR2(30);
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_inputview_columns = ' || pin_inputview_columns || '-- pin_no_match_table_columns = ' || pin_no_match_table_columns || ' -- pin_no_roll_up_table_columns = ' || pin_no_roll_up_table_columns || ' -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_run_id = ' || pin_run_id || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_start_period_column = ' || pin_start_period_column  || ' -- pin_operation_id = ' || pin_operation_id);

    IF (instr(pin_inputview_columns, ',') = 0) THEN
      V_INPUT_DATA_ENTITY := pin_inputview_columns;
    ELSE
      V_INPUT_DATA_ENTITY := substr(pin_inputview_columns,
                                    1,
                                    instr(replace(pin_inputview_columns || ',',
                                                  ' '),
                                          ',') - 1);
    END IF;
    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_LOW_NO_MATCH',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_LOW_NO_MATCH',
                                                  pin_operation_id);

    -- check if the roll up is done by entity or field
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');

    -- create inner query filter
    IF (pin_date_period_column IS NULL) THEN
      v_filter := '(SELECT 1
                          FROM ' ||
                  CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' ||
                  commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' ||
                  pin_roll_up_from_type || '
                          WHERE ' || case
                    WHEN V_ENTITY_IS_NUMBER = 6 THEN
                     'INPUT_DATA.ENTITY = E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')'
                    ELSE
                     'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || '))'
                  END;

      v_filter_select := '(SELECT MAX(1)
                                  FROM ' ||
                         CON_HIERARCHY_TABLE_NAME || ' hi
                                  INNER JOIN ' ||
                         commons.FIND_ENT_TABLE_NAME('E' ||
                                                     pin_roll_up_from_type) || ' E
                                  ON E.E_INTERNAL_ID = hi.ENT_UPPER
                                  AND hi.ent_upper_type = ' ||
                         pin_roll_up_from_type || '
                                  WHERE ' || case
                           WHEN V_ENTITY_IS_NUMBER = 6 THEN
                            'INPUT_DATA.ENTITY = E.' ||
                            commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                  pin_roll_up_from_type) || ')'
                           ELSE
                            'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                            commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                  pin_roll_up_from_type) || '))'
                         END;
    ELSE

      -- get the filter
      v_period_filter := CREDITING.CR_CREATE_DATE_PERIOD_NO(pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                                            pin_is_effective_period => pin_is_effective_period,
                                                            pin_process_run_for     => pin_process_run_for,
                                                            pin_date_period_column  => pin_date_period_column,
                                                            pin_start_period_column => pin_start_period_column);
      -- create the inner select
      v_filter := '(SELECT 1
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' ||
                  commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' ||
                  pin_roll_up_from_type || '
                          WHERE ' || case
                    WHEN V_ENTITY_IS_NUMBER = 6 THEN
                     'INPUT_DATA.ENTITY = E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                           pin_roll_up_from_type) ||
                     v_period_filter || ')'
                    ELSE
                     'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                     commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                           pin_roll_up_from_type) || ')' ||
                     v_period_filter || ')'
                  END;

      -- create the inner select
      v_filter_select := '(SELECT MAX(1)
                                  FROM ' ||
                         CON_HIERARCHY_TABLE_NAME || ' hi
                                  INNER JOIN ' ||
                         commons.FIND_ENT_TABLE_NAME('E' ||
                                                     pin_roll_up_from_type) || ' E
                                  ON E.E_INTERNAL_ID = hi.ENT_UPPER
                                  AND hi.ent_upper_type = ' ||
                         pin_roll_up_from_type || '
                                  WHERE ' || case
                           WHEN V_ENTITY_IS_NUMBER = 6 THEN
                            'INPUT_DATA.ENTITY = E.' ||
                            commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                  pin_roll_up_from_type) ||
                            v_period_filter || ')'
                           ELSE
                            'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                            commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                  pin_roll_up_from_type) || ')' ||
                            v_period_filter || ')'
                         END;
    END IF;

    IF (pin_no_match_table_columns IS NOT NULL) THEN
      -- create the main insert for no match
      V_INSERT := v_insert_hint || ' INTO ' ||
                  substr(pin_no_match_table_columns,
                         1,
                         instr(pin_no_match_table_columns, ',') - 1) ||
                  ' (ROW_IDENTIFIER, ROW_VERSION, ';

      if (pin_nm_ent_col is not null) then
        V_INSERT := V_INSERT || pin_nm_ent_col;
        if pin_nm_non_ent_col is not null then
          V_INSERT := V_INSERT || ',' || pin_nm_non_ent_col;
        end if;
      else
        if (pin_nm_non_ent_col is not null) then
          V_INSERT := V_INSERT || pin_nm_non_ent_col;
        end if;
      end if;

      --|| pin_nm_ent_col ||','|| pin_nm_non_ent_col ||

      V_INSERT := V_INSERT || ') SELECT ' ||
                  substr(pin_no_match_table_columns,
                         1,
                         instr(pin_no_match_table_columns, ',') - 1) ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, ' || V_INPUT_DATA_ENTITY;

      if (pin_nm_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nm_ent_col_alias;
        if pin_nm_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_nm_non_ent_col_alias;
        end if;
      else
        if (pin_nm_non_ent_col_alias is not null) then
          V_INSERT := V_INSERT || pin_nm_non_ent_col_alias;
        end if;
      end if;
      --|| pin_nm_ent_col_alias ||','|| pin_nm_non_ent_col_alias ||

      V_INSERT := V_INSERT || ' FROM ' || CON_INPUT_DATA_TABLE ||
                  ' INPUT_DATA
            WHERE NOT EXISTS ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST -- 1 -- V_INSERT = ' || V_INSERT);

      -- add the same filter
      v_insert := v_insert || v_filter;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST -- 2A -- V_INSERT = ' || V_INSERT);

      -- log the query
      v_stamp := 'CREDITING.CR_ROLLUP - v_insert_low_no_match - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

      BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                 ANYDATA.CONVERTCLOB(V_INSERT),
                                 ',v_insert_no_match => <value>',
                                 v_stamp);
      END;

      EXECUTE IMMEDIATE V_INSERT;
   /*   commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INSERT_LOWEST -- 2B -- AFTER SUCCESSFUL EXEC IMMEDIATE of V_INSERT = ' ||
                                V_INSERT);*/

      -- save the execution plan
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                        pi_query_identifier => 'ADDITIONAL_LOW_NO_MATCH');
    END IF;

    -- create the insert for no roll up and no match
    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_LOW_BOTH',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_LOW_BOTH',
                                                  pin_operation_id);

    -- create the main insert for no match and no roll up
    V_INSERT := v_insert_hint || ' FIRST ';
    -- add the no roll up case
    if (pin_no_roll_up_table_columns IS NOT NULL) THEN
      V_INSERT := V_INSERT || ' WHEN (IS_UPPER IS NULL) THEN INTO ' ||
                  substr(pin_no_roll_up_table_columns,
                         1,
                         instr(pin_no_roll_up_table_columns, ',') - 1) ||
                  ' (ROW_IDENTIFIER, ROW_VERSION, ';

      if (pin_nr_ent_col is not null) then
        V_INSERT := V_INSERT || pin_nr_ent_col;
        if pin_nr_non_ent_col is not null then
          V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col;
        end if;
      else
        if (pin_nr_non_ent_col is not null) then
          V_INSERT := V_INSERT || pin_nr_non_ent_col;
        end if;
      end if;
      --|| pin_nr_ent_col ||','|| pin_nr_non_ent_col ||

      V_INSERT := V_INSERT || ') VALUES (' ||
                  substr(pin_no_roll_up_table_columns,
                         1,
                         instr(pin_no_roll_up_table_columns, ',') - 1) ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, entity ';

      if (pin_nm_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nm_ent_col_alias;
        if pin_nm_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_nm_non_ent_col_alias;
        end if;
      else
        if (pin_nm_non_ent_col_alias is not null) then
          V_INSERT := V_INSERT || pin_nm_non_ent_col_alias;
        end if;
      end if;

      -- || pin_nr_ent_col_alias ||','|| pin_nr_non_ent_col_alias ||
      V_INSERT := V_INSERT || ')';
    END if;

    -- add the no match case
    if (pin_no_match_table_columns IS NOT NULL) THEN
      V_INSERT := V_INSERT || ' WHEN (IS_UPPER = 1) THEN INTO ' ||
                  substr(pin_no_match_table_columns,
                         1,
                         instr(pin_no_match_table_columns, ',') - 1) ||
                  ' (ROW_IDENTIFIER, ROW_VERSION, ';

      if (pin_nm_ent_col is not null) then
        V_INSERT := V_INSERT || pin_nm_ent_col;
        if pin_nm_non_ent_col is not null then
          V_INSERT := V_INSERT || ',' || pin_nm_non_ent_col;
        end if;
      else
        if (pin_nm_non_ent_col is not null) then
          V_INSERT := V_INSERT || pin_nm_non_ent_col;
        end if;
      end if;

      --|| pin_nm_ent_col ||','|| pin_nm_non_ent_col ||

      V_INSERT := V_INSERT || ') VALUES (' ||
                  substr(pin_no_match_table_columns,
                         1,
                         instr(pin_no_match_table_columns, ',') - 1) ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, entity ';
      if (pin_nm_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nm_ent_col_alias;
        if pin_nm_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_nm_non_ent_col_alias;
        end if;
      else
        if (pin_nm_non_ent_col_alias is not null) then
          V_INSERT := V_INSERT || pin_nm_non_ent_col_alias;
        end if;
      end if;

      --|| pin_nm_ent_col_alias ||','|| pin_nm_non_ent_col_alias || ')'
    end if;

    -- add the select
    V_INSERT := V_INSERT || 'SELECT ' || case
                  WHEN v_entity_field THEN
                   'INPUT_DATA.ENTITY_INT_ID'
                  ELSE
                   'INPUT_DATA.ENTITY'
                END || ' entity ' ||
                substr(pin_inputview_columns,
                       instr(replace(pin_inputview_columns || ',', ' '), ',')) || ', ' ||
                v_filter_select || ' IS_UPPER
            FROM ' || CON_INPUT_DATA_TABLE ||
                ' INPUT_DATA
                 WHERE EXISTS ';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST -- 3 -- V_INSERT = ' || V_INSERT);

    -- add the same filter
    v_insert := v_insert || v_filter;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST -- 4 -- V_INSERT = ' || V_INSERT);

    -- add the row_identifier filter
    v_insert := v_insert || ' AND NOT EXISTS (SELECT 1 FROM ' ||
                CON_INSERT_DATA_TABLE ||
                ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST -- 5A -- V_INSERT = ' || V_INSERT);

    -- log the query
    v_stamp := 'CREDITING.CR_ROLLUP - v_insert_low_both - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_INSERT),
                               ',v_insert_both => <value>',
                               v_stamp);
    END;

    EXECUTE IMMEDIATE V_INSERT;
/*    commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INSERT_LOWEST -- 5B -- AFTER SUCCESSFUL EXEC IMMEDIATE of -- V_INSERT = ' ||
                              V_INSERT);*/

    -- save the execution plan
    COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                      pi_query_identifier => 'ADDITIONAL_LOWEST_BOTH');
  /*  commons_utils.INSERT_LOGS('OUT CREDITING.CR_CREATE_INSERT_LOWEST');*/

  END CR_CREATE_INSERT_LOWEST;

  ---------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------

  PROCEDURE CR_CREATE_INSERT_NO_ROLL_ANY(pin_inputview_columns        IN VARCHAR2,
                                         pin_no_roll_up_table_columns IN VARCHAR2,
                                         pin_roll_up_from_type        IN NUMBER,
                                         pin_run_id                   IN NUMBER,
                                         pin_date_period_column       IN VARCHAR2,
                                         pin_is_effective_period      IN NUMBER,
                                         pin_process_run_for          IN NUMBER,
                                         pin_start_period_column      IN VARCHAR2,
                                         pin_inputview_ent_fld        IN VARCHAR2,
                                         pin_period_run_for           IN NUMBER,
                                         pin_operation_id             IN NUMBER,
                                         pin_nr_non_ent_col           IN varchar2,
                                         pin_nr_non_ent_col_alias     IN varchar2,
                                         pin_nr_ent_col               IN varchar2,
                                         pin_nr_ent_col_alias         IN varchar2) AS
    CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    V_INSERT          CLOB;
    v_entity_field    BOOLEAN;
    v_time_unit_id    NUMBER;
    v_hr_timeunit_id  NUMBER;
    V_CORRESP_RUN_FOR NUMBER;
    v_filter          CLOB;
    v_insert_hint     CLOB;
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY -- pin_inputview_columns = ' || pin_inputview_columns || ' -- pin_no_roll_up_table_columns = ' || pin_no_roll_up_table_columns || ' -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_run_id = ' || pin_run_id || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_start_period_column = ' || pin_start_period_column || '-- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_period_run_for = ' || pin_period_run_for || ' -- pin_operation_id = ' || pin_operation_id);

    -- check if the roll up is done by entity or field
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');
    -- get the time units
    CREDITING.CR_RETURN_CORRESP(pin_period_run_for,
                                pin_start_period_column,
                                V_TIME_UNIT_ID,
                                V_HR_TIMEUNIT_ID,
                                V_CORRESP_RUN_FOR);
    -- get the filter
    v_filter := CREDITING.CR_CREATE_DATE_PERIOD_NO(pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                                   pin_is_effective_period => pin_is_effective_period,
                                                   pin_process_run_for     => pin_process_run_for,
                                                   pin_date_period_column  => pin_date_period_column,
                                                   pin_start_period_column => pin_start_period_column);
    -- create the inner select
    v_filter := '(SELECT 1
                      FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                      INNER JOIN ' ||
                commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                      ON E.E_INTERNAL_ID = hi.ENT_LOWER
                      AND hi.ent_lower_type = ' ||
                pin_roll_up_from_type || '
                      WHERE ' || case
                  WHEN V_ENTITY_IS_NUMBER = 6 THEN
                   'INPUT_DATA.ENTITY = E.' ||
                   commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                         pin_roll_up_from_type) ||
                   v_filter || ')'
                  ELSE
                   'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                   commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                         pin_roll_up_from_type) || ')' ||
                   v_filter || ')'
                END;

    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_NO_ROLL_ANY',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_NO_ROLL_ANY',
                                                  pin_operation_id);

    IF (pin_no_roll_up_table_columns IS NOT NULL) THEN
      -- create the main insert for no roll up
      V_INSERT := v_insert_hint || ' INTO ' ||
                  substr(pin_no_roll_up_table_columns,
                         1,
                         instr(pin_no_roll_up_table_columns, ',') - 1) ||
                  ' (ROW_IDENTIFIER, ROW_VERSION, ';

      if (pin_nr_ent_col is not null) then
        V_INSERT := V_INSERT || pin_nr_ent_col;
        if pin_nr_non_ent_col is not null then
          V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col;
        end if;
      else
        if (pin_nr_non_ent_col is not null) then
          V_INSERT := V_INSERT || pin_nr_non_ent_col;
        end if;
      end if;
      --|| pin_nr_ent_col ||','|| pin_nr_non_ent_col ||

      V_INSERT := V_INSERT || ') SELECT ' ||
                  substr(pin_no_roll_up_table_columns,
                         1,
                         instr(pin_no_roll_up_table_columns, ',') - 1) ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, ';
      /*|| case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END*/

      if (pin_nr_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nr_ent_col_alias;
        if pin_nr_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col_alias;
        end if;
      else
        if (pin_nr_non_ent_col_alias is not null) then
          V_INSERT := V_INSERT || pin_nr_non_ent_col_alias;
        end if;
      end if;

      -- || pin_nr_ent_col_alias ||','|| pin_nr_non_ent_col_alias ||

      V_INSERT := V_INSERT || ' FROM ' || CON_INPUT_DATA_TABLE ||
                  ' INPUT_DATA
            WHERE EXISTS ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY -- 1 -- V_INSERT = ' || V_INSERT);

      -- add the same filter
      v_insert := v_insert || v_filter;
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY -- 2 -- V_INSERT = ' || V_INSERT);

      -- add the row_identifier filter
      v_insert := v_insert || ' AND EXISTS (SELECT 1 FROM ' ||
                  CON_INSERT_DATA_TABLE ||
                  ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY -- 3A -- V_INSERT = ' || V_INSERT);

      -- log the query
      v_stamp := 'CREDITING.CR_ROLLUP - v_insert_no_roll_any - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

      BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                 ANYDATA.CONVERTCLOB(V_INSERT),
                                 ',v_insert_no_roll => <value>',
                                 v_stamp);
      END;

      EXECUTE IMMEDIATE V_INSERT;
  /*    commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY -- 3B -- AFTER SUCCESSFUL EXEC IMMEDIATE of -- V_INSERT = ' ||
                                V_INSERT);*/

      -- save the execution plan
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                        pi_query_identifier => 'ADDITIONAL_NO_ROLLUP_ANY');

    END IF;
   /* commons_utils.INSERT_LOGS('OUT CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY');*/

  END CR_CREATE_INSERT_NO_ROLL_ANY;

  ---------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------

  PROCEDURE CR_CREATE_INSERT_LOWEST_ANY(pin_inputview_ent_fld        IN VARCHAR2,
                                        pin_inputview_columns        IN VARCHAR2,
                                        pin_no_roll_up_table_columns IN VARCHAR2,
                                        pin_roll_up_from_type        IN NUMBER,
                                        pin_run_id                   IN NUMBER,
                                        pin_date_period_column       IN VARCHAR2,
                                        pin_is_effective_period      IN NUMBER,
                                        pin_process_run_for          IN NUMBER,
                                        pin_start_period_column      IN VARCHAR2,
                                        pin_operation_id             IN NUMBER,
                                        pin_nr_non_ent_col           IN varchar2,
                                        pin_nr_non_ent_col_alias     IN varchar2,
                                        pin_nr_ent_col               IN varchar2,
                                        pin_nr_ent_col_alias         IN varchar2) AS
    CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    V_INSERT        CLOB;
    v_entity_field  BOOLEAN;
    v_filter        CLOB;
    v_second_filter CLOB;
    v_insert_hint   CLOB;
  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST_ANY -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_inputview_columns = ' || pin_inputview_columns || ' -- pin_no_roll_up_table_columns = ' || pin_no_roll_up_table_columns || ' -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_run_id = ' || pin_run_id || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_start_period_column = ' || pin_start_period_column  || ' -- pin_operation_id = ' || pin_operation_id);

    -- check if the roll up is done by entity or field
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');

    -- get the filter
    v_filter := CREDITING.CR_CREATE_DATE_PERIOD_NO(pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                                   pin_is_effective_period => pin_is_effective_period,
                                                   pin_process_run_for     => pin_process_run_for,
                                                   pin_date_period_column  => pin_date_period_column,
                                                   pin_start_period_column => pin_start_period_column);
    -- create the inner select
    v_filter := '(SELECT 1
                      FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                      INNER JOIN ' ||
                commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                      ON E.E_INTERNAL_ID = hi.ENT_LOWER
                      AND hi.ent_lower_type = ' ||
                pin_roll_up_from_type || '
                      WHERE ' || case
                  WHEN V_ENTITY_IS_NUMBER = 6 THEN
                   'INPUT_DATA.ENTITY = E.' ||
                   commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                         pin_roll_up_from_type) ||
                   v_filter || ')'
                  ELSE
                   'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                   commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                         pin_roll_up_from_type) || ')' ||
                   v_filter || ')'
                END;

    -- create the inner select
    v_second_filter := '(SELECT 1
                          FROM ' ||
                       CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' ||
                       commons.FIND_ENT_TABLE_NAME('E' ||
                                                   pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_UPPER
                          AND hi.ent_upper_type = ' ||
                       pin_roll_up_from_type || '
                          WHERE ' || case
                         WHEN V_ENTITY_IS_NUMBER = 6 THEN
                          'INPUT_DATA.ENTITY = E.' ||
                          commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                pin_roll_up_from_type) ||
                          v_filter || ')'
                         ELSE
                          'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' ||
                          commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                                pin_roll_up_from_type) || ')' ||
                          v_filter || ')'
                       END;

    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_LOW_ANY',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_LOW_ANY',
                                                  pin_operation_id);

    /*     V_INSERT := v_insert_hint || ' INTO '
    || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) ||
    ' (ROW_IDENTIFIER, ROW_VERSION, '
    || substr(pin_no_roll_up_table_columns, instr(pin_no_roll_up_table_columns, ',')+1) ||
    ') SELECT ' || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
    || case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END
    || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) ||
     ' FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
       WHERE EXISTS ';*/

    V_INSERT := v_insert_hint || ' INTO ' ||
                substr(pin_no_roll_up_table_columns,
                       1,
                       instr(pin_no_roll_up_table_columns, ',') - 1) ||
                ' (ROW_IDENTIFIER, ROW_VERSION, ';
    if (pin_nr_ent_col is not null) then
      V_INSERT := V_INSERT || pin_nr_ent_col;
      if pin_nr_non_ent_col is not null then
        V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col;
      end if;
    else
      if (pin_nr_non_ent_col is not null) then
        V_INSERT := V_INSERT || pin_nr_non_ent_col;
      end if;
    end if;

    --|| pin_nr_ent_col ||','|| pin_nr_non_ent_col ||

    V_INSERT := V_INSERT || ') SELECT ' ||
                substr(pin_no_roll_up_table_columns,
                       1,
                       instr(pin_no_roll_up_table_columns, ',') - 1) ||
                '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, ';
    /*|| case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END*/

    if (pin_nr_ent_col_alias is not null) then
      V_INSERT := V_INSERT || pin_nr_ent_col_alias;
      if pin_nr_non_ent_col_alias is not null then
        V_INSERT := V_INSERT || ',' || pin_nr_non_ent_col_alias;
      end if;
    else
      if (pin_nr_non_ent_col_alias is not null) then
        V_INSERT := V_INSERT || pin_nr_non_ent_col_alias;
      end if;
    end if;

    --|| pin_nr_ent_col_alias ||','|| pin_nr_non_ent_col_alias ||
    V_INSERT := V_INSERT || ' FROM ' || CON_INPUT_DATA_TABLE ||
                ' INPUT_DATA
			 WHERE EXISTS ';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST_ANY -- 1 -- V_INSERT = ' || V_INSERT);

    -- add the same filter
    v_insert := v_insert || v_filter;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST_ANY -- 2 -- V_INSERT = ' || V_INSERT);

    -- add the row_identifier filter
    v_insert := v_insert || ' AND EXISTS (SELECT 1 FROM ' ||
                CON_INSERT_DATA_TABLE || ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)
            AND NOT EXISTS ';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST_ANY -- 3 -- V_INSERT = ' || V_INSERT);

    -- add the select filter
    v_insert := v_insert || v_second_filter;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_INSERT_LOWEST_ANY -- 4A -- V_INSERT = ' || V_INSERT);

    -- log the query
    v_stamp := 'CREDITING.CR_ROLLUP - v_insert_low_any - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_INSERT),
                               ',v_insert_both => <value>',
                               v_stamp);
    END;

    EXECUTE IMMEDIATE V_INSERT;
/*    commons_utils.INSERT_LOGS('In CREDITING.CR_CREATE_INSERT_LOWEST_ANY -- 4B -- AFTER SUCCESSFUL EXEC IMMEDIATE of -- V_INSERT = ' ||
                              V_INSERT);*/

    -- save the execution plan
    COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                      pi_query_identifier => 'ADDITIONAL_LOWEST_ANY');
  /*  commons_utils.INSERT_LOGS('OUT CREDITING.CR_CREATE_INSERT_LOWEST_ANY');*/

  END CR_CREATE_INSERT_LOWEST_ANY;

  ---------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------
  FUNCTION CR_CREATE_PRIMARY_INSERT(pin_aggregate_values           IN NUMBER,
                                    pin_primary_table              IN VARCHAR2,
                                    pin_entity_roll_up_to_column   IN VARCHAR2,
                                    pin_entity_roll_up_from_column IN VARCHAR2,
                                    pin_levels_rolled_up_column    IN VARCHAR2,
                                    pin_fields_columns             IN VARCHAR2,
                                    pin_roll_up_from_type          IN NUMBER,
                                    pin_roll_up_to_type            IN NUMBER,
                                    pin_inputview_ent_fld          IN VARCHAR2,
                                    pin_operation_id               IN NUMBER,
                                    pin_INSTDT_NOROLLUP_COLUMNS    IN VARCHAR2,
                                    pin_non_ent_col                IN varchar2,
                                    pin_non_ent_col_alias          IN varchar2,
                                    pin_ent_col                    IN varchar2,
                                    pin_ent_col_alias              IN varchar2)
    RETURN CLOB AS

    V_INSERT      CLOB;
    v_insert_hint VARCHAR2(32767);

  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- pin_aggregate_values = ' || pin_aggregate_values || ' -- pin_primary_table = ' || pin_primary_table || ' -- pin_entity_roll_up_to_column = ' || pin_entity_roll_up_to_column || ' -- pin_entity_roll_up_from_column = ' || pin_entity_roll_up_from_column || ' -- pin_levels_rolled_up_column = ' || pin_levels_rolled_up_column || ' -- pin_fields_columns = ' || pin_fields_columns || ' -- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_roll_up_to_type = ' || pin_roll_up_to_type || ' -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_operation_id = ' || pin_operation_id);

    -- add the hint framework
    v_insert_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY',
                                                               'ROLLUP_INSERT_PRIMARY',
                                                               pin_operation_id) ||
                     'INSERT ' ||
                     COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY',
                                                  'ROLLUP_INSERT_PRIMARY',
                                                  pin_operation_id);
    -- add the insert condition

    V_INSERT := v_insert_hint || ' INTO ' || pin_primary_table ||
                ' (ROW_IDENTIFIER, ROW_VERSION,' ||
                pin_entity_roll_up_to_column;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 1 -- V_INSERT = ' || V_INSERT);
    -- if the entity to roll up from must be included in the primary output
    IF (pin_entity_roll_up_from_column IS NOT NULL) THEN
      V_INSERT := V_INSERT || ', ' || pin_entity_roll_up_from_column;
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 2 -- V_INSERT = ' || V_INSERT);
    -- add the levels rolled up if it exists
    IF (pin_levels_rolled_up_column IS NOT NULL) THEN
      V_INSERT := V_INSERT || ', ' || pin_levels_rolled_up_column;
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 3 -- V_INSERT = ' || V_INSERT);
    -- add the fields to roll up
    IF (pin_fields_columns IS NOT NULL) THEN
      V_INSERT := V_INSERT || ', ' || pin_fields_columns;
    END IF;

    if (pin_aggregate_values = 0) then
      if pin_ent_col is not null then
        V_INSERT := V_INSERT || ',' || pin_ent_col;
      end if;

      if pin_non_ent_col is not null then
        V_INSERT := V_INSERT || ',' || pin_non_ent_col;
      end if;
    end if;

    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 4 -- V_INSERT = ' || V_INSERT);
    -- the values to be added
    IF (pin_roll_up_from_type = pin_roll_up_to_type) THEN
      V_INSERT := V_INSERT || ') SELECT ' || pin_primary_table ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, NVL(ROOT, ENT_LOWER), ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 5_IF -- V_INSERT = ' || V_INSERT);
    ELSE
      V_INSERT := V_INSERT || ') SELECT ' || pin_primary_table ||
                  '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, ROOT, ';
      -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 5_ELSE -- V_INSERT = ' || V_INSERT);
    END IF;
    -- if the entity to roll up from must be included in the primary output
    IF (pin_entity_roll_up_from_column IS NOT NULL) THEN
      IF (pin_roll_up_from_type = pin_roll_up_to_type) AND
         (pin_entity_roll_up_from_column IS NOT NULL) AND
         regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$') THEN
        V_INSERT := V_INSERT || pin_entity_roll_up_from_column || ', ';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 6_IF_IF -- V_INSERT = ' || V_INSERT);
      ELSIF (NOT regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$')) THEN
        V_INSERT := V_INSERT || 'ENTITY, ';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 6_IF_ELSIF -- V_INSERT = ' || V_INSERT);
      ELSE
        V_INSERT := V_INSERT || 'ENT_LOWER, ';
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 6_IF_ELSE -- V_INSERT = ' || V_INSERT);
      END IF;
    END IF;
    -- add the levels rolled up if it exists
    IF (pin_levels_rolled_up_column IS NOT NULL) THEN
      V_INSERT := V_INSERT || 'LVL, ';
    END IF;
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 7 -- V_INSERT = ' || V_INSERT);
    -- add the fields rolled up
    -- if the values are not aggregated
    IF (pin_fields_columns IS NOT NULL) THEN
      IF (pin_aggregate_values = 0) THEN
        FOR i IN 1 .. nvl(regexp_count(pin_fields_columns, ','), -1) + 1 LOOP
          V_INSERT := V_INSERT || 'VALUE' || i || ', ';
        end loop;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 8_IF_IF-- V_INSERT = ' || V_INSERT);
        -- if the values are aggregated
      ELSE
        FOR i IN 1 .. nvl(regexp_count(pin_fields_columns, ','), -1) + 1 LOOP
          V_INSERT := V_INSERT || 'TO_SUM' || i || ', ';
        end loop;
        -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- 8_IF_ELSE-- V_INSERT = ' || V_INSERT);
      END IF;
    END IF;

    if (pin_aggregate_values = 0) then
      if pin_ent_col_alias is not null then
        V_INSERT := V_INSERT || pin_ent_col_alias;
        if pin_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || ',' || pin_non_ent_col_alias;
        end if;
        V_INSERT := V_INSERT || '  ';
      else
        if pin_non_ent_col_alias is not null then
          V_INSERT := V_INSERT || pin_non_ent_col_alias || '  ';
        end if;
      end if;

    end if;
    V_INSERT := substr(V_INSERT, 1, length(V_INSERT) - 2) || ' FROM (';
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_PRIMARY_INSERT -- FINAL -- 9 -- V_INSERT = ' || V_INSERT);

    RETURN V_INSERT;
    -- INSERT_LOGS ('OUT CREDITING.CR_CREATE_PRIMARY_INSERT');

  END CR_CREATE_PRIMARY_INSERT;

  ----------------------------------------------------------------------------------------------
  ----------------------------------------------------------------------------------------------

  PROCEDURE CR_CREATE_SELECT_ROLLUP(pin_inputview_columns          IN varchar2,
                                    pin_rollup_alias_columns       IN VARCHAR2,
                                    pin_inputview_ent_fld          IN varchar2,
                                    pin_inputview                  IN clob,
                                    pin_relationship_tables        IN TABLETYPE_RELATIONSHIP_TABLES,
                                    pin_include_input_records      IN number,
                                    pin_roll_up_from_type          IN number,
                                    pin_roll_up_to_type            IN number,
                                    pin_level_from                 IN number,
                                    pin_aggregate_values           IN number,
                                    pin_level_to                   IN NUMBER,
                                    pin_date_period_column         IN varchar2,
                                    pin_new_date_period_column     IN varchar2,
                                    pin_date_run_for               IN date,
                                    pin_period_run_for             IN number,
                                    pin_is_effective_period        IN number,
                                    pin_start_period_column        IN varchar2,
                                    pin_end_period_column          IN varchar2,
                                    pin_process_run_for            IN number,
                                    pin_RECORD_BASED_ON_OPTION     IN number,
                                    pin_RECORDS_BETWEEN_OPTION     in number,
                                    pin_Field_To_Match             in varchar2,
                                    pin_entity_roll_up_from_column IN varchar2,
                                    pin_fields_columns             IN VARCHAR2,
                                    PIN_CRSTRUCT_TABLE In varchar2,
                                    pin_operation_id               IN NUMBER,
                                    pin_run_id                     IN NUMBER,

                                    pout_primary_select          OUT NOCOPY CLOB,
                                    POUT_INSTDT_NOROLLUP_COLUMNS OUT VARCHAR2) AS

    V_INPUT_DATA_ENTITY            varchar2(30);
    V_INPUT_DATA_VALUES_NO         NUMBER(2);
    V_INPUTVIEW_NOROLLUP_COLUMNS   VARCHAR2(32767);
    V_INPUTDATA_NOROLLUP_COLUMNS   VARCHAR2(32767);
    V_INSRTDATA_NOROLLUP_COLUMNS   VARCHAR2(32767);
    V_A_INPUTVIEW_NOROLLUP_COLUMNS VARCHAR2(32767);
    V_rollup_alias_columns         VARCHAR2(32767);
    V_IS_FIELD                     NUMBER(1);
    v_ENTITY_FIELD                 BOOLEAN;

    VCOL_INPUT_VIEW_COLUMNS    TABLETYPE_COLUMN := TABLETYPE_COLUMN();
    VCOL_INPUT_VIEW_COLUMNS_NA TABLETYPE_COLUMN := TABLETYPE_COLUMN();

  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_CREATE_SELECT_ROLLUP -- pin_inputview_columns = ' || pin_inputview_columns || ' -- pin_rollup_alias_columns = ' || pin_rollup_alias_columns || ' -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_inputview = ' || pin_inputview || ' -- pin_include_input_records = ' || pin_include_input_records || '-- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_roll_up_to_type = ' || pin_roll_up_to_type || ' -- pin_level_from = ' || pin_level_from || ' -- pin_aggregate_values = ' || pin_aggregate_values || ' -- pin_level_to = ' || pin_level_to || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_new_date_period_column = ' || pin_new_date_period_column || ' -- pin_date_run_for = ' || pin_date_run_for || ' -- pin_period_run_for = ' || pin_period_run_for || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_start_period_column = ' || pin_start_period_column || ' -- pin_end_period_column = ' || pin_end_period_column || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_entity_roll_up_from_column = ' || pin_entity_roll_up_from_column || ' -- pin_fields_columns = ' || pin_fields_columns || ' -- pin_operation_id = ' || pin_operation_id || ' -- pin_run_id = ' || pin_run_id);

    -- check entity key field type
    SELECT fld_data_type
      INTO V_ENTITY_IS_NUMBER
      FROM fields f
     WHERE f.fld_column_name =
           commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' ||
                                                 pin_roll_up_from_type)
       AND ROWNUM = 1;
    -- INSERT_LOGS (' -- CHECK: 1 : BEFORE IF BLOCK -- V_INPUT_DATA_ENTITY = ' || V_INPUT_DATA_ENTITY || ' -- pin_inputview_columns = ' || pin_inputview_columns) ;
    IF (instr(pin_inputview_columns, ',') = 0) THEN
      -- INSERT_LOGS (' -- CHECK: 2A : IF (instr(pin_inputview_columns) = 0) THEN') ;
      V_INPUTVIEW_NOROLLUP_COLUMNS := '';
      V_INPUTDATA_NOROLLUP_COLUMNS := '';
      -- get the column name of the entity from the input table
      V_INPUT_DATA_ENTITY := pin_inputview_columns;
      -- INSERT_LOGS (' -- CHECK: 2B : V_INPUT_DATA_ENTITY = ' || V_INPUT_DATA_ENTITY) ;
    ELSE
      -- INSERT_LOGS (' -- CHECK: 3A : ELSE  of (instr(pin_inputview_columns) = 0) THEN') ;
      V_INPUTVIEW_NOROLLUP_COLUMNS := substr(replace(replace(pin_inputview_columns,
                                                             ' '),
                                                     ',',
                                                     ',a.'),
                                             instr(replace(pin_inputview_columns,
                                                           ' '),
                                                   ','));
      V_INPUTDATA_NOROLLUP_COLUMNS := substr(replace(replace(pin_inputview_columns,
                                                             ' '),
                                                     ',',
                                                     ',INPUT_DATA.'),
                                             instr(replace(pin_inputview_columns,
                                                           ' '),
                                                   ','));
      V_INSRTDATA_NOROLLUP_COLUMNS := substr(replace(replace(pin_inputview_columns,
                                                             ' '),
                                                     ',',
                                                     ',INPUT_DATA.'),
                                             instr(replace(pin_inputview_columns,
                                                           ' '),
                                                   ','));
      -- get the column name of the entity from the input table
      V_INPUT_DATA_ENTITY := substr(pin_inputview_columns,
                                    1,
                                    instr(replace(pin_inputview_columns || ',',
                                                  ' '),
                                          ',') - 1);
      -- INSERT_LOGS (' -- CHECK: 3B : V_INPUT_DATA_ENTITY = ' || V_INPUT_DATA_ENTITY) ;
    END IF;
    -- INSERT_LOGS (' -- CHECK: 4 : AFTER IF BLOCK -- V_INPUT_DATA_ENTITY = ' || V_INPUT_DATA_ENTITY) ;
    V_A_INPUTVIEW_NOROLLUP_COLUMNS := replace(replace(pin_inputview_columns,
                                                      ' '),
                                              ',',
                                              ',a.');

    -- get the column aliases without the row_identifier
    IF (instr(pin_rollup_alias_columns, ',') IS NULL) THEN
      v_rollup_alias_columns := '';
    ELSE
      IF (substr(pin_rollup_alias_columns, 1, 1) = 'E' OR (V_IS_FIELD = 1)) THEN
        V_rollup_alias_columns := replace(pin_rollup_alias_columns, ' ');
      ELSE
        V_rollup_alias_columns := substr(replace(pin_rollup_alias_columns,
                                                 ' '),
                                         instr(replace(pin_rollup_alias_columns,
                                                       ' '),
                                               ',') + 1);
      END IF;
    END IF;

    -- check if no values to rollup exist
    IF (pin_fields_columns IS NULL) THEN
      V_INPUT_DATA_VALUES_NO := 0;
    ELSE
      -- get the number of columns to roll up values for
      V_INPUT_DATA_VALUES_NO := regexp_count(v_rollup_alias_columns, ',') + 1;
    END IF;

    -- check if the roll up is done by entity or field
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');

    ------------------------
    ------------------------

    -- create the hierarchy input table
    CREDITING.CR_CREATE_HIERARCHY_INPUT(pin_is_effective_period => pin_is_effective_period,
                                        pin_date_period_column  => pin_date_period_column,
                                        pin_date_run_for        => pin_date_run_for,
                                        pin_relationship_tables => pin_relationship_tables,
                                        pin_process_run_for     => pin_process_run_for,
                                        pin_start_period_column => pin_start_period_column,
                                        pin_end_period_column   => pin_end_period_column,
                                        pin_period_run_for      => pin_period_run_for,
                                        pin_run_id              => pin_run_id,
                                        pin_operation_id        => pin_operation_id);

    -- create the input data table
    -- INSERT_LOGS (' -- CHECK: 5 : BEFORE CALL to CREDITING.CR_CREATE_INPUT_DATA -- V_INPUT_DATA_ENTITY = ' || V_INPUT_DATA_ENTITY) ;
    CREDITING.CR_CREATE_INPUT_DATA(pin_roll_up_from_type          => pin_roll_up_from_type,
                                   pin_rollup_alias_columns       => pin_rollup_alias_columns,
                                   pin_inputview_ent_fld          => pin_inputview_ent_fld,
                                   pin_inputview                  => pin_inputview,
                                   pin_date_period_column         => pin_date_period_column,
                                   pin_new_date_period_column     => pin_new_date_period_column,
                                   pin_fields_columns             => pin_fields_columns,
                                   pin_INPUTVIEW_NOROLLUP_COLUMNS => V_INPUTVIEW_NOROLLUP_COLUMNS,
                                   pin_A_INPUTVIEW_NOROLLUP_COLS  => V_A_INPUTVIEW_NOROLLUP_COLUMNS,
                                   pin_input_data_entity          => v_input_data_entity,
                                   pin_run_id                     => pin_run_id,

                                   pio_INPUT_VIEW_COLUMNS    => VCOL_INPUT_VIEW_COLUMNS,
                                   pio_INPUT_VIEW_COLUMNS_NA => VCOL_INPUT_VIEW_COLUMNS_NA);

    -- create connect by table
  /*  commons_utils.INSERT_LOGS(' call CREDITING.CR_CREATE_CBS_DATA');*/
    CREDITING.CR_CREATE_CBS_DATA(pin_roll_up_to_type        => pin_roll_up_to_type,
                                 pin_roll_up_from_type      => pin_roll_up_from_type,
                                 pin_level_to               => pin_level_to,
                                 pin_date_period_column     => pin_date_period_column,
                                 pin_RECORD_BASED_ON_OPTION => pin_RECORD_BASED_ON_OPTION,
                                 pin_RECORDS_BETWEEN_OPTION => pin_RECORDS_BETWEEN_OPTION,
                                 pin_Field_To_Match         => pin_Field_To_Match,
                                 pin_start_period_column    => pin_start_period_column,
                                 pin_end_period_column      => pin_end_period_column,
                                 pin_operation_id           => pin_operation_id,
                                 pin_run_id                 => pin_run_id);

    -- create insert data table
   /* commons_utils.INSERT_LOGS(' call CREDITING.CR_CREATE_INSERT_DATA');*/
    CREDITING.CR_CREATE_INSERT_DATA(PIN_ENTITY_FIELD               => v_ENTITY_FIELD,
                                    pin_entity_roll_up_from_column => pin_entity_roll_up_from_column,
                                    pin_inputview_columns          => pin_inputview_columns,
                                    PIN_ROLL_UP_FROM_TYPE          => PIN_ROLL_UP_FROM_TYPE,
                                    PIN_ROLL_UP_TO_TYPE            => PIN_ROLL_UP_TO_TYPE,
                                    PIN_LEVEL_FROM                 => PIN_LEVEL_FROM,
                                    PIN_DATE_PERIOD_COLUMN         => PIN_DATE_PERIOD_COLUMN,
                                    PIN_INPUT_DATA_VALUES_NO       => V_INPUT_DATA_VALUES_NO,
                                    PIN_INPUTDATA_NOROLLUP_COLUMNS => V_INPUTDATA_NOROLLUP_COLUMNS,
                                    pin_is_effective_period        => pin_is_effective_period,
                                    pin_process_run_for            => pin_process_run_for,
                                    pin_RECORD_BASED_ON_OPTION     => pin_RECORD_BASED_ON_OPTION,
                                    pin_RECORDS_BETWEEN_OPTION     => pin_RECORDS_BETWEEN_OPTION,
                                    pin_Field_To_Match             => pin_Field_To_Match,
                                    pin_start_period_column        => pin_start_period_column,
                                    pin_end_period_column          => pin_end_period_column,
                                    PIN_CRSTRUCT_TABLE=>PIN_CRSTRUCT_TABLE,
                                    /*  pin_start_period_column        => pin_start_period_column,*/
                                    PIN_OPERATION_ID      => PIN_OPERATION_ID,
                                    PIN_RUN_ID            => PIN_RUN_ID,
                                    pin_input_data_entity => v_input_data_entity,
                                    pin_aggregate_values  => pin_aggregate_values);

    -- create the main select
    CREDITING.CR_CREATE_MAIN_SELECT(pin_roll_up_from_type          => pin_roll_up_from_type,
                                    pin_roll_up_to_type            => pin_roll_up_to_type,
                                    pin_level_from                 => pin_level_from,
                                    pin_entity_roll_up_from_column => pin_entity_roll_up_from_column,
                                    pin_inputview_columns          => pin_inputview_columns,
                                    pin_entity_field               => v_entity_field,
                                    pin_aggregate_values           => pin_aggregate_values,
                                    pin_input_data_values_no       => v_input_data_values_no,
                                    pin_INPUT_VIEW_COLUMNS_NA      => VCOL_INPUT_VIEW_COLUMNS_NA,
                                    pin_include_input_records      => pin_include_input_records,
                                    pin_run_id                     => pin_run_id,
                                    pin_operation_id               => pin_operation_id,
                                    PIN_INPUTDATA_NOROLLUP_COLUMNS => V_INPUTDATA_NOROLLUP_COLUMNS,
                                    pin_input_data_entity          => v_input_data_entity,

                                    pio_select => pout_primary_select);

    -- INSERT_LOGS ('OUT CREDITING.CR_CREATE_SELECT_ROLLUP -- pout_primary_select = ' || pout_primary_select);
  END CR_CREATE_SELECT_ROLLUP;

  PROCEDURE CR_ROLLUP(pin_inputview_columns          IN varchar2,
                      pin_rollup_alias_columns       IN VARCHAR2,
                      pin_inputview_ent_fld          IN varchar2,
                      pin_inputview                  IN clob,
                      pin_relationship_tables        IN TABLETYPE_RELATIONSHIP_TABLES,
                      pin_levels_rolled_up_column    IN varchar2,
                      pin_include_input_records      IN number,
                      pin_roll_up_from_type          IN number,
                      pin_roll_up_to_type            IN number,
                      pin_level_from                 IN number,
                      pin_aggregate_values           IN number,
                      pin_level_to                   IN number,
                      pin_no_roll_up_table_columns   IN varchar2,
                      pin_no_match_table_columns     IN varchar2,
                      pin_is_effective_period        IN number,
                      pin_start_period_column        IN varchar2,
                      pin_end_period_column          IN varchar2,
                      pin_process_run_for            IN number,
                      pin_RECORD_BASED_ON_OPTION     IN number,
                      pin_RECORDS_BETWEEN_OPTION     in number,
                      pin_Field_To_Match             IN varchar2,
                      pin_date_period_column         IN varchar2,
                      pin_new_date_period_column     IN varchar2,
                      pin_entity_roll_up_to_column   IN varchar2,
                      PIN_CRSTRUCT_TABLE in varchar2,
                      pin_entity_roll_up_from_column IN varchar2,
                      pin_fields_columns             IN varchar2,
                      pin_output_where_clause        IN clob,
                      pin_primary_table              IN varchar2,
                      pin_date_run_for               IN date,
                      pin_period_run_for             IN number,
                      pin_operation_id               IN NUMBER,
                      pin_run_id                     IN NUMBER,
                      pin_non_ent_col                IN varchar2,
                      pin_non_ent_col_alias          IN varchar2,
                      pin_ent_col                    IN varchar2,
                      pin_ent_col_alias              IN varchar2,
                      pin_nm_non_ent_col             IN varchar2,
                      pin_nm_non_ent_col_alias       IN varchar2,
                      pin_nm_ent_col                 IN varchar2,
                      pin_nm_ent_col_alias           IN varchar2,
                      pin_nr_non_ent_col             IN varchar2,
                      pin_nr_non_ent_col_alias       IN varchar2,
                      pin_nr_ent_col                 IN varchar2,
                      pin_nr_ent_col_alias           IN varchar2,
                      pout_primary_rows              OUT number,
                      pout_no_rollup_rows            OUT number,
                      pout_no_match_rows             OUT number) AS

    CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id ||
                                                      CR_SEQ.NEXTVAL;
    CON_CONN_BY_SELECT_NAME  CONSTANT VARCHAR2(30) := 'CBS' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;
    CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id ||
                                                      CR_SEQ.CURRVAL;

    v_primary_rows   NUMBER;
    v_no_rollup_rows NUMBER;
    v_no_match_rows  NUMBER;
    v_query          CLOB;
    v_primary_query  CLOB;

    V_INSRTDATA_NOROLLUP_COLUMNS VARCHAR2(32767);

  BEGIN
    -- INSERT_LOGS ('In CREDITING.CR_ROLLUP -- pin_inputview_columns = ' || pin_inputview_columns || ' -- pin_rollup_alias_columns = ' || pin_rollup_alias_columns || ' -- pin_inputview_ent_fld = ' || pin_inputview_ent_fld || ' -- pin_inputview = ' || pin_inputview || ' -- pin_levels_rolled_up_column = ' || pin_levels_rolled_up_column || ' -- pin_include_input_records = ' || pin_include_input_records || '-- pin_roll_up_from_type = ' || pin_roll_up_from_type || ' -- pin_roll_up_to_type = ' || pin_roll_up_to_type || ' -- pin_level_from = ' || pin_level_from || ' -- pin_aggregate_values = ' || pin_aggregate_values || ' -- pin_level_to = ' || pin_level_to  || ' -- pin_no_roll_up_table_columns = ' || pin_no_roll_up_table_columns || ' -- pin_no_match_table_columns = ' || pin_no_match_table_columns || ' -- pin_is_effective_period = ' || pin_is_effective_period || ' -- pin_start_period_column = ' || pin_start_period_column || ' -- pin_end_period_column = ' || pin_end_period_column || ' -- pin_process_run_for = ' || pin_process_run_for || ' -- pin_date_period_column = ' || pin_date_period_column || ' -- pin_new_date_period_column = ' || pin_new_date_period_column || ' -- pin_entity_roll_up_to_column = ' || pin_entity_roll_up_to_column || ' -- pin_entity_roll_up_from_column = ' || pin_entity_roll_up_from_column || ' -- pin_fields_columns = ' || pin_fields_columns || ' -- pin_output_where_clause = ' || pin_output_where_clause || ' -- pin_primary_table = ' || pin_primary_table || ' -- pin_date_run_for = ' || pin_date_run_for || ' -- pin_period_run_for = ' || pin_period_run_for || ' -- pin_operation_id = ' || pin_operation_id || ' -- pin_run_id = ' || pin_run_id);

    v_stamp := 'CREDITING.CR_ROLLUP - input - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    -- log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_INPUTVIEW_COLUMNS),
                               ',PIN_INPUTVIEW_COLUMNS => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(pin_rollup_alias_columns),
                               ',PIN_ROLLUP_ALIAS_COLUMNS => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_INPUTVIEW_ENT_FLD),
                               ',PIN_INPUTVIEW_ENT_FLD => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PIN_INPUTVIEW),
                               ',PIN_INPUTVIEW => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(PIN_RELATIONSHIP_TABLES),
                               ',PIN_RELATIONSHIP_TABLES => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_LEVELS_ROLLED_UP_COLUMN),
                               ',PIN_LEVELS_ROLLED_UP_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_INCLUDE_INPUT_RECORDS),
                               ',PIN_INCLUDE_INPUT_RECORDS => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_ROLL_UP_FROM_TYPE),
                               ',PIN_ROLL_UP_FROM_TYPE => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_ROLL_UP_TO_TYPE),
                               ',PIN_ROLL_UP_TO_TYPE => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_LEVEL_FROM),
                               ',PIN_LEVEL_FROM => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_AGGREGATE_VALUES),
                               ',PIN_AGGREGATE_VALUES => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_LEVEL_TO),
                               ',PIN_LEVEL_TO => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_NO_ROLL_UP_TABLE_COLUMNS),
                               ',PIN_NO_ROLL_UP_TABLE_COLUMNS => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_NO_MATCH_TABLE_COLUMNS),
                               ',PIN_NO_MATCH_TABLE_COLUMNS => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_IS_EFFECTIVE_PERIOD),
                               ',PIN_IS_EFFECTIVE_PERIOD => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_START_PERIOD_COLUMN),
                               ',PIN_START_PERIOD_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_END_PERIOD_COLUMN),
                               ',PIN_END_PERIOD_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_PROCESS_RUN_FOR),
                               ',PIN_PROCESS_RUN_FOR => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_DATE_PERIOD_COLUMN),
                               ',PIN_DATE_PERIOD_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_NEW_DATE_PERIOD_COLUMN),
                               ',PIN_NEW_DATE_PERIOD_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ENTITY_ROLL_UP_TO_COLUMN),
                               ',PIN_ENTITY_ROLL_UP_TO_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ENTITY_ROLL_UP_FROM_COLUMN),
                               ',PIN_ENTITY_ROLL_UP_FROM_COLUMN => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_FIELDS_COLUMNS),
                               ',PIN_FIELDS_COLUMNS => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_OUTPUT_WHERE_CLAUSE),
                               ',PIN_OUTPUT_WHERE_CLAUSE => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_PRIMARY_TABLE),
                               ',PIN_PRIMARY_TABLE => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTDATE(PIN_DATE_RUN_FOR),
                               ',PIN_DATE_RUN_FOR => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_PERIOD_RUN_FOR),
                               ',PIN_PERIOD_RUN_FOR => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_OPERATION_ID),
                               ',PIN_OPERATION_ID => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_RUN_ID),
                               ',PIN_RUN_ID => <value>',
                               v_stamp);
    END;

    -- get the queries
    CREDITING.CR_CREATE_SELECT_ROLLUP(pin_inputview_columns          => pin_inputview_columns,
                                      pin_rollup_alias_columns       => CASE
                                                                          WHEN pin_rollup_alias_columns IS NULL THEN
                                                                           pin_fields_columns
                                                                          ELSE
                                                                           pin_rollup_alias_columns
                                                                        END,
                                      pin_inputview_ent_fld          => pin_inputview_ent_fld,
                                      pin_inputview                  => pin_inputview,
                                      pin_relationship_tables        => pin_relationship_tables,
                                      pin_include_input_records      => pin_include_input_records,
                                      pin_roll_up_from_type          => pin_roll_up_from_type,
                                      pin_roll_up_to_type            => pin_roll_up_to_type,
                                      pin_level_from                 => NVL(pin_level_from,
                                                                            1),
                                      pin_aggregate_values           => pin_aggregate_values,
                                      pin_level_to                   => NVL(pin_level_to,
                                                                            0),
                                      pin_is_effective_period        => pin_is_effective_period,
                                      pin_period_run_for             => pin_period_run_for,
                                      pin_RECORD_BASED_ON_OPTION     => pin_RECORD_BASED_ON_OPTION,
                                      pin_RECORDS_BETWEEN_OPTION     => pin_RECORDS_BETWEEN_OPTION,
                                      pin_Field_To_Match             => pin_Field_To_Match,
                                      pin_date_run_for               => pin_date_run_for,
                                      pin_date_period_column         => pin_date_period_column,
                                      pin_new_date_period_column     => pin_new_date_period_column,
                                      pin_start_period_column        => pin_start_period_column,
                                      pin_end_period_column          => pin_end_period_column,
                                      PIN_CRSTRUCT_TABLE =>PIN_CRSTRUCT_TABLE,
                                      pin_process_run_for            => pin_process_run_for,
                                      pin_entity_roll_up_from_column => pin_entity_roll_up_from_column,
                                      pin_fields_columns             => pin_fields_columns,
                                      pin_operation_id               => pin_operation_id,
                                      pin_run_id                     => pin_run_id,

                                      pout_primary_select          => v_primary_query,
                                      POUT_INSTDT_NOROLLUP_COLUMNS => V_INSRTDATA_NOROLLUP_COLUMNS);
   /* commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 1 -- v_primary_query = ' ||
                              v_primary_query);*/

    -- log the query
    v_query := CREDITING.CR_CREATE_PRIMARY_INSERT(pin_aggregate_values           => pin_aggregate_values,
                                                  pin_primary_table              => pin_primary_table,
                                                  pin_entity_roll_up_to_column   => pin_entity_roll_up_to_column,
                                                  pin_entity_roll_up_from_column => pin_entity_roll_up_from_column,
                                                  pin_levels_rolled_up_column    => pin_levels_rolled_up_column,
                                                  pin_fields_columns             => pin_fields_columns,
                                                  pin_roll_up_from_type          => pin_roll_up_from_type,
                                                  pin_roll_up_to_type            => pin_roll_up_to_type,
                                                  pin_inputview_ent_fld          => pin_inputview_ent_fld,
                                                  pin_operation_id               => pin_operation_id,
                                                  pin_INSTDT_NOROLLUP_COLUMNS    => V_INSRTDATA_NOROLLUP_COLUMNS,
                                                  pin_non_ent_col                => pin_non_ent_col,
                                                  pin_non_ent_col_alias          => pin_non_ent_col_alias,
                                                  pin_ent_col                    => pin_ent_col,
                                                  pin_ent_col_alias              => pin_ent_col_alias) ||
               v_primary_query || CASE
                 WHEN (pin_aggregate_values = 1) THEN
                  ') WHERE ROWNO = MAX_ROW_NUM'
                 ELSE
                  ')'
               END;

 /*   commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 2A -- v_query = ' ||
                              v_query);*/

    v_stamp := 'CREDITING.CR_ROLLUP - query - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(v_query),
                               ',v_query => <value>',
                               v_stamp);
    END;
    -- check the cardinality
    commons.terminate_insane_query(v_query, pin_run_id);

  /*  commons_utils.INSERT_LOGS('v_query in cr_roll_up=' || v_query);*/
    EXECUTE IMMEDIATE v_query;
    -- save the total number of rows
    v_primary_rows := SQL%ROWCOUNT;
   /* commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 2B -- AFTER SUCCESSFUL EXEC IMMEDIATE of -- v_query = ' ||
                              v_query);
    commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 3A -- v_primary_rows = ' ||
                              v_primary_rows);*/

    -- save the execution plan
    COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => pin_run_id,
                                      pi_query_identifier => 'PRIMARY_TABLE');

    -- delete the filtered rows
    IF (pin_output_where_clause IS NOT NULL) THEN
   /*   commons_utils.INSERT_LOGS('pin_output_where_clause in cr_roll_up=' ||
                                'DELETE FROM ' || pin_primary_table ||
                                ' WHERE ROW_IDENTIFIER NOT IN (' ||
                                pin_output_where_clause || ')');*/
      EXECUTE IMMEDIATE 'DELETE FROM ' || pin_primary_table ||
                        ' WHERE ROW_IDENTIFIER NOT IN (' ||
                        pin_output_where_clause || ')';
      -- remove the deleted rows
      v_primary_rows := v_primary_rows - SQL%ROWCOUNT;
     /* commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 3B -- FINAL v_primary_rows = ' ||
                                v_primary_rows);*/
    END IF;

    -- if an additional table is selected
    IF (pin_no_match_table_columns IS NOT NULL OR
       pin_no_roll_up_table_columns IS NOT NULL) THEN
      IF (pin_level_from = 0) THEN
        -- if the lowest values are selected
/*        commons_utils.INSERT_LOGS('CR_CREATE_INSERT_LOWEST ');*/

        CREDITING.CR_CREATE_INSERT_LOWEST(pin_inputview_ent_fld        => pin_inputview_ent_fld,
                                          pin_inputview_columns        => pin_inputview_columns,
                                          pin_no_match_table_columns   => pin_no_match_table_columns,
                                          pin_no_roll_up_table_columns => pin_no_roll_up_table_columns,
                                          pin_roll_up_from_type        => pin_roll_up_from_type,
                                          pin_run_id                   => pin_run_id,
                                          pin_is_effective_period      => pin_is_effective_period,
                                          pin_process_run_for          => pin_process_run_for,
                                          pin_date_period_column       => pin_date_period_column,
                                          pin_start_period_column      => pin_start_period_column,
                                          pin_operation_id             => pin_operation_id,
                                          pin_nm_non_ent_col           => pin_nm_non_ent_col,
                                          pin_nm_non_ent_col_alias     => pin_nm_non_ent_col_alias,
                                          pin_nm_ent_col               => pin_nm_ent_col,
                                          pin_nm_ent_col_alias         => pin_nm_ent_col_alias,
                                          pin_nr_non_ent_col           => pin_nr_non_ent_col,
                                          pin_nr_non_ent_col_alias     => pin_nr_non_ent_col_alias,
                                          pin_nr_ent_col               => pin_nr_ent_col,
                                          pin_nr_ent_col_alias         => pin_nr_ent_col_alias);
        -- if any option is selected
        IF (pin_period_run_for = 2) THEN

     /*     commons_utils.INSERT_LOGS('CR_CREATE_INSERT_LOWEST_ANY ');*/
          CREDITING.CR_CREATE_INSERT_LOWEST_ANY(pin_inputview_ent_fld        => pin_inputview_ent_fld,
                                                pin_inputview_columns        => pin_inputview_columns,
                                                pin_no_roll_up_table_columns => pin_no_roll_up_table_columns,
                                                pin_roll_up_from_type        => pin_roll_up_from_type,
                                                pin_run_id                   => pin_run_id,
                                                pin_is_effective_period      => pin_is_effective_period,
                                                pin_process_run_for          => pin_process_run_for,
                                                pin_date_period_column       => pin_date_period_column,
                                                pin_start_period_column      => pin_start_period_column,
                                                pin_operation_id             => pin_operation_id,
                                                pin_nr_non_ent_col           => pin_nr_non_ent_col,
                                                pin_nr_non_ent_col_alias     => pin_nr_non_ent_col_alias,
                                                pin_nr_ent_col               => pin_nr_ent_col,
                                                pin_nr_ent_col_alias         => pin_nr_ent_col_alias);
        END IF;
      ELSE
        /* pin_start_period_column        =>   pin_start_period_column,
        pin_end_period_column          =>   pin_end_period_column,*/
        -- if all values option was selected
      /*  commons_utils.INSERT_LOGS('CR_CREATE_INSERT_NO_MATCH_ROLL ');*/
        CREDITING.CR_CREATE_INSERT_NO_MATCH_ROLL(pin_inputview_columns        => pin_inputview_columns,
                                                 pin_no_match_table_columns   => pin_no_match_table_columns,
                                                 pin_no_roll_up_table_columns => pin_no_roll_up_table_columns,
                                                 pin_roll_up_from_type        => pin_roll_up_from_type,
                                                 pin_run_id                   => pin_run_id,
                                                 pin_is_effective_period      => pin_is_effective_period,
                                                 pin_process_run_for          => pin_process_run_for,
                                                 pin_date_period_column       => pin_date_period_column,
                                                 pin_start_period_column      => pin_start_period_column,
                                                 pin_end_period_column        => pin_end_period_column,
                                                 pin_inputview_ent_fld        => pin_inputview_ent_fld,
                                                 pin_period_run_for           => pin_period_run_for,
                                                 pin_operation_id             => pin_operation_id,
                                                 pin_RECORD_BASED_ON_OPTION   => pin_RECORD_BASED_ON_OPTION,
                                                 pin_RECORDS_BETWEEN_OPTION   => pin_RECORDS_BETWEEN_OPTION,
                                                 pin_Field_To_Match           => pin_Field_To_Match,
                                                 pin_nm_non_ent_col           => pin_nm_non_ent_col,
                                                 pin_nm_non_ent_col_alias     => pin_nm_non_ent_col_alias,
                                                 PIN_CRSTRUCT_TABLE=>PIN_CRSTRUCT_TABLE,
                                                 pin_nm_ent_col               => pin_nm_ent_col,
                                                 pin_nm_ent_col_alias         => pin_nm_ent_col_alias,
                                                 pin_nr_non_ent_col           => pin_nr_non_ent_col,
                                                 pin_nr_non_ent_col_alias     => pin_nr_non_ent_col_alias,
                                                 pin_nr_ent_col               => pin_nr_ent_col,
                                                 pin_nr_ent_col_alias         => pin_nr_ent_col_alias);
        -- if any option is selected
        IF (pin_period_run_for = 2) THEN
         /* commons_utils.INSERT_LOGS('CR_CREATE_INSERT_NO_ROLL_ANY ');*/
          CREDITING.CR_CREATE_INSERT_NO_ROLL_ANY(pin_inputview_columns        => pin_inputview_columns,
                                                 pin_no_roll_up_table_columns => pin_no_roll_up_table_columns,
                                                 pin_roll_up_from_type        => pin_roll_up_from_type,
                                                 pin_run_id                   => pin_run_id,
                                                 pin_is_effective_period      => pin_is_effective_period,
                                                 pin_process_run_for          => pin_process_run_for,
                                                 pin_date_period_column       => pin_date_period_column,
                                                 pin_start_period_column      => pin_start_period_column,
                                                 pin_inputview_ent_fld        => pin_inputview_ent_fld,
                                                 pin_period_run_for           => pin_period_run_for,
                                                 pin_operation_id             => pin_operation_id,
                                                 pin_nr_non_ent_col           => pin_nr_non_ent_col,
                                                 pin_nr_non_ent_col_alias     => pin_nr_non_ent_col_alias,
                                                 pin_nr_ent_col               => pin_nr_ent_col,
                                                 pin_nr_ent_col_alias         => pin_nr_ent_col_alias);
        END IF;
      END IF;
      IF (pin_no_roll_up_table_columns IS NOT NULL) THEN
        -- count all records
        /*commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 4 -- v_no_rollup_rows = ' ||
                                  'SELECT COUNT(*)
                               FROM ' ||
                                  substr(pin_no_roll_up_table_columns,
                                         1,
                                         instr(pin_no_roll_up_table_columns,
                                               ',') - 1));*/
        EXECUTE IMMEDIATE 'SELECT COUNT(*)
                               FROM ' ||
                          substr(pin_no_roll_up_table_columns,
                                 1,
                                 instr(pin_no_roll_up_table_columns, ',') - 1)
          INTO v_no_rollup_rows;
        -- commons_utils.INSERT_LOGS ('In CREDITING.CR_ROLLUP -- 4 -- v_no_rollup_rows = ' || v_no_rollup_rows);
      END IF;

      IF (pin_no_match_table_columns IS NOT NULL) THEN
        -- count all the records
      /*  commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 5 -- v_no_match_rows = ' ||
                                  'SELECT COUNT(*)
                               FROM ' ||
                                  substr(pin_no_match_table_columns,
                                         1,
                                         instr(pin_no_match_table_columns,
                                               ',') - 1));*/
        EXECUTE IMMEDIATE 'SELECT COUNT(*)
                               FROM ' ||
                          substr(pin_no_match_table_columns,
                                 1,
                                 instr(pin_no_match_table_columns, ',') - 1)
          INTO v_no_match_rows;
 /*       commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- 5 -- v_no_match_rows = ' ||
                                  v_no_match_rows);*/
      END IF;

    END IF;

    -- add the values in the output parameters
    pout_primary_rows   := v_primary_rows;
    pout_no_rollup_rows := v_no_rollup_rows;
    pout_no_match_rows  := v_no_match_rows;

    v_stamp := 'CREDITING.CR_ROLLUP - output - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    -- log the output parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(v_no_rollup_rows),
                               ',pout_no_rollup_rows => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(v_no_match_rows),
                               ',pout_no_match_rows => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(v_primary_rows),
                               ',pout_primary_rows => <value>',
                               v_stamp);
    END;

    -- drop the created tables
/*    commons_utils.INSERT_LOGS('In CREDITING.CR_ROLLUP -- Dropping tables -- CON_HIERARCHY_TABLE_NAME = ' ||
                              CON_HIERARCHY_TABLE_NAME ||
                              ' -- CON_INPUT_DATA_TABLE = ' ||
                              CON_INPUT_DATA_TABLE ||
                              ' -- CON_CONN_BY_SELECT_NAME = ' ||
                              CON_CONN_BY_SELECT_NAME ||
                              ' -- CON_INSERT_DATA_TABLE = ' ||
                              CON_INSERT_DATA_TABLE);*/
    FOR C IN (SELECT TABLE_NAME
                FROM USER_TABLES
               WHERE TABLE_NAME IN (CON_HIERARCHY_TABLE_NAME,
                                    CON_INPUT_DATA_TABLE,
                                    CON_CONN_BY_SELECT_NAME,
                                    CON_INSERT_DATA_TABLE)) LOOP
  /*    commons_utils.INSERT_LOGS('DROP TABLE ' || C.TABLE_NAME);*/
       COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' || C.TABLE_NAME);
    END LOOP;

  /*  commons_utils.INSERT_LOGS('OUT CREDITING.CR_ROLLUP -- pout_primary_rows = ' ||
                              pout_primary_rows ||
                              ' -- pout_no_rollup_rows = ' ||
                              pout_no_rollup_rows ||
                              ' -- pout_no_match_rows = ' ||
                              pout_no_match_rows);*/
  EXCEPTION
    WHEN OTHERS THEN
      FOR C IN (SELECT TABLE_NAME
                  FROM USER_TABLES
                 WHERE TABLE_NAME IN (CON_HIERARCHY_TABLE_NAME,
                                      CON_INPUT_DATA_TABLE,
                                      CON_CONN_BY_SELECT_NAME,
                                      CON_INSERT_DATA_TABLE)) LOOP
      /*  commons_utils.INSERT_LOGS('DROP TABLE ' || C.TABLE_NAME);*/
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' || C.TABLE_NAME);
      END LOOP;
  END CR_ROLLUP;
  ---------------------------------------
  ---------------------------------------
  ---------------------------------------

  PROCEDURE ISOLATE_OVERLAPPING_RECORDS(PI_SOURCE_TABLE_NAME      IN VARCHAR2, --Overlapping records will be deleted from this table.
                                        PI_OVERLAP_SET_TABLE_NAME IN VARCHAR2, --if not null then overlapping records will be inserted
                                        --into this table (incrementally).
                                        PI_KEY_FIELDS      IN CLOB,
                                        PI_EFFECTIVE_START IN VARCHAR2,
                                        PI_EFFECTIVE_END   IN VARCHAR2,
                                        PI_IS_PERIOD       IN NUMBER,
                                        PI_ID_COLUMN       IN VARCHAR2,
                                        PO_OVERLAP_CHK_RES OUT NUMBER) IS
    -- OF-10375 PRAGMA AUTONOMOUS_TRANSACTION
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_KEY_COLS       CLOB := PI_Key_Fields || ',';
    v_JOIN_CONDITION CLOB := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';
    v_INSERT_STR     CLOB := '';
    v_DELETE_STR     CLOB := '';
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           SYS_REFCURSOR;
    v_KEY_FIELDS     CLOB := '''' || REPLACE(pi_KEY_FIELDS, ',', ''',''') || '''';
    v_table          VARCHAR2(4000);

    --Checking the Columns data type
    v_data_type NUMBER;
    v_stamp     VARCHAR2(250); --OF-9688
  BEGIN
    -- INSERT_LOGS( ' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - START');
    -- INSERT_LOGS( ' -- v_KEY_FIELDS = ' || v_KEY_FIELDS);

    v_table := PI_SOURCE_TABLE_NAME;

    IF (pi_KEY_FIELDS IS NULL) THEN
      v_JOIN_CONDITION := NULL;
    ELSE
      v_JOIN_CONDITION := ' and ';

      OPEN cv_sql FOR '
select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || UPPER(PI_SOURCE_TABLE_NAME) || ''')) t
  where t.COLUMN_NAME in (' || UPPER(v_KEY_FIELDS) || ')';

      LOOP
        FETCH cv_sql
          INTO v_COL_NAME, v_IS_NULLABLE, v_data_type;
        EXIT WHEN cv_sql%NOTFOUND;

        -- if fields are Character or Not
        IF v_data_type in (1, 4) THEN
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( UPPER(a.' ||
                              v_COL_NAME || ') = UPPER(b.' || v_COL_NAME || '))' || CASE
                                WHEN v_IS_NULLABLE = 1 THEN
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' || v_COL_NAME ||
                                 ' IS NULL )'
                              END || ') and';
        ELSE
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( a.' || v_COL_NAME || ' = b.' ||
                              v_COL_NAME || ')' || CASE
                                WHEN v_IS_NULLABLE = 1 THEN
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                                 v_COL_NAME || ' IS NULL )'
                              END || ') and';
        END IF;
      END LOOP;

      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION,
                                 1,
                                 LENGTH(v_JOIN_CONDITION) - 4);
    END IF;

    -- INSERT_LOGS( ' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - v_JOIN_CONDITION = ' || v_JOIN_CONDITION);

    -- Overlap and date check
    IF (PI_is_Period = 0) THEN
      v_OVERLAP_STR := 'select a.*
  from ' || v_table || ' a, ' || v_table || ' b
  where (((nvl(a.' || PI_effective_start ||
                       ', to_date(''01/01/1900'', ''dd/mm/yyyy'')) <=  nvl(b.' ||
                       PI_effective_end || ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) and
          nvl(a.' || PI_effective_end ||
                       ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) >= nvl(b.' ||
                       PI_effective_start ||
                       ', to_date(''01/01/1900'', ''dd/mm/yyyy''))) and'
                      --changes for OF-14724 start (as per FD requirements for crediting records which have same start date and end date both will not be considered
                      --as overlapping. Such records will be candidates for aggregation.
                       || ' ((nvl(a.' || PI_effective_start ||
                       ', to_date(''01/01/1900'', ''dd/mm/yyyy'')) <> nvl(b.' ||
                       PI_effective_start ||
                       ', to_date(''01/01/1900'', ''dd/mm/yyyy''))) OR ' ||
                       '(nvl(a.' || PI_effective_end ||
                       ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) <> nvl(b.' ||
                       PI_effective_end ||
                       ', to_date(''31/12/9999'', ''dd/mm/yyyy'')))) and'
                      --changes for OF-14724 end
                       || ' a.' || PI_ID_COLUMN || ' <> b.' || PI_ID_COLUMN ||
                       ')  )  ' || v_JOIN_CONDITION;
    ELSIF (PI_is_Period = 1) THEN
      v_OVERLAP_STR := 'select a.* from ' || v_table || ' a,' || v_table ||
                       ' b, tu_periods_range a_tupr_start,
               tu_periods_range a_tupr_end,
                tu_periods_range b_tupr_start,
               tu_periods_range b_tupr_end
         where (
                  ((nvl(a_tupr_start.tupr_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                  nvl(b_tupr_end.tupr_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                  nvl(a_tupr_end.tupr_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) >=
                  nvl(b_tupr_start.tupr_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))
                  )
               and '
                      --changes for OF-14724 start (as per FD requirements for crediting records which have same start date and end date both will not be considered
                      --as overlapping. Such records will be candidates for aggregation.
                       ||
                       '((nvl(a_tupr_start.tupr_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <>
             nvl(b_tupr_start.tupr_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))) OR
             (nvl(a_tupr_end.tupr_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) <>
             nvl(b_tupr_end.tupr_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')))) and '
                      --changes for OF-14724 end
                       || 'a.' || PI_ID_COLUMN || ' <> b.' || PI_ID_COLUMN || ')
               and
               a.' || PI_effective_start ||
                       ' = a_tupr_start.tupr_id(+) and
               a.' || PI_effective_end ||
                       ' = a_tupr_end.tupr_id(+) and
               b.' || PI_effective_start ||
                       ' = b_tupr_start.tupr_id(+) and
               b.' || PI_effective_end ||
                       '= b_tupr_end.tupr_id(+)
               )
                 ' || v_JOIN_CONDITION;
    END IF;

    -- INSERT_LOGS( ' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - v_OVERLAP_STR = ' || v_OVERLAP_STR);

    IF PI_OVERLAP_SET_TABLE_NAME IS NOT NULL THEN
      v_INSERT_STR := 'insert into ' || PI_OVERLAP_SET_TABLE_NAME || ' ' ||
                      v_OVERLAP_STR;

      --OF-9688 start
      v_stamp := 'CREDITING.ISOLATE_OVERLAPPING_RECORDS: v_INSERT_STR';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_INSERT_STR),
                        'v_INSERT_STR := <value>;',
                        v_stamp);
      --OF-9688 end

   /*   commons_utils.INSERT_LOGS(' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - v_INSERT_STR = ' ||
                                v_INSERT_STR);*/
      EXECUTE IMMEDIATE v_INSERT_STR;

      --EXECUTE IMMEDIATE 'update '||PI_OVERLAP_SET_TABLE_NAME||' set IS_OVERLAPPING =1';

      v_DELETE_STR := 'delete from ' || PI_SOURCE_TABLE_NAME ||
                      ' s where exists (select 1 from ' ||
                      PI_OVERLAP_SET_TABLE_NAME || ' o where o.' ||
                      PI_ID_COLUMN || ' = s.' || PI_ID_COLUMN || ')';

      --OF-9688 start
      v_stamp := 'CREDITING.ISOLATE_OVERLAPPING_RECORDS: v_DELETE_STR1';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_DELETE_STR),
                        'v_DELETE_STR1 := <value>;',
                        v_stamp);
      --OF-9688 end
/*      commons_utils.INSERT_LOGS(' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - v_DELETE_STR = ' ||
                                v_DELETE_STR);*/
      EXECUTE IMMEDIATE v_DELETE_STR;

      EXECUTE IMMEDIATE 'select decode(' || SQL%ROWCOUNT ||
                        ',0,1,0) from dual'
        INTO po_OVERLAP_CHK_RES;
      --OF-9688 start
    /*  commons_utils.INSERT_LOGS(' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - po_OVERLAP_CHK_RES = ' ||
                                po_OVERLAP_CHK_RES);*/
      v_stamp := 'CREDITING.ISOLATE_OVERLAPPING_RECORDS: po_OVERLAP_CHK_RES1';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(to_clob(po_OVERLAP_CHK_RES)),
                        'po_OVERLAP_CHK_RES1 := <value>;',
                        v_stamp);
      --OF-9688 end

    ELSE
      v_DELETE_STR := 'delete from ' || PI_SOURCE_TABLE_NAME ||
                      ' s where exists ( select t.' || PI_ID_COLUMN ||
                      ' from (' || v_OVERLAP_STR || ') t where t.' ||
                      PI_ID_COLUMN || ' = s.' || PI_ID_COLUMN || ')';
      --OF-9688 start
      v_stamp := 'CREDITING.ISOLATE_OVERLAPPING_RECORDS: v_DELETE_STR2';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_DELETE_STR),
                        'v_DELETE_STR2 := <value>;',
                        v_stamp);
   /*   commons_utils.INSERT_LOGS(' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - v_DELETE_STR = ' ||
                                v_DELETE_STR);*/
      --OF-9688 end
      EXECUTE IMMEDIATE v_DELETE_STR;

      EXECUTE IMMEDIATE 'select decode(' || SQL%ROWCOUNT ||
                        ',0,1,0) from dual'
        INTO po_OVERLAP_CHK_RES;
   /*   commons_utils.INSERT_LOGS(' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - po_OVERLAP_CHK_RES = ' ||
                                po_OVERLAP_CHK_RES);*/
      --OF-9688 start
      v_stamp := 'CREDITING.ISOLATE_OVERLAPPING_RECORDS: po_OVERLAP_CHK_RES2';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(to_clob(po_OVERLAP_CHK_RES)),
                        'po_OVERLAP_CHK_RES2 := <value>;',
                        v_stamp);
      --OF-9688 end
    END IF;

    -- Close the open cursor
    IF cv_sql%ISOPEN THEN
      CLOSE cv_sql;
    END IF;
    -- Done closing the cursor

    -- INSERT_LOGS( ' In PROCEDURE ISOLATE_OVERLAPPING_RECORDS - END');
    -- OF-10375 PRAGMA AUTONOMOUS_TRANSACTION
    commit;

  EXCEPTION
    WHEN OTHERS THEN
      -- Close the open cursor
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      -- Done closing the cursor
      RAISE;
  END ISOLATE_OVERLAPPING_RECORDS;

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************
  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

  PROCEDURE EVALUATE_CREDITING(PI_CDT_INFO               IN COLTYPE_CDT_INFO,
                               PI_CAT_INFO               IN COLTYPE_CAT_INFO,
                               PI_CRT_INFO               IN COLTYPE_CRT_INFO,
                               PI_DATA_ENTITY_INFO       IN COLTYPE_DATA_ENTITY_INFO,
                               PI_FIELDS_TO_CREDIT       IN COLTYPE_FIELDS_TO_CREDIT,
                               PI_ADD_FIELDS_TO_CREDIT   IN COLTYPE_ADD_FIELDS_TO_CREDIT,
                               PI_CRED_CONDITIONS_INFO   IN COLTYPE_CRED_CONDITIONS_INFO,
                               PI_CRED_CONDITIONS_DETAIL IN COLTYPE_CRED_CONDITIONS_DETAIL,
                               -- PI_UNCREDITED_DATA_TABLE_NAME  IN     VARCHAR2,     /* OF-14723 */
                               PI_UDT_INFO IN COLTYPE_UDT_INFO, /* OF-14723  */
                               -- PI_UDT_NAME  IN     VARCHAR2,     /* OF-14723 */
                               -- PI_UDT_NON_TECH_COL_LIST          IN CLOB,                /* OF-14723 */
                               PI_RUN_ID       IN NUMBER,
                               PO_STATUS       OUT NUMBER,
                               PO_IS_CRT_EMPTY OUT NUMBER, /* OF-16309 */
                               PO_IS_UDT_EMPTY OUT NUMBER /* OF-16309 */) IS
    V_SQL                        VARCHAR2(32767 CHAR);
    V_SQL_VALIDATION             VARCHAR2(32767 CHAR);
    V_SELECT_CLAUSE              VARCHAR2(32767 CHAR);
    V_SELECT_TEMP                VARCHAR2(32767 CHAR);
    V_INS_COL_CLAUSE             VARCHAR2(32767 CHAR);
    V_INS_TEMP                   VARCHAR2(32767 CHAR);
    V_GROUP_CLAUSE               VARCHAR2(32767 CHAR);
    V_FROM_CLAUSE                VARCHAR2(32767 CHAR);
    V_JOIN_CLAUSE                VARCHAR2(32767 CHAR);
    V_WHERE_CLAUSE               VARCHAR2(32767 CHAR);
    V_AGGREGATE_TEMP             VARCHAR2(32767 CHAR);
    V_ENTITY_JOIN_CLAUSE         VARCHAR2(32767 CHAR);
    V_DATA_ENTITY_JOIN_CLAUSE    VARCHAR2(32767 CHAR);
    V_ADD_FLT_ENTITY_JOIN_CLAUSE VARCHAR2(32767 CHAR);
    V_ENTITY_JOIN_COLUMN         VARCHAR2(32767 CHAR);
    v_ENTITY_COL                 VARCHAR2(32767 CHAR);
    V_ENTITY_VAL_WHERE           VARCHAR2(32767 CHAR);
    V_ENT_BUSINESS_COL           VARCHAR2(32767 CHAR);
    V_ENTITY_NAME_COL            VARCHAR2(32767 CHAR);
    V_LISTAGG_ENT_FAIL           VARCHAR2(32767 CHAR);
    V_ENTITY_BUSINESS_FLD        VARCHAR2(32767 CHAR);
    V_GROUP_TEMP                 VARCHAR2(32767 CHAR);
    V_LOG_DETAILS                COLTYPE_LOG_DETAILS;
    V_ENT_BUSINESS_GRP           VARCHAR2(32767 CHAR);
    LOG_CNT                      NUMBER;
    CNT                          NUMBER;
    V_ENTITY_COL_WHERE           VARCHAR2(32767 CHAR);
    -- OF-17073 - START
    -- V_VALIDATION_TABLE               VARCHAR2(30 CHAR) := 'BKP_' || SUBSTR(PI_CRT_INFO(1).CRT_NAME, 1, 26);
    V_VALIDATION_TABLE VARCHAR2(30 CHAR) := 'T_VALIDATION_' || PI_RUN_ID;
    -- OF-17073 - END
    CUR_ENTITY_VALIDATION SYS_REFCURSOR;
    V_ENTITY_VALIDATION   VARCHAR2(32767 CHAR);

    entity_validation EXCEPTION;

    V_ENT_BUSINESS_ARRAY         DBMS_UTILITY.uncl_array;
    V_ENT_BUSINESS_LENGTH        BINARY_INTEGER;
    V_ENTITY_VAL_WHERE_LENGTH    BINARY_INTEGER;
    V_ENTITY_VAL_WHERE_ARRAY     DBMS_UTILITY.uncl_array;
    V_ENTITY_BUSINESS_FLD_LENGTH BINARY_INTEGER;
    V_ENTITY_BUSINESS_FLD_ARRAY  DBMS_UTILITY.uncl_array;

    -- OF-4574 START
    V_DATE_OR_PERIOD_COL         VARCHAR2(32767 CHAR);
    V_DATE_OR_PERIOD_COL_ALIASED VARCHAR2(32767 CHAR);
    v_CRT_KEY_FIELDS             CLOB;
    v_OUT_OVERLAP_CHK_RESULT     NUMBER;

    v_FLD_BUSINESS_NAME    VARCHAR2(100 CHAR);
    V_ENTITY_BUSINESS_NAME VARCHAR2(100 CHAR);
    -- OF-4574 END

    -- OF-5093 START
    V_LOG_START_TIME TIMESTAMP;
    -- OF-5093 END

    E_NUMERIC_OVERFLOW_13 EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_NUMERIC_OVERFLOW_13, -1438); --  OF-3180 -- "ORA-01438: value larger than specified precision allowed for this column"

    TYPE ENT_LOG_DETAIL_MAPPING IS RECORD(
      ENTITY_NAME VARCHAR2(100 CHAR),
      LOG_DETAILS COLTYPE_LOG_DETAILS);

    TYPE ENTITY_VALIDATION_TYPE IS TABLE OF VARCHAR2(250 CHAR);

    COL_ENTITY_VALIDATION ENTITY_VALIDATION_TYPE;

    -- OF-5674 -- CREDITING_CONDITION - START
    V_CRED_CONDITION_APPLICABLE NUMBER(1);
    V_COUNT_COND_CONFLICT       NUMBER;
    V_SQL_CAT_FINAL             CLOB := '';
    V_FILTER_AT_PER_COND        CLOB := '';
    V_FILTER_AT_ALL_COND        CLOB := '';
    V_FILTER_DT_ALL_COND        CLOB := '';
    V_CONDITION_SUM_CLAUSE      CLOB := '';
    V_CRED_COND_WHERE_CLAUSE    CLOB := '';
    V_DATE_RANGE_CLAUSE         CLOB := '';
    v_CAT_DATE_RANGE_PART_1     CLOB := '';
    v_CAT_DATE_RANGE_PART_2     CLOB := '';
    -- OF-17073 - START
    -- V_CAT_CRED_COND_TABLE            VARCHAR2(30 CHAR) := 'CAT_FINAL_TABLE';
    V_CAT_CRED_COND_TABLE VARCHAR2(30 CHAR) := 'T_CAT_FINAL_' || PI_RUN_ID;
    -- OF-17073 - END
    V_CAT_FINAL_TABLE       VARCHAR2(30 CHAR) := '';
    V_CAT_FINAL_TABLE_ALIAS VARCHAR2(30 CHAR) := '';
    CREDITING_CONDITIONS_CONFLICT EXCEPTION; -- This occurs when more than 1 Crediting Conditions apply to an CAT row
    -- OF-5674 -- CREDITING_CONDITION - END

    -- OF-7038 START
    V_FILTER_EVAL_AT_COMBINED CLOB := '';
    V_FILTER_EVAL_DT_COMBINED CLOB := '';
    -- OF-7038 END

    -- 1.30 - OF-6852 - START - Processing as much as you can
    V_SQL_LOAD_UNCREDITED_DATA CLOB;
    V_DT_KEY_FIELDS            VARCHAR2(32767 CHAR);

    -- 1.30 - OF-6852 - END - Processing as much as you can

    -- OF-14723 -- START -- Adding these variables for retrieving Valid Records for Crediting
    -- OF-17073 - START
    -- V_VALID_RECORDS_TABLE            VARCHAR2(30 CHAR) := 'T_VALID_RECORDS_TABLE';
    V_VALID_RECORDS_TABLE VARCHAR2(30 CHAR) := 'T_VALID_RECORDS_' ||
                                               PI_RUN_ID;
    -- OF-17073 - END
    V_SQL_VALID             CLOB;
    V_WHERE_CLAUSE_INVALID  CLOB;
    V_SELECT_CLAUSE_VALID   CLOB;
    V_FROM_CLAUSE_VALID     CLOB;
    V_WHERE_CLAUSE_VALID    CLOB;
    V_FROM_CLAUSE_INVALID   CLOB;
    V_UDT_NON_TECH_COL_LIST CLOB; --  := PI_UDT_NON_TECH_COL_LIST;  -- OF-14407, OF-14723
    V_UDT_NAME              VARCHAR2(30 CHAR); --  := PI_UDT_NAME; -- OF-14407, OF-14723
    -- OF-17073 - START
    -- V_NON_OVERLAP_DT                 VARCHAR2(30 CHAR) := 'T_OVERLAP_SET_TABLE';
    V_NON_OVERLAP_DT VARCHAR2(30 CHAR) := 'T_OVERLAP_SET_' || PI_RUN_ID;
    -- OF-17073 - END
    V_SQL_NON_OVERLAP_DT          CLOB;
    V_SQL_NON_OVERLAP_VALID_TABLE CLOB;
    V_SELECT_CLAUSE_VALIDATION    VARCHAR2(32767 CHAR);
    V_FROM_CLAUSE_VALIDATION      CLOB;
    V_GROUP_CLAUSE_VALIDATION     VARCHAR2(32767 CHAR);
    -- OF-14723 -- END

    -- OF-14966 - START
    V_FROM_CLAUSE_DT_PERIOD_FLT CLOB;
    V_SQL_FILTERED_DT           CLOB;
    V_FROM_CLAUSE_FILTERED_DT   CLOB;
    V_WHERE_CLAUSE_FILTERED_DT  CLOB;
    -- OF-14966 - END

    -- OF-14977 - START
    V_SQL_CONFLICTING_RECORDS CLOB;
    -- OF-14977 - END

    -- OF-? - START
    V_SQL_GT_13                CLOB;
    V_HAVING_CLAUSE_GT_13      CLOB;
    V_HAVING_CLAUSE_LTE_13     CLOB;
    V_HAVING_CLAUSE_VALIDATION CLOB;
    V_OPTYMYZE_NUMERIC_LIMIT   VARCHAR2(20 CHAR) := 'POWER(10, 13)';
    V_WHERE_CLAUSE_GT_13_OUTER CLOB;
    V_FROM_CLAUSE_GT_13_OUTER  CLOB;
    V_SQL_GT_13_OUTER          CLOB;
    V_SELECT_CLAUSE_GT_13      CLOB;
    --OF-? - END

    -- OF-15568 - START
    V_CREDITING_ENTITY_ALIASED    VARCHAR2(100 CHAR);
    V_DT_ALIAS_WITH_COMMA_INVALID VARCHAR2(100 CHAR);
    V_INSERT_CLAUSE_INVALID       VARCHAR2(32767 CHAR);
    V_SQL_UDT_NONTECH_COLS_ALIAS  VARCHAR2(32767 CHAR);
    V_SELECT_CLAUSE_INVALID       VARCHAR2(32767 CHAR);
    V_UDT_NON_TECH_COL_LIST_ALIAS VARCHAR2(32767 CHAR);
    V_SELECT_CLAUSE_GT_13_OUTER   VARCHAR2(32767 CHAR);
    -- OF-15568 - END

    -- OF-14407 - START
    -- OF-14407 - END

    -- OF-?? - START
    V_SQL_VALIDATE_CC_AT_FLT       CLOB;
    V_AT_FLT_INVALID_ENT           VARCHAR2(100 CHAR);
    V_LOG_MSG                      CLOB;
    V_LOG_DETAIL_MSG               CLOB;
    V_AT_FLT_INVALID_ENT_LIST_DTL  CLOB;
    V_COL_CAT_FLT_INVALID_ENT_LIST COLTYPE_NAME_LIST_INTERNAL;
    V_AT_FLT_INVALID_ENT_LIST      CLOB;
    V_LIST_CNT                     NUMBER := 0;
    V_CAT_TYPE                     VARCHAR2(20 CHAR);
    V_COUNT_UNMATCHING_CDT_RECORDS NUMBER;
    v_stamp                        VARCHAR2(250); --OF-9688
    -- OF-?? - END

  BEGIN
    -- INSERT_LOGS ('-- In CREDITING PROCEDURE');
    -- OF-5674 - Drop internal tables used in procedure, if they exist.
    FOR C IN (SELECT TABLE_NAME
                FROM USER_TABLES
               WHERE TABLE_NAME IN (V_VALIDATION_TABLE,
                                    V_CAT_CRED_COND_TABLE,
                                    V_VALID_RECORDS_TABLE,
                                    V_NON_OVERLAP_DT)) LOOP
      -- INSERT_LOGS ('-- Drop Table: ' || C.TABLE_NAME || ' -- start' );
      -- Start OF-10375 to execute DDL in autonomous transaction
      -- EXECUTE IMMEDIATE 'DROP TABLE ' || C.TABLE_NAME;
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' ||
                                                       C.TABLE_NAME);
      -- End OF-10375 to execute DDL in autonomous transaction
    -- INSERT_LOGS ('-- Drop Table: ' || C.TABLE_NAME || ' -- end');
    END LOOP;

    -- Abhi - 1.29 - start
    -- OF-4574
    PO_STATUS := 1; -- set successful by default and change it when error
    -- Abhi - 1.29 - end

    -- OF-16309 - START - Initializing PO_IS_CRT_EMPTY and PO_IS_UDT_EMPTY OUT parameters
    PO_IS_CRT_EMPTY := 0; -- Ideally CRT is expected to be Non-Empty, hence value set to 0
    PO_IS_UDT_EMPTY := 1; -- Ideally UDT is expected to be Empty, hence value set to 1
    -- OF-16309 - END

    V_CRED_CONDITION_APPLICABLE := PI_CRED_CONDITIONS_INFO(1)
                                   .CC_IS_APPLICABLE; -- OF-14407
    V_CAT_TYPE                  := CASE PI_CAT_INFO(1).CAT_TYPE
                                     WHEN 1 THEN
                                      'alignments'
                                     WHEN 2 THEN
                                      'assignments'
                                   END; -- OF-??

    -- OF-14407, OF-14723 - START
    -- Fetching the UDT Name
    V_UDT_NAME := PI_UDT_INFO(1).UDT_NAME;
    -- For UDT - Non Technical Columns -- In stead of Object, now we receive directly comma separated list -- since java side had an issue while passing it; so no need to create the list below
    /*
    -- Creating the "," separated list of UDT - Non Technical Columns
    SELECT  LISTAGG(COLUMN_VALUE, ' , ') WITHIN GROUP (ORDER BY NULL)
    INTO V_UDT_NON_TECH_COL_LIST
    FROM TABLE(PI_UDT_INFO(1).UDT_NON_TECH_COL_LIST);
    */
    V_UDT_NON_TECH_COL_LIST := PI_UDT_INFO(1).UDT_NON_TECH_COL_LIST;

    -- OF-14407, OF-14723 - END

    -- OF-?? - START - Crediting Logs related change
    IF V_CRED_CONDITION_APPLICABLE = 1 THEN
      -- Initialize Log Message Details Collections: V_LOG_DETAILS, and V_COL_CAT_FLT_INVALID_ENT_LIST
      V_COL_CAT_FLT_INVALID_ENT_LIST := COLTYPE_NAME_LIST_INTERNAL();
      V_LOG_DETAILS                  := COLTYPE_LOG_DETAILS();
      LOG_CNT                        := 0;

      FOR I IN PI_CRED_CONDITIONS_DETAIL.FIRST .. PI_CRED_CONDITIONS_DETAIL.LAST -- L1
       LOOP
        -- V_AT_FLT_INVALID_ENT_LIST_DTL              := NULL;
        IF PI_CRED_CONDITIONS_DETAIL(I)
         .CCD_FILTER_EVAL_AT_PER_ENTITY IS NOT NULL THEN
          FOR J IN PI_CRED_CONDITIONS_DETAIL(I)
                   .CCD_FILTER_EVAL_AT_PER_ENTITY.FIRST .. PI_CRED_CONDITIONS_DETAIL(I)
                                                           .CCD_FILTER_EVAL_AT_PER_ENTITY.LAST -- L2
           LOOP
            -- L2
            V_SQL_VALIDATE_CC_AT_FLT := 'SELECT MIN(E.ENTITY_NAME) ENTITY_NAME FROM ENTITIES E WHERE ' ||
                                        '''T''' ||
                                        ' || E.ENTITY_TABLES_ID = ''' || PI_CRED_CONDITIONS_DETAIL(I).CCD_FILTER_EVAL_AT_PER_ENTITY(J)
                                       .CAF_ENTITY_TABLE_NAME ||
                                        ''' AND NOT EXISTS (SELECT 1 FROM ' || PI_CRED_CONDITIONS_DETAIL(I).CCD_FILTER_EVAL_AT_PER_ENTITY(J)
                                       .CAF_ENTITY_TABLE_NAME || '  ' || PI_CRED_CONDITIONS_DETAIL(I).CCD_FILTER_EVAL_AT_PER_ENTITY(J)
                                       .CAF_ENTITY_TABLE_ALIAS ||
                                        '  WHERE ' || PI_CRED_CONDITIONS_DETAIL(I).CCD_FILTER_EVAL_AT_PER_ENTITY(J)
                                       .CAF_FILTER_EVALUATION || ')';

            -- INSERT_LOGS(' -- V_SQL_VALIDATE_CC_AT_FLT = ' || V_SQL_VALIDATE_CC_AT_FLT);

            BEGIN
              --OF-9688 start
              v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_VALIDATE_CC_AT_FLT';
              L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                                ANYDATA.CONVERTCLOB(V_SQL_VALIDATE_CC_AT_FLT),
                                'V_SQL_VALIDATE_CC_AT_FLT := <value>;',
                                v_stamp);
              --OF-9688 end
            /*  commons_utils.INSERT_LOGS(V_SQL_VALIDATE_CC_AT_FLT);*/

              EXECUTE IMMEDIATE V_SQL_VALIDATE_CC_AT_FLT
                INTO V_AT_FLT_INVALID_ENT;
            EXCEPTION
              WHEN OTHERS THEN
                V_AT_FLT_INVALID_ENT := NULL;
            END;

            -- INSERT_LOGS(' -- V_AT_FLT_INVALID_ENT = ' || V_AT_FLT_INVALID_ENT);

            IF V_AT_FLT_INVALID_ENT IS NOT NULL THEN
              V_AT_FLT_INVALID_ENT_LIST_DTL := V_AT_FLT_INVALID_ENT_LIST_DTL || CASE
                                                 WHEN V_AT_FLT_INVALID_ENT_LIST_DTL IS NOT NULL THEN
                                                  ', '
                                               END || V_AT_FLT_INVALID_ENT;
              V_COL_CAT_FLT_INVALID_ENT_LIST.EXTEND;
              V_LIST_CNT := V_LIST_CNT + 1;
              V_COL_CAT_FLT_INVALID_ENT_LIST(V_LIST_CNT) := V_AT_FLT_INVALID_ENT;
            END IF;
            -- INSERT_LOGS (' -- V_AT_FLT_INVALID_ENT_LIST_DTL = ' || V_AT_FLT_INVALID_ENT_LIST_DTL);
          END LOOP; -- L2
        END IF;

        IF V_AT_FLT_INVALID_ENT_LIST_DTL IS NOT NULL THEN
          IF INSTR(V_AT_FLT_INVALID_ENT_LIST_DTL, ',', -1) > 0 THEN
            V_AT_FLT_INVALID_ENT_LIST_DTL := REGEXP_REPLACE(V_AT_FLT_INVALID_ENT_LIST_DTL,
                                                            ',',
                                                            ' and',
                                                            INSTR(V_AT_FLT_INVALID_ENT_LIST_DTL,
                                                                  ',',
                                                                  -1),
                                                            1); -- OF-16472 - Replacing 'or' with 'and'
          END IF;

          -- Log message for Validation 1: "A crediting condition does not result in any valid values for the crediting or data entities specified" -- REFER LINE: 1187 to 1275

          V_LOG_DETAILS.EXTEND;
          LOG_CNT := LOG_CNT + 1;
          V_LOG_DETAIL_MSG := 'The following crediting condition did not result in any valid values for ' ||
                              V_AT_FLT_INVALID_ENT_LIST_DTL || ':' ||
                              CHR(13) || PI_CRED_CONDITIONS_DETAIL(I)
                             .CCD_TEXT;
          V_LOG_DETAILS(LOG_CNT) := RTYPE_LOG_DETAILS(V_LOG_DETAIL_MSG,
                                                      LOG_CNT);
        END IF;

        V_AT_FLT_INVALID_ENT_LIST_DTL := NULL;
      END LOOP; -- L1

      IF (V_LOG_DETAILS.COUNT <> 0) THEN
        BEGIN
          PO_STATUS := 3;
          CNT       := NULL;

          SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                   'rrrr-mm-dd hh24:mi:ss.ff'),
                                           'YYYY-MM-DD HH24:MI:SS.ff') AS
                              TIMESTAMP),
                         TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
            INTO V_LOG_START_TIME
            FROM DUAL;

          SELECT LISTAGG(INVALID_ENTITY, ', ') WITHIN GROUP(ORDER BY NULL)
            INTO V_AT_FLT_INVALID_ENT_LIST
            FROM (SELECT DISTINCT COLUMN_VALUE INVALID_ENTITY
                    FROM TABLE(V_COL_CAT_FLT_INVALID_ENT_LIST));

          IF INSTR(V_AT_FLT_INVALID_ENT_LIST, ',', -1) > 0 THEN
            V_AT_FLT_INVALID_ENT_LIST := REGEXP_REPLACE(V_AT_FLT_INVALID_ENT_LIST,
                                                        ',',
                                                        ' or',
                                                        INSTR(V_AT_FLT_INVALID_ENT_LIST,
                                                              ',',
                                                              -1),
                                                        1);
          END IF;

          V_LOG_MSG := 'One or more crediting conditions do not result in any valid values for ' ||
                       V_AT_FLT_INVALID_ENT_LIST || '.';

          LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                                pin_LM_LEVEL           => 0,
                                pin_LM_MESSAGE         => V_LOG_MSG,
                                pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                                pin_LM_START_DATE      => V_LOG_START_TIME,
                                pin_LM_UPDATE_DATE     => NULL,
                                pinout_LM_ID           => CNT);
          CNT := NULL;
        END;
      END IF;
    END IF;

    -- INSERT_LOGS ('CC - ENTITY EXISTENCE CHECK DONE');
    -- OF-?? - END

    -- OF-5674
    -- OF-5674 -- CREDITING_CONDITION - START
    -- V_CRED_CONDITION_APPLICABLE   := PI_CRED_CONDITIONS_INFO(1).CC_IS_APPLICABLE; -- OF-14407

    IF V_CRED_CONDITION_APPLICABLE = 0 THEN
      V_CAT_FINAL_TABLE        := PI_CAT_INFO(1).CAT_NAME;
      V_CAT_FINAL_TABLE_ALIAS  := PI_CAT_INFO(1).CAT_ALIAS;
      V_CRED_COND_WHERE_CLAUSE := '';
      V_DATE_RANGE_CLAUSE      := '';
    ELSIF V_CRED_CONDITION_APPLICABLE = 1 THEN
      V_CAT_FINAL_TABLE        := V_CAT_CRED_COND_TABLE;
      V_CAT_FINAL_TABLE_ALIAS  := 'CAT_FINAL';
      V_CRED_COND_WHERE_CLAUSE := '';

      -- Form the Assignment Table Date Range clause part
      CASE PI_CRED_CONDITIONS_INFO(1).CC_DATE_RANGE_OPTION
        WHEN 1 --1 = FIRST DAY
         THEN
          v_CAT_DATE_RANGE_PART_1 := '((NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
          v_CAT_DATE_RANGE_PART_2 := '(NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
        WHEN 2 --2 = LAST DAY
         THEN
          v_CAT_DATE_RANGE_PART_1 := '((NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
          v_CAT_DATE_RANGE_PART_2 := '(NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
        WHEN 3 --3 = ANY DAY
         THEN
          v_CAT_DATE_RANGE_PART_1 := '((NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
          v_CAT_DATE_RANGE_PART_2 := '(NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
        WHEN 4 --4 = EVERY DAY
         THEN
          v_CAT_DATE_RANGE_PART_1 := '((NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
          v_CAT_DATE_RANGE_PART_2 := '(NVL(TO_DATE (' || PI_CAT_INFO(1)
                                    .CAT_ALIAS ||
                                     '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
        ELSE
          v_CAT_DATE_RANGE_PART_1 := NULL;
          v_CAT_DATE_RANGE_PART_2 := NULL;
      END CASE;

      -- OF-7038 START

      WITH T_CRED_CONDITIONS_DETAIL AS
       (SELECT CCD_EFFECTIVE_START_DATE,
               CCD_EFFECTIVE_END_DATE,
               CCD_ID,
               CASE
                 WHEN CCD_FILTER_EVAL_DT_COMBINED IS NOT NULL THEN
                  ' AND ' || CCD_FILTER_EVAL_DT_COMBINED
                 ELSE
                  NULL
               END V_FILTER_EVAL_DT_COMBINED,
               CASE
                 WHEN PI_CRED_CONDITIONS_INFO(1)
                  .CC_DATE_RANGE_OPTION IS NOT NULL THEN
                  v_CAT_DATE_RANGE_PART_1 || CCD_EFFECTIVE_START_DATE ||
                  ''', ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR''))) AND ' ||
                  v_CAT_DATE_RANGE_PART_2 || CCD_EFFECTIVE_END_DATE ||
                  ''', ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR''))))'
                 ELSE
                  NULL
               END || CASE
                 WHEN CCD_FILTER_EVAL_AT_COMBINED IS NOT NULL THEN
                  ' AND ' || CCD_FILTER_EVAL_AT_COMBINED
                 ELSE
                  NULL
               END V_FILTER_EVAL_AT_COMBINED
          FROM TABLE(PI_CRED_CONDITIONS_DETAIL))
      SELECT LISTAGG(CASE
                       WHEN V_FILTER_EVAL_AT_COMBINED IS NOT NULL THEN
                        ('CASE WHEN (' || V_FILTER_EVAL_AT_COMBINED ||
                        ') THEN 1 ELSE 0 END CA' || CCD_ID)
                       ELSE
                        NULL
                     END,
                     ', ') WITHIN GROUP(ORDER BY CCD_ID),
             /* -- OF-## - START
             LISTAGG(CASE WHEN V_FILTER_EVAL_AT_COMBINED IS NOT NULL THEN (' WHEN (' || V_FILTER_EVAL_AT_COMBINED || ') THEN ' || CCD_ID) ELSE NULL END,' ') WITHIN GROUP (ORDER BY CCD_ID),
             */
             LISTAGG(CASE
                       WHEN V_FILTER_EVAL_AT_COMBINED IS NOT NULL THEN
                        (' CASE WHEN (' || V_FILTER_EVAL_AT_COMBINED || ') THEN ' ||
                        CCD_ID || ' || '','' END ')
                       ELSE
                        NULL
                     END,
                     ' || ') WITHIN GROUP(ORDER BY CCD_ID),
             /* */
             LISTAGG(' (' || V_CAT_FINAL_TABLE_ALIAS ||
                     '.CONDITION_APPLIED = ' || CCD_ID ||
                     V_FILTER_EVAL_DT_COMBINED || ') ',
                     ' OR ') WITHIN GROUP(ORDER BY CCD_ID),
             LISTAGG('A1.CA' || CCD_ID, ' + ') WITHIN GROUP(ORDER BY CCD_ID)
        INTO V_FILTER_AT_PER_COND,
             V_FILTER_AT_ALL_COND,
             V_FILTER_DT_ALL_COND,
             V_CONDITION_SUM_CLAUSE
        FROM T_CRED_CONDITIONS_DETAIL;

      -- Removing the Extra ',' from V_FILTER_AT_ALL_COND
      V_FILTER_AT_ALL_COND := RTRIM(V_FILTER_AT_ALL_COND, ',');
      /*OF-## - END */

      -- INSERT_LOGS ( ' -- V_FILTER_EVAL_AT_COMBINED -- ' || V_FILTER_EVAL_AT_COMBINED);
      -- INSERT_LOGS ( ' -- V_FILTER_AT_PER_COND -- ' || V_FILTER_AT_PER_COND);
      -- INSERT_LOGS(' -- V_FILTER_AT_ALL_COND -- ' || V_FILTER_AT_ALL_COND);
      -- OF-7038 END

      V_SQL_CAT_FINAL := '
      CREATE TABLE ' || V_CAT_FINAL_TABLE || ' AS
      SELECT A1.*, (' || V_CONDITION_SUM_CLAUSE ||
                         ') CA_SUM
      FROM(
         SELECT ' || PI_CAT_INFO(1).CAT_ALIAS ||
                         '.*,' || V_FILTER_AT_PER_COND
                        /* OF-## -- || ', CASE ' */
                         || ', ' || 'RTRIM(' || V_FILTER_AT_ALL_COND
                        /* OF-## -- || ' ELSE 0 END CONDITION_APPLIED */
                         || ', '','')' || ' CONDITION_APPLIED
         FROM ' || PI_CAT_INFO(1).CAT_NAME || ' ' || PI_CAT_INFO(1)
                        .CAT_ALIAS || ' ' || PI_CRED_CONDITIONS_INFO(1)
                        .CC_JOIN_CLAUSE_AT || ' ORDER BY 5, 6, 7) A1';

      -- INSERT_LOGS('-- V_SQL_CAT_FINAL => ' || V_SQL_CAT_FINAL);
      --OF-9688 start
      v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_CAT_FINAL';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(V_SQL_CAT_FINAL),
                        'V_SQL_CAT_FINAL := <value>;',
                        v_stamp);
      --OF-9688 end
      -- Start OF-10375 to execute DDL in autonomous transaction
      -- EXECUTE IMMEDIATE V_SQL_CAT_FINAL;
   /*   commons_utils.INSERT_LOGS('V_SQL_CAT_FINAL in EC_MAIN ' ||
                                V_SQL_CAT_FINAL);*/
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => V_SQL_CAT_FINAL);
      -- End OF-10375 to execute DDL in autonomous transaction

      -- OF-14977 -- START
      -- OF-15610 - START -- Replacing V_CREDITING_ENTITY_ALIASED with : <V_CAT_FINAL_TABLE_ALIAS> || '.ROW_IDENTIFIER'
      -- V_SQL_CONFLICTING_RECORDS := 'SELECT ' || PI_CAT_INFO(1).CAT_ENTITY_COL_NAME || '  FROM ' || V_CAT_FINAL_TABLE || ' WHERE CA_SUM > 1';
      V_SQL_CONFLICTING_RECORDS := 'SELECT ROW_IDENTIFIER  FROM ' ||
                                   V_CAT_FINAL_TABLE || ' WHERE CA_SUM > 1';

      -- OF-15610 - END
      -- OF-14977 -- END
      /*commons_utils.INSERT_LOGS('count query of EC_MAIN ' ||
                                'SELECT COUNT(*) FROM ' ||
                                V_CAT_FINAL_TABLE || ' WHERE CA_SUM > 1');*/
      EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || V_CAT_FINAL_TABLE ||
                        ' WHERE CA_SUM > 1'
        INTO V_COUNT_COND_CONFLICT;

      --OF-9688 start
      v_stamp := 'CREDITING.EVALUATE_CREDITING: V_COUNT_COND_CONFLICT';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(to_clob(V_COUNT_COND_CONFLICT)),
                        'V_COUNT_COND_CONFLICT := <value>;',
                        v_stamp);
      --OF-9688 end

      -- INSERT_LOGS('-- V_COUNT_COND_CONFLICT => ' || V_COUNT_COND_CONFLICT);

      IF V_COUNT_COND_CONFLICT > 0 THEN
        ---------------------------------

        -- OF-?? - START
        -- Log Message: eXCEL 9
        V_LOG_DETAILS := COLTYPE_LOG_DETAILS();
        V_LOG_DETAILS.EXTEND;
        LOG_CNT := LOG_CNT + 1;
        V_LOG_DETAIL_MSG := 'The records that did not get credited because there were conflicting conditions are included in the Uncredited Data validation result. See the Uncredited Data validation result for details.';
        V_LOG_DETAILS(LOG_CNT) := RTYPE_LOG_DETAILS(V_LOG_DETAIL_MSG,
                                                    LOG_CNT);

        PO_STATUS := 3;
        CNT       := NULL;

        SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                 'rrrr-mm-dd hh24:mi:ss.ff'),
                                         'YYYY-MM-DD HH24:MI:SS.ff') AS
                            TIMESTAMP),
                       TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
          INTO V_LOG_START_TIME
          FROM DUAL;

        LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                              pin_LM_LEVEL           => 0,
                              pin_LM_MESSAGE         => 'One or more records to credit from the performance data table ' || PI_CDT_INFO(1)
                                                       .CDT_BUSINESS_NAME ||
                                                        ' did not get credited because there were conflicting conditions.', /*OF-16332 - Replaced CDT_NAME with CDT_BUSINESS_NAME*/
                              pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                              pin_LM_START_DATE      => V_LOG_START_TIME,
                              pin_LM_UPDATE_DATE     => NULL,
                              pinout_LM_ID           => CNT);
        CNT := NULL;

        -- OF-?? - END

        --------------------------------
        -- Log Message: 'One or more crediting conditions conflict with each other.'
        V_LOG_DETAILS := COLTYPE_LOG_DETAILS();

        -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
        -- PO_STATUS     := 43; -- Temporarily set it to 43 (relative to "4"; non-used status)
        PO_STATUS := 3;
        -- 1.30 - OF-6852 - END - Processing as much as you can
        CNT := NULL;

        SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                 'rrrr-mm-dd hh24:mi:ss.ff'),
                                         'YYYY-MM-DD HH24:MI:SS.ff') AS
                            TIMESTAMP),
                       TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
          INTO V_LOG_START_TIME
          FROM DUAL;

        LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                              pin_LM_LEVEL           => 0,
                              pin_LM_MESSAGE         => 'One or more crediting conditions conflict with each other.',
                              pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                              pin_LM_START_DATE      => V_LOG_START_TIME,
                              pin_LM_UPDATE_DATE     => NULL,
                              pinout_LM_ID           => CNT);
        CNT := NULL;
        -- 1.30 - OF-6852 - START - Processing as much as you can -- Hence do not RAISE the error from here
        -- RAISE CREDITING_CONDITIONS_CONFLICT;
        -- 1.30 - OF-6852 - END - Processing as much as you can
      ELSE
        V_CRED_COND_WHERE_CLAUSE := ' AND ((' || V_CAT_FINAL_TABLE_ALIAS ||
                                    '.CA_SUM = 1 AND ' ||
                                    V_FILTER_DT_ALL_COND || ') OR ' ||
                                    V_CAT_FINAL_TABLE_ALIAS ||
                                    '.CA_SUM = 0)';
      END IF;
    END IF;

    -- OF-5674 -- CREDITING_CONDITION - END

    -- Abhi - 1.29 - start - comment the following code since it has been moved to start of procedure.
    -- OF-4574
    -- PO_STATUS                   := 1; -- set successful by default and change it when error
    -- Abhi - 1.29 - end

    V_SQL       := 'INSERT /* +APPEND */ INTO ' || PI_CRT_INFO(1).CRT_NAME;
    V_SQL_VALID := ''; -- OF-14723

    -- OF-14723 -- START
    -- V_SELECT_CLAUSE             := V_CAT_FINAL_TABLE_ALIAS /*PI_CAT_INFO ( 1).CAT_ALIAS*/ || '.' || PI_CAT_INFO(1).CAT_ENTITY_COL_NAME; -- OF-5674
    V_SELECT_CLAUSE_VALIDATION := V_CAT_FINAL_TABLE_ALIAS /*PI_CAT_INFO ( 1).CAT_ALIAS*/
                                  || '.' || PI_CAT_INFO(1)
                                 .CAT_ENTITY_COL_NAME; -- OF-5674
    V_SELECT_CLAUSE            := 'T_VALID.CAT_CREDITING_ENTITY_VALUE  ' || PI_CAT_INFO(1)
                                 .CAT_ENTITY_COL_NAME; -- OF-5674
    V_CREDITING_ENTITY_ALIASED := V_CAT_FINAL_TABLE_ALIAS || '.' || PI_CAT_INFO(1)
                                 .CAT_ENTITY_COL_NAME; -- OF-15568
    V_SELECT_CLAUSE_VALID      := PI_CDT_INFO(1)
                                  .CDT_ALIAS || '.' ||
                                   'ROW_IDENTIFIER  CDT_ROW_IDENTIFIER, ' ||
                                   V_CREDITING_ENTITY_ALIASED ||
                                   ' CAT_CREDITING_ENTITY_VALUE ';

    IF (PI_CAT_INFO(1).CAT_IS_ALLOCATION_APPLICABLE = 1) THEN
      V_SELECT_CLAUSE_VALID := V_SELECT_CLAUSE_VALID || ', ' ||
                               V_CAT_FINAL_TABLE_ALIAS || '.' || PI_CAT_INFO(1)
                              .CAT_ALLOCATION_COL_NAME;
    END IF;

    -- V_GROUP_CLAUSE              := V_SELECT_CLAUSE;
    V_GROUP_CLAUSE_VALIDATION := V_SELECT_CLAUSE_VALIDATION;
    V_GROUP_CLAUSE            := 'T_VALID.CAT_CREDITING_ENTITY_VALUE';
    -- OF-14723 -- END

    V_INS_COL_CLAUSE := PI_CAT_INFO(1).CAT_ENTITY_COL_NAME;

    SELECT LISTAGG(V_CAT_FINAL_TABLE_ALIAS /*PI_CAT_INFO ( 1).CAT_ALIAS*/
                   || '.' || DE_COLUMN_NAME || ' = ' || CASE
                     WHEN ENTITY_JOIN_COLUMN = 1 THEN
                      PI_CDT_INFO(1).CDT_ALIAS || '.' || DE_COLUMN_NAME || ' '
                     ELSE
                      'DT_ENT_' || DE_TABLE_NAME || '.E_INTERNAL_ID'
                   END,
                   ' AND ') WITHIN GROUP(ORDER BY NULL), -- OF-5674
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 1 THEN
                      PI_CDT_INFO(1).CDT_ALIAS || '.' || DE_COLUMN_NAME
                     ELSE
                      'DT_ENT_' || DE_TABLE_NAME || '.E_INTERNAL_ID ' ||
                      DE_COLUMN_NAME
                   END,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 1 THEN
                      PI_CDT_INFO(1).CDT_ALIAS || '.' || DE_COLUMN_NAME
                     ELSE
                      'DT_ENT_' || DE_TABLE_NAME || '.E_INTERNAL_ID '
                   END,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(DE_COLUMN_NAME, ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(' LEFT OUTER JOIN ' || DE_TABLE_NAME || ' ' || 'DT_ENT_' ||
                   DE_TABLE_NAME || ' ON '
                   /* -- OF-17153 - START - Fix to handle Case Sensitivity */
                   /*
                   || PI_CDT_INFO(1).CDT_ALIAS || '.'  || CASE WHEN ENTITY_JOIN_COLUMN = 1 THEN DE_COLUMN_NAME ELSE DE_BUSINESS_NAME END
                   || ' = '
                   || CASE WHEN ENTITY_JOIN_COLUMN = 1 THEN 'DT_ENT_' || DE_TABLE_NAME || '.E_INTERNAL_ID'  ELSE 'DT_ENT_' || DE_TABLE_NAME || '.' || DE_BUSINESS_NAME  END,
                   */
                   || CASE
                     WHEN ENTITY_JOIN_COLUMN = 1 THEN
                      PI_CDT_INFO(1).CDT_ALIAS || '.' || DE_COLUMN_NAME
                     ELSE
                      ' UPPER(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                      DE_BUSINESS_NAME || ')'
                   END || ' = ' || CASE
                     WHEN ENTITY_JOIN_COLUMN = 1 THEN
                      'DT_ENT_' || DE_TABLE_NAME || '.E_INTERNAL_ID'
                     ELSE
                      ' UPPER(' || 'DT_ENT_' || DE_TABLE_NAME || '.' ||
                      DE_BUSINESS_NAME || ')'
                   END,
                   /* -- OF-17153 - END - Fix to handle Case Sensitivity */
                   '  ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                      ENTITY_JOIN_COLUMN
                   END,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(DE_COLUMN_NAME, ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                      'DT_ENT_' || DE_TABLE_NAME || '.E_INTERNAL_ID IS NULL'
                   END,
                   ' OR ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                     /* -- OF-17153 - START - Fix to handle Case Sensitivity */
                     /* PI_CDT_INFO(1).CDT_ALIAS || '.' || DE_BUSINESS_NAME  */
                      ' UPPER(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                      DE_BUSINESS_NAME || ')'
                     /* -- OF-17153 - END - Fix to handle Case Sensitivity */
                      || ' "' || DE_NAME || '"'
                   END,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                     /* -- OF-17153 - START - Fix to handle Case Sensitivity */
                     /* PI_CDT_INFO(1).CDT_ALIAS || '.' || DE_BUSINESS_NAME  */
                      ' UPPER(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                      DE_BUSINESS_NAME || ')'
                   /* -- OF-17153 - END - Fix to handle Case Sensitivity */
                   END,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                      '"' || DE_NAME || '"'
                   END,
                   ',') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                      '"' || DE_PHYSICAL_COLUMN_NAME || '"'
                   END,
                   ',') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(CASE
                     WHEN ENTITY_JOIN_COLUMN = 0 THEN
                      ' LISTAGG( CASE WHEN ' || DE_COLUMN_NAME || ' IS NULL THEN' ||
                      DE_NAME || ' END ' || DE_NAME ||
                      ', '' , '') WITHIN GROUP(ORDER BY NULL)'
                   END,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(DE_COLUMN_NAME, ' , ') WITHIN GROUP(ORDER BY NULL)
      INTO V_JOIN_CLAUSE,
           V_SELECT_TEMP,
           V_GROUP_TEMP,
           V_INS_TEMP,
           V_ENTITY_JOIN_CLAUSE, /*OF-5370*/
           -- V_DATA_ENTITY_JOIN_CLAUSE, /*OF-5370*/
           V_ENTITY_JOIN_COLUMN,
           v_ENTITY_COL,
           V_ENTITY_VAL_WHERE,
           V_ENT_BUSINESS_COL,
           V_ENT_BUSINESS_GRP,
           V_ENTITY_NAME_COL,
           V_ENTITY_BUSINESS_FLD,
           V_LISTAGG_ENT_FAIL,
           V_ENTITY_COL_WHERE
      FROM (SELECT CASE
                     WHEN (SELECT MAX(UTC.COLUMN_NAME)
                             FROM USER_TAB_COLS UTC
                            WHERE UTC.COLUMN_NAME = ALIGN_OBJ.DE_COLUMN_NAME
                              AND UTC.TABLE_NAME = PI_CDT_INFO(1).CDT_NAME) IS NULL THEN
                      0
                     ELSE
                      1
                   END ENTITY_JOIN_COLUMN,
                   ALIGN_OBJ.*
              FROM TABLE(PI_DATA_ENTITY_INFO) ALIGN_OBJ);

    IF V_ENTITY_NAME_COL IS NOT NULL THEN
      DBMS_UTILITY.COMMA_TO_TABLE(V_ENTITY_NAME_COL,
                                  V_ENT_BUSINESS_LENGTH,
                                  V_ENT_BUSINESS_ARRAY);
      DBMS_UTILITY.COMMA_TO_TABLE(V_ENTITY_COL_WHERE,
                                  V_ENTITY_VAL_WHERE_LENGTH,
                                  V_ENTITY_VAL_WHERE_ARRAY);
      DBMS_UTILITY.COMMA_TO_TABLE(V_ENTITY_BUSINESS_FLD,
                                  V_ENTITY_BUSINESS_FLD_LENGTH,
                                  V_ENTITY_BUSINESS_FLD_ARRAY);
    END IF;

    V_FROM_CLAUSE             := PI_CDT_INFO(1).CDT_NAME || ' ' || PI_CDT_INFO(1)
                                 .CDT_ALIAS;
    V_FROM_CLAUSE             := V_FROM_CLAUSE || ' ' ||
                                 V_ENTITY_JOIN_CLAUSE;
    V_FROM_CLAUSE_FILTERED_DT := V_FROM_CLAUSE; -- OF-14966

    /*OF-7783 - START - Including Period Fields related Join, if required*/
    V_FROM_CLAUSE_DT_PERIOD_FLT := CASE
                                     WHEN (PI_CDT_INFO(1).CDT_INPUT_COMPARISON_COL_NAME IS NOT NULL AND PI_CDT_INFO(1)
                                          .CDT_INPUT_COMPARISON_COL_TYPE IN
                                           (4, 5, 6)) THEN
                                      ' LEFT OUTER JOIN TU_PERIODS_RANGE TUPR ON (TUPR.TUPR_ID = ' || PI_CDT_INFO(1)
                                     .CDT_ALIAS || '.' || PI_CDT_INFO(1)
                                     .CDT_INPUT_COMPARISON_COL_NAME || ')'
                                   END
                                  /* OF-7783 - END - Including Period Fields related Join, if required */
                                   || ' LEFT OUTER JOIN ' ||
                                   V_CAT_FINAL_TABLE -- OF-5674 -- PI_CAT_INFO ( 1).CAT_NAME
                                   || ' ' || V_CAT_FINAL_TABLE_ALIAS -- OF-5674 -- PI_CAT_INFO ( 1).CAT_ALIAS
                                   || ' ON ' || CASE
                                     WHEN PI_CDT_INFO(1)
                                      .CDT_INPUT_COMPARISON_COL_NAME IS NOT NULL THEN
                                     /*OF-7783 - START*/
                                     /* OF-8663 - START*/
                                      ' (' || /*OF-8796 - datetime issue handling part 1 */
                                      CASE
                                        WHEN PI_CDT_INFO(1)
                                         .CDT_INPUT_COMPARISON_COL_TYPE IN (1) -- DATE or DATETIME
                                         THEN
                                         'TO_DATE(TO_CHAR('
                                      END || CASE
                                        WHEN PI_CDT_INFO(1)
                                         .CDT_INPUT_COMPARISON_COL_TYPE NOT IN (1) THEN
                                         'NVL('
                                      END || CASE
                                        WHEN PI_CDT_INFO(1).CDT_INPUT_COMPARISON_COL_TYPE IN
                                              (1, 2, 3) -- DATES
                                         THEN
                                         PI_CDT_INFO(1)
                                         .CDT_ALIAS || '.' || PI_CDT_INFO(1)
                                         .CDT_INPUT_COMPARISON_COL_NAME
                                        WHEN PI_CDT_INFO(1).CDT_INPUT_COMPARISON_COL_TYPE IN
                                              (4, 5, 6) -- PERIODS' Start Date
                                         THEN
                                         'TUPR.TUPR_END_DATE'
                                      END || CASE
                                        WHEN PI_CDT_INFO(1)
                                         .CDT_INPUT_COMPARISON_COL_TYPE = 2 THEN
                                         ', TO_DATE(''01/01/1900'', ''DD/MM/YYYY''))' -- Date fields- START; START and END PERIODS' Start Date
                                        WHEN PI_CDT_INFO(1).CDT_INPUT_COMPARISON_COL_TYPE IN
                                              (3, 4, 5, 6) THEN
                                         ' , TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) ' -- Date fields- END
                                      END
                                     /*OF-8796 - datetime issue handling part 2*/
                                      || CASE
                                        WHEN PI_CDT_INFO(1)
                                         .CDT_INPUT_COMPARISON_COL_TYPE IN (1) -- DATE or DATETIME
                                         THEN
                                         ', ''DD/MM/YYYY''),''DD/MM/YYYY'')'
                                      END || ' BETWEEN NVL(' ||
                                      V_CAT_FINAL_TABLE_ALIAS -- OF-5674 -- PI_CAT_INFO ( 1).CAT_ALIAS
                                      || '.' || PI_CAT_INFO(1)
                                     .CAT_START_COL_NAME ||
                                      ', TO_DATE(''01/01/1900'', ''DD/MM/YYYY''))  AND NVL(' ||
                                      V_CAT_FINAL_TABLE_ALIAS -- OF-5674 -- PI_CAT_INFO ( 1).CAT_ALIAS
                                      || '.' || PI_CAT_INFO(1)
                                     .CAT_END_COL_NAME ||
                                      ', TO_DATE(''31/12/9999'', ''DD/MM/YYYY''))  ' || CASE
                                        WHEN PI_CDT_INFO(1).CDT_INPUT_COMPARISON_COL_TYPE IN
                                              (4, 5, 6) -- PERIODS' END Date
                                         THEN
                                         ' OR NVL(TUPR.TUPR_START_DATE, TO_DATE(''01/01/1900'', ''DD/MM/YYYY'')) ' ||
                                         ' BETWEEN NVL(' ||
                                         V_CAT_FINAL_TABLE_ALIAS -- OF-5674 -- PI_CAT_INFO ( 1).CAT_ALIAS
                                         || '.' || PI_CAT_INFO(1)
                                        .CAT_START_COL_NAME ||
                                         ', TO_DATE(''01/01/1900'', ''DD/MM/YYYY''))  AND NVL(' ||
                                         V_CAT_FINAL_TABLE_ALIAS -- OF-5674 -- PI_CAT_INFO ( 1).CAT_ALIAS
                                         || '.' || PI_CAT_INFO(1)
                                        .CAT_END_COL_NAME ||
                                         ', TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) '
                                      END || ')   AND  '
                                   END;

    V_FROM_CLAUSE := V_FROM_CLAUSE || V_FROM_CLAUSE_DT_PERIOD_FLT;
    /*OF-7783 - END*/
    /* OF-8663 - END*/

    V_FROM_CLAUSE             := V_FROM_CLAUSE || V_JOIN_CLAUSE || ' ' || PI_CDT_INFO(1)
                                .CDT_FILTER_JOIN_CLAUSE;
    V_FROM_CLAUSE_FILTERED_DT := V_FROM_CLAUSE_FILTERED_DT || ' ' || PI_CDT_INFO(1)
                                .CDT_FILTER_JOIN_CLAUSE; -- OF-14966

    -- OF-14723 -- START
    V_FROM_CLAUSE_VALID      := V_FROM_CLAUSE;
    V_FROM_CLAUSE_VALIDATION := V_FROM_CLAUSE;

    V_FROM_CLAUSE := PI_CDT_INFO(1)
                     .CDT_NAME || '  ' || PI_CDT_INFO(1).CDT_ALIAS ||
                      '  INNER JOIN ' || V_VALID_RECORDS_TABLE ||
                      '  T_VALID ON (T_VALID.CDT_ROW_IDENTIFIER = ' || PI_CDT_INFO(1)
                     .CDT_ALIAS || '.ROW_IDENTIFIER)';
    -- V_FROM_CLAUSE_GT_13_OUTER     := V_FROM_CLAUSE;  -- OF-15568
    V_FROM_CLAUSE := V_FROM_CLAUSE || ' ' || V_ENTITY_JOIN_CLAUSE;

    -- V_FROM_CLAUSE_INVALID       := PI_CDT_INFO(1).CDT_NAME || '  ' || PI_CDT_INFO(1).CDT_ALIAS || '  LEFT OUTER JOIN ' || V_VALID_RECORDS_TABLE  || '  T_VALID ON (T_VALID.CDT_ROW_IDENTIFIER = ' || PI_CDT_INFO(1).CDT_ALIAS || '.ROW_IDENTIFIER)';
    V_FROM_CLAUSE_INVALID := PI_CDT_INFO(1)
                             .CDT_NAME || '  ' || PI_CDT_INFO(1).CDT_ALIAS ||
                              '  LEFT OUTER JOIN ' || V_VALID_RECORDS_TABLE ||
                              '  T_VALID ON (T_VALID.CDT_ROW_IDENTIFIER = ' || PI_CDT_INFO(1)
                             .CDT_ALIAS || '.ROW_IDENTIFIER)';
    -- OF-14723 -- END

    V_INS_COL_CLAUSE := V_INS_COL_CLAUSE || CASE
                          WHEN V_INS_TEMP IS NOT NULL THEN
                           ',' || V_INS_TEMP
                        END;

    -- 1.30 - OF-6852 - START - Processing as much as you can -- Initializing the Key fields for Data_Table to be used while populating UNCREDITED_DATA_RESULT_TABLE
    V_DT_KEY_FIELDS := V_INS_TEMP;
    -- 1.30 - OF-6852 - END - Processing as much as you can

    -- OF-10503 - START - Commenting the following code to shift it post the Additional fields are also added in the V_INS_COL_CLAUSE
    -- Set Key field variable for Overlap check - OF-5063
    -- v_CRT_KEY_FIELDS            := V_INS_COL_CLAUSE;
    -- OF-10503 - END

    V_SELECT_CLAUSE := V_SELECT_CLAUSE || CASE
                         WHEN V_SELECT_TEMP IS NOT NULL THEN
                          ',' || V_SELECT_TEMP
                       END;
    V_GROUP_CLAUSE := V_GROUP_CLAUSE || CASE
                        WHEN V_GROUP_TEMP IS NOT NULL THEN
                         ',' || V_GROUP_TEMP
                      END;

    -- OF-14723 -- START
    V_SELECT_CLAUSE_VALIDATION := V_SELECT_CLAUSE_VALIDATION || CASE
                                    WHEN V_SELECT_TEMP IS NOT NULL THEN
                                     ',' || V_SELECT_TEMP
                                  END;
    V_GROUP_CLAUSE_VALIDATION := V_GROUP_CLAUSE_VALIDATION || CASE
                                   WHEN V_GROUP_TEMP IS NOT NULL THEN
                                    ',' || V_GROUP_TEMP
                                 END;
    -- OF-14723 -- END

    V_WHERE_CLAUSE := PI_CDT_INFO(1).CDT_FILTER_WHERE_CLAUSE;

    -- OF-14966 - START
    V_WHERE_CLAUSE_FILTERED_DT := V_WHERE_CLAUSE;
    -- V_SQL_FILTERED_DT := 'SELECT ' || PI_CDT_INFO(1).CDT_ALIAS || '.ROW_IDENTIFIER FROM  ' || V_FROM_CLAUSE_VALID || CASE WHEN V_WHERE_CLAUSE IS NOT NULL THEN '  WHERE  '  || V_WHERE_CLAUSE END;   -- OF-14966 -- old
    V_SQL_FILTERED_DT := CASE
                           WHEN V_WHERE_CLAUSE_FILTERED_DT IS NOT NULL THEN
                            'SELECT ' || PI_CDT_INFO(1).CDT_ALIAS ||
                            '.ROW_IDENTIFIER FROM  ' ||
                            V_FROM_CLAUSE_FILTERED_DT || '  WHERE  ' ||
                            V_WHERE_CLAUSE_FILTERED_DT
                           ELSE
                            NULL
                         END; -- OF-14966 - new approach -- here only Data Table related filter needed and AT related Data Filtering
    -- OF-14966 - END

    -- OF-15568 - START
    -- V_WHERE_CLAUSE              := V_WHERE_CLAUSE || CASE WHEN V_WHERE_CLAUSE IS NOT NULL THEN ' AND  ' || V_CREDITING_ENTITY_ALIASED || ' IS NOT NULL ' ELSE V_CREDITING_ENTITY_ALIASED || ' IS NOT NULL ' END || V_CRED_COND_WHERE_CLAUSE;
    V_WHERE_CLAUSE := V_CREDITING_ENTITY_ALIASED || ' IS NOT NULL ' || CASE
                        WHEN V_WHERE_CLAUSE IS NOT NULL THEN
                         ' AND  ' || V_WHERE_CLAUSE
                      END || V_CRED_COND_WHERE_CLAUSE;
    -- OF-15568 - END

    -- OF-14723 - START
    V_WHERE_CLAUSE_VALID   := V_WHERE_CLAUSE;
    V_WHERE_CLAUSE         := ''; -- OF-14723
    V_WHERE_CLAUSE_INVALID := ' T_VALID.CDT_ROW_IDENTIFIER IS NULL ';
    V_WHERE_CLAUSE_INVALID := V_WHERE_CLAUSE_INVALID || CASE
                                WHEN V_SQL_FILTERED_DT IS NOT NULL THEN
                                 '  AND  ' || PI_CDT_INFO(1).CDT_ALIAS ||
                                 '.ROW_IDENTIFIER IN (' || V_SQL_FILTERED_DT || ')'
                              END; -- OF-14966
    -- OF-14723 - END

    -- OF-14977 - START -- Removing those records for which the Crediting Conditions conflict
    -- OF-15610 - START -- Replacing V_CREDITING_ENTITY_ALIASED with : <V_CAT_FINAL_TABLE_ALIAS> || '.ROW_IDENTIFIER'
    -- V_WHERE_CLAUSE_VALID        := V_WHERE_CLAUSE_VALID || CASE WHEN V_SQL_CONFLICTING_RECORDS IS NOT NULL THEN CASE WHEN V_WHERE_CLAUSE_VALID IS NOT NULL THEN ' AND '  END || V_CREDITING_ENTITY_ALIASED || '  NOT IN (' || V_SQL_CONFLICTING_RECORDS || ')' END;
    V_WHERE_CLAUSE_VALID := V_WHERE_CLAUSE_VALID || CASE
                              WHEN V_SQL_CONFLICTING_RECORDS IS NOT NULL THEN
                               CASE
                                 WHEN V_WHERE_CLAUSE_VALID IS NOT NULL THEN
                                  ' AND '
                               END || V_CAT_FINAL_TABLE_ALIAS ||
                               '.ROW_IDENTIFIER  NOT IN (' ||
                               V_SQL_CONFLICTING_RECORDS || ')'
                            END;

    -- OF-15610 - END
    -- OF-14977 - END

    -- OF-17799 - START
    /*
        SELECT LISTAGG(PI_CDT_INFO(1).CDT_ALIAS || '.' || COLUMN_VALUE, ' , ') WITHIN GROUP (ORDER BY NULL),
               LISTAGG(COLUMN_VALUE, ' , ') WITHIN GROUP (ORDER BY NULL)
          INTO V_SELECT_TEMP, V_INS_TEMP
          FROM TABLE(PI_ADD_FIELDS_TO_CREDIT);
    */
    SELECT LISTAGG('UPPER(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                   COLUMN_VALUE || ') ' || COLUMN_VALUE,
                   ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(COLUMN_VALUE, ' , ') WITHIN GROUP(ORDER BY NULL),
           LISTAGG('UPPER(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                   COLUMN_VALUE || ')',
                   ' , ') WITHIN GROUP(ORDER BY NULL)
      INTO V_SELECT_TEMP, V_INS_TEMP, V_GROUP_TEMP
      FROM TABLE(PI_ADD_FIELDS_TO_CREDIT);

    -- OF-17799 - END

    -- OF-10503 - START
    -- Set Key field variable for Overlap check - OF-5063
    V_INS_COL_CLAUSE := V_INS_COL_CLAUSE || CASE
                          WHEN V_INS_TEMP IS NOT NULL THEN
                           ',' || V_INS_TEMP
                        END;
    v_CRT_KEY_FIELDS := V_INS_COL_CLAUSE;

    -- 1.30 - OF-6852 - START - Processing as much as you can -- Initializing the Key fields for Data_Table to be used while populating UNCREDITED_DATA_RESULT_TABLE
    V_DT_KEY_FIELDS := V_DT_KEY_FIELDS || CASE
                         WHEN V_INS_TEMP IS NOT NULL THEN
                          ',' || V_INS_TEMP
                       END;

    -- 1.30 - OF-6852 - END - Processing as much as you can

    -- INSERT_LOGS('-- v_CRT_KEY_FIELDS = ' || v_CRT_KEY_FIELDS);
    -- INSERT_LOGS('-- V_DT_KEY_FIELDS = ' || V_DT_KEY_FIELDS);
    -- INSERT_LOGS('-- Data_Table_Name = ' || PI_CDT_INFO(1).CDT_NAME);
    -- INSERT_LOGS('-- CRT_Table_Name = ' || PI_CRT_INFO(1).CRT_NAME);

    -- OF-10503 - END

    -- OF-4574 START
    -- Set Variables for Date Or Period field
    IF PI_CRT_INFO(1).CRT_DATE_OR_PERIOD_OPTION = 1 -- 1 - None
     THEN
      V_DATE_OR_PERIOD_COL         := NULL;
      V_DATE_OR_PERIOD_COL_ALIASED := NULL;
    ELSIF PI_CRT_INFO(1).CRT_DATE_OR_PERIOD_OPTION IN (2, 3) -- 2 - Date, 3 - Period
     THEN
      V_DATE_OR_PERIOD_COL         := PI_CRT_INFO(1).CRT_START_COLUMN_NAME;
      V_DATE_OR_PERIOD_COL_ALIASED := PI_CDT_INFO(1).CDT_ALIAS || '.' || PI_CRT_INFO(1)
                                      .CRT_START_COLUMN_NAME;
    ELSIF PI_CRT_INFO(1).CRT_DATE_OR_PERIOD_OPTION IN (4, 5) -- 4 - Date Range, 5- Period Range
     THEN
      V_DATE_OR_PERIOD_COL         := PI_CRT_INFO(1).CRT_START_COLUMN_NAME || ',' || PI_CRT_INFO(1)
                                      .CRT_END_COLUMN_NAME;
      V_DATE_OR_PERIOD_COL_ALIASED := PI_CDT_INFO(1).CDT_ALIAS || '.' || PI_CRT_INFO(1)
                                      .CRT_START_COLUMN_NAME || ',' || PI_CDT_INFO(1)
                                      .CDT_ALIAS || '.' || PI_CRT_INFO(1)
                                      .CRT_END_COLUMN_NAME;
    END IF;

    -- INSERT_LOGS('-- i M HERE 0 ');
    V_INS_COL_CLAUSE := V_INS_COL_CLAUSE || CASE
                          WHEN V_DATE_OR_PERIOD_COL IS NOT NULL THEN
                           ',' || V_DATE_OR_PERIOD_COL
                        END;

    -- INSERT_LOGS('-- i M HERE 00 ');
    V_SELECT_CLAUSE := V_SELECT_CLAUSE || CASE
                         WHEN V_SELECT_TEMP IS NOT NULL THEN
                          ',' || V_SELECT_TEMP
                       END || CASE
                         WHEN V_DATE_OR_PERIOD_COL_ALIASED IS NOT NULL THEN
                          ',' || V_DATE_OR_PERIOD_COL_ALIASED
                       END;

    -- OF-17799 - START
    /*
    V_GROUP_CLAUSE                :=
         V_GROUP_CLAUSE
      || CASE WHEN V_SELECT_TEMP IS NOT NULL THEN ',' || V_SELECT_TEMP END
      || CASE WHEN V_DATE_OR_PERIOD_COL_ALIASED IS NOT NULL THEN ',' || V_DATE_OR_PERIOD_COL_ALIASED END;
      */
    V_GROUP_CLAUSE := V_GROUP_CLAUSE || CASE
                        WHEN V_GROUP_TEMP IS NOT NULL THEN
                         ',' || V_GROUP_TEMP
                      END || CASE
                        WHEN V_DATE_OR_PERIOD_COL_ALIASED IS NOT NULL THEN
                         ',' || V_DATE_OR_PERIOD_COL_ALIASED
                      END;
    -- OF-17799 - END
    -- OF-4574 END

    -- OF-14723 -- START
    V_SELECT_CLAUSE_VALIDATION := V_SELECT_CLAUSE_VALIDATION || CASE
                                    WHEN V_SELECT_TEMP IS NOT NULL THEN
                                     ',' || V_SELECT_TEMP
                                  END || CASE
                                    WHEN V_DATE_OR_PERIOD_COL_ALIASED IS NOT NULL THEN
                                     ',' || V_DATE_OR_PERIOD_COL_ALIASED
                                  END;

    V_GROUP_CLAUSE_VALIDATION := V_GROUP_CLAUSE_VALIDATION || CASE
                                   WHEN V_SELECT_TEMP IS NOT NULL THEN
                                    ',' || V_SELECT_TEMP
                                 END || CASE
                                   WHEN V_DATE_OR_PERIOD_COL_ALIASED IS NOT NULL THEN
                                    ',' || V_DATE_OR_PERIOD_COL_ALIASED
                                 END;

    -- OF-14723 -- END

    -- INSERT_LOGS('-- i M HERE 000 ');

    -- OF-5674 -- START
    IF (PI_CAT_INFO(1).CAT_IS_ALLOCATION_APPLICABLE = 1) THEN
      -- V_AGGREGATE_TEMP := '*(' || V_CAT_FINAL_TABLE_ALIAS /*PI_CAT_INFO ( 1).CAT_ALIAS*/ || '.' || PI_CAT_INFO(1).CAT_ALLOCATION_COL_NAME || ')';
      V_AGGREGATE_TEMP := '*(T_VALID.' || PI_CAT_INFO(1)
                         .CAT_ALLOCATION_COL_NAME || ')'; -- OF-14723
    END IF;

    -- OF-5674 -- END

    -- INSERT_LOGS('-- i M HERE 0000 ');

    -- OF-? - START - Added HAVING_VALID and HAVING_INVALID below
    SELECT LISTAGG(CASE
                     WHEN FTC_DECIMAL_LENGTH IS NOT NULL THEN
                      'CAST (ROUND('
                   END || 'sum(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                   FTC_COLUMN_NAME || CASE
                     WHEN FTC_IS_ALLOCATION_APPLICABLE = 1 THEN
                      V_AGGREGATE_TEMP
                   END || ') ' || CASE
                     WHEN FTC_DECIMAL_LENGTH IS NOT NULL THEN
                      '   ,' || FTC_DECIMAL_LENGTH || ' )  AS  NUMBER(23,10) ) '
                   END || FTC_COLUMN_NAME,
                   ' , ') WITHIN GROUP(ORDER BY NULL) SELECT_TEMP,
           LISTAGG('NVL(' || /*OF-15608 - NULL Handling done*/
                   CASE
                     WHEN FTC_DECIMAL_LENGTH IS NOT NULL THEN
                      'ROUND('
                   END || 'sum(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                   FTC_COLUMN_NAME || CASE
                     WHEN FTC_IS_ALLOCATION_APPLICABLE = 1 THEN
                      V_AGGREGATE_TEMP
                   END || ') ' || CASE
                     WHEN FTC_DECIMAL_LENGTH IS NOT NULL THEN
                      '   ,' || FTC_DECIMAL_LENGTH || ' )  '
                   END || ', 0)' /*OF-15608 - NULL Handling done*/
                   || ' < ' || V_OPTYMYZE_NUMERIC_LIMIT,
                   '  AND  ') WITHIN GROUP(ORDER BY NULL) HAVING_VALID,
           LISTAGG('NVL(' || /*OF-15608 - NULL Handling done*/
                   CASE
                     WHEN FTC_DECIMAL_LENGTH IS NOT NULL THEN
                      'ROUND('
                   END || 'sum(' || PI_CDT_INFO(1).CDT_ALIAS || '.' ||
                   FTC_COLUMN_NAME || CASE
                     WHEN FTC_IS_ALLOCATION_APPLICABLE = 1 THEN
                      V_AGGREGATE_TEMP
                   END || ') ' || CASE
                     WHEN FTC_DECIMAL_LENGTH IS NOT NULL THEN
                      '   ,' || FTC_DECIMAL_LENGTH || ' )  '
                   END || ', 0)' /*OF-15608 - NULL Handling done*/
                   || ' >= ' || V_OPTYMYZE_NUMERIC_LIMIT,
                   '  OR  ') WITHIN GROUP(ORDER BY NULL) HAVING_INVALID,
           LISTAGG(FTC_COLUMN_NAME, ' , ') WITHIN GROUP(ORDER BY NULL) INS_TEMP
      INTO V_SELECT_TEMP,
           V_HAVING_CLAUSE_LTE_13,
           V_HAVING_CLAUSE_GT_13,
           V_INS_TEMP
      FROM TABLE(PI_FIELDS_TO_CREDIT);

    -- OF-? - END

    -- INSERT_LOGS('-- i M HERE 00000 ');

    V_SELECT_CLAUSE := V_SELECT_CLAUSE || CASE
                         WHEN V_SELECT_TEMP IS NOT NULL THEN
                          ',' || V_SELECT_TEMP
                       END;
    V_SELECT_CLAUSE_VALIDATION := V_SELECT_CLAUSE_VALIDATION || CASE
                                    WHEN V_SELECT_TEMP IS NOT NULL THEN
                                     ',' || V_SELECT_TEMP
                                  END; -- OF-14723
    V_INS_COL_CLAUSE := V_INS_COL_CLAUSE || CASE
                          WHEN V_INS_TEMP IS NOT NULL THEN
                           ',' || V_INS_TEMP
                        END;

    V_HAVING_CLAUSE_VALIDATION := V_HAVING_CLAUSE_LTE_13; -- OF-?

    -- INSERT_LOGS('-- i M HERE 1 ');

    -- Validation
    IF V_ENTITY_JOIN_COLUMN IS NOT NULL THEN
      -- VALIDATION POSTING
      V_SQL_VALIDATION := 'CREATE TABLE ' || V_VALIDATION_TABLE || ' AS ';

      -- OF-14723 -- START
      --V_SQL_VALIDATION := V_SQL_VALIDATION || ' SELECT ' || V_SELECT_CLAUSE;
      V_SQL_VALIDATION := V_SQL_VALIDATION || ' SELECT ' ||
                          V_SELECT_CLAUSE_VALIDATION;
      -- OF-14723 -- END

      V_SQL_VALIDATION := V_SQL_VALIDATION || CASE
                            WHEN V_ENT_BUSINESS_COL IS NOT NULL THEN
                             ',' || V_ENT_BUSINESS_COL
                          END;

      -- OF-14723 -- START
      --V_SQL_VALIDATION := V_SQL_VALIDATION || ' FROM ' || V_FROM_CLAUSE;
      V_SQL_VALIDATION := V_SQL_VALIDATION || ' FROM ' ||
                          V_FROM_CLAUSE_VALIDATION;
      -- OF-14723 -- END

      V_SQL_VALIDATION := V_SQL_VALIDATION || CASE
                            WHEN V_ENTITY_VAL_WHERE IS NOT NULL THEN
                             ' WHERE ' || V_ENTITY_VAL_WHERE
                          END;
      V_SQL_VALIDATION := V_SQL_VALIDATION || CASE
                            WHEN PI_CDT_INFO(1)
                             .CDT_FILTER_WHERE_CLAUSE IS NOT NULL THEN
                             ' AND ' || PI_CDT_INFO(1).CDT_FILTER_WHERE_CLAUSE
                          END;

      -- OF-14723 -- START
      V_SQL_VALIDATION := V_SQL_VALIDATION || CASE
                            WHEN V_GROUP_CLAUSE_VALIDATION IS NOT NULL THEN
                             ' GROUP BY ' || V_GROUP_CLAUSE_VALIDATION || CASE
                               WHEN V_ENT_BUSINESS_GRP IS NOT NULL THEN
                                ',' || V_ENT_BUSINESS_GRP
                             END
                          END;
      -- OF-14723 -- END

      -- OF-? -- START -- Add HAVING clause so as to filter out NUMERIC_13_OVERFLOW type records
      V_SQL_VALIDATION := V_SQL_VALIDATION || CASE
                            WHEN V_HAVING_CLAUSE_VALIDATION IS NOT NULL THEN
                             ' HAVING ' || V_HAVING_CLAUSE_VALIDATION
                          END;
      V_SQL_VALIDATION := REPLACE(V_SQL_VALIDATION,
                                  '(T_VALID',
                                  '(' || V_CAT_FINAL_TABLE_ALIAS); -- OF-15023

      -- OF-? -- END

      BEGIN
        -- INSERT_LOGS('-- V_SQL_VALIDATION => ' || V_SQL_VALIDATION);
        --OF-9688 start
        v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_VALIDATION';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(V_SQL_VALIDATION),
                          'V_SQL_VALIDATION := <value>;',
                          v_stamp);
        --OF-9688 end

        -- Start OF-10375 to execute DDL in autonomous transaction
        -- EXECUTE IMMEDIATE V_SQL_VALIDATION;
      /*  commons_utils.INSERT_LOGS(V_SQL_VALIDATION);*/
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => V_SQL_VALIDATION);
        -- End OF-10375 to execute DDL in autonomous transaction

        -- Start OF-10375 DML will be committed from JAVA
        -- COMMIT;
        -- End OF-10375 DML will be committed from JAVA
        -- NULL;
      EXCEPTION
        WHEN E_NUMERIC_OVERFLOW_13 THEN
          SELECT MIN(F.FLD_BUSINESS_NAME)
            INTO v_FLD_BUSINESS_NAME
            FROM fields f
           WHERE F.FLD_COLUMN_NAME = PI_FIELDS_TO_CREDIT(1).FTC_COLUMN_NAME; -- PI_FIELDS_TO_CREDIT(1).COLUMN_NAME;  -- OF-14407

          SELECT MIN(E.ENTITY_NAME)
            INTO V_ENTITY_BUSINESS_NAME
            FROM entities e
           WHERE 'E' || E.ENTITY_ID = PI_CAT_INFO(1).CAT_ENTITY_COL_NAME;

          V_LOG_DETAILS := COLTYPE_LOG_DETAILS();

          -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
          -- PO_STATUS     := 41; -- Temporarily set it to 41 (relative to "4"; non-used status)
          PO_STATUS := 3;
          -- 1.30 - OF-6852 - END - Processing as much as you can
          CNT := NULL;

          -- OF-5093
          SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                   'rrrr-mm-dd hh24:mi:ss.ff'),
                                           'YYYY-MM-DD HH24:MI:SS.ff') AS
                              TIMESTAMP),
                         TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
            INTO V_LOG_START_TIME
            FROM DUAL;

          LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                                pin_LM_LEVEL           => 0,
                                pin_LM_MESSAGE         => 'Crediting values from the ' ||
                                                          v_FLD_BUSINESS_NAME ||
                                                          ' field to one or more ' ||
                                                          V_ENTITY_BUSINESS_NAME ||
                                                          ' values will result in values that exceed 13 integer digits.',
                                pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                                pin_LM_START_DATE      => V_LOG_START_TIME, -- OF-5093
                                pin_LM_UPDATE_DATE     => NULL,
                                pinout_LM_ID           => CNT);
          CNT := NULL;
      END;

      -- INSERT_LOGS ( 'UTC = ' || TO_CHAR ( V_LOG_START_TIME));
      -- INSERT_LOGS ( 'SYSTIMESTAMP = ' || TO_CHAR ( SYSTIMESTAMP));

      IF (V_ENT_BUSINESS_LENGTH <> 0) THEN
        FOR C_ARRAY IN 1 .. V_ENT_BUSINESS_LENGTH LOOP
          V_ENTITY_VALIDATION := 'SELECT to_char(' ||
                                 V_ENT_BUSINESS_ARRAY(C_ARRAY) || ') FROM ' ||
                                 V_VALIDATION_TABLE || ' WHERE ' ||
                                 V_ENTITY_VAL_WHERE_ARRAY(C_ARRAY) ||
                                 ' IS NULL';

          -- INSERT_LOGS(' -- V_ENTITY_VALIDATION -- ' || V_ENTITY_VALIDATION);
          --OF-9688 start
          v_stamp := 'CREDITING.EVALUATE_CREDITING: V_ENTITY_VALIDATION';
          L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                            ANYDATA.CONVERTCLOB(V_ENTITY_VALIDATION),
                            'V_ENTITY_VALIDATION := <value>;',
                            v_stamp);
          --OF-9688 end
   /*       commons_utils.INSERT_LOGS('V_ENTITY_VALIDATION in EN_MAIN ' ||
                                    V_ENTITY_VALIDATION);*/
          EXECUTE IMMEDIATE V_ENTITY_VALIDATION BULK COLLECT
            INTO COL_ENTITY_VALIDATION;

          IF (COL_ENTITY_VALIDATION IS NOT NULL) THEN
            V_LOG_DETAILS := COLTYPE_LOG_DETAILS();
            LOG_CNT       := 0;

            FOR C IN 1 .. COL_ENTITY_VALIDATION.COUNT LOOP
              IF (COL_ENTITY_VALIDATION(C) IS NOT NULL) THEN
                IF (V_LOG_DETAILS.COUNT = 0) THEN
                  V_LOG_DETAILS.EXTEND;

                  V_LOG_DETAILS(1) := RTYPE_LOG_DETAILS('The following values do not exist in the ' ||
                                                        SUBSTR(V_ENT_BUSINESS_ARRAY(C_ARRAY),
                                                               2,
                                                               LENGTH(V_ENT_BUSINESS_ARRAY(C_ARRAY)) - 2) ||
                                                        ' entity table:',
                                                        1);
                  LOG_CNT := LOG_CNT + 1;
                END IF;

                V_LOG_DETAILS.EXTEND;
                LOG_CNT := LOG_CNT + 1;
                V_LOG_DETAILS(LOG_CNT) := RTYPE_LOG_DETAILS(COL_ENTITY_VALIDATION(C),
                                                            LOG_CNT);
              END IF;
            END LOOP;

            IF (V_LOG_DETAILS.COUNT <> 0) THEN
              BEGIN
                -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
                -- PO_STATUS := 4;
                PO_STATUS := 3;
                -- 1.30 - OF-6852 - END - Processing as much as you can
                CNT := NULL;

                -- OF-5093
                SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                         'rrrr-mm-dd hh24:mi:ss.ff'),
                                                 'YYYY-MM-DD HH24:MI:SS.ff') AS
                                    TIMESTAMP),
                               TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
                  INTO V_LOG_START_TIME
                  FROM DUAL;

                LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                                      pin_LM_LEVEL           => 0,
                                      pin_LM_MESSAGE         => 'Values in the field ' ||
                                                                SUBSTR(V_ENTITY_BUSINESS_FLD_ARRAY(C_ARRAY),
                                                                       2,
                                                                       LENGTH(V_ENTITY_BUSINESS_FLD_ARRAY(C_ARRAY)) - 2) ||
                                                                ' in the performance data table ' || PI_CDT_INFO(1)
                                                               .CDT_BUSINESS_NAME ||
                                                                ' do not exist in the ' ||
                                                                SUBSTR(V_ENT_BUSINESS_ARRAY(C_ARRAY),
                                                                       2,
                                                                       LENGTH(V_ENT_BUSINESS_ARRAY(C_ARRAY)) - 2) ||
                                                                ' entity table.',
                                      pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                                      pin_LM_START_DATE      => V_LOG_START_TIME, -- OF-5093
                                      pin_LM_UPDATE_DATE     => NULL,
                                      pinout_LM_ID           => CNT);
                CNT := NULL;
              END;
            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;

    -- 1.30 - OF-6852 - START - Processing as much as you can -- Hence do not RAISE the error from here -- If needed, later check the status to be 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
    -- IF (PO_STATUS = 4) THEN
    -- RAISE entity_validation;
    -- END IF;
    -- 1.30 - OF-6852 - END - Processing as much as you can

    /*----------------------------------------------------------------------------------------------------------------------------------*/

    -- ACTUAL POSTING TO CREDITING TABLE
    V_SQL := 'INSERT /* +APPEND */  when 1=1 then
INTO ' || PI_CRT_INFO(1).CRT_NAME;
    V_SQL := V_SQL || ' ( ROW_IDENTIFIER,ROW_VERSION,' || V_INS_COL_CLAUSE ||
             ' ) ';
    V_SQL := V_SQL || ' values  (' || PI_CRT_INFO(1).CRT_NAME ||
             '_ROW_IDENTIFIER_SEQ.NEXTVAL , 0,' || V_INS_COL_CLAUSE ||
             ' ) ';
    V_SQL := V_SQL || ' SELECT ' || V_SELECT_CLAUSE;

    -- OF-14723 -- START
    -- V_SQL                       := V_SQL || ' FROM ' || V_FROM_CLAUSE || ' ' || PI_CRED_CONDITIONS_INFO(1).JOIN_CLAUSE_DT;
    V_SQL := V_SQL || ' FROM ' || V_FROM_CLAUSE;
    -- OF-14723 -- END
    V_SQL := V_SQL || CASE
               WHEN V_WHERE_CLAUSE IS NOT NULL THEN
                ' WHERE ' || V_WHERE_CLAUSE
             END;
    V_SQL := V_SQL || CASE
               WHEN V_GROUP_CLAUSE IS NOT NULL THEN
                ' GROUP BY ' || V_GROUP_CLAUSE
             END;
    V_SQL := V_SQL || CASE
               WHEN V_HAVING_CLAUSE_LTE_13 IS NOT NULL THEN
                ' HAVING ' || V_HAVING_CLAUSE_LTE_13
             END; -- OF-?

    -- OF-14723 -- START
    V_SQL_VALID := 'CREATE TABLE ' || V_VALID_RECORDS_TABLE ||
                   '  AS SELECT ' || V_SELECT_CLAUSE_VALID;
    V_SQL_VALID := V_SQL_VALID || ' FROM ' || V_FROM_CLAUSE_VALID || ' ' || PI_CRED_CONDITIONS_INFO(1)
                  .CC_JOIN_CLAUSE_DT;
    V_SQL_VALID := V_SQL_VALID || CASE
                     WHEN V_WHERE_CLAUSE_VALID IS NOT NULL THEN
                      ' WHERE ' || V_WHERE_CLAUSE_VALID
                   END;

    -- OF-14723 -- END

    BEGIN
      -- OF-14723 -- START
      -- INSERT_LOGS(' -- V_SQL_VALID -- ' || V_SQL_VALID);
      --OF-9688 start
      v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_VALID';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(V_SQL_VALID),
                        'V_SQL_VALID := <value>;',
                        v_stamp);
      --OF-9688 end

      -- Start OF-10375 to execute DDL in autonomous transaction
      -- EXECUTE IMMEDIATE V_SQL_VALID;
  /*    commons_utils.INSERT_LOGS('V_SQL_VALID in EC_MAIN ' || V_SQL_VALID);*/
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => V_SQL_VALID);
      -- End OF-10375 to execute DDL in autonomous transaction

      -- INSERT_LOGS ('PI_CRT_INFO(1).CRT_IS_EFFECTIVE =  ' || PI_CRT_INFO(1).CRT_IS_EFFECTIVE || ' -- AND PI_CDT_INFO(1).CDT_DATE_OR_PERIOD_OPTION ' || PI_CDT_INFO(1).CDT_DATE_OR_PERIOD_OPTION);
      -- Check for Overlap in cases when CRT is effective and DATE (4) OR PERIOD (5) RANGE fields are part of CREDITING RESULT TABLE
      -- IF PI_CDT_INFO(1).CDT_DATE_OR_PERIOD_OPTION IN (4, 5) -- 4 - Date Range, 5- Period Range
      IF (PI_CRT_INFO(1).CRT_IS_EFFECTIVE = 1 AND PI_CDT_INFO(1)
         .CDT_DATE_OR_PERIOD_OPTION IN (4, 5)) -- 4 - Date Range, 5- Period Range
       THEN
        -- Create a copy Table of Filtered CDT
        -- V_SQL_NON_OVERLAP_DT := 'CREATE TABLE ' || V_NON_OVERLAP_DT || ' AS  SELECT * FROM ' || PI_CDT_INFO(1).CDT_NAME;
        V_SQL_NON_OVERLAP_DT := 'CREATE TABLE ' || V_NON_OVERLAP_DT ||
                                ' AS  SELECT ' || PI_CDT_INFO(1).CDT_ALIAS ||
                                '.* FROM ' || CASE
                                  WHEN V_WHERE_CLAUSE_FILTERED_DT IS NOT NULL THEN
                                   V_FROM_CLAUSE_FILTERED_DT || '  WHERE  ' || V_WHERE_CLAUSE_FILTERED_DT
                                  ELSE
                                   PI_CDT_INFO(1).CDT_NAME || '  ' || PI_CDT_INFO(1).CDT_ALIAS
                                END;
        -- INSERT_LOGS(' -- V_SQL_NON_OVERLAP_DT -- ' || V_SQL_NON_OVERLAP_DT);
        --OF-9688 start
        v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_NON_OVERLAP_DT';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(V_SQL_NON_OVERLAP_DT),
                          'V_SQL_NON_OVERLAP_DT := <value>;',
                          v_stamp);
        --OF-9688 end

        -- Start OF-10375 to execute DDL in autonomous transaction
        -- EXECUTE IMMEDIATE V_SQL_NON_OVERLAP_DT;
     /*   commons_utils.INSERT_LOGS('V_SQL_NON_OVERLAP_DT in EC_MAIN ' ||
                                  V_SQL_NON_OVERLAP_DT);*/
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => V_SQL_NON_OVERLAP_DT);
        -- End OF-10375 to execute DDL in autonomous transaction

        -- Pass the above CDT copy table to the ISOLATE_OVERLAPPING_RECORDS procedure to retrieve the Only the Non_Overlapping CDT records
        CREDITING.ISOLATE_OVERLAPPING_RECORDS(PI_SOURCE_TABLE_NAME      => V_NON_OVERLAP_DT,
                                              PI_OVERLAP_SET_TABLE_NAME => NULL,
                                              PI_KEY_FIELDS             => V_DT_KEY_FIELDS,
                                              PI_EFFECTIVE_START        => PI_CDT_INFO(1)
                                                                           .CDT_START_COLUMN_NAME,
                                              PI_EFFECTIVE_END          => PI_CDT_INFO(1)
                                                                           .CDT_END_COLUMN_NAME,
                                              PI_IS_PERIOD              => CASE
                                                                             WHEN PI_CDT_INFO(1)
                                                                              .CDT_DATE_OR_PERIOD_OPTION = 5 THEN
                                                                              1
                                                                             ELSE
                                                                              0
                                                                           END,
                                              PI_ID_COLUMN              => 'ROW_IDENTIFIER',
                                              PO_OVERLAP_CHK_RES        => v_OUT_OVERLAP_CHK_RESULT);

        V_SQL_NON_OVERLAP_VALID_TABLE := 'DELETE FROM ' ||
                                         V_VALID_RECORDS_TABLE ||
                                         ' T_VALID  WHERE EXISTS (SELECT 1 FROM ' || PI_CDT_INFO(1)
                                        .CDT_NAME || '  DT  ' ||
                                         ' LEFT OUTER JOIN  ' ||
                                         V_NON_OVERLAP_DT ||
                                         '  NODT  ON (NODT.ROW_IDENTIFIER = DT.ROW_IDENTIFIER)  WHERE NODT.ROW_IDENTIFIER IS NULL AND DT.ROW_IDENTIFIER = T_VALID.CDT_ROW_IDENTIFIER)';

        -- INSERT_LOGS('-- In Overlap block - IF THEN');
        -- INSERT_LOGS(' -- V_SQL_NON_OVERLAP_VALID_TABLE -- ' || V_SQL_NON_OVERLAP_VALID_TABLE);
        --OF-9688 start
        v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_NON_OVERLAP_VALID_TABLE';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(V_SQL_NON_OVERLAP_VALID_TABLE),
                          'V_SQL_NON_OVERLAP_VALID_TABLE := <value>;',
                          v_stamp);
        --OF-9688 end
        --Start OF-10375 to execute DDL in autonomous transaction
        -- EXECUTE IMMEDIATE V_SQL_NON_OVERLAP_VALID_TABLE;
     /*   commons_utils.INSERT_LOGS('V_SQL_NON_OVERLAP_VALID_TABLE in EC_MAIN ' ||
                                  V_SQL_NON_OVERLAP_VALID_TABLE);*/
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => V_SQL_NON_OVERLAP_VALID_TABLE);
        -- End OF-10375 to execute DDL in autonomous transaction
      ELSE
        -- No need to check for Overlap when PI_CRT_INFO ( 1).CRT_DATE_OR_PERIOD_OPTION NOT IN (4, 5)
        -- INSERT_LOGS('-- In Overlap block - ELSE');
        v_OUT_OVERLAP_CHK_RESULT := 1; -- Overlap Check succeeds
      END IF;

      -- INSERT_LOGS(' -- V_SQL -- ' || V_SQL);
      --OF-9688 start
      v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(V_SQL),
                        'V_SQL := <value>;',
                        v_stamp);
      --OF-9688 end
     /* commons_utils.INSERT_LOGS('V_SQL in EC_MAIN ' || V_SQL);*/
      EXECUTE IMMEDIATE V_SQL;

      -- OF-16309 - START - Setting PO_IS_CRT_EMPTY parameter, as per the result of "EXECUTE IMMEDIATE V_SQL" above.
      IF SQL%ROWCOUNT = 0 THEN
        PO_IS_CRT_EMPTY := 1; -- No records inserted in CRT
      ELSE
        PO_IS_CRT_EMPTY := 0; -- At least one record inserted in CRT
      END IF;

      -- OF-16309 - END
      -- INSERT_LOGS(' -- PO_IS_CRT_EMPTY = ' || PO_IS_CRT_EMPTY);
      -- OF-14723 -- END
      -- NULL;
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX -- "ORA-00001: unique constraint (constraint_name) violated"
       THEN
        -- INSERT_LOGS(' EXCEPTION 1 - START - WHEN DUP_VAL_ON_INDEX');
        /*  1.30 - OF-6852 - START - Processing as much as you can
        -- Truncate Crediting Result Table
        EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || PI_CRT_INFO(1).CRT_NAME;
        1.30 - OF-6852 - END */

        -- Log Message
        V_LOG_DETAILS := COLTYPE_LOG_DETAILS();
        -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
        -- PO_STATUS     := 42; -- Temporarily set it to 42 (relative to "4"; non-used status)
        PO_STATUS := 3;

        -- 1.30 - OF-6852 - END - Processing as much as you can

        SELECT MIN(E.ENTITY_NAME)
          INTO V_ENTITY_BUSINESS_NAME
          FROM entities e
         WHERE 'E' || E.ENTITY_ID = PI_CAT_INFO(1).CAT_ENTITY_COL_NAME;

        CNT := NULL;

        -- OF-5093
        SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                 'rrrr-mm-dd hh24:mi:ss.ff'),
                                         'YYYY-MM-DD HH24:MI:SS.ff') AS
                            TIMESTAMP),
                       TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
          INTO V_LOG_START_TIME
          FROM DUAL;

        LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                              pin_LM_LEVEL           => 0,
                              pin_LM_MESSAGE         => 'Crediting records to one or more ' ||
                                                        V_ENTITY_BUSINESS_NAME ||
                                                        ' values will result in overlapping records.', /*OF-4662 - Overlap Logs*/
                              pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                              pin_LM_START_DATE      => V_LOG_START_TIME, -- OF-5093
                              pin_LM_UPDATE_DATE     => NULL,
                              pinout_LM_ID           => CNT);

        CNT := NULL;
        -- INSERT_LOGS(' EXCEPTION 1 - END - WHEN DUP_VAL_ON_INDEX');

      WHEN E_NUMERIC_OVERFLOW_13 THEN
        -- INSERT_LOGS(' EXCEPTION 2 - START - WHEN E_NUMERIC_OVERFLOW_13');
        SELECT MIN(F.FLD_BUSINESS_NAME)
          INTO v_FLD_BUSINESS_NAME
          FROM fields f
         WHERE F.FLD_COLUMN_NAME = PI_FIELDS_TO_CREDIT(1).FTC_COLUMN_NAME; -- PI_FIELDS_TO_CREDIT(1).COLUMN_NAME;  -- OF-14407

        SELECT MIN(E.ENTITY_NAME)
          INTO V_ENTITY_BUSINESS_NAME
          FROM entities e
         WHERE 'E' || E.ENTITY_ID = PI_CAT_INFO(1).CAT_ENTITY_COL_NAME;

        V_LOG_DETAILS := COLTYPE_LOG_DETAILS();
        -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
        -- PO_STATUS     := 41; -- Temporarily set it to 41 (relative to "4"; non-used status)
        PO_STATUS := 3;
        -- 1.30 - OF-6852 - END - Processing as much as you can

        CNT := NULL;

        -- OF-5093
        SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                                 'rrrr-mm-dd hh24:mi:ss.ff'),
                                         'YYYY-MM-DD HH24:MI:SS.ff') AS
                            TIMESTAMP),
                       TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
          INTO V_LOG_START_TIME
          FROM DUAL;

        LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                              pin_LM_LEVEL           => 0,
                              pin_LM_MESSAGE         => 'Crediting values from the ' ||
                                                        v_FLD_BUSINESS_NAME ||
                                                        ' field to one or more ' ||
                                                        V_ENTITY_BUSINESS_NAME ||
                                                        ' values will result in values that exceed 13 integer digits.',
                              pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                              pin_LM_START_DATE      => V_LOG_START_TIME, -- OF-5093
                              pin_LM_UPDATE_DATE     => NULL,
                              pinout_LM_ID           => CNT);
        CNT := NULL;
        -- INSERT_LOGS(' EXCEPTION 2 - END - WHEN E_NUMERIC_OVERFLOW_13');
    END;

    -- 1.30 - OF-6852 - START - Processing as much as you can
    -- Comment the older code of Overlap Check and replace it with new private procedure -- removes the overlapping records, if any.
    -- OF-4574 START
    -- Check for Overlap in cases when DATE OR PERIOD RANGE fields are part of CREDITING RESULT TABLE
    /*IF PI_CRT_INFO(1).CRT_DATE_OR_PERIOD_OPTION IN (4, 5) -- 4 - Date Range, 5- Period Range
    THEN */
    -- INSERT_LOGS('-- In Overlap block - THEN');
    -- INSERT_LOGS('-- v_CRT_KEY_FIELDS = ' || v_CRT_KEY_FIELDS);
    /*
    COMMONS_TABLES.COMMON_OVERLAP_CHECK
    (
      pi_TABLE    => PI_CRT_INFO(1).CRT_NAME,
      pi_KEY_FIELDS => v_CRT_KEY_FIELDS,
      PI_effective_start => PI_CRT_INFO(1).CRT_START_COLUMN_NAME,
      PI_effective_end => PI_CRT_INFO(1).CRT_END_COLUMN_NAME,
      PI_is_Period => CASE WHEN PI_CRT_INFO(1).CRT_DATE_OR_PERIOD_OPTION = 5 THEN 1 ELSE 0 END,
      po_OVERLAP_CHK_RES => v_OUT_OVERLAP_CHK_RESULT
    );
    */

    --
    -- Create a blank copy Table of CRT to store the Overlapping CRT records
    -- V_SQL_NON_OVERLAP_DT  :=  'CREATE TABLE ' || V_NON_OVERLAP_DT || ' AS  SELECT * FROM ' || PI_CRT_INFO(1).CRT_NAME || ' WHERE 1 = 2';
    -- EXECUTE IMMEDIATE V_SQL_NON_OVERLAP_DT;
    /*
    CREDITING.ISOLATE_OVERLAPPING_RECORDS
    (
      PI_SOURCE_TABLE_NAME => PI_CRT_INFO(1).CRT_NAME,
      PI_OVERLAP_SET_TABLE_NAME => V_NON_OVERLAP_DT,   -- OF-14723
      PI_KEY_FIELDS => v_CRT_KEY_FIELDS,
      PI_EFFECTIVE_START => PI_CRT_INFO(1).CRT_START_COLUMN_NAME,
      PI_EFFECTIVE_END => PI_CRT_INFO(1).CRT_END_COLUMN_NAME,
      PI_IS_PERIOD => CASE WHEN PI_CRT_INFO(1).CRT_DATE_OR_PERIOD_OPTION = 5 THEN 1 ELSE 0 END,
      PI_ID_COLUMN => 'ROW_IDENTIFIER',
      PO_OVERLAP_CHK_RES => v_OUT_OVERLAP_CHK_RESULT
    );
    */
    -- 1.30 - OF-6852 - END - Processing as much as you can

    /*
    ELSE -- No need to check for Overlap when PI_CRT_INFO ( 1).CRT_DATE_OR_PERIOD_OPTION NOT IN (4, 5)
      -- INSERT_LOGS('-- In Overlap block - ELSE');
      v_OUT_OVERLAP_CHK_RESULT := 1; -- Overlap Check succeeds
    END IF;
    */

    -- INSERT_LOGS('-- v_OUT_OVERLAP_CHK_RESULT = ' || v_OUT_OVERLAP_CHK_RESULT);

    IF v_OUT_OVERLAP_CHK_RESULT = 0 -- when there is OVERLAP
     THEN
      -- INSERT_LOGS(' IF v_OUT_OVERLAP_CHK_RESULT = 0 - START ');
      -- 1.30 - OF-6852 - START - Processing as much as you can -- Hence no need to truncate the Result Table any more
      -- Truncate Crediting Result Table
      -- EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || PI_CRT_INFO(1).CRT_NAME;
      -- 1.30 - OF-6852 - END

      -- Log Message
      V_LOG_DETAILS := COLTYPE_LOG_DETAILS();

      -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
      -- PO_STATUS     := 42; -- Temporarily set it to 42 (relative to "4"; non-used status)
      PO_STATUS := 3;

      -- 1.30 - OF-6852 - END - Processing as much as you can

      SELECT MIN(E.ENTITY_NAME)
        INTO V_ENTITY_BUSINESS_NAME
        FROM entities e
       WHERE 'E' || E.ENTITY_ID = PI_CAT_INFO(1).CAT_ENTITY_COL_NAME;

      CNT := NULL;

      -- OF-5093
      SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                               'rrrr-mm-dd hh24:mi:ss.ff'),
                                       'YYYY-MM-DD HH24:MI:SS.ff') AS
                          TIMESTAMP),
                     TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
        INTO V_LOG_START_TIME
        FROM DUAL;

      LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                            pin_LM_LEVEL           => 0,
                            pin_LM_MESSAGE         => 'Crediting records to one or more ' ||
                                                      V_ENTITY_BUSINESS_NAME ||
                                                      ' values will result in overlapping records.', /*OF-4662 - Overlap Logs*/
                            pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                            pin_LM_START_DATE      => V_LOG_START_TIME, -- OF-5093
                            pin_LM_UPDATE_DATE     => NULL,
                            pinout_LM_ID           => CNT);
      CNT := NULL;
      -- INSERT_LOGS(' IF v_OUT_OVERLAP_CHK_RESULT = 0 - END ');
    END IF;

    -- INSERT_LOGS(' IF v_OUT_OVERLAP_CHK_RESULT = 0 - AFTER END ');

    -- OF-14723 -- START
    -- 1.30 - OF-6852 - START - Processing as much as you can
    /*
    -- a. Create the Column List -- To be used in the SELECT and INSERT clause of the V_SQL_LOAD_UNCREDITED_DATA
    FOR I IN PI_UDT_INFO(1).UDT_NON_TECH_COL_LIST.FIRST .. PI_UDT_INFO(1).UDT_NON_TECH_COL_LIST.LAST
    LOOP
      V_UDT_NON_TECH_COL_LIST  := V_UDT_NON_TECH_COL_LIST || PI_UDT_INFO(1).UDT_NON_TECH_COL_LIST(i) || ',';
    END LOOP;

    -- b. Remove the extra "," from the Column list
    V_UDT_NON_TECH_COL_LIST  := RTRIM(V_UDT_NON_TECH_COL_LIST, ',');
    */
    -- c. Populate the UNCREDITED_DATA_RESULT_TABLE with all the records that could not be credited due to several functional or technical validations.

    -- OF-15568 - START
    V_INSERT_CLAUSE_INVALID := 'ROW_IDENTIFIER,ROW_VERSION,' ||
                               V_UDT_NON_TECH_COL_LIST;
    V_SELECT_CLAUSE_INVALID := V_UDT_NAME ||
                               '_ROW_IDENTIFIER_SEQ.NEXTVAL , 0,' ||
                               V_UDT_NON_TECH_COL_LIST;

    V_DT_ALIAS_WITH_COMMA_INVALID := ', ' || PI_CDT_INFO(1).CDT_ALIAS || '.';
    V_SQL_UDT_NONTECH_COLS_ALIAS  := 'SELECT REPLACE(''' ||
                                     V_UDT_NON_TECH_COL_LIST ||
                                     ''','','',''' ||
                                     V_DT_ALIAS_WITH_COMMA_INVALID ||
                                     ''')  FROM DUAL';
    -- INSERT_LOGS(' -- V_SQL_UDT_NONTECH_COLS_ALIAS = ' || V_SQL_UDT_NONTECH_COLS_ALIAS);
    --OF-9688 start
    v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_UDT_NONTECH_COLS_ALIAS';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL_UDT_NONTECH_COLS_ALIAS),
                      'V_SQL_UDT_NONTECH_COLS_ALIAS := <value>;',
                      v_stamp);
    --OF-9688 end
  /*  commons_utils.INSERT_LOGS('V_SQL_UDT_NONTECH_COLS_ALIAS in EC_MAIN' ||
                              V_SQL_UDT_NONTECH_COLS_ALIAS);*/
    EXECUTE IMMEDIATE V_SQL_UDT_NONTECH_COLS_ALIAS
      INTO V_UDT_NON_TECH_COL_LIST_ALIAS;

    V_UDT_NON_TECH_COL_LIST_ALIAS := CASE
                                       WHEN V_UDT_NON_TECH_COL_LIST_ALIAS IS NOT NULL THEN
                                        V_DT_ALIAS_WITH_COMMA_INVALID ||
                                        V_UDT_NON_TECH_COL_LIST_ALIAS
                                     END;
    V_SELECT_CLAUSE_GT_13_OUTER   := LTRIM(V_UDT_NON_TECH_COL_LIST_ALIAS,
                                           ',');
    -- V_SELECT_CLAUSE_GT_13_OUTER := V_UDT_NAME || '_ROW_IDENTIFIER_SEQ.NEXTVAL , 0' || V_UDT_NON_TECH_COL_LIST_ALIAS;
    -- OF-15568 - END

    -- OF-? - START
    V_SELECT_CLAUSE_GT_13 := V_GROUP_CLAUSE;
    V_SQL_GT_13           := 'SELECT ' || V_SELECT_CLAUSE_GT_13 ||
                             '  FROM ' || V_FROM_CLAUSE;
    V_SQL_GT_13 := V_SQL_GT_13 || CASE
                     WHEN V_WHERE_CLAUSE IS NOT NULL THEN
                      ' WHERE ' || V_WHERE_CLAUSE
                   END;
    V_SQL_GT_13 := V_SQL_GT_13 || CASE
                     WHEN V_GROUP_CLAUSE IS NOT NULL THEN
                      ' GROUP BY ' || V_GROUP_CLAUSE
                   END;
    V_SQL_GT_13 := V_SQL_GT_13 || CASE
                     WHEN V_HAVING_CLAUSE_GT_13 IS NOT NULL THEN
                      ' HAVING ' || V_HAVING_CLAUSE_GT_13
                   END;

    V_FROM_CLAUSE_GT_13_OUTER  := V_FROM_CLAUSE; -- OF-15568
    V_WHERE_CLAUSE_GT_13_OUTER := V_GROUP_CLAUSE;
    V_SQL_GT_13_OUTER          := 'SELECT DISTINCT ' ||
                                  V_SELECT_CLAUSE_GT_13_OUTER || '  FROM ' ||
                                  V_FROM_CLAUSE_GT_13_OUTER; -- OF-15568
    V_SQL_GT_13_OUTER := V_SQL_GT_13_OUTER || CASE
                           WHEN V_WHERE_CLAUSE_GT_13_OUTER IS NOT NULL THEN
                            ' WHERE (' || V_WHERE_CLAUSE_GT_13_OUTER ||
                            ') IN (' || V_SQL_GT_13 || ')'
                         END;
    -- OF-? - END

    V_SQL_LOAD_UNCREDITED_DATA := 'INSERT /* +APPEND */  WHEN 1=1 THEN  INTO ' ||
                                  V_UDT_NAME;

    -- OF-15568 - START
    -- V_SQL_LOAD_UNCREDITED_DATA         := V_SQL_LOAD_UNCREDITED_DATA || ' ( ROW_IDENTIFIER,ROW_VERSION,' || V_UDT_NON_TECH_COL_LIST || ' ) ';
    V_SQL_LOAD_UNCREDITED_DATA := V_SQL_LOAD_UNCREDITED_DATA || ' ( ' ||
                                  V_INSERT_CLAUSE_INVALID || ' ) ';

    -- V_SQL_LOAD_UNCREDITED_DATA         := V_SQL_LOAD_UNCREDITED_DATA || ' VALUES  (' || V_UDT_NAME || '_ROW_IDENTIFIER_SEQ.NEXTVAL , 0,' || V_UDT_NON_TECH_COL_LIST || ' ) ';
    V_SQL_LOAD_UNCREDITED_DATA := V_SQL_LOAD_UNCREDITED_DATA ||
                                  ' VALUES  (' || V_SELECT_CLAUSE_INVALID ||
                                  ' ) ';
    -- OF-15568 - END

    V_SQL_LOAD_UNCREDITED_DATA := V_SQL_LOAD_UNCREDITED_DATA || ' SELECT '
                                 /*OF-30381 - START*/
                                  || V_SELECT_CLAUSE_GT_13_OUTER /*V_UDT_NON_TECH_COL_LIST*/
                                 /*OF-30381 - END*/
                                  || '  FROM ' || V_FROM_CLAUSE_INVALID ||
                                  ' WHERE ' || V_WHERE_CLAUSE_INVALID;
    V_SQL_LOAD_UNCREDITED_DATA := V_SQL_LOAD_UNCREDITED_DATA ||
                                  ' UNION ALL ' || V_SQL_GT_13_OUTER; -- OF-?

 /*   commons_utils.INSERT_LOGS(' -- V_SQL_LOAD_UNCREDITED_DATA -- ' ||
                              V_SQL_LOAD_UNCREDITED_DATA);*/
    --OF-9688 start
    v_stamp := 'CREDITING.EVALUATE_CREDITING: V_SQL_LOAD_UNCREDITED_DATA';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL_LOAD_UNCREDITED_DATA),
                      'V_SQL_LOAD_UNCREDITED_DATA := <value>;',
                      v_stamp);
    --OF-9688 end

    EXECUTE IMMEDIATE V_SQL_LOAD_UNCREDITED_DATA;

    -- OF-16309 - START - Setting PO_IS_UDT_EMPTY parameter, as per the result of "EXECUTE IMMEDIATE V_SQL_LOAD_UNCREDITED_DATA" above.
    IF SQL%ROWCOUNT = 0 THEN
      PO_IS_UDT_EMPTY := 1; -- No records inserted in UDT
    ELSE
      -- At least one record inserted in UDT
      PO_IS_UDT_EMPTY := 0;
      -- Even if 1 record goes into Uncredited Data Table, then Status should be "Completed with errors".
      -- P.S.: Here, we still need to handle an exception to the above rule that if all the records uncredited are due to the fact that the Crediting Condition meant them not to be credited, then in such a case it should be "Successful", i.e. 1.
      -- PO_STATUS := 3;
    END IF;

    -- OF-16309 - END
    -- INSERT_LOGS(' -- PO_IS_UDT_EMPTY = ' || PO_IS_UDT_EMPTY || ' -- PO_STATUS = ' || PO_STATUS);

    -- OF-?? - START
    EXECUTE IMMEDIATE 'SELECT COUNT(*)  FROM ' || V_FROM_CLAUSE_INVALID ||
                      ' WHERE ' || V_WHERE_CLAUSE_INVALID
      INTO V_COUNT_UNMATCHING_CDT_RECORDS;
    --OF-9688 start
    v_stamp := 'CREDITING.EVALUATE_CREDITING: V_COUNT_UNMATCHING_CDT_RECORDS';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(to_clob(V_COUNT_UNMATCHING_CDT_RECORDS)),
                      'V_COUNT_UNMATCHING_CDT_RECORDS := <value>;',
                      v_stamp);
    --OF-9688 end

    IF V_COUNT_UNMATCHING_CDT_RECORDS > 0 THEN
      -- Log Message
      V_LOG_DETAILS := COLTYPE_LOG_DETAILS();
      V_LOG_DETAILS.EXTEND;
      LOG_CNT := LOG_CNT + 1;
      V_LOG_DETAIL_MSG := 'The records that did not get credited using the ' ||
                          V_CAT_TYPE ||
                          ' are included in the Uncredited Data validation result. See the Uncredited Data validation result for details.';
      V_LOG_DETAILS(LOG_CNT) := RTYPE_LOG_DETAILS(V_LOG_DETAIL_MSG, LOG_CNT);

      PO_STATUS := 3;
      CNT       := NULL;

      SELECT FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(SYSTIMESTAMP,
                                               'rrrr-mm-dd hh24:mi:ss.ff'),
                                       'YYYY-MM-DD HH24:MI:SS.ff') AS
                          TIMESTAMP),
                     TZ_OFFSET(SESSIONTIMEZONE)) AT TIME ZONE 'UTC'
        INTO V_LOG_START_TIME
        FROM DUAL;

      LOGS.LOGS_UPSERT_DATA(pin_LM_RD_ID           => PI_RUN_ID,
                            pin_LM_LEVEL           => 0,
                            pin_LM_MESSAGE         => 'One or more records to credit from the performance data table ' || PI_CDT_INFO(1)
                                                     .CDT_BUSINESS_NAME ||
                                                      ' did not get credited using the ' ||
                                                      V_CAT_TYPE ||
                                                      ' records.', /*OF-16332 - Replaced CDT_NAME with CDT_BUSINESS_NAME*/
                            pin_LM_MESSAGE_DETAILS => V_LOG_DETAILS,
                            pin_LM_START_DATE      => V_LOG_START_TIME, -- OF-5093
                            pin_LM_UPDATE_DATE     => NULL,
                            pinout_LM_ID           => CNT);
      CNT := NULL;
      -- INSERT_LOGS(' IF v_OUT_OVERLAP_CHK_RESULT = 0 - END ');
    END IF;

    -- OF-?? - END

    -- OF-14723 -- END

    -- 1.30 - OF-6852 - START - Processing as much as you can -- Commit the data records inserted -- Will have to shift this COMMIT and corresponding code to AUTONOMOUS transaction
    -- COMMIT;
    -- 1.30 - OF-6852 - END - Processing as much as you can

    -- 1.30 - OF-6852 - START - Processing as much as you can -- Hence following steps not needed.
    -- IF PO_STATUS IN (41, 42, 43) THEN
    -- PO_STATUS := 4;
    -- END IF;
    -- 1.30 - OF-6852 - END - Processing as much as you can

    -- PO_STATUS                   := 3;  -- TEMP ABHI -- 10.JUN
    -- OF-4574 END

    -- OF-5674
    FOR C IN (SELECT TABLE_NAME
                FROM USER_TABLES
               WHERE TABLE_NAME IN (V_VALIDATION_TABLE,
                                    V_CAT_CRED_COND_TABLE,
                                    V_VALID_RECORDS_TABLE,
                                    V_NON_OVERLAP_DT)) LOOP
      --Start OF-10375 to execute DDL in autonomous transaction
      -- EXECUTE IMMEDIATE 'DROP TABLE ' || C.TABLE_NAME;
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' ||
                                                       C.TABLE_NAME);
      -- End OF-10375 to execute DDL in autonomous transaction
    END LOOP;

    -- OF-5674

    -- INSERT_LOGS(' -- processing - end');
  EXCEPTION
    WHEN entity_validation THEN
      -- OF-5674
      FOR C IN (SELECT TABLE_NAME
                  FROM USER_TABLES
                 WHERE TABLE_NAME IN (V_VALIDATION_TABLE,
                                      V_CAT_CRED_COND_TABLE,
                                      V_VALID_RECORDS_TABLE,
                                      V_NON_OVERLAP_DT)) LOOP
        -- Start OF-10375 to execute DDL in autonomous transaction
        -- EXECUTE IMMEDIATE 'DROP TABLE ' || C.TABLE_NAME;
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' ||
                                                         C.TABLE_NAME);
        -- End OF-10375 to execute DDL in autonomous transaction
      END LOOP;
      -- OF-5674

    -- OF-5674
    WHEN CREDITING_CONDITIONS_CONFLICT THEN
      -- 1.30 - OF-6852 - START - Processing as much as you can -- Change the status to 3 in stead of 4; since it is "completed with errors" now, in stead of failure.
      -- PO_STATUS := 4;
      PO_STATUS := 3;

      -- 1.30 - OF-6852 - END - Processing as much as you can
      FOR C IN (SELECT TABLE_NAME
                  FROM USER_TABLES
                 WHERE TABLE_NAME IN (V_VALIDATION_TABLE,
                                      V_CAT_CRED_COND_TABLE,
                                      V_VALID_RECORDS_TABLE,
                                      V_NON_OVERLAP_DT)) LOOP
        -- Start OF-10375 to execute DDL in autonomous transaction
        -- EXECUTE IMMEDIATE 'DROP TABLE ' || C.TABLE_NAME;
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' ||
                                                         C.TABLE_NAME);
        -- End OF-10375 to execute DDL in autonomous transaction
      END LOOP;
      -- OF-5674

    WHEN OTHERS THEN

      -- OF-5674
      FOR C IN (SELECT TABLE_NAME
                  FROM USER_TABLES
                 WHERE TABLE_NAME IN (V_VALIDATION_TABLE,
                                      V_CAT_CRED_COND_TABLE,
                                      V_VALID_RECORDS_TABLE,
                                      V_NON_OVERLAP_DT)) LOOP
        -- Start OF-10375 to execute DDL in autonomous transaction
        -- EXECUTE IMMEDIATE 'DROP TABLE ' || C.TABLE_NAME;
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP TABLE ' ||
                                                         C.TABLE_NAME);
        -- End OF-10375 to execute DDL in autonomous transaction
      END LOOP;
      -- OF-5674
    -- RAISE;
  END EVALUATE_CREDITING;

  PROCEDURE CREDITING_ROLLUP(PI_CRD_INFO       IN COLTYPE_CRD_INFO,
                             PI_CRT_INFO       IN COLTYPE_CRT_INFO,
                             PI_RTE_INFO       IN COLTYPE_RTE_INFO,
                             PI_HRD_INFO       IN COLTYPE_HRD_INFO,
                             PI_FTR_INFO       IN COLTYPE_FTR_INFO,
                             PI_RRT_INFO       IN COLTYPE_RRT_INFO,
                             PI_NRT_INFO       IN COLTYPE_NRT_INFO,
                             PI_URT_INFO       IN COLTYPE_URT_INFO,
                             PI_RUN_ID         IN NUMBER DEFAULT 0, -- ADDED
                             PI_date_run_for   date default null,
                             PI_period_run_for number, --- tupr_id for processing period (null in other cases)
                             PI_CREDITING_ID   IN NUMBER,

                             PO_STATUS           OUT NUMBER,
                             POUT_PRIMARY_ROWS   OUT NUMBER,
                             POUT_NO_ROLLUP_ROWS OUT NUMBER,
                             Pout_No_Match_Rows  Out Number) Is
    V_inputview_columns          VARCHAR2(1300 CHAR) := NULL; --
    V_rollup_alias_columns       VARCHAR2(1300 CHAR) := NULL; --
    V_inputview_ent_fld          VARCHAR2(1300 CHAR) := 'E' || PI_CRD_INFO(1)
                                                       .ROLLUP_FROM_ENTITY_EQ_ID;
    V_inputview                  clob := NULL; --
    V_relationship_tables        TABLETYPE_RELATIONSHIP_TABLES := TABLETYPE_RELATIONSHIP_TABLES(); --TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE(null, null, null, null, null));
    V_levels_rolled_up_column    VARCHAR2(1300 CHAR) := NULL;
    V_include_input_records      NUMBER := 0;
    V_roll_up_from_type          NUMBER := PI_CRD_INFO(1)
                                           .ROLLUP_FROM_ENTITY_BASE_ID; -- PI_CRD_INFO(1).ROLLUP_FROM_ENTITY_EQ_ID;
    V_roll_up_to_type            NUMBER := PI_RTE_INFO(1)
                                           .ROLLUP_TO_ENTITY_BASE_ID; -- PI_RTE_INFO(1).ROLLUP_TO_ENTITY_EQ_ID;
    V_level_from                 NUMBER := PI_CRD_INFO(1).LEVELS_TO_RUP_FROM;
    V_aggregate_values           NUMBER := PI_RTE_INFO(1).Aggregate_Values;
    V_level_to                   NUMBER := PI_RTE_INFO(1).Levels_To_Rup_To;
    V_no_roll_up_table_columns   VARCHAR2(1300 CHAR) := NULL;
    V_no_match_table_columns     VARCHAR2(1300 CHAR) := NULL;
    V_is_effective_period        NUMBER := NULL;
    V_start_period_column        VARCHAR2(1300 CHAR) := NULL;
    V_end_period_column          VARCHAR2(1300 CHAR) := NULL;
    V_process_run_for            NUMBER := NULL;
    V_date_period_column         VARCHAR2(1300 CHAR) := NULL;
    V_new_date_period_column     VARCHAR2(1300 CHAR) := NULL;
    V_entity_roll_up_to_column   VARCHAR2(1300 CHAR) := 'E' || PI_RTE_INFO(1)
                                                       .ROLLUP_TO_ENTITY_BASE_ID;
    V_entity_roll_up_from_column VARCHAR2(1300 CHAR) := NULL;
    V_fields_columns             VARCHAR2(1300 CHAR);
    V_output_where_clause        clob := NULL;
    V_primary_table              VARCHAR2(1300 CHAR) := PI_RRT_INFO(1)
                                                        .Result_Table_Name;
    V_date_run_for               date := NULL;
    V_period_run_for             number := NULL;
    V_OPERATION_ID               NUMBER := 1;

    v_non_ent_col       VARCHAR2(1300 CHAR);
    v_non_ent_col_alias VARCHAR2(1300 CHAR);
    v_ent_col           VARCHAR2(1300 CHAR);
    v_ent_col_alias     VARCHAR2(1300 CHAR);

    v_nm_non_ent_col       VARCHAR2(1300 CHAR);
    v_nm_non_ent_col_alias VARCHAR2(1300 CHAR);
    v_nm_ent_col           VARCHAR2(1300 CHAR);
    v_nm_ent_col_alias     VARCHAR2(1300 CHAR);

    v_nr_non_ent_col       VARCHAR2(1300 CHAR);
    v_nr_non_ent_col_alias VARCHAR2(1300 CHAR);
    v_nr_ent_col           VARCHAR2(1300 CHAR);
    v_nr_ent_col_alias     VARCHAR2(1300 CHAR);
    sql_stmt               CLOB;

    v_tu_name_of_hierarchy varchar2(24 char);
  Begin
    Pout_No_Rollup_Rows := 0;
    Pout_No_Match_Rows  := 0;
    POUT_PRIMARY_ROWS   := 0;
    PO_STATUS           := 0;
    --

    if PI_HRD_INFO(1).RecordDatingOption = 5 then
      select tu_name
        into v_tu_name_of_hierarchy
        from time_units tu
       where tu.tu_id = PI_HRD_INFO(1).timeunit_id;
    /*  commons_utils.insert_logs('in crediting_rollup :----- timeunit name  ' ||
                                v_tu_name_of_hierarchy);

      commons_utils.insert_logs('select fld_column_name
     from fields f where f.fld_timeunit = ' || PI_HRD_INFO(1)
                                .timeunit_id || '
      and f.fld_business_name =''Start ' ||
                                v_tu_name_of_hierarchy || '''');*/

      execute immediate 'select fld_column_name
     from fields f where f.fld_timeunit = ' || PI_HRD_INFO(1)
                       .timeunit_id || '
      and f.fld_business_name =''Start ' ||
                        v_tu_name_of_hierarchy || ''''
        into V_start_period_column;

     /* commons_utils.insert_logs('select fld_column_name
     from fields f where f.fld_timeunit = ' || PI_HRD_INFO(1)
                                .timeunit_id || '
      and f.fld_business_name =''End ' ||
                                v_tu_name_of_hierarchy || '''');*/

      execute immediate 'select fld_column_name
     from fields f where f.fld_timeunit = ' || PI_HRD_INFO(1)
                       .timeunit_id || '
      and f.fld_business_name =''End ' ||
                        v_tu_name_of_hierarchy || ''''
        into V_end_period_column;

    elsif PI_HRD_INFO(1).RecordDatingOption = 4 then
      V_start_period_column := 'START_DATE';
      V_end_period_column   := 'END_DATE';
    else
      V_start_period_column := null;
      V_end_period_column   := null;
    end if;

    /*
    INSERT_LOGS('input 1-------------------PI_CRD_INFO-------------');
    if PI_CRD_INFO  is not null then
      for i in PI_CRD_INFO.first..PI_CRD_INFO.last
      loop
      INSERT_LOGS(rpad(i,5,' ')||'ROLLUP_FROM_ENTITY_BASE_ID'||rpad(PI_CRD_INFO(i).ROLLUP_FROM_ENTITY_BASE_ID,10,' ')||'ROLLUP_FROM_ENTITY_EQ_ID'||rpad(PI_CRD_INFO(i).ROLLUP_FROM_ENTITY_EQ_ID,10,' ')||
      'LEVELS_TO_RUP_FROM'||rpad(PI_CRD_INFO(i).LEVELS_TO_RUP_FROM,10,' ')||'INCLUDE_UMATCH_RESULT'||rpad(PI_CRD_INFO(i).INCLUDE_UMATCH_RESULT,10,' ')||
      'RECORD_BASED_ON_OPTION'||rpad(PI_CRD_INFO(i).RECORD_BASED_ON_OPTION,10,' ')||'RECORDS_TO_USE_OPTION'||rpad(PI_CRD_INFO(i).RECORDS_TO_USE_OPTION,10,' ')||
      'RECORDS_BETWEEN_OPTION'||rpad(PI_CRD_INFO(i).RECORDS_BETWEEN_OPTION,10,' ')||'Field_To_Match'||rpad(PI_CRD_INFO(i).Field_To_Match,30,' '));
      end loop;
    end if;



    if PI_CRT_INFO is not null then
    commons_utils.insert_logs('input 2 =--------------------------COLTYPE_CRT_INFO===================');
    for i in PI_CRT_INFO.first..PI_CRT_INFO.last
    loop
    commons_utils.insert_logs(rpad(i,5,' ')||'CRT_NAME'||rpad(PI_CRT_INFO(i).CRT_NAME,30,' ')||'CRT_DATE_OR_PERIOD_OPTION'||rpad(PI_CRT_INFO(i).CRT_DATE_OR_PERIOD_OPTION,5,' ')||
    'CRT_START_COLUMN_NAME'||rpad(PI_CRT_INFO(i).CRT_START_COLUMN_NAME,30,' ')||'CRT_END_COLUMN_NAME'||rpad(PI_CRT_INFO(i).CRT_END_COLUMN_NAME,30,' ')||'CRT_IS_EFFECTIVE'||rpad(PI_CRT_INFO(i).CRT_IS_EFFECTIVE,5,' '));
    end loop;
    end if;



    if PI_RTE_INFO is not null then
    commons_utils.insert_logs('input 3 ----------------PI_RTE_INFO--------------');
    for i in PI_RTE_INFO.first..PI_RTE_INFO.last
    loop
        commons_utils.insert_logs(rpad(i,5,' ')||'ROLLUP_TO_ENTITY_BASE_ID'||rpad(PI_RTE_INFO(i).ROLLUP_TO_ENTITY_BASE_ID,10,' ')||'ROLLUP_TO_ENTITY_EQ_ID'||rpad(PI_RTE_INFO(i).ROLLUP_TO_ENTITY_EQ_ID,10,' ')||
      'Levels_To_Rup_To'||rpad(PI_RTE_INFO(i).Levels_To_Rup_To,5,' ')||'Aggregate_Values'||rpad(PI_RTE_INFO(i).Aggregate_Values,5,' ')||
      'INCLUDE_NO_RUP_RESULT'||rpad(PI_RTE_INFO(i).INCLUDE_NO_RUP_RESULT,5,' '));
     end loop;
     end if;




     if PI_HRD_INFO is not null then
     commons_utils.insert_logs(' input 4 ------------------PI_HRD_INFO-------------');
     for i in PI_HRD_INFO.first..PI_HRD_INFO.last
     loop
     commons_utils.insert_logs(rpad(i,5,' ')||'Relationship_Table_Name'||rpad(PI_HRD_INFO(i).Relationship_Table_Name,30,' ')||'Upper_Entity_Id'||rpad(PI_HRD_INFO(i).Upper_Entity_Id,10,' ')||
     'Lower_Entity_Id'||rpad(PI_HRD_INFO(i).Lower_Entity_Id,10,' ')||'Upper_Column_Name'||rpad(PI_HRD_INFO(i).Upper_Column_Name,30,' ')||'lower_column_name'||rpad(PI_HRD_INFO(i).lower_column_name,30,' '));
     end loop;
     end if;


    if PI_FTR_INFO is not null then
     commons_utils.insert_logs(' input 5 ------------------PI_FTR_INFO-------------');
     for i in PI_FTR_INFO.first..PI_FTR_INFO.last
     loop
     commons_utils.insert_logs(rpad(i,5,' ')||'Field_Business_Name'||rpad(PI_FTR_INFO(i).Field_Business_Name,30,' ')||'Column_Names_In_Crt'||rpad(PI_FTR_INFO(i).Column_Names_In_Crt,10,' ')||
     'decimal_length'||rpad(PI_FTR_INFO(i).decimal_length,10,' '));
     end loop;
     end if;



    if PI_RRT_INFO is not null then
     commons_utils.insert_logs(' input 6 ------------------PI_RRT_INFO-------------');
     for i in PI_RRT_INFO.first..PI_RRT_INFO.last
     loop
     commons_utils.insert_logs(rpad(i,5,' ')||'Result_Table_Name'||rpad(PI_RRT_INFO(i).Result_Table_Name,30,' ')||'nonTechnical_Column_Names'||to_char(PI_RRT_INFO(i).nonTechnical_Column_Names));
     end loop;
    end if;



    if PI_NRT_INFO is not null then
     commons_utils.insert_logs(' input 7 ------------------PI_NRT_INFO-------------');
     for i in PI_NRT_INFO.first..PI_NRT_INFO.last
     loop
     commons_utils.insert_logs(rpad(i,5,' ')||'Result_Table_Name'||rpad(PI_NRT_INFO(i).Result_Table_Name,30,' ')||'nonTechnical_Column_Names'||to_char(PI_NRT_INFO(i).nonTechnical_Column_Names));
     end loop;
     end if;


     if PI_URT_INFO is not null then
     commons_utils.insert_logs(' input 8 ------------------PI_URT_INFO-------------');
     for i in PI_URT_INFO.first..PI_URT_INFO.last
     loop
     commons_utils.insert_logs(rpad(i,5,' ')||'Result_Table_Name'||rpad(PI_URT_INFO(i).Result_Table_Name,30,' ')||'nonTechnical_Column_Names'||to_char(PI_URT_INFO(i).nonTechnical_Column_Names));
     end loop;
     end if;
     */
    ----------

    /*   select listagg(decode(e.entity_id, null, tc.tc_physical_name), ',') within group(order by tc.tc_physical_name) non_ent_col,
           listagg(decode(e.entity_id, null, null, tc.tc_physical_name), ',') within group(order by tc.tc_physical_name) ent_col,
           listagg(decode(e.entity_id,
                          null,
                          null,
                          ('C_' ||
                          RPAD('0_', LENGTH('0_') * TC_COLUMN_TYPE, '0_E') ||
                          e.entity_base_entity)),
                   ',') within group(order by tc.tc_physical_name) ent_col_alias
                   into v_non_ent_col, v_ent_col, v_ent_col_alias
      from table_columns tc
     inner join tables t
        on (tc.tc_tables_id = t.tables_id)
      left outer join entities e
        on (tc.tc_entity_id = e.entity_id)
     where tc.tc_physical_name in (to_char(''''||replace(pi_rrt_info(1).nonTechnical_Column_Names,',',''',''')||''''))--
       and t.tables_physical_name = pi_rrt_info(1).Result_Table_Name
       and tc.tc_physical_name not in ('E'||pi_rte_info(1).ROLLUP_TO_ENTITY_BASE_ID,pi_ftr_info(1).Column_Names_In_Crt)
       and ((tc.tc_column_type = 1 and
           entity_base_entity in (select cd.cde_entity_id
                                      from crediting_data_entities cd
                                     where cd.cde_crediting_id = 3507737
                                    union all
                                    select cf.caf_entity_id
                                      from crediting_additional_fields cf
                                     where cf.caf_crediting_id = 3507737
                                    union all
                                    select pi_crd_info(1).ROLLUP_FROM_ENTITY_BASE_ID
                                      from dual) or
           entity_id in (select cd.cde_entity_id
                             from crediting_data_entities cd
                            where cd.cde_crediting_id = 3507737
                           union all
                           select cf.caf_entity_id
                             from crediting_additional_fields cf
                            where cf.caf_crediting_id = 3507737
                           union all
                           select pi_crd_info(1).ROLLUP_FROM_ENTITY_BASE_ID
                             from dual)) or tc.tc_column_type <> 1);
    */
    sql_stmt := 'select listagg(decode(e.entity_id, null, tc.tc_physical_name), '','') within group(order by tc.tc_physical_name) non_ent_col,
       listagg(decode(e.entity_id,
                      null,
                      (''C_'' ||
                      RPAD(''0_'', LENGTH(''0_'') * TC_COLUMN_TYPE, ''0_'') ||
                      tc.tc_physical_name)),
                      '','') within group(order by tc.tc_physical_name) non_ent_col_alias,
       listagg(decode(e.entity_id, null, null, tc.tc_physical_name), '','') within group(order by tc.tc_physical_name) ent_col,
       listagg(decode(e.entity_id,
                      null,
                      null,
                      (''C_'' ||
                      RPAD(''0_'', LENGTH(''0_'') * TC_COLUMN_TYPE, ''0_'') ||
                      ''E''||nvl(e.entity_base_entity,e.entity_id))),
               '','') within group(order by tc.tc_physical_name) ent_col_alias
  from table_columns tc
 inner join tables t
    on (tc.tc_tables_id = t.tables_id)
  left outer join entities e
    on (tc.tc_entity_id = e.entity_id)
 where tc.tc_physical_name in (' ||
                to_char('''' ||
                        replace(pi_rrt_info(1).nonTechnical_Column_Names,
                                ',',
                                ''',''') || '''') || ')--
   and t.tables_physical_name = ''' || pi_rrt_info(1)
               .Result_Table_Name || '''
   and tc.tc_physical_name not in (''' || 'E' || pi_rte_info(1)
               .ROLLUP_TO_ENTITY_BASE_ID || '''/*,''' || pi_ftr_info(1)
               .Column_Names_In_Crt || '''*/)
   and ((tc.tc_column_type = 1 and
       entity_base_entity in (select cd.cde_entity_id
                                  from crediting_data_entities cd
                                 where cd.cde_crediting_id =' ||
                PI_CREDITING_ID || '
                                union all
                                select cf.caf_entity_id
                                  from crediting_additional_fields cf
                                 where cf.caf_crediting_id = ' ||
                PI_CREDITING_ID || '
                                union all
                                select ' || pi_crd_info(1)
               .ROLLUP_FROM_ENTITY_BASE_ID || '
                                  from dual) or
       entity_id in (select cd.cde_entity_id
                         from crediting_data_entities cd
                        where cd.cde_crediting_id = ' ||
                PI_CREDITING_ID || '
                       union all
                       select cf.caf_entity_id
                         from crediting_additional_fields cf
                        where cf.caf_crediting_id = ' ||
                PI_CREDITING_ID || '
                       union all
                       select ' || pi_crd_info(1)
               .ROLLUP_FROM_ENTITY_BASE_ID || '
                         from dual)) or tc.tc_column_type <> 1)';

    /*commons_utils.insert_logs('sql_stmt=' || sql_stmt);*/

    execute immediate sql_stmt
      into v_non_ent_col, v_non_ent_col_alias, v_ent_col, v_ent_col_alias;

    --URT

    if PI_URT_INFO is not null then
      sql_stmt := 'select listagg(decode(e.entity_id, null, tc.tc_physical_name), '','') within group(order by tc.tc_physical_name) non_ent_col,
       listagg(decode(e.entity_id,
                      null,
                      (''C_'' ||
                      RPAD(''0_'', LENGTH(''0_'') * TC_COLUMN_TYPE, ''0_'') ||
                      tc.tc_physical_name)),
                      '','') within group(order by tc.tc_physical_name) non_ent_col_alias,
       listagg(decode(e.entity_id, null, null, tc.tc_physical_name), '','') within group(order by tc.tc_physical_name) ent_col,
       listagg(decode(e.entity_id,
                      null,
                      null,
                      (''C_'' ||
                      RPAD(''0_'', LENGTH(''0_'') * TC_COLUMN_TYPE, ''0_'') ||
                      ''E''||nvl(e.entity_base_entity,e.entity_id))),
               '','') within group(order by tc.tc_physical_name) ent_col_alias
  from table_columns tc
 inner join tables t
    on (tc.tc_tables_id = t.tables_id)
  left outer join entities e
    on (tc.tc_entity_id = e.entity_id)
 where tc.tc_physical_name in (' ||
                  to_char('''' ||
                          replace(PI_URT_INFO(1).nonTechnical_Column_Names,
                                  ',',
                                  ''',''') || '''') || ')--
   and t.tables_physical_name = ''' || PI_URT_INFO(1)
                 .Result_Table_Name ||  ''''||case when pi_rte_info(1).Aggregate_Values=0 then
  ' and tc.tc_physical_name not in (''' || 'E' || pi_rte_info(1)
                 .ROLLUP_TO_ENTITY_BASE_ID || ' ''/*,''' || pi_ftr_info(1)
                 .Column_Names_In_Crt ||
                  '''*/)' end||'
   and ((tc.tc_column_type = 1 and
       entity_base_entity in (select cd.cde_entity_id
                                  from crediting_data_entities cd
                                 where cd.cde_crediting_id = ' ||
                  PI_CREDITING_ID || '
                                union all
                                select cf.caf_entity_id
                                  from crediting_additional_fields cf
                                 where cf.caf_crediting_id = ' ||
                  PI_CREDITING_ID || '
                                union all
                                select ' || pi_crd_info(1)
                 .ROLLUP_FROM_ENTITY_BASE_ID || '
                                  from dual) or
       entity_id in (select cd.cde_entity_id
                         from crediting_data_entities cd
                        where cd.cde_crediting_id = ' ||
                  PI_CREDITING_ID || '
                       union all
                       select cf.caf_entity_id
                         from crediting_additional_fields cf
                        where cf.caf_crediting_id = ' ||
                  PI_CREDITING_ID || '
                       union all
                       select ' || pi_crd_info(1)
                 .ROLLUP_FROM_ENTITY_BASE_ID || '
                         from dual)) or tc.tc_column_type <> 1)';

      --   commons_utils.insert_logs('sql_stmt='||sql_stmt);

      execute immediate sql_stmt
        into v_nm_non_ent_col, v_nm_non_ent_col_alias, v_nm_ent_col, v_nm_ent_col_alias;

    end if;

    --NRT

    if PI_NRT_INFO is not null then

      sql_stmt := 'select listagg(decode(e.entity_id, null, tc.tc_physical_name), '','') within group(order by tc.tc_physical_name) non_ent_col,
       listagg(decode(e.entity_id,
                      null,
                      (''C_'' ||
                      RPAD(''0_'', LENGTH(''0_'') * TC_COLUMN_TYPE, ''0_'') ||
                      tc.tc_physical_name)),
                      '','') within group(order by tc.tc_physical_name) non_ent_col_alias,
       listagg(decode(e.entity_id, null, null, tc.tc_physical_name), '','') within group(order by tc.tc_physical_name) ent_col,
       listagg(decode(e.entity_id,
                      null,
                      null,
                      (''C_'' ||
                      RPAD(''0_'', LENGTH(''0_'') * TC_COLUMN_TYPE, ''0_'') ||
                      ''E''||nvl(e.entity_base_entity,e.entity_id))),
               '','') within group(order by tc.tc_physical_name) ent_col_alias
  from table_columns tc
 inner join tables t
    on (tc.tc_tables_id = t.tables_id)
  left outer join entities e
    on (tc.tc_entity_id = e.entity_id)
 where tc.tc_physical_name in (' ||
                  to_char('''' ||
                          replace(PI_NRT_INFO(1).nonTechnical_Column_Names,
                                  ',',
                                  ''',''') || '''') || ')--
   and t.tables_physical_name = ''' || PI_NRT_INFO(1)
                 .Result_Table_Name || ''''||case when pi_rte_info(1).Aggregate_Values=0 then
  ' and tc.tc_physical_name not in (''' || 'E' || pi_rte_info(1)
                 .ROLLUP_TO_ENTITY_BASE_ID || ' ''/*,''' || pi_ftr_info(1)
                 .Column_Names_In_Crt ||
                  '''*/)' end||'
   and ((tc.tc_column_type = 1 and
       entity_base_entity in (select cd.cde_entity_id
                                  from crediting_data_entities cd
                                 where cd.cde_crediting_id = ' ||
                  PI_CREDITING_ID || '
                                union all
                                select cf.caf_entity_id
                                  from crediting_additional_fields cf
                                 where cf.caf_crediting_id = ' ||
                  PI_CREDITING_ID || '
                                union all
                                select ' || pi_crd_info(1)
                 .ROLLUP_FROM_ENTITY_BASE_ID || '
                                  from dual) or
       entity_id in (select cd.cde_entity_id
                         from crediting_data_entities cd
                        where cd.cde_crediting_id = ' ||
                  PI_CREDITING_ID || '
                       union all
                       select cf.caf_entity_id
                         from crediting_additional_fields cf
                        where cf.caf_crediting_id = ' ||
                  PI_CREDITING_ID || '
                       union all
                       select ' || pi_crd_info(1)
                 .ROLLUP_FROM_ENTITY_BASE_ID || '
                         from dual)) or tc.tc_column_type <> 1)';

     /* commons_utils.insert_logs('sql_stmt=' || sql_stmt);*/

      execute immediate sql_stmt
        into v_nr_non_ent_col, v_nr_non_ent_col_alias, v_nr_ent_col, v_nr_ent_col_alias;

    end if;

 /*   commons_utils.insert_logs('v_non_ent_col=' || v_nr_non_ent_col);
    commons_utils.insert_logs('v_ent_col=' || v_nr_ent_col);*/
    -- commons_utils.insert_logs('v_ent_col_alias='||v_nr_ent_col_alias);
    -- commons_utils.insert_logs('ntcols='||to_char(''''||replace(PI_NRT_INFO(1).nonTechnical_Column_Names,',',''',''')||''''));

    SELECT OBJTYPE_RELATIONSHIP_TABLE(Relationship_Table_Name,
                                      Upper_Entity_Id,
                                      Lower_Entity_Id,
                                      Upper_Column_Name,
                                      Lower_column_name) BULK COLLECT
      INTO V_relationship_tables
      FROM TABLE(PI_HRD_INFO);

/*    -- Column_Names_In_Crt from TABLE(PI_FTR_INFO)
    SELECT LISTAGG(Column_Names_In_Crt, ',') WITHIN GROUP(ORDER BY NULL) fields_columns,
           ('C_0_ROW_IDENTIFIER,' ||
           LISTAGG(('C_0_0_' || Column_Names_In_Crt), ',') WITHIN
            GROUP(ORDER BY NULL)) rollup_alias_columns
      INTO V_fields_columns, V_rollup_alias_columns
      FROM TABLE(PI_FTR_INFO);*/

 if pi_rte_info(1).Aggregate_Values=0 then
 execute immediate'
 SELECT LISTAGG(Column_Names_In_Crt, '','') WITHIN GROUP(ORDER BY NULL) fields_columns,
           (''C_0_ROW_IDENTIFIER,'' ||
           LISTAGG((''C_0_0_'' || Column_Names_In_Crt), '','') WITHIN
            GROUP(ORDER BY NULL)) rollup_alias_columns

      FROM TABLE(:1)
      where column_Names_In_Crt not in
       ('''||
                   replace(pi_rrt_info(1).nonTechnical_Column_Names,
                                ',',
                                ''',''') ||''')'
      into V_fields_columns, V_rollup_alias_columns using PI_FTR_INFO  ;
     elsif pi_rte_info(1).Aggregate_Values=1 then
       SELECT LISTAGG(Column_Names_In_Crt, ',') WITHIN GROUP(ORDER BY NULL) fields_columns,
           ('C_0_ROW_IDENTIFIER,' ||
           LISTAGG(('C_0_0_' || Column_Names_In_Crt), ',') WITHIN
            GROUP(ORDER BY NULL)) rollup_alias_columns
      INTO V_fields_columns, V_rollup_alias_columns
      FROM TABLE(PI_FTR_INFO);

     end if;


    --
   WITH C AS
 (SELECT LISTAGG((' T_0_0.' || TC_PHYSICAL_NAME || ' C_' ||
                 RPAD('0_', LENGTH('0_') * TC_COLUMN_TYPE, '0_') ||
                 TC_PHYSICAL_NAME),
                 ',') WITHIN GROUP(ORDER BY order_by) inputview_cols_n_aliases,
         LISTAGG(('C_' || RPAD('0_', LENGTH('0_') * TC_COLUMN_TYPE, '0_') ||
                 TC_PHYSICAL_NAME),
                 ',') WITHIN GROUP(ORDER BY order_by) inputview_columns
  /* FROM TABLE_COLUMNS TC
  INNER JOIN TABLES T
     ON (T.TABLES_ID = TC_TABLES_ID)
  WHERE TABLES_PHYSICAL_NAME = PI_CRT_INFO(1).CRT_NAME
    AND TC_COLUMN_TYPE <> 3*/
    from (select 'E' || to_char(PI_CRD_INFO(1).ROLLUP_FROM_ENTITY_BASE_ID) TC_PHYSICAL_NAME,
                 1 order_by,
                 1 TC_COLUMN_TYPE
            from dual
          union

          select TC_PHYSICAL_NAME, 2 order_by, TC_COLUMN_TYPE
            FROM TABLE_COLUMNS TC
           INNER JOIN TABLES T
              ON (T.TABLES_ID = TC_TABLES_ID)
           WHERE TABLES_PHYSICAL_NAME = PI_CRT_INFO(1).CRT_NAME
             AND TC_COLUMN_TYPE <> 3
             and TC_PHYSICAL_NAME <>
                 'E' ||  to_char(PI_CRD_INFO(1).ROLLUP_FROM_ENTITY_BASE_ID))

  )
SELECT ('SELECT  ' || C.inputview_cols_n_aliases ||
       ',T_0_0.ROW_IDENTIFIER C_0_ROW_IDENTIFIER FROM ' || PI_CRT_INFO(1)
       .CRT_NAME || ' T_0_0') inputview,
       C.inputview_columns
  INTO V_inputview, V_inputview_columns
  FROM C;
    -- Column_Names_In_Crt from TABLE(PI_NRT_INFO)
    IF PI_NRT_INFO IS NOT NULL THEN
      V_no_roll_up_table_columns := PI_NRT_INFO(1).Result_Table_Name || ',' || PI_NRT_INFO(1)
                                    .nonTechnical_Column_Names;
    END IF;

    -- Column_Names_In_Crt from TABLE(PI_URT_INFO)
    IF PI_URT_INFO IS NOT NULL THEN
      V_no_match_table_columns := PI_URT_INFO(1).Result_Table_Name || ',' || PI_URT_INFO(1)
                                  .nonTechnical_Column_Names;
    END IF;

    -- INSERT_LOGS ('IN CREDITING_ROLLUP -- V_inputview = ' ||V_inputview||' -- V_inputview_columns = '||V_inputview_columns||' -- V_rollup_alias_columns = '||V_rollup_alias_columns||' -- V_fields_columns = '||V_fields_columns);
  /*  commons_utils.insert_logs('pin_RECORDS_BETWEEN_OPTION   => ' || PI_CRD_INFO(1)
                              .RECORDS_BETWEEN_OPTION);
    commons_utils.insert_logs('Field_To_Match   => ' || PI_CRD_INFO(1)
                              .Field_To_Match);
    commons_utils.insert_logs('RECORD_BASED_ON_OPTION   => ' || PI_CRD_INFO(1)
                              .RECORD_BASED_ON_OPTION);*/
    -- Call final
    CREDITING.CR_ROLLUP(pin_inputview_columns          => V_inputview_columns, -- V_inputview_columns VARCHAR2 := NULL; --
                        pin_rollup_alias_columns       => V_rollup_alias_columns, -- V_rollup_alias_columns VARCHAR2 := NULL; --
                        pin_inputview_ent_fld          => V_inputview_ent_fld, -- V_inputview_ent_fld VARCHAR2 := NULL; --
                        pin_inputview                  => V_inputview, -- V_inputview clob := NULL; --
                        pin_relationship_tables        => V_relationship_tables, -- V_relationship_tables TABLETYPE_RELATIONSHIP_TABLES := TABLETYPE_RELATIONSHIP_TABLES(); --.
                        pin_levels_rolled_up_column    => V_levels_rolled_up_column, -- V_levels_rolled_up_column VARCHAR2 := NULL; --
                        pin_include_input_records      => V_include_input_records, -- V_include_input_records NUMBER := 1; --
                        pin_roll_up_from_type          => V_roll_up_from_type, -- V_roll_up_from_type NUMBER := 1; --
                        pin_roll_up_to_type            => V_roll_up_to_type, -- V_roll_up_to_type NUMBER := 1; --
                        pin_level_from                 => V_level_from, -- V_level_from NUMBER := 1; --
                        pin_aggregate_values           => V_aggregate_values, -- V_aggregate_values NUMBER := 0; --
                        pin_level_to                   => V_level_to, -- V_level_to NUMBER := 1; --
                        pin_no_roll_up_table_columns   => V_no_roll_up_table_columns, -- V_no_roll_up_table_columns VARCHAR2 := NULL;
                        pin_no_match_table_columns     => V_no_match_table_columns, -- V_no_match_table_columns VARCHAR2 := NULL;
                        pin_is_effective_period        => PI_HRD_INFO(1)
                                                          .RecordDatingOption, -- V_is_effective_period NUMBER := 0;
                        pin_start_period_column        => V_start_period_column, -- V_start_period_column VARCHAR2 := NULL;
                        pin_end_period_column          => V_end_period_column, -- V_end_period_column VARCHAR2 := NULL;
                        pin_process_run_for            => PI_CRD_INFO(1)
                                                          .RECORDS_BETWEEN_OPTION, -- V_process_run_for NUMBER := 0;
                        pin_RECORD_BASED_ON_OPTION     => PI_CRD_INFO(1)
                                                          .RECORD_BASED_ON_OPTION,
                        pin_RECORDS_BETWEEN_OPTION     => PI_CRD_INFO(1)
                                                          .RECORDS_BETWEEN_OPTION,
                        pin_Field_To_Match             => PI_CRD_INFO(1)
                                                          .Field_To_Match,
                                                          PIN_CRSTRUCT_TABLE=>PI_CRT_INFO(1).CRT_NAME,
                        pin_date_period_column         => V_date_period_column, -- V_date_period_column VARCHAR2 := NULL;
                        pin_new_date_period_column     => V_new_date_period_column, -- V_new_date_period_column VARCHAR2 := NULL;
                        pin_entity_roll_up_to_column   => V_entity_roll_up_to_column, -- V_entity_roll_up_to_column VARCHAR2 := NULL;
                        pin_entity_roll_up_from_column => V_entity_roll_up_from_column, -- V_entity_roll_up_from_column VARCHAR2 := NULL;
                        pin_fields_columns             => V_fields_columns, -- V_fields_columns varchar2 := NULL;
                        pin_output_where_clause        => V_output_where_clause, -- V_output_where_clause clob := NULL;
                        pin_primary_table              => V_primary_table, -- V_primary_table varchar2 := NULL;
                        pin_date_run_for               => pi_date_run_for, -- V_date_run_for date := NULL;
                        pin_period_run_for             => pi_period_run_for, -- V_period_run_for number := NULL;
                        pin_operation_id               => V_OPERATION_ID, -- V_OPERATION_ID NUMBER := 1;
                        pin_run_id                     => PI_RUN_ID,
                        pin_non_ent_col                => v_non_ent_col,
                        pin_non_ent_col_alias          => v_non_ent_col_alias,
                        pin_ent_col                    => v_ent_col,
                        pin_ent_col_alias              => v_ent_col_alias,
                        pin_nm_non_ent_col             => v_nm_non_ent_col,
                        pin_nm_non_ent_col_alias       => v_nm_non_ent_col_alias,
                        pin_nm_ent_col                 => v_nm_ent_col,
                        pin_nm_ent_col_alias           => v_nm_ent_col_alias,
                        pin_nr_non_ent_col             => v_nr_non_ent_col,
                        pin_nr_non_ent_col_alias       => v_nr_non_ent_col_alias,
                        pin_nr_ent_col                 => v_nr_ent_col,
                        pin_nr_ent_col_alias           => v_nr_ent_col_alias,
                        pout_primary_rows              => POUT_PRIMARY_ROWS,
                        pout_no_rollup_rows            => Pout_No_Rollup_Rows,
                        pout_no_match_rows             => Pout_No_Match_Rows);

    Pout_No_Rollup_Rows := NVL(Pout_No_Rollup_Rows, 0);
    Pout_No_Match_Rows  := NVL(Pout_No_Match_Rows, 0);
    POUT_PRIMARY_ROWS   := NVL(POUT_PRIMARY_ROWS, 0);

    PO_STATUS := 1;

  END CREDITING_ROLLUP;

END CREDITING;
/
