CREATE PACKAGE COMMONS_DATALOADPROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : dataloadprocessing-commons
  -- Requester      : Kalloli, Basavaraj
  -- Author         : Rohit, Maxim
  -- Reviewer       : Sharma, Pooja
  -- Review date    : 16-Feb-2012
  -- Description    : Pacakge holding Data laod processing related pieces
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- ***************** **************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  /*

    -- Author     : Maxim Rohit
    -- Create date: 16 Feb 2012
    -- Module     : dataloadprocessing-commons
    -- Description: Created the Aggregated/Non-Aggregated Qualifying Input(QI) from the dump table
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------

    -- Parameters:-
    -- IN Parameters
    pi_DUMP_TABLE           IN VARCHAR2,-- Dump table name

    pi_QI_TABLE             IN VARCHAR2,-- QI table name

    pi_KEY_COLUMNS          IN CLOB,--Comma separated list of key columns

    pi_DATA_COLUMNS         IN CLOB,--Comma separated list of data columns

    pi_START                IN VARCHAR2,--Start field

    pi_END                  IN VARCHAR2,--End field

    pi_RECORD_DATING_OPTION IN NUMBER,--record dating option

    pi_DATA_TABLE           IN VARCHAR2,--data table

    pi_IS_AUTO_VALUED       IN NUMBER,--is the table autovalued

    pi_AGGREGATION_RULE     IN TABLETYPE_NAME_MAP,--Column name to function mapping, for eg COL1=>LAST,COL2=>ADD

    pi_AGGREGATION_ORDER    IN VARCHAR2,--for excel and text =RECORD_NUMBER and INPUT_ORDER , for data table

    pi_ENTITY_COL_MAPPING   IN TABLETYPE_NAME_MAP,--entity business column to internal_id, for eg business_key_col=>inetrenal_id_col

    pi_PERIOD_COL_MAPPING   IN TABLETYPE_NAME_MAP --Period business column to period_range_id, for eg TU_period_name_col=>period_range_id




    -- OUT Parameters
    -- Po_data_tables            sys_refcursor




  */

 PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE          IN VARCHAR2,
                           pi_QI_TABLE            IN VARCHAR2,
                           pi_MODE                IN VARCHAR2, --1 insert, 2 update
                           pi_KEY_COLUMNS         IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_DEST_TABLE          IN VARCHAR2,
                           pi_IS_AUTO_VALUED      IN NUMBER,
                           pi_av_generated_by_sw  IN NUMBER,
                           pi_av_col_name         VARCHAR2,
                           pi_AGGREGATE           IN NUMBER,
                           pi_DATA_COLUMNS        IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER   IN VARCHAR2,
                           pi_WHERE_CONDITIONS    IN VARCHAR2,
                           PIO_DUPLICATE_TABLE    IN VARCHAR2,
                           pi_id_column_name      VARCHAR2 default null,
                           pi_version_column_name VARCHAR2 default null,

                                 PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null,
                                 PI_SEQ_USED_FOR_ID in varchar2 default null,
                                 PI_INPUT_COUNT in number default null);

PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE          IN VARCHAR2,
                           pi_QI_TABLE            IN VARCHAR2,
                           pi_MODE                IN VARCHAR2,
                           pi_KEY_COLUMNS         IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_DEST_TABLE          IN VARCHAR2,
                           pi_IS_AUTO_VALUED      IN NUMBER,
                           pi_av_generated_by_sw  IN NUMBER,
                           pi_av_col_name         VARCHAR2,
                           pi_AGGREGATE           IN NUMBER,
                           pi_DATA_COLUMNS        IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER   IN VARCHAR2,
                           pi_WHERE_CONDITIONS    IN VARCHAR2,
                           pi_id_column_name      VARCHAR2 default null,
                           pi_version_column_name VARCHAR2 default null,
                                 PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null,
                                 PI_SEQ_USED_FOR_ID in varchar2 default null,
                                 PI_INPUT_COUNT in number default null);

  Procedure  DL_QI_CREATION(pi_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                           pi_QI_TABLE               IN VARCHAR2, -- QI table name
                           pi_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_av_generated_by_sw     IN NUMBER, --auto-value column
                           pi_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                           pi_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER      IN VARCHAR2,
                           pi_WHERE_CONDITIONS       IN VARCHAR2, -- the where clause is needed to ignore the rejected records i.e the records failed the validations above.
                           pi_id_column_name         VARCHAR2,
                           pi_seq_used_for_id        VARCHAR2,
                           pi_version_column_name    VARCHAR2,
                           pi_ent_intern_id_col_name VARCHAR2,
                           pi_av_col_name            VARCHAR2,
                           po_row_id_max_value       out number,
                           po_COUNT                  out number,
                           po_av_count               out number,
                           PIO_DUPLICATE_TABLE       IN VARCHAR2,
                           pi_reset_sequence         in number default 0,

                                 PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null,
                                 PI_INPUT_COUNT in number default null/*,
                                 PI_SEQ_RESET_FLAG in number default 1*/);

  PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                           pi_QI_TABLE               IN VARCHAR2, -- QI table name
                           pi_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_av_generated_by_sw     IN NUMBER, --auto-value column
                           pi_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                           pi_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER      IN VARCHAR2,
                           pi_WHERE_CONDITIONS       IN VARCHAR2, -- the where clause is needed to ignore the rejected records i.e the records failed the validations above.
                           pi_id_column_name         VARCHAR2,
                           pi_seq_used_for_id        VARCHAR2,
                           pi_version_column_name    VARCHAR2,
                           pi_ent_intern_id_col_name VARCHAR2,
                           pi_av_col_name            VARCHAR2,
                           po_row_id_max_value       out number,
                           po_COUNT                  out number,
                           po_av_count               out number,
                           pi_reset_sequence         in number default 0,
                                 PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null,
                                 PI_INPUT_COUNT in number default null/*,
                                 PI_SEQ_RESET_FLAG in number default 1*/);

  PROCEDURE DUMP_TABLE_SEGREGATION(PIO_DUMP_TABLE        IN OUT VARCHAR2,
                                   PI_INTRANS_VALUE      IN NUMBER,
                                   PI_KEY_COLUMNS        IN CLOB,
                                   PI_DATA_COLUMNS       IN CLOB,
                                   PI_WHERE_CONDITIONS   IN VARCHAR2,
                                   PI_AGGREGATION_CLAUSE IN CLOB,
                                   PI_GROUP_BY_CLAUSE    IN CLOB,
                                   PI_AGGREGATION_ORDER  IN VARCHAR2,
                                   PIO_DUPLICATE_TABLE   IN  VARCHAR2 ,
                                   PI_AGREEGATE      IN NUMBER,
                                   PI_INPUT_COUNT      IN  NUMBER default null,
                   PO_STOP_FLAG      OUT NUMBER,
                     PI_ADD_LOG_INFO IN COLTYPE_KEY_VALUE default null
                                   );
  /*
    -- Author     : Rahul Sachan
    -- Create date: 28 June 2013
    -- Module     : dataloadprocessing-commons
    -- Description: Procedure to take the input as database link name and return the list of valid object for oracle table input in sys ref cursor.
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
    -- Parameters:-
    -- IN Parameters
    PI_DBLINK_NAME                VARCHAR2,-- Name of the db link.
    -- OUT Parameters
    PO_OBJECT_LIST                sys_refcursor
  */

  PROCEDURE DL_ORACLE_INPUT_GET_OBJECTS(PI_DBLINK_NAME IN VARCHAR2,
                                        PO_OBJECT_LIST OUT SYS_REFCURSOR);
  /*
    -- Author     : Rahul Sachan
    -- Create date: 28 June 2013
    -- Module     : dataloadprocessing-commons
    -- Description: Procedure to take the input as object name and db link name  for oracle table input and return the column list and column properties of the object in sys ref cursor.
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
    -- Parameters:-
    -- IN Parameters
    PI_DBLINK_NAME                VARCHAR2,-- Name of the db link.
    PI_OBJECT_NAME                VARCHAR2,-- Name of the valid object.
    -- OUT Parameters
    PO_COLUMN_LIST                sys_refcursor
  */
  PROCEDURE DL_ORACLE_INPUT_GET_COL_LIST(PI_OBJECT_NAME IN VARCHAR2,
                                         PI_DBLINK_NAME IN VARCHAR2,
                                         PO_COLUMN_LIST OUT SYS_REFCURSOR);

  /*
      -- Author     : Rahul Sachan
      -- Create date: 28 June 2013
      -- Module     : dataloadprocessing-commons
      -- Description: Procedure to take the input as object name and db link name  for oracle table input and return the column list and column properties of the object in sys ref cursor.
      -----**************************************************************************************------------------------
      -- Return : NA
      -----**************************************************************************************------------------------
      Sample call:-


  declare
    -- Non-scalar parameters require additional processing
    pi_key_columns        tabletype_dl_key_col_map := tableTYPE_DL_KEY_COL_MAP(OBJTYPE_DL_KEY_COL_MAP('E1885',
                                                                                                    'number(10)',
                                                                                                    0),
                                                                             OBJTYPE_DL_KEY_COL_MAP('F1879',
                                                                                                    'number(1)',
                                                                                                    1),
                                                                             OBJTYPE_DL_KEY_COL_MAP('F1883',
                                                                                                    'number(10)',
                                                                                                    0),
                                                                             OBJTYPE_DL_KEY_COL_MAP('F1801',
                                                                                                    'number(10)',
                                                                                                    0));
    pi_data_columns       tabletype_dl_data_col_map := tableTYPE_DL_DATA_COL_MAP(OBJTYPE_DL_DATA_COL_MAP('E1910',
                                                                                                       0,
                                                                                                       0,
                                                                                                       0,
                                                                                                       'NUMBER',
                                                                                                       0,
                                                                                                       1),
                                                                               OBJTYPE_DL_DATA_COL_MAP('F1876',
                                                                                                       3,
                                                                                                       2,
                                                                                                       1,
                                                                                                       'NUMBER',
                                                                                                       0,
                                                                                                       1));

    po_update_count       number;
    po_insert_count       number;
    po_closed_dates_count number;
    po_count              number;
    po_status             number;
  begin

  execute immediate '
  drop index DPBK_T2008';
  execute immediate '
  drop index DPPK_T2008';
    -- Call the procedure
    validationandposting(pi_dump_table                  => 'T2008_dump',
                         pi_key_columns                 => pi_key_columns,
                         pi_av_generated_by_sw          => 0,
                         pi_aggregate                   => 0,
                         pi_data_columns                => pi_data_columns,
                         pi_aggregation_order           => null,
                         pi_flt_join_conditions         => null,
                         pi_flt_where_conditions        => null,
                         pi_id_column_name              => 'ROW_IDENTIFIER',
                         pi_seq_used_for_id             => 'T2008' ||
                                                           '_ROW_IDENTIFIER_SEQ',
                         pi_version_column_name         => 'ROW_VERSION',
                         pi_ent_intern_id_col_name      => null,
                         pi_ent_seq_name                => null,
                         pi_av_col_name                 => null,
                         pi_process_id                  => 'dfdfsfddss',
                         pi_mode                        => 4,
                         pi_dest_table                  => 'T2008',
                         pi_dest_tables_id              => 2008,
                         pi_effective_start             => null,
                         pi_effective_end               => null,
                         pi_tu_id                       => null,
                         pi_tables_record_dating_option => 1,
                         po_update_count                => po_update_count,
                         po_insert_count                => po_insert_count,
                         po_closed_dates_count          => po_closed_dates_count,
                         po_count                       => po_count,
                         po_status                      => po_status,
             );
  end;


  */

  PROCEDURE ValidationAndPosting(PI_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                                 PI_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                                 PI_AV_GENERATED_BY_SW     IN NUMBER, --auto-value
                                 PI_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                                 PI_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                                 PI_AGGREGATION_ORDER      IN VARCHAR2,
                                 PI_FLT_JOIN_CONDITIONS    IN VARCHAR2,
                                 PI_FLT_WHERE_CONDITIONS   IN VARCHAR2,
                                 PI_ID_COLUMN_NAME         IN VARCHAR2,
                                 PI_SEQ_USED_FOR_ID        IN VARCHAR2,
                                 PI_VERSION_COLUMN_NAME    IN VARCHAR2,
                                 PI_ENT_INTERN_ID_COL_NAME IN VARCHAR2,
                                 pi_ent_seq_name           IN VARCHAR2,
                                 PI_AV_COL_NAME            IN VARCHAR2,
                                 /*   PO_ROW_ID_MAX_VALUE       OUT NUMBER,*/ ---in crete to be handled in teh dump table removing now
                                 /*    PO_AV_COUNT               OUT NUMBER,*/ ---to be set by sp hence removing
                                 pi_process_id     IN varchar2,
                                 PI_MODE           IN VARCHAR2, --1 insert, 2 update
                                 PI_DEST_TABLE     IN VARCHAR2,
                                 PI_DEST_TABLES_ID IN NUMBER,
                                 /* PI_INPUT_SIZE IN VARCHAR2,*/ --requireed in future , commented for now
                                 PI_Effective_Start IN VARCHAR2, --DON'T PASS IN KEY
                                 PI_Effective_End   IN VARCHAR2,
                                 /*   PI_Is_Period       IN number, --CAN BE CACULATED AS WELL*/
                                 PI_TU_ID                       IN NUMBER,
                                 PI_TABLES_RECORD_DATING_OPTION IN NUMBER,
                                 PI_DL_DEF_ID                   IN NUMBER,
                                 PI_INPUT_COUNT                 IN NUMBER DEFAULT NULL,
                                 PI_SOURCE_FILE_COUNT           IN NUMBER DEFAULT 1,
                 PI_RUN_ID              IN NUMBER DEFAULT NULL,
                                 po_update_count                OUT NUMBER,
                                 po_insert_count                OUT NUMBER,
                                 PO_closed_dates_Count          OUT NUMBER,
                                 PO_FILTER_COUNT                OUT NUMBER, --will be used in recrete mode
                                 po_status                      OUT NUMBER,
                                 po_QI_TABLE                    OUT VARCHAR2,
                 po_SHRINK_FLAG           OUT NUMBER,
                                 PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null,
                                 PI_SEQ_RESET_FLAG in number default 1);

PROCEDURE ValidationAndPosting(PI_DUMP_TABLE             IN VARCHAR2, -- Dump table name
             PI_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
             PI_AV_GENERATED_BY_SW     IN NUMBER, --auto-value
             PI_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
             PI_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
             PI_AGGREGATION_ORDER      IN VARCHAR2,
             PI_FLT_JOIN_CONDITIONS    IN VARCHAR2,
             PI_FLT_WHERE_CONDITIONS   IN VARCHAR2,
             PI_ID_COLUMN_NAME         IN VARCHAR2,
             PI_SEQ_USED_FOR_ID        IN VARCHAR2,
             PI_VERSION_COLUMN_NAME    IN VARCHAR2,
             PI_ENT_INTERN_ID_COL_NAME IN VARCHAR2,
             pi_ent_seq_name           IN VARCHAR2,
             PI_AV_COL_NAME            IN VARCHAR2,
             /*   PO_ROW_ID_MAX_VALUE       OUT NUMBER,*/ ---in crete to be handled in teh dump table removing now
             /*    PO_AV_COUNT               OUT NUMBER,*/ ---to be set by sp hence removing
             pi_process_id     IN varchar2,
             PI_MODE           IN VARCHAR2, --1 insert, 2 update
             PI_DEST_TABLE     IN VARCHAR2,
             PI_DEST_TABLES_ID IN NUMBER,
             /* PI_INPUT_SIZE IN VARCHAR2,*/ --requireed in future , commented for now
             PI_Effective_Start IN VARCHAR2, --DON'T PASS IN KEY
             PI_Effective_End   IN VARCHAR2,
             /*   PI_Is_Period       IN number, --CAN BE CACULATED AS WELL*/
             PI_TU_ID                       IN NUMBER,
             PI_TABLES_RECORD_DATING_OPTION IN NUMBER,
             PI_DL_DEF_ID                   IN NUMBER,
             PI_INPUT_COUNT                 IN NUMBER DEFAULT NULL,
             PI_SOURCE_FILE_COUNT           IN NUMBER DEFAULT 1,
             PI_RUN_ID              IN NUMBER DEFAULT NULL,
             po_update_count                OUT NUMBER,
             po_insert_count                OUT NUMBER,
             PO_closed_dates_Count          OUT NUMBER,
             PO_FILTER_COUNT                OUT NUMBER, --will be used in recrete mode
             po_status                      OUT NUMBER,
             po_QI_TABLE                    OUT VARCHAR2,
             po_SHRINK_FLAG           OUT NUMBER,
             PIO_DUPLICATE_TABLE     in  varchar2,
                           PI_OVERLAP_TABLE in varchar2 default null,
                                 PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null,
                                 PI_SEQ_RESET_FLAG in number default 1);

                                 PROCEDURE HIRARCHY_VIEW(pi_Dest_Table      IN VARCHAR2,
                                           pi_QI_Table        IN VARCHAR2,
                                           pi_view_name       IN VARCHAR2,
                                           pi_key_Fields      IN VARCHAR2,
                                           pi_DATA_Fields     IN VARCHAR2,
                                           PI_Effective_Start IN VARCHAR2,
                                           PI_Effective_End   IN VARCHAR2,
                                           PI_Is_Recreate     IN number,
                                           PI_Is_Period       IN number,
                                           PI_TU_ID           IN number);

    /*
    -- Author     : Garkar, Pramod
    -- Create date: 01 Aug 2014
    -- Module     : dataloadprocessing-commons
    -- Description: Procedure to set the row identifier offset value which will be used by parellel sql loader DL processes.
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
    -- Parameters:-
    -- IN Parameters
    PI_RUN_DATA_ID                NUMBER, -- Run Data Id.
    PI_RANGE                      NUMBER -- Number of row identifiers to be blocked.
    -- OUT Parameters
    PO_MAX_ROW_IDENTIFIER         NUMBER -- Maximum row idenfifier blocked (Inclusive).

    --Possible Exceptions :-
    ORA-20101 : Offset record for RUN_DATA_ID = [PI_RUN_DATA_ID] does not exist.

    --Example call:
    COMMONS_DATALOADPROCESSING.DL_SET_RUN_TIME_OFFSETS(12345,
                                                       1000,
                                                       v_MAX_ROW_IDENTIFIER);

  */

  PROCEDURE DL_SET_RUN_TIME_OFFSETS(PI_RUN_DATA_ID IN NUMBER,
                                    PI_RANGE IN NUMBER,
                                    PO_MAX_ROW_IDENTIFIER OUT NUMBER);


PROCEDURE COMMON_OVERLAP_NP_POST(pi_Dest_Table      IN VARCHAR2,
                                   pi_QI_Table        IN VARCHAR2,
                                   pi_key_Fields      IN VARCHAR2,
                                   pi_data_Fields     IN VARCHAR2 default null,
                                   PI_Effective_Start IN VARCHAR2,
                                   PI_Effective_End   IN VARCHAR2,
                                   PI_Is_Period       IN number,
                                   PI_TU_ID           IN number,
                                   PI_Is_Recreate     IN number,
                                   PI_TEMP_TABLE      IN VARCHAR2,
                                   PI_TEMP_COL        IN VARCHAR2,
                                   PI_MODE            IN varchar2,
                                   po_Overlap_Chk_Res OUT NUMBER,
                                   PI_INPUT_COUNT     IN NUMBER default null,
                                   PI_RUN_ID          IN NUMBER DEFAULT NULL,
                                   PI_OVERLAP_TABLE   IN Varchar2,
                                    PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null);

  -- *******************************    PUBLIC PROCEDURES END         *******************************
END COMMONS_DATALOADPROCESSING;
/
