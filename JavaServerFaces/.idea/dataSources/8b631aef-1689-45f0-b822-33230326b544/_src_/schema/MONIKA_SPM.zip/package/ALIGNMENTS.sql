CREATE PACKAGE ALIGNMENTS
AS
  -- --------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : alignments-commons
  -- Requester      : Sharma, Pooja
  -- Author         : Vijaywargiya, Abhishek
  -- Create date    : 11-Oct-2013
  -- Reviewer       : Rohit, Maxim
  -- Review date    :
  -- Description    : Package for Alignments
  --ls
  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : EVALUATE_ALIGNMENTS
    * AUTHOR            : Vijaywargiya, Abhishek
    * REVIEWER          : Rohit, Maxim
    * INPUT PARAMETERS  : ALIGNMENT_ENTITY_OBJECT       : Contains 1 record for Alignment Entity info
    *                     ALIGNED_ENTITIES_OBJECT       : Contains 1 record each for Aligned Entities info
    *                     CONDITIONS_OBJECT             : Contains 1 record each for All Conditions
    *                     FILTERS_OBJECT                : Contains 1 record each for All Filters
    *                     PI_ALIGNMENT_TABLE_NAME       : Alignment Table Name       - "T" table to be posted with all Valid Alignment records
    *                     PI_OVERLAPPING_TABLE_NAME     : Overlapping Table Name     - "T" table to be posted with all Overlapping records
    *                     PI_CONTRADICTORY_TABLE_NAME   : Contradictory Table Name   - "T" table to be posted with all Contradictory records
    *                     PI_DUAL_ALIGNMENTS_TABLE_NAME : Dual Alignments Table Name - "T" table to be posted with all Dual Alignments records
    * OUTPUT PARAMETERS : None
    * DESCRIPTION       : Evaluates the Alignments logic based on several conditions
    * Example           :
    BEGIN
        ALIGNMENTS.EVALUATE_ALIGNMENTS (
        PI_ALIGNMENT_ENTITY_OBJECT    ,
        PI_ALIGNED_ENTITIES_OBJECT    ,
        PI_CONDITIONS_OBJECT          ,
        PI_FILTERS_OBJECT             ,
        PI_ALIGNMENT_TABLE_NAME       ,
        PI_OVERLAPPING_TABLE_NAME     ,
        PI_CONTRADICTORY_TABLE_NAME   ,
        PI_DUAL_ALIGNMENTS_TABLE_NAME  );
    END;

    Evaluates the Alignment Logic based on the corresponding Alignment and Aligned Entities and the Conditions.
    *********************************************************************************************************************/

  PROCEDURE EVALUATE_ALIGNMENTS (PI_ALIGNMENT_ENTITY_OBJECT     IN COLTYPE_ALIGNMENT_ENTITY,
                                 PI_ALIGNED_ENTITIES_OBJECT     IN COLTYPE_ALIGNED_ENTITIES,
                                 PI_CONDITIONS_OBJECT           IN COLTYPE_ALIGNMENTS_CONDITIONS,
                                 PI_FILTERS_OBJECT              IN COLTYPE_ALIGNMENTS_FILTERS,
                                 PI_ALIGNMENT_TABLE_NAME        IN VARCHAR2,
                                 PI_OVERLAPPING_TABLE_NAME      IN VARCHAR2,
                                 PI_CONTRADICTORY_TABLE_NAME    IN VARCHAR2,
                                 PI_DUAL_ALIGNMENTS_TABLE_NAME  IN VARCHAR2);
END ALIGNMENTS;
/
