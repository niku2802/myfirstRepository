CREATE PACKAGE WORKFLOW_BUILDER AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: workflowmanagement
-- Module			: workflowbuilder
-- Requester		: Pantilimon, Narcisa
-- Author			: Dumitriu, Cosmin
-- Reviewer			:
-- Review date		:
-- Description		: Package that contains different utilities for workflowbuilder
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************




/*	PROCEDURE GET_WF_PROCESS_DIAGRAM
	========================================================
	Author		: Dumitriu, Cosmin
	Create date	: 2012.03.27
	Description	: This procedure will return the components of a given workflow process in the exact order in which they should be added in UI
	========================================================
	Parameters:
	 pi_wp_id		IN NUMBER
		- NOT NULL
		- id of the WORKFLOW_PROCESS that is being displayed

	,po_diagram		OUT SYS_REFCURSOR
		- NOT NULL
		- cursor returning the definition of the workflow diagram
		- members:
			* PARENT_OBJ_TYPE	- VARCHAR2 - NOT NULL - object type of the parent node. can be 'R' - base request, 'TA' - task assignment, 'A' - action
			* PARENT_OBJ_ID		- NUMBER - NULL - object ID of the parent node. It can be either an WTA_ID, WFA_ID or NULL when the parent is the request itself.
			* PARENT_OBJ_NAME	- VARCHAR2 - NULL - object name of the parent node.
			* CHILD_OBJ_TYPE	- VARCHAR2 - NOT NULL - object type of the child node. can be 'TA' - task assignment, 'A' - action
			* CHILD_OBJ_ID		- NUMBER - NOT NULL - object ID of the child node. It can be either an WTA_ID or WFA_ID.
			* CHILD_OBJ_NAME	- VARCHAR2 - NOT NULL - object name of the child node.
			* CHILD_OBJ_AVAILABILITY - NUMBER - NULL - if the child object is of type action then this will contain it's availability
			* CHILD_ORDER		- NUMBER - NOT NULL - order in which children nodes of the same parent are to be displayed from top to bottom.
			* WF_ORDER			- NUMBER - NOT NULL - order in which nodes are to be displayed in the diagram from left to right and top to bottom.
	========================================================*/
PROCEDURE GET_WF_PROCESS_DIAGRAM
(	 pi_wp_id		IN NUMBER
	,po_diagram		OUT SYS_REFCURSOR
);


/*	PROCEDURE GET_NODE_TA_PARENT_LIST
	========================================================
	Author		: Dumitriu, Cosmin
	Create date	: 2012.04.09
	Description	: This procedure will return all task assignments for all possible paths
				from the request root until a given node ID (action or task assignment)
	========================================================
	Parameters:
	 pi_wp_id		IN NUMBER
		- NOT NULL
		- id of the WORKFLOW_PROCESS that contains the node

	,pi_node_id		IN NUMBER
		- NOT NULL
		- id of the node selected (WFA_ID or WTA_ID)

	,pi_node_type	IN VARCHAR2
		- NOT NULL
		- type of the node selected ("A" - action, "TA" - task assignment)

	,po_ta_list		OUT SYS_REFCURSOR
		- NOT NULL
		- cursor returning the list of task assignments (in alphabetical order) and their corresponding actions
			on the path between the root and the selected node
		- members:
			* WTA_ID			- NUMBER - NOT NULL - ID of the "parent" task assignments
			* WTA_NAME			- VARCHAR2(250 CHAR) - NOT NULL - Name of the "parent" task assignments
			* WFA_ID			- NUMBER - NULL - ID of the action (in case an action is selected, then the last row will
									contain it's next task assignment with a NULL value for action ID)

	========================================================*/
PROCEDURE GET_NODE_TA_PARENT_LIST
(	 pi_wp_id		IN NUMBER
	,pi_node_id		IN NUMBER
	,pi_node_type	IN VARCHAR2
	,po_ta_list		OUT SYS_REFCURSOR
);

/*PROCEDURE GET_NODE_TA_PARENT_LIST
	========================================================
	Author		: Rohit,Maxim
	Create date	: 2014.01.
	Description	: This procedure create the re-routing entry.
	========================================================
Sample call:--
declare
po_status number;
po_returned_id number;
begin
  -- Call the procedure
  wf_re_routing_creation(pi_request_id =>4,
                         pi_request_table => 'request_t',
                         pi_task_id => 6,
                         pi_task_table => 'task_t',
                         pi_task_version => 1,
                         pi_re_reouting_table => 're_route_t',
                         pi_sender_comments => 'test',
                         pi_sender_user_id => 'Maxim',
                         pi_request_status_id => '5443',
                         pi_task_entity_cols => 'E385491,E384764',
                         pi_request_entity_cols => 'E384763,E385490',
                         po_status => po_status,
                         po_returned_id => po_returned_id);

                         dbms_output.put_line(po_returned_id);
                    dbms_output.put_line(po_status);
end;
*/
procedure WF_RE_ROUTING_CREATION(pi_request_id          in number,
                                                   pi_request_table       in varchar2,
                                                   pi_task_id             in number,
                                                   pi_task_table          in varchar2,
                                                   pi_task_version        in number,
                                                   pi_re_reouting_table   in varchar2,
                                                   pi_sender_comments     in varchar2,
                                                   pi_sender_user_id      in varchar2,
                                                   pi_request_status_id   in number,
                                                   pi_task_entity_cols    in varchar2,
                                                   pi_request_entity_cols in varchar2,
                                                   /*   pi_col_value         in COLTYPE_COL_VALUE,*/
                                                   po_status      out number,
                                                   po_returned_id out number);


/*	PROCEDURE UPDATE_REQUEST_TABLE
	========================================================
	Author		: Garkar, Pramod
	Create date	: 2014.10.28
	Description	: This procedure will update the request table data returning updated records from source table and non updated records.
	JIRA ID     : OF-21944 SP to update form fields of request records in processing
	========================================================
	Parameters:
		PI_REQ_UPDATE_PROCESS_ID  IN NUMBER
		- It will be process id mapped to WORKFLOW_AUTOMATION_PROCESS.WAP_ID

		PI_REQ_TO_INPUT_COL_MAP IN TABLETYPE_NAME_MAP
		- This will be collection containing pair of values (name1 and name2). name1 will be column name of request table to be updated and name2 will be value to be updated.

		PI_INPUT_TABLE_QUERY IN CLOB
		- will be a query to fetch records from input table which will be considered for updating corresponding records in request table. This query will be including join and filter condition on input table.

		PO_REQ_IDS_MATCHED OUT COLTYPE_ID
		- It will be collection of request ids returned by above query on input table which are updated (or matched to corresponding record in request table).

		PO_REQ_IDS_NOT_MATCHED OUT COLTYPE_ID
		- It will be collection of request ids returned by above query on input table which are not updated (or not matched to corresponding record in request table).

	    PO_STATUS OUT NUMBER
		- status will be 1 if procedure executes successfully, 2 if there are duplicate source record, 3 if entity doesn't exist, 4 if source is updated concurrently.

	========================================================*/

procedure UPDATE_REQUEST_TABLE( PI_REQ_UPDATE_PROCESS_ID  IN NUMBER,
                                PI_REQ_TO_INPUT_COL_MAP IN TABLETYPE_WF_COL_MAP,
                                PI_INPUT_TABLE_QUERY IN CLOB,
                                PI_REQ_ID_FLD_COLUMN_NAME IN VARCHAR2,
                                PO_REQ_IDS_MATCHED OUT COLTYPE_WF_ID,
                                PO_REQ_IDS_NOT_MATCHED OUT COLTYPE_WF_ID,
                                PO_MATCHED_RECORD_COUNT OUT NUMBER,
                                PO_MISMATCHED_RECORD_COUNT OUT NUMBER,
                                PO_STATUS OUT NUMBER);


/*PROCEDURE UPDATE_WORKFLOW_FIRST_LAST
  ========================================================
  Author    : Kristo,Robert
  Create date  : 2014.10.21
  Description  : This procedure populates the first and last task tables
  ========================================================
Sample call:--
begin
  -- Call the procedure
  UPDATE_WORKFLOW_FIRST_LAST(PIN_WP_ID =>4);
end;
*/
PROCEDURE UPDATE_WORKFLOW_FIRST_LAST(PIN_WP_ID  IN NUMBER);



/*PROCEDURE UPDATE_WORKFLOW_FIRST_LAST
  ========================================================
  Author       : Garkar, Pramod
  Create date  : 2015.12.30
  Description  : This procedure Updates the assocoated data record on action perform.
  ========================================================
Sample call:--
declare
v_action_ids COLTYPE_COMMON_ACTION_IDS;
begin
  v_action_ids := COLTYPE_COMMON_ACTION_IDS(11111,11112,11113);
  -- Call the procedure
  UPDATE_DATA_RECORD_ON_ACTION
          (
            PI_REQUEST_ID                => 22222,
            PI_COLTYPE_COMMON_ACTION_IDS => v_action_ids,
            PI_NAME_OF_TBL_TO_BE_UPDATED => 'T12345'
          );
end;
*/

PROCEDURE UPDATE_DATA_RECORD_ON_ACTION
          (
            PI_APPLICATION_ID IN NUMBER,
            PI_COLTYPE_ACTION_DETAILS IN COLTYPE_ACTION_DETAILS,
            PI_ID_OF_TABLE_TO_BE_UPDATED IN NUMBER,
            PO_STATUS OUT COLTYPE_STATUS_IDS,
            PO_ENTITY_VALIDATION  OUT NUMBER
          );

/*PROCEDURE PRC_WF_TASK_CREATION
	========================================================
	Description	: This procedure creates task records in task table
	========================================================
Sample call:--
declare

begin
  -- Call the procedure
  PRC_WF_TASK_CREATION(PI_TASK_NODE =>6323760,
                         PI_WA_ID => 6323552,
                         PI_ANH_CLAUSE => NULL,
                         PI_FIL_CONDITION => NULL,
                         PI_ET_CONDITION => NULL,
                         PI_ACT_TASK_NODE_ID => 6323752,
                         PI_TASK_REQ_ID => TABLETYPE_ID_ID((OBJTYPE_ID_ID(836, 267))),
                         PI_MAP_TASK_NODE_LST => COLTYPE_ID (6323752,6323694),
                         PI_IS_ASSO_MAPPED =>0,
                         PI_CNDT_JOIN_CLAUSE =>NULL,
                         PI_EXTERNAL_CNDT_JOIN_CLAUSE =>NULL );
end;
*/
PROCEDURE PRC_WF_TASK_CREATION(PI_TASK_NODE NUMBER,
                                                       PI_WA_ID NUMBER,
                                                       PI_ANH_CLAUSE CLOB DEFAULT NULL,
                                                       PI_FIL_CONDITION CLOB DEFAULT NULL,
                                                       PI_ET_CONDITION CLOB DEFAULT NULL,
                                                       PI_ACT_TASK_NODE_ID COLTYPE_ID DEFAULT NULL,
                                                       PI_TASK_REQ_ID TABLETYPE_ID_ID DEFAULT NULL,
                                                       PI_MAP_TASK_NODE_LST COLTYPE_ID DEFAULT NULL,
                                                       PI_IS_ASSO_MAPPED NUMBER DEFAULT NULL,
                                                       PI_CNDT_JOIN_CLAUSE CLOB DEFAULT NULL,
                                                       PI_EXTERNAL_CNDT_JOIN_CLAUSE CLOB DEFAULT NULL);



/*PROCEDURE PRC_TASK_REQUEST_INFO
	========================================================
	Description	: This procedure creates task records in task table
	========================================================
Sample call:--
DECLARE
  PI_REQ_TASK_COL TABLETYPE_ID_ID;
  PI_REQ_GTT_NAME VARCHAR2(200);
  PI_TASK_GTT_NAME VARCHAR2(200);
  PI_MAP_TASK_NODE COLTYPE_ID;
  PO_REQ_RID_LIST CLOB;
  PO_TR_QRY CLOB;
  PO_TN_QRY CLOB;
BEGIN
  -- Modify the code to initialize the variable
  -- PI_REQ_TASK_COL := NULL;
  PI_REQ_GTT_NAME := NULL;
  PI_TASK_GTT_NAME := NULL;
  PI_REQ_TASK_COL :=TABLETYPE_ID_ID((OBJTYPE_ID_ID(600, 219)));
  PI_REQ_GTT_NAME := 'REQ_GTT_6323552_BDIR';
  PI_TASK_GTT_NAME := 'TASK_GTT_6323552_BDIR';
 PI_MAP_TASK_NODE := coltype_id(6323760,6323752);

  WORKFLOW_BUILDER.PRC_TASK_REQUEST_INFO(
    PI_REQ_TASK_COL => PI_REQ_TASK_COL,
    PI_REQ_GTT_NAME => PI_REQ_GTT_NAME,
    PI_TASK_GTT_NAME => PI_TASK_GTT_NAME,
    PI_MAP_TASK_NODE => PI_MAP_TASK_NODE,
    PO_REQ_RID_LIST => PO_REQ_RID_LIST,
    PO_TR_QRY => PO_TR_QRY,
    PO_TN_QRY => PO_TN_QRY
  );
DBMS_OUTPUT.PUT_LINE('PO_REQ_RID_LIST = ' || PO_REQ_RID_LIST);

DBMS_OUTPUT.PUT_LINE('PO_TR_QRY = ' || PO_TR_QRY);

DBMS_OUTPUT.PUT_LINE('PO_TN_QRY = ' || PO_TN_QRY);
END;
*/
PROCEDURE PRC_TASK_REQUEST_INFO(PI_REQ_TASK_COL     IN  TABLETYPE_ID_ID,
                                PI_REQ_GTT_NAME     IN  VARCHAR2,
                                PI_TASK_GTT_NAME    IN  VARCHAR2,
                                PI_MAP_TASK_NODE    IN  COLTYPE_ID,
                                PO_REQ_RID_LIST     OUT CLOB,
                                PO_TR_QRY           OUT CLOB,
                                PO_TN_QRY           OUT CLOB
                               );
PROCEDURE PRC_ANH_ENT_FLD_RR_EVAL(PI_WTA_ID IN NUMBER,
                                      PI_ANH_CLAUSE IN CLOB,
                                      PI_ANH_DATE_CLS IN CLOB,
                                      PI_TASK_CREATION_SELECT IN CLOB,
                                      PI_WTA_ET_IS_EXT_TABLE IN NUMBER,
                                      PO_ENTITY_FILTER OUT CLOB,
                                      PO_ASSIGN_ENT OUT CLOB,
                                      PO_TASK_CREATION_SELECT OUT CLOB,
                                      PO_ENT_FLD_SELECT_CLAUSE OUT CLOB);

PROCEDURE PRC_ENT_FLD_RR_EVAL(PI_WTA_ID IN NUMBER,
                                      PI_ENT_INT_ID_CLAUSE IN CLOB,
                                      PO_ASSIGN_ENT OUT CLOB,
                                      PO_ENT_FLD_SELECT_CLAUSE OUT CLOB);
-- *******************************    PUBLIC PROCEDURES END         *******************************
END WORKFLOW_BUILDER;
/
