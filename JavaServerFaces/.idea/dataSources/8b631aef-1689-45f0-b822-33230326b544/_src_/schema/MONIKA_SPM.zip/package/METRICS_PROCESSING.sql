CREATE PACKAGE METRICS_PROCESSING AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type   : SPM
-- Product        : compensation
-- Module          : compensation-processing
-- Requester      : Homeuca, Victor
-- Author          : Hrubaru, Ionut
-- Create date  : 20110518
-- Reviewer        : Homeuca, Victor
-- Review date   :
-- Description   : package used to handle all operations for metrics processing
-- ---------------------------------------------------------------------------
      -- *******************************    PUBLIC TYPES START       *******************************
      -- *******************************    PUBLIC TYPES END         *******************************

      -- *******************************    PUBLIC CURSORS START       *******************************
      -- *******************************    PUBLIC CURSORS END         *******************************

      -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
   CANNOT_INSERT_NULL   EXCEPTION;
   PRAGMA EXCEPTION_INIT (CANNOT_INSERT_NULL,-1400);
   STEP_LOOKUP           CONSTANT PLS_INTEGER := 1;
   CONTINUOUS_LOOKUP     CONSTANT PLS_INTEGER := 2;
   DISCRETE_LOOKUP       CONSTANT PLS_INTEGER := 3;
      -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

      -- *******************************    PUBLIC FUNCTIONS START       *******************************


      -- *******************************    PUBLIC FUNCTIONS END         *******************************

      -- *******************************    PUBLIC PROCEDURES START       *******************************

  PROCEDURE Metric_Aggregates(pin_inputTable          in varchar2
                             ,pin_JoinedInput         in varchar2
                             ,pin_WhereClause         in varchar2
                             ,pin_EarningEntity       in TABLETYPE_NAME_MAP
                             ,pin_ColumnMapping       in TABLETYPE_NAME_MAP
                             ,pin_EntityMapping       in TABLETYPE_NAME_JOIN_MAP
                             ,pin_operationType       in number
                             ,pin_priorPeriodTable    IN VARCHAR2
                             ,pin_priorPeriodColumn   IN VARCHAR2
                             ,pin_projectedFlag       IN NUMBER
                             ,pin_baseLineTable       IN VARCHAR2
                             ,pin_priorPeriod         IN NUMBER
                             ,pin_calculationType     IN NUMBER
					                   ,pin_PriorPeriodFlag     IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                             ,pin_AggregatedField     in varchar2
                             );
--
  PROCEDURE METRICS_VALUES (pin_inputTable         IN VARCHAR2
                           ,pin_JoinedInput        IN VARCHAR2
                           ,pin_WhereClause        IN VARCHAR2
                           ,pin_EarningEntity      IN TABLETYPE_NAME_MAP
                           ,pin_ColumnMapping      IN TABLETYPE_NAME_MAP
                           ,pin_EntityMapping      IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_operationType      IN NUMBER
                           ,pin_priorPeriodTable   IN VARCHAR2
                           ,pin_priorPeriodColumn  IN VARCHAR2
                           ,pin_projectedFlag      IN NUMBER
                           ,pin_baseLineTable      IN VARCHAR2
                           ,pin_priorPeriod        IN NUMBER
                           ,pin_calculationType    IN NUMBER
                           ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                           ,pin_columnNames        IN VARCHAR2
);
--
  PROCEDURE METRIC_LOOKUP (pin_inputTable         IN VARCHAR2
                          ,pin_joinedInput        IN VARCHAR2
                          ,pin_whereClause        IN VARCHAR2
                          ,pin_earningEntity      IN TABLETYPE_NAME_MAP
                          ,pin_columnMapping      IN TABLETYPE_NAME_MAP
                          ,pin_entityMapping      IN TABLETYPE_NAME_JOIN_MAP
                          ,pin_operationType      IN NUMBER
                          ,pin_priorPeriodTable   IN VARCHAR2
                          ,pin_priorPeriodColumn  IN VARCHAR2
                          ,pin_projectedFlag      IN NUMBER
                          ,pin_baseLineTable      IN VARCHAR2
                          ,pin_priorPeriod        IN NUMBER
                          ,pin_calculationType    IN NUMBER
						              ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                          ,pin_lookupTable        IN VARCHAR2
                          ,pin_inputLookupColumn  IN VARCHAR2
                          ,pin_LessThanSmallest   IN NUMBER
                          ,pin_GreaterThanLargest IN NUMBER
                          ,pin_LookupWhereClause  in varchar2 default null
                          ,pin_LookupJoinClause   in varchar2 default null
                          ,pin_varyByFields       in varchar2 default null
                          ,pin_varyByRosterFields in varchar2 default null
                          ,pin_LookupEffProp      in TABLETYPE_DATE_RANGE_INTERNAL default null
                          ,pin_LookupPrecision    in number default null
                          );
--
   PROCEDURE METRIC_STATISTICS(pin_inputTable         IN VARCHAR2
                              ,pin_JoinedInput        IN VARCHAR2
                              ,pin_WhereClause        IN VARCHAR2
                              ,pin_EarningEntity      IN TABLETYPE_NAME_MAP
                              ,pin_ColumnMapping      IN TABLETYPE_NAME_MAP
                              ,pin_EntityMapping      IN TABLETYPE_NAME_JOIN_MAP
                              ,pin_operationType      IN NUMBER
                              ,pin_priorPeriodTable   IN VARCHAR2
                              ,pin_priorPeriodColumn  IN VARCHAR2
                              ,pin_projectedFlag      IN NUMBER
                              ,pin_baseLineTable      IN VARCHAR2
                              ,pin_priorPeriod        IN NUMBER
                              ,pin_calculationType    IN NUMBER
							                ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                              ,pin_distinctField      IN VARCHAR2
                              );
--
   PROCEDURE METRIC_RANKS (pin_inputTable         IN VARCHAR2
                          ,pin_joinedInput        IN VARCHAR2
                          ,pin_whereClause        IN VARCHAR2
                          ,pin_earningEntity      IN TABLETYPE_NAME_MAP
                          ,pin_columnMapping      IN TABLETYPE_NAME_MAP
                          ,pin_entityMapping      IN TABLETYPE_NAME_JOIN_MAP
                          ,pin_operationType      IN NUMBER
                          ,pin_priorPeriodTable   IN VARCHAR2
                          ,pin_priorPeriodColumn  IN VARCHAR2
                          ,pin_projectedFlag      IN NUMBER
                          ,pin_baseLineTable      IN VARCHAR2
                          ,pin_priorPeriod        IN NUMBER
                          ,pin_calculationType    IN NUMBER
                          ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
						              ,pin_rankField          IN VARCHAR2
                          ,pin_rankOrder          IN NUMBER
                          ,pin_groupByFields      IN VARCHAR2
                          ,pin_tieBreakField      IN VARCHAR2
                          ,pin_tieBreakRankOrder  IN NUMBER
                          ,pin_denseRank          IN NUMBER
                          );
--
   PROCEDURE METRIC_RATIOS (pin_inputTable1            IN VARCHAR2
                           ,pin_inputTable2            IN VARCHAR2
                           ,pin_joinedInput1           IN VARCHAR2
                           ,pin_joinedInput2           IN VARCHAR2
                           ,pin_whereClause1           IN VARCHAR2
                           ,pin_whereClause2           IN VARCHAR2
                           ,pin_earningEntity          IN TABLETYPE_NAME_MAP
                           ,pin_columnMapping          IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_entityMapping1         IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_entityMapping2         IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_operationType          IN NUMBER
                           ,pin_priorPeriodTable       IN VARCHAR2
                           ,pin_priorPeriodColumn      IN VARCHAR2
                           ,pin_projectedFlag          IN NUMBER
                           ,pin_baseLineTable          IN VARCHAR2
                           ,pin_priorPeriod            IN NUMBER
                           ,pin_calculationType        IN NUMBER
                           ,pin_PriorPeriodFlag        IN NUMBER
                           ,pin_BroaderFrequency       IN NUMBER
                           ,pin_BroaderFrequency2      IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInput2Constants  in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                           ,pin_numerator              IN VARCHAR2
                           ,pin_denominator            IN VARCHAR2
                           ,pin_numOperationType       IN NUMBER
                           ,pin_denOperationType       IN NUMBER
                           ,pin_plan_time_unit_id      IN NUMBER
                           ,pin_input1_time_unit_id    IN NUMBER
                           ,pin_input2_time_unit_id    IN NUMBER
                           ,pin_input1_period_field    IN VARCHAR2
                           ,pin_input2_period_field    IN VARCHAR2
                           ,pin_zero_attainment        IN NUMBER
                           );

    -- *******************************    PUBLIC PROCEDURES END         *******************************
END METRICS_PROCESSING;
/
