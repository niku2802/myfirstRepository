CREATE PACKAGE BODY ROLLUP_HIERARCHY AS

  -----------------------------------------------


      -- tabletype used

      TYPE RTYPE_COLUMN IS RECORD (
      COLUMN_NAME VARCHAR2(30),
      COLUMN_TYPE NUMBER);

      TYPE TABLETYPE_COLUMN IS TABLE OF RTYPE_COLUMN;
      V_ENTITY_IS_NUMBER    NUMBER(2);

      V_TX_ID               VARCHAR2(30);
      v_stamp               VARCHAR2(250);

      CON_DATE_FORMAT CONSTANT VARCHAR2(12) := '''mm/dd/yyyy''';
      CON_START_DATE  CONSTANT VARCHAR2(12) := '''01/01/1900''';
      CON_END_DATE    CONSTANT VARCHAR2(12) := '''12/31/9999''';

  ------------------------------------------------------


  FUNCTION IS_CORESP(pin_time_unit_id           IN NUMBER,
                     pin_hr_timeunit_id         IN NUMBER) RETURN BOOLEAN
  AS
     v_count NUMBER;
  BEGIN
     -- check for correspondence
     SELECT COUNT(*)
       INTO v_count
       FROM TU_CORRESPONDENCE
      WHERE TUC_TU_ID = pin_time_unit_id
        AND TUC_TU_ID_CORR = pin_hr_timeunit_id;

     IF v_count = 1 THEN
       RETURN TRUE;
     ELSE
       RETURN FALSE;
     END IF;
  END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

   PROCEDURE RETURN_TIME_UNITS(pin_date_period_column   IN VARCHAR2,
                               pin_start_period_column  IN VARCHAR2,

                               pio_time_unit_id         IN OUT NUMBER,
                               pio_hr_timeunit_id       IN OUT NUMBER)
   AS
   BEGIN
       -- select the time unit id of the input column
       SELECT FLD_TIMEUNIT
       INTO pio_TIME_UNIT_ID
       FROM FIELDS
       WHERE FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;

       -- select the time unit id of the hierarchy column
       SELECT FLD_TIMEUNIT
       INTO pio_HR_TIMEUNIT_ID
       FROM FIELDS
       WHERE FLD_COLUMN_NAME = pin_start_period_column AND ROWNUM = 1;
   EXCEPTION
     WHEN NO_DATA_FOUND
       THEN NULL;
   END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------


  FUNCTION GET_PERIODS_AND_CORESP(pin_date_period_column   IN VARCHAR2,
                                  pin_start_period_column  IN VARCHAR2,

                                  pout_time_unit            OUT NUMBER) RETURN BOOLEAN
  AS
     v_time_unit_id         NUMBER;
     v_hr_timeunit_id       NUMBER;
  BEGIN
     RETURN_TIME_UNITS(pin_date_period_column   => pin_date_period_column,
                       pin_start_period_column  => pin_start_period_column,

                       pio_time_unit_id         => v_time_unit_id,
                       pio_hr_timeunit_id       => v_hr_timeunit_id);

     pout_time_unit := v_hr_timeunit_id;

     RETURN IS_CORESP(v_hr_timeunit_id,
                      v_time_unit_id);
  END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------



   PROCEDURE CREATE_INDEX (pin_index IN CLOB)
   AS
   PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
     EXECUTE IMMEDIATE pin_index;
     COMMIT;
   END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

   PROCEDURE RETURN_CORRESP(pin_period_run_for          IN NUMBER,
                             pin_start_period_column    IN VARCHAR2,

                             pio_time_unit_id           IN OUT NUMBER,
                             pio_hr_timeunit_id         IN OUT NUMBER,
                             pio_corresp_RUN_FOR        IN OUT NUMBER)
    AS
       v_CORRESP NUMBER(10);
      BEGIN
       -- select the time unit id of the period for which the process is ran
       SELECT TU_PERIODS_RANGE.TUPR_TU_ID
       INTO pio_TIME_UNIT_ID
       FROM TU_PERIODS_RANGE
       WHERE TUPR_ID = pin_period_run_for;

       -- select the time unit id of the column
       SELECT FLD_TIMEUNIT
       INTO pio_HR_TIMEUNIT_ID
       FROM FIELDS
       WHERE FLD_COLUMN_NAME = pin_start_period_column AND ROWNUM = 1;

       IF (pio_TIME_UNIT_ID <> pio_HR_TIMEUNIT_ID) THEN
           -- check the correspondence of the time units
           SELECT COUNT(*)
           INTO v_CORRESP
           FROM TU_CORRESPONDENCE
           WHERE TUC_TU_ID = pio_TIME_UNIT_ID
           AND TUC_TU_ID_CORR = pio_HR_TIMEUNIT_ID;

           IF (v_CORRESP = 1) THEN
                -- get the corresponding period for which the process is ran
                WITH CORR AS
                 (SELECT TUC_TU_ID_CORR,
                         TUPR_ID,
                         TUPR_ID_CORR
                    FROM TU_CORR_MAT_VIEW)
                SELECT TUPR_ID_CORR
                  INTO pio_CORRESP_RUN_FOR
                  FROM CORR
                 WHERE TUPR_ID = pin_period_run_for
                   AND TUC_TU_ID_CORR = pio_HR_TIMEUNIT_ID;

            END IF;
      END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND
          THEN NULL;
      END;

  ----------
  ----------


    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

    FUNCTION RETURN_SELECT_IN(pin_process_run_for IN number,
                              pin_entity_col      IN varchar2,
                              pin_input_data      IN VARCHAR2)
    RETURN CLOB
    AS
    BEGIN
      -- case for the 4 kinds of process runs posibble

       CASE (pin_process_run_for)
         -- first day
         WHEN 0 THEN
           RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_input_data || ' INPUT_DATA) AND (INPUT_DATA.START_DATEE BETWEEN HIERARCHY_INPUT.START_DATE AND HIERARCHY_INPUT.END_DATE)';
         -- last day
         WHEN 1 THEN
           RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_INPUT_DATA || ' INPUT_DATA) AND (INPUT_DATA.END_DATEE BETWEEN HIERARCHY_INPUT.START_DATE AND HIERARCHY_INPUT.END_DATE)';
         -- any day
         WHEN 2 THEN
           RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_INPUT_DATA || ' INPUT_DATA) AND (INPUT_DATA.END_DATEE >= HIERARCHY_INPUT.START_DATE AND INPUT_DATA.START_DATEE <= HIERARCHY_INPUT.END_DATE)';
         -- all days
         WHEN 3 THEN
           RETURN '(SELECT ' || pin_entity_col || ' FROM ' || pin_INPUT_DATA || ' INPUT_DATA) AND (INPUT_DATA.START_DATEE >= HIERARCHY_INPUT.START_DATE AND INPUT_DATA.END_DATEE <= HIERARCHY_INPUT.END_DATE)';
         ELSE
           RETURN NULL;
       END CASE;
    END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

    PROCEDURE RETURN_SELECT_CONNECT_BY(pin_process_run_for IN NUMBER,

                                       pio_select          IN OUT NOCOPY CLOB)
    AS
    BEGIN
      -- case for the 4 kinds of process runs posibble
       CASE (pin_process_run_for)
         -- first day
         WHEN 0 THEN
           pio_select := pio_select || ' AND START_DATEE BETWEEN MAX_START_DATE AND MIN_END_DATE';
           -- last day
         WHEN 1 THEN
           pio_select := pio_select || ' AND END_DATEE BETWEEN MAX_START_DATE AND MIN_END_DATE';
           -- any day
         WHEN 2 THEN
           pio_select := pio_select || ' AND (START_DATEE <= MIN_END_DATE AND (END_DATEE >= MAX_START_DATE)
                            AND (MIN_END_DATE >= MAX_START_DATE))';
          -- all days
         WHEN 3 THEN
           pio_select := pio_select || ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
       ELSE
            NULL;
       END CASE;
    END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

    PROCEDURE RETURN_FILTER_NO(pin_process_run_for IN NUMBER,

                               pio_select          IN OUT NOCOPY CLOB)
    AS
    BEGIN
      -- case for the 4 kinds of process runs posibble
       CASE (pin_process_run_for)
         -- first day
         WHEN 0 THEN
           pio_select := pio_select || ' AND INPUT_DATA.START_DATEE BETWEEN HI.START_DATE AND HI.END_DATE';
           -- last day
         WHEN 1 THEN
           pio_select := pio_select || ' AND INPUT_DATA.END_DATEE BETWEEN HI.START_DATE AND HI.END_DATE';
           -- any day
         WHEN 2 THEN
           pio_select := pio_select || ' AND (INPUT_DATA.START_DATEE <= HI.END_DATE AND (INPUT_DATA.END_DATEE >= HI.START_DATE)
                            AND (HI.END_DATE >= HI.START_DATE))';
          -- all days
         WHEN 3 THEN
           pio_select := pio_select || ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
       ELSE
            NULL;
       END CASE;
    END;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

    FUNCTION CREATE_DATE_PERIOD_FILTER(pin_ENTITY_FIELD        IN BOOLEAN,
                                       pin_is_effective_period IN NUMBER,
                                       pin_process_run_for     IN NUMBER,
                                       pin_date_period_column  IN VARCHAR2,
                                       pin_start_period_column IN VARCHAR2
                                       )
    RETURN CLOB
    AS
      V_SELECT                         CLOB;
      v_corresp                        NUMBER(10);
      v_field_type                     NUMBER(10);
      v_time_unit_id                   NUMBER(10);
      v_hr_timeunit_id                 NUMBER(10);
    BEGIN

       BEGIN
         SELECT FIELDS.fld_data_type
         INTO V_FIELD_TYPE
         FROM FIELDS
         WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;
       EXCEPTION
         when OTHERS
           THEN NULL;
       END;
      IF (pin_ENTITY_FIELD) THEN
             CASE
                  -- if the run is made for a date and the hierarchy is date effective
                  WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN

                     V_SELECT := ' AND DATE_FIELD BETWEEN MAX_START_DATE AND MIN_END_DATE';
                   -- if the run is made for a period and the hierarchy is date effective
                   WHEN (pin_is_effective_period = 0) THEN
                     -- case for the 4 choices for the records to be selected
                     RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);
                  -- if the run is made for a period and the hierarchy is period effective
                  ELSE
                     -- select the time unit ids
                     RETURN_TIME_UNITS(pin_date_period_column,
                                       pin_start_period_column,
                                       v_time_unit_id,
                                       v_hr_timeunit_id);
                     -- if the run is made for the same periods or corresponding periods
                     IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
                         -- if the run is made for the same periods
                         V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
                     -- if the run is made for corresponding periods
                     ELSE
                         SELECT COUNT(*)
                         INTO v_corresp
                         FROM TU_CORRESPONDENCE
                         WHERE TUC_TU_ID = v_TIME_UNIT_ID
                         AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

                         IF (v_corresp = 1) THEN
                            -- if the used time unit corresponds
                            V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
                         ELSE
                            -- case for the 4 kinds of process runs posibble
                            RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);
                         END IF;
                     END IF;
               END CASE;
             ELSE
               CASE
                  -- if the run is made for a date and the hierarchy is date effective
                  WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
                     V_SELECT := ' AND DATE_FIELD BETWEEN MAX_START_DATE AND MIN_END_DATE';
                   -- if the run is made for a period and the hierarchy is date effective
                   WHEN (pin_is_effective_period = 0) THEN
                     -- case for the 4 choices for the records to be selected
                     RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);
                  -- if the run is made for a period and the hierarchy is period effective
                  ELSE
                     -- select the time unit ids
                     RETURN_TIME_UNITS(pin_date_period_column,
                                       pin_start_period_column,
                                       v_time_unit_id,
                                       v_hr_timeunit_id);
                     -- if the run is made for the same periods or corresponding periods
                     IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
                       -- if the run is made for the same periods
                         V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';
                     -- if the run is made for corresponding periods
                     ELSE
                         SELECT COUNT(*)
                         INTO v_corresp
                         FROM TU_CORRESPONDENCE
                         WHERE TUC_TU_ID = v_TIME_UNIT_ID
                         AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

                         IF (v_corresp = 1) THEN
                             -- if the used time unit corresponds
                             V_SELECT := ' AND START_DATEE >= MAX_START_DATE AND END_DATEE <= MIN_END_DATE';

                         ELSE
                            -- case for the 4 kinds of process runs posibble
                            RETURN_SELECT_CONNECT_BY(pin_process_run_for, V_SELECT);
                         END IF;
                     END IF;

                END CASE;
             END IF;

        -- return the value
        RETURN V_SELECT;
    END CREATE_DATE_PERIOD_FILTER;

    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

    FUNCTION CREATE_DATE_PERIOD_NO(pin_ENTITY_FIELD        IN BOOLEAN,
                                   pin_is_effective_period IN NUMBER,
                                   pin_process_run_for     IN NUMBER,
                                   pin_date_period_column  IN VARCHAR2,
                                   pin_start_period_column IN VARCHAR2
                                   )
    RETURN CLOB
    AS
      V_SELECT                     CLOB;
      v_corresp                    NUMBER(10);
      v_field_type                 NUMBER(10);
      v_time_unit_id               NUMBER(10);
      v_hr_timeunit_id             NUMBER(10);
    BEGIN

       BEGIN
         SELECT FIELDS.fld_data_type
         INTO V_FIELD_TYPE
         FROM FIELDS
         WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;
       EXCEPTION
         when OTHERS
           THEN NULL;
       END;
      IF (pin_ENTITY_FIELD) THEN
             CASE
                  -- if the run is made for a date and the hierarchy is date effective
                  WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN

                     V_SELECT := ' AND INPUT_DATA.DATE_FIELD BETWEEN HI.START_DATE AND HI.END_DATE';
                   -- if the run is made for a period and the hierarchy is date effective
                   WHEN (pin_is_effective_period = 0) THEN
                     -- case for the 4 choices for the records to be selected
                     RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
                  -- if the run is made for a period and the hierarchy is period effective
                  ELSE
                     -- select the time unit ids
                     RETURN_TIME_UNITS(pin_date_period_column,
                                       pin_start_period_column,
                                       v_time_unit_id,
                                       v_hr_timeunit_id);
                     -- if the run is made for the same periods or corresponding periods
                     IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
                         -- if the run is made for the same periods
                         V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
                     -- if the run is made for corresponding periods
                     ELSE
                         SELECT COUNT(*)
                         INTO v_corresp
                         FROM TU_CORRESPONDENCE
                         WHERE TUC_TU_ID = v_TIME_UNIT_ID
                         AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

                         IF (v_corresp = 1) THEN
                            -- if the used time unit corresponds
                            V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
                         ELSE
                            -- case for the 4 kinds of process runs posibble
                            RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
                         END IF;
                     END IF;
               END CASE;
             ELSE
               CASE
                  -- if the run is made for a date and the hierarchy is date effective
                  WHEN (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
                     V_SELECT := ' AND INPUT_DATA.DATE_FIELD BETWEEN HI.START_DATE AND HI.END_DATE';
                   -- if the run is made for a period and the hierarchy is date effective
                   WHEN (pin_is_effective_period = 0) THEN
                     -- case for the 4 choices for the records to be selected
                     RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
                  -- if the run is made for a period and the hierarchy is period effective
                  ELSE
                     -- select the time unit ids
                     RETURN_TIME_UNITS(pin_date_period_column,
                                       pin_start_period_column,
                                       v_time_unit_id,
                                       v_hr_timeunit_id);
                     -- if the run is made for the same periods or corresponding periods
                     IF (v_HR_TIMEUNIT_ID = v_TIME_UNIT_ID) THEN
                       -- if the run is made for the same periods
                         V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';
                     -- if the run is made for corresponding periods
                     ELSE
                         SELECT COUNT(*)
                         INTO v_corresp
                         FROM TU_CORRESPONDENCE
                         WHERE TUC_TU_ID = v_TIME_UNIT_ID
                         AND TUC_TU_ID_CORR = v_HR_TIMEUNIT_ID;

                         IF (v_corresp = 1) THEN
                             -- if the used time unit corresponds
                             V_SELECT := ' AND INPUT_DATA.START_DATEE >= HI.START_DATE AND INPUT_DATA.END_DATEE <= HI.END_DATE';

                         ELSE
                            -- case for the 4 kinds of process runs posibble
                            RETURN_FILTER_NO(pin_process_run_for, V_SELECT);
                         END IF;
                     END IF;

                END CASE;
             END IF;

        -- return the value
        RETURN V_SELECT;
    END CREATE_DATE_PERIOD_NO;


    -----------------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------------

    FUNCTION CREATE_HIERARCHY(
      pin_relationship_tables             IN TABLETYPE_RELATIONSHIP_TABLES,
      pin_start_period_column             IN varchar2,
      pin_end_period_column               IN varchar2
    )
    RETURN CLOB
    AS
           V_HIERARCHY CLOB;
    BEGIN
         -- if the hierarchy is date or period effective
         IF (pin_start_period_column IS NULL) THEN

             V_HIERARCHY := 'SELECT '
                  || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
                  ' AS ENT_LOWER, '
                  || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
                  ' AS ENT_UPPER, '
                  || PIN_RELATIONSHIP_TABLES(1).ENTITY_LOWER ||
                  ' AS ENT_LOWER_TYPE, '
                  || PIN_RELATIONSHIP_TABLES(1).ENTITY_UPPER ||
                  ' AS ENT_UPPER_TYPE FROM '
                  || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME;


            -- iterate the rest of the hierarchies

            FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST
              LOOP

                V_HIERARCHY := V_HIERARCHY ||
                  ' UNION SELECT '
                  || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
                  ', '
                  || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
                  ', '
                  || PIN_RELATIONSHIP_TABLES(I).ENTITY_LOWER ||
                  ', '
                  || PIN_RELATIONSHIP_TABLES(I).ENTITY_UPPER ||
                  ' FROM '
                  || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME;

              END LOOP;
        -- if the hierarchy is non effective
        ELSE

             V_HIERARCHY := 'SELECT '
                  || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
                  ' AS ENT_LOWER, '
                  || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
                  ' AS ENT_UPPER, '
                  || PIN_RELATIONSHIP_TABLES(1).ENTITY_LOWER ||
                  ' AS ENT_LOWER_TYPE, '
                  || PIN_RELATIONSHIP_TABLES(1).ENTITY_UPPER ||
                  ' AS ENT_UPPER_TYPE, '
                  || pin_start_period_column ||
                  ', '
                  || pin_end_period_column ||
                  ' FROM '
                  || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME;


            -- iterate the rest of the hierarchies

            FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST
              LOOP

                V_HIERARCHY := V_HIERARCHY ||
                  ' UNION ALL SELECT '
                  || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
                  ', '
                  || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
                  ', '
                  || PIN_RELATIONSHIP_TABLES(I).ENTITY_LOWER ||
                  ', '
                  || PIN_RELATIONSHIP_TABLES(I).ENTITY_UPPER ||
                  ', '
                  || pin_start_period_column ||
                  ', '
                  || pin_end_period_column ||
                  ' FROM '
                  || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME;

              END LOOP;


        END IF;

        RETURN V_HIERARCHY;
    END CREATE_HIERARCHY;


    ------------------------------------------------------------------------------------------------
    -----------------------------------------------------------------------------------------------
    PROCEDURE CREATE_HIERARCHY_INPUT(pin_is_effective_period          IN NUMBER,
                                     pin_date_period_column           IN VARCHAR2,
                                     pin_date_run_for                 IN DATE,
                                     pin_relationship_tables          IN TABLETYPE_RELATIONSHIP_TABLES,
                                     pin_process_run_for              IN NUMBER,
                                     pin_start_period_column          IN VARCHAR2,
                                     pin_end_period_column            IN VARCHAR2,
                                     pin_period_run_for               IN NUMBER,
                                     pin_run_id                       IN NUMBER,
                                     pin_operation_id                 IN NUMBER)
    AS

      CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI' || pin_run_id;
      V_START_DATE             DATE;
      V_END_DATE               DATE;
      V_CORRESP                NUMBER;
      V_CREATE_HTABLE          CLOB;
      V_SELECT_HINT            CLOB;
      v_hr_timeunit_id         NUMBER;
      v_time_unit_id           NUMBER;
      v_corresp_run_for        NUMBER;

    BEGIN
        -- add the hint framework
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_HIERARCHY_INPUT', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_HIERARCHY_INPUT', pin_operation_id);

        RETURN_CORRESP(pin_period_run_for,
                       pin_start_period_column,
                       v_TIME_UNIT_ID,
                       v_HR_TIMEUNIT_ID,
                       V_CORRESP_RUN_FOR);

        IF (V_CORRESP_RUN_FOR IS NULL) THEN
          V_CORRESP_RUN_FOR := pin_period_run_for;
        END IF;
      -- concatenate the with containing the hierarchy

        CASE (pin_is_effective_period)
          -- when the hierarchy is date effective
          WHEN 0 THEN
            IF (pin_date_period_column IS NULL) THEN
              v_create_htable :=
                      'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower FROM ('
                      || CREATE_HIERARCHY(pin_relationship_tables, 'START_DATE', 'END_DATE') ||
                      ')';
            ELSE
              v_create_htable :=
                      'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower, NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AS START_DATE, NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) AS END_DATE FROM ('
                      || CREATE_HIERARCHY(pin_relationship_tables, 'START_DATE', 'END_DATE') ||
                      ')';
            END IF;
          -- when the hierarchy is period effective
          WHEN 1 THEN
            IF (pin_date_period_column IS NULL) THEN
              v_create_htable :=
                      'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower FROM ('
                      || CREATE_HIERARCHY(pin_relationship_tables, pin_start_period_column, pin_end_period_column) ||
                      ')';
            ELSE
              v_create_htable :=
                      'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower, NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AS START_DATE, NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) AS END_DATE FROM ('
                      || CREATE_HIERARCHY(pin_relationship_tables, pin_start_period_column, pin_end_period_column) ||
                      ') LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                      || PIN_START_PERIOD_COLUMN ||
                      ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                      || PIN_END_PERIOD_COLUMN;
            END IF;
          -- when the hierarchy is not effective dated
          ELSE
            v_create_htable :=
                    'CREATE TABLE ' || CON_HIERARCHY_TABLE_NAME || ' TABLESPACE ' || USER || '_OUT AS (' || v_select_hint || ' ent_upper_type, ent_lower_type, ent_upper, ent_lower FROM ('
                    || CREATE_HIERARCHY(pin_relationship_tables, NULL, NULL) ||
                    ')';


        END CASE;

        -- enter the where clause in case the query is run for a given date or period
        CASE
          -- if the run is made for a date and the hierarchy is date effective
          WHEN (pin_date_run_for IS NOT NULL AND pin_date_period_column IS NULL) AND (pin_is_effective_period = 0) THEN
               v_create_htable := v_create_htable ||
                           ' WHERE TO_DATE('''
                           || pin_date_run_for ||
                           ''') BETWEEN NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
          -- if the run is made for a date and the hierarchy is period effective
          WHEN (pin_date_run_for IS NOT NULL AND pin_date_period_column IS NULL) AND (pin_is_effective_period = 1) THEN
               v_create_htable := v_create_htable ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                           || PIN_START_PERIOD_COLUMN ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                           || PIN_END_PERIOD_COLUMN ||
                           ' WHERE TO_DATE('''
                           || pin_date_run_for ||
                           ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
           -- if the run is made for a period and the hierarchy is date effective
           WHEN (v_CORRESP_RUN_FOR IS NOT NULL AND pin_date_period_column IS NULL) AND (pin_is_effective_period = 0) THEN
             -- case for the 4 choices for the records to be selected
             CASE (pin_process_run_for)
               -- first day
               WHEN 0 THEN
                 SELECT TU_PERIODS_RANGE.TUPR_START_DATE
                 INTO V_START_DATE
                 FROM TU_PERIODS_RANGE
                 WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                 v_create_htable := v_create_htable ||
                             ' WHERE TO_DATE('''
                             || V_START_DATE ||
                             ''') BETWEEN NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
                 -- last day
               WHEN 1 THEN
                 SELECT TU_PERIODS_RANGE.TUPR_END_DATE
                 INTO V_END_DATE
                 FROM TU_PERIODS_RANGE
                 WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                 v_create_htable := v_create_htable ||
                             ' WHERE TO_DATE('''
                             || V_END_DATE ||
                             ''') BETWEEN NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';

               WHEN 2 THEN
                 SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                 INTO V_START_DATE, V_END_DATE
                 FROM TU_PERIODS_RANGE
                 WHERE TUPR_ID = v_CORRESP_RUN_FOR;
                 -- any days
                 v_create_htable := v_create_htable ||
                             ' WHERE (TO_DATE('''
                             || V_START_DATE ||
                             ''') BETWEEN NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))) OR (TO_DATE('''
                             || V_END_DATE ||
                             ''') BETWEEN NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))) OR (TO_DATE('''
                             || V_START_DATE ||
                             ''') < NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                             || V_END_DATE ||
                             ''') > NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')))';
                  -- all days
               WHEN 3 THEN
                 SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                 INTO V_START_DATE, V_END_DATE
                 FROM TU_PERIODS_RANGE
                 WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                 v_create_htable := v_create_htable ||
                             ' WHERE TO_DATE('''
                             || V_START_DATE ||
                             ''') >= NVL(START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                             || V_END_DATE ||
                             ''') <= NVL(END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
             ELSE

                             v_create_htable := v_create_htable;
             END CASE;
          -- if the run is made for a period and the hierarchy is period effective
          WHEN (v_CORRESP_RUN_FOR IS NOT NULL AND pin_date_period_column IS NULL) AND (pin_is_effective_period = 1) THEN
             -- if the run is made for the same periods or non corresponding periods
             IF (v_hr_timeunit_id = v_time_unit_id) THEN
               -- if the run is made for the same periods
                 SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                 INTO V_START_DATE, V_END_DATE
                 FROM TU_PERIODS_RANGE
                 WHERE TUPR_ID = v_CORRESP_RUN_FOR;

               v_create_htable := v_create_htable ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                           || PIN_START_PERIOD_COLUMN ||
                           ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                           || PIN_END_PERIOD_COLUMN ||
                           ' WHERE TO_DATE('''
                           || V_START_DATE ||
                           ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                           || V_END_DATE ||
                           ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
             -- if the run is made for corresponding periods
             ELSE
                 SELECT COUNT(*)
                 INTO V_CORRESP
                 FROM TU_CORRESPONDENCE
                 WHERE TUC_TU_ID = v_time_unit_id
                 AND TUC_TU_ID_CORR = v_hr_timeunit_id;

                 IF (V_CORRESP = 1) THEN
                     -- if the used time unit corresponds
                     SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                     INTO V_START_DATE, V_END_DATE
                     FROM TU_PERIODS_RANGE
                     WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                     v_create_htable := v_create_htable ||
                                 ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                 || PIN_START_PERIOD_COLUMN ||
                                 ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                 || PIN_END_PERIOD_COLUMN ||
                                 ' WHERE TO_DATE('''
                                 || V_START_DATE ||
                                 ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                                 || V_END_DATE ||
                                 ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';

                 ELSE
                   SELECT COUNT(*)
                   INTO V_CORRESP
                   FROM TU_CORRESPONDENCE
                   WHERE TUC_TU_ID = v_hr_timeunit_id
                   AND TUC_TU_ID_CORR = v_time_unit_id;
                     IF (V_CORRESP = 0) THEN
                       -- if the process time unit corresponds or there is no time unit correspondence
                       SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                       INTO V_START_DATE, V_END_DATE
                       FROM TU_PERIODS_RANGE
                       WHERE TUPR_ID = v_CORRESP_RUN_FOR;
                      -- case for the 4 kinds of process runs posibble
                        CASE (pin_process_run_for)
                          -- first day
                         WHEN 0 THEN
                           SELECT TU_PERIODS_RANGE.TUPR_START_DATE
                           INTO V_START_DATE
                           FROM TU_PERIODS_RANGE
                           WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE TO_DATE('''
                                       || V_START_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
                               -- last day
                         WHEN 1 THEN
                           SELECT TU_PERIODS_RANGE.TUPR_END_DATE
                           INTO V_END_DATE
                           FROM TU_PERIODS_RANGE
                           WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE TO_DATE('''
                                       || V_END_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';

                         WHEN 2 THEN
                           SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                           INTO V_START_DATE, V_END_DATE
                           FROM TU_PERIODS_RANGE
                           WHERE TUPR_ID = v_CORRESP_RUN_FOR;
                               -- any days
                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE (TO_DATE('''
                                       || V_START_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))) OR (TO_DATE('''
                                       || V_END_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))) OR (TO_DATE('''
                                       || V_START_DATE ||
                                       ''') < NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                                       || V_END_DATE ||
                                       ''') > NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')))';
                                -- all days
                         WHEN 3 THEN
                           SELECT TU_PERIODS_RANGE.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_END_DATE
                           INTO V_START_DATE, V_END_DATE
                           FROM TU_PERIODS_RANGE
                           WHERE TUPR_ID = v_CORRESP_RUN_FOR;

                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE TO_DATE('''
                                       || V_START_DATE ||
                                       ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                                       || V_END_DATE ||
                                       ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
                       ELSE
                            v_create_htable := v_create_htable;
                       END CASE;
                    ELSE
                       -- if the process time unit corresponds or there is no time unit correspondence
                       WITH CORR AS
                         (SELECT TUC_TU_ID,
                                 TUC_TU_ID_CORR,
                                 TUPR_ID,
                                 TUPR_ID_CORR,
                                 TUPR_START_DATE,
                                 TUPR_END_DATE
                            FROM TU_CORR_MAT_VIEW)
                        SELECT MIN(TUPR_START_DATE), MAX(TUPR_END_DATE)
                          INTO V_START_DATE, V_END_DATE
                          FROM CORR
                         WHERE TUPR_ID_CORR = pin_period_run_for
                           AND TUC_TU_ID = v_hr_timeunit_id;
                      -- case for the 4 kinds of process runs posibble
                        CASE (pin_process_run_for)
                          -- first day
                         WHEN 0 THEN

                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE TO_DATE('''
                                       || V_START_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
                               -- last day
                         WHEN 1 THEN

                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE TO_DATE('''
                                       || V_END_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';

                         WHEN 2 THEN
                               -- any days
                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE (TO_DATE('''
                                       || V_START_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))) OR (TO_DATE('''
                                       || V_END_DATE ||
                                       ''') BETWEEN NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))) OR (TO_DATE('''
                                       || V_START_DATE ||
                                       ''') < NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                                       || V_END_DATE ||
                                       ''') > NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')))';
                                -- all days
                         WHEN 3 THEN

                           v_create_htable := v_create_htable ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                                       || PIN_START_PERIOD_COLUMN ||
                                       ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                                       || PIN_END_PERIOD_COLUMN ||
                                       ' WHERE TO_DATE('''
                                       || V_START_DATE ||
                                       ''') >= NVL(TP.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) AND TO_DATE('''
                                       || V_END_DATE ||
                                       ''') <= NVL(TP2.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || '))';
                       ELSE
                            NULL;
                       END CASE;
                    END IF;
                 END IF;
             END IF;
        ELSE
             NULL;

        END CASE;

        v_create_htable := v_create_htable || ')';

        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - create hierarchy table - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_create_htable),    ',v_create_htable => <value>', v_stamp);
        END;


      COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => V_TX_ID,
                    pi_description      => 'CREATE ROLL UP HIERARCHY TABLE',
                    pi_ddl              => v_create_htable,
                    pi_undo_ddl         => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' || CON_HIERARCHY_TABLE_NAME || ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' || CON_HIERARCHY_TABLE_NAME || '''; END LOOP; END;',
                    pi_run_id           => pin_run_id);

      END;

      ----------------------------------------------------------
      ----------------------------------------------------------


    PROCEDURE CREATE_INPUT_DATA(
      pin_roll_up_from_type            IN NUMBER,
      pin_rollup_alias_columns         IN VARCHAR2,
      pin_inputview_ent_fld            IN varchar2,
      pin_inputview                    IN CLOB,
      pin_date_period_column           IN varchar2,
      pin_new_date_period_column       IN VARCHAR2,
      pin_start_period_column          IN VARCHAR2,
      pin_fields_columns               IN VARCHAR2,
      pin_INPUTVIEW_NOROLLUP_COLUMNS   IN VARCHAR2,
      pin_A_INPUTVIEW_NOROLLUP_COLS    IN VARCHAR2,
      pin_input_data_entity            IN VARCHAR2,
      pin_run_id                       IN NUMBER,

     pio_INPUT_VIEW_COLUMNS_NA     IN OUT TABLETYPE_COLUMN,
     pio_INPUT_VIEW_COLUMNS        IN OUT TABLETYPE_COLUMN)
     AS

      CON_INPUT_DATA       CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
      CON_INPUT_DATA_INDEX CONSTANT VARCHAR2(30) := 'IDIP' || pin_run_id;

      V_CREATE_INPUT_DATA     CLOB;
      V_INPUTVIEW_COLUMNS     VARCHAR2(32767);
      V_INPUTVIEW_COLUMNS_NA  VARCHAR2(32767);
      V_FIELD_TYPE            NUMBER;
      V_ENT_BUS_COLUMN        VARCHAR2(30);
      V_ENTITY_FIELD          BOOLEAN;
      V_ROW_IDENTIFIER        VARCHAR2(45);
      V_ROW_IDENTIFIER_NA     VARCHAR2(30);
      V_rollup_alias_columns  VARCHAR2(32767);
      V_IS_FIELD              NUMBER(1);
      V_INNER_JOIN            VARCHAR2(150);
      v_time_unit             NUMBER;

     BEGIN

    -- if the entity/field column is Exxxx type
    V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');
      -- get the business key column of the entity
      IF (V_ENTITY_FIELD) THEN
            V_ENT_BUS_COLUMN := commons.FIND_ENT_BUSINESS_KEY_BY_NAME(pin_inputview_ent_fld);
      ELSE
            V_ENT_BUS_COLUMN := commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type);
      END IF;

      -- set the join between the input table and entity table
       IF (V_ENTITY_IS_NUMBER = 6) THEN
         V_INNER_JOIN := ' LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' b ON b.' || V_ENT_BUS_COLUMN || ' = a.'
                                        || pin_INPUT_DATA_ENTITY;
       ELSE
         V_INNER_JOIN := ' LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' b ON UPPER(b.' || V_ENT_BUS_COLUMN || ') = UPPER(a.'
                                        || pin_INPUT_DATA_ENTITY || ')';
       END IF;

       IF (pin_fields_columns IS NULL) THEN
          -- check if the first column is of field type
          BEGIN
            SELECT 1
            INTO V_IS_FIELD
            FROM fields f
            WHERE f.fld_column_name = pin_rollup_alias_columns AND ROWNUM = 1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_IS_FIELD := 0;
          END;
          -- get the row_identifier alias
          IF (substr(pin_rollup_alias_columns,1,1) = 'E' OR (V_IS_FIELD=1)) THEN
            V_ROW_IDENTIFIER := 'ROW_IDENTIFIER';
            V_ROW_IDENTIFIER_NA := 'ROW_IDENTIFIER';
          ELSE
            V_ROW_IDENTIFIER := substr(replace(pin_rollup_alias_columns,' '),1,instr(replace(pin_rollup_alias_columns,' '),',')-1) || ' ROW_IDENTIFIER';
            V_ROW_IDENTIFIER_NA := substr(replace(pin_rollup_alias_columns,' '),1,instr(replace(pin_rollup_alias_columns,' '),',')-1);
          END IF;

          -- get the column aliases without the row_identifier
          IF (instr(pin_rollup_alias_columns,',') IS NULL) THEN
            v_rollup_alias_columns := '';
          ELSE
            IF (substr(pin_rollup_alias_columns,1,1) = 'E' OR (V_IS_FIELD=1)) THEN
              V_rollup_alias_columns := replace(pin_rollup_alias_columns,' ');
           ELSE
              V_rollup_alias_columns := substr(replace(pin_rollup_alias_columns,' '),instr(replace(pin_rollup_alias_columns,' '),',')+1);
            END IF;
          END IF;

          -- if the there is no date/period field to filter by
          IF (pin_date_period_column IS NOT NULL) THEN
                 SELECT FIELDS.fld_data_type
                 INTO V_FIELD_TYPE
                 FROM FIELDS
                 WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;
                       -- if the field is date type
                       IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
                          IF (V_ENTITY_FIELD) THEN
                            V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                        || V_ENT_BUS_COLUMN ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                         a.'
                                        || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                        ', a.'
                                        || pin_new_date_period_column ||
                                        ' AS DATE_FIELD, a.' || V_ROW_IDENTIFIER || '
                                         FROM ('
                                        || pin_InputView ||
                                        ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                        || pin_INPUT_DATA_ENTITY;
                          -- if the field is period type
                          ELSE
                            V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                        || pin_INPUT_DATA_ENTITY ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID
                                        , a.'
                                        || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                        ', a.'
                                        || pin_new_date_period_column ||
                                        ' AS DATE_FIELD, a.' || V_ROW_IDENTIFIER || '
                                         FROM ('
                                        || pin_InputView ||
                                        ') a ' || V_INNER_JOIN;
                          END IF;
                       -- if the field is not date type
                       ELSE
                          IF GET_PERIODS_AND_CORESP(pin_date_period_column   => pin_date_period_column,
                                                    pin_start_period_column  => pin_start_period_column,

                                                    pout_time_unit           => v_time_unit) THEN
                              -- if the roll up it's done by entity
                              IF (V_ENTITY_FIELD) THEN
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                            || V_ENT_BUS_COLUMN ||
                                            ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                              a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', MIN(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ') END) AS START_DATEE, MAX(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_END_DATE, TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ') END) AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID
                                                LEFT OUTER JOIN TU_CORR_MAT_VIEW TCMV
                                                  ON TCMV.TUPR_ID_CORR = A.' || pin_new_date_period_column || ' AND TCMV.TUC_TU_ID = ' || v_time_unit ||
                                            ' GROUP BY b.'
                                            || V_ENT_BUS_COLUMN ||
                                            ', b.E_INTERNAL_ID ,
                                              a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS || ',a.' || V_ROW_IDENTIFIER_NA;
                              -- if the roll up it's not done by entity
                              ELSE
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                              a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', MIN(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ') END) AS START_DATEE, MAX(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_END_DATE, TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ') END) AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a ' || V_INNER_JOIN ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID
                                                LEFT OUTER JOIN TU_CORR_MAT_VIEW TCMV
                                                  ON TCMV.TUPR_ID_CORR = A.' || pin_new_date_period_column || ' AND TCMV.TUC_TU_ID = ' || v_time_unit ||
                                            ' GROUP BY a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ', b.E_INTERNAL_ID,
                                              a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS || ',a.' || V_ROW_IDENTIFIER_NA;
                               END IF;
                           ELSE
                              -- if the roll up it's done by entity
                              IF (V_ENTITY_FIELD) THEN
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                            || V_ENT_BUS_COLUMN ||
                                            ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                              a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ') END AS START_DATEE, CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ') END AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID';
                              -- if the roll up it's not done by entity
                              ELSE
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                              a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ') END AS START_DATEE, CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ') END AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a ' || V_INNER_JOIN ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID';
                               END IF;
                           END IF;
                        END IF;
           -- if there is a date/period field to filter by
           ELSE
                 IF (V_ENTITY_FIELD) THEN
                   V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                        || V_ENT_BUS_COLUMN ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                      a.'
                                    || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                    ', a.' || V_ROW_IDENTIFIER || ' FROM ('
                                    || pin_InputView ||
                                    ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                    || pin_INPUT_DATA_ENTITY;
                 ELSE
                   V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                        || pin_INPUT_DATA_ENTITY ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                      a.'
                                    || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                    ', a.' || V_ROW_IDENTIFIER || ' FROM ('
                                    || pin_InputView ||
                                    ') a ' || V_INNER_JOIN;
                 END IF;

           END IF;

        -- if there exists values to roll up
        ELSE
          -- check if the first column is of field type
          BEGIN
            SELECT 1
            INTO V_IS_FIELD
            FROM fields f
            WHERE f.fld_column_name = substr(pin_rollup_alias_columns,1,instr(pin_rollup_alias_columns,',')-1) AND ROWNUM = 1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_IS_FIELD := 0;
          END;
          -- get the row_identifier alias
          IF (substr(pin_rollup_alias_columns,1,1) = 'E' OR (V_IS_FIELD=1)) THEN
            V_ROW_IDENTIFIER := 'ROW_IDENTIFIER';
            V_ROW_IDENTIFIER_NA := 'ROW_IDENTIFIER';
          ELSE
            V_ROW_IDENTIFIER := substr(replace(pin_rollup_alias_columns,' '),1,instr(replace(pin_rollup_alias_columns,' '),',')-1) || ' ROW_IDENTIFIER';
            V_ROW_IDENTIFIER_NA := substr(replace(pin_rollup_alias_columns,' '),1,instr(replace(pin_rollup_alias_columns,' '),',')-1);
          END IF;

          -- get the column aliases without the row_identifier
          IF (instr(pin_rollup_alias_columns,',') IS NULL) THEN
            v_rollup_alias_columns := '';
          ELSE
            IF (substr(pin_rollup_alias_columns,1,1) = 'E' OR (V_IS_FIELD=1)) THEN
              V_rollup_alias_columns := replace(pin_rollup_alias_columns,' ');
           ELSE
              V_rollup_alias_columns := substr(replace(pin_rollup_alias_columns,' '),instr(replace(pin_rollup_alias_columns,' '),',')+1);
            END IF;
          END IF;

          -- get the alias field column names into an array
          select BB.AA, 6
          BULK COLLECT INTO pio_INPUT_VIEW_COLUMNS
          FROM
          (select regexp_substr(v_rollup_alias_columns,'[^ ,]+', 1, level) AA, level as LVL from dual
          connect by regexp_substr(v_rollup_alias_columns, '[^ ,]+', 1, level) is not null) BB
          order by BB.LVL;

          -- get the field column names into an array
          SELECT BB.AA, NVL(fields.fld_Data_Type, 6)
          BULK COLLECT INTO pio_INPUT_VIEW_COLUMNS_NA
          FROM
          (select regexp_substr(PIN_FIELDS_COLUMNS,'[^ ,]+', 1, level) AA, level as LVL from dual
          connect by regexp_substr(PIN_FIELDS_COLUMNS, '[^ ,]+', 1, level) is not null) BB
          left outer join fields on BB.AA=fields.fld_column_name
          order by BB.LVL;

          V_INPUTVIEW_COLUMNS := '';

          IF (V_ENTITY_FIELD) THEN
            -- add the field columns
            FOR i IN pio_INPUT_VIEW_COLUMNS.FIRST .. pio_INPUT_VIEW_COLUMNS.LAST
              LOOP
                V_INPUTVIEW_COLUMNS := V_INPUTVIEW_COLUMNS || 'A.' || pio_INPUT_VIEW_COLUMNS(i).COLUMN_NAME || ' AS VALUE' || i || ',';
                V_INPUTVIEW_COLUMNS_NA := V_INPUTVIEW_COLUMNS_NA || 'A.' || pio_INPUT_VIEW_COLUMNS(i).COLUMN_NAME || ',';
              END LOOP;
          ELSE
            -- add the field columns
            FOR i IN pio_INPUT_VIEW_COLUMNS.FIRST .. pio_INPUT_VIEW_COLUMNS.LAST
              LOOP
                V_INPUTVIEW_COLUMNS := V_INPUTVIEW_COLUMNS || pio_INPUT_VIEW_COLUMNS(i).COLUMN_NAME || ' AS VALUE' || i || ',';
                V_INPUTVIEW_COLUMNS_NA := V_INPUTVIEW_COLUMNS_NA || pio_INPUT_VIEW_COLUMNS(i).COLUMN_NAME || ',';
              END LOOP;
          END IF;

          V_INPUTVIEW_COLUMNS := substr(V_INPUTVIEW_COLUMNS,1,length(V_INPUTVIEW_COLUMNS)-1);    -- if the there is no date/period field to filter by
          V_INPUTVIEW_COLUMNS_NA := substr(V_INPUTVIEW_COLUMNS_NA,1,length(V_INPUTVIEW_COLUMNS_NA)-1);    -- if the there is no date/period field to filter by

            IF (V_ENTITY_FIELD) THEN
                IF (pin_date_period_column IS NOT NULL) THEN
                       SELECT FIELDS.fld_data_type
                       INTO V_FIELD_TYPE
                       FROM FIELDS
                       WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;
                         -- if the field is date type
                         IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
                            V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                        || V_ENT_BUS_COLUMN ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.'
                                        || pin_INPUT_DATA_ENTITY ||
                                        ', '
                                        || V_INPUTVIEW_COLUMNS ||
                                        ', a.'
                                        || pin_new_date_period_column ||
                                        ' AS DATE_FIELD, a.' || V_ROW_IDENTIFIER || ' ' || PIN_INPUTVIEW_NOROLLUP_COLUMNS || ' FROM ('
                                        || pin_InputView ||
                                        ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                        || pin_INPUT_DATA_ENTITY;
                         -- if the field is not date type
                         ELSE
                            IF GET_PERIODS_AND_CORESP(pin_date_period_column   => pin_date_period_column,
                                                      pin_start_period_column  => pin_start_period_column,

                                                      pout_time_unit           => v_time_unit) THEN
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                          || V_ENT_BUS_COLUMN ||
                                          ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', '
                                            || V_INPUTVIEW_COLUMNS ||
                                            ', MIN(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ') END) AS START_DATEE, MAX(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_END_DATE, TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ') END) AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID
                                                LEFT OUTER JOIN TU_CORR_MAT_VIEW TCMV
                                                  ON TCMV.TUPR_ID_CORR = A.' || pin_new_date_period_column || ' AND TCMV.TUC_TU_ID = ' || v_time_unit ||
                                            ' GROUP BY b.'
                                            || V_ENT_BUS_COLUMN ||
                                            ' , b.E_INTERNAL_ID,
                                            a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', '
                                            || V_INPUTVIEW_COLUMNS_NA || ', a.' || V_ROW_IDENTIFIER_NA;
                            ELSE
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                          || V_ENT_BUS_COLUMN ||
                                          ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', '
                                            || V_INPUTVIEW_COLUMNS ||
                                            ', CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE NULL END AS START_DATEE, CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE NULL END AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID';
                            END IF;
                          END IF;
                 -- if there is a date/period field to filter by
                 ELSE
                       V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT b.'
                                        || V_ENT_BUS_COLUMN ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.'
                                          || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                          ', a.' || V_ROW_IDENTIFIER || ', '
                                          || V_INPUTVIEW_COLUMNS ||
                                          ' FROM ('
                                          || pin_InputView ||
                                          ') a LEFT JOIN ' || commons.FIND_ENT_TABLE_NAME(pin_inputview_ent_fld) || ' b ON b.E_INTERNAL_ID = a.'
                                          || pin_INPUT_DATA_ENTITY;
                 END IF;
            ELSE
                IF (pin_date_period_column IS NOT NULL) THEN
                       SELECT FIELDS.fld_data_type
                       INTO V_FIELD_TYPE
                       FROM FIELDS
                       WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;

                         -- if the field is date type
                         IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
                            V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                        || pin_INPUT_DATA_ENTITY ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                          a.'
                                        || pin_INPUT_DATA_ENTITY ||
                                        ', '
                                        || V_INPUTVIEW_COLUMNS ||
                                        ', a.'
                                        || pin_new_date_period_column ||
                                        ' AS DATE_FIELD, a.' || V_ROW_IDENTIFIER || ' ' || PIN_INPUTVIEW_NOROLLUP_COLUMNS || ' FROM ('
                                        || pin_InputView ||
                                        ') a ' || V_INNER_JOIN;
                         -- if the field is not date type
                         ELSE
                            IF GET_PERIODS_AND_CORESP(pin_date_period_column   => pin_date_period_column,
                                                      pin_start_period_column  => pin_start_period_column,

                                                      pout_time_unit           => v_time_unit) THEN
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                          || pin_INPUT_DATA_ENTITY ||
                                          ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', '
                                            || V_INPUTVIEW_COLUMNS ||
                                            ', MIN(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_START_DATE, TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ') END) AS START_DATEE, MAX(CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN COALESCE(TCMV.TUPR_END_DATE, TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ') END) AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a ' || V_INNER_JOIN ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID
                                                LEFT OUTER JOIN TU_CORR_MAT_VIEW TCMV
                                                  ON TCMV.TUPR_ID_CORR = A.' || pin_new_date_period_column || ' AND TCMV.TUC_TU_ID = ' || v_time_unit ||
                                            ' GROUP BY a.'
                                            || pin_INPUT_DATA_ENTITY ||
                                            ', b.E_INTERNAL_ID ,
                                            a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', '
                                            || V_INPUTVIEW_COLUMNS_NA || ', a.' || V_ROW_IDENTIFIER_NA;
                            ELSE
                               V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                          || pin_INPUT_DATA_ENTITY ||
                                          ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.'
                                            || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                            ', '
                                            || V_INPUTVIEW_COLUMNS ||
                                            ', CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE NULL END AS START_DATEE, CASE WHEN a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID THEN NVL(TU_PERIODS_RANGE.TUPR_END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) ELSE NULL END AS END_DATEE, a.' || V_ROW_IDENTIFIER || ' FROM ('
                                            || pin_InputView ||
                                            ') a ' || V_INNER_JOIN ||
                                            ' LEFT OUTER JOIN TU_PERIODS_RANGE ON a.'
                                            || pin_new_date_period_column ||
                                            ' = TU_PERIODS_RANGE.TUPR_ID';
                            END IF;
                          END IF;
                 -- if there is a date/period field to filter by
                 ELSE
                       V_CREATE_INPUT_DATA := 'CREATE TABLE ' || CON_INPUT_DATA || ' TABLESPACE ' || USER || '_OUT AS (SELECT a.'
                                        || pin_INPUT_DATA_ENTITY ||
                                        ' AS ENTITY, b.E_INTERNAL_ID ENTITY_INT_ID,
                                            a.'
                                          || pin_A_INPUTVIEW_NOROLLUP_COLS ||
                                          ', a.' || V_ROW_IDENTIFIER || ', '
                                          || V_INPUTVIEW_COLUMNS ||
                                          ' FROM ('
                                          || pin_InputView ||
                                          ') a ' || V_INNER_JOIN;
                 END IF;
            END IF;
        END IF;


     V_CREATE_INPUT_DATA := V_CREATE_INPUT_DATA || ')';

      v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - create input data table - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

      BEGIN
              L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_CREATE_INPUT_DATA),    ',V_CREATE_INPUT_DATA => <value>', v_stamp);
      END;


      COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => V_TX_ID,
                    pi_description      => 'CREATE ROLL UP INPUT DATA TABLE',
                    pi_ddl              => V_CREATE_INPUT_DATA,
                    pi_undo_ddl         => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' || CON_INPUT_DATA || ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' || CON_INPUT_DATA || '''; END LOOP; END;',
                    pi_run_id           => pin_run_id);

      -- create index
      IF (pin_date_period_column IS NOT NULL) THEN
         -- if the entity key field is number type
         IF (V_ENTITY_IS_NUMBER = 6) THEN
           IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
              CREATE_INDEX('CREATE INDEX ' || CON_INPUT_DATA_INDEX || ' ON ' || CON_INPUT_DATA || '(ENTITY, DATE_FIELD) TABLESPACE ' || USER || '_IND');
           ELSE
              CREATE_INDEX('CREATE INDEX ' || CON_INPUT_DATA_INDEX || ' ON ' || CON_INPUT_DATA || '(ENTITY, START_DATEE, END_DATEE) TABLESPACE ' || USER || '_IND');
           END IF;
         ELSE
           IF (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) THEN
              CREATE_INDEX('CREATE INDEX ' || CON_INPUT_DATA_INDEX || ' ON ' || CON_INPUT_DATA || '(UPPER(ENTITY), DATE_FIELD) TABLESPACE ' || USER || '_IND');
           ELSE
              CREATE_INDEX('CREATE INDEX ' || CON_INPUT_DATA_INDEX || ' ON ' || CON_INPUT_DATA || '(UPPER(ENTITY), START_DATEE, END_DATEE) TABLESPACE ' || USER || '_IND');
           END IF;
         END IF;
      END IF;


     END;


      -----------------------------------------------------------
      -----------------------------------------------------------

      PROCEDURE CREATE_CBS_DATA(   pin_roll_up_to_type            IN NUMBER,
                                   pin_roll_up_from_type          IN NUMBER,
                                   pin_level_to                   IN NUMBER,
                                   pin_date_period_column         IN VARCHAR2,
                                   pin_operation_id               IN NUMBER,
                                   pin_run_id                     IN NUMBER
                                   )
        AS
           CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI'  || pin_run_id;
           CON_CONN_BY_SELECT_NAME  CONSTANT VARCHAR2(30) := 'CBS' || pin_run_id;

           v_create_hierarchy      VARCHAR2(32767);
           v_select_hierarchy      VARCHAR2(32767);
           v_select                CLOB;
        BEGIN
          -- add the hint framework
          v_create_hierarchy := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_WITH', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_WITH', pin_operation_id);
          v_select_hierarchy := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_SELECT_WITH', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_SELECT_WITH', pin_operation_id);

          v_select := 'CREATE TABLE ' || CON_CONN_BY_SELECT_NAME || ' TABLESPACE ' || USER || '_OUT AS
                       WITH HIERARCHY_RECUR(LVL, ROOT, ENT_UPPER, ENT_LOWER, ENT_LOWER_TYPE' || CASE WHEN (pin_date_period_column IS NULL) THEN '' ELSE ', MAX_START_DATE, MIN_END_DATE, ROOT_START, ROOT_END' END || ') AS (
                       ' || v_create_hierarchy || '
                          1                              LVL,
                          HIERARCHY_INPUT.ENT_UPPER      ROOT,
                          HIERARCHY_INPUT.ENT_UPPER      ENT_UPPER,
                          HIERARCHY_INPUT.ENT_LOWER      ENT_LOWER,
                          HIERARCHY_INPUT.ENT_LOWER_TYPE ENT_LOWER_TYPE
                          ' ||
                          CASE WHEN (pin_date_period_column IS NULL) THEN '' ELSE ',
                            NVL(HIERARCHY_INPUT.START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')) MAX_START_DATE,
                            NVL(HIERARCHY_INPUT.END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')) MIN_END_DATE,
                            HIERARCHY_INPUT.START_DATE     ROOT_START,
                            HIERARCHY_INPUT.END_DATE       ROOT_END '
                          END || '
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' HIERARCHY_INPUT
                          WHERE  HIERARCHY_INPUT.ENT_UPPER_TYPE = ' || pin_roll_up_to_type ||'

                         UNION ALL

                   SELECT HIERARCHY_RECUR.LVL + 1 LVL,
                          HIERARCHY_RECUR.ROOT,
                          HIERARCHY_INPUT.ENT_UPPER,
                          HIERARCHY_INPUT.ENT_LOWER,
                          HIERARCHY_INPUT.ENT_LOWER_TYPE
                          ' ||
                          CASE WHEN (pin_date_period_column IS NULL) THEN '' ELSE ',
                            GREATEST(NVL(HIERARCHY_INPUT.START_DATE, TO_DATE(' || CON_START_DATE ||', ' || CON_DATE_FORMAT || ')), HIERARCHY_RECUR.MAX_START_DATE) MAX_START_DATE,
                            LEAST(NVL(HIERARCHY_INPUT.END_DATE, TO_DATE(' || CON_END_DATE ||', ' || CON_DATE_FORMAT || ')), HIERARCHY_RECUR.MIN_END_DATE) MAX_END_DATE,
                            HIERARCHY_RECUR.ROOT_START,
                            HIERARCHY_RECUR.ROOT_END'
                          END || '
                     FROM ' || CON_HIERARCHY_TABLE_NAME || ' HIERARCHY_INPUT, HIERARCHY_RECUR
                    WHERE HIERARCHY_RECUR.ENT_LOWER = HIERARCHY_INPUT.ENT_UPPER
                      AND HIERARCHY_RECUR.ENT_LOWER_TYPE = HIERARCHY_INPUT.ENT_UPPER_TYPE
                     ' || CASE WHEN pin_level_to <> 0 THEN ' AND HIERARCHY_RECUR.LVL < ' || pin_level_to ELSE '' END || ')
                     SEARCH depth FIRST BY ENT_UPPER SET order1
                     CYCLE ENT_UPPER, ENT_LOWER_TYPE SET CYCLE TO 1 DEFAULT 0
              ' || v_select_hierarchy || ' HR.*, E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ' ENTI_KEY_FIELD
                FROM (SELECT HR.*, ROWNUM ROW_NUM
                        FROM HIERARCHY_RECUR HR
                       WHERE CYCLE <> 1 AND HR.ENT_LOWER_TYPE = ' || pin_roll_up_from_type || ') HR
                JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                  ON E.E_INTERNAL_ID = HR.ENT_LOWER';

          v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - create connect by table - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

          BEGIN
                  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_select),    ',v_create_htable => <value>', v_stamp);
          END;

      COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => V_TX_ID,
                    pi_description      => 'CREATE ROLL UP CONNECT BY TABLE',
                    pi_ddl              => v_select,
                    pi_undo_ddl         => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' || CON_CONN_BY_SELECT_NAME || ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' || CON_CONN_BY_SELECT_NAME || '''; END LOOP; END;',
                    pi_run_id           => pin_run_id);

        END;


      -----------------------------------------------------------
      -----------------------------------------------------------

      PROCEDURE CREATE_INSERT_DATA(pin_entity_field                 IN BOOLEAN,
                                   pin_entity_roll_up_from_column   IN VARCHAR2,
                                   pin_inputview_columns            IN VARCHAR2,
                                   pin_roll_up_from_type            IN NUMBER,
                                   pin_roll_up_to_type              IN NUMBER,
                                   pin_level_from                   IN NUMBER,
                                   pin_date_period_column           IN VARCHAR2,
                                   pin_INPUT_DATA_VALUES_NO         IN NUMBER,
                                   pin_INPUTDATA_NOROLLUP_COLUMNS   IN VARCHAR2,
                                   pin_is_effective_period          IN NUMBER,
                                   pin_process_run_for              IN NUMBER,
                                   pin_start_period_column          IN VARCHAR2,
                                   pin_operation_id                 IN NUMBER,
                                   pin_run_id                       IN NUMBER
                                   )
      AS
        CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;
        CON_CONN_BY_SELECT_NAME  CONSTANT VARCHAR2(30) := 'CBS'  || pin_run_id;
        CON_INPUT_DATA           CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
        CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI'   || pin_run_id;

        v_select           CLOB;
        V_FIELD_TYPE       NUMBER(10);
        v_filter           CLOB;
        v_insert_data_hint VARCHAR2(32767);
      BEGIN
         v_insert_data_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_DATA', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_DATA', pin_operation_id);

         -- performance edit row_identifier only for pin_aggregate_values = 1 or pin_no_match for level_from = 0
                 v_select := v_insert_data_hint || ' CBS.ROW_NUM, input_data.row_identifier, CBS.root, CBS.ent_lower, CBS.LVL, '
                                                || case WHEN pin_roll_up_from_type = pin_roll_up_to_type
                                                     THEN 'CBS.ENTI_KEY_FIELD ENTITY'
                                                     ELSE 'INPUT_DATA.ENTITY_INT_ID ENTITY'
                                                   END
                                                || CASE WHEN (pin_roll_up_from_type = pin_roll_up_to_type) AND (pin_entity_roll_up_from_column IS NOT NULL) AND (instr(',' || pin_inputview_columns || ',', ',' || pin_entity_roll_up_from_column || ',') < 3 AND pin_ENTITY_FIELD) THEN
                                                ', INPUT_DATA.ENTITY ENTITY_INT_ID'
                                                ELSE ''
                                                   END;

           -- if the entities are of the same type
           IF (pin_roll_up_from_type = pin_roll_up_to_type) THEN
             -- add the columns for the values
             FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO
               LOOP
                 v_select := v_select || ', VALUE' || i || ' as VALUE' || i || '';
               END LOOP;
           -- if the entities are of different types
           ELSE
             -- add the columns for the values
             FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO
               LOOP
                 v_select := v_select || ',VALUE' || i;
               END LOOP;
           END IF;

       IF (pin_date_period_column IS NOT NULL) THEN
                 SELECT FIELDS.fld_data_type
                 INTO V_FIELD_TYPE
                 FROM FIELDS
                 WHERE FIELDS.FLD_COLUMN_NAME = pin_date_period_column AND ROWNUM = 1;
         v_select := v_select || case when (V_FIELD_TYPE = 3 OR V_FIELD_TYPE = 5) then ', DATE_FIELD'
                                                    else ', START_DATEE, END_DATEE'
                              END || ', NVL(MAX_START_DATE, TO_DATE(''01/01/1900'', ' || CON_DATE_FORMAT || ')) MAX_START_DATE, NVL(MIN_END_DATE, TO_DATE(''12/31/9999'', ' || CON_DATE_FORMAT || ')) MIN_END_DATE';
       END IF;
       -- add the rows needed by the additional tables
       v_select := v_select || pin_INPUTDATA_NOROLLUP_COLUMNS;

       -- add the from clause
       if (V_ENTITY_IS_NUMBER = 6) THEN
         -- if the entity key field is number type
         v_select := v_select || ' FROM ' || CON_CONN_BY_SELECT_NAME || ' CBS
                                      INNER JOIN
                                     ' || CON_INPUT_DATA || ' INPUT_DATA
                                      ON INPUT_DATA.ENTITY = CBS.ENTI_KEY_FIELD';
       ELSE
         -- if the entity key field is number type
         v_select := v_select || ' FROM ' || CON_CONN_BY_SELECT_NAME || ' CBS
                                      INNER JOIN
                                     ' || CON_INPUT_DATA || ' INPUT_DATA
                                      ON UPPER(INPUT_DATA.ENTITY) = UPPER(CBS.ENTI_KEY_FIELD)';
       END IF;

       IF (pin_date_period_column IS NOT NULL) THEN

           v_filter := CREATE_DATE_PERIOD_FILTER(
                                         pin_ENTITY_FIELD        => pin_ENTITY_FIELD,
                                         pin_is_effective_period => pin_is_effective_period,
                                         pin_process_run_for     => pin_process_run_for,
                                         pin_date_period_column  => pin_date_period_column,
                                         pin_start_period_column => pin_start_period_column
                                         );
            -- add the filter
            v_select := v_select || v_filter;
       END IF;

       -- if lowest value is selected
       IF (pin_level_from = 0) THEN
         -- remove the rows that do not match
         IF (pin_date_period_column IS NULL) THEN
           v_select := v_select || ' WHERE NOT EXISTS (SELECT 1
                                                      FROM ' || CON_HIERARCHY_TABLE_NAME || ' i
                                                      INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                                                      ON E.E_INTERNAL_ID = i.ENT_UPPER
                                                      AND i.ent_upper_type = ' || pin_roll_up_from_type || '
                                                      WHERE ' ||
                                                      CASE WHEN V_ENTITY_IS_NUMBER = 6 THEN
                                                           'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')'
                                                      ELSE
                                                           'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || '))'
                                                      END;
          ELSE
             v_filter := CREATE_DATE_PERIOD_FILTER(
                                           pin_ENTITY_FIELD        => pin_ENTITY_FIELD,
                                           pin_is_effective_period => pin_is_effective_period,
                                           pin_process_run_for     => pin_process_run_for,
                                           pin_date_period_column  => pin_date_period_column,
                                           pin_start_period_column => pin_start_period_column
                                           );

             v_select := v_select || ' WHERE NOT EXISTS (SELECT 1
                                                      FROM ' || CON_HIERARCHY_TABLE_NAME || ' i
                                                      INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                                                      ON E.E_INTERNAL_ID = i.ENT_UPPER
                                                      AND i.ent_upper_type = ' || pin_roll_up_from_type || '
                                                      WHERE ' ||
                                                      CASE WHEN V_ENTITY_IS_NUMBER = 6 THEN
                                                           'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_filter || ')'
                                                      ELSE
                                                           'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_filter || ')'
                                                      END;
          END IF;
       END IF;

                  -- create the connect by table
          v_select :=  'CREATE TABLE ' || CON_INSERT_DATA_TABLE || ' TABLESPACE ' || USER || '_OUT AS (' || v_select || ')';

          v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - create insert data table - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

          BEGIN
                  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_select),    ',v_insert_data_table => <value>', v_stamp);
          END;

      COMMONS_DDL_HANDLING.execute_ddl(pi_transaction_id => V_TX_ID,
                    pi_description      => 'CREATE ROLL UP INSERT DATA TABLE',
                    pi_ddl              => v_select,
                    pi_undo_ddl         => 'BEGIN FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = ''' || CON_INSERT_DATA_TABLE || ''') LOOP EXECUTE IMMEDIATE ''DROP TABLE ' || CON_INSERT_DATA_TABLE || '''; END LOOP; END;',
                    pi_run_id           => pin_run_id);
      END;


    PROCEDURE CREATE_MAIN_SELECT(pin_roll_up_from_type                  IN NUMBER,
                                 pin_roll_up_to_type                    IN NUMBER,
                                 pin_level_from                         IN NUMBER,
                                 pin_entity_roll_up_from_column         IN VARCHAR2,
                                 pin_inputview_columns                  IN VARCHAR2,
                                 pin_entity_field                       IN BOOLEAN,
                                 pin_aggregate_values                   IN NUMBER,
                                 pin_input_data_values_no               IN NUMBER,
                                 pin_INPUT_VIEW_COLUMNS_NA              IN TABLETYPE_COLUMN,
                                 pin_include_input_records              IN NUMBER,
                                 pin_run_id                             IN NUMBER,
                                 pin_operation_id                       IN NUMBER,

                                 pio_select                             IN OUT NOCOPY CLOB)
    AS
      CON_INSERT_DATA_TABLE CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;

      v_select_hint  CLOB;
    BEGIN

        -- add the hint framework
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_MAIN_SELECT', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_MAIN_SELECT', pin_operation_id);

        -- create the main select
        --
        pio_select := pio_select || v_select_hint || ' INSERT_DATA.ROW_NUM, INSERT_DATA.ROOT, INSERT_DATA.ENT_LOWER, INSERT_DATA.LVL, INSERT_DATA.ENTITY, ROWNUM ROW_IDENTIFIER';

        IF (pin_level_from = 0) THEN
          pio_select := pio_select
                        || ',max(ROWNUM) over (partition by INSERT_DATA.ROW_IDENTIFIER) as MAX_ROW_IDENTIFIER ';
        END IF;
        --
        -- if the entities used in the operation are the same and the roll up from column is used in the output table
        IF (pin_roll_up_from_type = pin_roll_up_to_type) AND (pin_entity_roll_up_from_column IS NOT NULL) AND (instr(',' || pin_inputview_columns || ',', ',' || pin_entity_roll_up_from_column || ',') < 3 AND pin_ENTITY_FIELD) THEN
            pio_select := pio_select ||
                        ', INSERT_DATA.ENTITY_INT_ID '
                        || pin_entity_roll_up_from_column;
        END IF;
        -- add the selected columns if the rows are aggregated
        IF (pin_aggregate_values = 1) THEN

          -- get the max row num so only one row is inserted
          -- if the lowest value is selected
            pio_select := pio_select || ', max(ROWNUM) over (partition by INSERT_DATA.root) as MAX_ROW_NUM, ROWNUM ROWNO ';

          FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO
            LOOP
              -- if the values are numeric type
              IF (pin_INPUT_VIEW_COLUMNS_NA(I).COLUMN_TYPE = 6) THEN
                 pio_select := pio_select || ', sum(VALUE' || i || ') over (partition by INSERT_DATA.root) as TO_SUM' || i ||'';
              -- if the values are not numeric type
              ELSE
                 pio_select := pio_select || ', min(VALUE' || i ||') keep (DENSE_RANK last order by INSERT_DATA.ROW_IDENTIFIER) over (partition by INSERT_DATA.root) as TO_SUM' || i ||'';
              END IF;
            END LOOP;
        ELSE
        -- add the selected columns if the rows are not aggregated
          FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO
          LOOP
            pio_select := pio_select || ', INSERT_DATA.VALUE' || i;
          end loop;
        END IF;

        -- add the from clause
        pio_select := pio_select || ' FROM ' || CON_INSERT_DATA_TABLE || ' INSERT_DATA';


        -- if the roll up is done only for leaves
        IF (pin_level_from = 0) THEN

          -- if include input records option is selected
          IF (pin_include_input_records = 1) THEN

              -- add the hint framework
              v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_MAIN_UNION_LOW', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_MAIN_UNION_LOW', pin_operation_id);

              pio_select := pio_select || ' UNION ALL ' || v_select_hint || ' DISTINCT ';

              -- add the main columns
              pio_select := pio_select || 'NULL ROW_NUM, NULL ROOT, INSERT_DATA.ENT_LOWER, NULL LVL, INSERT_DATA.ENTITY, NULL ROW_IDENTIFIER';
              -- if the lowest value is selected
              IF (pin_level_from = 0) THEN
                pio_select := pio_select || ', NULL MAX_ROW_IDENTIFIER';
              END IF;
              -- if the entities used in the operation are the same and the roll up from column is used in the output table
              IF (pin_roll_up_from_type = pin_roll_up_to_type) AND (pin_entity_roll_up_from_column IS NOT NULL) AND (instr(',' || pin_inputview_columns || ',', ',' || pin_entity_roll_up_from_column || ',') < 3 AND pin_ENTITY_FIELD) THEN
                  pio_select := pio_select ||
                              ', INSERT_DATA.ENTITY_INT_ID '
                              || pin_entity_roll_up_from_column;
              END IF;
              -- add the selected columns if the rows are not aggregated
              FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO
              LOOP
                pio_select := pio_select || ', INSERT_DATA.VALUE' || i;
              end LOOP;

              pio_select := pio_select || ' FROM (SELECT * FROM ' || CON_INSERT_DATA_TABLE || ' INSERT_DATA
                                        WHERE ROOT IS NOT NULL) INSERT_DATA ';

           END IF;
        ELSE

          -- if include input records option is selected
          IF (pin_include_input_records = 1) THEN
               -- add the hint framework
              v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_MAIN_UNION', pin_operation_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_MAIN_UNION', pin_operation_id);

              pio_select := pio_select || ' UNION ALL ' || v_select_hint || ' DISTINCT ';

              -- add the main columns
              pio_select := pio_select || 'NULL ROW_NUM, NULL ROOT, INSERT_DATA.ENT_LOWER, NULL LVL, INSERT_DATA.ENTITY, NULL ROW_IDENTIFIER';
              -- if the entities used in the operation are the same and the roll up from column is used in the output table
              IF (pin_roll_up_from_type = pin_roll_up_to_type) AND (pin_entity_roll_up_from_column IS NOT NULL) AND (instr(',' || pin_inputview_columns || ',', ',' || pin_entity_roll_up_from_column || ',') < 3 AND pin_ENTITY_FIELD) THEN
                  pio_select := pio_select ||
                              ', INSERT_DATA.ENTITY_INT_ID '
                              || pin_entity_roll_up_from_column;
              END IF;
              -- add the selected columns if the rows are not aggregated
              FOR i IN 1 .. pin_INPUT_DATA_VALUES_NO
              LOOP
                pio_select := pio_select || ', INSERT_DATA.VALUE' || i;
              end LOOP;

              -- filter the records
              pio_select := pio_select || ' FROM ' || CON_INSERT_DATA_TABLE || ' INSERT_DATA
                             WHERE ROOT IS NOT NULL';

         END IF;
       END IF;

       -- add the order by
       pio_select := pio_select || ' ORDER BY ENT_LOWER, ROW_NUM NULLS FIRST';
    END;


    ---------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------

     PROCEDURE CREATE_INSERT_NO_MATCH_ROLL(
                                  pin_inputview_columns               IN VARCHAR2,
                                  pin_no_match_table_columns          IN VARCHAR2,
                                  pin_no_roll_up_table_columns        IN VARCHAR2,
                                  pin_roll_up_from_type               IN NUMBER,
                                  pin_run_id                          IN NUMBER,
                                  pin_date_period_column              IN VARCHAR2,
                                  pin_is_effective_period             IN NUMBER,
                                  pin_process_run_for                 IN NUMBER,
                                  pin_start_period_column             IN VARCHAR2,
                                  pin_inputview_ent_fld               IN VARCHAR2,
                                  pin_period_run_for                  IN NUMBER,
                                  pin_operation_id                    IN NUMBER)
    AS
      CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
      CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;
      CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI'   || pin_run_id;

      V_INSERT                 CLOB;
      v_entity_field           BOOLEAN;
      v_time_unit_id           NUMBER;
      v_hr_timeunit_id         NUMBER;
      V_CORRESP_RUN_FOR        NUMBER;
      v_filter                 CLOB;
      v_insert_hint            CLOB;
      V_INPUT_DATA_ENTITY      VARCHAR2(30);
    BEGIN
         IF (instr(pin_inputview_columns,',') = 0) THEN
            V_INPUT_DATA_ENTITY := pin_inputview_columns;
          ELSE
            V_INPUT_DATA_ENTITY := substr(pin_inputview_columns,1,instr(replace(pin_inputview_columns || ',',' '),',')-1);
          END IF;
         -- check if the roll up is done by entity or field
         V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');
         -- create inner query filter
         IF (pin_date_period_column IS NULL) THEN
            v_filter := '(SELECT 1
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' || pin_roll_up_from_type || '
                          WHERE ' ||
                          case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                            'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')'
                          ELSE
                            'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || '))'
                          END;
         ELSE

           -- get the time units
          RETURN_CORRESP(pin_period_run_for,
                         pin_start_period_column,
                         V_TIME_UNIT_ID,
                         V_HR_TIMEUNIT_ID,
                         V_CORRESP_RUN_FOR);
           -- get the filter
           v_filter := CREATE_DATE_PERIOD_NO(
                                         pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                         pin_is_effective_period => pin_is_effective_period,
                                         pin_process_run_for     => pin_process_run_for,
                                         pin_date_period_column  => pin_date_period_column,
                                         pin_start_period_column => pin_start_period_column
                                         );
            -- create the inner select
            v_filter := '(SELECT 1
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' || pin_roll_up_from_type || '
                          WHERE ' ||
                          case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                           'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_filter || ')'
                          ELSE
                           'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_filter || ')'
                          END;
         END IF;

      -- add the hint framework
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_NO_MATCH', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_NO_MATCH', pin_operation_id);

      IF (pin_no_match_table_columns IS NOT NULL) THEN
           -- create the main insert for no match
           V_INSERT := V_INSERT_hint || ' INTO '
             || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1) ||
             ' (ROW_IDENTIFIER, ROW_VERSION, '
             || substr(pin_no_match_table_columns, instr(pin_no_match_table_columns, ',')+1) ||
             ') SELECT ' || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
            || V_INPUT_DATA_ENTITY
            || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) ||
             ' FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
              WHERE NOT EXISTS ';


         -- add the same filter
         v_insert := v_insert || v_filter;

        -- log the query
        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - v_insert_no_match - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_INSERT),    ',v_insert_no_match => <value>', v_stamp);
        END;

        EXECUTE IMMEDIATE V_INSERT;

      END IF;

      -- add the hint framework
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_NO_ROLL', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_NO_ROLL', pin_operation_id);

      IF (pin_no_roll_up_table_columns IS NOT NULL) THEN
        -- create the main insert for no roll up
         V_INSERT := v_insert_hint || ' INTO '
           || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) ||
           ' (ROW_IDENTIFIER, ROW_VERSION, '
           || substr(pin_no_roll_up_table_columns, instr(pin_no_roll_up_table_columns, ',')+1) ||
           ') SELECT ' || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
           || case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END
            || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) ||
           ' FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
            WHERE EXISTS ';

         -- add the same filter
         v_insert := v_insert || v_filter;

         -- add the row_identifier filter
         v_insert := v_insert || ' AND NOT EXISTS (SELECT 1 FROM ' || CON_INSERT_DATA_TABLE || ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)';

        -- log the query
        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - v_insert_no_roll - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_INSERT),    ',v_insert_no_roll => <value>', v_stamp);
        END;

        EXECUTE IMMEDIATE V_INSERT;

      END IF;

    END CREATE_INSERT_NO_MATCH_ROLL;

    ---------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------

     PROCEDURE CREATE_INSERT_LOWEST(
                                  pin_inputview_ent_fld               IN VARCHAR2,
                                  pin_inputview_columns               IN VARCHAR2,
                                  pin_no_match_table_columns          IN VARCHAR2,
                                  pin_no_roll_up_table_columns        IN VARCHAR2,
                                  pin_roll_up_from_type               IN NUMBER,
                                  pin_run_id                          IN NUMBER,
                                  pin_date_period_column              IN VARCHAR2,
                                  pin_is_effective_period             IN NUMBER,
                                  pin_process_run_for                 IN NUMBER,
                                  pin_start_period_column             IN VARCHAR2,
                                  pin_operation_id                    IN NUMBER)
    AS
      CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
      CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;
      CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI'   || pin_run_id;

      V_INSERT                 CLOB;
      v_entity_field           BOOLEAN;
      v_filter                 CLOB;
      v_filter_select          CLOB;
      v_insert_hint            CLOB;
      v_period_filter          CLOB;
      V_INPUT_DATA_ENTITY      VARCHAR2(30);
    BEGIN

       IF (instr(pin_inputview_columns,',') = 0) THEN
          V_INPUT_DATA_ENTITY := pin_inputview_columns;
        ELSE
          V_INPUT_DATA_ENTITY := substr(pin_inputview_columns,1,instr(replace(pin_inputview_columns || ',',' '),',')-1);
        END IF;
      -- add the hint framework
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_LOW_NO_MATCH', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_LOW_NO_MATCH', pin_operation_id);

     -- check if the roll up is done by entity or field
     V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');

         -- create inner query filter
         IF (pin_date_period_column IS NULL) THEN
            v_filter := '(SELECT 1
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' || pin_roll_up_from_type || '
                          WHERE ' ||
                          case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                           'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')'
                          ELSE
                           'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || '))'
                          END;

            v_filter_select := '(SELECT MAX(1)
                                  FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                                  INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                                  ON E.E_INTERNAL_ID = hi.ENT_UPPER
                                  AND hi.ent_upper_type = ' || pin_roll_up_from_type || '
                                  WHERE ' ||
                                  case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                                   'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')'
                                  ELSE
                                   'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || '))'
                                  END;
         ELSE

           -- get the filter
           v_period_filter := CREATE_DATE_PERIOD_NO(
                                         pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                         pin_is_effective_period => pin_is_effective_period,
                                         pin_process_run_for     => pin_process_run_for,
                                         pin_date_period_column  => pin_date_period_column,
                                         pin_start_period_column => pin_start_period_column
                                         );
            -- create the inner select
            v_filter := '(SELECT 1
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_LOWER
                          AND hi.ent_lower_type = ' || pin_roll_up_from_type || '
                          WHERE ' ||
                          case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                           'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_period_filter || ')'
                          ELSE
                           'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_period_filter || ')'
                          END;

            -- create the inner select
            v_filter_select := '(SELECT MAX(1)
                                  FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                                  INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                                  ON E.E_INTERNAL_ID = hi.ENT_UPPER
                                  AND hi.ent_upper_type = ' || pin_roll_up_from_type || '
                                  WHERE ' ||
                                  case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                                   'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_period_filter || ')'
                                  ELSE
                                   'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_period_filter || ')'
                                  END;
         END IF;

      IF (pin_no_match_table_columns IS NOT NULL) THEN
         -- create the main insert for no match
         V_INSERT := v_insert_hint || ' INTO '
           || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1) ||
           ' (ROW_IDENTIFIER, ROW_VERSION, '
           || substr(pin_no_match_table_columns, instr(pin_no_match_table_columns, ',')+1) ||
           ') SELECT ' || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
           || V_INPUT_DATA_ENTITY
            || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) ||
           ' FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
            WHERE NOT EXISTS ';

         -- add the same filter
         v_insert := v_insert || v_filter;

        -- log the query
        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - v_insert_low_no_match - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_INSERT),    ',v_insert_no_match => <value>', v_stamp);
        END;

        EXECUTE IMMEDIATE V_INSERT;

      END IF;

        -- create the insert for no roll up and no match

        -- add the hint framework
        v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_LOW_BOTH', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_LOW_BOTH', pin_operation_id);

         -- create the main insert for no match and no roll up
         V_INSERT := v_insert_hint || ' FIRST ' ||
         -- add the no roll up case
         case WHEN (pin_no_roll_up_table_columns IS NOT NULL) THEN
         ' WHEN (IS_UPPER IS NULL) THEN INTO '
           || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) ||
           ' (ROW_IDENTIFIER, ROW_VERSION, '
           || substr(pin_no_roll_up_table_columns, instr(pin_no_roll_up_table_columns, ',')+1) ||
           ') VALUES (' || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, entity '
            || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) || ')'
         ELSE '' END ||
           -- add the no match case
         case WHEN (pin_no_match_table_columns IS NOT NULL) THEN
         ' WHEN (IS_UPPER = 1) THEN INTO '
           || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1) ||
           ' (ROW_IDENTIFIER, ROW_VERSION, '
           || substr(pin_no_match_table_columns, instr(pin_no_match_table_columns, ',')+1) ||
           ') VALUES (' || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, entity '
            || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) || ')'
         ELSE '' END ||
           -- add the select
           'SELECT ' || case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END || ' entity ' || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),','))
           || ', ' || v_filter_select || ' IS_UPPER
            FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
            WHERE EXISTS ';

         -- add the same filter
         v_insert := v_insert || v_filter;

         -- add the row_identifier filter
         v_insert := v_insert || ' AND NOT EXISTS (SELECT 1 FROM ' || CON_INSERT_DATA_TABLE || ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)';

        -- log the query
        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - v_insert_low_both - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_INSERT),    ',v_insert_both => <value>', v_stamp);
        END;

        EXECUTE IMMEDIATE V_INSERT;


    END CREATE_INSERT_LOWEST;

    ---------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------

     PROCEDURE CREATE_INSERT_NO_ROLL_ANY(
                                  pin_inputview_columns               IN VARCHAR2,
                                  pin_no_roll_up_table_columns        IN VARCHAR2,
                                  pin_roll_up_from_type               IN NUMBER,
                                  pin_run_id                          IN NUMBER,
                                  pin_date_period_column              IN VARCHAR2,
                                  pin_is_effective_period             IN NUMBER,
                                  pin_process_run_for                 IN NUMBER,
                                  pin_start_period_column             IN VARCHAR2,
                                  pin_inputview_ent_fld               IN VARCHAR2,
                                  pin_period_run_for                  IN NUMBER,
                                  pin_operation_id                    IN NUMBER)
    AS
      CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
      CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;
      CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI'   || pin_run_id;

      V_INSERT                 CLOB;
      v_entity_field           BOOLEAN;
      v_time_unit_id           NUMBER;
      v_hr_timeunit_id         NUMBER;
      V_CORRESP_RUN_FOR        NUMBER;
      v_filter                 CLOB;
      v_insert_hint            CLOB;
    BEGIN

       -- check if the roll up is done by entity or field
       V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');
       -- get the time units
      RETURN_CORRESP(pin_period_run_for,
                     pin_start_period_column,
                     V_TIME_UNIT_ID,
                     V_HR_TIMEUNIT_ID,
                     V_CORRESP_RUN_FOR);
       -- get the filter
       v_filter := CREATE_DATE_PERIOD_NO(
                                     pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                     pin_is_effective_period => pin_is_effective_period,
                                     pin_process_run_for     => pin_process_run_for,
                                     pin_date_period_column  => pin_date_period_column,
                                     pin_start_period_column => pin_start_period_column
                                     );
        -- create the inner select
        v_filter := '(SELECT 1
                      FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                      INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                      ON E.E_INTERNAL_ID = hi.ENT_LOWER
                      AND hi.ent_lower_type = ' || pin_roll_up_from_type || '
                      WHERE ' ||
                      case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                       'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_filter || ')'
                      ELSE
                       'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_filter || ')'
                      END;

      -- add the hint framework
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_NO_ROLL_ANY', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_NO_ROLL_ANY', pin_operation_id);

      IF (pin_no_roll_up_table_columns IS NOT NULL) THEN
        -- create the main insert for no roll up
         V_INSERT := v_insert_hint || ' INTO '
           || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) ||
           ' (ROW_IDENTIFIER, ROW_VERSION, '
           || substr(pin_no_roll_up_table_columns, instr(pin_no_roll_up_table_columns, ',')+1) ||
           ') SELECT ' || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
           || case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END
            || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) ||
           ' FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
            WHERE EXISTS ';

         -- add the same filter
         v_insert := v_insert || v_filter;

         -- add the row_identifier filter
         v_insert := v_insert || ' AND EXISTS (SELECT 1 FROM ' || CON_INSERT_DATA_TABLE || ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)';

        -- log the query
        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - v_insert_no_roll_any - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_INSERT),    ',v_insert_no_roll => <value>', v_stamp);
        END;

        EXECUTE IMMEDIATE V_INSERT;

      END IF;

    END CREATE_INSERT_NO_ROLL_ANY;

    ---------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------

     PROCEDURE CREATE_INSERT_LOWEST_ANY(
                                  pin_inputview_ent_fld               IN VARCHAR2,
                                  pin_inputview_columns               IN VARCHAR2,
                                  pin_no_roll_up_table_columns        IN VARCHAR2,
                                  pin_roll_up_from_type               IN NUMBER,
                                  pin_run_id                          IN NUMBER,
                                  pin_date_period_column              IN VARCHAR2,
                                  pin_is_effective_period             IN NUMBER,
                                  pin_process_run_for                 IN NUMBER,
                                  pin_start_period_column             IN VARCHAR2,
                                  pin_operation_id                    IN NUMBER)
    AS
      CON_INPUT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
      CON_INSERT_DATA_TABLE    CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;
      CON_HIERARCHY_TABLE_NAME CONSTANT VARCHAR2(30) := 'HI'   || pin_run_id;

      V_INSERT                 CLOB;
      v_entity_field           BOOLEAN;
      v_filter                 CLOB;
      v_second_filter          CLOB;
      v_insert_hint            CLOB;
    BEGIN

       -- check if the roll up is done by entity or field
       V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');

       -- get the filter
       v_filter := CREATE_DATE_PERIOD_NO(
                                     pin_ENTITY_FIELD        => v_ENTITY_FIELD,
                                     pin_is_effective_period => pin_is_effective_period,
                                     pin_process_run_for     => pin_process_run_for,
                                     pin_date_period_column  => pin_date_period_column,
                                     pin_start_period_column => pin_start_period_column
                                     );
        -- create the inner select
        v_filter := '(SELECT 1
                      FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                      INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                      ON E.E_INTERNAL_ID = hi.ENT_LOWER
                      AND hi.ent_lower_type = ' || pin_roll_up_from_type || '
                      WHERE ' ||
                      case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                       'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_filter || ')'
                      ELSE
                       'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_filter || ')'
                      END;

      -- create the inner select
      v_second_filter := '(SELECT 1
                          FROM ' || CON_HIERARCHY_TABLE_NAME || ' hi
                          INNER JOIN ' || commons.FIND_ENT_TABLE_NAME('E' || pin_roll_up_from_type) || ' E
                          ON E.E_INTERNAL_ID = hi.ENT_UPPER
                          AND hi.ent_upper_type = ' || pin_roll_up_from_type || '
                          WHERE ' ||
                          case WHEN V_ENTITY_IS_NUMBER = 6 THEN
                           'INPUT_DATA.ENTITY = E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || v_filter || ')'
                          ELSE
                           'UPPER(INPUT_DATA.ENTITY) = UPPER(E.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) || ')' || v_filter || ')'
                          END;

        -- add the hint framework
        v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_LOW_ANY', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_LOW_ANY', pin_operation_id);

                  V_INSERT := v_insert_hint || ' INTO '
           || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) ||
           ' (ROW_IDENTIFIER, ROW_VERSION, '
           || substr(pin_no_roll_up_table_columns, instr(pin_no_roll_up_table_columns, ',')+1) ||
           ') SELECT ' || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1) || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
           || case WHEN v_entity_field THEN 'INPUT_DATA.ENTITY_INT_ID' ELSE 'INPUT_DATA.ENTITY' END
           || substr(pin_inputview_columns,instr(replace(pin_inputview_columns || ',',' '),',')) ||
            ' FROM ' || CON_INPUT_DATA_TABLE || ' INPUT_DATA
              WHERE EXISTS ';

         -- add the same filter
         v_insert := v_insert || v_filter;

         -- add the row_identifier filter
         v_insert := v_insert || ' AND EXISTS (SELECT 1 FROM ' || CON_INSERT_DATA_TABLE || ' insert_data
                                                   WHERE input_data.row_identifier = insert_Data.row_identifier)
            AND NOT EXISTS ';

         -- add the select filter
         v_insert := v_insert || v_second_filter;

        -- log the query
        v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - v_insert_low_any - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        BEGIN
                L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_INSERT),    ',v_insert_both => <value>', v_stamp);
        END;

        EXECUTE IMMEDIATE V_INSERT;


    END CREATE_INSERT_LOWEST_ANY;

    ---------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------
   FUNCTION CREATE_PRIMARY_INSERT(
                                  pin_aggregate_values                IN NUMBER,
                                  pin_primary_table                   IN VARCHAR2,
                                  pin_entity_roll_up_to_column        IN VARCHAR2,
                                  pin_entity_roll_up_from_column      IN VARCHAR2,
                                  pin_levels_rolled_up_column         IN VARCHAR2,
                                  pin_fields_columns                  IN VARCHAR2,
                                  pin_roll_up_from_type               IN NUMBER,
                                  pin_roll_up_to_type                 IN NUMBER,
                                  pin_inputview_ent_fld               IN VARCHAR2,
                                  pin_operation_id                    IN NUMBER
                                  )
          RETURN CLOB
    AS

      V_INSERT              CLOB;
      v_insert_hint         VARCHAR2(32767);

    BEGIN
      -- add the hint framework
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_PRIMARY', pin_operation_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('ROLLUP_HIERARCHY', 'ROLLUP_INSERT_PRIMARY', pin_operation_id);
      -- add the insert condition

      V_INSERT := v_insert_hint || ' INTO '
                  || pin_primary_table ||
                  ' (ROW_IDENTIFIER, ROW_VERSION,'
                  || pin_entity_roll_up_to_column;
      -- if the entity to roll up from must be included in the primary output
      IF (pin_entity_roll_up_from_column IS NOT NULL) THEN
        V_INSERT := V_INSERT || ', ' || pin_entity_roll_up_from_column;
      END IF;
      -- add the levels rolled up if it exists
      IF (pin_levels_rolled_up_column IS NOT NULL) THEN
        V_INSERT := V_INSERT || ', ' || pin_levels_rolled_up_column;
      END IF;
      -- add the fields to roll up
      IF (pin_fields_columns IS NOT NULL) THEN
         V_INSERT := V_INSERT  || ', ' || pin_fields_columns;
      END IF;
      -- the values to be added
      IF (pin_roll_up_from_type = pin_roll_up_to_type) THEN
         V_INSERT := V_INSERT || ') SELECT ' || pin_primary_table || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, NVL(ROOT, ENT_LOWER), ';
      ELSE
         V_INSERT := V_INSERT || ') SELECT ' || pin_primary_table || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, ROOT, ';
      END IF;
      -- if the entity to roll up from must be included in the primary output
      IF (pin_entity_roll_up_from_column IS NOT NULL) THEN
        IF (pin_roll_up_from_type = pin_roll_up_to_type) AND (pin_entity_roll_up_from_column IS NOT NULL) AND regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$') THEN
           V_INSERT := V_INSERT || pin_entity_roll_up_from_column || ', ';
        ELSIF (NOT regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$'))
        THEN
           V_INSERT := V_INSERT || 'ENTITY, ';
        ELSE
           V_INSERT := V_INSERT || 'ENT_LOWER, ';
        END IF;
      END IF;
      -- add the levels rolled up if it exists
      IF (pin_levels_rolled_up_column IS NOT NULL) THEN
        V_INSERT := V_INSERT || 'LVL, ';
      END IF;
      -- add the fields rolled up
      -- if the values are not aggregated
      IF (pin_fields_columns IS NOT NULL) THEN
        IF (pin_aggregate_values = 0) THEN
            FOR i IN 1 .. nvl(regexp_count(pin_fields_columns, ',' ), -1) + 1
            LOOP
              V_INSERT := V_INSERT || 'VALUE' || i || ', ';
            end loop;
        -- if the values are aggregated
        ELSE
          FOR i IN 1 .. nvl(regexp_count(pin_fields_columns, ',' ), -1) + 1
          LOOP
            V_INSERT := V_INSERT || 'TO_SUM' || i || ', ';
          end loop;
        END IF;
      END IF;
     V_INSERT := substr(V_INSERT, 1, length(V_INSERT)-2) || ' FROM (';

     RETURN V_INSERT;

    END CREATE_PRIMARY_INSERT;


    ----------------------------------------------------------------------------------------------
    ----------------------------------------------------------------------------------------------


    PROCEDURE CREATE_SELECT_ROLLUP(
      pin_inputview_columns           IN varchar2,
      pin_rollup_alias_columns        IN VARCHAR2,
      pin_inputview_ent_fld           IN varchar2,
      pin_inputview                   IN clob,
      pin_relationship_tables         IN TABLETYPE_RELATIONSHIP_TABLES,
      pin_include_input_records       IN number,
      pin_roll_up_from_type           IN number,
      pin_roll_up_to_type             IN number,
      pin_level_from                  IN number,
      pin_aggregate_values            IN number,
      pin_level_to                    IN NUMBER,
      pin_date_period_column          IN varchar2,
      pin_new_date_period_column      IN varchar2,
      pin_date_run_for                IN date,
      pin_period_run_for              IN number,
      pin_is_effective_period         IN number,
      pin_start_period_column         IN varchar2,
      pin_end_period_column           IN varchar2,
      pin_process_run_for             IN number,
      pin_entity_roll_up_from_column  IN varchar2,
      pin_fields_columns              IN VARCHAR2,
      pin_operation_id                IN NUMBER,
      pin_run_id                      IN NUMBER,

      pout_primary_select             OUT NOCOPY CLOB)
    AS

      V_INPUT_DATA_ENTITY             varchar2(30);
      V_INPUT_DATA_VALUES_NO          NUMBER(3);
      V_INPUTVIEW_NOROLLUP_COLUMNS    VARCHAR2(32767);
      V_INPUTDATA_NOROLLUP_COLUMNS    VARCHAR2(32767);
      V_A_INPUTVIEW_NOROLLUP_COLUMNS  VARCHAR2(32767);
      V_rollup_alias_columns          VARCHAR2(32767);
      V_IS_FIELD                      NUMBER(1);
      v_ENTITY_FIELD                  BOOLEAN;

      VCOL_INPUT_VIEW_COLUMNS TABLETYPE_COLUMN := TABLETYPE_COLUMN();
      VCOL_INPUT_VIEW_COLUMNS_NA TABLETYPE_COLUMN := TABLETYPE_COLUMN();

    BEGIN

      -- check entity key field type
      SELECT fld_data_type
      INTO   V_ENTITY_IS_NUMBER
      FROM   fields f
      WHERE  f.fld_column_name = commons.FIND_ENT_BUSINESS_KEY_BY_NAME('E' || pin_roll_up_from_type) AND ROWNUM = 1;

      IF (instr(pin_inputview_columns,',') = 0) THEN
        V_INPUTVIEW_NOROLLUP_COLUMNS := '';
        V_INPUTDATA_NOROLLUP_COLUMNS := '';
        -- get the column name of the entity from the input table
        V_INPUT_DATA_ENTITY := pin_inputview_columns;
      ELSE
        V_INPUTVIEW_NOROLLUP_COLUMNS := substr(replace(replace(pin_inputview_columns,' '),',',',a.'),instr(replace(pin_inputview_columns,' '),','));
        V_INPUTDATA_NOROLLUP_COLUMNS := substr(replace(replace(pin_inputview_columns,' '),',',',INPUT_DATA.'),instr(replace(pin_inputview_columns,' '),','));
        -- get the column name of the entity from the input table
        V_INPUT_DATA_ENTITY := substr(pin_inputview_columns,1,instr(replace(pin_inputview_columns || ',',' '),',')-1);
      END IF;
        V_A_INPUTVIEW_NOROLLUP_COLUMNS := replace(replace(pin_inputview_columns,' '),',',',a.');

      -- get the column aliases without the row_identifier
      IF (instr(pin_rollup_alias_columns,',') IS NULL) THEN
        v_rollup_alias_columns := '';
      ELSE
        IF (substr(pin_rollup_alias_columns,1,1) = 'E' OR (V_IS_FIELD=1)) THEN
          V_rollup_alias_columns := replace(pin_rollup_alias_columns,' ');
       ELSE
          V_rollup_alias_columns := substr(replace(pin_rollup_alias_columns,' '),instr(replace(pin_rollup_alias_columns,' '),',')+1);
        END IF;
      END IF;

      -- check if no values to rollup exist
      IF (pin_fields_columns IS NULL) THEN
        V_INPUT_DATA_VALUES_NO := 0;
      ELSE
        -- get the number of columns to roll up values for
        V_INPUT_DATA_VALUES_NO := regexp_count(v_rollup_alias_columns, ',') + 1;
      END IF;

     -- check if the roll up is done by entity or field
     V_ENTITY_FIELD := regexp_like(pin_inputview_ent_fld, '^(E)[0-9]+$');

  ------------------------
  ------------------------

    -- create the hierarchy input table
    CREATE_HIERARCHY_INPUT(
                           pin_is_effective_period          => pin_is_effective_period,
                           pin_date_period_column           => pin_date_period_column,
                           pin_date_run_for                 => pin_date_run_for,
                           pin_relationship_tables          => pin_relationship_tables,
                           pin_process_run_for              => pin_process_run_for,
                           pin_start_period_column          => pin_start_period_column,
                           pin_end_period_column            => pin_end_period_column,
                           pin_period_run_for               => pin_period_run_for,
                           pin_run_id                       => pin_run_id,
                           pin_operation_id                 => pin_operation_id);

    -- create the input data table
    CREATE_INPUT_DATA(
                      pin_roll_up_from_type            => pin_roll_up_from_type,
                      pin_rollup_alias_columns         => pin_rollup_alias_columns,
                      pin_inputview_ent_fld            => pin_inputview_ent_fld,
                      pin_inputview                    => pin_inputview,
                      pin_date_period_column           => pin_date_period_column,
                      pin_new_date_period_column       => pin_new_date_period_column,
                      pin_start_period_column          => pin_start_period_column,
                      pin_fields_columns               => pin_fields_columns,
                      pin_INPUTVIEW_NOROLLUP_COLUMNS   => V_INPUTVIEW_NOROLLUP_COLUMNS,
                      pin_A_INPUTVIEW_NOROLLUP_COLS    => V_A_INPUTVIEW_NOROLLUP_COLUMNS,
                      pin_input_data_entity            => v_input_data_entity,
                      pin_run_id                       => pin_run_id,

                      pio_INPUT_VIEW_COLUMNS           => VCOL_INPUT_VIEW_COLUMNS,
                      pio_INPUT_VIEW_COLUMNS_NA        => VCOL_INPUT_VIEW_COLUMNS_NA);

     -- create connect by table
    CREATE_CBS_DATA(
                    pin_roll_up_to_type            => pin_roll_up_to_type,
                    pin_roll_up_from_type          => pin_roll_up_from_type,
                    pin_level_to                   => pin_level_to,
                    pin_date_period_column         => pin_date_period_column,
                    pin_operation_id               => pin_operation_id,
                    pin_run_id                     => pin_run_id);

    -- create insert data table
    CREATE_INSERT_DATA(PIN_ENTITY_FIELD               => v_ENTITY_FIELD,
                       pin_entity_roll_up_from_column => pin_entity_roll_up_from_column,
                       pin_inputview_columns          => pin_inputview_columns,
                       PIN_ROLL_UP_FROM_TYPE          => PIN_ROLL_UP_FROM_TYPE,
                       PIN_ROLL_UP_TO_TYPE            => PIN_ROLL_UP_TO_TYPE,
                       PIN_LEVEL_FROM                 => PIN_LEVEL_FROM,
                       PIN_DATE_PERIOD_COLUMN         => PIN_DATE_PERIOD_COLUMN,
                       PIN_INPUT_DATA_VALUES_NO       => V_INPUT_DATA_VALUES_NO,
                       PIN_INPUTDATA_NOROLLUP_COLUMNS => V_INPUTDATA_NOROLLUP_COLUMNS,
                       pin_is_effective_period        => pin_is_effective_period,
                       pin_process_run_for            => pin_process_run_for,
                       pin_start_period_column        => pin_start_period_column,
                       PIN_OPERATION_ID               => PIN_OPERATION_ID,
                       PIN_RUN_ID                     => PIN_RUN_ID);


     -- create the main select
     CREATE_MAIN_SELECT(
                           pin_roll_up_from_type                  => pin_roll_up_from_type,
                           pin_roll_up_to_type                    => pin_roll_up_to_type,
                           pin_level_from                         => pin_level_from,
                           pin_entity_roll_up_from_column         => pin_entity_roll_up_from_column,
                           pin_inputview_columns                  => pin_inputview_columns,
                           pin_entity_field                       => v_entity_field,
                           pin_aggregate_values                   => pin_aggregate_values,
                           pin_input_data_values_no               => v_input_data_values_no,
                           pin_INPUT_VIEW_COLUMNS_NA              => VCOL_INPUT_VIEW_COLUMNS_NA,
                           pin_include_input_records              => pin_include_input_records,
                           pin_run_id                             => pin_run_id,
                           pin_operation_id                       => pin_operation_id,

                           pio_select                             => pout_primary_select);

  END CREATE_SELECT_ROLLUP;



  PROCEDURE ROLLUP_THE_HIERARCHY(
      pin_inputview_columns           IN varchar2,
      pin_rollup_alias_columns        IN VARCHAR2,
      pin_inputview_ent_fld           IN varchar2,
      pin_inputview                   IN clob,
      pin_relationship_tables         IN TABLETYPE_RELATIONSHIP_TABLES,
      pin_levels_rolled_up_column     IN varchar2,
      pin_include_input_records       IN number,
      pin_roll_up_from_type           IN number,
      pin_roll_up_to_type             IN number,
      pin_level_from                  IN number,
      pin_aggregate_values            IN number,
      pin_level_to                    IN number,
      pin_no_roll_up_table_columns    IN varchar2,
      pin_no_match_table_columns      IN varchar2,
      pin_is_effective_period         IN number,
      pin_start_period_column         IN varchar2,
      pin_end_period_column           IN varchar2,
      pin_process_run_for             IN number,
      pin_date_period_column          IN varchar2,
      pin_new_date_period_column      IN varchar2,
      pin_entity_roll_up_to_column    IN varchar2,
      pin_entity_roll_up_from_column  IN varchar2,
      pin_fields_columns              IN varchar2,
      pin_output_where_clause         IN clob,
      pin_primary_table               IN varchar2,
      pin_date_run_for                IN date,
      pin_period_run_for              IN number,
      pin_operation_id                IN NUMBER,
      pin_run_id                      IN NUMBER,

      pout_primary_rows               OUT     number,
      pout_no_rollup_rows             OUT     number,
      pout_no_match_rows              OUT     number
    )
  AS

      CON_HIERARCHY_TABLE_NAME  CONSTANT VARCHAR2(30) := 'HI' || pin_run_id;
      CON_CONN_BY_SELECT_NAME   CONSTANT VARCHAR2(30) := 'CBS' || pin_run_id;
      CON_INPUT_DATA       CONSTANT VARCHAR2(30) := 'INPD' || pin_run_id;
      CON_INSERT_DATA_TABLE     CONSTANT VARCHAR2(30) := 'INSD' || pin_run_id;

      v_primary_rows        NUMBER;
      v_no_rollup_rows      NUMBER;
      v_no_match_rows       NUMBER;
      v_query               CLOB;
      v_primary_query       CLOB;


  BEGIN

    v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTVIEW_COLUMNS),    ',PIN_INPUTVIEW_COLUMNS => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_rollup_alias_columns),    ',PIN_ROLLUP_ALIAS_COLUMNS => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTVIEW_ENT_FLD),    ',PIN_INPUTVIEW_ENT_FLD => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_INPUTVIEW),    ',PIN_INPUTVIEW => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_RELATIONSHIP_TABLES),    ',PIN_RELATIONSHIP_TABLES => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LEVELS_ROLLED_UP_COLUMN),    ',PIN_LEVELS_ROLLED_UP_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_INCLUDE_INPUT_RECORDS),    ',PIN_INCLUDE_INPUT_RECORDS => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_ROLL_UP_FROM_TYPE),    ',PIN_ROLL_UP_FROM_TYPE => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_ROLL_UP_TO_TYPE),    ',PIN_ROLL_UP_TO_TYPE => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LEVEL_FROM),    ',PIN_LEVEL_FROM => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_AGGREGATE_VALUES),    ',PIN_AGGREGATE_VALUES => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LEVEL_TO),    ',PIN_LEVEL_TO => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_NO_ROLL_UP_TABLE_COLUMNS),    ',PIN_NO_ROLL_UP_TABLE_COLUMNS => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_NO_MATCH_TABLE_COLUMNS),    ',PIN_NO_MATCH_TABLE_COLUMNS => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_IS_EFFECTIVE_PERIOD),    ',PIN_IS_EFFECTIVE_PERIOD => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_START_PERIOD_COLUMN),    ',PIN_START_PERIOD_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_END_PERIOD_COLUMN),    ',PIN_END_PERIOD_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_PROCESS_RUN_FOR),    ',PIN_PROCESS_RUN_FOR => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_DATE_PERIOD_COLUMN),    ',PIN_DATE_PERIOD_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_NEW_DATE_PERIOD_COLUMN),    ',PIN_NEW_DATE_PERIOD_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_ENTITY_ROLL_UP_TO_COLUMN),    ',PIN_ENTITY_ROLL_UP_TO_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_ENTITY_ROLL_UP_FROM_COLUMN),    ',PIN_ENTITY_ROLL_UP_FROM_COLUMN => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_FIELDS_COLUMNS),    ',PIN_FIELDS_COLUMNS => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_OUTPUT_WHERE_CLAUSE),    ',PIN_OUTPUT_WHERE_CLAUSE => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PRIMARY_TABLE),    ',PIN_PRIMARY_TABLE => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_DATE_RUN_FOR),    ',PIN_DATE_RUN_FOR => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_PERIOD_RUN_FOR),    ',PIN_PERIOD_RUN_FOR => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_OPERATION_ID),    ',PIN_OPERATION_ID => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_RUN_ID),    ',PIN_RUN_ID => <value>', v_stamp);
    END;

    -- get a transaction id to rollback the temp table creation
    V_TX_ID := COMMONS_DDL_HANDLING.get_transaction_id;
    -- get the queries
    CREATE_SELECT_ROLLUP( pin_inputview_columns          =>   pin_inputview_columns,
                          pin_rollup_alias_columns       =>   CASE WHEN pin_rollup_alias_columns IS NULL THEN pin_fields_columns ELSE pin_rollup_alias_columns END,
                          pin_inputview_ent_fld          =>   pin_inputview_ent_fld,
                          pin_inputview                  =>   pin_inputview,
                          pin_relationship_tables        =>   pin_relationship_tables,
                          pin_include_input_records      =>   pin_include_input_records,
                          pin_roll_up_from_type          =>   pin_roll_up_from_type,
                          pin_roll_up_to_type            =>   pin_roll_up_to_type,
                          pin_level_from                 =>   NVL(pin_level_from, 1),
                          pin_aggregate_values           =>   pin_aggregate_values,
                          pin_level_to                   =>   NVL(pin_level_to, 0),
                          pin_is_effective_period        =>   pin_is_effective_period,
                          pin_period_run_for             =>   pin_period_run_for,
                          pin_date_run_for               =>   pin_date_run_for,
                          pin_date_period_column         =>   pin_date_period_column,
                          pin_new_date_period_column     =>   pin_new_date_period_column,
                          pin_start_period_column        =>   pin_start_period_column,
                          pin_end_period_column          =>   pin_end_period_column,
                          pin_process_run_for            =>   pin_process_run_for,
                          pin_entity_roll_up_from_column =>   pin_entity_roll_up_from_column,
                          pin_fields_columns             =>   pin_fields_columns,
                          pin_operation_id               =>   pin_operation_id,
                          pin_run_id                     =>   pin_run_id,

                          pout_primary_select            =>   v_primary_query);

    -- log the query
    v_query := CREATE_PRIMARY_INSERT(
                                          pin_aggregate_values                => pin_aggregate_values,
                                          pin_primary_table                   => pin_primary_table,
                                          pin_entity_roll_up_to_column        => pin_entity_roll_up_to_column,
                                          pin_entity_roll_up_from_column      => pin_entity_roll_up_from_column,
                                          pin_levels_rolled_up_column         => pin_levels_rolled_up_column,
                                          pin_fields_columns                  => pin_fields_columns,
                                          pin_roll_up_from_type               => pin_roll_up_from_type,
                                          pin_roll_up_to_type                 => pin_roll_up_to_type,
                                          pin_inputview_ent_fld               => pin_inputview_ent_fld,
                                          pin_operation_id                    => pin_operation_id)
                || v_primary_query ||
                CASE WHEN (pin_aggregate_values = 1) THEN ') WHERE ROWNO = MAX_ROW_NUM'
                  ELSE ')'
                END;



    v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - query - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query),    ',v_query => <value>', v_stamp);
    END;

    -- check the cardinality
    commons.terminate_insane_query(v_query, pin_run_id);

    EXECUTE IMMEDIATE v_query;

     -- save the total number of rows
     v_primary_rows := SQL%ROWCOUNT;

     -- delete the filtered rows
     IF (pin_output_where_clause IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'DELETE FROM ' || pin_primary_table || ' WHERE ROW_IDENTIFIER NOT IN (' || pin_output_where_clause ||  ')';
        -- remove the deleted rows
        v_primary_rows := v_primary_rows - SQL%ROWCOUNT;
     END IF;

     -- if an additional table is selected
     IF (pin_no_match_table_columns IS NOT NULL OR pin_no_roll_up_table_columns IS NOT NULL) THEN
           IF (pin_level_from = 0) THEN
             -- if the lowest values are selected
             CREATE_INSERT_LOWEST(
                                  pin_inputview_ent_fld               => pin_inputview_ent_fld,
                                  pin_inputview_columns               => pin_inputview_columns,
                                  pin_no_match_table_columns          => pin_no_match_table_columns,
                                  pin_no_roll_up_table_columns        => pin_no_roll_up_table_columns,
                                  pin_roll_up_from_type               => pin_roll_up_from_type,
                                  pin_run_id                          => pin_run_id,
                                  pin_is_effective_period             => pin_is_effective_period,
                                  pin_process_run_for                 => pin_process_run_for,
                                  pin_date_period_column              => pin_date_period_column,
                                  pin_start_period_column             => pin_start_period_column,
                                  pin_operation_id                    => pin_operation_id
                                         );
             -- if any option is selected
             IF (pin_period_run_for = 2) THEN
               CREATE_INSERT_LOWEST_ANY(
                                    pin_inputview_ent_fld               => pin_inputview_ent_fld,
                                    pin_inputview_columns               => pin_inputview_columns,
                                    pin_no_roll_up_table_columns        => pin_no_roll_up_table_columns,
                                    pin_roll_up_from_type               => pin_roll_up_from_type,
                                    pin_run_id                          => pin_run_id,
                                    pin_is_effective_period             => pin_is_effective_period,
                                    pin_process_run_for                 => pin_process_run_for,
                                    pin_date_period_column              => pin_date_period_column,
                                    pin_start_period_column             => pin_start_period_column,
                                    pin_operation_id                    => pin_operation_id
                                           );
             END IF;
           ELSE
           -- if all values option was selected
             CREATE_INSERT_NO_MATCH_ROLL(
                                  pin_inputview_columns               => pin_inputview_columns,
                                  pin_no_match_table_columns          => pin_no_match_table_columns,
                                  pin_no_roll_up_table_columns        => pin_no_roll_up_table_columns,
                                  pin_roll_up_from_type               => pin_roll_up_from_type,
                                  pin_run_id                          => pin_run_id,
                                  pin_is_effective_period             => pin_is_effective_period,
                                  pin_process_run_for                 => pin_process_run_for,
                                  pin_date_period_column              => pin_date_period_column,
                                  pin_start_period_column             => pin_start_period_column,
                                  pin_inputview_ent_fld               => pin_inputview_ent_fld,
                                  pin_period_run_for                  => pin_period_run_for,
                                  pin_operation_id                    => pin_operation_id
                                         );
             -- if any option is selected
             IF (pin_period_run_for = 2) THEN
               CREATE_INSERT_NO_ROLL_ANY(
                                    pin_inputview_columns               => pin_inputview_columns,
                                    pin_no_roll_up_table_columns        => pin_no_roll_up_table_columns,
                                    pin_roll_up_from_type               => pin_roll_up_from_type,
                                    pin_run_id                          => pin_run_id,
                                    pin_is_effective_period             => pin_is_effective_period,
                                    pin_process_run_for                 => pin_process_run_for,
                                    pin_date_period_column              => pin_date_period_column,
                                    pin_start_period_column             => pin_start_period_column,
                                    pin_inputview_ent_fld               => pin_inputview_ent_fld,
                                    pin_period_run_for                  => pin_period_run_for,
                                    pin_operation_id                    => pin_operation_id
                                           );
             END IF;
           END IF;
           IF (pin_no_roll_up_table_columns IS NOT NULL) THEN
             -- count all records
             EXECUTE IMMEDIATE 'SELECT COUNT(*)
                               FROM ' || substr(pin_no_roll_up_table_columns, 1, instr(pin_no_roll_up_table_columns, ',')-1)
             INTO v_no_rollup_rows;
           END IF;

           IF (pin_no_match_table_columns IS NOT NULL) THEN
             -- count all the records
             EXECUTE IMMEDIATE 'SELECT COUNT(*)
                               FROM ' || substr(pin_no_match_table_columns, 1, instr(pin_no_match_table_columns, ',')-1)
             INTO v_no_match_rows;
          END IF;

     END IF;


    -- add the values in the output parameters
    pout_primary_rows   := v_primary_rows;
    pout_no_rollup_rows := v_no_rollup_rows;
    pout_no_match_rows  := v_no_match_rows;

    v_stamp := 'ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY - output - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log the output parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_no_rollup_rows),    ',pout_no_rollup_rows => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_no_match_rows),    ',pout_no_match_rows => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_primary_rows),    ',pout_primary_rows => <value>', v_stamp);
    END;

    -- clean the undo_ddl_log
    COMMONS_DDL_HANDLING.CLEAN_DDL_LOG(PI_TRANSACTION_ID => V_TX_ID);
    -- drop the created tables
    for i in (select table_name from user_tables where table_name in (CON_HIERARCHY_TABLE_NAME, CON_INPUT_DATA, CON_CONN_BY_SELECT_NAME, CON_INSERT_DATA_TABLE))
    loop
      COMMONS_DDL_HANDLING.execute_ddl_nolog('DROP TABLE ' || i.table_name);
    end loop;

  EXCEPTION
    WHEN OTHERS THEN
      -- rollback all the temp table creation
      ROLLBACK;
      COMMONS_DDL_HANDLING.ROLLBACK_DDL(PI_TRANSACTION_ID => V_TX_ID);
      COMMONS_DDL_HANDLING.CLEAN_DDL_LOG(PI_TRANSACTION_ID => V_TX_ID);
      raise_application_error(-20001, SUBSTR(SQLERRM, 1, 1000));

  END ROLLUP_THE_HIERARCHY;


  END ROLLUP_HIERARCHY;
/
