CREATE package body merge_fields as

  procedure run_merge_fields(pin_operation_id        in number,
                             pin_inputs              in tabletype_dt_mf_table_list,
                             pin_column_mappings     in tabletype_dt_mf_col_map_list,
                             pin_outputs             in tabletype_id_name,
                             pin_outputs_structure   in tabletype_dt_mf_id_name_alias,
                             pin_period_filter_joins in clob,
                             pin_output_filter       in clob,
                             pin_run_data_id         in number,
                             pin_autotune_option     in number default null,
                             pout_invalid_records   out sys_refcursor,
                             pout_record_count      out sys_refcursor) is
    v_primary_output            varchar2(30 char);
    v_initial_input             clob;
    v_initial_input_unmatched   clob;
    v_initial_input_multiple    clob;
    v_initial_input_card        varchar2(100);
    v_insert_clause             clob;
    v_select_clause             clob;
    v_join_types                clob;
    v_from_clause               clob;
    v_where_clause              clob;
    v_transaction_id            varchar2(30 char);
    v_intermed_table            varchar2(30 char);
    v_intermed_table_clause     clob;
    v_intermed_undo_clause      clob;
    v_intermed_seq_clause       clob;
    v_intermed_seq_undo_clause  clob;
    v_insert_clause_no_filter   clob;
    v_initial_input_table       varchar2(30 char);
    v_unmatched_exists          integer;
    v_unmatched_output          varchar2(30 char);
    v_unmatched_clause          clob;
    v_unmatched_input           varchar2(30 char);
    v_multiple_exists           integer;
    v_multiple_output           varchar2(30 char);
    v_multiple_clause           clob;
    v_multiple_input            varchar2(30 char);
    v_validations_sql           clob;
    v_record_count_clause       clob;
    v_primary_count             integer;
    v_unmatched_count           integer;
    v_multiple_count            integer;
    v_stop_process              integer := 0;
    v_initial_row_id_alias      varchar2(30 char);
    v_initial_row_id_output     varchar2(30 char);
    v_inputs                    tabletype_dt_op_inputs;
    v_inputs_cardinality        tabletype_dt_op_inputs_card;
    v_stamp	                    L4O_LOGS.L4OL_IDENTIFIER%TYPE;
  begin
    -- log input parameters
    v_stamp := 'MERGE_FIELDS.RUN_MERGE_FIELDS:'||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operation_id) ,',pin_operation_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_inputs) ,',pin_inputs => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_column_mappings) ,',pin_column_mappings => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_outputs) ,',pin_outputs => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_outputs_structure) ,',pin_outputs_structure => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_period_filter_joins) ,',pin_period_filter_joins => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_output_filter) ,',pin_output_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_run_data_id) ,',pin_run_data_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_autotune_option) ,',pin_autotune_option => <value>', v_stamp);
    -- add auto tune hints
    if pin_autotune_option is not null then
      -- if option 0 was selected then remove all existing hints
      if pin_autotune_option = 0 then
        commons_processing.remove_hints(pin_operation_id);
      else
        -- for options 1-6 add corresponding hints
        commons_processing.remove_hints(pin_operation_id);
        commons_processing.add_autotune_hints(pin_operation_id,pin_autotune_option);
      end if;
      commons_processing.log_autotune_run(pin_run_data_id,pin_autotune_option);
    end if;
    -- build select clause
    v_select_clause :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('MERGEFIELDS', 'MERGE_FIELDS_PRIMARY_SELECT', pin_operation_id) ||
                        ' select ' ||
                        COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_PRIMARY_SELECT', pin_operation_id, null);
    -- add hints for join types per each input
    for c in (select input_number, input_alias
                from table(pin_inputs)
               order by input_number) loop
      v_join_types := v_join_types ||
                         regexp_replace(COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_<' || c.input_number || '>_JOIN', pin_operation_id, null),
                                        '<' || c.input_number || '>',
                                        c.input_alias,
                                        1,
                                        1);
    end loop;
    if v_join_types is not null then
      v_join_types := '/*+' || replace(replace(v_join_types,'/*+',''),'*/','') || '*/';
      v_select_clause := v_select_clause || ' ' || v_join_types;
    end if;
    for c in (select existence_check, column_name, alias_value, is_boolean, input_number, mapping_value from table(pin_column_mappings) order by column_order) loop
      v_select_clause := v_select_clause || case when c.existence_check is null
                                                 then case when c.is_boolean = 1
                                                           then 'nvl('
                                                       end || case when c.input_number < 0
                                                                   then c.mapping_value
                                                                   else c.alias_value
                                                               end || case when c.is_boolean = 1
                                                                           then ',0)'
                                                                           end || ' ' || c.column_name || ','
                                                 else 'case when ' || case when c.is_boolean = 1
                                                                           then 'nvl('
                                                                       end || case when c.input_number < 0
                                                                                   then c.mapping_value
                                                                                   else c.alias_value
                                                                               end || case when c.is_boolean = 1
                                                                                           then ',0)'
                                                                                       end || ' is null or ' || c.existence_check || ' is not null then ' || c.existence_check || ' else 1/0 end' || ' ' || c.column_name || ','
                                             end;
    end loop;
    v_select_clause := substr(v_select_clause,1,length(v_select_clause)-1);
    -- build from clause
   select objtype_dt_op_inputs(INPUT_ID, DTIN_DTOUT_ID, TABLE_NAME, TABLE_ALIAS)
      bulk collect into v_inputs
      from table(pin_inputs)
      join DT_INPUTS on INPUT_ID = DTIN_ID
     where DTIN_DTOUT_ID is not null;
    data_transformation_processing.get_inputs_cardinality(v_inputs,
                                                          v_inputs_cardinality);
    select max(CARDINAL_HINT)
      into v_initial_input_card
      from table(pin_inputs) i
      join table(v_inputs_cardinality) ic on i.INPUT_ID = ic.INPUT_ID
     where table_type = 1;
    select regexp_replace(input_filter,
                          'SELECT',
                          COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('MERGEFIELDS', 'MERGE_FIELDS_INITIAL_INPUT', pin_operation_id) ||
                          'SELECT ' || COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_INITIAL_INPUT', pin_operation_id, v_initial_input_card),
                          1,
                          1),
           regexp_replace(input_filter,
                          'SELECT',
                          COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('MERGEFIELDS', 'MERGE_FIELDS_INITIAL_UNMATCHED', pin_operation_id) ||
                          'SELECT ' || COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_INITIAL_UNMATCHED', pin_operation_id, v_initial_input_card),
                          1,
                          1),
           regexp_replace(input_filter,
                          'SELECT',
                          COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('MERGEFIELDS', 'MERGE_FIELDS_INITIAL_MULTIPLE', pin_operation_id) ||
                          'SELECT ' || COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_INITIAL_MULTIPLE', pin_operation_id, v_initial_input_card),
                          1,
                          1)
      into v_initial_input, v_initial_input_unmatched, v_initial_input_multiple
      from table(pin_inputs)
     where table_type = 1;
    v_from_clause := ' from ' || v_initial_input;
    for c in (select join_type, input_filter, join_clause, input_alias, table_name, table_alias, CARDINAL_HINT, input_number
                from table(pin_inputs) i
                left join table(v_inputs_cardinality) ic on i.INPUT_ID = ic.INPUT_ID
               where table_type = 2
               order by input_number) loop
      v_from_clause := v_from_clause || ' ' || case when c.join_clause is not null
                                                    then c.join_type
                                                    else 'cross join'
                                                end || ' ' || regexp_replace(c.input_filter,
                                                                             'SELECT',
                                                                             'SELECT ' || regexp_replace(COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_<' || c.input_number || '>_INPUT', pin_operation_id, c.CARDINAL_HINT),
                                                                                                         '<' || c.input_number || '>',
                                                                                                         c.table_alias,
                                                                                                         1,
                                                                                                         1),
                                                                             1,
                                                                             1)  ||
                                        ' ' || case when c.join_clause is not null
                                                    then ' on ' || c.join_clause
                                                end;
    end loop;
    -- build where clause
    v_where_clause := case when pin_output_filter is not null then ' where ' || pin_output_filter end;
    -- build insert clause for primary output
    select table_name into v_initial_input_table from table(pin_inputs) where table_type = 1;
    select name into v_primary_output from table(pin_outputs) where id = 3;
    v_insert_clause := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('MERGEFIELDS', 'MERGE_FIELDS_PRIMARY_INSERT', pin_operation_id) ||
                       ' insert ' ||
                       COMMONS_PROCESSING.GET_HINTS('MERGEFIELDS', 'MERGE_FIELDS_PRIMARY_INSERT', pin_operation_id, null);
    -- if there are no additional outputs and therefore no need to query the primary output use APPEND hint
    select count(1) into v_unmatched_exists from (select rownum from table(pin_outputs) where id = 5) where rownum <= 1;
    select count(1) into v_multiple_exists from (select rownum from table(pin_outputs) where id = 6) where rownum <= 1;
    if v_unmatched_exists = 0 and v_multiple_exists = 0 and pin_output_filter is null then
      v_insert_clause := v_insert_clause || ' /*+ APPEND */ ';
    end if;
    v_insert_clause := v_insert_clause || ' into ' || v_primary_output || '(';
    for c in (select column_name from table(pin_column_mappings) order by column_order) loop
      v_insert_clause := v_insert_clause || c.column_name || ',';
    end loop;
    v_insert_clause := v_insert_clause || 'ROW_IDENTIFIER,ROW_VERSION,';
    for c in (select row_identifier_output from table(pin_inputs) order by input_number) loop
      v_insert_clause := v_insert_clause || c.row_identifier_output || ',';
    end loop;
    v_insert_clause := substr(v_insert_clause,1,length(v_insert_clause)-1) || ') ' || v_select_clause || case when substr(v_select_clause,length(v_select_clause)-5) = 'select' then ' ' else ',' end || v_primary_output || '_ROW_IDENTIFIER_SEQ.NEXTVAL,0,';
    for c in (select row_identifier_alias from table(pin_inputs) order by input_number) loop
      v_insert_clause := v_insert_clause || c.row_identifier_alias || ',';
    end loop;
    select row_identifier_alias, row_identifier_output into v_initial_row_id_alias, v_initial_row_id_output from table(pin_inputs) where table_type = 1;
    v_insert_clause := substr(v_insert_clause,1,length(v_insert_clause)-1) || ' ' || v_from_clause || ' ' || pin_period_filter_joins;

    if pin_output_filter is not null and (v_unmatched_exists = 1 or v_multiple_exists = 1) then
      v_transaction_id := commons_ddl_handling.get_transaction_id;
      v_intermed_table := 'MF_' || pin_run_data_id;
      v_intermed_table_clause := 'create table ' || v_intermed_table || ' tablespace ' || user || '_out as select * from ' || v_primary_output || ' where 1 = 0';
      v_intermed_undo_clause := 'begin for c in (select 1 from user_tables where table_name = ''' || v_intermed_table || ''') loop execute immediate ''drop table ' || v_intermed_table || '''; end loop; end;';

      v_intermed_seq_clause := 'create sequence ' || v_intermed_table || '_ROWID_SEQ minvalue 1 maxvalue 9999999999999999999999999999 start with 1 increment by 1 cache 10000';
      v_intermed_seq_undo_clause := 'begin for c in (select 1 from user_sequences where sequence_name = ''' || v_intermed_table || '_ROWID_SEQ'') loop execute immediate ''drop sequence ' || v_intermed_table || '_ROWID_SEQ''; end loop; end;';

      v_insert_clause_no_filter := replace(v_insert_clause, v_primary_output || '_ROW_IDENTIFIER_SEQ.NEXTVAL', v_intermed_table || '_ROWID_SEQ.NEXTVAL');
      v_insert_clause_no_filter := replace(v_insert_clause_no_filter,v_primary_output,v_intermed_table);
    end if;

    v_insert_clause := v_insert_clause || v_where_clause;

    -- build insert clause for unmatched records additional output
    if v_unmatched_exists = 1 then
      if pin_output_filter is not null then
        v_unmatched_input := v_intermed_table;
      else
        v_unmatched_input := v_primary_output;
      end if;
      select name into v_unmatched_output from table(pin_outputs) where id = 5;
      v_unmatched_clause := 'insert /*+ APPEND */ into ' || v_unmatched_output || '(';
      for c in (select name from table(pin_outputs_structure) order by id) loop
        v_unmatched_clause := v_unmatched_clause || c.name || ',';
      end loop;
      v_unmatched_clause := v_unmatched_clause || 'ROW_IDENTIFIER,ROW_VERSION) ' || ' select ';
      for c in (select alias from table(pin_outputs_structure) order by id) loop
        v_unmatched_clause := v_unmatched_clause || c.alias || ',';
      end loop;
      v_unmatched_clause := v_unmatched_clause || v_unmatched_output || '_ROW_IDENTIFIER_SEQ.NEXTVAL,0 from (select /*+ CARDINALITY(' || v_unmatched_input || ' ' || v_primary_count || ')*/ * from ' || v_initial_input_unmatched || ') ' || v_initial_input_table || ' left join ' || v_unmatched_input || ' on ' || v_initial_input_table || '.'|| v_initial_row_id_alias || ' = ' || v_unmatched_input || '.' || v_initial_row_id_output || ' where ';
      for c in (select row_identifier_output from table(pin_inputs) order by input_number) loop
        v_unmatched_clause := v_unmatched_clause || v_unmatched_input || '.' || c.row_identifier_output || ' is null or ';
      end loop;
      v_unmatched_clause := substr(v_unmatched_clause,1,length(v_unmatched_clause)-4);
    end if;

    -- build insert clause for multiple matches additional output
    if v_multiple_exists = 1 then
      if pin_output_filter is not null then
        v_multiple_input := v_intermed_table;
      else
        v_multiple_input := v_primary_output;
      end if;
      select name into v_multiple_output from table(pin_outputs) where id = 6;
      v_multiple_clause := 'insert /*+ APPEND */ into ' || v_multiple_output || '(';
      for c in (select name from table(pin_outputs_structure) order by id) loop
        v_multiple_clause := v_multiple_clause || c.name || ',';
      end loop;
      v_multiple_clause := v_multiple_clause || 'ROW_IDENTIFIER,ROW_VERSION) ' || ' select ';
      for c in (select alias from table(pin_outputs_structure) order by id) loop
        v_multiple_clause := v_multiple_clause || c.alias || ',';
      end loop;
      v_multiple_clause := v_multiple_clause || v_multiple_output || '_ROW_IDENTIFIER_SEQ.NEXTVAL,0 from (select * from ' || v_initial_input_multiple || ') ' || v_initial_input_table ||
      ' join (select /*+ CARDINALITY(' || v_multiple_input || ' ' || v_primary_count || ')*/ ' || v_initial_row_id_output || ' from ' || v_multiple_input || ' group by ' || v_initial_row_id_output || ' having count(*) > 1) ass on ass.' || v_initial_row_id_output || ' = ' || v_initial_input_table || '.' || v_initial_row_id_alias;
    end if;

    -- execute insert clauses for primary output
    begin

      -- if we have output filter we need to create an intermmediate table with the same structure as the primary output table
      if pin_output_filter is not null and (v_unmatched_exists = 1 or v_multiple_exists = 1) then
        begin
          commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                           pi_description    => 'Create temporary intermmediate output for Merge Fields processing',
                                           pi_ddl            => v_intermed_table_clause,
                                           pi_undo_ddl       => v_intermed_undo_clause,
                                           pi_run_id         => pin_run_data_id,
                                           pi_resource_id    => null);
          commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                           pi_description    => 'Create sequence for temporary intermmediate output for Merge Fields processing',
                                           pi_ddl            => v_intermed_seq_clause,
                                           pi_undo_ddl       => v_intermed_seq_undo_clause,
                                           pi_run_id         => pin_run_data_id,
                                           pi_resource_id    => null);
          commons_ddl_handling.clean_ddl_log(pi_transaction_id => v_transaction_id, pi_run_id => null);
        exception
          when others then
            commons_ddl_handling.rollback_ddl(pi_transaction_id => v_transaction_id, pi_run_id => null);
            commons_ddl_handling.clean_ddl_log(pi_transaction_id => v_transaction_id, pi_run_id => null);
        end;
      end if;

      --logg('v_insert_clause: ' || v_insert_clause);
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, v_insert_clause);
      -- check if the estimated execution time for the query exceeds a treshold
      commons.terminate_insane_query(v_insert_clause, pin_run_data_id);
      -- log session stats
      COMMONS_PROCESSING.EXEC_START_PROC_TRANSACTION(pin_run_id => pin_run_data_id,
                                                     pin_definition_id => pin_operation_id);
      execute immediate v_insert_clause;
      v_primary_count := sql%rowcount;
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id => pin_run_data_id);

      -- if we have output filter then we insert the data from the intermmediate table in the primary output result table using the output filter
      if pin_output_filter is not null and (v_unmatched_exists = 1 or v_multiple_exists = 1) then
        --logg('v_insert_clause_no_filter: ' || v_insert_clause_no_filter);
        execute immediate v_insert_clause_no_filter;
      end if;

      open pout_invalid_records for select null input_number, null column_name, null record_number, null record_values, null column_order from dual;

      exception
        when zero_divide then
          -- when insert fails because of incorrect mapping between entities and fields stop process and return cursor with invalid records
          v_stop_process := 1;
          v_validations_sql := 'with x as (select ';
          for c in (select alias_value, mapping_value, existence_check, column_name, column_order, input_number from table(pin_column_mappings) where existence_check is not null order by column_order) loop
            v_validations_sql := v_validations_sql || case when c.input_number < 0
                                                           then c.mapping_value || ' ' || c.alias_value || '#' || c.column_order || ',' || c.existence_check || ' ' || c.column_name || ','
                                                           else c.alias_value || ' ' || c.mapping_value || '#' || c.column_order || ',' || c.existence_check || ' ' || c.column_name || ','
                                                       end;
          end loop;
          v_validations_sql := substr(v_validations_sql,1,length(v_validations_sql)-1) || v_from_clause || ' ' || pin_period_filter_joins || v_where_clause || ')' || 'select input_number, column_order, record_values from (' || 'select input_number, field column_name, sufix, column_order, listagg_java(OBJTYPE_WORD_DLM(value,'';'',1000)) record_values from ' || '(select distinct input_number, field, value, sufix, column_order from (';
          for c in (select alias_value, mapping_value, existence_check, column_name, column_order, input_number from table(pin_column_mappings) where existence_check is not null order by column_order) loop
            v_validations_sql := v_validations_sql || ' select ''' || case when c.input_number < 0
                                                                           then c.alias_value
                                                                           else c.mapping_value
                                                                       end || '#' || c.column_order || ''' field, to_char(' || case when c.input_number < 0
                                                                                                                                    then c.alias_value
                                                                                                                                    else c.mapping_value
                                                                                                                                end || '#' || c.column_order || ') value, ''' || '#' || c.column_order || ''' sufix, ' || c.column_order || ' column_order from x where ' || c.column_name || ' is null union all';
          end loop;
          v_validations_sql := substr(v_validations_sql,1,length(v_validations_sql)-9) || ') fields join (';
          for c in (select input_number, mapping_value, alias_value, column_order from table(pin_column_mappings) where existence_check is not null order by column_order) loop
            v_validations_sql := v_validations_sql || ' select ' || c.input_number || ' input_number, ''' || case when c.input_number < 0
                                                                                                                  then c.alias_value
                                                                                                                  else c.mapping_value
                                                                                                              end || '#' || c.column_order || ''' mapping_value from dual union all';
          end loop;
          v_validations_sql := substr(v_validations_sql,1,length(v_validations_sql)-9) || ') inputs on field = mapping_value) group by input_number, field, sufix, column_order)';
          --dbms_output.put_line(substr(v_validations_sql,1,1000));
          --dbms_output.put_line(substr(v_validations_sql,1001,1000));
          --dbms_output.put_line(substr(v_validations_sql,2001,1000));
          --logg(v_validations_sql);
          open pout_invalid_records for v_validations_sql;
          open pout_record_count for select null id, null no from dual;
    end;

    if v_stop_process != 1 then

      -- execute insert clause for unmatched records additional output
      if v_unmatched_exists = 1 then
        --logg(v_unmatched_clause);
        execute immediate v_unmatched_clause;
        v_unmatched_count := sql%rowcount;
		    COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id => pin_run_data_id);
      end if;

      -- execute insert clause for multiple matches additional output
      if v_multiple_exists = 1 then
        --logg(v_multiple_clause);
        execute immediate v_multiple_clause;
        v_multiple_count := sql%rowcount;
		    COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id => pin_run_data_id);
      end if;

      if pin_output_filter is not null and (v_unmatched_exists = 1 or v_multiple_exists = 1) then
        -- register them as temp resources (tr_lifecycle = 0 means that is owned by a process and will be purged in post execution)
        insert into TEMP_RESOURCES(TR_ID,TR_NAME,TR_TYPE,TR_LIFECYCLE,TR_RUN_ID,TR_TRANSACTION_ID,TR_LOCATION)
        values(uid_sequence.nextval,v_intermed_table,2,0,pin_run_data_id,v_transaction_id,0);
      end if;

    end if;

    -- log session stats
    COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_run_id => pin_run_data_id,
                                                 pin_definition_id => pin_operation_id);

    if v_stop_process != 1 then

      -- build record count validation clause
      v_record_count_clause := 'select 3 id, ' || v_primary_count || ' no from dual';
      if v_unmatched_exists = 1 then
        v_record_count_clause := v_record_count_clause || ' union all select 5, ' || v_unmatched_count || ' from dual';
      end if;
      if v_multiple_exists = 1 then
        v_record_count_clause := v_record_count_clause || ' union all select 6, ' ||v_multiple_count  || ' from dual';
      end if;
      --dbms_output.put_line(v_record_count_clause);
      open pout_record_count for v_record_count_clause;

    end if;

  end run_merge_fields;

end merge_fields;
/
