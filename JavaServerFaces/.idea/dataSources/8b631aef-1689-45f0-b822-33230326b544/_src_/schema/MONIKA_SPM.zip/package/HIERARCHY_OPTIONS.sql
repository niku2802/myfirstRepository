CREATE PACKAGE HIERARCHY_OPTIONS AS

  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2015 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : PORTAL
  -- Module   : HIERARCHY
  -- Description    :
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  -- ############################# DELETE_HIERARCHY START #############################
  -- Author     :
  -- Create date:
  -- Reviewer :
  -- Review date:
  -- Description: Function for Delete Hierarchy
   -----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Deletes from Portal Hierarchy
      -- Input Parameters:
      --    ->> INPUT
--pin_upper_entity_value (internal id)
--pin_upper_entity_id
--pin_start_date_of_delete (date, even if it is period)
--pin_end_date_of_delete
--pin_is_effective_period (1 for period, 0 for date, null for not effective dated)
--pin_upper_start_period_column (for period, the columns' name from fields, ex 'start quarter')
--pin_upper_end_period_column
--pin_time_unit_id (for period, time unit to use)
--PIN_NEW_PARENT_ENTITY_VALUE (the internal id of the new parent)
--PIN_RELATIONSHIP_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES)
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name
--PIN_RELATIONSHIP_MOVE_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES)
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name

--->> OUTPUT
--pout_inserted_rows (TYPE TABLETYPE_ID_NAME)
--                - row_id
--                - table name
--pout_updated_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_deleted_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_scn (number)
--pout_update_validation - Returns 0 if the validations pass, 1 if there are cycles or 2 if there is an entity with more than one parent

   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      DECLARE
      POUT_INSERTED_ROWS TABLETYPE_ID_NAME;
      POUT_UPDATED_ROWS TABLETYPE_ID_NAME;
      POUT_DELETED_ROWS TABLETYPE_ID_NAME;
      POUT_SCN NUMBER;
	  POUT_UPDATE_VALIDATION NUMBER;
      BEGIN
      DELETE_FROM_HIERARCHY.DELETE_HIERARCHY(PIN_UPPER_ENTITY_VALUE => 2,
             PIN_UPPER_ENTITY_ID => 190647,
             PIN_START_DATE_OF_DELETE => TO_DATE('1/1/2015','mm/dd/yyyy'),
             PIN_END_DATE_OF_DELETE => TO_DATE('1/1/2018','mm/dd/yyyy'),
             PIN_IS_EFFECTIVE_PERIOD => 0,
             PIN_TIME_UNIT_ID => NULL,
             PIN_UPPER_START_PERIOD_COLUMN => NULL,
             PIN_UPPER_END_PERIOD_COLUMN => NULL,
             PIN_NEW_PARENT_ENTITY_VALUE => 6,
             PIN_RELATIONSHIP_TABLES => TABLETYPE_RELATIONSHIP_TABLES(
             OBJTYPE_RELATIONSHIP_TABLE(' T200000', 190647, 190647, 'E190714', 'E190713'),
             OBJTYPE_RELATIONSHIP_TABLE('T200001', 190647, 190647, 'E190713', 'E190712'),
             OBJTYPE_RELATIONSHIP_TABLE('T200002', 190647, 190647, 'E190713', 'E190711')),
             PIN_RELATIONSHIP_MOVE_TABLES => TABLETYPE_RELATIONSHIP_TABLES(
             OBJTYPE_RELATIONSHIP_TABLE(' T200000', 190647, 190647, 'E190714', 'E190713'),
             OBJTYPE_RELATIONSHIP_TABLE('T200001', 190647, 190647, 'E190713', 'E190712'),
             OBJTYPE_RELATIONSHIP_TABLE('T200002', 190647, 190647, 'E190713', 'E190711')),
             POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
             POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
             POUT_DELETED_ROWS => POUT_DELETED_ROWS,
             POUT_SCN => POUT_SCN,
             POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION)

      END;
         */
   -----------------------------------------------------------------------------------------------

PROCEDURE DELETE_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
pin_upper_entity_id    NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

);


  -- ############################# MOVE_HIERARCHY START #############################
  -- Author     :
  -- Create date:
  -- Reviewer :
  -- Review date:
  -- Description: Functions for Move Hierarchy
   -----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Moves in Portal Hierarchy
      -- Input Parameters:
      --    ->> INPUT
-- PIN_upper_entity_rowid the row id of the record to be moved
-- PIN_OLD_REL_START_DATE the start date entered for the old relationship of the moved entity (date, even if it is period)
-- PIN_OLD_REL_END_DATE
-- PIN_NEW_REL_START_DATE the end date entered for the new relationship of the moved entity (date, even if it is period)
-- PIN_NEW_REL_END_DATE
-- PIN_OLD_RELATIONSHIP the action for the old relationship (1 for retain, 2 for delete, 3 for update)
-- PIN_NEW_PARENT_ENTITY_VALUE the new parent's internal id
-- PIN_SUBORDINATE_PARENT_VALUE the new parent's internal id (for the record's childs)
-- PIN_RELATIONSHIP_MOVE_TABLE the tabel for the new relationship
--pin_upper_entity_value (internal id)
--pin_start_date_of_delete (date, even if it is period)
--pin_end_date_of_delete
--pin_is_effective_period (1 for period, 0 for date, null for not effective dated)
--pin_current_date (date of the delete)
--pin_upper_start_period_column (for period, the columns' name from fields, ex 'start quarter')
--pin_upper_end_period_column
--pin_time_unit_id (for period, time unit to use)
--PIN_RELATIONSHIP_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES)
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name
--PIN_RELATIONSHIP_MOVE_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES) - only the tabels used at move
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name

--->> OUTPUT
--pout_inserted_rows (TYPE TABLETYPE_ID_NAME)
--                - row_id
--                - table name
--pout_updated_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_deleted_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_scn_inserted (number)
--pout_scn_upd_deleted (number)

   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      DECLARE
      POUT_INSERTED_ROWS TABLETYPE_ID_NAME;
      POUT_UPDATED_ROWS TABLETYPE_ID_NAME;
      POUT_DELETED_ROWS TABLETYPE_ID_NAME;
      POUT_SCN_INSERTED NUMBER;
      POUT_SCN_UPD_DELETED NUMBER;
      BEGIN
            MOVE_IN_HIERARCHY.MOVE_HIERARCHY(
                        PIN_upper_entity_rowid => NULL,
                        PIN_OLD_REL_START_DATE => NULL,
                        PIN_OLD_REL_END_DATE => NULL,
                        PIN_NEW_REL_START_DATE => NULL,
                        PIN_NEW_REL_END_DATE => NULL,
                        PIN_IS_EFFECTIVE_PERIOD => NULL,
                        PIN_UPPER_START_PERIOD_COLUMN => NULL,
                        PIN_UPPER_END_PERIOD_COLUMN => NULL,
                        PIN_TIME_UNIT_ID => NULL,
                        PIN_OLD_RELATIONSHIP => NULL,
                        PIN_UPPER_ENTITY_VALUE => 1,
                        PIN_NEW_PARENT_ENTITY_VALUE => 5,
                        PIN_SUBORDINATE_PARENT_VALUE => 6,
                        PIN_RELATIONSHIP_MOVE_TABLE => OBJTYPE_RELATIONSHIP_TABLE('T200002', 190647, 190647, 'E190711', 'E190713'),
                        pin_relationship_move_tables => TABLETYPE_RELATIONSHIP_TABLES(
                           OBJTYPE_RELATIONSHIP_TABLE('T200000', 190647, 190647, 'E190714', 'E190713'),
                           OBJTYPE_RELATIONSHIP_TABLE('T200001', 190647, 190647, 'E190713', 'E190712')),
                         pin_relationship_tables => TABLETYPE_RELATIONSHIP_TABLES(
                           OBJTYPE_RELATIONSHIP_TABLE('T200000', 190647, 190647, 'E190714', 'E190713'),
                           OBJTYPE_RELATIONSHIP_TABLE('T200002', 190647, 190647, 'E190711', 'E190713'),
                           OBJTYPE_RELATIONSHIP_TABLE('T200001', 190647, 190647, 'E190713', 'E190712')),

                        POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                        POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                        POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                        POUT_SCN => POUT_SCN,
                        POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION);

      END;
         */
   -----------------------------------------------------------------------------------------------

PROCEDURE MOVE_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
PIN_upper_entity_rowid NUMBER,
PIN_OLD_REL_START_DATE DATE,
PIN_OLD_REL_END_DATE DATE,
PIN_NEW_REL_START_DATE DATE,
PIN_NEW_REL_END_DATE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
PIN_OLD_RELATIONSHIP NUMBER,
PIN_SUBORDINATE_PARENT_VALUE NUMBER,
PIN_RELATIONSHIP_MOVE_TABLE OBJTYPE_RELATIONSHIP_TABLE,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

);

 -- ############################# SEARCH_IN_HIERARCHY START #############################
 -- Assumptions:
    -- Input Parameters are built using valid column names
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_hierarchy_list         The hierarchy build from Java; NOT NULL
    --    pin_tables_list            The entity tables list (and the ID of each entity); NOT NULL
    --    pin_fields_list            The display fields and their tables; NOT NULL
    --    pin_start_list             The entity IDs and entity VALUEs of the not yet expanded nodes; NOT NULL
    --    pin_search_string          The string used in the search; NOT NULL
    --    pin_field_to_search_in     The field in which the search is done (it may differ from entity to entity);NOT NULL
    -----------------------------------------------------------------------------------------
    -- Output :
    -----------------------------------------------------------------------------------------
    -- Return :
    --    pout_cursor                A sys_refcursor used to return the result to the Java
    --    pout_id_path               The id path used to get to the first node (nodes are separated by ',')
    --    pout_value_path            The value path used to get to the first node (nodes are separated by ',')
    ----------------------------------------------------------------------------------------
    /*

    -- Example : where_clause_vals and orderby_clause
        variable rc refcursor;
        declare
        c sys_refcursor;
        i varchar2(200);
        v varchar2(200);

          begin
            v_test := search_in_hierarchy3(pin_hierarchy_list        => 'SELECT 2303    UPPER_ENTITY_ID,
                                                                                2303    LOWER_ENTITY_ID,
                                                                                e800328 UPPER_VALUE,
                                                                                e800308 LOWER_VALUE
                                                                          FROM   T800329',
                                          pin_table_list             => TABLETYPE_ID_NAME(OBJTYPE_ID_NAME('451', 'T800329')),
                                          pin_fields_list           => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('E800308', 'T800329'))
                                          pin_start_list            => TABLETYPE_ID_ID(OBJTYPE_ID_ID(2303,1)),
                                          pin_search_string         => 'asd',
                                          pin_field_to_search_in    => TABLETYPE_DT_CHAR(OBJTYPE_DT_CHAR('T800329.e800308')),
                                          pout_cursor               => c,
                                          pout_id_path              => i,
                                          pout_value_path           => v);
          :rc := c;
          dbms_output.put_line(i);
          dbms_output.put_line(v);
        end;
        print rc;
    */

PROCEDURE SEARCH_IN_HIERARCHY(pin_hierarchy_list      IN  VARCHAR2,
                              pin_tables_list         IN  TABLETYPE_ID_NAME,
                              pin_fields_list         IN  TABLETYPE_NAME_MAP,
                              pin_start_list          IN  TABLETYPE_ID_ID,
                              pin_search_string       IN  VARCHAR2,
                              pin_fields_to_search_in IN  TABLETYPE_DT_CHAR,
                              pin_search_field_type   IN  VARCHAR2,
                              pout_cursor             OUT SYS_REFCURSOR,
                              pout_id_path            OUT VARCHAR2,
                              pout_value_path         OUT VARCHAR2);

-- *******************************    PUBLIC PROCEDURES END         *******************************
END HIERARCHY_OPTIONS;
/
