CREATE PACKAGE BODY TABLE_CALCULATIONS AS

FUNCTION IS_LEAF_LEVEL
(   PI_VIEW_ID    NUMBER,
    PI_ROW_PATH   TABLETYPE_MDL_DIM_PATH_EXP,
    PI_COL_PATH   TABLETYPE_MDL_DIM_PATH_EXP
) RETURN NUMBER IS
    V_RESULT      NUMBER;
BEGIN
    V_RESULT := 1;

    FOR C IN (SELECT 1
              FROM (SELECT DIM_ID
                    FROM XMLTABLE('/pivotView/columns/dimensions/dimension' PASSING XMLTYPE((SELECT OD_DEFINITION FROM OBJECT_DEFINITIONS WHERE OD_CONTAINER_ID = PI_VIEW_ID)) COLUMNS
                         DIM_ID NUMBER PATH 'dimensionId')
                    UNION ALL
                    SELECT DIM_ID
                    FROM XMLTABLE('/pivotView/rows/dimensions/dimension' PASSING XMLTYPE((SELECT OD_DEFINITION FROM OBJECT_DEFINITIONS WHERE OD_CONTAINER_ID = PI_VIEW_ID)) COLUMNS
                                  DIM_ID NUMBER PATH 'dimensionId')
                   ) ALL_DIMS
              LEFT JOIN
                   (SELECT DIM_ID
                    FROM TABLE(PI_ROW_PATH)
                    WHERE NVL(DIM_BASE_ID, DIM_ID) = DIM_ID AND DIM_VALUE IS NOT NULL
                    UNION ALL
                    SELECT DIM_ID
                    FROM TABLE(PI_COL_PATH)
                    WHERE NVL(DIM_BASE_ID, DIM_ID) = DIM_ID AND DIM_VALUE IS NOT NULL
                   ) PI_DIMS ON PI_DIMS.DIM_ID = ALL_DIMS.DIM_ID
              WHERE PI_DIMS.DIM_ID IS NULL)
    LOOP
        V_RESULT := 0;
    END LOOP;

    RETURN V_RESULT;
END IS_LEAF_LEVEL;

-----------------------------------------------------------------------------

  PROCEDURE BUILD_ENTITY_JOIN_LIST(PIN_TBL_ID             IN NUMBER,
                                   PIN_TABLE_ALIAS        IN VARCHAR2,
                                   PIN_ENTITY_LIST        IN CLOB,
                                   PIO_ENTITY_LIST        IN OUT CLOB,
                                   PIO_ENTITY_JOIN_CLAUSE IN OUT CLOB) IS
  BEGIN

    FOR C IN (SELECT 'JOIN ' || T2.TABLES_PHYSICAL_NAME || ' E' || ENTITY_ID ||
                     ' ON ' || NVL(PIN_TABLE_ALIAS, T1.TABLES_PHYSICAL_NAME) || '.' ||
                     TC.TC_PHYSICAL_NAME || '= E' || ENTITY_ID ||
                     '.E_INTERNAL_ID' ENTITY_JOIN,
                     ENTITY_ID
                FROM TABLES T1
                JOIN TABLE_COLUMNS TC
                  ON TC_TABLES_ID = T1.TABLES_ID
                JOIN ENTITIES
                  ON ENTITY_ID = TC_ENTITY_ID
                JOIN TABLES T2
                  ON T2.TABLES_ID = ENTITY_TABLES_ID
                JOIN TABLE_COLUMNS TC2
                  ON TC2.TC_TABLES_ID = ENTITY_TABLES_ID
                 AND TC2.TC_LOGIC_TYPE IN (1, 5)
               WHERE T1.TABLES_ID = PIN_TBL_ID
                 AND INSTR(',' || PIN_ENTITY_LIST || ',',
                           ',' || ENTITY_ID || ',') > 0) LOOP
      IF INSTR(',' || PIO_ENTITY_LIST || ',', ',' || C.ENTITY_ID || ',') < 1 OR
         PIO_ENTITY_LIST IS NULL THEN
        PIO_ENTITY_LIST := PIO_ENTITY_LIST || CASE
                             WHEN PIO_ENTITY_LIST IS NOT NULL THEN
                              ','
                             ELSE
                              NULL
                           END || C.ENTITY_ID;
        PIO_ENTITY_JOIN_CLAUSE := PIO_ENTITY_JOIN_CLAUSE || ' ' ||
                                  C.ENTITY_JOIN;
      END IF;

    END LOOP;

  END BUILD_ENTITY_JOIN_LIST;
  --
  PROCEDURE BUILD_ENTITY_JOIN_TABLE(PIN_TBL_ID             IN NUMBER,
                                    PIN_ENTITY_TABLE       IN TABLETYPE_NUMBER,
                                    PIO_ENTITY_LIST        IN OUT CLOB,
                                    PIO_ENTITY_JOIN_CLAUSE IN OUT CLOB) IS
  BEGIN

    FOR C IN (SELECT 'JOIN ' || T2.TABLES_PHYSICAL_NAME || ' E' || ENTITY_ID ||
                     ' ON ' || T1.TABLES_PHYSICAL_NAME || '.' ||
                     TC.TC_PHYSICAL_NAME || '= E' || ENTITY_ID ||
                     '.E_INTERNAL_ID' JOIN_CLAUSE,
                     ENTITY_ID
                FROM TABLES T1
                JOIN TABLE_COLUMNS TC
                  ON TC_TABLES_ID = T1.TABLES_ID
                JOIN ENTITIES
                  ON ENTITY_ID = TC_ENTITY_ID
                JOIN TABLE(PIN_ENTITY_TABLE)
                  ON ENTITY_ID = COLUMN_VALUE
                JOIN TABLES T2
                  ON T2.TABLES_ID = ENTITY_TABLES_ID
                JOIN TABLE_COLUMNS TC2
                  ON TC2.TC_TABLES_ID = ENTITY_TABLES_ID
                 AND TC2.TC_LOGIC_TYPE IN (1, 5)
               WHERE T1.TABLES_ID = PIN_TBL_ID) LOOP
      IF INSTR(',' || PIO_ENTITY_LIST || ',', ',' || C.ENTITY_ID || ',') < 1 OR
         PIO_ENTITY_LIST IS NULL THEN
        PIO_ENTITY_LIST := PIO_ENTITY_LIST || CASE
                             WHEN PIO_ENTITY_LIST IS NOT NULL THEN
                              ','
                             ELSE
                              NULL
                           END || C.ENTITY_ID;
        PIO_ENTITY_JOIN_CLAUSE := PIO_ENTITY_JOIN_CLAUSE || ' ' ||
                                  C.JOIN_CLAUSE;
      END IF;
    END LOOP;

  END BUILD_ENTITY_JOIN_TABLE;
  --
  PROCEDURE BUILD_CROSSREC_QUERY(PIN_CALC_FORMULA     IN CLOB,
                                 PIN_JOIN_ENTITIES    IN CLOB,
                                 PIN_CROSSREC_JOINS   IN CLOB,
                                 PIN_WHERE_CLAUSE     IN CLOB,
                                 PIN_INNER_TABLE_NAME IN VARCHAR2,
                                 PIN_TBL_ID           IN NUMBER,
                                 POUT_SELECT_STMT     OUT CLOB) IS

    V_SELECT_STMT       CLOB;
    V_ENTITY_LIST_CROSS CLOB;
    V_CROSS_ENTITY_JOIN CLOB;
    V_STAMP             VARCHAR2(200 CHAR);
  BEGIN

    V_STAMP := 'TABLE_CALCULATIONS.BUILD_CROSSREC_QUERY - ' || TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(PIN_CALC_FORMULA), 'PIN_CALC_FORMULA := <value>', V_STAMP);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(PIN_JOIN_ENTITIES), 'PIN_JOIN_ENTITIES := <value>', V_STAMP);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(PIN_WHERE_CLAUSE), 'PIN_WHERE_CLAUSE := <value>', V_STAMP);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(PIN_INNER_TABLE_NAME), 'PIN_INNER_TABLE_NAME := <value>', V_STAMP);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(PIN_TBL_ID), 'PIN_TBL_ID := <value>', V_STAMP);

    V_SELECT_STMT := 'SELECT ' || PIN_CALC_FORMULA || ' FROM ' ||
                     PIN_INNER_TABLE_NAME || ' INNERQ ';

    BUILD_ENTITY_JOIN_LIST(PIN_TBL_ID,
                           'INNERQ',
                           PIN_JOIN_ENTITIES,
                           V_ENTITY_LIST_CROSS,
                           V_CROSS_ENTITY_JOIN);

    V_SELECT_STMT := V_SELECT_STMT || ' ' || V_CROSS_ENTITY_JOIN;

    V_SELECT_STMT    := V_SELECT_STMT || ' ' || NVL(PIN_CROSSREC_JOINS, '') || ' WHERE ' || PIN_WHERE_CLAUSE;
    POUT_SELECT_STMT := '(' || V_SELECT_STMT || ')';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(POUT_SELECT_STMT), 'POUT_SELECT_STMT := <value>', V_STAMP);

  END BUILD_CROSSREC_QUERY;
  --
  PROCEDURE BUILD_WITH_STREAM(PIN_SELECT_COLS      IN CLOB,
                              PIN_NEW_STREAM_TABLE IN VARCHAR2,
                              PIN_OLD_STREAM_TABLE IN VARCHAR2,
                              PIN_TABLE_ALIAS      IN VARCHAR2,
                              PIN_ENTITY_JOIN      IN CLOB,
                              PIN_STREAM_CLOB      IN OUT CLOB) IS
  BEGIN

    PIN_STREAM_CLOB := PIN_STREAM_CLOB || ',' || PIN_NEW_STREAM_TABLE ||
                       ' AS (SELECT ' || PIN_SELECT_COLS || ' FROM ' ||
                       PIN_OLD_STREAM_TABLE || ' ' || PIN_TABLE_ALIAS ||
                       PIN_ENTITY_JOIN || ')';

  END BUILD_WITH_STREAM;
  --
  PROCEDURE BUILD_SELECT_STMT(PIN_CALC_FORMULA IN CLOB,
                              PIN_COLUMN_NAME  IN VARCHAR2,
                              PIN_COLUMN_ALIAS IN VARCHAR2 DEFAULT NULL,
                              PIN_SELECT_COLS  IN OUT CLOB) IS
  BEGIN

    PIN_SELECT_COLS := ',' || PIN_SELECT_COLS || ',';

    PIN_SELECT_COLS := REGEXP_REPLACE(PIN_SELECT_COLS,
                                      ',' || PIN_COLUMN_NAME || ' AS ' ||
                                      PIN_COLUMN_ALIAS || ',',
                                      ',');
    PIN_SELECT_COLS := SUBSTR(PIN_SELECT_COLS,
                              2,
                              LENGTH(PIN_SELECT_COLS) - 2);

    PIN_SELECT_COLS := PIN_SELECT_COLS || ',(' || PIN_CALC_FORMULA ||
                       ') AS "' || NVL(PIN_COLUMN_ALIAS, PIN_COLUMN_NAME) || '"';

  END BUILD_SELECT_STMT;
  --
  PROCEDURE BUILD_STREAM_INDEPENDENT(PIN_CALC_FORMULA IN CLOB,
                                     PIN_COLUMN_ALIAS IN VARCHAR2,
                                     PIN_COLUMN_NAME  IN VARCHAR2,
                                     PIN_SELECT_COLS  IN OUT CLOB,
                                     PIN_FROM_CLAUSE  IN CLOB,
                                     PIN_ENTITY_JOIN  IN CLOB,
                                     PIN_STREAM_CLOB  OUT CLOB) IS
  BEGIN

    PIN_SELECT_COLS := ',' || PIN_SELECT_COLS || ',';

    PIN_SELECT_COLS := REGEXP_REPLACE(PIN_SELECT_COLS,
                                      ',' || PIN_COLUMN_NAME || ' AS ' ||
                                      PIN_COLUMN_ALIAS || ',',
                                      ',');
    PIN_SELECT_COLS := SUBSTR(PIN_SELECT_COLS,
                              2,
                              LENGTH(PIN_SELECT_COLS) - 2);

    PIN_STREAM_CLOB := 'SELECT ' || PIN_SELECT_COLS || ',(' ||
                       PIN_CALC_FORMULA || ') AS "' || PIN_COLUMN_ALIAS ||
                       '" FROM ' || PIN_FROM_CLAUSE || ' ' ||
                       PIN_ENTITY_JOIN;
    PIN_SELECT_COLS := PIN_SELECT_COLS || ',' || PIN_COLUMN_NAME;

  END BUILD_STREAM_INDEPENDENT;
  --
  PROCEDURE ADD_CALCULATION(PIN_INPUT_TBL_ID    NUMBER,
                            PIN_INPUT_FLD_ID    CLOB,
                            PIN_OUTPUT_TBL      NUMBER,
                            PIN_OUTPUT_FLD_ID   NUMBER,
                            PIN_ROWBASED_CALC   NUMBER,
                            PIN_EXP_ID          NUMBER,
                            PIN_EXP_RESOLVED    CLOB,
                            PIN_ORDER           NUMBER,
                            PIN_TBL_REL_KEYS    TABLETYPE_TBL_CALC_REL,
                            PIN_JOIN_ENTITIES   TABLETYPE_NUMBER,
							PIN_JOIN_PERIODS    CLOB,
                            PIN_ENTITIES_FIELDS TABLETYPE_CLOB,
                            PIN_CROSSREC_DATA   TABLETYPE_CROSSREC DEFAULT NULL,
                            PIN_NULL_CALCS      NUMBER) IS

    V_REL_ID            NUMBER(10);
    V_NEW_EXP_RESOLVED  CLOB;
    V_TABLE_NAME        VARCHAR2(30CHAR);
    V_CROSS_SELECT_STMT CLOB;
    V_INPUT_FLD_IDS     CLOB;
	V_JOIN_PERIODS      CLOB;
  BEGIN
    IF PIN_ROWBASED_CALC = 0 THEN
      V_REL_ID := TBLCD_TCKF_REL_ID_SEQ.NEXTVAL;
      INSERT INTO TBL_CALC_KEY_FLDS
        (TCKF_ID,
         TCKF_INPUT_KEY_FLD_ID,
         TCKF_OUTPUT_KEY_FLD_ID,
         TCKF_REL_ID,
         TCKF_FIXED_VALUE)
        SELECT TCKF_ID_SEQ.NEXTVAL,
               INPUT_KEY,
               OUTPUT_KEY,
               V_REL_ID,
               FIXED_VALUE
          FROM TABLE(PIN_TBL_REL_KEYS);
    END IF;

    V_INPUT_FLD_IDS := PIN_INPUT_FLD_ID;

    SELECT TABLES_PHYSICAL_NAME
      INTO V_TABLE_NAME
      FROM TABLES
     WHERE TABLES_ID = PIN_INPUT_TBL_ID;

    V_NEW_EXP_RESOLVED := PIN_EXP_RESOLVED;

    IF PIN_JOIN_ENTITIES IS NOT NULL THEN

      FOR C IN (SELECT COLUMN_VALUE,
                       REPLACE(COLUMN_VALUE, '.', NULL) ALIAS_VAL
                  FROM TABLE(PIN_ENTITIES_FIELDS)) LOOP

        V_NEW_EXP_RESOLVED := REPLACE(V_NEW_EXP_RESOLVED,
                                      C.COLUMN_VALUE,
                                      C.ALIAS_VAL);

      END LOOP;

    END IF;

	IF (PIN_JOIN_PERIODS IS NOT NULL)
    THEN
        V_JOIN_PERIODS := PIN_JOIN_PERIODS;
        V_JOIN_PERIODS := REPLACE(V_JOIN_PERIODS, 'THISROW', V_TABLE_NAME);
    END IF;

    IF PIN_CROSSREC_DATA IS NOT NULL THEN
      FOR C IN (SELECT CROSSREC_FORMULA,
                       CROSSREC_CRITERIA,
                       CROSSREC_ENTITIES,
                       CROSSREC_ALIAS,
                       CROSSREC_THISROW_FIELDS,
                       CROSSREC_FIELD,
					   CROSSREC_JOINS
                  FROM TABLE(PIN_CROSSREC_DATA)) LOOP
        IF NULLIF(LENGTH(C.CROSSREC_THISROW_FIELDS), 0) IS NULL AND
           INSTR(C.CROSSREC_CRITERIA, 'THISROW.') = 0 THEN
          IF NULLIF(LENGTH(C.CROSSREC_CRITERIA), 0) IS NOT NULL THEN
            V_NEW_EXP_RESOLVED := REPLACE(V_NEW_EXP_RESOLVED,
                                          C.CROSSREC_ALIAS,
                                          CASE
                                            WHEN UPPER(C.CROSSREC_FORMULA) = 'SELECTSUM' THEN
                                             ' SUM('
                                            WHEN UPPER(C.CROSSREC_FORMULA) = 'SELECTAVERAGE' THEN
                                             ' AVG('
                                          END || ' CASE WHEN ' || C.CROSSREC_CRITERIA ||
                                          ' THEN ' || V_TABLE_NAME || '.' ||
                                          C.CROSSREC_FIELD || ' END) OVER () ');
          ELSE
            V_NEW_EXP_RESOLVED := REPLACE(V_NEW_EXP_RESOLVED,
                                          C.CROSSREC_ALIAS,
                                          CASE
                                            WHEN UPPER(C.CROSSREC_FORMULA) = 'SELECTSUM' THEN
                                             ' SUM('
                                            WHEN UPPER(C.CROSSREC_FORMULA) = 'SELECTAVERAGE' THEN
                                             ' AVG('
                                          END || V_TABLE_NAME || '.' ||
                                          C.CROSSREC_FIELD || ') OVER () ');
          END IF;

        ELSE
          V_INPUT_FLD_IDS     := V_INPUT_FLD_IDS || ',' ||
                                 C.CROSSREC_THISROW_FIELDS;
          C.CROSSREC_CRITERIA := REPLACE(C.CROSSREC_CRITERIA,
                                         V_TABLE_NAME,
                                         'INNERQ');
          C.CROSSREC_CRITERIA := REPLACE(C.CROSSREC_CRITERIA,
                                         'THISROW',
                                         V_TABLE_NAME);

		  IF (C.CROSSREC_JOINS IS NOT NULL)
          THEN
              C.CROSSREC_JOINS := REPLACE(C.CROSSREC_JOINS,
                                          V_TABLE_NAME,
                                          'INNERQ');
              C.CROSSREC_JOINS := REPLACE(C.CROSSREC_JOINS,
                                          'THISROW',
                                          V_TABLE_NAME);
          END IF;

          BUILD_CROSSREC_QUERY(CASE WHEN
                               UPPER(C.CROSSREC_FORMULA) = 'SELECTSUM' THEN
                               ' SUM( INNERQ.' WHEN
                               UPPER(C.CROSSREC_FORMULA) = 'SELECTAVERAGE' THEN
                               ' AVG( INNERQ.'
                               END || C.CROSSREC_FIELD || ')',
                               C.CROSSREC_ENTITIES,
							   C.CROSSREC_JOINS,
                               C.CROSSREC_CRITERIA,
                               V_TABLE_NAME,
                               PIN_INPUT_TBL_ID,
                               V_CROSS_SELECT_STMT);

          V_NEW_EXP_RESOLVED := REPLACE(V_NEW_EXP_RESOLVED,
                                        C.CROSSREC_ALIAS,
                                        V_CROSS_SELECT_STMT);

        END IF;
      END LOOP;
    END IF;

    INSERT INTO TBL_CALC_DEFINITIONS
      (TBLCD_ID,
       TBLCD_INPUT_TBL_ID,
       TBLCD_INPUT_FLD_ID,
       TBLCD_OUTPUT_TBL_ID,
       TBLCD_OUTPUT_FLD_ID,
       TBLCD_EXP_ID,
       TBLCD_REL_ID,
       TBLCD_ORDER,
       TBLCD_ROWBASED_CALCULATION,
       TBLCD_SAVED_UPDATE_SQL,
       TBLCD_NULL_CALCS)
    VALUES
      (TBLCD_ID_SEQ.NEXTVAL,
       PIN_INPUT_TBL_ID,
       V_INPUT_FLD_IDS,
       PIN_OUTPUT_TBL,
       PIN_OUTPUT_FLD_ID,
       PIN_EXP_ID,
       V_REL_ID,
       PIN_ORDER,
       PIN_ROWBASED_CALC,
       NULL,
       PIN_NULL_CALCS);

    INSERT INTO TBL_CALC_EXP_RESOLVED
      (TBLCER_EXP_ID,
       TBLCER_EXP_RESOLVED,
       TBLCER_ENTITIES_USED,
       TBLCER_ENTITY_FLDS_USED,
       TBLCER_JOINS)
    VALUES
      (PIN_EXP_ID,
       V_NEW_EXP_RESOLVED,
       PIN_JOIN_ENTITIES,
       PIN_ENTITIES_FIELDS,
       V_JOIN_PERIODS);

    IF PIN_CROSSREC_DATA IS NOT NULL THEN
      INSERT INTO TBL_CALC_CROSSREC
        (TBLCC_EXP_ID,
         TBLCC_FORMULA,
         TBLCC_CRITERIA,
         TBLCC_ENTITIES,
         TBLCC_ALIAS,
         TBLCC_FIELD,
         TBLCC_THISROW_FIELDS)
        SELECT PIN_EXP_ID,
               CROSSREC_FORMULA,
               CROSSREC_CRITERIA,
               CROSSREC_ENTITIES,
               CROSSREC_ALIAS,
               CROSSREC_FIELD,
               CROSSREC_THISROW_FIELDS
          FROM TABLE(PIN_CROSSREC_DATA);
    END IF;

  END ADD_CALCULATION;
  --
  PROCEDURE GET_CALC_ROWBASED_SQL(PIN_TBL_ID       NUMBER,
                                  PIN_INPUT_FLD_ID TABLETYPE_NUMBER,
                                  PIN_HAS_ROW_IDS  NUMBER,
                                  PIN_UPDATE_MODE  NUMBER,
                                  POUT_UPDATE_SQL  IN OUT CLOB) IS
    V_EXPR                  CLOB;
    V_TABLE_NAME            VARCHAR2(30 CHAR);
    V_INPUT_FLDS            CLOB;
    V_INPUT_FLDS_ITMD       CLOB;
    V_INPUT_FLDS_INIT       CLOB;
    V_INPUT_FLDS_AFTER      CLOB;
    V_SET_STMT              CLOB;
    V_STAMP                 VARCHAR2(200 CHAR);
    V_ENTITY_LIST           CLOB;
    V_ENTITY_FLD_LIST       CLOB;
    V_ENTITY_FLD_LIST_AFTER CLOB;
    V_JOIN_CLAUSE           CLOB;
    V_HAS_CALCULATIONS      NUMBER(1) := 0;
    V_CASE_WHEN_CLAUSES     CLOB;
    V_EXPR_RESOLVED         CLOB;
    V_PREV_ROW_LVL          NUMBER(10) := 0;
    V_CROSS_ENTITY_JOIN     CLOB;
    V_ENTITY_LIST_CROSS     CLOB;
    V_EXISTS_CROSS          NUMBER := 0;
    V_CURRENT_TABLE         VARCHAR2(50 CHAR);
    V_NEXT_TABLE            VARCHAR2(50 CHAR);

    V_TABLE_NAME_INCREMENT NUMBER := 0;
  BEGIN
    V_STAMP := 'TABLE_CALCULATIONS.GET_CALC_ROWBASED_SQL - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    SELECT TABLES_PHYSICAL_NAME
      INTO V_TABLE_NAME
      FROM TABLES
     WHERE TABLES_ID = PIN_TBL_ID;

    V_CURRENT_TABLE        := V_TABLE_NAME || '_' ||
                              TO_CHAR(V_TABLE_NAME_INCREMENT);
    V_TABLE_NAME_INCREMENT := V_TABLE_NAME_INCREMENT + 1;
    V_NEXT_TABLE           := V_TABLE_NAME || '_' ||
                              TO_CHAR(V_TABLE_NAME_INCREMENT);

    SELECT RTRIM(XMLAGG(XMLELEMENT(E, V_TABLE_NAME || '.' || TC_PHYSICAL_NAME || ' AS ' || TC_PHYSICAL_NAME, ',').EXTRACT('//text()') ORDER BY TC_ORDER)
                 .GETCLOBVAL(),
                 ',') AS LIST,
           RTRIM(XMLAGG(XMLELEMENT(E, TC_PHYSICAL_NAME, ',').EXTRACT('//text()') ORDER BY TC_ORDER)
                 .GETCLOBVAL(),
                 ',') AS LIST1
      INTO V_INPUT_FLDS_INIT, V_INPUT_FLDS_AFTER
      FROM TABLE_COLUMNS
      LEFT JOIN FIELDS
        ON TC_FLD_ID = FLD_ID
     WHERE TC_TABLES_ID = PIN_TBL_ID;

    V_INPUT_FLDS := V_INPUT_FLDS_INIT;
    V_EXPR       := 'WITH ' || V_CURRENT_TABLE || ' AS (SELECT ' ||
                    V_INPUT_FLDS || ' <ENTITY_FIELDS> ' || ' FROM ' ||
                    V_TABLE_NAME || '<ENTITY_JOIN>';

    IF NVL(PIN_UPDATE_MODE, 0) = 0 AND NVL(PIN_HAS_ROW_IDS, 0) = 1 THEN
      V_EXPR := V_EXPR ||
                ' JOIN TABLE(RWIDS_TABLE) RWIDS ON COLUMN_VALUE = ' ||
                V_TABLE_NAME || '.ROW_IDENTIFIER )';
    ELSE
      V_EXPR := V_EXPR || ')';
    END IF;

    V_INPUT_FLDS := V_INPUT_FLDS_INIT || '<ENTITY_FIELDS_AFTER>';

    IF NVL(PIN_HAS_ROW_IDS, 0) = 0 AND NVL(PIN_UPDATE_MODE, 0) = 0 THEN
      RETURN;
    END IF;

    V_INPUT_FLDS_ITMD := V_INPUT_FLDS;

    DBMS_OUTPUT.PUT_LINE('1');

    FOR C IN (SELECT FLD_COLUMN_NAME,
                     FLD_LENGTH,
                     FLD_DATA_TYPE,
                     TBLCD_OUTPUT_FLD_ID,
                     TBLCER_EXP_RESOLVED,
                     TBLCER_ENTITIES_USED,
                     TBLCER_ENTITY_FLDS_USED,
					 TBLCER_JOINS,
                     TBLCD_NULL_CALCS,
                     TBLCD_INPUT_FLD_ID,
                     CROSS_REC_ENTITIES,
                     CROSS_IDS,
                     LVL1
                FROM (SELECT TBLCD_OUTPUT_FLD_ID,
                             TBLCD_EXP_ID,
                             TBLCD_ORDER,
                             TBLCD_NULL_CALCS,
                             TBLCD_INPUT_FLD_ID,
                             LISTAGG(TBLCC_ENTITIES, ',') WITHIN GROUP(ORDER BY TBLCC_EXP_ID) CROSS_REC_ENTITIES,
                             LISTAGG(TBLCC_EXP_ID, ',') WITHIN GROUP(ORDER BY TBLCC_EXP_ID) CROSS_IDS,
                             MAX(LVL1) LVL1
                        FROM (SELECT TBLCD_OUTPUT_FLD_ID,
                                     TBLCD_EXP_ID,
                                     TBLCD_ORDER,
                                     TBLCD_NULL_CALCS,
                                     TBLCD_INPUT_FLD_ID,
                                     LEVEL LVL1
                                FROM (SELECT TBLCD_ID,
                                             TBLCD_EXP_ID,
                                             TBLCD_ORDER,
                                             TBLCD_OUTPUT_FLD_ID,
                                             TBLCD_NULL_CALCS,
                                             TO_CHAR(SUBSTR(TBLCD_INPUT_FLD_ID,
                                                            1,
                                                            4000)) AS TBLCD_INPUT_FLD_ID,
                                             IN_FLD
                                        FROM TBL_CALC_DEFINITIONS
                                       CROSS JOIN (SELECT DISTINCT COLUMN_VALUE IN_FLD
                                                    FROM TABLE(PIN_INPUT_FLD_ID))
                                       WHERE TBLCD_INPUT_TBL_ID = PIN_TBL_ID
                                         AND TBLCD_ROWBASED_CALCULATION = 1)
                               START WITH INSTR(',' || TBLCD_INPUT_FLD_ID || ',',
                                                ',' || IN_FLD || ',') > 0
                              CONNECT BY NOCYCLE
                               INSTR(',' || TBLCD_INPUT_FLD_ID || ',',
                                               ',' || PRIOR TBLCD_OUTPUT_FLD_ID || ',') > 0
                               GROUP BY TBLCD_OUTPUT_FLD_ID,
                                        TBLCD_EXP_ID,
                                        TBLCD_ORDER,
                                        TBLCD_NULL_CALCS,
                                        TBLCD_INPUT_FLD_ID,
                                        LEVEL)
                        LEFT JOIN TBL_CALC_CROSSREC
                          ON TBLCC_EXP_ID = TBLCD_EXP_ID
                       GROUP BY TBLCD_OUTPUT_FLD_ID,
                                TBLCD_EXP_ID,
                                TBLCD_ORDER,
                                TBLCD_NULL_CALCS,
                                TBLCD_INPUT_FLD_ID)
                JOIN TBL_CALC_EXP_RESOLVED
                  ON TBLCER_EXP_ID = TBLCD_EXP_ID
                JOIN FIELDS
                  ON FLD_ID = TBLCD_OUTPUT_FLD_ID
               ORDER BY LVL1, TBLCD_ORDER) LOOP
      DBMS_OUTPUT.PUT_LINE('2');
      IF V_HAS_CALCULATIONS = 0 THEN
        V_HAS_CALCULATIONS := 1;
      END IF;

      IF C.CROSS_IDS IS NOT NULL THEN
        V_EXISTS_CROSS := 1;
      END IF;

      IF V_PREV_ROW_LVL <> C.LVL1 AND V_PREV_ROW_LVL > 0 THEN
        BUILD_WITH_STREAM(V_INPUT_FLDS_ITMD,
                          V_NEXT_TABLE,
                          V_CURRENT_TABLE,
                          V_TABLE_NAME,
                          V_CROSS_ENTITY_JOIN,
                          V_EXPR);
        V_INPUT_FLDS_ITMD      := V_INPUT_FLDS;
        V_CROSS_ENTITY_JOIN    := NULL;
        V_ENTITY_LIST_CROSS    := NULL;
        V_PREV_ROW_LVL         := C.LVL1;
        V_CURRENT_TABLE        := V_NEXT_TABLE;
        V_TABLE_NAME_INCREMENT := V_TABLE_NAME_INCREMENT + 1;
        V_NEXT_TABLE           := V_TABLE_NAME || '_' ||
                                  TO_CHAR(V_TABLE_NAME_INCREMENT);
      ELSIF V_PREV_ROW_LVL = 0 THEN
        V_PREV_ROW_LVL := C.LVL1;
      END IF;

      V_EXPR_RESOLVED := C.TBLCER_EXP_RESOLVED;

      IF C.TBLCD_NULL_CALCS = 0 AND C.TBLCD_INPUT_FLD_ID IS NOT NULL THEN
        SELECT LISTAGG(FLD_COLUMN_NAME, ' IS NOT NULL AND ') WITHIN GROUP(ORDER BY FLD_COLUMN_NAME)
          INTO V_CASE_WHEN_CLAUSES
          FROM FIELDS
          JOIN (SELECT REGEXP_SUBSTR(STR, '[[:digit:]]+', 1, LEVEL) AS SUBSTR
                  FROM (SELECT C.TBLCD_INPUT_FLD_ID AS STR FROM DUAL)
                CONNECT BY LEVEL <=
                           LENGTH(REGEXP_REPLACE(STR, '[[:digit:]]+')) + 1) FLDS
            ON FLDS.SUBSTR = FLD_ID;

        V_CASE_WHEN_CLAUSES := V_CASE_WHEN_CLAUSES || ' IS NOT NULL ';
      END IF;

      IF C.CROSS_REC_ENTITIES IS NOT NULL THEN
        BUILD_ENTITY_JOIN_LIST(PIN_TBL_ID,
                               NULL,
                               C.CROSS_REC_ENTITIES,
                               V_ENTITY_LIST_CROSS,
                               V_CROSS_ENTITY_JOIN);
      END IF;

	  IF (C.TBLCER_JOINS IS NOT NULL)
      THEN
          V_CROSS_ENTITY_JOIN := NVL(V_CROSS_ENTITY_JOIN, ' ') || ' ' || C.TBLCER_JOINS;
      END IF;

      IF C.TBLCER_ENTITIES_USED IS NOT NULL THEN

        BUILD_ENTITY_JOIN_TABLE(PIN_TBL_ID,
                                C.TBLCER_ENTITIES_USED,
                                V_ENTITY_LIST,
                                V_JOIN_CLAUSE);

        FOR Z IN (SELECT COLUMN_VALUE FROM TABLE(C.TBLCER_ENTITY_FLDS_USED)) LOOP
          IF INSTR(V_ENTITY_FLD_LIST_AFTER || ',',
                   ',' || REPLACE(Z.COLUMN_VALUE, '.') || ',') < 1 OR
             V_ENTITY_FLD_LIST IS NULL THEN

            V_ENTITY_FLD_LIST       := V_ENTITY_FLD_LIST || ',' ||
                                       Z.COLUMN_VALUE || ' AS ' ||
                                       REPLACE(Z.COLUMN_VALUE, '.');
            V_ENTITY_FLD_LIST_AFTER := V_ENTITY_FLD_LIST_AFTER || ',' ||
                                       REPLACE(Z.COLUMN_VALUE, '.');

            IF C.TBLCD_NULL_CALCS = 0 THEN

              V_CASE_WHEN_CLAUSES := V_CASE_WHEN_CLAUSES || CASE WHEN V_CASE_WHEN_CLAUSES IS NOT NULL THEN ' AND ' END||
                                     REPLACE(Z.COLUMN_VALUE, '.') ||
                                     ' IS NOT NULL ';

            END IF;
          END IF;
        END LOOP;
      END IF;

      IF C.TBLCD_NULL_CALCS = 0 AND V_CASE_WHEN_CLAUSES IS NOT NULL THEN

        V_CASE_WHEN_CLAUSES := 'CASE WHEN ' || V_CASE_WHEN_CLAUSES ||
                               '  THEN ';
        V_EXPR_RESOLVED     := V_CASE_WHEN_CLAUSES || V_EXPR_RESOLVED ||
                               'END ';
      END IF;

      BUILD_SELECT_STMT(REPLACE(V_EXPR_RESOLVED,
                                V_TABLE_NAME || ' INNERQ',
                                V_CURRENT_TABLE || ' INNERQ'),
                        V_TABLE_NAME || '.' || C.FLD_COLUMN_NAME,
                        C.FLD_COLUMN_NAME,
                        V_INPUT_FLDS_ITMD);

      IF V_SET_STMT IS NOT NULL THEN
        V_SET_STMT := V_SET_STMT || ',';
      END IF;

      IF C.FLD_DATA_TYPE = 6 THEN
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= CASE WHEN T_CALC.' || C.FLD_COLUMN_NAME ||
                      ' > -10000000000 AND T_CALC.' || C.FLD_COLUMN_NAME ||
                      ' < 10000000000 THEN ROUND(T_CALC.' ||
                      C.FLD_COLUMN_NAME || ',' || C.FLD_LENGTH ||
                      ') ELSE NULL END';
      ELSIF C.FLD_DATA_TYPE IN (1, 4) THEN
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= SUBSTR(T_CALC.' || C.FLD_COLUMN_NAME || ', 1 , ' ||
                      C.FLD_LENGTH || ')';
      ELSE
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= T_CALC.' || C.FLD_COLUMN_NAME;
      END IF;

      IF V_EXISTS_CROSS = 1 THEN
        V_EXPR := REPLACE(V_EXPR,
                          ' JOIN TABLE(RWIDS_TABLE) RWIDS ON COLUMN_VALUE = ' ||
                          V_TABLE_NAME || '.ROW_IDENTIFIER',
                          '');
      END IF;
    END LOOP;
    IF V_HAS_CALCULATIONS = 1 THEN
      BUILD_WITH_STREAM(V_INPUT_FLDS_ITMD,
                        V_NEXT_TABLE,
                        V_CURRENT_TABLE,
                        V_TABLE_NAME,
                        V_CROSS_ENTITY_JOIN,
                        V_EXPR);
      V_INPUT_FLDS_ITMD := V_INPUT_FLDS;
      V_EXPR := 'DECLARE
               RWIDS_TABLE TABLETYPE_NUMBER;
               BEGIN ' || CASE
                  WHEN NVL(PIN_UPDATE_MODE, 0) = 0 AND
                       NVL(PIN_HAS_ROW_IDS, 0) = 1 THEN
                   ' RWIDS_TABLE := :1; '
                END || ' MERGE INTO ' || V_TABLE_NAME || ' T_UPD USING ( ' ||
                V_EXPR || ' SELECT ' || V_INPUT_FLDS || ' FROM ' ||
                V_NEXT_TABLE || ' ' || V_TABLE_NAME ||
                ') T_CALC ON(T_UPD.ROW_IDENTIFIER = T_CALC.ROW_IDENTIFIER)
              WHEN MATCHED THEN UPDATE SET ' || V_SET_STMT ||
                '; END;';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_EXPR),
                               'V_EXPR_1 := <value>',
                               V_STAMP);

      V_EXPR := REPLACE(V_EXPR, '<ENTITY_FIELDS>', V_ENTITY_FLD_LIST);
      V_EXPR := REPLACE(V_EXPR,
                        '<ENTITY_FIELDS_AFTER>',
                        V_ENTITY_FLD_LIST_AFTER);
      V_EXPR := REPLACE(V_EXPR, '<ENTITY_JOIN>', V_JOIN_CLAUSE);

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_EXPR),
                               'V_EXPR_2 := <value>',
                               V_STAMP);

      POUT_UPDATE_SQL := 'BEGIN ' || POUT_UPDATE_SQL || ' ' || V_EXPR ||
                         ' END;';
    END IF;

  END GET_CALC_ROWBASED_SQL;

  PROCEDURE GET_RECALCULATE_ENTITY_CHANGE(PIN_TBL_ID         IN NUMBER,
                                          PIN_ENTITY_ID      IN NUMBER,
                                          PIN_HAS_ENTITY_IDS IN NUMBER,
                                          POUT_UPDATE_SQL    IN OUT CLOB) IS
    V_EXPR                  CLOB;
    V_TABLE_NAME            VARCHAR2(30 CHAR);
    V_INPUT_FLDS            CLOB;
    V_INPUT_FLDS_INIT       CLOB;
    V_INPUT_FLDS_AFTER      CLOB;
    V_OUTPUT_FLD_IDS        CLOB;
    V_SET_STMT              CLOB;
    V_STAMP                 VARCHAR2(200 CHAR);
    V_ENTITY_LIST           CLOB;
    V_ENTITY_FLD_LIST       CLOB;
    V_ENTITY_FLD_LIST_AFTER CLOB;
    V_JOIN_CLAUSE           CLOB;
    V_HAS_CALCULATIONS      NUMBER(1) := 0;
    V_CASE_WHEN_CLAUSES     CLOB;
    V_EXPR_RESOLVED         CLOB;
    V_ENTITY_LIST_CROSS     CLOB;
    V_CROSS_ENTITY_JOIN     CLOB;
    V_ADDED_ROW_ID          NUMBER(1) := 0;
    V_OUTPUT_FLD_TBL        TABLETYPE_NUMBER;
  BEGIN
    V_STAMP := 'TABLE_CALCULATIONS.GET_CALC_ROWBASED_SQL - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    SELECT TABLES_PHYSICAL_NAME
      INTO V_TABLE_NAME
      FROM TABLES
     WHERE TABLES_ID = PIN_TBL_ID;

    SELECT RTRIM(XMLAGG(XMLELEMENT(E, V_TABLE_NAME || '.' || TC_PHYSICAL_NAME || ' AS ' || TC_PHYSICAL_NAME, ',').EXTRACT('//text()') ORDER BY TC_ORDER)
                 .GETCLOBVAL(),
                 ',') AS LIST,
           RTRIM(XMLAGG(XMLELEMENT(E, TC_PHYSICAL_NAME, ',').EXTRACT('//text()') ORDER BY TC_ORDER)
                 .GETCLOBVAL(),
                 ',') AS LIST1
      INTO V_INPUT_FLDS_INIT, V_INPUT_FLDS_AFTER
      FROM TABLE_COLUMNS
      LEFT JOIN FIELDS
        ON TC_FLD_ID = FLD_ID
     WHERE TC_TABLES_ID = PIN_TBL_ID;

    V_INPUT_FLDS := V_INPUT_FLDS_INIT;
    V_EXPR       := 'SELECT ' || V_INPUT_FLDS || ' <ENTITY_FIELDS> ' ||
                    ' FROM ' || V_TABLE_NAME || '<ENTITY_JOIN>';

    V_INPUT_FLDS := V_INPUT_FLDS_INIT || '<ENTITY_FIELDS_AFTER>';

    FOR C IN (SELECT FLD_COLUMN_NAME,
                     FLD_LENGTH,
                     FLD_DATA_TYPE,
                     TBLCER_EXP_RESOLVED,
                     TBLCER_ENTITIES_USED,
                     TBLCER_ENTITY_FLDS_USED,
					 TBLCER_JOINS,
                     TBLCD_NULL_CALCS,
                     TBLCD_INPUT_FLD_ID,
                     CROSS_REC_ENTITIES,
                     TBLCD_OUTPUT_FLD_ID,
                     TBLCD_EXP_ID,
                     TBLCD_ORDER
                FROM (SELECT DISTINCT TBLCD_NULL_CALCS,
                                      TO_CHAR(SUBSTR(TBLCD_INPUT_FLD_ID,
                                                     1,
                                                     4000)) AS TBLCD_INPUT_FLD_ID,
                                      TBLCD_OUTPUT_FLD_ID,
                                      LISTAGG(TBLCC_ENTITIES, ',') WITHIN GROUP(ORDER BY TBLCC_EXP_ID) OVER(PARTITION BY TBLCC_EXP_ID) CROSS_REC_ENTITIES,
                                      TBLCD_EXP_ID,
                                      TBLCD_ORDER
                        FROM TBL_CALC_DEFINITIONS
                        LEFT JOIN TBL_CALC_CROSSREC
                          ON TBLCC_EXP_ID = TBLCD_EXP_ID
                       WHERE TBLCD_INPUT_TBL_ID = PIN_TBL_ID)
                JOIN TBL_CALC_EXP_RESOLVED
                  ON TBLCER_EXP_ID = TBLCD_EXP_ID
                JOIN FIELDS
                  ON FLD_ID = TBLCD_OUTPUT_FLD_ID
               WHERE (TBLCER_ENTITIES_USED IS NOT NULL OR
                     CROSS_REC_ENTITIES IS NOT NULL)
                 AND ((TABLETYPE_NUMBER(PIN_ENTITY_ID) SUBMULTISET
                      TBLCER_ENTITIES_USED) OR
                     INSTR(',' || CROSS_REC_ENTITIES || ',',
                            ',' || PIN_ENTITY_ID || ',') > 0)
               ORDER BY TBLCD_ORDER) LOOP

      IF V_HAS_CALCULATIONS = 0 THEN
        V_HAS_CALCULATIONS := 1;
      END IF;

      V_OUTPUT_FLD_IDS := V_OUTPUT_FLD_IDS || (CASE
                            WHEN V_OUTPUT_FLD_IDS IS NULL THEN
                             TO_CHAR(C.TBLCD_OUTPUT_FLD_ID)
                            ELSE
                             ',' || TO_CHAR(C.TBLCD_OUTPUT_FLD_ID)
                          END);

      V_EXPR_RESOLVED := C.TBLCER_EXP_RESOLVED;

       IF C.TBLCD_NULL_CALCS = 0 AND C.TBLCD_INPUT_FLD_ID IS NOT NULL THEN
        SELECT LISTAGG(FLD_COLUMN_NAME, ' IS NOT NULL AND ') WITHIN GROUP(ORDER BY FLD_COLUMN_NAME)
          INTO V_CASE_WHEN_CLAUSES
          FROM FIELDS
          JOIN (SELECT REGEXP_SUBSTR(STR, '[[:digit:]]+', 1, LEVEL) AS SUBSTR
                  FROM (SELECT C.TBLCD_INPUT_FLD_ID AS STR FROM DUAL)
                CONNECT BY LEVEL <=
                           LENGTH(REGEXP_REPLACE(STR, '[[:digit:]]+')) + 1) FLDS
            ON FLDS.SUBSTR = FLD_ID;

        V_CASE_WHEN_CLAUSES := V_CASE_WHEN_CLAUSES || ' IS NOT NULL ';
      END IF;

      IF C.CROSS_REC_ENTITIES IS NOT NULL THEN
        BUILD_ENTITY_JOIN_LIST(PIN_TBL_ID,
                               NULL,
                               C.CROSS_REC_ENTITIES,
                               V_ENTITY_LIST_CROSS,
                               V_CROSS_ENTITY_JOIN);
      END IF;

	  IF (C.TBLCER_JOINS IS NOT NULL)
      THEN
          V_CROSS_ENTITY_JOIN := NVL(V_CROSS_ENTITY_JOIN, ' ') || ' ' || C.TBLCER_JOINS;
      END IF;

      IF C.TBLCER_ENTITIES_USED IS NOT NULL THEN

        BUILD_ENTITY_JOIN_TABLE(PIN_TBL_ID,
                                C.TBLCER_ENTITIES_USED,
                                V_ENTITY_LIST,
                                V_JOIN_CLAUSE);

        IF V_ADDED_ROW_ID = 0 AND
           INSTR(',' || V_ENTITY_LIST || ',', ',' || PIN_ENTITY_ID || ',') > 0 THEN
          V_ADDED_ROW_ID := 1;
        END IF;

        FOR Z IN (SELECT COLUMN_VALUE FROM TABLE(C.TBLCER_ENTITY_FLDS_USED)) LOOP
          IF INSTR(V_ENTITY_FLD_LIST_AFTER || ',',
                   ',' || REPLACE(Z.COLUMN_VALUE, '.') || ',') < 1 OR
             V_ENTITY_FLD_LIST IS NULL THEN

            V_ENTITY_FLD_LIST       := V_ENTITY_FLD_LIST || ',' ||
                                       Z.COLUMN_VALUE || ' AS ' ||
                                       REPLACE(Z.COLUMN_VALUE, '.');
            V_ENTITY_FLD_LIST_AFTER := V_ENTITY_FLD_LIST_AFTER || ',' ||
                                       REPLACE(Z.COLUMN_VALUE, '.');

            IF C.TBLCD_NULL_CALCS = 0 THEN

              V_CASE_WHEN_CLAUSES := V_CASE_WHEN_CLAUSES || CASE WHEN V_CASE_WHEN_CLAUSES IS NOT NULL THEN ' AND ' END ||
                                     REPLACE(Z.COLUMN_VALUE, '.') ||
                                     ' IS NOT NULL ';

            END IF;
          END IF;
        END LOOP;
      END IF;

      IF C.TBLCD_NULL_CALCS = 0 THEN

        V_CASE_WHEN_CLAUSES := 'CASE WHEN ' || V_CASE_WHEN_CLAUSES ||
                               '  THEN ';
        V_EXPR_RESOLVED     := V_CASE_WHEN_CLAUSES || V_EXPR_RESOLVED ||
                               'END ';
      END IF;
      BUILD_STREAM_INDEPENDENT(V_EXPR_RESOLVED,
                               C.FLD_COLUMN_NAME,
                               V_TABLE_NAME || '.' || C.FLD_COLUMN_NAME,
                               V_INPUT_FLDS,
                               '(' || V_EXPR || ') ' || V_TABLE_NAME,
                               V_CROSS_ENTITY_JOIN,
                               V_EXPR);
      V_ENTITY_LIST_CROSS := NULL;
      V_CROSS_ENTITY_JOIN := NULL;
      IF V_SET_STMT IS NOT NULL THEN
        V_SET_STMT := V_SET_STMT || ',';
      END IF;

      IF C.FLD_DATA_TYPE = 6 THEN
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= CASE WHEN T_CALC.' || C.FLD_COLUMN_NAME ||
                      ' > -10000000000 AND T_CALC.' || C.FLD_COLUMN_NAME ||
                      ' < 10000000000 THEN ROUND(T_CALC.' ||
                      C.FLD_COLUMN_NAME || ',' || C.FLD_LENGTH ||
                      ') ELSE NULL END';
      ELSIF C.FLD_DATA_TYPE IN (1, 4) THEN
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= SUBSTR(T_CALC.' || C.FLD_COLUMN_NAME || ', 1 , ' ||
                      C.FLD_LENGTH || ')';
      ELSE
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= T_CALC.' || C.FLD_COLUMN_NAME;
      END IF;

    END LOOP;

    IF V_ADDED_ROW_ID = 1 and PIN_HAS_ENTITY_IDS = 1 THEN
      V_JOIN_CLAUSE := V_JOIN_CLAUSE ||
                       ' JOIN TABLE(ROW_IDENTIFIERS) ON COLUMN_VALUE = E' ||
                       PIN_ENTITY_ID || '.ROW_IDENTIFIER';
    END IF;

    IF V_HAS_CALCULATIONS = 1 THEN
      V_EXPR := CASE
                  WHEN V_ADDED_ROW_ID = 1 and PIN_HAS_ENTITY_IDS = 1 THEN
                   ' DECLARE ROW_IDENTIFIERS TABLETYPE_NUMBER := :1; '
                END || 'BEGIN
                MERGE INTO ' || V_TABLE_NAME ||
                ' T_UPD USING (SELECT ' || V_INPUT_FLDS || ' FROM (' || V_EXPR || ')' ||
                V_TABLE_NAME || ') T_CALC ON(T_UPD.ROW_IDENTIFIER = T_CALC.ROW_IDENTIFIER)
              WHEN MATCHED THEN UPDATE SET ' || V_SET_STMT ||
                '; END;';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_EXPR),
                               'V_EXPR_1 := <value>',
                               V_STAMP);

      V_EXPR := REPLACE(V_EXPR, '<ENTITY_FIELDS>', V_ENTITY_FLD_LIST);
      V_EXPR := REPLACE(V_EXPR,
                        '<ENTITY_FIELDS_AFTER>',
                        V_ENTITY_FLD_LIST_AFTER);
      V_EXPR := REPLACE(V_EXPR, '<ENTITY_JOIN>', V_JOIN_CLAUSE);

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_EXPR),
                               'V_EXPR_2 := <value>',
                               V_STAMP);

      --EXECUTE IMMEDIATE V_EXPR;
      SELECT TO_NUMBER(REGEXP_SUBSTR(STR, '[[:digit:]]+', 1, LEVEL)) AS SUBSTR
        BULK COLLECT
        INTO V_OUTPUT_FLD_TBL
        FROM (SELECT V_OUTPUT_FLD_IDS AS STR FROM DUAL)
      CONNECT BY LEVEL <= LENGTH(REGEXP_REPLACE(STR, '[[:digit:]]+')) + 1;

      POUT_UPDATE_SQL := 'BEGIN ' || POUT_UPDATE_SQL || ' ' || V_EXPR ||
                         ' END;';

      GET_CALCULATE_SQL(PIN_TBL_ID,
                        V_OUTPUT_FLD_TBL,
                        NULL,
                        1,
                        POUT_UPDATE_SQL);

    END IF;
  END GET_RECALCULATE_ENTITY_CHANGE;

  PROCEDURE GET_CALCULATE_INDEPENDENT_SQL(PIN_TBL_ID      NUMBER,
                                          POUT_UPDATE_SQL IN OUT CLOB) IS

    V_EXPR                  CLOB;
    V_TABLE_NAME            VARCHAR2(30 CHAR);
    V_INPUT_FLDS            CLOB;
    V_INPUT_FLDS_INIT       CLOB;
    V_INPUT_FLDS_AFTER      CLOB;
    V_OUTPUT_FLD_IDS        CLOB;
    V_SET_STMT              CLOB;
    V_STAMP                 VARCHAR2(200 CHAR);
    V_ENTITY_LIST           CLOB;
    V_ENTITY_FLD_LIST       CLOB;
    V_ENTITY_FLD_LIST_AFTER CLOB;
    V_JOIN_CLAUSE           CLOB;
    V_HAS_CALCULATIONS      NUMBER(1) := 0;
    V_CASE_WHEN_CLAUSES     CLOB;
    V_EXPR_RESOLVED         CLOB;
    V_ENTITY_LIST_CROSS     CLOB;
    V_CROSS_ENTITY_JOIN     CLOB;
    V_OUTPUT_FLD_TBL        TABLETYPE_NUMBER;
  BEGIN
    V_STAMP := 'TABLE_CALCULATIONS.GET_CALCULATE_INDEPENDENT_SQL - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    SELECT TABLES_PHYSICAL_NAME
      INTO V_TABLE_NAME
      FROM TABLES
     WHERE TABLES_ID = PIN_TBL_ID;

    SELECT RTRIM(XMLAGG(XMLELEMENT(E, V_TABLE_NAME || '.' || TC_PHYSICAL_NAME || ' AS ' || TC_PHYSICAL_NAME, ',').EXTRACT('//text()') ORDER BY TC_ORDER)
                 .GETCLOBVAL(),
                 ',') AS LIST,
           RTRIM(XMLAGG(XMLELEMENT(E, TC_PHYSICAL_NAME, ',').EXTRACT('//text()') ORDER BY TC_ORDER)
                 .GETCLOBVAL(),
                 ',') AS LIST1
      INTO V_INPUT_FLDS_INIT, V_INPUT_FLDS_AFTER
      FROM TABLE_COLUMNS
      LEFT JOIN FIELDS
        ON TC_FLD_ID = FLD_ID
     WHERE TC_TABLES_ID = PIN_TBL_ID;

    V_INPUT_FLDS := V_INPUT_FLDS_INIT;
    V_EXPR       := 'SELECT ' || V_INPUT_FLDS || ' <ENTITY_FIELDS> ' ||
                    ' FROM ' || V_TABLE_NAME || '<ENTITY_JOIN>';

    V_INPUT_FLDS := V_INPUT_FLDS_INIT || '<ENTITY_FIELDS_AFTER>';

    FOR C IN (SELECT FLD_COLUMN_NAME,
                     FLD_LENGTH,
                     FLD_DATA_TYPE,
                     TBLCER_EXP_RESOLVED,
                     TBLCER_ENTITIES_USED,
                     TBLCER_ENTITY_FLDS_USED,
					 TBLCER_JOINS,
                     TBLCD_NULL_CALCS,
                     TBLCD_INPUT_FLD_ID,
                     CROSS_REC_ENTITIES,
                     TBLCD_OUTPUT_FLD_ID,
                     TBLCD_EXP_ID,
                     TBLCD_ORDER
                FROM (SELECT DISTINCT TBLCD_NULL_CALCS,
                                      TO_CHAR(SUBSTR(TBLCD_INPUT_FLD_ID,
                                                     1,
                                                     4000)) AS TBLCD_INPUT_FLD_ID,
                                      TBLCD_OUTPUT_FLD_ID,
                                      LISTAGG(TBLCC_ENTITIES, ',') WITHIN GROUP(ORDER BY TBLCC_EXP_ID) OVER(PARTITION BY TBLCC_EXP_ID) CROSS_REC_ENTITIES,
                                      TBLCD_EXP_ID,
                                      TBLCD_ORDER
                        FROM TBL_CALC_DEFINITIONS
                        LEFT JOIN TBL_CALC_CROSSREC
                          ON TBLCC_EXP_ID = TBLCD_EXP_ID
                       WHERE TBLCD_INPUT_TBL_ID = PIN_TBL_ID)
                JOIN TBL_CALC_EXP_RESOLVED
                  ON TBLCER_EXP_ID = TBLCD_EXP_ID
                JOIN FIELDS
                  ON FLD_ID = TBLCD_OUTPUT_FLD_ID

               WHERE (TBLCD_INPUT_FLD_ID IS NULL OR
                     TBLCER_ENTITIES_USED IS NOT NULL)
               ORDER BY TBLCD_ORDER) LOOP

      IF V_HAS_CALCULATIONS = 0 THEN
        V_HAS_CALCULATIONS := 1;
      END IF;

      V_OUTPUT_FLD_IDS := V_OUTPUT_FLD_IDS || (CASE
                            WHEN V_OUTPUT_FLD_IDS IS NULL THEN
                             TO_CHAR(C.TBLCD_OUTPUT_FLD_ID)
                            ELSE
                             ',' || TO_CHAR(C.TBLCD_OUTPUT_FLD_ID)
                          END);

      V_EXPR_RESOLVED := C.TBLCER_EXP_RESOLVED;

       IF C.TBLCD_NULL_CALCS = 0 AND C.TBLCD_INPUT_FLD_ID IS NOT NULL THEN
        SELECT LISTAGG(FLD_COLUMN_NAME, ' IS NOT NULL AND ') WITHIN GROUP(ORDER BY FLD_COLUMN_NAME)
          INTO V_CASE_WHEN_CLAUSES
          FROM FIELDS
          JOIN (SELECT REGEXP_SUBSTR(STR, '[[:digit:]]+', 1, LEVEL) AS SUBSTR
                  FROM (SELECT C.TBLCD_INPUT_FLD_ID AS STR FROM DUAL)
                CONNECT BY LEVEL <=
                           LENGTH(REGEXP_REPLACE(STR, '[[:digit:]]+')) + 1) FLDS
            ON FLDS.SUBSTR = FLD_ID;

        V_CASE_WHEN_CLAUSES := V_CASE_WHEN_CLAUSES || ' IS NOT NULL ';
      END IF;

      IF C.CROSS_REC_ENTITIES IS NOT NULL THEN
        BUILD_ENTITY_JOIN_LIST(PIN_TBL_ID,
                               NULL,
                               C.CROSS_REC_ENTITIES,
                               V_ENTITY_LIST_CROSS,
                               V_CROSS_ENTITY_JOIN);
      END IF;

	  IF (C.TBLCER_JOINS IS NOT NULL)
      THEN
          V_CROSS_ENTITY_JOIN := NVL(V_CROSS_ENTITY_JOIN, ' ') || ' ' || C.TBLCER_JOINS;
      END IF;

      IF C.TBLCER_ENTITIES_USED IS NOT NULL THEN

        BUILD_ENTITY_JOIN_TABLE(PIN_TBL_ID,
                                C.TBLCER_ENTITIES_USED,
                                V_ENTITY_LIST,
                                V_JOIN_CLAUSE);

        FOR Z IN (SELECT COLUMN_VALUE FROM TABLE(C.TBLCER_ENTITY_FLDS_USED)) LOOP
          IF INSTR(V_ENTITY_FLD_LIST_AFTER || ',',
                   ',' || REPLACE(Z.COLUMN_VALUE, '.') || ',') < 1 OR
             V_ENTITY_FLD_LIST IS NULL THEN

            V_ENTITY_FLD_LIST       := V_ENTITY_FLD_LIST || ',' ||
                                       Z.COLUMN_VALUE || ' AS ' ||
                                       REPLACE(Z.COLUMN_VALUE, '.');
            V_ENTITY_FLD_LIST_AFTER := V_ENTITY_FLD_LIST_AFTER || ',' ||
                                       REPLACE(Z.COLUMN_VALUE, '.');

            IF C.TBLCD_NULL_CALCS = 0 THEN

              V_CASE_WHEN_CLAUSES := V_CASE_WHEN_CLAUSES ||CASE WHEN V_CASE_WHEN_CLAUSES IS NOT NULL THEN ' AND ' END ||
                                     REPLACE(Z.COLUMN_VALUE, '.') ||
                                     ' IS NOT NULL ';

            END IF;
          END IF;
        END LOOP;
      END IF;

      IF C.TBLCD_NULL_CALCS = 0 AND V_CASE_WHEN_CLAUSES IS NOT NULL THEN

        V_CASE_WHEN_CLAUSES := 'CASE WHEN ' || V_CASE_WHEN_CLAUSES ||
                               '  THEN ';
        V_EXPR_RESOLVED     := V_CASE_WHEN_CLAUSES || V_EXPR_RESOLVED ||
                               'END ';
      END IF;
      BUILD_STREAM_INDEPENDENT(V_EXPR_RESOLVED,
                               C.FLD_COLUMN_NAME,
                               V_TABLE_NAME || '.' || C.FLD_COLUMN_NAME,
                               V_INPUT_FLDS,
                               '(' || V_EXPR || ') ' || V_TABLE_NAME,
                               V_CROSS_ENTITY_JOIN,
                               V_EXPR);
      V_ENTITY_LIST_CROSS := NULL;
      V_CROSS_ENTITY_JOIN := NULL;
      IF V_SET_STMT IS NOT NULL THEN
        V_SET_STMT := V_SET_STMT || ',';
      END IF;

      IF C.FLD_DATA_TYPE = 6 THEN
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= CASE WHEN T_CALC.' || C.FLD_COLUMN_NAME ||
                      ' > -10000000000 AND T_CALC.' || C.FLD_COLUMN_NAME ||
                      ' < 10000000000 THEN ROUND(T_CALC.' ||
                      C.FLD_COLUMN_NAME || ',' || C.FLD_LENGTH ||
                      ') ELSE NULL END';
      ELSIF C.FLD_DATA_TYPE IN (1, 4) THEN
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= SUBSTR(T_CALC.' || C.FLD_COLUMN_NAME || ', 1 , ' ||
                      C.FLD_LENGTH || ')';
      ELSE
        V_SET_STMT := V_SET_STMT || 'T_UPD.' || C.FLD_COLUMN_NAME ||
                      '= T_CALC.' || C.FLD_COLUMN_NAME;
      END IF;

    END LOOP;

    IF V_HAS_CALCULATIONS = 1 THEN
      V_EXPR := ' MERGE INTO ' || V_TABLE_NAME || ' T_UPD USING (SELECT ' ||
                V_INPUT_FLDS || ' FROM (' || V_EXPR || ')' || V_TABLE_NAME ||
                ') T_CALC ON(T_UPD.ROW_IDENTIFIER = T_CALC.ROW_IDENTIFIER)
              WHEN MATCHED THEN UPDATE SET ' || V_SET_STMT || ';';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_EXPR),
                               'V_EXPR_1 := <value>',
                               V_STAMP);

      V_EXPR := REPLACE(V_EXPR, '<ENTITY_FIELDS>', V_ENTITY_FLD_LIST);
      V_EXPR := REPLACE(V_EXPR,
                        '<ENTITY_FIELDS_AFTER>',
                        V_ENTITY_FLD_LIST_AFTER);
      V_EXPR := REPLACE(V_EXPR, '<ENTITY_JOIN>', V_JOIN_CLAUSE);

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_EXPR),
                               'V_EXPR_2 := <value>',
                               V_STAMP);

      --EXECUTE IMMEDIATE V_EXPR;
      SELECT TO_NUMBER(REGEXP_SUBSTR(STR, '[[:digit:]]+', 1, LEVEL)) AS SUBSTR
        BULK COLLECT
        INTO V_OUTPUT_FLD_TBL
        FROM (SELECT V_OUTPUT_FLD_IDS AS STR FROM DUAL)
      CONNECT BY LEVEL <= LENGTH(REGEXP_REPLACE(STR, '[[:digit:]]+')) + 1;

      POUT_UPDATE_SQL := 'BEGIN ' || POUT_UPDATE_SQL || ' ' || V_EXPR ||
                         ' END;';

      GET_CALCULATE_SQL(PIN_TBL_ID,
                        V_OUTPUT_FLD_TBL,
                        NULL,
                        1,
                        POUT_UPDATE_SQL);

      POUT_UPDATE_SQL := 'BEGIN ' || POUT_UPDATE_SQL || ' END;';

    END IF;

  END GET_CALCULATE_INDEPENDENT_SQL;

  PROCEDURE GET_FIRST_CALCULATIONS_SQL(PIN_TBL_ID           NUMBER,
                                       PIN_DIMENSION_FLD_ID TABLETYPE_NUMBER,
                                       POUT_UPDATE_SQL      IN OUT CLOB) IS

  BEGIN

    GET_CALCULATE_SQL(PIN_TBL_ID,
                      PIN_DIMENSION_FLD_ID,
                      NULL,
                      1,
                      POUT_UPDATE_SQL);
    GET_CALCULATE_INDEPENDENT_SQL(PIN_TBL_ID, POUT_UPDATE_SQL);

  END GET_FIRST_CALCULATIONS_SQL;

  PROCEDURE EXECUTE_FIRST_CALCULATIONS(PIN_UPDATE_SQL IN CLOB) IS
  BEGIN

    EXECUTE IMMEDIATE PIN_UPDATE_SQL;

  END;

  PROCEDURE GET_CALCULATE_SQL(PIN_TBL_ID       NUMBER,
                              PIN_INPUT_FLD_ID TABLETYPE_NUMBER,
                              PIN_HAS_ROW_IDS  NUMBER DEFAULT NULL,
                              PIN_UPDATE_MODE  NUMBER,
                              POUT_UPDATE_SQL  IN OUT CLOB) IS

  BEGIN

    GET_CALC_ROWBASED_SQL(PIN_TBL_ID,
                          PIN_INPUT_FLD_ID,
                          PIN_HAS_ROW_IDS,
                          PIN_UPDATE_MODE,
                          POUT_UPDATE_SQL);

    IF POUT_UPDATE_SQL IS NOT NULL THEN
      POUT_UPDATE_SQL := 'BEGIN ' || POUT_UPDATE_SQL || ' END;';
    END IF;

  END GET_CALCULATE_SQL;

  PROCEDURE EXECUTE_CALCULATE(PIN_ROW_IDS    TABLETYPE_NUMBER,
                              PIN_UPDATE_SQL CLOB) IS

  BEGIN

    EXECUTE IMMEDIATE PIN_UPDATE_SQL
      USING PIN_ROW_IDS;

  END;

  --
  --
  /*----------------------------- GET_SQLS_FOR_TD_QUERIES --------------------------------------
    -- Author     : Kristo, Robert
  */
  PROCEDURE GET_SQLS_FOR_TD_QUERIES(PI_VIEW_ID              NUMBER,
                                    PI_FROM_CLAUSE          CLOB,
                                    PI_FIELD_ID             NUMBER,
									PI_WEIGHT_FIELD_ID      NUMBER,
                                    PI_ROW_PATH             TABLETYPE_MDL_DIM_PATH_EXP,
                                    PI_COL_PATH             TABLETYPE_MDL_DIM_PATH_EXP,
                                    PI_OLD_SUM              NUMBER,
                                    PI_NEW_SUM              VARCHAR2,
                                    PI_TD_TYPE              NUMBER,
                                    PI_TD_DISTRIBUTION_TYPE NUMBER,
									PI_PROPORTION_FLD_ID    NUMBER,
                                    PI_PROPORTION_FLD_VALUE NUMBER,

                                    POUT_SQL_TD            OUT NOCOPY CLOB,
                                    POUT_TD_DIFFERENCE_SQL OUT NOCOPY CLOB,
                                    POUT_SQL_CALC          OUT NOCOPY CLOB) AS
    V_ROW_EXPANDED_DIM_LIST TABLETYPE_MDL_DIM_PATH_EXP;
    V_COL_EXPANDED_DIM_LIST TABLETYPE_MDL_DIM_PATH_EXP;

    V_TABLE_ID             NUMBER;
    V_FLD_LENGTH           NUMBER;
    V_VIEW_DEF             CLOB;
    V_TABLE_NAME           VARCHAR2(30);
    V_FIELD_COLUMN_NAME    VARCHAR2(30);
    V_FLD_DATA_TYPE        NUMBER;
	V_WEIGHT_COLUMN_NAME   VARCHAR2(30);
	V_PROPORTION_COLUMN_NAME VARCHAR2(30);
    V_PARENT_FILTER        CLOB;
    V_PARENT_FILTER_UPDATE CLOB;
    V_UPDATE_SELECT        CLOB;
    V_UPDATE_SET_STATEMENT CLOB;
	V_IS_LEAF_LEVEL        NUMBER;

    V_STAMP VARCHAR2(200 CHAR);

    v_tu_join               CLOB;
    v_tu_cols               CLOB;
    v_rebuilt_from_clause   CLOB;
  BEGIN
    V_STAMP := 'TABLE_CALCULATIONS.GET_SQLS_FOR_TD_QUERIES - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    -- LOG AND VALIDATE INPUT PARAMETERS

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_VIEW_ID),
                               ',pi_view_id => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PI_FROM_CLAUSE),
                               ',pi_from_clause => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_FIELD_ID),
                               ',pi_field_id => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_WEIGHT_FIELD_ID),
                               ',pi_weight_field_id => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(PI_ROW_PATH),
                               ',pi_row_path => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(PI_COL_PATH),
                               ',pi_col_path => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_OLD_SUM),
                               ',pi_old_sum => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PI_NEW_SUM),
                               ',pi_new_sum => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_TD_TYPE),
                               ',pi_td_type => <value>',
                               V_STAMP);
	  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_TD_DISTRIBUTION_TYPE),
                               ',PI_TD_DISTRIBUTION_TYPE => <value>',
                               V_STAMP);
	  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_PROPORTION_FLD_ID),
                               ',PI_PROPORTION_FLD_ID => <value>',
                               V_STAMP);
	  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_PROPORTION_FLD_VALUE),
                               ',PI_PROPORTION_FLD_VALUE => <value>',
                               V_STAMP);
    END;

	v_row_expanded_dim_list := PI_ROW_PATH;
    v_col_expanded_dim_list := PI_COL_PATH;

	V_IS_LEAF_LEVEL := IS_LEAF_LEVEL(PI_VIEW_ID, v_row_expanded_dim_list, v_col_expanded_dim_list);

	-- GET THE FIELD's physical name
    SELECT FLD_COLUMN_NAME, FLD_DATA_TYPE
    INTO V_FIELD_COLUMN_NAME, V_FLD_DATA_TYPE
    FROM FIELDS
    WHERE FLD_ID = pi_field_id;

	IF (PI_PROPORTION_FLD_ID IS NOT NULL)
    THEN
        SELECT FLD_COLUMN_NAME
        INTO V_PROPORTION_COLUMN_NAME
        FROM FIELDS
        WHERE FLD_ID = PI_PROPORTION_FLD_ID;
    END IF;

	IF (PI_WEIGHT_FIELD_ID IS NOT NULL)
    THEN
        SELECT FLD_COLUMN_NAME
        INTO V_WEIGHT_COLUMN_NAME
        FROM FIELDS
        WHERE FLD_ID = PI_WEIGHT_FIELD_ID;
    END IF;

    -- get info using the view id
    SELECT OD_DEFINITION, TABLES_ID, TABLES_PHYSICAL_NAME
      INTO V_VIEW_DEF, V_TABLE_ID, V_TABLE_NAME
      FROM OBJECT_DEFINITIONS
     INNER JOIN TABLE_REFERENCES
        ON TREF_ID = EXTRACTVALUE(XMLTYPE(OD_DEFINITION),
                                  '/pivotView/tableReferenceId')
     INNER JOIN TABLES
        ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
     WHERE OD_CONTAINER_ID = PI_VIEW_ID;

    -- get the additional info needed in order to create the where condition for the rows


    -- create the where condition for the rows
    FOR c IN (SELECT DIM_ID,
                     DIM_TYPE,
                     DIM_NAME,
                     DIM_DATA_TYPE,
                     DIM_ORDER,
                     DIM_VALUE,
                     DIM_BASE_ID
                FROM TABLE(V_ROW_EXPANDED_DIM_LIST)
               ORDER BY DIM_ORDER) LOOP
      IF (C.DIM_VALUE IS NOT NULL) THEN
        V_PARENT_FILTER_UPDATE := V_PARENT_FILTER_UPDATE || CASE
                             WHEN V_PARENT_FILTER_UPDATE IS NOT NULL THEN
                              CHR(10) || 'AND '
                             ELSE
                              NULL
                           END || 'ALL_COMB.' || c.DIM_NAME || ' = ' ||
                           PLANNING_MODELS.FORMAT_CONSTANT_VALUE(PI_DIM_TYPE      => C.DIM_TYPE,
                                                                 PI_DIM_DATA_TYPE => C.DIM_DATA_TYPE,
                                                                 PI_DIM_VALUE     => C.DIM_VALUE);
        IF (NVL(C.DIM_BASE_ID,C.DIM_ID)= C.DIM_ID) THEN
          V_PARENT_FILTER := V_PARENT_FILTER || CASE
                             WHEN v_parent_filter IS NOT NULL THEN
                              CHR(10) || 'AND '
                             ELSE
                              NULL
                           END || 'ALL_COMB.' || c.DIM_NAME || ' = ' ||
                           PLANNING_MODELS.FORMAT_CONSTANT_VALUE(PI_DIM_TYPE      => C.DIM_TYPE,
                                                                 PI_DIM_DATA_TYPE => C.DIM_DATA_TYPE,
                                                                 PI_DIM_VALUE     => C.DIM_VALUE);
        END IF;
      END IF;
    END LOOP;

    -- get the additional info needed in order to create the where condition for the columns

    -- create the where condition for the columns
    FOR C IN (SELECT DIM_ID,
                     DIM_TYPE,
                     DIM_NAME,
                     DIM_DATA_TYPE,
                     DIM_ORDER,
                     DIM_VALUE,
                     DIM_BASE_ID
                FROM TABLE(V_COL_EXPANDED_DIM_LIST)
               ORDER BY DIM_ORDER) LOOP
      IF (C.DIM_VALUE IS NOT NULL) THEN
        V_PARENT_FILTER_UPDATE := V_PARENT_FILTER_UPDATE || CASE
                             WHEN V_PARENT_FILTER_UPDATE IS NOT NULL THEN
                              CHR(10) || 'AND '
                             ELSE
                              NULL
                           END || 'ALL_COMB.' || c.DIM_NAME || ' = ' ||
                           PLANNING_MODELS.FORMAT_CONSTANT_VALUE(PI_DIM_TYPE      => C.DIM_TYPE,
                                                                 PI_DIM_DATA_TYPE => C.DIM_DATA_TYPE,
                                                                 PI_DIM_VALUE     => C.DIM_VALUE);
        IF (NVL(C.DIM_BASE_ID,C.DIM_ID)= C.DIM_ID) THEN
          V_PARENT_FILTER := V_PARENT_FILTER || CASE
                             WHEN v_parent_filter IS NOT NULL THEN
                              CHR(10) || 'AND '
                             ELSE
                              NULL
                           END || 'ALL_COMB.' || c.DIM_NAME || ' = ' ||
                           PLANNING_MODELS.FORMAT_CONSTANT_VALUE(PI_DIM_TYPE      => C.DIM_TYPE,
                                                                 PI_DIM_DATA_TYPE => C.DIM_DATA_TYPE,
                                                                 PI_DIM_VALUE     => C.DIM_VALUE);
        END IF;
      END IF;
    END LOOP;

    -- remove the first condition from where
    IF V_PARENT_FILTER IS NOT NULL THEN
      V_PARENT_FILTER := ' WHERE ' ||
                         REPLACE(REPLACE(SUBSTR(V_PARENT_FILTER, 5),
                                         'ALL_COMB.',
                                         'TAB.'),
                                 'COMB.',
                                 'TAB.');
    END IF;
    --
     IF V_PARENT_FILTER_UPDATE IS NOT NULL THEN
      V_PARENT_FILTER_UPDATE := ' WHERE ' ||
                         REPLACE(REPLACE(SUBSTR(V_PARENT_FILTER_UPDATE, 5),
                                         'ALL_COMB.',
                                         'TAB.'),
                                 'COMB.',
                                 'TAB.');
    END IF;
    -- get time unit joins
    PLANNING_MODELS.GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => V_ROW_EXPANDED_DIM_LIST,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    IF v_tu_cols IS NULL THEN
       PLANNING_MODELS.GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => V_COL_EXPANDED_DIM_LIST,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    END IF;
    PLANNING_MODELS.GET_REBUILT_FROM_CLAUSE(PI_TU_SELECT         => v_tu_join,
                                            PI_TU_COLUMNS        => v_tu_cols,
                                            PI_ORIG_FROM_CLAUSE  => pi_from_clause,
                                            PI_TABLE_NAME        => v_table_name,
                                            PI_DIM_TYPE          => 8,
                                            PO_FROM_CLAUSE       => v_rebuilt_from_clause);

    -- prepare the select to be updated
    V_UPDATE_SELECT := '(SELECT *
                         FROM ' || v_rebuilt_from_clause ||')';

    -- PREPARE THE SET STATEMENT
    IF (V_FLD_DATA_TYPE = 6) -- numeric field
    THEN
    V_UPDATE_SET_STATEMENT := ' SET TAB.' || V_FIELD_COLUMN_NAME || ' = '
                              || (CASE WHEN V_WEIGHT_COLUMN_NAME IS NOT NULL AND V_IS_LEAF_LEVEL = 0
                                       THEN (' (CASE WHEN TAB.' || V_WEIGHT_COLUMN_NAME || ' IS NULL THEN TAB.' || V_FIELD_COLUMN_NAME || ' ELSE ')
                                       ELSE NULL END)
                              || ' CAST('
                              || CASE WHEN (PI_NEW_SUM IS NULL)
                                           THEN 'NULL'

                                      -- sum; split equally
                                      WHEN (PI_TD_DISTRIBUTION_TYPE = 2 AND PI_TD_TYPE = 0)
                                           THEN PI_NEW_SUM
                                                || ' / (SELECT COUNT(1) FROM ('  || V_UPDATE_SELECT || ') TAB ' || V_PARENT_FILTER_UPDATE || ')'

                                      -- avg; split equally
                                      WHEN (PI_TD_DISTRIBUTION_TYPE = 2 AND PI_TD_TYPE = 1)
                                           THEN PI_NEW_SUM

                                      -- constant
                                      WHEN (PI_TD_TYPE = 2)
                                           THEN PI_NEW_SUM

                                      -- split proportionally
                                      -- sum; denominator=0 => split equally
                                      WHEN (PI_TD_TYPE = 0 AND PI_TD_DISTRIBUTION_TYPE = 1
                                            AND ((PI_PROPORTION_FLD_ID IS NOT NULL AND NVL(PI_PROPORTION_FLD_VALUE, 0) = 0)
                                                  OR
                                                 (PI_PROPORTION_FLD_ID IS NULL AND NVL(PI_OLD_SUM, 0) = 0)
                                                )
                                           )
                                           THEN PI_NEW_SUM
                                                || ' / (SELECT COUNT(1) FROM (' || V_UPDATE_SELECT || ') TAB ' || V_PARENT_FILTER_UPDATE || ')'

                                      -- avg | weighted avg; denominator=0 => split equally
                                      WHEN (PI_TD_TYPE IN (1, 3) AND PI_TD_DISTRIBUTION_TYPE = 1
                                            AND ((PI_PROPORTION_FLD_ID IS NOT NULL AND NVL(PI_PROPORTION_FLD_VALUE, 0) = 0)
                                                  OR
                                                 (PI_PROPORTION_FLD_ID IS NULL AND NVL(PI_OLD_SUM, 0) = 0)
                                                )
                                           )
                                           THEN PI_NEW_SUM

                                      -- sum; split proportionally by other column
                                      WHEN (PI_TD_TYPE = 0 AND NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME) != V_FIELD_COLUMN_NAME)
                                           THEN 'COALESCE(' || V_FIELD_COLUMN_NAME || ', 0) + '
                                                || (CAST(PI_NEW_SUM AS NUMBER) - NVL(PI_OLD_SUM, 0))
                                                || ' * '
                                                || NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME)
                                                || ' / '
                                                || ' (SELECT SUM(' || V_PROPORTION_COLUMN_NAME || ') FROM (' || V_UPDATE_SELECT || ') TAB ' || V_PARENT_FILTER_UPDATE || ')'

                                      -- sum; split proportionally by the same column
                                      WHEN (PI_TD_TYPE = 0)
                                           THEN 'COALESCE(' || V_FIELD_COLUMN_NAME || ', 0) + '
                                                || (CAST(PI_NEW_SUM AS NUMBER) - NVL(PI_OLD_SUM, 0))
                                                || ' * '
                                                || NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME)
                                                || ' / '
                                                || TO_CHAR(NVL(PI_PROPORTION_FLD_VALUE, PI_OLD_SUM))

                                      -- avg; proportionally by other column
                                      WHEN (PI_TD_TYPE = 1 AND NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME) != V_FIELD_COLUMN_NAME)
                                           THEN 'COALESCE(' || V_FIELD_COLUMN_NAME || ', 0) + '
                                                || (CAST(PI_NEW_SUM AS NUMBER) - NVL(PI_OLD_SUM, 0))
                                                || ' * '
                                                || ' (SELECT COUNT(1) FROM (' || V_UPDATE_SELECT || ') TAB ' || V_PARENT_FILTER_UPDATE || ')'
                                                || ' * '
                                                || V_PROPORTION_COLUMN_NAME
                                                || ' / '
                                                || ' (SELECT SUM(' || V_PROPORTION_COLUMN_NAME || ') FROM (' || V_UPDATE_SELECT || ') TAB ' || V_PARENT_FILTER_UPDATE || ')'

                                      -- avg | weighted avg; split proportionally by the same column
                                      ELSE 'COALESCE(' || V_FIELD_COLUMN_NAME || ', 0) * '
                                           || PI_NEW_SUM || ' / ' || TO_CHAR(PI_OLD_SUM)
                                 END
                              || ' AS NUMBER'
                              || COMMONS.FIELD_PRECISION_AND_SCALE(V_FIELD_COLUMN_NAME) || ')'
                              || (CASE WHEN V_WEIGHT_COLUMN_NAME IS NOT NULL AND V_IS_LEAF_LEVEL = 0  THEN ' END)' ELSE NULL END)
                              || ' ,TAB.ROW_VERSION = TAB.ROW_VERSION + 1';
    ELSE
        V_UPDATE_SET_STATEMENT := ' SET TAB.' || V_FIELD_COLUMN_NAME || ' = '
                                  || CASE WHEN V_FLD_DATA_TYPE IN (1, 4)
                                          THEN ' ''' || PI_NEW_SUM || ''' '
                                          ELSE PI_NEW_SUM
                                     END
                                  || ' ,TAB.ROW_VERSION = TAB.ROW_VERSION + 1';
    END IF;

    -- CREATE THE FULL UPDATE STATEMENT
    POUT_SQL_TD := 'UPDATE ' || V_TABLE_NAME || ' TAB ' ||
                   V_UPDATE_SET_STATEMENT || CASE
                     WHEN V_PARENT_FILTER IS NULL THEN
                      CASE
                        WHEN PI_FROM_CLAUSE IS NULL AND V_TU_COLS IS NULL THEN
                         ''
                        ELSE
                         ' WHERE ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER FROM ' ||
                         V_UPDATE_SELECT || ' TAB)'
                      END
                     ELSE
                      V_PARENT_FILTER || CASE
                        WHEN PI_FROM_CLAUSE IS NULL AND V_TU_COLS IS NULL THEN
                         ''
                        ELSE
                         ' AND ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER FROM ' ||
                         V_UPDATE_SELECT || CASE WHEN  V_TU_COLS IS NOT NULL THEN ' TAB ' ||
                                 V_PARENT_FILTER_UPDATE  END ||')'
                      END
                   END || ' RETURNING ROW_IDENTIFIER, ROW_VERSION, '
                   || CASE WHEN V_FLD_DATA_TYPE = 6 THEN V_FIELD_COLUMN_NAME ELSE ' NULL ' END
				   || (CASE WHEN V_WEIGHT_COLUMN_NAME IS NOT NULL THEN (', ' || V_WEIGHT_COLUMN_NAME) ELSE NULL END)
                   || ' INTO :ROW_IDENTIFIER, :ROW_VERSION, :CALC_FIELD '
                   || (CASE WHEN V_WEIGHT_COLUMN_NAME IS NOT NULL THEN ', :WEIGHT_FIELD' ELSE NULL END);

    IF (PI_TD_TYPE IN (0, 1, 3)) THEN
      -- GET THE CALCULATION FIELD LENGTH IN ORDER TO ESTABLISH THE UNIT LENGTH THAT NEEDS TO BE ADDED
      SELECT FLD_LENGTH
        INTO V_FLD_LENGTH
        FROM FIELDS
       WHERE FLD_COLUMN_NAME = V_FIELD_COLUMN_NAME;

      -- CREATE THE DIFFERENCE SQL
      POUT_TD_DIFFERENCE_SQL := 'UPDATE ' || V_TABLE_NAME || ' TAB ' || 'SET ' ||
                                V_FIELD_COLUMN_NAME || ' = ' ||
                                V_FIELD_COLUMN_NAME ||
                                ' OPERATOR_PLACE_HOLDER POWER(10, -' ||
                                TO_CHAR(V_FLD_LENGTH) || ')' || CASE
                                  WHEN V_PARENT_FILTER IS NULL THEN
                                   ' WHERE '
                                  ELSE
                                   V_PARENT_FILTER || ' AND '
                                END ||
                                'ROWNUM <= ROWNUM_DIFFERENCE_PLACE_HOLDER * POWER(10, ' ||
                                TO_CHAR(V_FLD_LENGTH) || ')
                             AND TAB.' ||
                                V_FIELD_COLUMN_NAME ||
                                ' > 0 CHECK_ZERO_PLACEHOLDER ' || CASE
                                  WHEN PI_FROM_CLAUSE IS NULL AND V_TU_COLS IS NULL THEN
                                   ''
                                  ELSE
                                   ' AND ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER FROM ' ||
                                   V_UPDATE_SELECT || CASE WHEN  V_TU_COLS IS NOT NULL THEN ' TAB ' ||
                                 V_PARENT_FILTER_UPDATE END || ')'
                                END;

    END IF;
    -- GET THE QUERY NEEDED FOR THE OUTPUT CALCULATIONS
    TABLE_CALCULATIONS.GET_CALCULATE_SQL(PIN_TBL_ID       => V_TABLE_ID,
                                         PIN_INPUT_FLD_ID => TABLETYPE_NUMBER(PI_FIELD_ID),
                                         PIN_HAS_ROW_IDS  => 1,
                                         PIN_UPDATE_MODE  => 0,

                                         POUT_UPDATE_SQL => POUT_SQL_CALC);

    -- log output parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(pout_sql_td),
                               ',POUT_SQL_TD => <VALUE>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(pout_td_difference_sql),
                               ',POUT_TD_DIFFERENCE_SQL => <VALUE>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(pout_sql_calc),
                               ',POUT_SQL_CALC => <VALUE>',
                               v_stamp);
    END;

  END GET_SQLS_FOR_TD_QUERIES;

  PROCEDURE GET_SQLS_FOR_ZERO_SUM(PI_VIEW_ID              NUMBER,
                                  PI_FROM_CLAUSE          CLOB,
                                  PI_FIELD_ID             NUMBER,
                                  PI_COL_PATH             TABLETYPE_MDL_DIM_PATH_EXP,
                                  PI_SIBLINGS_ROW_INFO    TABLETYPE_PIVOT_ROW_INFO,
                                  PI_TD_TYPE              NUMBER,
                                  PI_TD_DISTRIBUTION_TYPE NUMBER,
                                  PI_SL_DISTRIBUTION_TYPE NUMBER,
								  PI_PROPORTION_FLD_ID    NUMBER, -- for both TD and SL adjustment

                                  POUT_QUERIES            OUT TABLETYPE_ADJUSTMENT_QUERIES
  ) AS
    V_ROW_EXPANDED_TU_DIM_LIST TABLETYPE_MDL_DIM_PATH_EXP;
    V_COL_EXPANDED_DIM_LIST    TABLETYPE_MDL_DIM_PATH_EXP;

    V_TABLE_ID             NUMBER;
    V_FLD_LENGTH           NUMBER;
    V_VIEW_DEF             CLOB;
    V_TABLE_NAME           VARCHAR2(30);
    V_FIELD_COLUMN_NAME    VARCHAR2(30);
	V_PROPORTION_COLUMN_NAME VARCHAR2(30);
    V_SIBLINGS_OLD_SUM     NUMBER;
	V_PROPORTION_FLD_SUM   NUMBER;
    V_SIBLINGS_ROW_COUNT   NUMBER;
    V_SIBLINGS_ROW_VERSION_SUM NUMBER;
    V_ADJUSTED_OLD_SUM     NUMBER;
    V_ADJUSTED_NEW_SUM     NUMBER;
    V_ADJUSTED_DIFF        NUMBER;
    V_ADJUSTED_ROW_PATH    TABLETYPE_MDL_DIM_PATH_EXP;

    V_PARENT_FILTER        CLOB;
    V_PARENT_FILTER_UPDATE CLOB;
    V_COL_FILTER           CLOB;
    V_COL_FILTER_UPDATE    CLOB;
    V_ROW_FILTER           CLOB;
    V_ROW_FILTER_UPDATE    CLOB;
    V_INNER_ROW_FILTER_UPDATE CLOB;
    V_INNER_ROW_FILTER     CLOB;

    V_UPDATE_SELECT        CLOB;
    V_UPDATE_SET_STATEMENT CLOB;

    V_POUT_SQL_TD          CLOB;
    V_POUT_TD_DIFFERENCE_SQL CLOB;
    V_POUT_SQL_CALC        CLOB;

    V_STAMP VARCHAR2(200 CHAR);

    V_TU_JOIN               CLOB;
    V_TU_COLS               CLOB;
    V_REBUILT_FROM_CLAUSE   CLOB;

  BEGIN
    V_STAMP := 'TABLE_CALCULATIONS.GET_SQLS_FOR_ZERO_SUM - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    -- LOG AND VALIDATE INPUT PARAMETERS

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_VIEW_ID),
                               ',pi_view_id => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PI_FROM_CLAUSE),
                               ',pi_from_clause => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_FIELD_ID),
                               ',pi_field_id => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(PI_COL_PATH),
                               ',pi_col_path => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(PI_SIBLINGS_ROW_INFO),
                               ',pi_siblings_row_path => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_TD_TYPE),
                               ',pi_td_type => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_TD_DISTRIBUTION_TYPE),
                               ',pi_td_distribution_type => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_SL_DISTRIBUTION_TYPE),
                               ',pi_sl_distribution_type => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PI_PROPORTION_FLD_ID),
                               ',pi_proportion_fld_id => <value>',
                               V_STAMP);
    END;
    V_COL_EXPANDED_DIM_LIST := PI_COL_PATH;

    POUT_QUERIES := TABLETYPE_ADJUSTMENT_QUERIES();

    -- GET THE FIELD's physical name
    SELECT FLD_COLUMN_NAME
    INTO V_FIELD_COLUMN_NAME
    FROM FIELDS
    WHERE FLD_ID = pi_field_id;

	IF (PI_PROPORTION_FLD_ID IS NOT NULL)
    THEN
        SELECT FLD_COLUMN_NAME
        INTO V_PROPORTION_COLUMN_NAME
        FROM FIELDS
        WHERE FLD_ID = PI_PROPORTION_FLD_ID;
    END IF;

    -- get info using the view id
    SELECT OD_DEFINITION, TABLES_ID, TABLES_PHYSICAL_NAME
    INTO V_VIEW_DEF, V_TABLE_ID, V_TABLE_NAME
    FROM OBJECT_DEFINITIONS
    INNER JOIN TABLE_REFERENCES ON TREF_ID = EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/tableReferenceId')
    INNER JOIN TABLES ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
    WHERE OD_CONTAINER_ID = PI_VIEW_ID;

    -- get TD queries for adjusted record
    -- todo: If no valid adjustment was done, return empty sql...?; throw error if more than one adjustment was done
	V_ADJUSTED_DIFF := 0;
    FOR C IN (SELECT ROW_PATH,
                     OLD_SUM,
                     NEW_SUM,
					 PROPORTION_FLD_SUM,
					 IS_ADJUSTED,
                     ROW_COUNT,
                     ROW_VERSION_SUM
              FROM TABLE(PI_SIBLINGS_ROW_INFO)
              WHERE IS_ADJUSTED = 1)
    LOOP
        V_ADJUSTED_OLD_SUM := NVL(C.OLD_SUM, 0);
        V_ADJUSTED_NEW_SUM := NVL(C.NEW_SUM, 0);
        V_ADJUSTED_DIFF := NVL(C.OLD_SUM,0) - NVL(C.NEW_SUM, 0);
        V_ADJUSTED_ROW_PATH := C.ROW_PATH;
		V_POUT_SQL_CALC := NULL;

        GET_SQLS_FOR_TD_QUERIES(PI_VIEW_ID => PI_VIEW_ID,
                                PI_FROM_CLAUSE => PI_FROM_CLAUSE,
                                PI_FIELD_ID => PI_FIELD_ID,
                                PI_WEIGHT_FIELD_ID => NULL,
                                PI_ROW_PATH => C.ROW_PATH,
                                PI_COL_PATH => PI_COL_PATH,
                                PI_OLD_SUM => C.OLD_SUM,
                                PI_NEW_SUM => TO_CHAR(C.NEW_SUM),
                                PI_TD_TYPE => PI_TD_TYPE,
                                PI_TD_DISTRIBUTION_TYPE => PI_TD_DISTRIBUTION_TYPE,
								PI_PROPORTION_FLD_ID => PI_PROPORTION_FLD_ID,
                                PI_PROPORTION_FLD_VALUE => C.PROPORTION_FLD_SUM,
                                POUT_SQL_TD => V_POUT_SQL_TD,
                                POUT_TD_DIFFERENCE_SQL => V_POUT_TD_DIFFERENCE_SQL,
                                POUT_SQL_CALC => V_POUT_SQL_CALC);

        POUT_QUERIES.EXTEND;
        POUT_QUERIES(POUT_QUERIES.LAST) := OBJTYPE_ADJUSTMENT_QUERIES( V_POUT_SQL_TD,
                                                                       V_POUT_TD_DIFFERENCE_SQL,
                                                                       V_POUT_SQL_CALC,
                                                                       NULL,
                                                                       C.NEW_SUM,
                                                                       C.ROW_COUNT,
                                                                       C.ROW_VERSION_SUM);
    END LOOP;

    -- create query to adjust the siblings

    -- create the where condition for the columns
    FOR C IN (SELECT DIM_ID,
                     DIM_TYPE,
                     DIM_NAME,
                     DIM_DATA_TYPE,
                     DIM_ORDER,
                     DIM_VALUE,
                     DIM_BASE_ID
              FROM TABLE(V_COL_EXPANDED_DIM_LIST)
              ORDER BY DIM_ORDER)
    LOOP
        IF (C.DIM_VALUE IS NOT NULL)
        THEN
            V_COL_FILTER_UPDATE := V_COL_FILTER_UPDATE
                                   || CASE WHEN V_COL_FILTER_UPDATE IS NOT NULL
                                           THEN CHR(10) || 'AND '
                                           ELSE NULL
                                      END
                                   || 'ALL_COMB.' || c.DIM_NAME || ' = '
                                   || PLANNING_MODELS.FORMAT_CONSTANT_VALUE( PI_DIM_TYPE      => C.DIM_TYPE,
                                                                             PI_DIM_DATA_TYPE => C.DIM_DATA_TYPE,
                                                                             PI_DIM_VALUE     => C.DIM_VALUE);
            IF (NVL(C.DIM_BASE_ID, C.DIM_ID) = C.DIM_ID)
            THEN
                V_COL_FILTER := V_COL_FILTER
                                || CASE WHEN V_COL_FILTER IS NOT NULL
                                        THEN CHR(10) || 'AND '
                                        ELSE NULL
                                   END
                                || 'ALL_COMB.' || c.DIM_NAME || ' = '
                                || PLANNING_MODELS.FORMAT_CONSTANT_VALUE( PI_DIM_TYPE      => C.DIM_TYPE,
                                                                          PI_DIM_DATA_TYPE => C.DIM_DATA_TYPE,
                                                                          PI_DIM_VALUE     => C.DIM_VALUE);
            END IF;
        END IF;
    END LOOP;

    -- create the where condition for the rows
    FOR C IN (SELECT ROW_PATH,
                     OLD_SUM,
                     NEW_SUM,
					 PROPORTION_FLD_SUM,
					 IS_ADJUSTED,
                     ROW_COUNT,
                     ROW_VERSION_SUM
              FROM TABLE(PI_SIBLINGS_ROW_INFO)
              WHERE IS_ADJUSTED = 0)
    LOOP
        V_SIBLINGS_OLD_SUM := NVL(V_SIBLINGS_OLD_SUM, 0) + NVL(C.OLD_SUM, 0);
		V_PROPORTION_FLD_SUM := NVL(V_PROPORTION_FLD_SUM, 0) + NVL(C.PROPORTION_FLD_SUM, 0);
        V_SIBLINGS_ROW_COUNT := NVL(V_SIBLINGS_ROW_COUNT, 0) + NVL(C.ROW_COUNT, 0);
        V_SIBLINGS_ROW_VERSION_SUM := NVL(V_SIBLINGS_ROW_VERSION_SUM, 0) + NVL(C.ROW_VERSION_SUM, 0);

        V_INNER_ROW_FILTER_UPDATE := NULL;
        V_INNER_ROW_FILTER := NULL;

        IF (V_ROW_EXPANDED_TU_DIM_LIST IS NULL)
        THEN
            V_ROW_EXPANDED_TU_DIM_LIST := C.ROW_PATH;
        END IF;

        FOR C2 IN (SELECT DIM_ID,
                          DIM_TYPE,
                          DIM_NAME,
                          DIM_DATA_TYPE,
                          DIM_ORDER,
                          DIM_DISPLAY_FLD_ID,
                          DIM_DISPLAY_ENTITY_BK,
                          DIM_VALUE,
                          DIM_BASE_ID
                   FROM TABLE(C.ROW_PATH)
                   WHERE DIM_VALUE IS NOT NULL
                   ORDER BY DIM_ORDER)
        LOOP
            IF (C2.DIM_VALUE IS NOT NULL)
            THEN
                V_INNER_ROW_FILTER_UPDATE := V_INNER_ROW_FILTER_UPDATE
                                             || CASE WHEN V_INNER_ROW_FILTER_UPDATE IS NOT NULL
                                                     THEN ' AND '
                                                     ELSE NULL
                                                END
                                             || 'ALL_COMB.' || C2.DIM_NAME || ' = '
                                             || PLANNING_MODELS.FORMAT_CONSTANT_VALUE( PI_DIM_TYPE      => C2.DIM_TYPE,
                                                                                       PI_DIM_DATA_TYPE => C2.DIM_DATA_TYPE,
                                                                                       PI_DIM_VALUE     => C2.DIM_VALUE);

                IF (NVL(C2.DIM_BASE_ID, C2.DIM_ID) = C2.DIM_ID)
                THEN
                    V_INNER_ROW_FILTER := V_INNER_ROW_FILTER
                                          || CASE WHEN V_INNER_ROW_FILTER IS NOT NULL
                                                  THEN CHR(10) || 'AND '
                                                  ELSE NULL
                                             END
                                          || 'ALL_COMB.' || C2.DIM_NAME || ' = '
                                          || PLANNING_MODELS.FORMAT_CONSTANT_VALUE( PI_DIM_TYPE      => C2.DIM_TYPE,
                                                                                    PI_DIM_DATA_TYPE => C2.DIM_DATA_TYPE,
                                                                                    PI_DIM_VALUE     => C2.DIM_VALUE);
                END IF;
            END IF;
        END LOOP;

        V_ROW_FILTER_UPDATE := V_ROW_FILTER_UPDATE
                               || CASE WHEN V_ROW_FILTER_UPDATE IS NOT NULL AND V_INNER_ROW_FILTER_UPDATE IS NOT NULL
                                       THEN CHR(10) || ' OR '
                                       ELSE NULL
                                  END
                               || CASE WHEN V_INNER_ROW_FILTER_UPDATE IS NOT NULL
                                       THEN '(' || V_INNER_ROW_FILTER_UPDATE || ')'
                                       ELSE NULL
                                  END;

        V_ROW_FILTER := V_ROW_FILTER
                        || CASE WHEN V_ROW_FILTER IS NOT NULL AND V_INNER_ROW_FILTER IS NOT NULL
                                THEN CHR(10) || ' OR '
                                ELSE NULL
                           END
                        || CASE WHEN V_INNER_ROW_FILTER IS NOT NULL
                                THEN '(' || V_INNER_ROW_FILTER || ')'
                                ELSE NULL
                           END;
    END LOOP;

    V_PARENT_FILTER := V_COL_FILTER
                       || CASE WHEN V_COL_FILTER IS NOT NULL AND V_ROW_FILTER IS NOT NULL
                               THEN ' AND '
                               ELSE NULL
                          END
                       || CASE WHEN V_ROW_FILTER IS NOT NULL
                               THEN '(' || V_ROW_FILTER || ')'
                               ELSE NULL
                          END;

    V_PARENT_FILTER_UPDATE := V_COL_FILTER_UPDATE
                              || CASE WHEN V_COL_FILTER_UPDATE IS NOT NULL AND V_ROW_FILTER_UPDATE IS NOT NULL
                                      THEN ' AND '
                                      ELSE NULL
                                 END
                              || CASE WHEN V_ROW_FILTER_UPDATE IS NOT NULL
                                      THEN '(' || V_ROW_FILTER_UPDATE || ')'
                                      ELSE NULL
                                  END;

    -- remove the first condition from where
    IF V_PARENT_FILTER IS NOT NULL
    THEN
        V_PARENT_FILTER := ' WHERE '
                           || REPLACE(REPLACE(V_PARENT_FILTER,
                                              'ALL_COMB.',
                                              'TAB.'),
                                      'COMB.',
                                      'TAB.');
    END IF;

    IF V_PARENT_FILTER_UPDATE IS NOT NULL
    THEN
        V_PARENT_FILTER_UPDATE := ' WHERE '
                                  || REPLACE(REPLACE(V_PARENT_FILTER_UPDATE,
                                                     'ALL_COMB.',
                                                     'TAB.'),
                                             'COMB.',
                                             'TAB.');
    END IF;

    -- get time unit joins
    PLANNING_MODELS.GET_TIME_UNIT_STRUCTURE( PI_EXPANDED_DIM_LIST => V_ROW_EXPANDED_TU_DIM_LIST,
                                             PO_TU_SELECT         => V_TU_JOIN,
                                             PO_TU_COLUMNS        => V_TU_COLS
                                           );
    IF V_TU_COLS IS NULL
    THEN
        PLANNING_MODELS.GET_TIME_UNIT_STRUCTURE( PI_EXPANDED_DIM_LIST => V_COL_EXPANDED_DIM_LIST,
                                                 PO_TU_SELECT         => V_TU_JOIN,
                                                 PO_TU_COLUMNS        => V_TU_COLS
                                               );
    END IF;

    PLANNING_MODELS.GET_REBUILT_FROM_CLAUSE(PI_TU_SELECT         => V_TU_JOIN,
                                            PI_TU_COLUMNS        => V_TU_COLS,
                                            PI_ORIG_FROM_CLAUSE  => PI_FROM_CLAUSE,
                                            PI_TABLE_NAME        => V_TABLE_NAME,
                                            PI_DIM_TYPE          => 8,
                                            PO_FROM_CLAUSE       => V_REBUILT_FROM_CLAUSE);

    -- prepare the select to be updated
    V_UPDATE_SELECT := '(SELECT *
                         FROM ' || V_REBUILT_FROM_CLAUSE ||')';

    -- PREPARE THE SET STATEMENT
    V_UPDATE_SET_STATEMENT := ' SET TAB.' || V_FIELD_COLUMN_NAME || ' = '
                              || ' CAST('
                              || CASE WHEN ((PI_SL_DISTRIBUTION_TYPE = 2 AND PI_TD_TYPE = 0)
                                            OR
                                            ((PI_PROPORTION_FLD_ID IS NOT NULL AND NVL(V_PROPORTION_FLD_SUM, 0) = 0)
                                             OR
                                             (PI_PROPORTION_FLD_ID IS NULL AND NVL(V_SIBLINGS_OLD_SUM, 0) = 0)
                                            )) -- zero sum; spread equally
                                           THEN
                                               (V_SIBLINGS_OLD_SUM + V_ADJUSTED_DIFF)
                                               || ' / '
                                               || V_SIBLINGS_ROW_COUNT || ' '
                                      WHEN (PI_SL_DISTRIBUTION_TYPE = 1 AND PI_TD_TYPE = 0 AND NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME) != V_FIELD_COLUMN_NAME) -- zero sum; spread proportionally by different column
                                           THEN
                                               'COALESCE(' || V_FIELD_COLUMN_NAME || ', 0) + '
                                                || V_ADJUSTED_DIFF
                                                || ' * '
                                                || NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME)
                                                || ' / '
                                                || ' (SELECT SUM(' || V_PROPORTION_COLUMN_NAME || ') FROM (' || V_UPDATE_SELECT || ') TAB ' || V_PARENT_FILTER_UPDATE || ')'
                                      WHEN (PI_SL_DISTRIBUTION_TYPE = 1 AND PI_TD_TYPE = 0) -- zero sum; spread proportionally by the same column
                                           THEN
                                               'COALESCE(' || V_FIELD_COLUMN_NAME || ', 0) + '
                                                || V_ADJUSTED_DIFF
                                                || ' * '
                                                || NVL(V_PROPORTION_COLUMN_NAME, V_FIELD_COLUMN_NAME)
                                                || ' / '
                                                || TO_CHAR(NVL(V_PROPORTION_FLD_SUM, V_SIBLINGS_OLD_SUM))
                                      ELSE
                                          V_FIELD_COLUMN_NAME
                                 END
                              || ' AS NUMBER'
                              || COMMONS.FIELD_PRECISION_AND_SCALE(V_FIELD_COLUMN_NAME) || ')'
                              || ' ,TAB.ROW_VERSION = TAB.ROW_VERSION + 1';

    -- CREATE THE FULL UPDATE STATEMENT
    V_POUT_SQL_TD := 'UPDATE ' || V_TABLE_NAME || ' TAB ' ||
                     V_UPDATE_SET_STATEMENT
                     || CASE WHEN V_PARENT_FILTER IS NULL
                             THEN CASE WHEN PI_FROM_CLAUSE IS NULL AND V_TU_COLS IS NULL
                                       THEN ''
                                       ELSE
                                            ' WHERE ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER FROM ' || V_UPDATE_SELECT || ' TAB)'
                                  END
                             ELSE V_PARENT_FILTER
                                  || CASE WHEN PI_FROM_CLAUSE IS NULL AND V_TU_COLS IS NULL
                                          THEN ''
                                          ELSE
                                               ' AND ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER FROM '
                                               || V_UPDATE_SELECT
                                               || CASE WHEN V_TU_COLS IS NOT NULL
                                                       THEN ' TAB ' || V_PARENT_FILTER_UPDATE
                                                  END
                                               ||')'
                                     END
                        END
                     || ' RETURNING ROW_IDENTIFIER, ROW_VERSION, ' || V_FIELD_COLUMN_NAME
                     || ' INTO :ROW_IDENTIFIER, :ROW_VERSION, :CALC_FIELD ';

    -- GET THE CALCULATION FIELD LENGTH IN ORDER TO ESTABLISH THE UNIT LENGTH THAT NEEDS TO BE ADDED
    SELECT FLD_LENGTH
    INTO V_FLD_LENGTH
    FROM FIELDS
    WHERE FLD_COLUMN_NAME = V_FIELD_COLUMN_NAME;

    -- CREATE THE DIFFERENCE SQL
    V_POUT_TD_DIFFERENCE_SQL := 'UPDATE ' || V_TABLE_NAME || ' TAB '
                                || 'SET '
                                || V_FIELD_COLUMN_NAME || ' = ' || V_FIELD_COLUMN_NAME
                                || ' OPERATOR_PLACE_HOLDER POWER(10, -' || TO_CHAR(V_FLD_LENGTH) || ')'
                                || CASE WHEN V_PARENT_FILTER IS NULL
                                        THEN ' WHERE '
                                        ELSE V_PARENT_FILTER || ' AND '
                                   END
                                || 'ROWNUM <= ROWNUM_DIFFERENCE_PLACE_HOLDER * POWER(10, ' || TO_CHAR(V_FLD_LENGTH) || ')
                                    AND TAB.' || V_FIELD_COLUMN_NAME || ' > 0 CHECK_ZERO_PLACEHOLDER '
                                || CASE WHEN PI_FROM_CLAUSE IS NULL AND V_TU_COLS IS NULL
                                        THEN ''
                                        ELSE ' AND ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER FROM '
                                             || V_UPDATE_SELECT
                                             || CASE WHEN  V_TU_COLS IS NOT NULL
                                                     THEN ' TAB ' || V_PARENT_FILTER_UPDATE
                                                END
                                             || ')'
                                   END;

    -- GET THE QUERY NEEDED FOR THE OUTPUT CALCULATIONS
	V_POUT_SQL_CALC := NULL;
    TABLE_CALCULATIONS.GET_CALCULATE_SQL(PIN_TBL_ID       => V_TABLE_ID,
                                         PIN_INPUT_FLD_ID => TABLETYPE_NUMBER(PI_FIELD_ID),
                                         PIN_HAS_ROW_IDS  => 1,
                                         PIN_UPDATE_MODE  => 0,

                                         POUT_UPDATE_SQL => V_POUT_SQL_CALC);

    POUT_QUERIES.EXTEND;
    POUT_QUERIES(POUT_QUERIES.LAST) := OBJTYPE_ADJUSTMENT_QUERIES( V_POUT_SQL_TD,
                                                                   V_POUT_TD_DIFFERENCE_SQL,
                                                                   V_POUT_SQL_CALC,
                                                                   NULL,
                                                                   (V_SIBLINGS_OLD_SUM + V_ADJUSTED_DIFF),
                                                                   V_SIBLINGS_ROW_COUNT,
                                                                   V_SIBLINGS_ROW_VERSION_SUM);
    -- log output parameters
    FOR C IN (SELECT SQL_TD,
                     TD_DIFFERENCE_SQL,
                     SQL_CALC,
                     NEW_SUM_SQL,
                     NEW_SUM,
                     ROW_COUNT,
                     ROW_VERSION_SUM
              FROM TABLE(POUT_QUERIES))
    LOOP
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(C.SQL_TD),
                               ',POUT_SQL_TD => <value>',
                               V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(C.TD_DIFFERENCE_SQL),
                               ',POUT_TD_DIFFERENCE_SQL => <value>',
                               V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(C.SQL_CALC),
                               ',POUT_SQL_CALC => <value>',
                               V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(C.NEW_SUM),
                               ',NEW_SUM => <value>',
                               V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(C.ROW_COUNT),
                               ',ROW_COUNT => <value>',
                               V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(C.ROW_VERSION_SUM),
                               ',ROW_VERSION_SUM => <value>',
                               V_STAMP);
    END LOOP;

  END GET_SQLS_FOR_ZERO_SUM;

END TABLE_CALCULATIONS;
/
