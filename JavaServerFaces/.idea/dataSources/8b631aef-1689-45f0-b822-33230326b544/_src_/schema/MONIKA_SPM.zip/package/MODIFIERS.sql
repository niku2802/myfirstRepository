CREATE package MODIFIERS as
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type   : SPM
  -- Product        : compensation
  -- Module          : compensation-processing
  -- Requester      : Homeuca, Victor
  -- Author          : Popescu, Mircea
  -- Create date  : 20110916
  -- Reviewer        :
  -- Review date   :
  -- Description   : package used to handle all operations for modifiers
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  type NT_STRING_TABLE is table of varchar2(100);
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  STEP_LOOKUP            constant pls_integer := 1;
  CONTINUOUS_LOOKUP      constant pls_integer := 2;
  DISCRETE_LOOKUP        constant pls_integer := 3;
  METRICS_MODULE         constant varchar2(50) := 'METRICS';
  COMPONENTS_MODULE      constant varchar2(50) := 'COMPONENTS';
  UNMODIFIED_VALUE_ALIAS constant varchar2(50) := 'F01';
  METRIC                 constant varchar2(50) := 'METRIC';
  MODIFIED_EARNINGS      constant varchar2(50) := 'MODIFIED_EARNINGS';
  UNMODIFIED_EARNINGS    constant varchar2(50) := 'UNMODIFIED_EARNINGS';
  UNMODIFIED_METRIC      constant varchar2(50) := 'UNMODIFIED_METRIC';
  MODIFIER_INPUT_VALUE   constant varchar2(50) := 'MODIFIER_INPUT_VALUE';
  MODIFIER_METRIC_VALUE  constant varchar2(50) := 'MODIFIER_METRIC_VALUE';

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************

  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  --

  -- Used to transform Input fields to MCE fields
  -- Used for  Modifier Input / Modifier Lookup Input
  -- This PS will return a join between the Input Table and any needed entities in order to handle Metrics Duality
  -- The only situation when the Modifier/Lookup Input must be joined with an Entity Table is when we have Entity in Modifier/Lookup Input and BusinessKey in MCE
  -- For the ogher scenarios we do not need to transform v_parameter_Table since TEMP_METRIC_VALUES contains EntityID and BK also
  procedure PROCESS_INPUT(pin_input           in  varchar2
                         ,pin_input_alias     in  varchar2
                         ,pin_input_fields    in  varchar2
                         ,pin_MCE_fields      in  varchar2
                         ,pin_aditional_fields in  varchar2
                         ,pout_new_input      out varchar2);

  -- Used to transform Modifier Input fields to Lookup Fields
  -- For Metrics, the MCE might have Entity and the Lookup Input the BK duality or viceversa
  -- The SP below transforms the Lookup input in order to be able to acces the fields exactly as they are selected on the MCE
  -- this way the pin_LookupJoinClause and roster_join_clause will have the same fields in TAB./R. and LOOKUP. tables
  -- Returns a list of columns to be selected
  procedure PROCESS_INPUT_LOOKUP(pin_input           in  varchar2
                                ,pin_input_alias     in  varchar2
                                ,pin_input_fields    in  varchar2
                                ,pin_MCE_fields      in  varchar2
                                ,pin_aditional_fields in  varchar2
                                ,pout_select_list    out varchar2
                                ,pout_new_input      out varchar2);

  --
  function MODIFIER_FLOOR_CAP_OVERRIDE(PIN_CLAUSES             in TABLETYPE_MODIFIER_CLAUSES,
                                       PIN_MODIFIERTYPE        in number,
                                       PIN_VALUE               in number,
                                       PIN_PARAMETERTABLE      in varchar2,
                                       PIN_PARAMETERTABLEALIAS in varchar2,
                                       PIN_PARAMETERCOL        in varchar2,
                                       PIN_INPUTJOINMAP        in TABLETYPE_NAME_JOIN_MAP,
                                       PIN_ROSTERCOLS          in TABLETYPE_NAME_JOIN_MAP,
                                       PIN_PARAMPERIODFILTER   in clob,
                                       PIN_METRICCOMPONENT_ID  in number default null,
                                       pin_effective_date_cols IN OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                       ,pin_lookup_precision   IN VARCHAR2 DEFAULT NULL
                                       )
    return TABLETYPE_MODIFIER_CLAUSES;

  /* FUNCTION MODIFIER_FLOOR_CAP_OLD(pin_clauses              IN       TABLETYPE_MODIFIER_CLAUSES
                             ,pin_modifierType         IN       NUMBER
                             ,pin_value                IN       NUMBER
                             ,pin_parameterTable       IN       VARCHAR2
                             ,pin_parameterCol         IN       VARCHAR2
                             ,pin_inputJoinMap         IN       tabletype_name_join_map
                             ,pin_rosterCols           IN       tabletype_name_join_map
                             ,pin_paramPeriodFilter    IN       clob
                             ,pin_MetricComponent_id    IN       NUMBER default null)
  RETURN TABLETYPE_MODIFIER_CLAUSES;   */
  -----------------------------------------------------------------------------------------------
  -- Assumptions:
  -- Input Parameters are built using valid table names and column names
  -- Process: Execute operation indicated by pin_modifierType param and append specific clauses to the OBJTYPE_MODIFIER_CLAUSES object
  -- Input Parameters:
  --    pin_clauses                the array that contains the clauses from the previous modifiers and
  --    pin_modifierType           can have two values: 1 - FLOOR, 2 - CAP
  --    pin_value                  the constant parameter value from UI
  --    pin_parameterTable         the parameter table
  --    pin_parameterCol           the column from the parameter table that is used in calculation of the modifier
  --    pin_inputJoinMap           the join map between the input and the parameter table
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY',NULL,NULL,NULL))
  --                               F10 - the col from parameter table that is used in join condition,
  --                               ML_EARNINGS_ENTITY - the col from input used in join condition
  --    pin_rosterCols             the join map between the roster table and the parameter table
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50','Roster',NULL,NULL,NULL))
  --                               F20 and F50 - the cols from parameter table and Roster that are used in join condition, Roster - roster table
  --    pin_paramPeriodFilter      the period filter condition when the parameter table is time managed
  -----------------------------------------------------------------------------------------------
  --    Call statement:
  /*    DECLARE
     MODIFIER_CLAUSES  TABLETYPE_MODIFIER_CLAUSES;
  BEGIN
     MODIFIER_CLAUSES := METRICS_PROCESSING.MODIFIER_FLOOR_CAP(pin_clauses =>  TABLETYPE_MODIFIER_CLAUSES(
                                                                                OBJTYPE_MODIFIER_CLAUSES(SELECT_CLAUSE => 'ML_FINAL_VALUE',
                                                                                                         FROM_CLAUSE => 'TEMP_METRIC_LOOKUPS',
                                                                                                         WHERE_CLAUSE => '1=1',
                                                                                                         WHEN_CLAUSE => NULL
                                                                                                         MODULE => 'METRICS'))
                                                              ,pin_modifierType => 1
                                                              ,pin_value => NULL
                                                              ,pin_parameterTable => 'T500'
                                                              ,pin_parameterCol => 'F12'
                                                              ,pin_inputJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY',NULL,NULL,NULL))
                                                              ,pin_rosterJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50','ROSTER',NULL,NULL,NULL))
                                                              ,pin_paramPeriodFilter => NULL
                                                              );
  END;*/
  -----------------------------------------------------------------------------------------------
  -----------------

  function MODIFIER_HURDLE_QUALIFIER(PIN_CLAUSES                   in TABLETYPE_MODIFIER_CLAUSES,
                                     PIN_MODIFIERTYPE              in number,
                                     PIN_INPUTTABLE                in varchar2,
                                     PIN_INPUTCOL                  in varchar2,
                                     PIN_LEFTPARAMETERVALUE        in number,
                                     PIN_LEFTPARAMETERTABLE        in varchar2,
                                     PIN_LEFTPARAMETERTABLEALIAS   in varchar2,
                                     PIN_LEFTPARAMETERCOL          in varchar2,
                                     PIN_LEFTPARAMETERPERIODFILTER in clob,
                                     PIN_PARAMETERVALUE            in number,
                                     PIN_PARAMETERTABLE            in varchar2,
                                     PIN_PARAMETERTABLEALIAS       in varchar2,
                                     PIN_PARAMETERCOL              in varchar2,
                                     PIN_PARAMETERPERIODFILTER     in clob,
                                     PIN_INPUTJOINMAP              in TABLETYPE_NAME_JOIN_MAP,
                                     PIN_ROSTERJOINMAP             in TABLETYPE_NAME_JOIN_MAP,
                                     PIN_INPUTTABLEFILTER          in varchar2,
                                     PIN_INPUTTABLENAME            in varchar2,
                                     PIN_SCN                       in number,
                                     PIN_METRICCOMPONENT_ID        in number default NULL
                                     ,pin_effective_date_cols_lhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                     ,pin_effective_date_cols_rhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                     ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                                     ,pin_metricInputTable           in       varchar2           default null
                                     ,pin_metricInputSequence        in       varchar2           default null
                                     ,pin_thresholdInputFields       in       tabletype_name_map default null
                                     ,pin_thresholdFilterFields      in       tabletype_name_map default null
                                     ,pin_thresholdConstants         in       tabletype_name_map default null
                                    )
    return TABLETYPE_MODIFIER_CLAUSES;
  -----------------------------------------------------------------------------------------------
  -- Assumptions:
  -- Input Parameters are built using valid table names and column names
  -- Process: Execute operation indicated by pin_modifierType param and append specific clauses to the OBJTYPE_MODIFIER_CLAUSES object
  -- Input Parameters:
  --    pin_clauses                      the array that contains the clauses from the previous modifiers and
  --    pin_modifierType                 can have two values: 1 - HURDLE, 2 - QUALIFIER
  --    pin_inputTable                   the input table name
  --    pin_inputCol                     the column name from the input table used to compare with threshold value
  --    pin_leftParameterValue           constant hurdle/qualifier value entered in UI
  --    pin_leftParameterTable           hurdle/qualifier table name
  --    pin_leftParameterCol             column name from hurdle/qualifier table used to compare with input column
  --    pin_leftParameterPeriodFilter    period filter on hurdle/qualifier table
  --    pin_parameterValue               the constant modifier value from UI
  --    pin_parameterTable               the parameter table name
  --    pin_parameterCol                 the column from the parameter table that is used in calculation of the modifier
  --    pin_parameterPeriodFilter        period filter on parameter table
  --    pin_inputJoinMap                 the join map between the process input and roster
  --                                     Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY','Roster',NULL,NULL),
  --                                                                 OBJTYPE_NAME_JOIN_MAP('Col/s from INPUT/METRIC table','Col/s from process input table',NULL,NULL,NULL))
  --                                     F10 - the column from roster table that is used in join condition,
  --                                     ML_EARNINGS_ENTITY - the column from process input used in join condition
  --    pin_rosterJoinMap                the join map between the roster table and the parameter table,roster table and hurdle/qualifier table table
  --                                     and roster table and metrics/input
  --                                     Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL),
  --                                                                 OBJTYPE_NAME_JOIN_MAP('F100,F53',NULL,NULL,NULL,NULL))
  --                                     F20 and F50 - the cols from parameter table and Roster that are used in the join condition
  --                                     F50 and f53 - the cols from hurdle/qualifier table and roster that are used in the join condition
  --    pin_inputTableFilter             filter on the input table
  -----------------------------------------------------------------------------------------------
  --    Call statement:
  /*    DECLARE
     MODIFIER_CLAUSES  TABLETYPE_MODIFIER_CLAUSES;
  BEGIN
     MODIFIER_CLAUSES := METRICS_PROCESSING.MODIFIER_FLOOR_CAP(pin_clauses =>  TABLETYPE_MODIFIER_CLAUSES(
                                                                                OBJTYPE_MODIFIER_CLAUSES(SELECT_CLAUSE => 'ML_FINAL_VALUE',
                                                                                                         FROM_CLAUSE => 'TEMP_METRIC_LOOKUPS',
                                                                                                         WHERE_CLAUSE => '1=1',
                                                                                                         WHEN_CLAUSE => NULL
                                                                                                         MODULE => 'METRICS'))
                                                              ,pin_modifierType => 1
                                                              ,pin_inputTable => 'T10'
                                                              ,pin_inputCol => 'F13'
                                                              ,pin_leftParameterValue => NULL
                                                              ,pin_leftParameterTable => 'T100'
                                                              ,pin_leftParameterCol => 'F55'
                                                              ,pin_leftParameterPeriodFilter => NULL
                                                              ,pin_parameterValue => NULL
                                                              ,pin_parameterTable => 'T200'
                                                              ,pin_parameterCol => 'F50'
                                                              ,pin_parameterPeriodFilter => NULL
                                                              ,pin_inputJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F100','ML_EARNINGS_ENTITY','ROSTER',NULL,NULL),
                                                                                                           OBJTYPE_NAME_JOIN_MAP('F150,F200','ML_EARNINGS_ENTITY,ML_METRIC_CALC_ENTITY_NAME1',NULL,NULL,NULL))
                                                              ,pin_rosterJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL),
                                                                                                            OBJTYPE_NAME_JOIN_MAP('F100,F53',NULL,NULL,NULL,NULL))
                                                              ,pin_inputTableFilter => NULL
                                                              );
  END;*/
  -----------------------------------------------------------------------------------------------
  ---------------

  function MODIFIER_ACC_DEC(PIN_CLAUSES               in TABLETYPE_MODIFIER_CLAUSES,
                            PIN_MODIFIERTYPE          in number,
                            PIN_INPUTTABLE            in varchar2,
                            PIN_INPUTCOL              in varchar2,
                            PIN_THRESHOLDVALUE        in number,
                            PIN_THRESHOLDTABLE        in varchar2,
                            PIN_THRESHOLDTABLEALIAS   in varchar2,
                            PIN_THRESHOLDCOL          in varchar2,
                            PIN_THRESHOLDPERIODFILTER in clob,
                            PIN_LOOKUPTYPE            in number,
                            PIN_LOOKUPTABLE           in varchar2,
                            PIN_LOWERVALUEOPTION      in number,
                            PIN_HIGHERVALUEOPTION     in number,
                            PIN_PARAMETERVALUE        in number,
                            PIN_PARAMETERTABLE        in varchar2,
                            PIN_PARAMETERTABLEALIAS   in varchar2,
                            PIN_PARAMETERCOL          in varchar2,
                            PIN_PARAMETERPERIODFILTER in clob,
                            PIN_INPUTJOINMAP          in TABLETYPE_NAME_JOIN_MAP,
                            PIN_ROSTERJOINMAP         in TABLETYPE_NAME_JOIN_MAP,
                            PIN_INPUTTABLEFILTER      in varchar2,
                            PIN_PARAMETERTABLEFILTER  in varchar2,
                            PIN_INPUTTABLENAME        in varchar2,
                            PIN_SCN                   in number,
                            PIN_METRICCOMPONENT_ID    in number default null,
                            pin_LookupInputJoinMap    in tabletype_name_join_map default null, -- A copy of PIN_INPUTJOINMAP that holds the
                                                                                              -- MCE fields as selected on UI and not translated in TEMP_METRIC_VALUES
                                                                                              -- NAME1: The fields as they are on the input (same as pin_InputJoinMap.Name1)
                                                                                              -- NAME2: The fields as selected in MCE
                            pin_LookupJoinClause      in varchar2 default null,-- The join clause using the Fields as they are on LOOKUP Table
                            pin_LookupVaryByFields    in varchar2 default null,-- The Fields by which the LK vary, as they are in the LOOKUP Table
                            pin_LookupInputEE         in varchar2 default null, -- The EE as selected at Plan Level
                            pin_LookupRosterFilter    in varchar2 default null, --
                            pin_LookupPeriodFilter    in clob default NULL
                             ,pin_effective_date_cols_lhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                             ,pin_effective_date_cols_rhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                             ,pin_effective_date_cols_lookup IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                             ,pin_lookup_date_field          IN       VARCHAR2 DEFAULT NULL
                             ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                             ,pin_lookup_value_precision     IN       VARCHAR2 DEFAULT NULL
                             ,pin_lookup_result_precision    IN       VARCHAR2 DEFAULT NULL
                             ,pin_metricInputTable           in       varchar2           default null
                             ,pin_metricInputSequence        in       varchar2           default null
                             ,pin_thresholdInputFields       in       tabletype_name_map default null
                             ,pin_thresholdFilterFields      in       tabletype_name_map default null
                             ,pin_thresholdConstants         in       tabletype_name_map default null
                             ,pin_lookupFilterFields         in       tabletype_name_map default null
                             ,pin_lookupInputFields          in       tabletype_name_map default null
                             ,pin_lookupConstants            in       tabletype_name_map default null
                           )
    return TABLETYPE_MODIFIER_CLAUSES;
  -----------------------------------------------------------------------------------------------
  -- Assumptions:
  -- Input Parameters are built using valid table names and column names
  -- Process: Execute operation indicated by pin_modifierType param and append specific clauses to the OBJTYPE_MODIFIER_CLAUSES object
  -- Input Parameters:
  --    pin_clauses                the array that contains the clauses from the previous modifiers and
  --    pin_modifierType           can have two values: 1 - ACCELERATOR, 2 - DECELERATOR
  --    pin_inputTable             the input table name
  --    pin_inputCol               the column name from the input table used to compare with threshold value
  --    pin_thresholdValue         constant threshold value entered in UI
  --    pin_thresholdTable         threshold table name
  --    pin_thresholdCol           column name from threshold table used to compare with input column
  --    pin_thresholdPeriodFilter  period filter on threshold table
  --    pin_lookupType             lookup type. Possible values: 1 - Step lookup, 2 - Continuous lookup, 3 - Discrete lookup
  --    pin_lookupTable            lookup table name
  --    pin_LowerValueOption       the option if the lookup field value is less than the smallest lookup value
  --                               Possible values:  1-the result value from the smallest lookup value, 5-zero, 6-an error
  --    pin_HigherValueOption      the option if the lookup field value is greater than the largest lookup value
  --                               Possible values:  3-the result value from the largest lookup value, 6-an error
  --    pin_parameterValue         the constant parameter value from UI
  --    pin_parameterTable         the parameter table name or the input/metric table name that contains the lookup field
  --    pin_parameterCol           the column from the parameter table that is used in calculation of the modifier or the lookup field in the lookup input table
  --    pin_parameterPeriodFilter  period filter on parameter table
  --    pin_inputJoinMap           the join map between the process input and roster
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY','Roster',NULL,NULL),
  --                                                           OBJTYPE_NAME_JOIN_MAP('Col/s from INPUT/METRIC table','Col/s from process input table',NULL,NULL,NULL))
  --                               F10 - the column from roster table that is used in join condition,
  --                               ML_EARNINGS_ENTITY - the column from process input used in join condition
  --    pin_rosterJoinMap          the join map between roster table and threshold table and roster table and the parameter table
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL),
  --                                                           OBJTYPE_NAME_JOIN_MAP('F100,F53',NULL,NULL,NULL,NULL))
  --                               F20 and F50 - the cols from threshold table and Roster that are used in the join condition
  --                               F50 and f53 - the cols from parameter table and roster that are used in the join condition
  --    pin_inputTableFilter       filter on the input table
  --    pin_parameterTableFilter   filter on the lookup input table (if lookup is used)
  -----------------------------------------------------------------------------------------------
  --    Call statement:
  /*    DECLARE
           MODIFIER_CLAUSES  TABLETYPE_MODIFIER_CLAUSES;
        BEGIN
           MODIFIER_CLAUSES := METRICS_PROCESSING.MODIFIER_FLOOR_CAP(pin_clauses =>  TABLETYPE_MODIFIER_CLAUSES(
                                                                                      OBJTYPE_MODIFIER_CLAUSES(SELECT_CLAUSE => 'ML_FINAL_VALUE',
                                                                                                               FROM_CLAUSE => 'TEMP_METRIC_LOOKUPS',
                                                                                                               WHERE_CLAUSE => '1=1',
                                                                                                               WHEN_CLAUSE => NULL
                                                                                                               MODULE => 'METRICS'))
                                                                    ,pin_modifierType => 1
                                                                    ,pin_inputTable => 'T10'
                                                                    ,pin_inputCol => 'F13'
                                                                    ,pin_thresholdValue => NULL
                                                                    ,pin_thresholdTable => 'T100'
                                                                    ,pin_thresholdCol => 'F55'
                                                                    ,pin_thresholdPeriodFilter => NULL
                                                                    ,pin_lookupType => 2
                                                                    ,pin_lookupTable => 'T124'
                                                                    ,pin_LowerValueOption => 1
                                                                    ,pin_HigherValueOption => 3
                                                                    ,pin_parameterValue => NULL
                                                                    ,pin_parameterTable => 'T200'
                                                                    ,pin_parameterCol => 'F50'
                                                                    ,pin_parameterPeriodFilter => NULL
                                                                    ,pin_inputJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F100','ML_EARNINGS_ENTITY','ROSTER',NULL,NULL)
                                                                    ,pin_rosterJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL),
  --                                                                                                              OBJTYPE_NAME_JOIN_MAP('F100,F53',NULL,NULL,NULL,NULL),
  --                                                                                                              OBJTYPE_NAME_JOIN_MAP('F100',NULL,NULL,NULL,NULL))
                                                                    ,pin_inputTableFilter => NULL
                                                                    ,pin_parameterTableFilter => NULL
                                                                    );
        END;*/
  -----------------------------------------------------------------------------------------------
  -----------------

  function MODIFIER_FAC_ADD_SUB_MUL_DIV(PIN_CLAUSES               in TABLETYPE_MODIFIER_CLAUSES,
                                        PIN_MODIFIERTYPE          in number,
                                        PIN_LOOKUPTYPE            in number,
                                        PIN_LOOKUPTABLE           in varchar2,
                                        PIN_LOWERVALUEOPTION      in number,
                                        PIN_HIGHERVALUEOPTION     in number,
                                        PIN_PARAMETERVALUE        in number,
                                        PIN_PARAMETERTABLE        in varchar2,
                                        PIN_PARAMETERTABLEALIAS   in varchar2,
                                        PIN_PARAMETERCOL          in varchar2,
                                        PIN_PARAMETERPERIODFILTER in clob,
                                        PIN_INPUTJOINMAP          in TABLETYPE_NAME_JOIN_MAP,
                                        PIN_ROSTERJOINMAP         in TABLETYPE_NAME_JOIN_MAP,
                                        PIN_PARAMETERTABLEFILTER  in varchar2,
                                        PIN_METRICCOMPONENT_ID    in number default null,
                                        pin_LookupInputJoinMap    in tabletype_name_join_map default null, -- A copy of PIN_INPUTJOINMAP that holds the
                                                                                                          -- MCE fields as selected on UI and not translated in TEMP_METRIC_VALUES
                                                                                                          -- NAME1: The fields as they are on the input (same as pin_InputJoinMap.Name1)
                                                                                                          -- NAME2: The fields as selected in MCE
                                        pin_LookupJoinClause      in varchar2 default null,-- The join clause using the Fields as they are on LOOKUP Table
                                        pin_LookupVaryByFields    in varchar2 default null,-- The Fields by which the LK vary, as they are in the LOOKUP Table
                                        pin_LookupInputEE         in varchar2 default null, -- The EE as selected at Plan Level
                                        pin_LookupRosterFilter    in varchar2 default null, --
                                        pin_LookupPeriodFilter    in clob default NULL
                                         ,pin_effective_date_cols_lhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                         ,pin_effective_date_cols_lookup IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                         ,pin_lookup_date_field          IN       VARCHAR2 DEFAULT NULL
                                         ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                                         ,pin_lookup_value_precision     IN       VARCHAR2 DEFAULT NULL
                                         ,pin_lookup_result_precision    IN       VARCHAR2 DEFAULT NULL
                                       ,pin_metricInputTable             IN       varchar2           default null
                                       ,pin_metricInputSequence          IN       varchar2           default null
                                       ,pin_lookupInputFields            IN       tabletype_name_map default null
                                       ,pin_lookupFilterFields           IN       tabletype_name_map default null
                                       ,pin_lookupConstants              IN       tabletype_name_map default null
                                       )
    return TABLETYPE_MODIFIER_CLAUSES;
  -----------------------------------------------------------------------------------------------
  -- Assumptions:
  -- Input Parameters are built using valid table names and column names
  -- Process: Execute operation indicated by pin_modifierType param and append specific clauses to the OBJTYPE_MODIFIER_CLAUSES object
  -- Input Parameters:
  --    pin_clauses                the array that contains the clauses from the previous modifiers and
  --    pin_modifierType           can have two values: 1 - Factor, 2 - Add, 3 - Subtract, 4 - Multiply, 5 - Divide
  --    pin_lookupType             lookup type. Possible values: 1 - Step lookup, 2 - Continuous lookup, 3 - Discrete lookup
  --    pin_lookupTable            lookup table name
  --    pin_LowerValueOption       the option if the lookup field value is less than the smallest lookup value
  --                               Possible values:  1-the result value from the smallest lookup value, 5-zero, 6-an error
  --    pin_HigherValueOption      the option if the lookup field value is greater than the largest lookup value
  --                               Possible values:  3-the result value from the largest lookup value, 6-an error
  --    pin_parameterValue         the constant parameter value from UI
  --    pin_parameterTable         the parameter table name or the input/metric table name that contains the lookup field
  --    pin_parameterCol           the column from the parameter table that is used in calculation of the modifier or the lookup field in the lookup input table
  --    pin_parameterPeriodFilter  period filter on parameter table
  --    pin_inputJoinMap           the join map between the process input and roster
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY','Roster',NULL,NULL),
  --                                                           OBJTYPE_NAME_JOIN_MAP('Col/s from param table','Col/s from process input table',NULL,NULL,NULL))
  --                               F10 - the column from roster table that is used in join condition,
  --                               ML_EARNINGS_ENTITY - the column from process input used in join condition
  --    pin_rosterJoinMap          the join map between  roster table and the parameter table
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL))
  --                               F20 and F50 - the cols from parameter table and Roster that are used in the join condition
  --    pin_parameterTableFilter   filter on the lookup input table (if lookup is used)
  -----------------------------------------------------------------------------------------------
  --    Call statement:
  /*    DECLARE
     MODIFIER_CLAUSES  TABLETYPE_MODIFIER_CLAUSES;
  BEGIN
     MODIFIER_CLAUSES := METRICS_PROCESSING.MODIFIER_FAC_ADD_SUB_MUL_DIV(pin_clauses =>  TABLETYPE_MODIFIER_CLAUSES(
                                                                                OBJTYPE_MODIFIER_CLAUSES(SELECT_CLAUSE => 'ML_FINAL_VALUE',
                                                                                                         FROM_CLAUSE => 'TEMP_METRIC_LOOKUPS',
                                                                                                         WHERE_CLAUSE => '1=1',
                                                                                                         WHEN_CLAUSE => NULL
                                                                                                         MODULE => 'METRICS'))
                                                              ,pin_modifierType => 1
                                                              ,pin_lookupType => 2
                                                              ,pin_lookupTable => 'T124'
                                                              ,pin_LowerValueOption => 1
                                                              ,pin_HigherValueOption => 3
                                                              ,pin_parameterValue => NULL
                                                              ,pin_parameterTable => 'T200'
                                                              ,pin_parameterCol => 'F50'
                                                              ,pin_parameterPeriodFilter => NULL
                                                              ,pin_inputJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F100','ML_EARNINGS_ENTITY','ROSTER',NULL,NULL)
                                                              ,pin_rosterJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL))
                                                              ,pin_parameterTableFilter => NULL
                                                              );
  END;*/
  -----------------------------------------------------------------------------------------------
  -----------------

  function MODIFIER_ROUND_UP_DOWN(PIN_CLAUSES            in TABLETYPE_MODIFIER_CLAUSES,
                                  PIN_MODIFIERTYPE       in number,
                                  PIN_VALUE              in number,
                                  PIN_INPUTJOINMAP       in TABLETYPE_NAME_JOIN_MAP,
                                  PIN_METRICCOMPONENT_ID in number default NULL
                                  ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL)
    return TABLETYPE_MODIFIER_CLAUSES;
  -----------------------------------------------------------------------------------------------
  -- Assumptions:
  -- Input Parameters are built using valid table names and column names
  -- Process: Execute operation indicated by pin_modifierType param and append specific clauses to the OBJTYPE_MODIFIER_CLAUSES object
  -- Input Parameters:
  --    pin_clauses                the array that contains the clauses from the previous modifiers and
  --    pin_modifierType           can have two values: 1 - ROUND UP, 2 - ROUND DOWN
  --    pin_value                  the number of decimals
  -----------------------------------------------------------------------------------------------
  --    Call statement:
  /*    DECLARE
     MODIFIER_CLAUSES  TABLETYPE_MODIFIER_CLAUSES;
  BEGIN
     MODIFIER_CLAUSES := METRICS_PROCESSING.MODIFIER_ROUND_UP_DOWN(pin_clauses =>  TABLETYPE_MODIFIER_CLAUSES(
                                                                                OBJTYPE_MODIFIER_CLAUSES(SELECT_CLAUSE => 'ML_FINAL_VALUE',
                                                                                                         FROM_CLAUSE => 'TEMP_METRIC_LOOKUPS',
                                                                                                         WHERE_CLAUSE => '1=1',
                                                                                                         WHEN_CLAUSE => NULL
                                                                                                         MODULE => 'COMPONENTS'))
                                                              ,pin_modifierType => 1
                                                              ,pin_value => 2
                                                              );
  END;*/
  -----------------------------------------------------------------------------------------------
  ---------------

  function MODIFIER_SPLIT_ROUND(PIN_CLAUSES             in TABLETYPE_MODIFIER_CLAUSES,
                                PIN_MODIFIERTYPE        in number,
                                PIN_VALUE               in number,
                                PIN_PARAMETERTABLE      in varchar2,
                                PIN_PARAMETERTABLEALIAS in varchar2,
                                PIN_PARAMETERCOL        in varchar2,
                                PIN_INPUTJOINMAP        in TABLETYPE_NAME_JOIN_MAP,
                                PIN_ROSTERCOLS          in TABLETYPE_NAME_JOIN_MAP,
                                PIN_PARAMPERIODFILTER   in clob,
                                PIN_METRICCOMPONENT_ID  in number default NULL
                                 ,pin_effective_date_cols    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                 ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL)
    return TABLETYPE_MODIFIER_CLAUSES;
  -----------------------------------------------------------------------------------------------
  -- Assumptions:
  -- Input Parameters are built using valid table names and column names
  -- Process: Execute operation indicated by pin_modifierType param and append specific clauses to the OBJTYPE_MODIFIER_CLAUSES object
  -- Input Parameters:
  --    pin_clauses                the array that contains the clauses from the previous modifiers and
  --    pin_modifierType           can have two values: 1 - SPLIT, 2 - ROUND
  --    pin_value                  the constant parameter value from UI
  --    pin_parameterTable         the parameter table
  --    pin_parameterCol           the column from the parameter table that is used in calculation of the modifier
  --    pin_inputJoinMap           the join map between the input and the roster table and input and parameter table
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY','Roster',NULL,NULL),
  --                                                           OBJTYPE_NAME_JOIN_MAP('Col/s from param table','Col/s from process input table',NULL,NULL,NULL))
  --                               F10 - the col from parameter table that is used in join condition,
  --                               ML_EARNINGS_ENTITY - the col from input used in join condition,
  --                               Roster - roster table
  --    pin_rosterCols             the join map between the roster table and the parameter table
  --                               Ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL))
  --                               F20 and F50 - the cols from parameter table and Roster that are used in join condition
  --    pin_paramPeriodFilter      period filter on parameter table
  -----------------------------------------------------------------------------------------------
  --    Call statement:
  /*    DECLARE
     MODIFIER_CLAUSES  TABLETYPE_MODIFIER_CLAUSES;
  BEGIN
     MODIFIER_CLAUSES := METRICS_PROCESSING.MODIFIER_SPLIT_ROUND(pin_clauses =>  TABLETYPE_MODIFIER_CLAUSES(
                                                                                OBJTYPE_MODIFIER_CLAUSES(SELECT_CLAUSE => 'ML_FINAL_VALUE',
                                                                                                         FROM_CLAUSE => 'TEMP_METRIC_LOOKUPS',
                                                                                                         WHERE_CLAUSE => '1=1',
                                                                                                         WHEN_CLAUSE => NULL,
                                                                                                         MODIFIER_OPERATIONS => NULL,
                                                                                                         MODULE => 'METRICS'))
                                                              ,pin_modifierType => 1
                                                              ,pin_value => NULL
                                                              ,pin_parameterTable => 'T500'
                                                              ,pin_parameterCol => 'F12'
                                                              ,pin_inputJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F10','ML_EARNINGS_ENTITY','Roster',NULL,NULL),
                                                                                                           OBJTYPE_NAME_JOIN_MAP('F100','ML_METRIC_CALC_ENTITY_ID_1',NULL,NULL,NULL))
                                                              ,pin_rosterJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('F20,F50',NULL,NULL,NULL,NULL))
                                                              ,pin_paramPeriodFilter => NULL);
  END;*/
  -----------------------------------------------------------------------------------------------
  -----------------

  procedure CALL_MODIFIERS(PIN_MODIFIERRESULTTABLE in varchar2,
                           PIN_MODIFIERCALLS       in clob,
                           PIN_MODIFIERRESULTCOLS  in varchar2,
                           PIN_INPUTCOLS           in varchar2,
                           PIN_EARNINGENTITY       in varchar2 := null,
                           POUT_INSERTSTATEMENT    out clob,
                           POUT_WHENCLAUSE         out clob,
                           POUT_SELECTCLAUSE       out clob,
                           POUT_FROMCLAUSE         out clob,
                           POUT_WHERECLAUSE        out clob,
                           PIN_METRICCOMPONENT_ID  in number default null);
  -----------------------------------------------------------------------------------------------
-- Assumptions:
-- Input Parameters are built using valid table names and column names
-- Process: executes the calls to modifier functions and creates the final insert statement
-- Parameters:
-- pin_modifierResultTable       the name of the modifier result table
-- pin_modifierCalls             the calls to the modifier functions
-- pin_modifierResultCols        the column names in the modifier result table separated by comma
-- pin_inputCols                 the aditional columns that need to be inserted in the modifier result table separated by comma
-- pout_insertStatement          the insert statement that is created and is returned as output
-- pout_whenClause               the when clause of the insert statement without else part
-- pout_selectClause             the select clause of the insert statement
-- pout_fromClause               the from clause of the insert statement
-- pout_whereClause              the where clause of the insert statement
-----------------------------------------------------------------------------------------------
--    Call statement:
/*    DECLARE
               V_OUT1 CLOB;
               V_OUT2 CLOB;
               V_OUT3 CLOB;
               V_OUT4 CLOB;
               V_OUT5 CLOB;
            BEGIN
               METRICS_PROCESSING.CALL_MODIFIERS(
                  pin_modifierResultTable => 'RESULT_TABLE',
                  pin_modifierCalls => 'METRICS_PROCESSING.MODIFIER_FLOOR_CAP
                                          (pin_clauses => TABLETYPE_MODIFIER_CLAUSES(OBJTYPE_MODIFIER_CLAUSES(''MS_FINAL_VALUE'',''TEMP_METRIC_STATISTICS'',NULL,NULL,NULL)),
                                           pin_modifierType => 1,
                                           pin_value => NULL,
                                           pin_parameterTable => ''PARAMETER_TABLE'',
                                           pin_parameterCol => ''PARAMETER_COL'',
                                           pin_inputJoinMap => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP(''COL1'',''MS_METRIC_CALC_ENTITY_NAME1'',NULL,NULL,NULL),
                                                                                       OBJTYPE_NAME_JOIN_MAP(''COL2'',''MS_METRIC_CALC_ENTITY_NAME2'',NULL,NULL,NULL)),
                                           pin_rosterCols => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP(''COL3,COL4'',''ROSTER'',NULL,NULL,NULL)))',
                  pin_modifierResultCols => 'F100,F101,F102,F103,F104,ROW_IDENTIFIER,ROW_VERSION'
                  pin_inputCols => 'MS_METRIC_CALC_ENTITY_NAME1,MS_METRIC_CALC_ENTITY_NAME2',
                  pout_insertStatement => V_OUT1,
                  pout_whenClause => V_OUT2,
                  pout_selectClause => V_OUT3,
                  pout_fromClause => V_OUT4,
                  pout_whereClause => V_OUT5);
            END;*/
-----------------------------------------------------------------------------------------------
-- *******************************    PUBLIC PROCEDURES END         *******************************
end MODIFIERS;
/
