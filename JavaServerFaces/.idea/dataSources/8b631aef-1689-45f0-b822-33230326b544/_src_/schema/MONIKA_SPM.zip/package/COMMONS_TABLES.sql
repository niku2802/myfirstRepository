CREATE PACKAGE COMMONS_TABLES AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product      : commons
  -- Module       : tables-commons
  -- Requester    : Homeuca
  -- Author       : Hrubaru, Ionut; Rohit, Maxim; Popescu, Mircea; Homeuca, Victor; Sharma, Pooja
  -- Create date  : 20110415
  -- Reviewer     : Homeuca, Victor
  -- Review date  : 20110415
  -- Description  : package used to handle all operations for data tables
  --
  -- Change author  : Popescu, Mircea
  -- Change date  : 20110509
  -- Change reviewer   :
  -- Change review date :
  -- Change description : Added the CHECK_REQUIRED_FIELD function

  --
  -- Change author  : Vijaywargiya, Abhishek
  -- Change date  : 14.May.2013
  -- Change reviewer   : Sharma, Pooja
  -- Change review date : 14.May.2013
  -- Change description : Remove redundant procedures from Commons_Tables package,
  --                      since their latest version exists in Commons_Indexing package.
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START        *******************************
  FUNCTION COMMA_TO_TABLE(pi_col_list in varchar2) return SYS.Hsblknamlst;

  FUNCTION UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME  IN VARCHAR2,
                                   PI_COL_LIST    IN VARCHAR2,
                                   PI_CLAUSE_TYPE IN NUMBER DEFAULT 1) --1. PROJECTION (Select clause) or GROUPING  --2. IN CLAUSE as data,
   RETURN VARCHAR2;

  function NVL_CHECK(v_col_name varchar2, v_data_type number) return varchar2;

  FUNCTION GET_ST_DATA(table_name           VARCHAR2,
                       column_names         VARCHAR2,
                       period_fields        TABLETYPE_NAME_MAP,
                       where_clause         VARCHAR2 DEFAULT ' ',
                       orderby_clause       VARCHAR2,
                       select_rowstartindex NUMBER, --0 if last page
                       page_size            NUMBER,
                       lastpage_flag        NUMBER,
                       count_flag           NUMBER DEFAULT 0)
    RETURN sys_refCursor;

  FUNCTION CHECK_REQUIRED_FIELD(PIN_TABLE_NAME IN VARCHAR2,
                                PIN_COLUMNS    IN CLOB) RETURN SYS_REFCURSOR;

  FUNCTION Resultset_Merge_Fields(pin_table_name VARCHAR2,
                                  pin_add_fields VARCHAR2,
                                  pin_data       CLOB,
                                  stale_check    simple_integer default 0)
    RETURN sys_refCursor;

  FUNCTION HIERARCHY_VALIDATIONS(pin_RelationshipTables IN TABLETYPE_RELATIONSHIP_TABLES,
                                 pin_TimeUnit           IN NUMBER DEFAULT NULL,
                                 pin_StartTimeUnitCol   IN VARCHAR2 DEFAULT NULL,
                                 pin_EndTimeUnitCol     IN VARCHAR2 DEFAULT NULL,
                                 pin_Data               IN CLOB DEFAULT NULL)
    RETURN NUMBER;

  FUNCTION ADJ_HIERARCHY_VALIDATIONS(pin_RelationshipTable  IN VARCHAR2,
                                     pin_Data               IN CLOB,
                                     pin_RelationshipTables IN TABLETYPE_RELATIONSHIP_TABLES,
                                     pin_TimeUnit           IN NUMBER DEFAULT NULL,
                                     pin_StartTimeUnitCol   IN VARCHAR2 DEFAULT NULL,
                                     pin_EndTimeUnitCol     IN VARCHAR2 DEFAULT NULL)
    RETURN NUMBER;

  /*
    -- Author     : Maxim Rohit
    -- Create date: 1 APRIL 2012
    -- Description: FUNCTION returns the next value for the autovalue column of the table name being passed
    -- Parameters:-
    -- IN Parameters

    -- pi_TABLE_ID              Auto value registering table name.
  Example:-

  declare

  result number;

  begin
  -- Call the function
  result := commons_tables.get_auto_value(pi_table_id => 34);

  dbms_output.put_line(result);
  end;

  */
  Function GET_AUTO_VALUE(pi_TABLE_ID IN number) return number;

  /*
    -- Author     : Maxim Rohit
    -- Description:
    -----**************************************************************************************------------------------
    -- Return : List of deleted ID's
    -----**************************************************************************************------------------------


  Adjustment_DateRange_Check

  Input parameter:-
  PI_effective_start    VARCHAR2,--effective start date/period column name
  PI_effective_end      VARCHAR2,-- effective end date/period column name
  PI_Period_check       NUMBER,-- 0 DATE RANGE,   1 PERIOD RANGE
  PI_key_Data           CLOB, --CONTAINS THE DATA TO BE TESTED

  Returns :-
  sys_refCursor
  example:-
  declare
    c_list sys_refCursor;
    v_ROW_IDENTIFIER number(10);
  begin
    c_list := Adjustment_DateRange_Check(PI_effective_end   => 'F565',
                                         PI_Period_check    => 0,
                                         PI_key_Data        => 'SELECT 4 ROW_IDENTIFIER, 549 F564, 548 F565 FROM DUAL  UNION ALL SELECT 5 , 548, 549 FROM DUAL  UNION ALL SELECT 0 , 549, 548 FROM DUAL  UNION ALL SELECT 0 , 548, 549 FROM DUAL',
                                         PI_effective_start => 'F564');

   loop
      fetch c_list into v_ROW_IDENTIFIER;
      exit when c_list%notfound;
      dbms_output.put_line(v_ROW_IDENTIFIER);
    end loop;
  end;
  */

  FUNCTION Adjustment_DateRange_Check(PI_effective_start varchar2,
                                      PI_effective_end   varchar2,
                                      PI_Period_check    number,
                                      PI_key_Data        in clob)
    RETURN sys_refCursor;

  -- Author     : Lazarescu, Bogdan
  -- Description: used for GET_DATA_FROM_QUERY SP for bind variables call
  -----**************************************************************************************------------------------

  FUNCTION RUN_QUERY(pin_sql            IN CLOB,
                     pin_using_bind_var IN coltype_NAME_VALUE)
    RETURN SYS_REFCURSOR;

  /*
     -- Author     : Maxim Rohit
     -- Description: The funcvtion accepts a table name and returns a map of column vs there nullabilty
     -----**************************************************************************************------------------------
     -- Return : Map of Column versus there nullablity
     -----**************************************************************************************------------------------


   GET_COL_NULLABLITY

   Input parameter:-
   pi_TABLE    VARCHAR2--Table Name


   Returns :-
   COLTYPE_COL_NULLABLITY
   example:-
  select * from table(commons_tables.get_col_nullablity(pi_table => 'tes_overlap'))
   */

  Function GET_COL_NULLABILITY(pi_TABLE IN varchar2)
    return COLTYPE_COLUMN_NULLABILITY;

  Function GET_COLUMN_CHARACTERISTICS(pi_TABLE IN varchar2)
    return COLTYPE_COLUMN_CHARACTERISTICS;

  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  /*
    -- Author     : Maxim Rohit
    -- Description: Procedure Deletes the records from a table based on teh where conditon
                    and returns the ID's of the rows deleted.
    -----**************************************************************************************------------------------

      -- Input Parameters:
   PI_Table          IN  VARCHAR2   the table from which we are deleting the data(usually a T table)
     PI_Where_Clause   IN  VARCHAR2   the where clause for the delete query
     PO_Row_Identifier OUT  VARCHAR2  Returns ROW_IDENTIFIER of the deleted rows

  example:
  declare

    po_row_identifier coltype_id;
  begin
    -- Call the procedure
    adjustment_delete(pi_table => 'T1759',
                      pi_v_Where_Clause => '(ROW_IDENTIFIER,ROW_VERSION) IN ((4,0),(5,0))',
                      po_row_identifier => po_row_identifier);
  end;




  */
  PROCEDURE Adjustment_Delete(PI_Table          in varchar2,
                              PI_Where_Clause   in clob,
                              PI_ID_Column      in varchar2,
                              PO_Row_Identifier out coltype_id);

  PROCEDURE Multi_Edit_Upsert(pin_table_name             VARCHAR2,
                              pin_id_column_name         VARCHAR2,
                              pin_version_column_name    VARCHAR2,
                              pin_seq_used_for_id        VARCHAR2,
                              pin_ent_intern_id_col_name VARCHAR2,
                              pin_ent_seq_name           VARCHAR2,
                              pin_av_col_name            VARCHAR2,
                              pin_data                   CLOB,
                              pout_list_of_updated_ids   OUT COLTYPE_ID,
                              /*  pout_list_of_inserted_ids  OUT COLTYPE_ID,*/
                              pout_map_of_inserted_ids OUT TABLETYPE_ID_ID);

  /*
      -- Author     : Maxim Rohit
      -- Create date: 1 March 2012
      -- Description: Procedure accepts the table name(being Posted to ) and a QI table name( the table from data
                      is being poated). Based on the Mode(Insert/update/Insert-update). It also hanlde the nitigrities of
                      T-tables like Row identifiers, Row version, entity columns etc.

      -----**************************************************************************************------------------------
      -- Return : NA
      -----**************************************************************************************------------------------

      -- Parameters:-
      -- IN Parameters

      -- pi_table_name              Table being posted to
      -- pi_QI_name                 Table being posted from
      -- PI_mode                    2= UPDATE_EXISTING_RECORDS, 3=UPDATE_AND_INSERT_NEW_RECORDS, 4= INSERTING
      -- pi_list_of_columns         List of columns that are being subjectd(Inserted/updated) to this run
      -- pi_id_column_name          Id Column of the table
      -- pi_version_column_name     Version cloumn of the table
      -- pi_seq_used_for_id         Sequence being used for ID generation
      -- pi_ent_intern_id_col_name  Entity internal ID column id the table is entity table
      -- pi_ent_seq_name            Sequence being used for Entity internal ID generation
      -- pi_av_col_name             Auto value column name
      -- pi_av_generated_sw         Is autovalue being generated by the software
      -- pi_process_id              Transaction ID for DDL rollback
      -- pi_gather_stats            Gather stats after execution 1=true, 0=false


      -- pi_Dest_Table      Destination table name, whoes end dates are simulated to be closed
      -- pi_QI_Table        Qualifying input
      -- pi_key_Fields      list of comma seprated key fields
      -- PI_Effective_Start Start Column
      -- PI_Effective_End     End Column
      -- PI_Is_Period         1=Period range, 0=Date range
      -- PI_TU_ID             Time unit in case of period range


    -- OUT Parameter
    -- OUT Parameters
    -- po_update_count            Number of records being updated.
    -- po_insert_count            Number of records inserted.
    -- po_status                  2 means primary key enabled
                                    9 means unique indexes are created
                                    3 means unique\non unique indexes and primary key enables/created

                                    8 means non unique indexes are disabled
                                    4 unique indexes are disabled adn unique ones are dropped
                                    5 means index and primary key disabled/dropped

    -- PO_Count             Count of row for which end date was populated.


   --Example
      /*
   declare

    po_index_created number(1);
    po_update_count  number;
    po_insert_count  number;
    po_av_count       number;
    PO_closed_dates_Count number;
  pi_unmapped_columns TABLETYPE_CHARMAX:=
  TABLETYPE_CHARMAX('F64239','F64345','F64240','F64341','F64342','F66587','F66589',
  'F66592','F66594','F66611','F66613','F66615','F66553','F66554','F66555','F66556','F66557','F66558'
  ,'F66559','F66560','F66561','F66563','ROW_IDENTIFIER','ROW_VERSION');
  begin
    -- Call the procedure
    commons_tables.common_upsert(pi_table_name             => 'T560716',
                                 pi_qi_name                => 'DLQI_564592_169216_BKP',
                                 PI_mode                   => 4,
                                 pi_list_of_columns   =>pi_unmapped_columns,
                                 pi_id_column_name         => 'ROW_IDENTIFIER',
                                 pi_version_column_name    => 'ROW_VERSION',
                                 pi_seq_used_for_id        => 'T560716_ROW_IDENTIFIER_SEQ',
                                 pi_ent_intern_id_col_name => null,
                                 pi_ent_seq_name           => null,
                                 pi_av_count=>null,
                                 pi_gather_stats           =>1,
                                 pi_av_generated_sw        => 0,
                                 pi_av_col_name            => null,
                                 pi_process_id             => 'dgs54g54',
                                 po_update_count           => po_update_count,
                                 po_insert_count           => po_insert_count,
                                 po_av_count               =>po_av_count,
                                 po_status                 => po_index_created,
                                  PO_closed_dates_Count=>  PO_closed_dates_Count,
                                 --
                                  pi_is_close_end    =>0,
                               pi_key_Fields      =>null,
                               pi_Effective_Start =>null,
                               pi_Effective_End   =>null,
                               pi_Is_Period       =>null,
                               pi_tu_id           =>null
  );

    dbms_output.put_line(po_index_created);
      dbms_output.put_line(po_update_count);
        dbms_output.put_line(po_insert_count);
      dbms_output.put_line(po_av_count);
  end;

      */

  procedure Common_Upsert(pi_table_name             VARCHAR2,
                          pi_QI_name                VARCHAR2,
                          PI_mode                   NUMBER,
                          pi_list_of_columns        IN TABLETYPE_CHARMAX,
                          pi_id_column_name         VARCHAR2,
                          pi_version_column_name    VARCHAR2,
                          pi_seq_used_for_id        VARCHAR2,
                          pi_ent_intern_id_col_name VARCHAR2,
                          pi_ent_seq_name           VARCHAR2,
                          pi_av_col_name            VARCHAR2,
                          pi_av_generated_sw        number,
                          pi_process_id             varchar2,
                          pi_gather_stats           number,
                          pi_av_count               number,

                          --moving close date parameters start
                          pi_is_close_end    number,
                          pi_key_Fields      IN VARCHAR2,
                          pi_Effective_Start IN VARCHAR2,
                          pi_Effective_End   IN VARCHAR2,
                          pi_Is_Period       IN number,
                          pi_tu_id           IN number,

                          PO_closed_dates_Count out NUMBER,
                          --moving close date parameters end
                          po_av_count     out number,
                          po_update_count out number,
                          po_insert_count out number,
                          po_status       out number);

  /*
    -- Author     : Maxim Rohit
    -- Create date: 1 March 2012
    -- Description: Procdure for closing end dates w.r.t key fields
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
     -- Parameters:-
    -- IN Parameters

    -- pi_Table              Table name
    -- pi_key_Fields        list of comma seprated key fields
    -- PI_Effective_Start   Start Column
    -- PI_Effective_End     End Column
    -- PI_Is_Period         1=Period range, 0=Date range
    -- PI_TU_ID             Time unit in case of period range
    -- PI_Commit            Commit changes after populating dates, 0=No, 1=Yes

    -- OUT Parameter
    -- PO_Count             Count of row for which end date was populated.
  Example:-

  declare
    PO_Count number;
  begin
    COMMONS_TABLES.COMMON_CLOSING_END(pi_Table           => 'test_overlap_check_ori',
                                      pi_key_Fields      => 'key1',
                                      PI_Effective_Start => 'start1',
                                      PI_Effective_End   => 'end1',
                                      PI_Is_Period       => 1,
                                      PI_TU_ID           => 241 PI_Commit => 0,
                                      PO_Count           => PO_Count);

  end;

  */
  PROCEDURE COMMON_CLOSING_END(pi_Table           IN VARCHAR2,
                               pi_key_Fields      IN VARCHAR2,
                               PI_Effective_Start IN VARCHAR2,
                               PI_Effective_End   IN VARCHAR2,
                               PI_Is_Period       IN number,
                               PI_TU_ID           IN number,
                               /*   PI_Commit          IN number,*/
                               PO_Count out NUMBER

                               );

  /*
    -- Author     : Maxim Rohit
    -- Create date: 1 March 2012
    -- Description: Procedure for check overlap for ranges tables, the procedure simulates
    --              closing end date of pi_Dest_Table for performing the check
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
    -- Parameters:-
    -- IN Parameters

    -- pi_Dest_Table      Destination table name, whoes end dates are simulated to be closed
    -- pi_QI_Table        Qualifying input
    -- pi_key_Fields      list of comma seprated key fields
    -- PI_Effective_Start Start Column
    -- PI_Effective_End     End Column
    -- PI_Is_Period         1=Period range, 0=Date range
    -- PI_TU_ID             Time unit in case of period range


    -- OUT Parameter
    -- PO_Count             Count of row for which end date was populated.

    Example:-

    declare
    po_overlap_chk_res number;

    begin
      -- Call the procedure
      COMMONS_TABLES.common_overlap(pi_Dest_Table => upper('test_overlap'),
                                    pi_qi_table => UPPER('test_overlap_check'),
                                    pi_key_fields => 'key1',
                                    pi_effective_start => 'start1',
                                    pi_effective_end => 'end1',
                                    PI_TU_ID=>241,
                                    pi_is_period => 0,
                                   PI_Is_Recreate=>1,
                                    po_overlap_chk_res => po_overlap_chk_res);

                                    dbms_output.put_line(po_overlap_chk_res);
    end;
  */
  PROCEDURE COMMON_OVERLAP(pi_Dest_Table      IN VARCHAR2,
                           pi_QI_Table        IN VARCHAR2,
                           pi_key_Fields      IN VARCHAR2,
                           PI_Effective_Start IN VARCHAR2,
                           PI_Effective_End   IN VARCHAR2,
                           PI_Is_Period       IN number,
                           PI_TU_ID           IN number,
                           PI_Is_Recreate     IN number,
                           po_Overlap_Chk_Res OUT NUMBER,
                           PI_INPUT_COUNT     IN NUMBER DEFAULT NULL

                           );

  /*
    -- Author     : Maxim Rohit
    -- Create date: 1 APRIL 2012
    -- Description: Procedure sets the next value for the autovalue column of the table name being passed and updates the timestamp column with current value.
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
     -- Parameters:-
    -- IN Parameters

    -- pi_TABLE_ID           Auto value registering table name.
    -- pi_value              Next value to be set for the autovalue column
  Example:-

  begin
  -- Call the procedure
  commons_tables.set_auto_value(pi_table_ID => 34,
                                pi_value => 352);
  end;


  */
  PROCEDURE SET_AUTO_VALUE(PI_TABLE_ID IN number, pi_value IN number);

  /*
    -- Author     : Maxim Rohit
    -- Description: Procedure performs an overlap check on the data set being passed
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
     -- Input Parameters:
       pi_TABLE                IN  VARCHAR2   The table for which overlap check is to be performed
       pi_KEY_FIELDS           IN  clob       comma seprated list key fields values
       PI_effective_start      IN  VARCHAR2   name of the efffective start date/period columns
       PI_effective_end        IN  VARCHAR2   name of the efffective end date/period columns
       PI_is_Period            IN  number     PI_is_Period       number   -- Period range then 1, date range than 0

  Out parameter :-
      po_DATE_RANGE_RES        out NUMBER if 1 then pass, if 0 then fail
  example:-
       declare
           po_OVERLAP_CHK_RES NUMBER;
         begin
           COMMON_OVERLAP_CHECK(pi_TABLE           => 't3',
                                pi_KEY_FIELDS      => 't3,t2_number',
                                PI_effective_start => 'effective_start_date',
                                PI_effective_end   => 'effective_end_date',
                                PI_is_Period       => 0,
                                po_OVERLAP_CHK_RES => po_OVERLAP_CHK_RES
                                );
         end;
  */

  PROCEDURE COMMON_OVERLAP_CHECK(pi_TABLE           IN VARCHAR2,
                                 pi_KEY_FIELDS      IN CLOB,
                                 PI_effective_start IN VARCHAR2,
                                 PI_effective_end   IN VARCHAR2,
                                 PI_is_Period       IN number,
                                 po_OVERLAP_CHK_RES OUT NUMBER

                                 );

  PROCEDURE COMMON_OVERLAP_CHECK(pi_TABLE           IN VARCHAR2,
                                 pi_TABLE_CLOB      IN CLOB,
                                 pi_KEY_FIELDS      IN CLOB,
                                 PI_effective_start IN VARCHAR2,
                                 PI_effective_end   IN VARCHAR2,
                                 PI_is_Period       IN number,
                                 PI_ID_COLUMN       IN VARCHAR2,
                                 po_OVERLAP_CHK_RES OUT NUMBER,
                                 PI_INPUT_COUNT     IN NUMBER DEFAULT NULL);

  PROCEDURE COMMON_OVERLAP_POST(pi_TABLE           IN VARCHAR2,
                                pi_TABLE_CLOB      IN CLOB,
                                pi_KEY_FIELDS      IN CLOB,
                                pi_DATA_FIELDS     IN CLOB,
                                PI_effective_start IN VARCHAR2,
                                PI_effective_end   IN VARCHAR2,
                                PI_is_Period       IN number,
                                PI_ID_COLUMN       IN VARCHAR2,
                                po_OVERLAP_CHK_RES OUT NUMBER,
                                PI_INPUT_COUNT     IN NUMBER DEFAULT NULL,
                                PI_OVERLAP_TABLE   IN varchar2 DEFAULT NULL,
                                PI_ADD_LOG_INFO    IN COLTYPE_KEY_VALUE default null);

  /*

    -- Author     : Maxim Rohit
    -- Description: Procedure performs an date range check on the data set being passed
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
  Input parameter:-
  pi_TABLE           VARCHAR2,--Table name
  PI_effective_start VARCHAR2,--Effective start column name
  PI_effective_end   VARCHAR2,--Effective End column name
  PI_is_Period       number   -- Period range then 1, date range than 0

  Out parameter :-
  po_DATE_RANGE_RES  NUMBER ?if 1 then pass, if 0 then fail

    example:-
         declare
             po_DATE_RANGE_RES NUMBER;
           begin

             COMMON_DATE_RANGE_CHECK(pi_TABLE           => 't3',
                                  PI_effective_start => 'effective_start_date',
                                  PI_effective_end   => 'effective_end_date',
                                  PI_is_Period       => 0,
                                  po_DATE_RANGE_RES => po_DATE_RANGE_RES

                                  );
           end;
    */

  PROCEDURE COMMON_DATE_RANGE_CHECK(pi_TABLE           IN VARCHAR2,
                                    PI_effective_start IN VARCHAR2,
                                    PI_effective_end   IN VARCHAR2,
                                    PI_is_Period       IN number,
                                    po_DATE_RANGE_RES  OUT NUMBER);

  /*


    -- Author     : Maxim Rohit
    -- Description: Procedure performs an uniqueness check on the data set being passed
    -----**************************************************************************************------------------------
    -- Return : NA
    -----**************************************************************************************------------------------
   Input parameter:-
  pi_TABLE          VARCHAR2,--Table name
  pi_KEY_FIELDS      CLOB,-- comma separated list of key columns

  Out parameter :-
  po_UNIQUE_CHK_RES NUMBER ?if 1 then pass, if 0 then fail

  example:-
  declare
  po_UNIQUE_CHK_RES number;

  begin
  COMMON_UNIQUE_CHECK(pi_TABLE      =>'t12',
                                                  pi_KEY_FIELDS =>'t1,t2'   ,
                                                  po_UNIQUE_CHK_RES =>po_UNIQUE_CHK_RES);
                                                  dbms_output.put_line(po_UNIQUE_CHK_RES);
  end;

  */

  PROCEDURE COMMON_UNIQUE_CHECK(pi_TABLE          IN VARCHAR2,
                                pi_KEY_FIELDS     IN VARCHAR2,
                                po_UNIQUE_CHK_RES OUT NUMBER,
                                PI_INPUT_COUNT    IN NUMBER DEFAULT NULL);

  PROCEDURE COMMON_UNIQUE_CHECK(pi_TABLE          IN VARCHAR2,
                                pi_KEY_FIELDS     IN VARCHAR2,
                                pi_WHERE_CLAUSE   IN VARCHAR2,
                                po_UNIQUE_CHK_RES OUT NUMBER,
                                PI_INPUT_COUNT    IN NUMBER DEFAULT NULL);

  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /* pin_table_name          IN  VARCHAR2    the table for which the validation is performed (usually a T table)
     pin_key_fields          IN  VARCHAR2    comma separated list of key fields
     pin_data                IN  CLOB        a CLOB variable holding the edited data in the form of a cursor
     pout_list_of_stale_ids  OUT COLTYPE_ID  array of ID's that failed the stale validation
     pout_list_of_failed_ids OUT COLTYPE_ID  array of ID's that failed the uniqueness validation
  */
  /*example:
   DECLARE
      PIN_TABLE_NAME VARCHAR2(32767);
      pin_key_fields VARCHAR2(32767);
      PIN_DATA CLOB;
      pout_list_of_stale_ids COLTYPE_ID;
      pout_list_of_failed_ids COLTYPE_ID;

    BEGIN
      PIN_TABLE_NAME := 'T152';
      pin_key_fields := 'F11,F25';
      PIN_DATA :=
         'SELECT 0 "UpdatedInsertedFlag",8 ROW_IDENTIFIER,0 ROW_VERSION,  TO_DATE(''01.01.2006'',''DD.MM.YYYY'') START_DATE, TO_DATE(''01.01.2011'',''DD.MM.YYYY'') END_DATE, ''Territory 6'' F11, 600 F25, 1001 F100, 3423 E_INTERNAL_ID FROM DUAL UNION ALL
          SELECT 0,                      2,               5,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 2'' ,    200    , 1002 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                      3,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 4'' ,    400    , 1003 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                      5,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 4'' ,    400    , 1004 F100, 15                 FROM DUAL UNION ALL
          --SELECT 0,                    9,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 4'' ,    400    , 1005 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                      4,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 3'' ,    900    , 1006 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                      6,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 5'' ,    44     , 1007 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                      7,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 1'' ,    100    , 1008 F100, 15                 FROM DUAL UNION ALL
          SELECT 1,                    -10,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 6'' ,    600    , 1009 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                     11,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''T12''         ,    99     , 1010 F100, 15                 FROM DUAL UNION ALL
          SELECT 0,                      9,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,          null           ,    77     , 1011 F100, 15                 FROM DUAL
      ';
    Adjustment_Unique_Check(PIN_TABLE_NAME,pin_key_fields,PIN_DATA,pout_list_of_stale_ids,pout_list_of_failed_ids);

    for i in 1..pout_list_of_stale_ids.count  loop    dbms_output.put_line('Stale: '||pout_list_of_stale_ids(i)); end loop;

    for i in 1..pout_list_of_failed_ids.count loop    dbms_output.put_line('Failed: '||pout_list_of_failed_ids(i)); end loop;
    --  COMMIT;
    END;
  */

  PROCEDURE Adjustment_Unique_Check(pin_table_name          VARCHAR2,
                                    pin_key_fields          VARCHAR2,
                                    pin_data                CLOB,
                                    pout_list_of_stale_ids  OUT COLTYPE_ID,
                                    pout_list_of_failed_ids OUT COLTYPE_ID);

  -----------------------------------------------------------------------------------------
  -- Author: Pooja Sharma , Maxim Rohit
  -- Description: Procedure performs an uniqueness check on the data set being passed
  -----**************************************************************************************------------------------
  -- Return : NA
  -----**************************************************************************************------------------------

  -- Input Parameters:
  /* pi_table_name              IN  VARCHAR2    the table for which the validation is performed (usually a T table)
    pi_key_Fields          IN  VARCHAR2    comma separated list of key fields
    pi_effective_start_date in varchar2  Start Date/Period Column
    pi_effective_end_date   in varchar2    End Date/Period Column
    pi_period_check         in number    0 - Date; 1 -Period
    pi_data             in clob        a CLOB variable holding the edited data in the form of a cursor
    po_list_of_stale_ids out COLTYPE_ID arrays of Id's that are stale.
    pout_list_of_failed_ids  OUT COLTYPE_ID  array of ID's that failed the overlap validation
  */
  /*
     ----Example call for date:

    declare
    -- Non-scalar parameters require additional processing
    po_list_of_stale_ids  coltype_id;
    po_list_of_failed_ids coltype_id;

    begin
    COMMONS_TABLES.ADJUSTMENT_OVERLAP_CHECK(
    pi_data=>'SELECT 1 "UpdatedInsertedFlag", -1 ROW_IDENTIFIER, 0 ROW_VERSION, 1 F1, 257 F463, 261 F464
    FROM DUAL
    UNION ALL SELECT 1, -2 , 0 , 2, 257, 261 FROM DUAL
    UNION ALL SELECT 1, -3 , 0 , 3, 259, 262 FROM DUAL' ,
    pi_key_Fields=>'F1',
    pi_table_name=>'T26580',
    pi_period_check=>1,
    pi_effective_end_date=>'F464',
    pi_effective_start_date=>'F463',
    po_list_of_stale_ids    => po_list_of_stale_ids,
    po_list_of_failed_ids   => po_list_of_failed_ids);

    dbms_output.put_line('Stale');
    for i in 1 .. po_list_of_stale_ids.count loop
      dbms_output.put_line(po_list_of_stale_ids(i));
    end loop;
    dbms_output.put_line('Rejected');
    for i in 1 .. po_list_of_failed_ids.count loop
      dbms_output.put_line(po_list_of_failed_ids(i));
    end loop;
  end;
     */

  PROCEDURE Adjustment_Overlap_Check(pi_table_name           IN VARCHAR2,
                                     pi_key_Fields           IN CLOB,
                                     pi_effective_start_date IN VARCHAR2,
                                     pi_effective_end_date   IN VARCHAR2,
                                     pi_period_check         IN NUMBER,
                                     pi_data                 IN CLOB,
                                     pi_table_clob           in clob,
                                     po_list_of_stale_ids    OUT COLTYPE_ID,
                                     po_list_of_failed_ids   OUT COLTYPE_ID);

  procedure Adjustment_Overlap_Check(pi_table_name           in varchar2,
                                     pi_key_Fields           in clob,
                                     pi_effective_start_date in varchar2,
                                     pi_effective_end_date   in varchar2,
                                     pi_period_check         in number,
                                     pi_data                 in clob,
                                     po_list_of_stale_ids    OUT COLTYPE_ID,
                                     po_list_of_failed_ids   OUT COLTYPE_ID);
  PROCEDURE DELETE_ALL_ST_DATA(table_name    VARCHAR2,
                               entity_fields TABLETYPE_NAME_MAP,
                               period_fields TABLETYPE_NAME_MAP,
                               where_clause  VARCHAR2);

  /*
  -- Author     : Maxim Rohit
  -- Description: The Procedure replicates table properties (indexes, triggers and constarints) to another table

  -----**************************************************************************************------------------------
  -- Return : NA
  -----**************************************************************************************------------------------

  -- Parameters:-
  -- IN Parameters
  -- pi_data_table             Table whose properies need to be replicated
  -- pi_dump_table             Table on which properies need to be replicated
  */

  PROCEDURE Copy_Dependencies(pi_data_table varchar2,
                              pi_dump_table varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 10 Oct 2011
  -- Module     : datamanagement
  -- Description: This procedure returns a sys_refcursor listing table details of all the data table containg entities or busness key of entities and set of fields
  -----**************************************************************************************------------------------
  -- Return : NA
  -----**************************************************************************************------------------------

  -- Parameters:-
  -- IN Parameters

  -- pi_ent_fld                TABLETYPE_ID_ID:- Entities Id to business key(fields) mapping( Entity_ID,Busness_key_id)
  -- pi_fld                    coltype_id:- List of field Id's

  -- OUT Parameters
  -- Po_data_tables            sys_refcursor

  --Example
  /*
  declare
  po_data_tables sys_refcursor;
  pi_ent_fld   TABLETYPE_ID_ID:=TABLETYPE_ID_ID(OBJTYPE_ID_ID(11,1),OBJTYPE_ID_ID(12,2));
  pi_fld         coltype_id:=coltype_id(4,3);
  begin
    -- Call the procedure
    get_list_of_data_tables(pi_ent_fld =>pi_ent_fld,
              pi_fld => null,
              po_data_tables => po_data_tables);
  end;
  */

  procedure get_list_of_data_tables(pi_ent_fld     TABLETYPE_ID_ID,
                                    pi_fld         coltype_id,
                                    Po_data_tables out sys_refcursor);

  PROCEDURE HIERARCHY_OVERLAP_CHECK(pin_Table            IN CLOB,
                                    pin_KeyFields        IN CLOB,
                                    pin_EntityUpperAlias IN VARCHAR2,
                                    pin_ValueUpperAlias  IN VARCHAR2,
                                    pin_EffectiveStart   IN VARCHAR2,
                                    pin_EffectiveEnd     IN VARCHAR2,
                                    pin_IsPeriod         IN NUMBER,
                                    pin_Data             IN CLOB DEFAULT NULL,
                                    pout_OverlapChkRes   OUT NUMBER);

  PROCEDURE HIERARCHY_UNIQUE_CHECK(pin_Table         IN CLOB,
                                   pin_KeyFields     IN CLOB,
                                   pout_UniqueChkRes OUT NUMBER);

  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : CREATE_INDEX
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Table name, index name ,comma separated column list, uniqueness characteristic,
  *                     type (normal or composite), primary key constraint, initrans, tablespace for index, nls sort function value
  * OUTPUT PARAMETERS : po_indexing_info
  * DESCRIPTION       : Creates index (unique/non-unique/composite/primary key indexes)
  * Example           :

  BEGIN

      COMMONS_TABLES.CREATE_INDEX(pi_tablename         => 'T3126',
                                    pi_indexname         => 'T3126' ||
                                                            '_BUSINESSKEY_UI',
                                    pi_col_list          => 'E2787,F2631,E2794,E2800,F2634,F2635,F7777',
                                    pi_uniqueness        => 1,
                                    pi_composite         => 1,
                                    pi_col_is_primarykey => 0,
                                    pi_initrans          => 'INITRANS 5',
                                    pi_index_tablespace  => 'SAGAR_SPM_LATEST_IND',
                                    pi_nls_sort          => 'BINARY_CI',
                                    po_indexing_info     => v_out);
  END;

  Creates unique composite index T3126_BUSINESSKEY_UI on table T3126 for columns E2787,F2631,E2794,E2800,F2634,F2635,F7777 with NLSSORT function applied to the VARCHAR columns.
  **********************************************************************************************************/
  /*
  -- 14.May.2013 -- P.1. CREATE_INDEX
  PROCEDURE CREATE_INDEX(pi_tablename         in VARCHAR2,
                         pi_indexname         in VARCHAR2,
                         pi_col_list          in CLOB,
                         pi_uniqueness        in NUMBER,
                         pi_composite         in NUMBER,
                         pi_col_is_primarykey in NUMBER,
                         pi_initrans          in NUMBER DEFAULT 5,
                         pi_index_tablespace  in VARCHAR2 DEFAULT USER ||
                                                                  '_IND',
                         pi_nls_sort          in VARCHAR2 DEFAULT null,
                         po_indexing_info     OUT CLOB);
  */
  /*********************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : CREATE_INDEXES
    * AUTHOR            : Sagar Thorat
    * REVIEWER          : Pooja Sharma
    * INPUT PARAMETERS  : Tables_id
    * OUTPUT PARAMETERS : Message log (po_log_msg)
    * DESCRIPTION       : Creates indexes for following criteria
    *                     - Primary key constraint and index
    *                     - unique concatenated index on Key columns
    *                     - unique index on E_INTERNAL_ID
    *                     - index on entity columns
    *                     - index on TUPR columns
    * Example           :

    BEGIN
    COMMONS_TABLES.CREATE_INDEXES(3126,po_log_msg);
    END;

    The above example creates indexes:

    PK_T3126
    T3126_E2800_SI
    T3126_F636_SI
    T3126_F7777_SI
    T3126_F637_SI
    T3126_E2787_SI
    T3126_E2794_SI
    T3126_BUSINESSKEY_UI

  The po_log_msg o/p clob variable contains
         Indexes created on Table: T3126
         =====================================
  Index T3126_E2787_SI created on column E2787
  Index T3126_E2794_SI created on column E2794
  Index T3126_E2800_SI created on column E2800
  Index T3126_F637_SI created on column F637
  Index T3126_F636_SI created on column F636
  Index T3126_F7777_SI created on column F7777
  Primary Key and index PK_T3126 created on ROW_IDENTIFIER column
  Index T3126_BUSINESSKEY_UI created on columns E2787,F2631,E2794,E2800,F2634,F2635,F7777

    **********************************************************************************************************/
  /*
  -- 14.May.2013 -- P.2. CREATE_INDEXES
  PROCEDURE CREATE_INDEXES(pi_tables_id in NUMBER, po_log_msg OUT CLOB);
  */
  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : RENAME_INDEX
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Index Name, unique id (Rownum of the index from DELETE_INDEXES SP) ,process_id and run id
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Renames the index to IDX_<unique id>_<process id>_<run id>
  *                     and any constraint associated with it to CON_<unique id>_<process id>_<run id>
  * Example           :
                        BEGIN
                          COMMONS_TABLES.RENAME_INDEX(PK_T3126,1,123456,45678);
                        END;

   Renames the index PK_T3126 to IDX_1_123456_45678 and
   constraint associated with  PK_T3126 to CON_1_123456_45678
  *********************************************************************************************************************/
  /*
  -- 14.May.2013 -- P.3. RENAME_INDEX
  PROCEDURE RENAME_INDEX(pi_index_name in VARCHAR2,
                         pi_unique_id  in NUMBER DEFAULT null,
                         pi_process_id in NUMBER DEFAULT null,
                         pi_run_id     in NUMBER DEFAULT null);
  */
  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DELETE_INDEXES
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, process_id and run id
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Renames the indexes to <index_name>_BKP  and any constraint associated with it to <constraint_name>_BKP
  * Example           :
                        BEGIN
                          COMMONS_TABLES.DELETE_INDEXES(3126);
                        END;

   Renames the indexes of table T3126 by calling RENAME_INDEX procedure
  *********************************************************************************************************************/
  /*
  -- 14.May.2013 -- P.4. DELETE_INDEXES
  PROCEDURE DELETE_INDEXES(pi_tables_id  in NUMBER,
                           pi_process_id in NUMBER DEFAULT null,
                           pi_run_id     in NUMBER DEFAULT null,
                           po_log_msg    OUT CLOB);
  */
  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : UPDATE_INDEXES
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, process_id and run id
  * OUTPUT PARAMETERS : po_log_msg
  * DESCRIPTION       : Updates the indexes
  * Example           :
                        BEGIN
                          COMMONS_TABLES.UPDATE_INDEXES(3126, po_log_msg);
                        END;

  If TABLE T3126 has an additional entity column which is added after creating the table, this column is indexed.
  Same applies for TUPR  columns.
  If key columns are no longer valid, the concatenated index already present on the previous key columns is dropped
  and new index is created for the new key columns.
  *********************************************************************************************************************/
  /*
  -- 14.May.2013 -- P.5. UPDATE_INDEXES
  PROCEDURE UPDATE_INDEXES(pi_tables_id  in NUMBER,
                           pi_process_id in NUMBER DEFAULT null,
                           pi_run_id     in NUMBER DEFAULT null,
                           po_log_msg    OUT CLOB);
  */

  -- Author     : Kristo, Robert
  -- Description: used in CLEANUP_DBA_QUERIES job to periodically cleanup the TABLE_DBA_QUERIES table
  -----**************************************************************************************------------------------
  PROCEDURE CLEANUP_DBA_QUERIES;

  -- Author     : Lazarescu, Bogdan
  -- Updated by : Kristo, Robert
  -- Description: return sys_refcursor for the query send as parameters
  /*
    PARAMETER LIST:
    pin_query          CLOB                            - the full query without the order by clause
    pin_where_clause_vals      coltype_NAME_VALUE      - bind variable - value pair for filtering confition
    pin_orderby_clause         varchar2,               - order by clause used for ordering in page and for paging

                      ex:
                           ORDER BY specified: -> (no) -> "TAB.ROW_IDENTIFIER ASC"
                                               -> (yes)-> are columns from order by unique? -> (no) -> is field nullable? -> (no) -> field name ASC/DESC
                                                                                                                          -> (yes)-> field name ASC/DESC NULLS FIRST/LAST
                                                                                            -> (yes)-> is field nullable? -> (no) -> field name ASC/DESC + ", TAB.ROW_IDENTIFIER ASC"
                                                                                                                          -> (yes)-> field name ASC/DESC NULLS FIRST/LAST + ", TAB.ROW_IDENTIFIER ASC"


    pin_object_id              number                  - object id of the query if supposed to be persisted
    pin_object_type            number                  - object tyoe of the view if supposed to be persisted
    pin_select_rowstartindex   number                  - 0 if last page
    pin_page_size              number                  - page size - number of returned records
    pin_lastpage_flag          number                  - 1 if last page
    pout_result                out sys_refcursor       - object to return as output
    pout_sql_id                out varchar2            - the sql_id which is computed using compute_sql_id function
    pout_exec_plan_enabled     out varchar2            - the value of the property COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('VIEWS_EXEC_PLAN_ENABLED')
  call:
      declare c sys_refcursor; d varchar2(13); e varchar2(30);
      begin
        commons_tables.GET_DATA_FROM_QUERY(
        pin_query => ' T123.F1 AS COL_4712, T123.F2 AS Fdoi, T123.ROW_IDENTIFIER, T123.ROW_VERSION FROM T123'
        , pin_where_clause_vals => null
        , pin_orderby_clause => ' TAB.ROW_IDENTIFIER ASC'
        , pin_object_id => NULL
        , pin_select_rowstartindex => 1
        , pin_page_size => 6
        , pin_lastpage_flag => 1
        , pout_result => c
        , pout_sql_id => d
        , pout_exec_plan_enabled => e);
      end;
    */
  -----**************************************************************************************------------------------
  PROCEDURE GET_DATA_FROM_QUERY(pin_query                CLOB,
                                pin_where_clause_vals    coltype_NAME_VALUE,
                                pin_orderby_clause       VARCHAR2,
                                pin_object_id            NUMBER,
                                pin_select_rowstartindex NUMBER --0 IF LAST PAGE
                               ,
                                pin_page_size            NUMBER,
                                pin_lastpage_flag        NUMBER,

                                pout_result            IN OUT SYS_REFCURSOR,
                                pout_sql_id            IN OUT VARCHAR2,
                                pout_exec_plan_enabled IN OUT VARCHAR2);

  -- Author     : Lazarescu, Bogdan
  -- Updated by : Kristo, Robert
  -- Description: return sys_refcursor for the query send as parameters
  /*
    PARAMETER LIST:
    pin_query          CLOB                            - the full query without the order by clause
    pin_where_clause_vals      coltype_NAME_VALUE      - bind variable - value pair for filtering confition
    pin_orderby_clause         varchar2,               - order by clause used for ordering in page and for paging

                      ex:
                           ORDER BY specified: -> (no) -> "TAB.ROW_IDENTIFIER ASC"
                                               -> (yes)-> are columns from order by unique? -> (no) -> is field nullable? -> (no) -> field name ASC/DESC
                                                                                                                          -> (yes)-> field name ASC/DESC NULLS FIRST/LAST
                                                                                            -> (yes)-> is field nullable? -> (no) -> field name ASC/DESC + ", TAB.ROW_IDENTIFIER ASC"
                                                                                                                          -> (yes)-> field name ASC/DESC NULLS FIRST/LAST + ", TAB.ROW_IDENTIFIER ASC"


    pin_object_id              number                  - object id of the query if supposed to be persisted
    pin_object_type            number                  - object tyoe of the view if supposed to be persisted
    pin_select_rowstartindex   number                  - 0 if last page
    pin_page_size              number                  - page size - number of returned records
    pin_lastpage_flag          number                  - 1 if last page
    pout_result                out sys_refcursor       - object to return as output
    pout_sql_id                out varchar2            - the sql_id which is computed using compute_sql_id function
    pout_exec_plan_enabled     out varchar2            - the value of the property COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('VIEWS_EXEC_PLAN_ENABLED')
  call:
      declare c sys_refcursor; d varchar2(13); e varchar2(30);
      begin
        commons_tables.GET_DATA_FROM_QUERY(
        pin_query => ' T123.F1 AS COL_4712, T123.F2 AS Fdoi, T123.ROW_IDENTIFIER, T123.ROW_VERSION FROM T123'
        , pin_where_clause_vals => null
        , pin_orderby_clause => ' TAB.ROW_IDENTIFIER ASC'
        , pin_object_id => NULL
        , pin_select_rowstartindex => 1
        , pin_page_size => 6
        , pin_lastpage_flag => 1
        , pout_result => c
        , pout_sql_id => d
        , pout_exec_plan_enabled => e);
      end;
    */
  -----**************************************************************************************------------------------
  PROCEDURE GET_DATA_FROM_QUERY(pin_query                CLOB,
                                pin_where_clause_vals    coltype_NAME_VALUE,
                                pin_orderby_clause       VARCHAR2,
                                pin_object_id            NUMBER,
                                pin_select_rowstartindex NUMBER --0 IF LAST PAGE
                               ,
                                pin_page_size            NUMBER,
                                pin_lastpage_flag        NUMBER,
                                pin_dba_hints            TABLETYPE_ID_HINT,

                                pout_result            OUT SYS_REFCURSOR,
                                pout_sql_id            OUT VARCHAR2,
                                pout_exec_plan_enabled OUT VARCHAR2);

  -- Author     : Kristo, Robert
  -- Updated by : Kristo, Robert
  -- Description: save the execution plan of the last executed data view
  /*
    --  Input Parameters:
    --    pin_where_clause_vals         The list of bind variables used in the query
    --    pin_object_id             ID of the view to be displayed in order to activate catching feature

    -----------------------------------------------------------------------------------------
    -- Output :
    -----------------------------------------------------------------------------------------
    -- Return :
    ----------------------------------------------------------------------------------------
    /*
    -- Example :
        DECLARE
    v_temp NUMBER(10);
  BEGIN
    SELECT 1
    INTO v_temp
    FROM dual;

    COMMONS_TABLES.SAVE_EXEC_PLAN(pin_where_clause_vals => coltype_NAME_VALUE(RTYPE_NAME_VALUE(':qpv1','23'), RTYPE_NAME_VALUE(':qpv1','46')),
           pin_object_id             => 1);

  END;
  */
  -----**************************************************************************************------------------------
  /*PROCEDURE SAVE_EXEC_PLAN(pin_where_clause_vals IN coltype_NAME_VALUE,
  pin_object_id         IN NUMBER,
  pin_differntiator     IN NUMBER,
  pi_sql_id             IN VARCHAR2,
  pi_child_number       IN NUMBER);*/

  -----**************************************************************************************------------------------
  PROCEDURE SAVE_EXEC_PLAN(pin_where_clause_vals IN coltype_NAME_VALUE,
                           pin_object_id         IN NUMBER);

  -----**************************************************************************************------------------------
  -- Author     : Kristo, Robert
  -- Updated by : Kristo, Robert
  -- Description: the procedure which will call all the other SPs which will save the view stats
  /*
    --  Input Parameters:
    --    pin_where_clause_vals     The list of bind variables used in the query
    --    pin_object_id             ID of the view to be displayed in order to activate catching feature
    --    pin_tdq_sql_id            The sql_id calculated for the TABLE_DBA_QUERIES table
    --    pin_elapsed_time          The Java fetch elapsed time

    -----------------------------------------------------------------------------------------
    -- Output :
    -----------------------------------------------------------------------------------------
    -- Return :
    ----------------------------------------------------------------------------------------
    /*
    -- Example :
  BEGIN

    COMMONS_TABLES.SAVE_STATS(pin_where_clause_vals => coltype_NAME_VALUE(RTYPE_NAME_VALUE(':qpv1','23'), RTYPE_NAME_VALUE(':qpv1','46')),
                              pin_object_id         => 1646856,
                              pin_tdq_sql_id        => '1w3rge4te23re',
                              pin_elapsed_time      => 112);

  END;
  */
  PROCEDURE SAVE_STATS(pin_where_clause_vals IN coltype_NAME_VALUE,
                       pin_object_id         IN NUMBER,
                       pin_tdq_sql_id        IN VARCHAR2,
                       pin_elapsed_time      IN NUMBER);

  -- *******************************    PUBLIC PROCEDURES END         *******************************

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : CREATE_UNIQUE_INDEXES
  * AUTHOR            : Sagar Thorat
  * REVIEWER          :
  * INPUT PARAMETERS  : Tables_id
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Creates the indexes on Key fields and/or E_INTERNAL_ID column
  * Example           :
                        BEGIN
                          COMMONS_TABLES.CREATE_UNIQUE_INDEXES(3126);
                        END;

  Creates  T3126_BUSINESSKEY_UI on key fields
  *********************************************************************************************************************/

  /*
  -- 14.May.2013 -- P.6. CREATE_UNIQUE_INDEXES
  =======


    PROCEDURE CREATE_UNIQUE_INDEXES(pi_tables_id in NUMBER);
  */
  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : GET_SET_AUTO_VALUE
  * AUTHOR            : Rahul Sachan
  * CREATE_DATE       : 12-Feb-2013
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : PI_TABLE_ID,PI_OFFSET_VAL
  * OUTPUT PARAMETERS : PO_AV_RANGE_WITH_TS sys ref cursor.
  * DESCRIPTION       : Table id and offset is passed to get the range of auto_values along with the timestamp.
                        And this proc call will update the new AV_NEXT_VAL and timestamp in AUTO_VALUE table corresponding to table_id.
  * Example           :
                        BEGIN
                          COMMONS_TABLES.GET_SET_AUTO_VALUE(PI_TABLE_ID => 1234,PI_OFFSET_VAL => 5,:cur);
                        END;

   Cur will return upper and lower bound of auto_values(MIN and MAX) depending upon AV_NEXT_VAL set against the
   table_id 1234 with range as 5,along with the current timestamp.
  *********************************************************************************************************************/
  procedure GET_SET_AUTO_VALUE(PI_TABLE_ID         in number,
                               PI_OFFSET_VAL       IN NUMBER,
                               PO_AV_RANGE_WITH_TS OUT SYS_REFCURSOR);

  /********************************************************************************************************************
   * TYPE              : PROCEDURE
   * PROCEDURE NAME    : DELETE_ENTITY_CHECK
   * AUTHOR            : Rahul Sachan
   * REVIEWER          : Pooja Sharma
   * INPUT PARAMETERS  : pi_Entity_IDs, pi_Ent_Del_Run_Param_ID and pi_Entity_Usage_Table_Name
   * OUTPUT PARAMETERS : None
   * DESCRIPTION       : This proc takes list entity ids (comma separated string) and the run paramter id for the delete entity process,
   *                     and the table name (predefined structure) which will be populated with the entity usage across other objects.
   * EXAMPLE           :
                        Begin
                           Commons_tables. Delete_Entity_check
                           (pi_Entity_IDs            => 'E1,E2,E3',
                            pi_Ent_Del_Run_Param_ID   => 7,
                            pi_Entity_Usage_Table_Name => 'entity_delete_<run_id> table name'
                           )
                        End;

                        Table struture which will be populated with entity usage result
                        Entity_Delete_<run_id>
                               ( cr_definition_id number ,
                                 e_internal_id number) ;

  *********************************************************************************************************************/

  PROCEDURE Delete_Entity_Check(pi_Entity_IDs              VARCHAR2,
                                pi_Ent_Del_Run_Param_ID    NUMBER,
                                pi_Entity_Usage_Table_Name VARCHAR2,
                                pi_intl_Col_name           VARCHAR2,
                                pi_TempUsage_Table_Name    VARCHAR2);

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : entity_assignment_validation
  * AUTHOR            : Snehal Pasalkar
  * CREATE_DATE       : 05-jan-2015
  * REVIEWER          : rohit maxim, pramod garkar
  * INPUT PARAMETERS  : pi_table_name,pi_ea_entity_id_ra_list,
  * OUTPUT PARAMETERS : po_status number.
  * DESCRIPTION       : Table name and list of secodary enitities will passed to find out whether is there any record in table where all secodary entities are null

   if record with all nulls in secodary entities exists then it will return 0, otherwise it will return 1
  *********************************************************************************************************************/

  PROCEDURE all_null_col_check(pi_table_name           IN varchar2,
                               pi_ea_entity_id_ra_list IN COL_LIST_30,
                               po_status               OUT number);
  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : all_null_col_records
    * AUTHOR            : Snehal Pasalkar
    * CREATE_DATE       : 08-jan-2015
    * REVIEWER          : rohit maxim, pramod garkar
    * INPUT PARAMETERS  : pi_table_name,pi_return_col_list,pi_ea_entity_id_ra_list
    * OUTPUT PARAMETERS : po_null_col_rec
    * DESCRIPTION       : Table name ,list of columns which are to be returned and list of secodary enitities will passed to find out whether is there any record in table where all secodary entities are null

    If such records are present then all those records will be returned.
  *********************************************************************************************************************/

  procedure all_null_col_records(pi_table_name           IN varchar2,
                                 pi_return_col_list      IN COL_LIST_30,
                                 pi_ea_entity_id_ra_list IN COL_LIST_30,
                                 po_null_col_rec         OUT sys_refcursor);

  FUNCTION index_column_expression_char(tab_name     VARCHAR2,
                                        ind_name     VARCHAR2,
                                        col_position NUMBER) RETURN VARCHAR2;

  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : INPUT_CARDINALITY
    * AUTHOR            : Robert Kristo
    * CREATE_DATE       : 08-nov-2016
    * REVIEWER          :
    * INPUT PARAMETERS  : pin_input_table_name   - the input table
    *                     pin_full_sql           - the sql used for count
    *                     pin_input_threshold    - the input cardinality threshold
    *                     pin_sql_threshold      - the count cardinality threshold
    * RETURN PARAMETER  : pout_cardinality_threshold - if the threshold is exceeded
    * DESCRIPTION       : Query used to calculate the cardinality for TOTALS query. This procedure will return the estimated cardinality of the input table
    * CALL EXAMPLE      :

    DECLARE
       v_input_cardinality NUMBER;
    BEGIN
       v_input_cardinality := INPUT_CARDINALITY(pin_input_table_name   => 'T123');

       dbms_output.put_line(v_input_cardinality);
    END;
  *********************************************************************************************************************/
  PROCEDURE SQL_INPUT_CARDINALITY(pin_input_table_name IN VARCHAR2,
                                  pin_full_sql         IN CLOB,
                                  pin_input_threshold  IN NUMBER,
                                  pin_sql_threshold    IN NUMBER,

                                  pout_cardinality_threshold OUT NUMBER);

/********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : UPDATE_ORDER_ID
    * AUTHOR            : Hardika Bhate
    * CREATE_DATE       : 17-May-2016
    * REVIEWER          : rohit maxim
    * INPUT PARAMETERS  : sql_id, child_number
    * OUTPUT PARAMETERS : null
    * DESCRIPTION       : save order_id, projection and filter_predicates if execution stats are gathered earlier

  *********************************************************************************************************************/

/*PROCEDURE UPDATE_ORDER_ID(PI_SQL_ID       IN VARCHAR2,
                            PI_CHILD_NUMBER IN NUMBER);*/

END COMMONS_TABLES;
/
