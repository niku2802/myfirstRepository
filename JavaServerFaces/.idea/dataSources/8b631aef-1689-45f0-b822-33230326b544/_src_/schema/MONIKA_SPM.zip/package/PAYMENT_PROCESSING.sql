CREATE PACKAGE PAYMENT_PROCESSING AS
-- -----------------------------------------------------------------------------
-- Copyright ? 2010-2011, SPM Software LP. All rights reserved.
-- This program belongs to SPM Software LP.  It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from SPM Software LP.
-- ---------------------------------------------------------------------------
-- Database Type  : SPM
-- Product    :   COMPENSATION
-- Module    :  COMPENSATION-PROCESSING
-- Requester    :  Creoleanu, Irina
-- Author    :  Lazarescu, Bogdan
-- Reviewer    :  Lazar, Lucian
-- Review date    :  20110624
-- Description    :  package used to handle all operations for payment processing
-- ---------------------------------------------------------------------------
    -- *******************************    PUBLIC TYPES START       *******************************
    -- *******************************    PUBLIC TYPES END         *******************************

    -- *******************************    PUBLIC CURSORS START       *******************************
    -- *******************************    PUBLIC CURSORS END         *******************************

    -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
    -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

    -- *******************************    PUBLIC FUNCTIONS START       *******************************
    -- *******************************    PUBLIC FUNCTIONS END         *******************************

    -- *******************************    PUBLIC PROCEDURES START       *******************************

  PROCEDURE CALCULATE_PAYMENT(PIN_INPUT_LIST               IN  TABLETYPE_INPUT_TABLE_LIST,
                              PIN_COMP_PRIOR_PERIOD_LIST   IN  TABLETYPE_COMP_PERIOD_LIST,
                              PIN_CURRENT_PERIOD           IN  NUMERIC,
                              PIN_CURRENT_PERIOD_COLUMN    IN  VARCHAR2,
                              PIN_PROJECTED_PERIOD         IN  NUMERIC,
                              PIN_PROJECTED_PERIOD_COLUMN  IN  VARCHAR2,
                              PIN_PROJECTED                IN  NUMBER,
                              PIN_PRIOR_PERIOD_IDS         IN  VARCHAR2,
                              PIN_EARN_ENTITY_COLUMN       IN  VARCHAR2,
                              PIN_PAY_ENTITY_COLUMN        IN  VARCHAR2,
                              PIN_PAY_ATTRIBUTE_COLUMNS    IN  VARCHAR2,
                              PIN_ADD_ATTRIBUTE_COLUMNS    IN  VARCHAR2,
                              PIN_APPLY_DRAWS              IN  NUMBER,
                              PIN_CONSTANT_DRAW            IN  NUMBER,
                              PIN_RECOVERABLE_PRIOR_PERIOD IN  NUMBER,
                              PIN_ENTITY_KEY               IN  VARCHAR2,
                              PIN_VER_OBJECT_ID            IN  NUMBER,
                              PIN_0_PAYMENT                IN  NUMBER,
							  PIN_ROSTER_BY_COMPONENT	   IN  NUMBER,
                              PIN_VLD_WHEN                 IN  CLOB,
                              PIN_VLD_SELECT               IN  CLOB,
                              PIN_VLD_FROM                 IN  CLOB,
                              PIN_VLD_GET_VALUES           IN  CLOB,
                              POUT_VLD_RESULT              OUT SYS_REFCURSOR,
                              POUT_ROWS_IN_OUTPUT          OUT NUMBER);

    -- *******************************    PUBLIC PROCEDURES END         *******************************
END PAYMENT_PROCESSING;
/
