CREATE PACKAGE BODY COMMONS_TABLES AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : commons-tables
  -- Requester      : Homeuca, Victor
  -- Authors        : Hrubaru, Ionut; Rohit, Maxim; Popescu, Mircea; Homeuca, Victor; Sharma, Pooja
  -- Create date    : 20110415
  -- Reviewer       : Homeuca, Victor
  -- Review date    : 20110415
  -- Description    : package used to handle all operations for data tables
  -- Change Date    : 20110428 - by Ionut - last page needs to calculate a total count (page number is needed to be displayed in the UI)
  -- Change Date    : 20110526 - by Victor - fixed 859 and 871 in Multi_Edit_Upsert
  -- Change Date    : 20110603 - by Victor - fixed 1004 in Adjustment_Unique_Check
  -- Change Date    : 20110622 - by Victor - fixed 1194 in Multi_Edit_Upsert
  -- Change Date    : 20110727 - by Johnny - changed GET_ST_DATA (period_fields parameter is now an array containing the column names and aliases for tables)
  -- Change Date    : 20120217 - by Victor - change in Multi_Edit_Upsert to add support for Custom Views Adjustments
  --                     - added Resultset_Merge_Fields function
  -- Change Date    : 20120313 - by Mircea - Added the Hierarchy tables validations functions
  -- Change Date    : 20120315 - by Mircea - Fix for defect #5580 - In hierarchy overlap check SP check only records with different upper entities or duplicate ones
  --                                                                to avoid comparison of one record with itself
  -- Change Date    : 20120320 - by Mircea - Fix for defect #5642 - In hierarchy table validation function use "greater than or equal" instead of "greater than" to link nodes
  --                                                                when the hierarchy is effective for a range of dates or periods.
  -- Change Date    : 20120321 - by Mircea - Fix for defect #5812 - Do left join with TU_PERIODS_RANGE table when creating the hierarchy query. Use NVL when creating the CONNECT BY
  --                                                                clause (when the hierarchy is effective by a range of dates or periods)
  -- Change Date    : 20120509 - by Mircea - Fix for defect #6553 - Changed the datatype of variables in Get_ST_Data function from VARCHAR2(32767) to CLOB
  -- Change Date    : 20120524 - by Mircea - Last page optimization - First, get the list of row_identifiers that need to be displaied on last page and then create the last page
  -- Change Date    : 20120704 - by Mircea - Fix for defect #2302 - Use rownum instead of analytic (in Get_ST_data) in case of intermediary pages
  -- Change Date    : 20110622 - by Victor - Multi_Edit_Upsert - Changes for Audit: we return table-generated row_identifiers in `pout_list_of_inserted_ids` for the inserted rows.
  -- Change Date    : 14.May.2013 - by Vijaywargiya, Abhishek - Remove redundant procedures from Commons_Tables package, since their latest version exists in Commons_Indexing package.
  -- Change Date    : 20140226 - by Elena Banea - OF-10027: Modified Adjustment_Unique_Check as follows: Removed FTS for pin_table_name,removed decode from conditions,
  --                                              removed all useless CLOB variables

  -- Author         : Hrubaru, Ionut
  -- Reviewer       : Homeuca, Victor Stefan
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START        *******************************
  PROCEDURE ALTER_SESSION_NLS_BINARY IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''BINARY''';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''BINARY''';
  END ALTER_SESSION_NLS_BINARY;

  PROCEDURE ALTER_SESSION_PROJ_NLS_SETTING IS
    V_NLS_SORT VARCHAR2(160 CHAR);
    V_NLS_COMP VARCHAR2(160 CHAR);
  BEGIN
    SELECT NVL(MAX(VALUE), 'LINGUISTIC')
      INTO V_NLS_COMP
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_COMP';

    SELECT NVL(MAX(VALUE), 'BINARY_CI')
      INTO V_NLS_SORT
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_SORT';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''' || V_NLS_COMP || '''';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''' || V_NLS_SORT || '''';
  END ALTER_SESSION_PROJ_NLS_SETTING;

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START         *******************************
  function NVL_CHECK(v_col_name varchar2, v_data_type number) return varchar2 is
    nvl_value varchar2(4000);
  begin

    if v_data_type in (1, 4) THEN
      nvl_value := ' NVL(UPPER(a.' || v_COL_NAME ||
                   '), CHR(0))= NVL(UPPER(b.' || v_COL_NAME ||
                   '), CHR(0)) ';

      --end of addition by pramod
    elsif v_data_type in (2, 6, 8) THEN
      nvl_value := ' NVL(a.' || v_COL_NAME || ', 1E38)= NVL(b.' ||
                   v_COL_NAME || ', 1E38) ';

    elsif v_data_type in (3) THEN
      nvl_value := ' NVL(a.' || v_COL_NAME ||
                   ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD''))= NVL(b.' ||
                   v_COL_NAME ||
                   ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD'')) ';

    elsif v_data_type = (5) THEN
      nvl_value := ' NVL(a.' || v_COL_NAME ||
                   ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD''))= NVL(b.' ||
                   v_COL_NAME ||
                   ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD'')) ';

    ELSE
      nvl_value := '((a.' || v_COL_NAME || '= b.' || v_COL_NAME ||
                   ') or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                   v_COL_NAME || ' IS NULL ) )';
    END if;

    return nvl_value;
  end NVL_CHECK;

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END       *******************************
  FUNCTION COMMA_TO_TABLE(pi_col_list in varchar2) return SYS.Hsblknamlst as
    v_str            varchar2(32767) default pi_col_list || ',';
    v_col_collection SYS.Hsblknamlst := SYS.Hsblknamlst();
    v_comma_count    number;
  begin
    loop
      exit when v_str is null;
      v_comma_count := instr(v_str, ',');
      v_col_collection.extend;
      v_col_collection(v_col_collection.count) := ltrim(rtrim(substr(v_str,
                                                                     1,
                                                                     v_comma_count - 1)));
      v_str := substr(v_str, v_comma_count + 1);
    end loop;

    return v_col_collection;
  end COMMA_TO_TABLE;

  FUNCTION UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME  IN VARCHAR2,
                                   PI_COL_LIST    IN VARCHAR2,
                                   PI_CLAUSE_TYPE IN NUMBER DEFAULT 1) --1. PROJECTION (Select clause (not to be used in posting records)) or GROUPING or PARTITION BY --2. IN CLAUSE as data,
   RETURN VARCHAR2 IS
    --v_table_name      VARCHAR2(30);
    v_return_col_list VARCHAR2(32767) := '';

    TYPE RECTYPE_COL_DATATYPE IS RECORD(
      COL_POSITION NUMBER,
      COLUMN_NAME  VARCHAR2(30),
      DATA_TYPE    VARCHAR2(106));

    TYPE COLTYPE_COL_DATATYPE IS TABLE OF RECTYPE_COL_DATATYPE;

    V_COL_DATATYPE COLTYPE_COL_DATATYPE := COLTYPE_COL_DATATYPE();
    V_PR_VALUE     varchar2(20);
  BEGIN
    SELECT nvl(max(PR_VALUE), 'SPM')
      INTO V_PR_VALUE
      FROM PROPERTIES
     WHERE PR_NAME = 'ENV_NAME';
    --Sagar
    --insert_logs(PI_CLOB => 'UPPER_VARCHAR2_COL_LIST called');

    -- Tune the below code in a single query
    -- Try using Variable in dynamic sql to replace comma_to_table
    if V_PR_VALUE = 'SPM' then
      execute immediate 'SELECT ROWNUM, TC.TC_PHYSICAL_NAME COLUMN_NAME, F.FLD_DATA_TYPE
        FROM TABLE_COLUMNS TC
       INNER JOIN TABLES T
          ON T.TABLES_ID = TC.TC_TABLES_ID
        LEFT JOIN FIELDS F
          ON TC.TC_FLD_ID = F.FLD_ID
       where T.TABLES_PHYSICAL_NAME = UPPER(''' ||
                        PI_TABLE_NAME || ''')
         and TC.TC_PHYSICAL_NAME IN
             (SELECT *
                FROM TABLE (select commons_tables.COMMA_TO_TABLE(:1) from dual))' BULK
                        COLLECT
        INTO V_COL_DATATYPE
        using PI_COL_LIST;
    end if;
    IF V_COL_DATATYPE.COUNT = 0 THEN

      --Sagar
      --insert_logs(PI_CLOB => 'No data in TABLE_COLUMNS table. Will use USER_TAB_COLUMNS');
      SELECT ROWNUM, utc.COLUMN_NAME, utc.data_type
        BULK COLLECT
        INTO V_COL_DATATYPE
        FROM USER_TAB_COLUMNS UTC
       where utc.table_name = UPPER(PI_TABLE_NAME)
         and utc.COLUMN_NAME IN
             (SELECT *
                FROM TABLE (select COMMA_TO_TABLE(PI_COL_LIST) from dual));
    END IF;

    IF V_COL_DATATYPE.COUNT != 0 THEN
      FOR C IN V_COL_DATATYPE.FIRST .. V_COL_DATATYPE.LAST LOOP

        IF V_COL_DATATYPE(C).DATA_TYPE in ('1', '4', 'VARCHAR2') THEN
          IF PI_CLAUSE_TYPE = 1 THEN
            v_return_col_list := v_return_col_list || ',UPPER(' || V_COL_DATATYPE(C)
                                .column_name || ')';
          ELSE
            v_return_col_list := v_return_col_list || ',UPPER(''' || V_COL_DATATYPE(C)
                                .column_name || ''')';
          END IF;
          --DBMS_OUTPUT.put_line(v_return_col_list);
        ELSE
          IF PI_CLAUSE_TYPE = 1 THEN
            v_return_col_list := v_return_col_list || ',' || V_COL_DATATYPE(C)
                                .column_name || '';
          ELSE
            v_return_col_list := v_return_col_list || ',''' || V_COL_DATATYPE(C)
                                .column_name || '''';
          END IF;
          --DBMS_OUTPUT.put_line(v_return_col_list);
        END IF;
      END LOOP;
    END IF;

    v_return_col_list := SUBSTR(v_return_col_list,
                                2,
                                LENGTH(v_return_col_list));

    RETURN v_return_col_list;
  end UPPER_VARCHAR2_COL_LIST;

  FUNCTION Get_ST_Data(table_name           VARCHAR2,
                       column_names         VARCHAR2,
                       period_fields        TABLETYPE_NAME_MAP,
                       where_clause         VARCHAR2 DEFAULT ' ',
                       orderby_clause       VARCHAR2,
                       select_rowstartindex NUMBER, --0 if last page
                       page_size            NUMBER,
                       lastpage_flag        NUMBER,
                       count_flag           NUMBER DEFAULT 0)
    RETURN SYS_REFCURSOR
  -- Assumptions:
    -- Input Parameters are built using valid column names
    -- when WHERE_CLAUSE parameter is passed it should have "WHERE" clause in it.
    -- when ORDERBY_CLAUSE parameter is passed it should have "ORDER" clause in it.
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    TABLE_NAME                Standard Table name from where to select records
    --    COLUMN_NAMES              List of column names from table specified in TABLE_NAME parameter
    --    PERIOD_FIELDS             List of column names from table representing period fields. It is an array containing elements like ('F1','TPR1'), ('F2','TPR2')
    --                              where TPR1,TPR2 are aliases for each TU_PERIODS_RANGE instance used in joins
    --    WHERE_CLAUSE              Filter clause
    --    ORDERBY_CLAUSE            Order by clause
    --    SELECT_ROWSTARTINDEX      start position used to return rows (0 if last page, 1 if first page, >=1 for any other page)
    --    PAGE_SIZE                 100/250/500...
    --    LASTPAGE_FLAG             1 - last page
    --    COUNT_FLAG                0 - returns normal resultset, 1 - returns record count of final resultset
    -----------------------------------------------------------------------------------------
    -- Output : None
    -----------------------------------------------------------------------------------------
    -- Return : CURSOR having columns specified in COLUMN_NAMES parameter
    ----------------------------------------------------------------------------------------
    /*
    -- Example : 1 - "first page" .
    SELECT Get_ST_Data ('T166264_1900_1 TAB', 'TAB.F120903,TAB.F121918,TAB.ROW_ID', TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F345','TPR1'))
    , 'TAB.F120903 IS NOT NULL','TAB.F121918 DESC',1,250, 0,0 ) from dual;
    */
   IS
    c                       SYS_REFCURSOR;
    cnt                     NUMBER;
    select_clause           CLOB;
    select_rowendindex      NUMBER;
    strsql                  CLOB;
    orderby_clause_new      CLOB;
    orderby_clause_reversed CLOB;
    hidden_cols             CLOB := ',TAB.ROW_IDENTIFIER ASC'; --,ROW_VERSION
    table_name_final        CLOB;
    period_join_condition   CLOB;
    period_columns          CLOB;
    period_select_columns   CLOB;
    start_date_join         CLOB;
    start_date_col          CLOB;
    orderby_column          CLOB;
    t_table_name            CLOB;
    order_type              CLOB;
    v_pagination_filter1    CLOB;
    v_pagination_filter2    CLOB;
    v_where_clause          CLOB;
    v_lp_row_identifiers    VARCHAR2(32767);
    v_lp_listagg            VARCHAR2(32767);
    v_row_count             PLS_INTEGER;
  BEGIN
    IF where_clause IS NOT NULL THEN
      v_where_clause := ' WHERE ' || where_clause;
    END IF;

    orderby_column := TRIM(REPLACE(REPLACE(UPPER(orderby_clause), 'ASC', ''),
                                   'DESC',
                                   ''));
    order_type     := TRIM(REPLACE(orderby_clause, orderby_column, ''));
    t_table_name   := SUBSTR(table_name, 1, INSTR(table_name, ' '));

    IF count_flag = 0 THEN
      select_clause := ' SELECT * ';
    ELSE
      select_clause := ' SELECT COUNT(1) AS record_count ';
    END IF;

    IF lastpage_flag = 1 THEN
      select_rowendindex := page_size;
    ELSE
      select_rowendindex := select_rowstartindex + page_size;
    END IF;

    --in case order by is null remove the comma from , ROW_IDENTIFIER, ROW_VERSION
    IF orderby_clause IS NULL THEN
      hidden_cols := SUBSTR(hidden_cols, 2, LENGTH(hidden_cols));
    ELSE
      hidden_cols := hidden_cols;
    END IF;

    --check if period_fields is NULL and build preiod_columns and period_join_condition appropiately
    IF period_fields IS NOT NULL THEN
      BEGIN
        FOR i IN 1 .. period_fields.COUNT LOOP
          period_join_condition := period_join_condition ||
                                   ' LEFT JOIN TU_PERIODS_RANGE ' || period_fields(i)
                                  .NAME2 || '
                         ON ' || period_fields(i)
                                  .NAME2 || '.TUPR_ID' || '=' || period_fields(i)
                                  .NAME1;
          period_columns        := period_columns || ',' || period_fields(i)
                                  .NAME2 || '.TUPR_TUP_ID AS ' || period_fields(i)
                                  .NAME2 || '_TUPR_TUP_ID,' || period_fields(i)
                                  .NAME2 || '.TUPR_YEAR AS ' || period_fields(i)
                                  .NAME2 || '_TUPR_YEAR ';

          --find the alias for the order by column
          IF SUBSTR(period_fields(i).NAME1,
                    INSTR(period_fields(i).NAME1, '.') + 1) =
             orderby_column THEN
            --we can have only one period field in the order clause
            orderby_clause_new := ' order by ' || period_fields(i).NAME2 ||
                                  '.TUPR_START_DATE ' || order_type;
            period_columns     := period_columns || ',' || period_fields(i)
                                 .NAME2 || '.TUPR_START_DATE ';
          END IF;
        END LOOP;
      END;

      IF column_names IS NULL THEN
        period_columns := SUBSTR(period_columns, 2, LENGTH(period_columns));
      END IF;
    END IF;

    IF orderby_clause_new IS NULL THEN
      --this means that the period filtering did not exist
      orderby_clause_new := ' order by ' || orderby_clause;
    END IF;

    IF order_type = 'ASC' THEN
      orderby_clause_new := orderby_clause_new || ' NULLS FIRST ';
    ELSIF order_type = 'DESC' THEN
      orderby_clause_new := orderby_clause_new || ' NULLS LAST ';
    END IF;

    orderby_clause_new      := orderby_clause_new || hidden_cols;
    orderby_clause_reversed := REPLACE(REPLACE(REPLACE(UPPER(orderby_clause_new),
                                                       'ASC',
                                                       'DESTEMP'),
                                               'DESC',
                                               'ASC'),
                                       'DESTEMP',
                                       'DESC');

    orderby_clause_reversed := REPLACE(REPLACE(REPLACE(UPPER(orderby_clause_reversed),
                                                       'FIRST',
                                                       'DESTEMP'),
                                               'LAST',
                                               'FIRST'),
                                       'DESTEMP',
                                       'LAST');

    --if page size is null then we need to return all the data from the input table
    IF page_Size IS NOT NULL THEN
      /*        v_pagination_filter := '';
      else*/
      v_pagination_filter1 := 'where rownum <= ' ||
                              TO_CHAR(select_rowendindex);
      v_pagination_filter2 := 'where rowno >= ' ||
                              TO_CHAR(select_rowstartindex);
    END IF;

    IF count_flag = 0 THEN
      IF lastpage_flag = 0 THEN
        -- in case of intermediary page
        strsql := select_clause || 'from (select tab.*,rownum rowno ' ||
                  'from (select /*+ first_rows(' || page_size || ') */ ' ||
                  column_names || period_columns ||
                  ',TAB.ROW_IDENTIFIER,TAB.ROW_VERSION,null as TotalCount ' ||
                  'from ' || table_name || period_join_condition || ' ' ||
                  v_where_clause || orderby_clause_new || ') tab ' ||
                  v_pagination_filter1 || ') tab ' || v_pagination_filter2 ||
                  REGEXP_REPLACE(REGEXP_REPLACE(orderby_clause_new,
                                                '(TPR[0-9]+)',
                                                'TAB'),
                                 '(E[0-9]+)\.',
                                 '\1_');
        /*select_clause || '
                                from (
        select \*+ first_rows(' || page_size || ') *\ ' ||
              column_names || ' ' || period_columns || ',TAB.ROW_IDENTIFIER, TAB.ROW_VERSION, null as TotalCount,row_number() over (' ||orderby_clause_new || ') ROWNO ' ||
        'from ' || table_name || period_join_condition || ' ' || v_where_clause || ') tab ' || v_pagination_filter ||
                          regexp_replace(regexp_replace(orderby_clause_new, '(TPR[0-9]+)', 'TAB'),
                                        '(E[0-9]+)\.',
                                        '\1_');*/
      ELSE
        -- last page case
        -- get row_identifiers of the last page
        BEGIN
          v_lp_listagg := 'SELECT LISTAGG(TAB.ROW_IDENTIFIER,'','') WITHIN GROUP(ORDER BY NULL),ROW_COUNT ' ||
                          'FROM (SELECT COUNT(*) OVER () ROW_COUNT, TAB.ROW_IDENTIFIER ' ||
                          'FROM ' || table_name || period_join_condition || ' ' ||
                          v_where_clause || ' ' || orderby_clause_reversed ||
                          ') TAB ' || 'WHERE ROWNUM <= 1+MOD(ROW_COUNT-1,' ||
                          TO_CHAR(page_size) || ') GROUP BY ROW_COUNT';

          EXECUTE IMMEDIATE v_lp_listagg
            INTO v_lp_row_identifiers, v_row_count;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_lp_row_identifiers := 'NULL';
            v_row_count          := 0;
        END;

        --
        strsql := 'SELECT ' || column_names || ' ' || period_columns ||
                  ',TAB.ROW_IDENTIFIER, TAB.ROW_VERSION, ' ||
                  TO_CHAR(v_row_count) || ' AS TotalCount
                   ' || 'FROM ' || table_name ||
                  period_join_condition || '
                   ' || 'WHERE TAB.ROW_IDENTIFIER IN (' ||
                  v_lp_row_identifiers || ')
                   ' || orderby_clause_new;
      END IF;
    ELSE
      strsql := select_clause || ' from ' || table_name ||
                period_join_condition || ' ' || v_where_clause;
    END IF;

    /*SELECT CASE
           WHEN count_flag = 0 THEN
            CASE
              WHEN lastpage_flag = 0 THEN
               select_clause || '
                      from (
                          select   \*+ first_rows(' ||
               page_size || ') *\ ' || column_names || ' ' ||
               period_columns ||
               ',TAB.ROW_IDENTIFIER, TAB.ROW_VERSION, null as TotalCount
                                   ,row_number() over (' ||orderby_clause_new || ') ROWNO
                          from ' || table_name ||
               period_join_condition || ' ' || v_where_clause || ') tab ' || v_pagination_filter ||
                regexp_replace(regexp_replace(orderby_clause_new, '(TPR[0-9]+)', 'TAB'),
                              '(E[0-9]+)\.',
                              '\1_')
              ELSE
              --its a "last page" call
               select_clause || '
                      FROM ( ' || select_clause || '
                           from (
                              select  \*+ first_rows(' ||
               page_size || ') *\ ' || column_names || ' ' ||
               period_columns ||
               ',TAB.ROW_IDENTIFIER, TAB.ROW_VERSION
                                      ,row_number() over (' ||
                  orderby_clause_reversed ||
               ') ROWNO
                                      , COUNT(*) OVER() AS TotalCount
                              from ' || table_name ||
               period_join_condition || ' ' || v_where_clause || ') tab
                      where rowno <= ' || TO_CHAR(page_size) ||
               ' ) tab where rowno <= 1 + MOD(TotalCount-1,' ||
               TO_CHAR(page_size) || ')' ||
                regexp_replace(regexp_replace(orderby_clause_new, '(TPR[0-9]+)', 'TAB'),
                              '(E[0-9]+)\.',
                              '\1_')

            END
           ELSE
            select_clause || ' from   (select  1
                          from ' || table_name ||
               period_join_condition || ' ' || v_where_clause ||') TAB '
         END
    INTO strsql
    FROM DUAL;*/

    --    DBMS_OUTPUT.PUT_LINE(STRSQL);

    OPEN c FOR strsql;

    RETURN c;
  EXCEPTION
    WHEN OTHERS THEN
      IF (c%ISOPEN) THEN
        CLOSE c;
      END IF;

      raise_application_error(-20001, SUBSTR(SQLERRM, 1, 1000));
  END Get_ST_Data;

  FUNCTION CHECK_REQUIRED_FIELD(PIN_TABLE_NAME IN VARCHAR2,
                                PIN_COLUMNS    IN CLOB) RETURN SYS_REFCURSOR
  -----------------------------------------------------------------------------------------------
    -- Assumptions:
    -- Input Parameters are built using valid table name and column names
    -- Process: Check if PIN_COLUMNS have null values
    -- Input Parameters:
    --    PIN_TABLE_NAME        Standard Table name where to check null records
    --    PIN_COLS              List of column names from table specified in PIN_TABLE_NAME parameter
    -----------------------------------------------------------------------------------------------
    -- Output : None
    -----------------------------------------------------------------------------------------
    -- Return : CURSOR having columns specified in PIN_COLUMNS parameter
    -- Possible values: 1 - column has nulls, 0 - column does not have nulls
    -- Example:    F12                   F13
    --          --------               -------
    --              1                     0
    -----------------------------------------------------------------------------------------------
   IS
    VC_CURSOR SYS_REFCURSOR;
    VC_COLS   CLOB;
    /*    VC_COLS   VARCHAR2(2000);*/
  BEGIN
    --Used UPPER to fix OF-3814 REQUIRED FILED CHECK SP used in data import throws exception with BINARY settings for NLSCOMP and NLSSORT
    -- commons_utils.insert_logs(PIN_TABLE_NAME);
    --  commons_utils.insert_logs(PIN_COLUMNS);
    FOR c IN (SELECT COLUMN_NAME
                FROM USER_TAB_COLS
               WHERE TABLE_NAME = UPPER(PIN_TABLE_NAME)
                    --AND INSTR(UPPER(PIN_COLUMNS), COLUMN_NAME) > 0
                 AND COLUMN_NAME in
                     (SELECT column_value
                      /*    upper(substr(SUBSTR(column_value, 1, LENGTH(column_value) - 1),
                      2)
                              \*upper(column_value*\)*/
                        FROM TABLE (select COMMONS_TABLES.COMMA_TO_TABLE(to_char(upper(substr(SUBSTR(PIN_COLUMNS,
                                                                                                     1,
                                                                                                     LENGTH(PIN_COLUMNS) - 1),
                                                                                              2))))
                                      from dual))

              ) LOOP

      --       commons_utils.insert_logs('inside');
      VC_COLS := VC_COLS || ' NVL2(MIN(' || c.COLUMN_NAME ||
                 ') KEEP (DENSE_RANK LAST ORDER BY ' || c.COLUMN_NAME ||
                 '),0,1) ' || c.COLUMN_NAME || ',';
    END LOOP;

    VC_COLS := SUBSTR(VC_COLS, 1, LENGTH(VC_COLS) - 1);
    --commons_utils.insert_logs(VC_COLS);
    /*SELECT LISTAGG('NVL2(MIN(' || COLUMN_NAME ||
                 ') KEEP (DENSE_RANK LAST ORDER BY ' || COLUMN_NAME ||
                  '),0,1) ' || COLUMN_NAME,
                  ', ') WITHIN GROUP(ORDER BY NULL)
     INTO VC_COLS
     FROM USER_TAB_COLS
    WHERE TABLE_NAME = PIN_TABLE_NAME
      AND INSTR(PIN_COLUMNS, COLUMN_NAME) > 0;*/
    -- commons_utils.insert_logs('SELECT ' || VC_COLS || ' FROM ' || PIN_TABLE_NAME);

    VC_COLS := 'SELECT ' || VC_COLS || ' FROM ' || PIN_TABLE_NAME;

    OPEN VC_CURSOR FOR VC_COLS;

    RETURN VC_CURSOR;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001, SUBSTR(SQLERRM, 1, 1000));
  END CHECK_REQUIRED_FIELD;

  -----------------------------------------------------------------------------------------

  -----------------------------------------------------------------------------------------
  PROCEDURE Adjustment_Delete(PI_Table          IN VARCHAR2,
                              PI_Where_Clause   IN CLOB,
                              PI_ID_Column      IN VARCHAR2,
                              PO_Row_Identifier OUT coltype_id) AS
    V_DELETE_QUERY CLOB;
    v_wait_time    NUMBER;
    v_select_query CLOB;
  BEGIN
    IF PI_Table IS NULL THEN
      raise_application_error(-20001, 'Table name can not be null');
    END IF;

    IF PI_Where_Clause IS NULL /*or PI_v_Where_Clause =''*/
     THEN
      raise_application_error(-20001, 'Where clause can not be null');
    END IF;

    EXECUTE IMMEDIATE 'select PR_VALUE/1000 from properties where pr_name=''ADJUSTMENTS_LOCK_TIMEOUT'''
      INTO v_wait_time;

    v_Delete_Query := 'Delete from ' || PI_Table || ' where ' ||
                      PI_Where_Clause || ' returning ' || PI_ID_Column ||
                      '  INTO  :v_Col_list';

    V_SELECT_QUERY := 'select 1 from ' || PI_TABLE || ' where ' ||
                      PI_WHERE_CLAUSE || 'for update wait ' || v_wait_time;

    EXECUTE IMMEDIATE v_select_query;

    EXECUTE IMMEDIATE v_Delete_Query
      RETURNING BULK COLLECT
      INTO PO_Row_Identifier;
  END Adjustment_Delete;

  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /* pin_table_name          IN  VARCHAR2   the table for which the multi edit save is done (usually a T table)
     pin_id_column_name      IN  VARCHAR2   name of the PK column (usually ROW_IDENTIFIER)
     pin_version_column_name IN  VARCHAR2,  name of the version columns (usually ROW_VERSION)
     pin_seq_used_for_id     IN  VARCHAR2,  name of the sequence used to generate values for `pin_id_column_name` column during insert operation
                                                (usually <T_table_name>_ROW_IDENTIFIER_SEQ); if NULL, then values passed for `pin_id_column_name` will
                                                be used during insert operation.
     pin_data                IN  CLOB        a CLOB variable holding the edited data in the form of a cursor
  */
  /*example:
  DECLARE
    PIN_TABLE_NAME VARCHAR2(32767);
    PIN_ID_COLUMN_NAME VARCHAR2(32767);
    PIN_VERSION_COLUMN_NAME VARCHAR2(32767);
    PIN_SEQ_USED_FOR_ID VARCHAR2(32767);
    PIN_ENT_INTERN_ID_COL_NAME VARCHAR2(32767);
    PIN_ENT_SEQ_NAME VARCHAR2(32767);
    PIN_AV_COL_NAME  VARCHAR2(32767);
    PIN_DATA CLOB;
    POUT_LIST_OF_UPDATED_IDS COLTYPE_ID;
    POUT_LIST_OF_INSERTED_IDS COLTYPE_ID;

  BEGIN
    PIN_TABLE_NAME := 'T152';
    PIN_ID_COLUMN_NAME := 'ROW_IDENTIFIER';
    PIN_VERSION_COLUMN_NAME := 'ROW_VERSION';
    PIN_SEQ_USED_FOR_ID := 'T152_ROW_IDENTIFIER_SEQ';
    PIN_ENT_INTERN_ID_COL_NAME := 'E_INTERNAL_ID';
    PIN_ENT_SEQ_NAME := 'T152_E_INTERNAL_ID_SEQ';
    PIN_AV_COL_NAME:='F100';
    PIN_DATA :=
      'SELECT 0 "UpdatedInsertedFlag", 1 ROW_IDENTIFIER, 0 ROW_VERSION, TO_DATE(''01.01.2006'',''DD.MM.YYYY'') START_DATE, TO_DATE(''01.01.2011'',''DD.MM.YYYY'') END_DATE, ''Territory 1'' F11, 100 F25, 1001 F100, 3423 E_INTERNAL_ID FROM DUAL UNION ALL
       SELECT 0,                       2 ,               0,             TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 2'' ,    200,     1002,      15                 FROM DUAL UNION ALL
       SELECT 1,                      -4 ,               0,             TO_DATE(''01.01.2000'',''DD.MM.YYYY'') ,           TO_DATE(''01.09.2000'',''DD.MM.YYYY'') ,         ''Territory 3'' ,    900,     NULL,      NULL               FROM DUAL UNION ALL
       SELECT 1,                      99 ,               0,             TO_DATE(''01.01.2000'',''DD.MM.YYYY'') ,           TO_DATE(''01.09.2000'',''DD.MM.YYYY'') ,         ''Territory 30'' ,   999,     NULL,      NULL               FROM DUAL';

    commons_tables.MULTI_EDIT_UPSERT ( PIN_TABLE_NAME, PIN_ID_COLUMN_NAME, PIN_VERSION_COLUMN_NAME, PIN_SEQ_USED_FOR_ID, PIN_ENT_INTERN_ID_COL_NAME, PIN_ENT_SEQ_NAME, PIN_AV_COL_NAME, PIN_DATA, POUT_LIST_OF_UPDATED_IDS, POUT_LIST_OF_INSERTED_IDS );

  --for i in 1..POUT_LIST_OF_UPDATED_IDS.count  loop    dbms_output.put_line('updated: '||POUT_LIST_OF_UPDATED_IDS(i)); end loop;

  --for i in 1..POUT_LIST_OF_INSERTED_IDS.count loop    dbms_output.put_line('inserted: '||POUT_LIST_OF_INSERTED_IDS(i)); end loop;
  --  COMMIT;
  END;
  */
  -----------------------------------------------------------------------------------------
  PROCEDURE Multi_Edit_Upsert(pin_table_name             VARCHAR2,
                              pin_id_column_name         VARCHAR2,
                              pin_version_column_name    VARCHAR2,
                              pin_seq_used_for_id        VARCHAR2,
                              pin_ent_intern_id_col_name VARCHAR2,
                              pin_ent_seq_name           VARCHAR2,
                              pin_av_col_name            VARCHAR2,
                              pin_data                   CLOB,
                              pout_list_of_updated_ids   OUT COLTYPE_ID,
                              /*  pout_list_of_inserted_ids  OUT COLTYPE_ID,*/
                              pout_map_of_inserted_ids OUT TABLETYPE_ID_ID) IS
    v_upd_stmt                 CLOB;
    v_col_list                 CLOB;
    v_inserted_col_list        CLOB;
    v_edited_col_list          CLOB;
    v_stale_condition          CLOB;
    v_id_column_value          CLOB;
    v_ent_intern_id_string     CLOB;
    v_ent_seq_string           CLOB;
    v_av_col_string            CLOB;
    v_av_value_string          CLOB;
    v_version_col_string       CLOB;
    v_version_value_upd_string CLOB;
    v_version_value_ins_string CLOB;
    v_av_col_field_id          NUMBER;
    v_AV_max_value             NUMBER; -- Defect#6145 changed number(10) to number;
    v_update_sql               CLOB;
    v_insert_sql               CLOB;
    v_av_update_sql            CLOB;
    v_cols_cnt                 NUMBER;
    v_tablestr                 DBMS_SQL.desc_tab;
    v_cursorcols               CLOB;
    v_refc                     SYS_REFCURSOR;
    v_refc_desc                BINARY_INTEGER;
    v_tables_id                NUMBER;
    v_inserted_collection_cols CLOB;
    LIST_OF_INSERTED_COLUMNS   CLOB;
    V_WAIT_TIME                VARCHAR2(100 CHAR);
    V_SELECT_QUERY             CLOB;
    v_stamp                    VARCHAR2(250 CHAR);
    V_IS_EXEC                  BOOLEAN;
    V_PR_VALUE                 VARCHAR2(1300 char);
    V_AV_COUNT                 NUMBER;
    CUR                        SYS_REFCURSOR;
    v_av_max_plus_off          NUMBER;
    v_av_timestamp             TIMESTAMP;
  BEGIN

    execute immediate 'select OBJTYPE_ID_ID(ROW_IDENTIFIER, ' ||
                      pin_seq_used_for_id || '.nextval)
    from (' || pin_data || ')
          where  "UpdatedInsertedFlag"=1' bulk collect
      into pout_map_of_inserted_ids;

    v_stamp := 'COMMONS_TABLES.MULTI_EDIT_UPSERT - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      SELECT PR_VALUE
        INTO V_PR_VALUE
        FROM PROPERTIES
       WHERE PR_NAME = 'ENV_NAME';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_PR_VALUE := NULL;
    END;

    CASE V_PR_VALUE
      WHEN 'SPM' THEN
        V_IS_EXEC := TRUE;
      ELSE
        V_IS_EXEC := FALSE;
    END CASE;

    EXECUTE IMMEDIATE 'select count(1) from (' || pin_data ||
                      ') where "UpdatedInsertedFlag"=1'
      into V_AV_COUNT;
    -- log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_TABLE_NAME),
                               ',PIN_TABLE_NAME => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ID_COLUMN_NAME),
                               ',PIN_ID_COLUMN_NAME => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_VERSION_COLUMN_NAME),
                               ',PIN_VERSION_COLUMN_NAME => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_SEQ_USED_FOR_ID),
                               ',PIN_SEQ_USED_FOR_ID => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ENT_INTERN_ID_COL_NAME),
                               ',PIN_ENT_INTERN_ID_COL_NAME => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ENT_SEQ_NAME),
                               ',PIN_ENT_SEQ_NAME => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_AV_COL_NAME),
                               ',PIN_AV_COL_NAME => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PIN_DATA),
                               ',PIN_DATA => <value>',
                               v_stamp);
    END;

    EXECUTE IMMEDIATE 'select to_char(PR_VALUE/1000) from properties where pr_name=''ADJUSTMENTS_LOCK_TIMEOUT'''
      INTO v_wait_time;

    IF V_IS_EXEC THEN
      EXECUTE IMMEDIATE 'SELECT MIN(TABLES_ID)
        FROM tables
       WHERE TABLES_PHYSICAL_NAME = ''' ||
                        pin_table_name || ''''
        into v_tables_id;

      execute immediate 'SELECT MIN(tc_fld_id)
        FROM table_columns
       INNER JOIN tables
          ON tables_id = tc_tables_id
       WHERE tables_physical_name = ''' ||
                        pin_table_name || '''
         AND tc_physical_name = ''' ||
                        pin_av_col_name || ''''
        INTO v_av_col_field_id;

      IF v_av_col_field_id IS NOT NULL THEN
        -- deshmukha commented code
        /*execute immediate 'SELECT MIN(AV_NEXT_VALUE)
         FROM auto_value
        WHERE AV_TABLES_ID = ' || v_tables_id || '
          AND AV_FLD_ID = ' || v_av_col_field_id
           into v_AV_max_value;*/
        /*commons_utils.insert_logs('V_AV_COUNT: ' || V_AV_COUNT);*/
        -- deshmukha added call to get_set_auto_value
        if V_AV_COUNT > 0 then
          execute immediate 'begin
      commons_tables.GET_SET_AUTO_VALUE(:1,:2,:3);
      end;'
            using IN v_tables_id, IN V_AV_COUNT, OUT cur;
          /*loop*/
          fetch cur
            into v_AV_max_value, v_av_max_plus_off, v_av_timestamp;
        end if;
        /* exit when cur%notfound;
        end loop;*/
      END IF;
    END IF;

    /*BEGIN - get cursor description from pin_data select
    Please close both cursors after finishing in order to eliminate "cursor leaks" OF-18212:
    - NDS cursor v_refc
    - DBMS_SQL cusrsor v_refc_desc
    */
    OPEN v_refc FOR pin_data;
    v_refc_desc := DBMS_SQL.TO_CURSOR_NUMBER(v_refc);
    DBMS_SQL.DESCRIBE_COLUMNS(v_refc_desc, v_cols_cnt, v_tablestr);

    DBMS_SQL.CLOSE_CURSOR(v_refc_desc);
    IF v_refc%ISOPEN THEN
      CLOSE v_refc;
    END IF;
    /*END - get cursor description*/

    FOR i IN 1 .. v_cols_cnt LOOP
      v_cursorcols := '''' || v_tablestr(i).col_name || ''',' ||
                      v_cursorcols;
    END LOOP;

    v_cursorcols := RTRIM(v_cursorcols, ',');

    SELECT listagg_java(objtype_word_dlm('TAB.' || column_name ||
                                         '=EDITED.' || column_name,
                                         ', ',
                                         NULL)),
           listagg_java(objtype_word_dlm(DECODE(column_name,
                                                pin_ent_intern_id_col_name,
                                                NULL,
                                                pin_av_col_name,
                                                NULL,
                                                pin_version_column_name,
                                                NULL,
                                                column_name),
                                         ',',
                                         NULL)),
           listagg_java(objtype_word_dlm('TAB.' || column_name, ',', NULL)),
           listagg_java(objtype_word_dlm('EDITED.' || column_name,
                                         ',',
                                         NULL))
      INTO v_upd_stmt, v_col_list, v_inserted_col_list, v_edited_col_list
      FROM user_tab_columns
     WHERE table_name = pin_table_name
       AND COLUMN_NAME != pin_id_column_name
       AND EXISTS (SELECT 1
              FROM XMLTABLE(v_cursorcols)
             WHERE TRIM(COLUMN_VALUE) = column_name);

    SELECT DECODE(pin_version_column_name,
                  NULL,
                  NULL,
                  ' WHERE TAB.' || pin_version_column_name || '=EDITED.' ||
                  pin_version_column_name),

           DECODE(pin_seq_used_for_id,
                  NULL,
                  'EDITED.' || pin_id_column_name,

                  '(select id2 from table(:map) where id1= ' ||
                  pin_id_column_name || ') ' || pin_id_column_name
                  /* pin_seq_used_for_id || '.NEXTVAL'*/),

           NVL2(pin_ent_intern_id_col_name,
                ',' || pin_ent_intern_id_col_name,
                ''),
           NVL2(pin_ent_seq_name, ',' || pin_ent_seq_name || '.NEXTVAL', ''),
           NVL2(pin_av_col_name, ',' || pin_av_col_name, ''),
           NVL2(pin_av_col_name,
                ',' || TO_CHAR(v_AV_max_value) || '+rownum-1',
                ''),
           NVL2(pin_version_column_name, ',' || pin_version_column_name, ''),
           NVL2(pin_version_column_name,
                ',' || pin_version_column_name || '+1',
                ''),
           NVL2(pin_version_column_name, ',' || pin_version_column_name, '')
      INTO v_stale_condition,
           v_id_column_value,
           v_ent_intern_id_string,
           v_ent_seq_string,
           v_av_col_string,
           v_av_value_string,
           v_version_col_string,
           v_version_value_upd_string,
           v_version_value_ins_string
      FROM DUAL;

    SELECT '
        UPDATE ' || pin_table_name || ' TAB
        set      (' || NVL2(v_col_list, v_col_list || ',', '') ||
           NVL2(pin_ent_intern_id_col_name,
                pin_ent_intern_id_col_name || ',',
                '') || pin_version_column_name || ')=
                (select ' ||
           NVL2(v_col_list, v_col_list || ',', '') ||
           NVL2(pin_ent_intern_id_col_name,
                pin_ent_intern_id_col_name || ',',
                '') || pin_version_column_name || '+1
                 from (' || pin_data ||
           ')  EDITED
                 where TAB.' || pin_id_column_name ||
           ' = EDITED.' || pin_id_column_name || '
                )
        where
        (' || pin_id_column_name || ',' ||
           pin_version_column_name || ') in
        (select ' || pin_id_column_name || ',' ||
           pin_version_column_name || ' from (' || pin_data || ') )
        returning ' || pin_id_column_name || ' into :updated_list
        '
      INTO v_update_sql
      FROM DUAL;

    V_SELECT_QUERY := ' select 1 from ' || pin_table_name || ' TAB  where
         (' || pin_id_column_name || ',' ||
                      pin_version_column_name || ') in
         (select ' || pin_id_column_name || ',' ||
                      pin_version_column_name || ' from (' || pin_data || ') )
         FOR UPDATE WAIT ' || V_WAIT_TIME || '';

    EXECUTE IMMEDIATE V_SELECT_QUERY;
    --dbms_output.put_line(v_update_sql);
    EXECUTE IMMEDIATE v_update_sql
      RETURNING BULK COLLECT
      INTO pout_list_of_updated_ids;

    SELECT pin_id_column_name || NVL2(v_col_list, ',' || v_col_list, '') ||
           v_ent_intern_id_string || v_av_col_string ||
           v_version_col_string
      INTO list_of_inserted_columns
      FROM DUAL;

    v_inserted_collection_cols := 'rows4insert(i).' ||
                                  REPLACE(list_of_inserted_columns,
                                          ',',
                                          ',rows4insert(i).');

    --      --dbms_output.put_line(list_of_inserted_columns);
    -- deshmukha added coditional fire of insert only when there are records to insert
    if V_AV_COUNT > 0 then
      v_insert_sql := '
        declare
            cursor c is select ' ||
                      list_of_inserted_columns || ' from (' ||
                      pin_table_name || ') where 1=0;
            type t is table of c%rowtype;
            rows4insert t;
        begin
            select ' || v_id_column_value;

      v_insert_sql := v_insert_sql ||
                     /*NVL2(v_col_list, ',' || v_col_list, '')*/
                      case
                        when v_col_list is null then
                         ''
                        else
                         ',' || v_col_list
                      end || v_ent_seq_string || v_av_value_string ||
                      v_version_value_ins_string || '
                    bulk collect into rows4insert
             from (' || pin_data || ')
             where "UpdatedInsertedFlag"=1;

            forall i in 1..rows4insert.count
               INSERT INTO ' || pin_table_name || '(' ||
                      list_of_inserted_columns || ') values (' ||
                      v_inserted_collection_cols || ')
           /* returning ROW_IDENTIFIER BULK COLLECT into :ids*/;
        end;';

      EXECUTE IMMEDIATE v_insert_sql
        USING IN /*OUT */
      pout_map_of_inserted_ids /*,pout_list_of_inserted_ids*/
      ;
    end if;
    /*commons_utils.insert_logs('v_insert_sql : ' || v_insert_sql);*/

    /*SELECT '
        declare
            cursor c is select ' || list_of_inserted_columns ||
           ' from (' || pin_table_name || ') where 1=0;
            type t is table of c%rowtype;
            rows4insert t;
        begin
            select ' || v_id_column_value ||
           NVL2(v_col_list, ',' || v_col_list, '') || v_ent_seq_string ||
           v_av_value_string || v_version_value_ins_string || '
                    bulk collect into rows4insert
             from (' || pin_data || ')
             where "UpdatedInsertedFlag"=1;

            forall i in 1..rows4insert.count
               INSERT INTO ' || pin_table_name || '(' ||
           list_of_inserted_columns || ') values (' ||
           v_inserted_collection_cols || ')
           \* returning ROW_IDENTIFIER BULK COLLECT into :ids*\;
        end;'
      INTO v_insert_sql
      FROM DUAL;
    commons_utils.insert_logs('v_insert_sql : ' || v_insert_sql);*/

    --IN OUT new_deptid, new_dname
    --  pout_map_of_inserted_ids

    --dbms_output.put_line(v_insert_sql);

    --dbms_output.put_line(sql%rowcount);
    -- deshmukha commented the local update
    /*v_av_update_sql := '
          update AUTO_VALUE
          set AV_NEXT_VALUE = AV_NEXT_VALUE +
                             (select count(1) from (' ||
                       pin_data || ') where "UpdatedInsertedFlag"=1)
          where av_tables_id=''' ||
                       TO_CHAR(v_tables_id) || ''' and AV_FLD_ID = ' ||
                       TO_CHAR(v_av_col_field_id);

    IF v_av_col_field_id IS NOT NULL THEN
      EXECUTE IMMEDIATE v_av_update_sql;
    END IF;*/
    --  dbms_output.put_line(1);

  END MULTI_EDIT_UPSERT;

  PROCEDURE Common_Upsert(pi_table_name             VARCHAR2,
                          pi_QI_name                VARCHAR2,
                          PI_mode                   NUMBER,
                          pi_list_of_columns        IN TABLETYPE_CHARMAX,
                          pi_id_column_name         VARCHAR2,
                          pi_version_column_name    VARCHAR2,
                          pi_seq_used_for_id        VARCHAR2,
                          pi_ent_intern_id_col_name VARCHAR2,
                          pi_ent_seq_name           VARCHAR2,
                          pi_av_col_name            VARCHAR2,
                          pi_av_generated_sw        NUMBER,
                          pi_process_id             VARCHAR2,
                          pi_gather_stats           NUMBER,
                          pi_av_count               NUMBER,
                          --moving close date parameters start
                          pi_is_close_end       NUMBER,
                          pi_key_Fields         IN VARCHAR2,
                          pi_Effective_Start    IN VARCHAR2,
                          pi_Effective_End      IN VARCHAR2,
                          pi_Is_Period          IN NUMBER,
                          pi_tu_id              IN NUMBER,
                          PO_closed_dates_Count OUT NUMBER,
                          --moving close date parameters end
                          po_av_count     OUT NUMBER,
                          po_update_count OUT NUMBER,
                          po_insert_count OUT NUMBER,
                          po_status       OUT NUMBER) IS
    v_merge_count              NUMBER;
    v_insert_count             NUMBER;
    v_IP_col_list              CLOB;
    v_OP_col_list              CLOB;
    v_update_col_list          CLOB;
    v_col_list                 CLOB;
    v_id_column_value          CLOB;
    v_ent_intern_id_string     CLOB;
    v_ent_seq_string           CLOB;
    v_av_col_string            CLOB;
    v_av_value_string          CLOB;
    v_version_col_string       CLOB;
    v_av_update_sql            CLOB;
    v_version_value_ins_string CLOB;
    v_count_query              VARCHAR2(1000);
    join_condition_for_merge   VARCHAR2(1000);
    v_av_col_field_id          NUMBER;
    v_AV_max_value             NUMBER;
    v_sql                      CLOB;
    v_QI_table                 VARCHAR2(30) := UPPER(pi_QI_name);
    v_data_table               VARCHAR2(30) := UPPER(pi_table_name);
    e_Data_table_missing EXCEPTION;
    e_Dump_table_missing EXCEPTION;
    V_SIZE_DATA               NUMBER;
    V_SIZE_DUMP               NUMBER;
    V_SIZE_DIFF               NUMBER;
    V_REBUILD                 NUMBER(1);
    V_BREAKPOINT_SIZE         NUMBER := 100;
    V_BREAKPOINT_SIMILAR_SIZE NUMBER := 45;
    V_BREAKPOINT_SIMILAR_DIFF NUMBER := 5;
    V_BREAKPOINT_DIFF_SMALL   NUMBER := 50;
    v_index                   NUMBER := 0;
    v_Primary_Key_enabled     NUMBER(1) := 0;
    l_offset                  NUMBER DEFAULT 1;
    v_count                   NUMBER;
    v_index_created           NUMBER(1) := 0;
    v_index_status            NUMBER := 1;
    v_tables_id               NUMBER;
    v_merge_status            BOOLEAN := FALSE;
    v_in_log_msg              CLOB;
    v_out_log_msg             CLOB;
    v_before                  number;
    v_post                    number;
    v_cnt                     number;
  BEGIN
    /*execute immediate 'create table temp_bkp as select * from ' ||
                      pi_QI_name;*/
  if(PI_mode in (3,4)) then
   v_count_query := 'select count ( * ) from ' || pi_QI_name || ' where ' ||
                     pi_id_column_name || ' is null';
   /* commons_utils.insert_logs('PI_mode : '||PI_mode);*/
    EXECUTE IMMEDIATE v_count_query
      INTO v_insert_count;

    IF (pi_av_count + NVL(v_insert_count, 0) >= 10000000000000) THEN
      raise_application_error(-20001,
                              'Auto-value not withing system Bounds');
    END IF;
    end if;

    SELECT MIN(TABLES_ID)
      INTO v_tables_id
      FROM tables
     WHERE TABLES_PHYSICAL_NAME = pi_table_name;

    --check if data table exists
    FOR c IN (SELECT 1
                FROM DUAL
               WHERE NOT EXISTS (SELECT 1
                        FROM user_tables
                       WHERE table_name = v_data_table)) LOOP
      RAISE e_Data_table_missing;
    END LOOP;

    --check if QI table exists
    FOR c IN (SELECT 1
                FROM DUAL
               WHERE NOT EXISTS
               (SELECT 1 FROM user_tables WHERE table_name = v_QI_table)) LOOP
      RAISE e_Dump_table_missing;
    END LOOP;

    ---disable logging

    /*   commons_utils.Disable_logging ( v_data_table, pi_process_id, v_index);
    */
    --dbms_output.put_line('commons_utils.Disable_logging');
    -------get size
    --OF-9107 start
    /*  commons_utils.GET_TABLE_SIZE ( v_data_table, V_SIZE_DATA);
    commons_utils.GET_TABLE_SIZE ( v_QI_table, V_SIZE_DUMP);

    --dbms_output.put_line('V_SIZE_DATA= ' || V_SIZE_DATA);
    --dbms_output.put_line('V_SIZE_DUMP= ' || V_SIZE_DUMP);

    V_SIZE_DIFF       := ABS ( V_SIZE_DATA - V_SIZE_DUMP);

    ---formula
    SELECT CASE WHEN ( (V_SIZE_DIFF < V_BREAKPOINT_SIMILAR_DIFF) AND (V_SIZE_DATA < V_BREAKPOINT_SIMILAR_SIZE)) THEN '0' WHEN ( (V_SIZE_DIFF > V_BREAKPOINT_DIFF_SMALL) AND (V_SIZE_DATA < V_BREAKPOINT_SIZE)) THEN '0' ELSE '1' END
      INTO V_REBUILD
      FROM DUAL;

    IF V_REBUILD = '0'
    THEN
      v_index_created := 1;
      v_index_status  := 3;
      DBMS_OUTPUT.put_line ( ' V_REBUILD = 0');
    END IF;

    \*insert into test_adl values (v_tables_id,V_REBUILD,sysdate);
    commit;*\
    ----disable indexes
    IF V_REBUILD = 1
    THEN
      COMMONS_INDEXING.DISABLE_ALL_INDEXES (PI_TABLES_ID        => v_tables_id,
                                            PI_PROCESS_ID       => NULL,
                                            PI_RUN_ID           => NULL,
                                            PI_TRANSACTION_ID   => pi_process_id,
                                            PO_LOG_MSG          => v_in_log_msg);

      v_index_status  := 10;
      v_index_created := 0;
    \* --dbms_output.put_line(' V_REBUILD = 1');
     -- commons_utils.Disable_indexes(v_data_table, pi_process_id, v_index);
     commons_utils.Disable_nonunique_indexes(v_data_table,
                                             pi_process_id,
                                             v_index);
     v_index_status := 8;
     commons_utils.Drop_unique_indexes(v_data_table, pi_process_id, v_index);

     v_index_status := 4;

     v_index_created := 0;
     --dbms_output.put_line(' Disable_indexes');
     commons_utils.Disable_Primary_Key_Cons(v_data_table,
                                            pi_process_id,
                                            v_index);
     -- dbms_output.put_line(' Disable_Primary_Key_Cons');
     v_index_status := 5;*\



    \*  commons_utils.Disable_Unique_Constraint(v_data_table,
    pi_process_id,
    v_index);*\

    END IF;*/
    -- OF-9107 end
    --dbms_output.put_line(' after rebuild if');

    /* \*  if(pi_av_generated_sw=1) then*\
    -- min used to avoid no data found
    select min(tc_fld_id)
      into v_av_col_field_id
      from table_columns
     inner join tables
        on tables_id = tc_tables_id
     where tables_physical_name = pi_table_name
       and tc_physical_name = pi_av_col_name;
     -- min used to avoid no data found
    select min(AV_NEXT_VALUE)
      into v_AV_max_value
      from auto_value
     where av_tables_id = v_tables_id
       and AV_FLD_ID = v_av_col_field_id;
    \*  end if;*\*/
    v_AV_max_value := pi_av_count;
    --DBMS_OUTPUT.put_line ( ' av_max_value=' || v_AV_max_value);

    /*select listagg(decode(column_name,
                         pi_ent_intern_id_col_name,
                         NULL,
                         pi_av_col_name,
                         NULL,
                         pi_version_column_name,
                         NULL,
                         'IP.' || column_name),
                  ',') within group(order by null),
          listagg(decode(column_name,
                         pi_ent_intern_id_col_name,
                         NULL,
                         pi_av_col_name,
                         NULL,
                         pi_version_column_name,
                         NULL,
                         'OP.' || column_name),
                  ',') within group(order by null),
          listagg(decode(column_name,
                         pi_ent_intern_id_col_name,
                         NULL,
                         pi_av_col_name,
                         decode(pi_av_generated_sw,
                                1,
                                null,
                                'OP.' || column_name || '=IP.' || column_name),
                         pi_version_column_name,
                         'OP.' || column_name || '=OP.' || column_name || '+1',
                         'OP.' || column_name || '=IP.' || column_name),
                  ',') within group(order by null)

     into v_OP_col_list, v_IP_col_list, v_update_col_list
     from user_tab_columns
    where table_name = v_data_table
      AND (COLUMN_NAME != pi_id_column_name
      and COLUMN_NAME  in (select * from table(pi_list_of_columns)));*/

    FOR c IN (SELECT column_name
                FROM user_tab_columns
               WHERE table_name = v_data_table
                 AND (COLUMN_NAME NOT IN
                     (NVL(pi_id_column_name, ' '),
                       NVL(pi_ent_intern_id_col_name, ' ')) AND
                     COLUMN_NAME IN
                     (SELECT * FROM TABLE(pi_list_of_columns)))) LOOP
      IF (c.column_name = pi_av_col_name) THEN
        v_update_col_list := CASE
                               WHEN pi_av_generated_sw = 1 THEN
                                v_update_col_list
                               ELSE
                                v_update_col_list || 'OP.' || c.column_name ||
                                '=IP.' || c.column_name || ','
                             END;
      ELSIF (c.column_name = pi_version_column_name) THEN
        v_update_col_list := v_update_col_list || 'OP.' || c.column_name ||
                             '=OP.' || c.column_name || '+1' || ',';
      ELSE
        v_OP_col_list     := v_OP_col_list || 'IP.' || c.column_name || ',';
        v_IP_col_list     := v_IP_col_list || 'OP.' || c.column_name || ',';
        v_update_col_list := v_update_col_list || 'OP.' || c.column_name ||
                             '=IP.' || c.column_name || ',';
      END IF;
      /* v_OP_col_list:=substr(v_OP_col_list,1,length(v_OP_col_list)-1 );
       v_IP_col_list:=substr(v_IP_col_list,1,length(v_IP_col_list)-1 );
         v_update_col_list:=substr(v_update_col_list,1,length(v_update_col_list)-1 );
      */
    /* end loop;*/
    /* case when */

    /* listagg(decode(column_name,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        pi_ent_intern_id_col_name,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        NULL,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        pi_av_col_name,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        NULL,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        pi_version_column_name,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        NULL,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        'IP.' || column_name),
                                                                                                                                                                                                                                                                                                                                                                                                                                                 ',') within group(order by null),*/

    END LOOP;

    v_OP_col_list     := SUBSTR(v_OP_col_list, 1, LENGTH(v_OP_col_list) - 1);
    v_IP_col_list     := SUBSTR(v_IP_col_list, 1, LENGTH(v_IP_col_list) - 1);
    v_update_col_list := SUBSTR(v_update_col_list,
                                1,
                                LENGTH(v_update_col_list) - 1);

    /*
     loop
        exit when l_offset > dbms_lob.getlength(v_IP_col_list);
        dbms_output.put_line(dbms_lob.substr(v_IP_col_list, 999, l_offset));
        l_offset := l_offset + 999;
      end loop;
      l_offset := 1;

        loop
        exit when l_offset > dbms_lob.getlength(v_OP_col_list);
        dbms_output.put_line(dbms_lob.substr(v_OP_col_list, 999, l_offset));
        l_offset := l_offset + 999;
      end loop;
      l_offset := 1;


        loop
        exit when l_offset > dbms_lob.getlength(v_update_col_list);
        dbms_output.put_line(dbms_lob.substr(v_update_col_list, 999, l_offset));
        l_offset := l_offset + 999;
      end loop;
      l_offset := 1;

    */

    SELECT 'OP.' || pi_id_column_name || ' = IP.' || pi_id_column_name,
           DECODE(pi_seq_used_for_id,
                  NULL,
                  pi_id_column_name,
                  pi_seq_used_for_id || '.NEXTVAL'),
           NVL2(pi_ent_intern_id_col_name,
                ',' || pi_ent_intern_id_col_name,
                ''),
           NVL2(pi_ent_seq_name, ',' || pi_ent_seq_name || '.NEXTVAL', ''),
           /* decode(pi_av_generated_sw,0,null,1,*/
           NVL2(pi_av_col_name, ',OP.' || pi_av_col_name, '') /*)*/,
           DECODE(pi_av_generated_sw,
                  0,
                  NVL2(pi_av_col_name, ',IP.' || pi_av_col_name, ''),
                  1,
                  NVL2(pi_av_col_name,
                       ',' || TO_CHAR(v_AV_max_value) || '+row_num-1',
                       '')),
           NVL2(pi_version_column_name, ',' || pi_version_column_name, ''),
           NVL2(pi_version_column_name, ',' || 0, '')
      INTO join_condition_for_merge,
           v_id_column_value,
           v_ent_intern_id_string,
           v_ent_seq_string,
           v_av_col_string,
           v_av_value_string,
           v_version_col_string,
           v_version_value_ins_string
      FROM DUAL;

    /*dbms_output.put_line(' join_condition_for_merge=' || join_condition_for_merge);
    dbms_output.put_line(' v_id_column_value=' || v_id_column_value);
    dbms_output.put_line(' v_ent_intern_id_string=' ||
                         v_ent_intern_id_string);
    dbms_output.put_line(' v_ent_seq_string=' || v_ent_seq_string);
    dbms_output.put_line(' v_av_col_string=' || v_av_col_string);
    dbms_output.put_line(' v_av_value_string=' || v_av_value_string);
    dbms_output.put_line(' v_version_col_string=' || v_version_col_string);
    dbms_output.put_line(' v_version_value_ins_string=' ||
                         v_version_value_ins_string);*/
    --/*+ APPEND */
    /*  select ' MERGE ' || decode(pi_is_close_end, 1, ' ', '\*+ APPEND *\') ||
           ' INTO  ' || pi_table_name || ' OP
         USING (select rownum row_num,' || pi_QI_name || '.* from ' ||
           pi_QI_name || ') IP
        ON  (IP.' || pi_id_column_name || ' = OP.' ||
           pi_id_column_name || ' )
        WHEN MATCHED
      THEN
         UPDATE
        SET ' || v_update_col_list || ' WHEN NOT MATCHED
    THEN
       INSERT (' || pi_id_column_name ||
           nvl2(v_IP_col_list, ',' || v_IP_col_list, '') ||
           v_ent_intern_id_string || v_av_col_string || v_version_col_string || ')
      VALUES ( ' || v_id_column_value ||
           nvl2(v_OP_col_list, ',' || v_OP_col_list, '') || v_ent_seq_string ||
           v_av_value_string || v_version_value_ins_string || ')'
      into v_sql
      from dual;*/

    v_sql := ' MERGE ' || CASE
               WHEN pi_is_close_end = 1 THEN
                ' '
               ELSE
                '/*+ APPEND */'
             END || ' INTO  ' || pi_table_name || ' OP
       USING (select rownum row_num,' || pi_QI_name || '.* from ' ||
             pi_QI_name || ') IP
      ON  (IP.' || pi_id_column_name || ' = OP.' ||
             pi_id_column_name || ' )' || case
               when PI_mode in (2, 3) /*and (pi_av_generated_sw <> 1) and PI_mode in (2)*/ then
                ' WHEN MATCHED
    THEN
       UPDATE
      SET ' || v_update_col_list
             end || '' || case
               when PI_mode in (3, 4) then

                ' WHEN NOT MATCHED
  THEN
     INSERT (' || pi_id_column_name || CASE
                  WHEN v_IP_col_list IS NOT NULL THEN
                   ',' || v_IP_col_list
                  ELSE
                   ''
                END || v_ent_intern_id_string || v_av_col_string ||
                v_version_col_string || ')
    VALUES ( ' || v_id_column_value || CASE
                  WHEN v_OP_col_list IS NOT NULL THEN
                   ',' || v_OP_col_list
                  ELSE
                   ''
                END || v_ent_seq_string || v_av_value_string ||
                v_version_value_ins_string || ')'
             end;
    /*  loop
      exit when l_offset > dbms_lob.getlength(v_sql);
      dbms_output.put_line(dbms_lob.substr(v_sql, 999, l_offset));
      l_offset := l_offset + 999;
    end loop;*/
    l_offset := 1;

    execute immediate '
  select count(' || pi_id_column_name || ') from ' ||
                      pi_table_name
      into v_before;
    v_before := case
                  when v_before = 0 then
                   1
                  else
                   v_before
                end;
   /* commons_utils.insert_logs('Merge : '||v_sql);*/
    if not ((pi_av_generated_sw = 1) and PI_mode in (2)) then
      EXECUTE IMMEDIATE v_sql;
       v_merge_count := SQL%ROWCOUNT;
    else
       v_merge_count := 0;
    end if;
     /*v_merge_count := SQL%ROWCOUNT;*/
   /* commons_utils.insert_logs('v_merge_count : '||v_merge_count);*/
    /*  v_post := v_merge_count;*/
    v_post := nvl(v_merge_count, 0);
    --  DBMS_OUTPUT.put_line('SQL%ROWCOUNT=' || SQL%ROWCOUNT);
    v_merge_status := TRUE;
    /* v_count_query := 'select count ( * ) from ' || pi_QI_name || ' where ' ||
                     pi_id_column_name || ' is null';
    execute immediate v_count_query
      INTO v_insert_count;*/
    --DBMS_OUTPUT.put_line('v_insert_count=' || v_insert_count);
    po_update_count := v_merge_count - NVL(v_insert_count, 0);
    po_insert_count := NVL(v_insert_count, 0);

    --call to closing end date
    IF (pi_is_close_end = 1) THEN
      COMMON_CLOSING_END(pi_Table           => pi_table_name,
                         pi_key_Fields      => pi_key_Fields,
                         PI_Effective_Start => PI_Effective_Start,
                         PI_Effective_End   => PI_Effective_End,
                         PI_Is_Period       => PI_Is_Period,
                         PI_TU_ID           => PI_TU_ID,
                         /*   PI_Commit          =>PI_Commit,*/
                         PO_Count => PO_closed_dates_Count);
    END IF;

    COMMIT;

    --dbms_output.put_line(' v_insert_sql='||v_insert_sql);

    /* loop
      exit when l_offset > dbms_lob.getlength(v_sql);
      dbms_output.put_line(dbms_lob.substr(v_sql, 999, l_offset));
      l_offset := l_offset + 999;
    end loop;*/
    l_offset := 1;

    /*
       v_av_update_sql := '
            update AUTO_VALUE
            set AV_NEXT_VALUE =(select Max(' ||
                         pi_av_col_name || ') + 1 from ' || pi_table_name || ')
            where av_tables_id=''' ||
                         v_tables_id || ''' and AV_FLD_ID = ' ||
                         to_char(v_av_col_field_id);
    */

    IF (pi_av_col_name IS NOT NULL AND PI_mode <> 2) THEN
      EXECUTE IMMEDIATE ' select Max(' || pi_av_col_name || ')  from ' ||
                        pi_table_name
        INTO v_count;

      po_av_count := v_count;
      /* COMMONS_TABLES.SET_AUTO_VALUE(v_tables_id, v_count);*/
    END IF;

    -- commit;
    -----rebuild indexes
    -- OF-9107 starts
    /*  IF V_REBUILD = 1
        THEN
          COMMONS_INDEXING.ENABLE_ALL_INDEXES (PI_TABLES_ID        => v_tables_id,
                                               PI_PROCESS_ID       => NULL,
                                               PI_RUN_ID           => NULL,
                                               PI_TRANSACTION_ID   => pi_process_id,
                                               PO_LOG_MSG          => v_out_log_msg);

          v_index_status := 11;
        \* commons_utils.Enable_Primary_Key_Cons(v_data_table);
          v_Primary_Key_enabled := 1;
          v_index_status        := 2;
          --dbms_output.put_line(' Enable_Primary_Key_Cons');
          \* commons_utils.Disable_Unique_Constraint(v_data_table,
                                             pi_process_id,
                                             v_index);
          v_Unique_Key_enabled:=1;
          v_index_status:=3;*\

          commons_tables.CREATE_UNIQUE_INDEXES(pi_tables_id => v_tables_id);
          v_index_status := 9;
          commons_utils.Rebuild_nonunique_indexes(v_data_table);

          --commons_utils.Rebuild_indexes(v_data_table);
          v_index_created := 1;
          v_index_status  := 3;
          dbms_output.put_line(' Rebuild_indexes');*\

        END IF;
    */
    -- OF-9107 stops
    po_status := v_index_status;
    /* commons_utils.Enable_logging ( v_data_table);*/

    IF (v_post / v_before > 0.1) THEN
      commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => v_data_table,
                                               PI_MODE  => 2);
      /*commons_utils.GET_TABLE_SIZE(v_data_table, V_SIZE_DATA);*/
    END IF;

    --dbms_output.put_line(' Enable_logging');
    --  commons_ddl_handling.clean_ddl_log(pi_process_id);
  EXCEPTION
    WHEN e_Data_table_missing THEN
      raise_application_error(-20101, 'Data table does not exist');
    WHEN e_Dump_table_missing THEN
      raise_application_error(-20101, 'Dump table does not exist');
    WHEN OTHERS THEN
      /* IF (v_index_status IN (2,
                             3,
                             9,
                             11))
      THEN
        po_status := v_index_status;
        DBMS_OUTPUT.put_line ( 'rollback');
        DBMS_OUTPUT.put_line ( SQLERRM);

        IF (v_merge_status = FALSE)
        THEN
          ROLLBACK;
          commons_ddl_handling.rollback_ddl ( pi_process_id);
          RAISE;
        END IF;*/

      IF (v_merge_status = true) then

        po_status := v_index_status;
        -- dbms_output.put_line('rollback');
        -- dbms_output.put_line(SQLERRM);
      ELSE
        -- dbms_output.put_line('rollback');
        -- dbms_output.put_line(SQLERRM);
        --no ddl invloved now so no rollback requried.
        /*  ROLLBACK;
        commons_ddl_handling.rollback_ddl(pi_process_id);*/

        --commons_ddl_handling.clean_ddl_log(pi_process_id);
        -- commit;
        /*commons_utils.insert_logs(sqlerrm || dbms_utility.format_error_backtrace());*/
        RAISE;
      END IF;
  END Common_Upsert;

  /*
  PROCEDURE SET_AUTO_VALUE(pi_TABLE IN number, pi_value IN number) IS



  v_av_update_sql varchar2(1000);

  begin


  if(pi_value>=10000000000000) then

  raise_application_error(-20001, 'Auto-value not within system Bounds');

  end if;


    v_av_update_sql := '
          update AUTO_VALUE
          set AV_NEXT_VALUE =(
          case when (ceil(' || pi_value || ' + 1
          )<1) then 1 else ceil(' || pi_value ||
                       ' + 1)
          end
          )
          where AV_TABLES_ID=''' || pi_TABLE|| ''' ';
          dbms_output.put_line(v_av_update_sql);
           execute immediate v_av_update_sql;


  end SET_AUTO_VALUE;
  */

  PROCEDURE SET_AUTO_VALUE(pi_TABLE_ID IN NUMBER, pi_value IN NUMBER) IS
    v_av_update_sql VARCHAR2(1000);
  BEGIN
    IF (pi_value >= 10000000000000) THEN
      raise_application_error(-20310,
                              'Auto-value not within system Bounds');
    END IF;

    v_av_update_sql := '
        update AUTO_VALUE
        set AV_NEXT_VALUE =(
        case when (ceil(' || pi_value ||
                       ' + 1
        )<1) then 1 else ceil(' || pi_value ||
                       ' + 1)
        end
        ),
        AV_UTC_TIMESTAMP    =''' ||
                       SYS_EXTRACT_UTC(SYSTIMESTAMP) || '''
        where AV_TABLES_ID=''' || pi_TABLE_ID ||
                       ''' ';

    --dbms_output.put_line(v_av_update_sql);
    EXECUTE IMMEDIATE v_av_update_sql;
  END SET_AUTO_VALUE;

  FUNCTION GET_AUTO_VALUE(pi_TABLE_ID IN NUMBER) RETURN NUMBER IS
    v_av_sql   VARCHAR2(1000);
    v_av_value NUMBER;
  BEGIN
    v_av_sql := '
        Select AV_NEXT_VALUE
        From AUTO_VALUE
        where AV_TABLES_ID=''' || pi_TABLE_ID || '''';

    -- dbms_output.put_line(v_av_sql);
    EXECUTE IMMEDIATE v_av_sql
      INTO v_av_value;

    IF (v_av_value >= 10000000000000) THEN
      raise_application_error(-20310,
                              'Auto-value not withing system Bounds');
    END IF;

    RETURN v_av_value;
  END GET_AUTO_VALUE;

  PROCEDURE COMMON_CLOSING_END(pi_Table           IN VARCHAR2,
                               pi_key_Fields      IN VARCHAR2,
                               PI_Effective_Start IN VARCHAR2,
                               PI_Effective_End   IN VARCHAR2,
                               PI_Is_Period       IN number,
                               PI_TU_ID           IN number,
                               /*  PI_Commit          IN number,*/
                               PO_Count out NUMBER

                               ) IS

    close_date sys_refcursor;
    v_sql      VARCHAR2(32767);
    v_update   VARCHAR2(32767);

    TYPE rtype_periods IS RECORD(
      ROW_IDENTIFIER number,
      start_date     number,
      end_date       number,
      end_calulate   number);
    TYPE coltype_periods is table of rtype_periods;
    vr_periods coltype_periods;

    TYPE rtype_dates IS RECORD(
      ROW_IDENTIFIER number,
      start_date     date,
      end_date       date,
      end_calulate   date);
    l_offset number default 1;
    TYPE coltype_dates is table of rtype_dates;
    vr_dates coltype_dates;
  BEGIN

    if (PI_Is_Period = 0) then
      select '

     select ROW_IDENTIFIER ,' || PI_Effective_Start || ' , ' ||
             PI_Effective_End || ' , end_calulate
      from (

     select  ROW_IDENTIFIER , ' ||
             decode(to_char(pi_key_Fields),
                    null,
                    null,
                    pi_key_Fields || ' , ') || ' decode( ' ||
             PI_Effective_End || ' ,
                 null,
                 LEAD( ' || PI_Effective_Start ||
             ' ) OVER(partition by ' ||
             nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Table),
                                                        PI_COL_LIST   => pi_key_Fields),
                 ' NULL ') || ' order by ' || PI_Effective_Start ||
             '  nulls first ) - 1, ' || PI_Effective_End ||
             ' ) AS end_calulate, ' || PI_Effective_Start || '
                 , ' || PI_Effective_End || '

                 from ' || pi_Table || ' ) IP
     where IP.' || PI_Effective_End || ' is null and
     IP.end_calulate is not null
      '
        into v_sql
        from dual;
      /*loop
          exit when l_offset > dbms_lob.getlength(v_sql);
         dbms_output.put_line( dbms_lob.substr( v_sql, 1000, l_offset ) );
        l_offset := l_offset + 1000;
      end loop;*/

      execute immediate v_sql bulk collect
        into vr_dates;

      if (vr_dates is not null) then
        PO_Count := vr_dates.count;

        select

         'UPDATE ' || pi_Table || '
       SET    ' || PI_Effective_End ||
         ' = :1
       WHERE  ROW_IDENTIFIER = :2'
          into v_update
          from dual;

        FORALL i IN vr_dates.first .. vr_dates.last EXECUTE IMMEDIATE
                                      v_update USING vr_dates(i)
                                     .end_calulate, vr_dates(i)
                                     .ROW_IDENTIFIER
          ;
      end if;
    elsif (PI_Is_Period = 1) then

      select '

with Table_Check_partial as
 (select rownum as row_number,
         T_Temp.*,
         T_Temp.tupr_start_date start_given,
         LEAD(T_Temp.tupr_start_date) OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by T_Temp.tupr_start_date nulls first) end_calulated_partial

    from (

          select Temp.*,
                  tupr_start.TUPR_start_date TUPR_start_date,
                  tupr_end.tupr_end_date     tupr_end_date,
                  tupr_start.TUPR_id         TUPR_start_id,
                  tupr_end.tupr_id           tupr_end_id

            from (select IP.*
                     from ' || pi_Table || ' IP
                   ) Temp
            left outer join tu_periods_range tupr_start
              on tupr_start.TUPR_ID = Temp.' ||
              PI_Effective_Start || '
            left outer join tu_periods_range tupr_end
              on tupr_end.TUPR_ID = Temp.' || PI_Effective_End ||
              ') T_Temp) /*T)*/
--select * from Table_Check_partial
,
Table_Check as

 (

  select T.*,
          (select tupr_id
             from tu_periods_range
            where tupr_id in (decode(tupr_end_id,
                                     null,
                                     commons_timeunits.Get_nth_prior_period(' ||
              PI_TU_ID || ',
                                                                            (select tupr_id
                                                                               from tu_periods_range
                                                                              where tupr_start_date =
                                                                                    end_calulated_partial
                                                                                and tupr_tup_id in
                                                                                    (select TUP_ID
                                                                                       from tu_periods
                                                                                      where tup_tu_id = ' ||
              PI_TU_ID || ')

                                                                             ),
                                                                            1,
                                                                            2010,
                                                                            2025),
                                     tupr_end_id))) end_calulate
    from Table_Check_partial T

  )
    select  ROW_IDENTIFIER ,' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' , end_calulate    from Table_Check
         where ' || PI_Effective_End ||
              ' is null and
     end_calulate is not null'
        into v_sql
        from dual;

      /*
      loop
             exit when l_offset > dbms_lob.getlength(v_sql);
            dbms_output.put_line( dbms_lob.substr( v_sql, 1000, l_offset ) );
           l_offset := l_offset + 1000;
         end loop;*/

      execute immediate v_sql bulk collect
        into vr_periods;
      if (vr_periods is not null) then
        PO_Count := vr_periods.count;
        -- dbms_output.put_line('vr_periods done');
        select

         'UPDATE ' || pi_Table || '
       SET    ' || PI_Effective_End ||
         ' = :1
       WHERE  ROW_IDENTIFIER = :2'
          into v_update
          from dual;

        FORALL i IN vr_periods.first .. vr_periods.last EXECUTE IMMEDIATE
                                        v_update USING vr_periods(i)
                                       .end_calulate, vr_periods(i)
                                       .ROW_IDENTIFIER
          ;
      end if;

    end if;
    /*
    if(PI_Commit=1) then

    commit;

    end if;*/

  end COMMON_CLOSING_END;

  FUNCTION GET_COL_NULLABILITY(pi_TABLE IN VARCHAR2)
    RETURN COLTYPE_COLUMN_NULLABILITY IS
    v_COL_NULLABILITY COLTYPE_COLUMN_NULLABILITY;
  BEGIN
    --dbms_output.put_line ('1');
    SELECT OBJTYPE_COLUMN_NULLABILITY(tc.tc_physical_name,
                                      tc.tc_is_nullable)
      BULK COLLECT
      INTO v_COL_NULLABILITY
      FROM table_columns tc
     INNER JOIN tables t
        ON t.tables_id = tc.tc_tables_id
     WHERE t.tables_physical_name = UPPER(pi_TABLE);

    --dbms_output.put_line (v_COL_NULLABILITY.count);
    IF v_COL_NULLABILITY.COUNT = 0 THEN
      --dbms_output.put_line ('2');
      SELECT OBJTYPE_COLUMN_NULLABILITY(column_name,
                                        TO_NUMBER(DECODE(nullable,
                                                         'Y',
                                                         1,
                                                         'N',
                                                         0)))
        BULK COLLECT
        INTO v_COL_NULLABILITY
        FROM user_tab_columns
       WHERE TABLE_NAME = UPPER(pi_TABLE);
    END IF;

    --dbms_output.put_line ('3');
    RETURN v_COL_NULLABILITY;
  END GET_COL_NULLABILITY;

  Function GET_COLUMN_CHARACTERISTICS(pi_TABLE IN varchar2)
    return COLTYPE_COLUMN_CHARACTERISTICS is

    v_COLUMN_CHARACTERISTICS COLTYPE_COLUMN_CHARACTERISTICS;
  begin
    --dbms_output.put_line ('1');
    --Sagar
    --insert_logs(PI_CLOB => 'GET_COLUMN_CHARACTERISTICS called');
    select OBJTYPE_COLUMN_CHARACTERISTICS(tc.tc_physical_name,
                                          tc.tc_is_nullable,
                                          f.fld_data_type)
      bulk collect
      into v_COLUMN_CHARACTERISTICS
      from table_columns tc
     inner join tables t
        on t.tables_id = tc.tc_tables_id
      left join fields f
        on tc.tc_fld_id = f.fld_id
     where t.tables_physical_name = upper(pi_TABLE);
    --dbms_output.put_line (v_COL_NULLABILITY.count);
    if v_COLUMN_CHARACTERISTICS.count = 0 then
      --dbms_output.put_line ('2');
      select OBJTYPE_COLUMN_CHARACTERISTICS(utc.column_name,
                                            to_number(decode(utc.nullable,
                                                             'Y',
                                                             1,
                                                             'N',
                                                             0)),
                                            decode(utc.DATA_TYPE,
                                                   'VARCHAR2',
                                                   1,
                                                   'NUMBER',
                                                   6,
                                                   'DATE',
                                                   3,
                                                   'TIMESTAMP(6)',
                                                   5,
                                                   'TIMESTAMP',
                                                   5,
                                                   'CLOB',
                                                   1,
                                                   null))
        bulk collect
        into v_COLUMN_CHARACTERISTICS
        from user_tab_columns utc
       where TABLE_NAME = upper(pi_TABLE);

    end if;
    --dbms_output.put_line ('3');
    return v_COLUMN_CHARACTERISTICS;

  end GET_COLUMN_CHARACTERISTICS;
  PROCEDURE COMMON_OVERLAP(pi_Dest_Table      IN VARCHAR2,
                           pi_QI_Table        IN VARCHAR2,
                           pi_key_Fields      IN VARCHAR2,
                           PI_Effective_Start IN VARCHAR2,
                           PI_Effective_End   IN VARCHAR2,
                           PI_Is_Period       IN number,
                           PI_TU_ID           IN number,
                           PI_Is_Recreate     IN number,
                           po_Overlap_Chk_Res OUT NUMBER,
                           PI_INPUT_COUNT     IN NUMBER DEFAULT NULL) IS

    v_KEY_COLS       clob := PI_Key_Fields || ',';
    v_JOIN_CONDITION VARCHAR2(32767) := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';
    V_OVERLAP_RESULT Number;
    v_Intenal_query  clob;
    l_offset         number default 1;
    v_Dest_Table     varchar2(1000);
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           sys_refcursor;
    v_KEY_FIELDS     clob := '''' || replace(pi_KEY_FIELDS, ',', ''',''') || '''';

    --Checking the Columns data type
    v_data_type number;

  begin

    --Sagar
    --insert_logs(PI_CLOB => 'COMMON_OVERLAP called');
    if (pi_KEY_FIELDS is null) then
      v_JOIN_CONDITION := null;

    else

      --Change in Key fields in list
      open cv_sql for '
select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_Dest_Table || ''')) t
  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';

      loop
        fetch cv_sql
          into v_COL_NAME, v_IS_NULLABLE, v_data_type;
        EXIT WHEN cv_sql%NOTFOUND;

        -- if fields are Character or Note
        v_JOIN_CONDITION := v_JOIN_CONDITION || CASE
                              WHEN v_IS_NULLABLE = 0 THEN --required column

                               CASE
                                 WHEN v_data_type in (1, 4) THEN --note or chracter

                                  ' UPPER(a.' || v_COL_NAME || ') = UPPER(b.' ||
                                  v_COL_NAME || ')'

                               --end of addition by pramod
                                 ELSE
                                  '  a.' || v_COL_NAME || ' = b.' || v_COL_NAME
                               end
                              ELSE
                               nvl_check(v_col_name, v_data_type)

                            END || ' and ';

      END LOOP;
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION,
                                 1,
                                 LENGTH(v_JOIN_CONDITION) - 4);

    end if;

    --DBMS_OUTPUT.PUT_LINE(v_JOIN_CONDITION);

    if (PI_Is_Recreate = 0) then
      select '( Select 1 to_calculate,' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || pi_Dest_Table || ' Dest where not exists
( select ' || case
                when PI_INPUT_COUNT is not null then
                 '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

              end || ' 1 from ' || pi_QI_Table ||
              ' Qi where Qi.row_identifier=Dest.row_identifier )) '

        into v_Dest_Table
        from dual;
    elsif (PI_Is_Recreate = 1) then
      select pi_Dest_Table into v_Dest_Table from dual;
    end if;

    /*
    '||decode(PI_Is_Recreate,1,' where 1=2 ',null)||'*/
    if (PI_is_Period = 0) then
      select '
with Table_Check as
 (

  select /*+ materialize */ rownum as row_number,
          T.*, ' || PI_Effective_Start || ' start_given,' || case
                when PI_Is_Recreate = 0 then
                 '
          decode(to_calculate,1,decode(' || PI_Effective_End || ',
                 null,
                  LEAD(' || PI_Effective_Start ||
                 ') OVER(partition by ' ||
                 nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                            PI_COL_LIST   => pi_key_Fields),
                     ' NULL ') || ' order by ' || PI_Effective_Start ||
                 ' nulls first ) - 1,' || PI_Effective_End || '),0,' ||
                 PI_Effective_End || ' ) '
                else
                 PI_Effective_End
              end || ' AS end_calulated

    from (select to_calculate, ' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) || '
              from ' || decode(PI_Is_Recreate,
                                            0,
                                            v_Dest_Table || ' IP
           union all',
                                            ' ( ') || '
           select ' || case
                when PI_INPUT_COUNT is not null then
                 '/*+  CARDINALITY(OP ' || PI_INPUT_COUNT || ') */ '

              end || '  0 to_calculate,' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || pi_QI_Table || ' OP ) ' ||
              decode(PI_Is_Recreate, 0, ' ', ' ) ') || ' T)

--select * from Table_Check
,'
        into v_Intenal_query
        from dual;

    elsif (PI_is_Period = 1) then
      select '

with Table_Check_partial as
 (select ' || case
                when PI_Is_Recreate = 0 then
                 '/*+ materialize */'
              end || 'rownum as row_number,
         T_Temp.*,
         T_Temp.tupr_start_date start_given,' || case
                when PI_Is_Recreate = 0 then
                 '
          decode(to_calculate,1,
         LEAD(T_Temp.tupr_start_date) OVER(partition by ' ||
                 nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                            PI_COL_LIST   => pi_key_Fields),
                     ' NULL ') ||
                 ' order by T_Temp.tupr_start_date nulls first) ,0,T_Temp.tupr_start_date)  '
                else
                 ' T_Temp.tupr_end_date '
              end || ' end_calulated_partial
     from (

          select Temp.*,
                  tupr_start.TUPR_start_date TUPR_start_date,
                  tupr_end.tupr_end_date     tupr_end_date,
                  tupr_start.TUPR_id         TUPR_start_id,
                  tupr_end.tupr_id           tupr_end_id

            from (select to_calculate,' || PI_Effective_Start ||
              ' , ' || PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || decode(PI_Is_Recreate,
                                 0,
                                 v_Dest_Table || ' IP
           union all',
                                 ' ( ') || '
                   select ' || case
                when PI_INPUT_COUNT is not null then
                 '/*+  CARDINALITY(OP ' || PI_INPUT_COUNT || ') */ '

              end || ' 0 to_calculate,' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || pi_QI_Table || ' OP )' ||
              decode(PI_Is_Recreate, 0, ' ', ' ) ') ||
              ' Temp
            left outer join tu_periods_range tupr_start
              on tupr_start.TUPR_ID = Temp.' ||
              PI_Effective_Start || '
            left outer join tu_periods_range tupr_end
              on tupr_end.TUPR_ID = Temp.' || PI_Effective_End ||
              ') T_Temp)
--select * from Table_Check_partial
,'
        into v_Intenal_query
        from dual;

      v_Intenal_query := v_Intenal_query || '

Table_Check as

 (

  select /*+ materialize */ T.*,' || case
                           when PI_Is_Recreate = 0 then
                            ' (select tupr_end_date
             from tu_periods_range
            where tupr_id in (
             decode(to_calculate,1,
            decode(tupr_end_id,
                                     null,
                                     commons_timeunits.Get_nth_prior_period(' ||
                            PI_TU_ID || ',
                                                                            (select tupr_id
                                                                               from tu_periods_range
                                                                              where tupr_start_date =
                                                                                    end_calulated_partial
                                                                                and tupr_tu_id =' ||
                            PI_TU_ID || '

                                                                             ),
                                                                            1,
                                                                            2010,
                                                                            2025),
                                     tupr_end_id),tupr_end_id)

                                     ))'
                           else
                            ' end_calulated_partial '
                         end || ' end_calulated
    from Table_Check_partial T

  ),

 ';

    end if;

    select v_Intenal_query || '

Overlap_check as
 (SELECT COUNT(*) FROM DUAL WHERE EXISTS
   (select /*+ USE_HASH(a,b) */ 1
            from Table_Check a, Table_Check b
           where ' ||
            decode(v_JOIN_CONDITION, null, null, v_JOIN_CONDITION || ' and ') || '
              (a.row_number <> b.row_number and
                 (
                 nvl(a.start_given,
                      to_date(''1 / 1 / 1900 '', ''mm / dd / yyyy '')) <=
                 nvl(b.end_calulated,
                      to_date('' 12 / 31 / 9999 '', '' mm / dd / yyyy ''))
                      and
                 nvl(a.end_calulated,
                      to_date('' 12 / 31 / 9999 '', '' mm / dd / yyyy '')) >=
                 nvl(b.start_given,
                      to_date('' 1 / 1 / 1900 '', '' mm / dd / yyyy ''))
                      )

                      )
                      )

  )

  select * from Overlap_check'
      into v_Intenal_query
      from dual;

    /* loop
        exit when l_offset > dbms_lob.getlength(v_Intenal_query);
        dbms_output.put_line(dbms_lob.substr(v_Intenal_query, 999, l_offset));
        l_offset := l_offset + 999;
      end loop;
      l_offset := 1;
    */
    --  DBMS_OUTPUT.PUT_LINE(v_OVERLAP_STR);

    --Sagar
    --commons_utils.insert_logs(PI_CLOB => 'v_Intenal_query '||v_Intenal_query);
    EXECUTE IMMEDIATE v_Intenal_query
      INTO V_OVERLAP_RESULT;
    -- Overlap check
    IF V_OVERLAP_RESULT = 1 THEN
      po_OVERLAP_CHK_RES := 0;
    ELSE
      po_OVERLAP_CHK_RES := 1;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN

      /*commons_utils.insert_logs(PI_CLOB => 'v_Intenal_query ' ||
      v_Intenal_query);*/
      IF cv_sql%ISOPEN THEN

        CLOSE cv_sql;
      END IF;
      raise;
      --raise_application_error(-20101,'COMMON_OVERLAP_CHECK encountered an error');*/
  end COMMON_OVERLAP;

  PROCEDURE COMMON_OVERLAP_CHECK(pi_TABLE           IN VARCHAR2,
                                 pi_TABLE_CLOB      IN CLOB,
                                 pi_KEY_FIELDS      IN CLOB,
                                 PI_effective_start IN VARCHAR2,
                                 PI_effective_end   IN VARCHAR2,
                                 PI_is_Period       IN number,
                                 PI_ID_COLUMN       IN VARCHAR2,
                                 po_OVERLAP_CHK_RES OUT NUMBER,
                                 PI_INPUT_COUNT     IN NUMBER DEFAULT NULL) IS

    v_KEY_COLS       clob := PI_Key_Fields || ',';
    v_JOIN_CONDITION CLOB := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';
    V_OVERLAP_RESULT Number;
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           sys_refcursor;
    v_KEY_FIELDS     clob := '''' || replace(pi_KEY_FIELDS, ',', ''',''') || '''';
    v_table          CLOB;
    --Checking the Columns data type
    v_data_type     number;
    v_fld_data_type number;
    v_check         number;
  begin
    --Sagar
    --insert_logs(PI_CLOB => 'COMMON_OVERLAP_CHECK called');
    --insert_logs(PI_CLOB => 'pi_TABLE '|| pi_TABLE);
    --insert_logs(PI_CLOB => 'pi_TABLE_CLOB '|| pi_TABLE_CLOB);

    if (pi_TABLE_CLOB is null) then

      v_table := pi_TABLE;

    else

      v_table := pi_TABLE_CLOB;

    end if;

    if (pi_KEY_FIELDS is null) then
      v_JOIN_CONDITION := null;

    else

      v_JOIN_CONDITION := ' and ';

      -- Create the string v_JOIN_CONDITION (logic to parse comma separated pi_KEY_FIELDS)
      --insert_logs(PI_CLOB => 'select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_TABLE || ''')) t  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')');

      open cv_sql for 'select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_TABLE || ''')) t
  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';

      /*  open cv_sql for '
      select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
        from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_TABLE || ''')) t
        where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';
          */

      loop
        fetch cv_sql
          into v_COL_NAME, v_IS_NULLABLE, v_data_type;
        EXIT WHEN cv_sql%NOTFOUND;

        -- if fields are Character or Note
        /*    if v_data_type in( 1,4) then
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( UPPER(a.' ||
                              v_COL_NAME || ') = UPPER(b.' || v_COL_NAME || '))' || case
                                when v_IS_NULLABLE = 1 then
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' || v_COL_NAME ||
                                 ' IS NULL )'
                              end || ') and';
        else
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( a.' || v_COL_NAME || ' = b.' ||
                              v_COL_NAME || ')' || case
                                when v_IS_NULLABLE = 1 then
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                                 v_COL_NAME || ' IS NULL )'
                              end || ') and';
        end if;*/

        v_JOIN_CONDITION := v_JOIN_CONDITION || CASE
                              WHEN v_IS_NULLABLE = 0 THEN --required column

                               CASE
                                 WHEN v_data_type in (1, 4) THEN --note or chracter

                                  ' UPPER(a.' || v_COL_NAME || ') = UPPER(b.' ||
                                  v_COL_NAME || ')'

                               --end of addition by pramod
                                 ELSE
                                  '  a.' || v_COL_NAME || ' = b.' || v_COL_NAME
                               end
                              ELSE
                               nvl_check(v_col_name, v_data_type)

                            END || ' and ';
      END LOOP;
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION,
                                 1,
                                 LENGTH(v_JOIN_CONDITION) - 4);

    end if;

    -- /*+ USE_HASH(a,b) */
    --DBMS_OUTPUT.PUT_LINE(v_JOIN_CONDITION);
    -- Overlap and date check
    if (PI_is_Period = 0) then
      v_OVERLAP_STR := 'SELECT   COUNT(*) FROM DUAL WHERE EXISTS(
select ' || '/*+ USE_HASH(a,b) ' || case
                         when PI_INPUT_COUNT is not null then
                          ' CARDINALITY(a ' || PI_INPUT_COUNT ||
                          ') CARDINALITY(b ' || PI_INPUT_COUNT || ') '

                       end || ' */ ' || ' a.*
  from ' || v_table || ' a, ' || v_table || ' b
  where (((nvl(a.' || PI_effective_start ||
                       ', to_date(''01/01/0001'', ''dd/mm/yyyy'')) between  nvl(b.' ||
                       PI_effective_start ||
                       ', to_date(''01/01/0001'', ''dd/mm/yyyy'')) and
                                                                                                nvl(b.' ||
                       PI_effective_end || ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) or
          nvl(a.' || PI_effective_end ||
                       ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) between nvl(b.' ||
                       PI_effective_start ||
                       ', to_date(''01/01/0001'', ''dd/mm/yyyy'')) and
                                                                                           nvl(b.' ||
                       PI_effective_end ||
                       ', to_date(''31/12/9999'', ''dd/mm/yyyy''))) and' ||
                       ' a.' || PI_ID_COLUMN || ' <> b.' || PI_ID_COLUMN ||
                       ')  )  ' || v_JOIN_CONDITION || ')';

    elsif (PI_is_Period = 1) then

      v_OVERLAP_STR := 'SELECT  COUNT(*)  FROM DUAL WHERE EXISTS (select ' ||
                       '/*+ USE_HASH(a,b) ' || case
                         when PI_INPUT_COUNT is not null then
                          ' CARDINALITY(a ' || PI_INPUT_COUNT ||
                          ') CARDINALITY(b ' || PI_INPUT_COUNT || ') '

                       end || ' */ ' || '  a.* from ' || v_table || ' a,' ||
                       v_table || ' b, tu_periods_range a_tupr_start,
               tu_periods_range a_tupr_end,
                tu_periods_range b_tupr_start,
               tu_periods_range b_tupr_end
         where (((nvl(a_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy'')) between
               nvl(b_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy'')) and
               nvl(b_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy''))
               or
               nvl(a_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy'')) between
               nvl(b_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy'')) and
               nvl(b_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy''))) and
               a.' || PI_ID_COLUMN || ' <> b.' ||
                       PI_ID_COLUMN || ')
               and
               a.' || PI_effective_start ||
                       ' = a_tupr_start.tupr_id(+) and
               a.' || PI_effective_end ||
                       ' = a_tupr_end.tupr_id(+) and
               b.' || PI_effective_start ||
                       ' = b_tupr_start.tupr_id(+) and
               b.' || PI_effective_end ||
                       '= b_tupr_end.tupr_id(+)
               )
                 ' || v_JOIN_CONDITION || ')';

    end if;

    --dbms_output.put_line(v_OVERLAP_STR);
    -- insert_logs(PI_CLOB => 'v_OVERLAP_STR '|| v_OVERLAP_STR);
    EXECUTE IMMEDIATE v_OVERLAP_STR
      INTO V_OVERLAP_RESULT;
    -- Overlap check
    IF V_OVERLAP_RESULT = 1 THEN
      po_OVERLAP_CHK_RES := 0;
    ELSE
      po_OVERLAP_CHK_RES := 1;
    END IF;
  exception
    when others then
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      raise;
  end COMMON_OVERLAP_CHECK;

  PROCEDURE COMMON_OVERLAP_CHECK(pi_TABLE           IN VARCHAR2,
                                 pi_KEY_FIELDS      IN CLOB,
                                 PI_effective_start IN VARCHAR2,
                                 PI_effective_end   IN VARCHAR2,
                                 PI_is_Period       IN number,
                                 po_OVERLAP_CHK_RES OUT NUMBER

                                 ) IS
  begin
    COMMON_OVERLAP_CHECK(pi_TABLE           => pi_TABLE,
                         pi_TABLE_CLOB      => null,
                         pi_KEY_FIELDS      => pi_KEY_FIELDS,
                         PI_effective_start => PI_effective_start,
                         PI_effective_end   => PI_effective_end,
                         PI_is_Period       => PI_is_Period,
                         PI_ID_COLUMN       => 'ROW_IDENTIFIER',
                         po_OVERLAP_CHK_RES => po_OVERLAP_CHK_RES);

  end COMMON_OVERLAP_CHECK;

  PROCEDURE COMMON_OVERLAP_POST(pi_TABLE           IN VARCHAR2,
                                pi_TABLE_CLOB      IN CLOB,
                                pi_KEY_FIELDS      IN CLOB,
                                pi_DATA_FIELDS     IN CLOB,
                                PI_effective_start IN VARCHAR2,
                                PI_effective_end   IN VARCHAR2,
                                PI_is_Period       IN number,
                                PI_ID_COLUMN       IN VARCHAR2,
                                po_OVERLAP_CHK_RES OUT NUMBER,
                                PI_INPUT_COUNT     IN NUMBER DEFAULT NULL,
                                PI_OVERLAP_TABLE   IN varchar2 DEFAULT NULL,
                                PI_ADD_LOG_INFO    IN COLTYPE_KEY_VALUE default null) IS

    v_KEY_COLS       clob := PI_Key_Fields || ',';
    v_JOIN_CONDITION CLOB := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';
    V_OVERLAP_RESULT Number;
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           sys_refcursor;
    v_KEY_FIELDS     clob := '''' || replace(pi_KEY_FIELDS, ',', ''',''') || '''';
    v_table          CLOB;
    v_insert_part    clob;
    v_post_select    clob;
    --Checking the Columns data type
    v_data_type     number;
    v_fld_data_type number;
    v_check         number;
    v_sql_temp      clob;
    v_col_list      varchar2(4000);
    v_val_list      varchar2(4000);
    v_select_value  varchar2(4000);
    v_AV_max_value  number;
    v_av_col_name   varchar2(30 char);
    v_ovr_tables_id number;
    v_data_fields   CLOB := '';
  begin
    --Sagar
    --insert_logs(PI_CLOB => 'COMMON_OVERLAP_CHECK called');
    --  insert_logs(PI_CLOB => 'pi_TABLE '|| pi_TABLE);
    --  insert_logs(PI_CLOB => 'pi_data_Fields '|| pi_data_Fields);
    --insert_logs(PI_CLOB => 'pi_TABLE_CLOB '|| pi_TABLE_CLOB);

    if (pi_TABLE_CLOB is null) then

      v_table := pi_TABLE;

    else

      v_table := pi_TABLE_CLOB;

    end if;

    if (PI_ADD_LOG_INFO is not null) then

      FOR i IN 1 .. PI_ADD_LOG_INFO.COUNT LOOP
        --DBMS_OUTPUT.PUT_LINE('INSIDE LOOP');
        v_col_list := v_col_list || PI_ADD_LOG_INFO(i).v_key || ',';
        /*v_val_list:= v_val_list ||case when PI_ADD_LOG_INFO(i).v_value='autonumber' then PI_ADD_LOG_INFO(i).v_key else PI_ADD_LOG_INFO(i).v_value end|| ',';*/
        /* v_val_list := v_val_list || case
          when PI_ADD_LOG_INFO(i).v_value = 'autonumber' then
           PI_ADD_LOG_INFO(i).v_key
          else
           PI_ADD_LOG_INFO(i).v_value
        end || ',';*/
        --v_val_list:= v_val_list || PI_ADD_LOG_INFO(i).v_value || ',';
        if PI_ADD_LOG_INFO(i).v_value = 'autonumber' then
          select tables_ID
            into v_ovr_tables_id
            from tables
           where tables_physical_name = PI_OVERLAP_TABLE;
          v_AV_max_value := COMMONS_TABLES.GET_AUTO_VALUE(v_ovr_tables_id);
          v_select_value := v_select_value || to_char(v_AV_max_value) ||
                            '+rownum-1 ' || PI_ADD_LOG_INFO(i).v_key || ',';

          v_av_col_name := PI_ADD_LOG_INFO(i).v_key;

          --v_select_value:=' 1+rownum v_num, ';
        else
          v_select_value := v_select_value || /*''''||*/
                            PI_ADD_LOG_INFO(i).v_value || ' ' || PI_ADD_LOG_INFO(i)
                           .v_key || ',';

        end if;
      end loop;

    end if;

    FOR CUR IN (SELECT PIF.column_value COLUMN_NAME, F.FLD_DATA_TYPE
                  FROM TABLE(COMMA_TO_TABLE(PI_DATA_FIELDS)) PIF
                  LEFT OUTER JOIN FIELDS F
                    ON F.FLD_COLUMN_NAME = PIF.column_value) LOOP
      IF cur.FLD_DATA_TYPE = 9 THEN
        V_DATA_FIELDS := V_DATA_FIELDS || 'a.' || CUR.COLUMN_NAME ||
                         '.getstringval() ' || CUR.COLUMN_NAME || ',';
      ELSE
        V_DATA_FIELDS := V_DATA_FIELDS || 'a.' || CUR.COLUMN_NAME || ',';
      END IF;
    END LOOP;
    V_DATA_FIELDS := rtrim(V_DATA_FIELDS, ',');

    if (pi_KEY_FIELDS is null) then
      v_JOIN_CONDITION := null;

      /*     v_insert_part := ' insert into ' || PI_OVERLAP_TABLE || ' ('
      ||case when v_col_list is not null then v_col_list||',' end||' row_identifier,row_version,' ||
                        pi_data_Fields || PI_Effective_Start || \*','||PI_Effective_END||*\
                        ',DLP_EXISTING_RECORD) ';*/
      v_insert_part := ' insert into ' || PI_OVERLAP_TABLE || ' (' ||
                       v_col_list || 'row_identifier,row_version,' ||
                       pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD) ';
      v_sql_temp    := pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD/*,row_identifier,row_version*/ ';
      --v_post_select :=  /*case when pi_data_Fields is null then*/
      -- 'a.' /*end*/
      --                || replace(pi_data_Fields, ',', ',a.') || /*'a.'||*/
      --                 PI_Effective_Start || /*',a.'||PI_Effective_END||*/
      --                 ',0 DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';
      V_POST_SELECT := V_DATA_FIELDS || PI_EFFECTIVE_START ||
                       ',0 DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';

    else

      /* v_insert_part := ' insert into ' || PI_OVERLAP_TABLE || ' ('
      ||case when v_col_list is not null then v_col_list||',' end||'row_identifier,row_version,' ||
                        pi_data_Fields || PI_Effective_Start || \*','||PI_Effective_END||*\
                        ',DLP_EXISTING_RECORD' || ',' ||
                        pi_KEY_FIELDS || ') ';*/
      v_insert_part := ' insert into ' || PI_OVERLAP_TABLE || ' (' ||
                       v_col_list || 'row_identifier,row_version,' ||
                       pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD' || ',' || pi_KEY_FIELDS || ') ';
      v_sql_temp    := pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD/*,row_identifier,row_version*/' || ',' ||
                       pi_KEY_FIELDS;
      --v_post_select :=  /*case when pi_data_Fields is null then*/
      -- 'a.' /*end*/
      --                 || replace(pi_data_Fields, ',', ',a.') || /*'a.'||*/
      --                PI_Effective_Start || /*',a.'||PI_Effective_END||*/
      --                 ',0 DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';
      V_POST_SELECT    := V_DATA_FIELDS || PI_EFFECTIVE_START ||
                          ',0 DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';
      v_JOIN_CONDITION := ' and ';

      -- Create the string v_JOIN_CONDITION (logic to parse comma separated pi_KEY_FIELDS)
      --insert_logs(PI_CLOB => 'select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_TABLE || ''')) t  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')');

      open cv_sql for 'select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_TABLE || ''')) t
  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';

      /*  open cv_sql for '
      select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
        from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_TABLE || ''')) t
        where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';
          */

      loop
        fetch cv_sql
          into v_COL_NAME, v_IS_NULLABLE, v_data_type;
        EXIT WHEN cv_sql%NOTFOUND;
        v_post_select := v_post_select || ',a.' || v_COL_NAME;
        -- if fields are Character or Note
        /*    if v_data_type in( 1,4) then
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( UPPER(a.' ||
                              v_COL_NAME || ') = UPPER(b.' || v_COL_NAME || '))' || case
                                when v_IS_NULLABLE = 1 then
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' || v_COL_NAME ||
                                 ' IS NULL )'
                              end || ') and';
        else
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( a.' || v_COL_NAME || ' = b.' ||
                              v_COL_NAME || ')' || case
                                when v_IS_NULLABLE = 1 then
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                                 v_COL_NAME || ' IS NULL )'
                              end || ') and';
        end if;*/

        v_JOIN_CONDITION := v_JOIN_CONDITION || CASE
                              WHEN v_IS_NULLABLE = 0 THEN --required column

                               CASE
                                 WHEN v_data_type in (1, 4) THEN --note or chracter

                                  ' UPPER(a.' || v_COL_NAME || ') = UPPER(b.' ||
                                  v_COL_NAME || ')'

                               --end of addition by pramod
                                 ELSE
                                  '  a.' || v_COL_NAME || ' = b.' || v_COL_NAME
                               end
                              ELSE
                               nvl_check(v_col_name, v_data_type)

                            END || ' and ';
      END LOOP;
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION,
                                 1,
                                 LENGTH(v_JOIN_CONDITION) - 4);

    end if;

    -- /*+ USE_HASH(a,b) */
    --DBMS_OUTPUT.PUT_LINE(v_JOIN_CONDITION);
    -- Overlap and date check
    if (PI_is_Period = 0) then
      v_OVERLAP_STR := 'select  ' || case
                         when PI_OVERLAP_TABLE is null then
                          'rownum'
                         else
                          v_select_value || PI_OVERLAP_TABLE ||
                          '_row_identifier_seq.nextval'
                       end || ' row_identifier,
                0 row_version,' || v_sql_temp ||
                       ' from (
  select distinct ' || v_sql_temp || ' from ' || '/*SELECT   COUNT(*) FROM DUAL WHERE EXISTS*/(
select ' || '/*+ USE_HASH(a,b) ' || case
                         when PI_INPUT_COUNT is not null then
                          ' CARDINALITY(a ' || PI_INPUT_COUNT ||
                          ') CARDINALITY(b ' || PI_INPUT_COUNT || ') '

                       end || ' */ ' || '  /*a.**/ ' || v_post_select ||
                       ' from ' || v_table || ' a, ' || v_table || ' b
  where ((
  (
  nvl(a.' || PI_effective_start ||
                       ', to_date(''01/01/0001'', ''dd/mm/yyyy''))  <=  nvl(b.' ||
                       PI_effective_end || ', to_date(''31/12/9999'', ''dd/mm/yyyy''))

                       and

          nvl(a.' || PI_effective_end ||
                       ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) >= nvl(b.' ||
                       PI_effective_start || ', to_date(''01/01/0001'', ''dd/mm/yyyy''))

                       ) and' || ' a.' || PI_ID_COLUMN ||
                       ' <> b.' || PI_ID_COLUMN || ')  )  ' || v_JOIN_CONDITION || ')' ||
                       ' )T';

    elsif (PI_is_Period = 1) then

      v_OVERLAP_STR := 'select  ' || case
                         when PI_OVERLAP_TABLE is null then
                          'rownum'
                         else
                          v_select_value || PI_OVERLAP_TABLE ||
                          '_row_identifier_seq.nextval'
                       end || ' row_identifier,
                0 row_version,' || v_sql_temp ||
                       ' from (
  select distinct ' || v_sql_temp || ' from ' ||
                       '/*SELECT  COUNT(*)  FROM DUAL WHERE EXISTS */(select ' ||
                       '/*+ USE_HASH(a,b) ' || case
                         when PI_INPUT_COUNT is not null then
                          ' CARDINALITY(a ' || PI_INPUT_COUNT ||
                          ') CARDINALITY(b ' || PI_INPUT_COUNT || ') '

                       end || ' */ ' || '  /*a.**/ ' || v_post_select ||
                       ' from ' || v_table || ' a,' || v_table ||
                       ' b, tu_periods_range a_tupr_start,
               tu_periods_range a_tupr_end,
                tu_periods_range b_tupr_start,
               tu_periods_range b_tupr_end
         where ((
         (
         nvl(a_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy''))  <=
               nvl(b_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy''))
               and
               nvl(a_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy'')) >=
               nvl(b_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy''))

               ) and
               a.' || PI_ID_COLUMN || ' <> b.' ||
                       PI_ID_COLUMN || ')
               and
               a.' || PI_effective_start ||
                       ' = a_tupr_start.tupr_id(+) and
               a.' || PI_effective_end ||
                       ' = a_tupr_end.tupr_id(+) and
              b.' || PI_effective_start ||
                       ' = b_tupr_start.tupr_id(+) and
               b.' || PI_effective_end ||
                       '= b_tupr_end.tupr_id(+)
               )
                 ' || v_JOIN_CONDITION || ')' || ' )T';

    end if;
    --insert_logs(PI_CLOB => 'v_OVERLAP_STR '|| v_OVERLAP_STR);

    v_OVERLAP_STR := v_insert_part || v_OVERLAP_STR;

    --dbms_output.put_line(v_OVERLAP_STR);
    --insert_logs(PI_CLOB => 'v_OVERLAP_STR '|| v_OVERLAP_STR);
    /*   EXECUTE IMMEDIATE v_OVERLAP_STR \* INTO V_OVERLAP_RESULT*\;*/

    /*commons_utils.INSERT_LOGS(PI_CLOB => 'v_OVERLAP_STR ' || v_OVERLAP_STR);*/
    /*  commons_ddl_handling.execute_ddl_nolog(v_OVERLAP_STR);*/
    commons_ddl_handling.execute_ddl_nolog_rowcount(pi_ddl      => v_OVERLAP_STR,
                                                    pi_to_trace => 1,
                                                    po_rowcount => V_OVERLAP_RESULT);

    if (PI_ADD_LOG_INFO is not null) then

      execute immediate '
  select nvl(max(' || v_av_col_name || '),0)  from ' ||
                        PI_OVERLAP_TABLE
        into v_AV_max_value;
      /* COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => v_ovr_tables_id,
      pi_value    => v_AV_max_value);  */

      commons_ddl_handling.execute_ddl_nolog('begin
COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => ' ||
                                             v_ovr_tables_id || ',
                                    pi_value    => ' ||
                                             v_AV_max_value || ');

                                    end;');
    end if;

    commit;

    -- Overlap check
    /* v_OVERLAP_STR := 'select count(*) from dual where exists (select 1 from ' ||
                         PI_OVERLAP_TABLE || ' where rownum=1 )';
    --  INSERT_LOGS(PI_CLOB => 'v_OVERLAP_STR ' || v_OVERLAP_STR);
      EXECUTE IMMEDIATE v_OVERLAP_STR
        INTO V_OVERLAP_RESULT;*/

    IF V_OVERLAP_RESULT = 0 THEN
      po_OVERLAP_CHK_RES := 1;
    ELSE
      po_OVERLAP_CHK_RES := 0;
    END IF;
  exception
    when others then
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      --commons_utils.INSERT_LOGS(PI_CLOB => 'v_OVERLAP_STR ' || v_OVERLAP_STR);
      --commons_utils.INSERT_LOGS(PI_CLOB => 'v_AV_max_value ' || v_AV_max_value);
      --commons_utils.INSERT_LOGS(PI_CLOB => 'v_ovr_tables_id ' || v_ovr_tables_id);
      raise;
  end COMMON_OVERLAP_POST;

  PROCEDURE COMMON_DATE_RANGE_CHECK(pi_TABLE           IN VARCHAR2,
                                    PI_effective_start IN VARCHAR2,
                                    PI_effective_end   IN VARCHAR2,
                                    PI_is_Period       IN number,
                                    po_DATE_RANGE_RES  OUT NUMBER) IS

    v_EFF_CONDITION clob;
    v_EFF_RESULT    number;

  begin

    if (PI_is_Period = 0) then

      v_EFF_CONDITION := 'SELECT COUNT(*) FROM DUAL WHERE EXISTS
(SELECT * FROM ' || pi_TABLE || ' WHERE  NVL(' ||
                         PI_effective_start ||
                         ',to_date(''01/01/0001'', ''dd/mm/yyyy''))' ||
                         ' > NVL(' || PI_effective_end ||
                         ',to_date(''31/12/9999'', ''dd/mm/yyyy'')))';
      --      DBMS_OUTPUT.PUT_LINE(v_EFF_CONDITION);

    elsif (PI_is_Period = 1) then
      v_EFF_CONDITION := 'SELECT COUNT(*) FROM DUAL WHERE EXISTS
(SELECT * FROM ' || pi_TABLE ||
                         ' IP,tu_periods_range tupr_start,tu_periods_range tupr_end WHERE
                     tupr_start.tupr_id(+)=IP.' ||
                         PI_effective_start ||
                         ' and tupr_end.tupr_id(+)=IP.' || PI_effective_end ||
                         ' and    NVL(tupr_start.tupr_start_date' ||
                         ',to_date(''01/01/0001'', ''dd/mm/yyyy''))' ||
                         ' > NVL(tupr_end.tupr_end_date' ||
                         ',to_date(''31/12/9999'', ''dd/mm/yyyy'')))';

    END IF;

    --    dbms_output.put_line(v_EFF_CONDITION);
    EXECUTE IMMEDIATE v_EFF_CONDITION
      into v_EFF_RESULT;
    IF (v_EFF_RESULT = 0) THEN

      po_DATE_RANGE_RES := 1;

    ELSIF (v_EFF_RESULT = 1) THEN

      po_DATE_RANGE_RES := 0;
    END IF;

  EXCEPTION

    WHEN OTHERS THEN

      raise_application_error(-20101,
                              'Common_DATE_RANGE_CHECK encountered an error');

  END COMMON_DATE_RANGE_CHECK;

  PROCEDURE COMMON_UNIQUE_CHECK(pi_TABLE          IN VARCHAR2,
                                pi_KEY_FIELDS     IN VARCHAR2,
                                po_UNIQUE_CHK_RES OUT NUMBER,
                                PI_INPUT_COUNT    IN NUMBER DEFAULT NULL) IS

    /* v_UNIQUE_STR CLOB := '';

    v_DUPLICATE_CNT NUMBER(10);*/

  begin

    COMMON_UNIQUE_CHECK(pi_TABLE          => pi_TABLE,
                        pi_KEY_FIELDS     => pi_KEY_FIELDS,
                        pi_WHERE_CLAUSE   => null,
                        po_UNIQUE_CHK_RES => po_UNIQUE_CHK_RES,
                        PI_INPUT_COUNT    => PI_INPUT_COUNT);
    -- Unique Record validation

    /*  v_UNIQUE_STR := 'select count(*) from dual where exists(  SELECT 1 FROM ' || pi_TABLE ||
                        ' GROUP BY ' || pi_KEY_FIELDS||' having count(*)>1)';
      \* DBMS_OUTPUT.PUT_LINE(v_UNIQUE_STR);
    *\
        EXECUTE IMMEDIATE v_UNIQUE_STR
          INTO v_DUPLICATE_CNT;
     --DBMS_OUTPUT.PUT_LINE('v_DUPLICATE_CNT');
        IF v_DUPLICATE_CNT =0 THEN
          po_UNIQUE_CHK_RES := 1;
        ELSE
          po_UNIQUE_CHK_RES :=0;
        END IF;
    */
    /* EXCEPTION

    WHEN OTHERS THEN

      raise_application_error(-20101,
                              'COMMON_UNIQUE_CHECK encountered an error');*/

  end COMMON_UNIQUE_CHECK;

  PROCEDURE COMMON_UNIQUE_CHECK(pi_TABLE          IN VARCHAR2,
                                pi_KEY_FIELDS     IN VARCHAR2,
                                pi_WHERE_CLAUSE   IN VARCHAR2,
                                po_UNIQUE_CHK_RES OUT NUMBER,
                                PI_INPUT_COUNT    IN NUMBER DEFAULT NULL) IS

    v_UNIQUE_STR    CLOB;
    v_TEMP_CLOB     CLOB;
    v_DUPLICATE_CNT NUMBER(10);
    V_KEY_FIELDS    VARCHAR2(32767);

  begin

    --Sagar
    --insert_logs(PI_CLOB => 'COMMON_UNIQUE_CHECK called');

    --Sagar
    --insert_logs(PI_CLOB => 'pi_KEY_FIELDS '||pi_KEY_FIELDS);
    --Use Upper columns for VARCHAR2 fields
    V_KEY_FIELDS := UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => pi_TABLE,
                                            PI_COL_LIST   => pi_KEY_FIELDS);

    --Sagar
    --insert_logs(PI_CLOB => 'V_KEY_FIELDS '||V_KEY_FIELDS);
    -- Unique Record validation

    v_UNIQUE_STR := 'select  count(*) from dual where exists(  SELECT ' || case
                      when PI_INPUT_COUNT is not null then
                       '/*+  CARDINALITY( ' || pi_TABLE || ' ' ||
                       PI_INPUT_COUNT || ') */ '

                    end || '   1 FROM ' || pi_TABLE;

    if pi_WHERE_CLAUSE is not null then
      v_TEMP_CLOB := to_clob(' where ');

      v_UNIQUE_STR := v_UNIQUE_STR || v_TEMP_CLOB;

      v_UNIQUE_STR := v_UNIQUE_STR || pi_WHERE_CLAUSE;

    end if;

    v_TEMP_CLOB := to_clob(' GROUP BY ');

    v_UNIQUE_STR := v_UNIQUE_STR || v_TEMP_CLOB;

    v_UNIQUE_STR := v_UNIQUE_STR || V_KEY_FIELDS;

    v_TEMP_CLOB := to_clob('  having count(*)>1 )');

    v_UNIQUE_STR := v_UNIQUE_STR || v_TEMP_CLOB;

    -- dbms_output.put_line(v_UNIQUE_STR);
    --Sagar
    --insert_logs(PI_CLOB => 'v_UNIQUE_STR '||v_UNIQUE_STR);

    EXECUTE IMMEDIATE v_UNIQUE_STR
      INTO v_DUPLICATE_CNT;

    IF v_DUPLICATE_CNT = 0 THEN
      po_UNIQUE_CHK_RES := 1;
    ELSE
      po_UNIQUE_CHK_RES := 0;
    END IF;

  end COMMON_UNIQUE_CHECK;

  FUNCTION Adjustment_DateRange_Check(PI_effective_start VARCHAR2,
                                      PI_effective_end   VARCHAR2,
                                      PI_Period_check    NUMBER,
                                      PI_key_Data        IN CLOB)
    RETURN SYS_REFCURSOR AS
    /*l_offset               number default 1;*/
    v_Date_Range_Query     CLOB;
    c                      SYS_REFCURSOR;
    v_effective_start_date VARCHAR2(50) := PI_effective_start;
    v_effective_end_date   VARCHAR2(50) := PI_effective_end;
  BEGIN
    --for range of dates
    IF (PI_Period_check = 0) THEN
      v_effective_start_date := PI_effective_start;
      v_effective_end_date   := PI_effective_end;

      v_Date_Range_Query := 'select row_identifier from
              (  ' || PI_key_Data || ')
                 where (' ||
                            v_effective_start_date || ' <= ' ||
                            v_effective_end_date || ' or  ' ||
                            v_effective_start_date || ' is null or ' ||
                            v_effective_end_date ||
                            ' is null )  and  row_identifier <> 0';
      --for range of periods
    ELSIF (PI_Period_check = 1) THEN
      v_Date_Range_Query := 'select row_identifier
  from (  ' || PI_key_Data ||
                            ' ) a,
       (select tupr_start_date, tupr_id
          from tu_periods_range
         where tupr_id in (select ' ||
                            v_effective_start_date || ' from ( ' ||
                            PI_key_Data ||
                            '))) ef_st_date,

       (select tupr_end_date, tupr_id
          from tu_periods_range
         where tupr_id in (select ' ||
                            v_effective_end_date || ' from ( ' ||
                            PI_key_Data || '))) ef_ed_date

 where a.' || v_effective_start_date ||
                            ' = ef_st_date.tupr_id(+)
   and a.' || v_effective_end_date ||
                            ' = ef_ed_date.tupr_id(+)
   and ( ef_st_date.tupr_start_date <= ef_ed_date.tupr_end_date
       or ef_st_date.tupr_start_date is null or ef_ed_date.tupr_end_date is null)
   and row_identifier <> 0 ';
    END IF;

    /*loop
        exit when l_offset > dbms_lob.getlength(v_Date_Range_Query);
       dbms_output.put_line( dbms_lob.substr( v_Date_Range_Query, 255, l_offset ) );
      l_offset := l_offset + 255;
    end loop;*/
    /*  dbms_output.put_line(v_Date_Range_Query);*/
    OPEN c FOR v_Date_Range_Query;

    RETURN c;
  EXCEPTION
    WHEN OTHERS THEN
      IF (c%ISOPEN) THEN
        CLOSE c;
      END IF;

      raise_application_error(-20001, SUBSTR(SQLERRM, 1, 1000));
  END ADJUSTMENT_DATERANGE_CHECK;

  PROCEDURE Adjustment_Unique_Check(pin_table_name          VARCHAR2,
                                    pin_key_fields          VARCHAR2,
                                    pin_data                CLOB,
                                    pout_list_of_stale_ids  OUT COLTYPE_ID,
                                    pout_list_of_failed_ids OUT COLTYPE_ID) IS
    v_list_of_rejected_ids TABLETYPE_ID_NAME;
    v_sql                  CLOB;
  BEGIN
    -- Defect #13538
    -- 1. Alter Session to BINARY
    COMMONS_TABLES.ALTER_SESSION_NLS_BINARY;

    -- deshmukha added substr(column_name,1,28) at multiple places for OF-70347 in the following select
    SELECT 'with
              distinct_edited as (
                 select * from
                    (select "UpdatedInsertedFlag", row_identifier e_id, row_version, ' ||
            LISTAGG('EDITED.' || column_name || ' as e_' || substr(column_name,1,28), ',') WITHIN GROUP(ORDER BY NULL) || '
                           , count(row_identifier) over (partition by ' || LISTAGG(CASE
             WHEN DATA_TYPE LIKE
                  'VARCHAR%' THEN
              'UPPER(EDITED.' ||
              column_name || ')'
             ELSE
              'EDITED.' ||
              column_name
           END, ',') WITHIN GROUP(ORDER BY NULL) || ') e_kf_cnt
                    from (' || pin_data || ') EDITED
                    --where "UpdatedInsertedFlag"=0
                   )
                 where e_kf_cnt=1 or "UpdatedInsertedFlag"=1
              ),
              combined_data as (
                 select e_id, t_id, t_row_version, "UpdatedInsertedFlag", ' || LISTAGG('t_' || substr(column_name,1,28), ',') WITHIN GROUP(ORDER BY NULL) || ', ' || LISTAGG('e_' || substr(column_name,1,28), ',') WITHIN GROUP(ORDER BY NULL) || '
                 from (
                  select * from
                   ( select /*+ INDEX_JOIN (TAB)*/ DISTINCT_EDITED."UpdatedInsertedFlag"
                   ,TAB.row_identifier t_id, DISTINCT_EDITED.e_id, TAB.row_version t_row_version, ' || LISTAGG('TAB.' || column_name || ' as t_' || substr(column_name,1,28), ',') WITHIN GROUP(ORDER BY NULL) || ', ' || LISTAGG('e_' || substr(column_name,1,28), ',') WITHIN GROUP(ORDER BY NULL) || '

                    from ' || pin_table_name || ' TAB inner join DISTINCT_EDITED on
                         (DISTINCT_EDITED.e_id=TAB.row_identifier and DISTINCT_EDITED.row_version=TAB.row_version)
                     or ('
           /* Data Types from UI:
           BOOLEAN   => mapped in DB to NUMBER(1)
           CHARACTER => mapped in DB to VARCHAR2(1-250)
           DATE      => mapped in DB to DATE
           DATE-TIME => mapped in DB to TIMESTAMP(6)
           NOTE      => mapped in DB to VARCHAR2(4000)
           NUMERIC   => mapped in DB to NUMBER(0-10)
           PERIOD    => mapped in DB to NUMBER(10)
           */ || LISTAGG(CASE
             WHEN DATA_TYPE LIKE 'VARCHAR%' THEN
              'NVL(UPPER(DISTINCT_EDITED.e_' || substr(column_name,1,28) ||
              '),chr(0))=NVL(UPPER(TAB.' || column_name ||
              '),chr(0))'
             WHEN DATA_TYPE LIKE 'DATE%' OR
                  DATA_TYPE LIKE 'TIMESTAMP%' THEN
              'NVL(DISTINCT_EDITED.e_' || substr(column_name,1,28) ||
              ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(TAB.' ||
              column_name ||
              ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
             WHEN DATA_TYPE = 'NUMBER' THEN
              'NVL(DISTINCT_EDITED.e_' || substr(column_name,1,28) ||
              ',1E38)=NVL(TAB.' || column_name || ',1E38)'
             ELSE
              'NVL(TO_CHAR(DISTINCT_EDITED.e_' || substr(column_name,1,28) ||
              '),chr(0))=NVL(TO_CHAR(TAB.' || column_name ||
              '),chr(0))'
           END, ' and ') WITHIN GROUP(ORDER BY NULL) || ')
                    --where DISTINCT_EDITED."UpdatedInsertedFlag"=0 -- check updates now and the inserts at the end
                  )
                 )
              ),
              distinct_combined_data as (
                select * from combined_data where not (' || LISTAGG(CASE
             WHEN DATA_TYPE LIKE
                  'VARCHAR%' THEN
              'NVL(UPPER(e_' ||
              substr(column_name,1,28) ||
              '),chr(0))=NVL(UPPER(t_' ||
              substr(column_name,1,28) ||
              '),chr(0))'
             WHEN DATA_TYPE LIKE
                  'DATE%' OR
                  DATA_TYPE LIKE
                  'TIMESTAMP%' THEN
              'NVL(e_' ||
              substr(column_name,1,28) ||
              ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(t_' ||
              substr(column_name,1,28) ||
              ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
             WHEN DATA_TYPE =
                  'NUMBER' THEN
              'NVL(e_' ||
              substr(column_name,1,28) ||
              ',1E38)=NVL(t_' ||
              substr(column_name,1,28) ||
              ',1E38)'
             ELSE
              'NVL(TO_CHAR(e_' ||
              substr(column_name,1,28) ||
              '),chr(0))=NVL(TO_CHAR(t_' ||
              substr(column_name,1,28) ||
              '),chr(0))'
           END, ' and ') WITHIN GROUP(ORDER BY NULL) || ' and "UpdatedInsertedFlag"=0)
              )
              ,failed as (
                select distinct_combined_data.*
                    , connect_by_root e_id root
                    , connect_by_root decode("UpdatedInsertedFlag",0,''U'',''I'') root_flag
                    --, connect_by_isleaf
                    --, connect_by_iscycle
                    --,level
                    ,''U'' flag
                from  distinct_combined_data
                where connect_by_isleaf =1
                     and exists (select 1 from combined_data where ' || LISTAGG(CASE
             WHEN DATA_TYPE LIKE
                  'VARCHAR%' THEN
              'NVL(UPPER(distinct_combined_data.e_' ||
              substr(column_name,1,28) ||
              '),chr(0))=NVL(UPPER(t_' ||
              substr(column_name,1,28) ||
              '),chr(0))'
             WHEN DATA_TYPE LIKE
                  'DATE%' OR
                  DATA_TYPE LIKE
                  'TIMESTAMP%' THEN
              'NVL(distinct_combined_data.e_' ||
              substr(column_name,1,28) ||
              ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(t_' ||
              substr(column_name,1,28) ||
              ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
             WHEN DATA_TYPE =
                  'NUMBER' THEN
              'NVL(distinct_combined_data.e_' ||
              substr(column_name,1,28) ||
              ',1E38)=NVL(t_' ||
              substr(column_name,1,28) ||
              ',1E38)'
             ELSE
              'NVL(TO_CHAR(distinct_combined_data.e_' ||
              substr(column_name,1,28) ||
              '),chr(0))=NVL(TO_CHAR(t_' ||
              substr(column_name,1,28) ||
              '),chr(0))'
           END, ' and ') WITHIN GROUP(ORDER BY NULL) || ' and "UpdatedInsertedFlag"=0)
                    and (connect_by_iscycle=0)-- or uif=1
                start with
                "UpdatedInsertedFlag" is not null
                connect by
                nocycle
                ' || '(prior ' || LISTAGG(CASE
             WHEN DATA_TYPE LIKE
                  'VARCHAR%' THEN
              'UPPER(e_' ||
              substr(column_name,1,28) ||
              ') = UPPER(t_' ||
              substr(column_name,1,28) ||
              ') or (e_' ||
              substr(column_name,1,28) ||
              ' is null and t_' ||
              substr(column_name,1,28) ||
              ' is null) )'
             ELSE
              'e_' || substr(column_name,1,28) ||
              '=t_' || substr(column_name,1,28) ||
              ' or (e_' ||
              substr(column_name,1,28) ||
              ' is null and t_' ||
              substr(column_name,1,28) ||
              ' is null) )'
           END, ' and (prior ') WITHIN GROUP(ORDER BY NULL) || '
              )
              select root as e_id,--' || LISTAGG('e_' || substr(column_name,1,28), ',') WITHIN GROUP(ORDER BY NULL) || ',
                     root_flag as flag
              from failed
              UNION ALL
             select de.e_id,''I''
             from distinct_edited de
               inner join combined_data cd on cd.e_id=de.e_id
             where de."UpdatedInsertedFlag"=1
               and not exists (select 1 from distinct_combined_data dct where dct."UpdatedInsertedFlag"=0 and dct.e_id=cd.t_id)
               and not exists (select 1 from failed f where f.e_id=de.e_id)
              UNION ALL
              select e_id,''S'' from distinct_edited where "UpdatedInsertedFlag"=0
                minus
              select e_id,''S'' from combined_data where "UpdatedInsertedFlag"=0 and e_id=t_id
              UNION ALL
              select de.e_id,''S''
              from distinct_edited de
                inner join combined_data cd on de.e_id=cd.t_id and de.row_version<>cd.t_row_version
              where de."UpdatedInsertedFlag"=0
                and cd."UpdatedInsertedFlag"=0
              '
      INTO v_sql
      FROM user_tab_columns
     WHERE table_name = upper(pin_table_name)
       AND INSTR(upper(pin_key_fields), COLUMN_NAME) > 0;


    EXECUTE IMMEDIATE 'select cast(multiset(select e_id, flag from(' ||
                      v_sql || ')
                       )
               as TABLETYPE_ID_NAME
              )
        from dual'
      INTO v_list_of_rejected_ids;

    SELECT id
      BULK COLLECT
      INTO pout_list_of_stale_ids
      FROM TABLE(v_list_of_rejected_ids)
     WHERE name = 'S';

    SELECT id
      BULK COLLECT
      INTO pout_list_of_failed_ids
      FROM TABLE(v_list_of_rejected_ids)
     WHERE name != 'S';

    -- Defect #13538
    -- COMMONS_TABLES.ALTER_SESSION_PROJ_NLS_SETTING;
  END Adjustment_Unique_Check;

  PROCEDURE Adjustment_Overlap_Check(pi_table_name           IN VARCHAR2,
                                     pi_key_Fields           IN CLOB,
                                     pi_effective_start_date IN VARCHAR2,
                                     pi_effective_end_date   IN VARCHAR2,
                                     pi_period_check         IN NUMBER,
                                     pi_data                 IN CLOB,
                                     pi_table_clob           in clob,
                                     po_list_of_stale_ids    OUT COLTYPE_ID,
                                     po_list_of_failed_ids   OUT COLTYPE_ID) AS
    v_key_fields_join_filter VARCHAR2(4000 CHAR);
    v_prior_join_filter      VARCHAR2(4000 CHAR);
    v_uniq_filter            VARCHAR2(4000 CHAR);
    v_tab_key_fields_list    VARCHAR2(4000 CHAR);
    v_edited_key_fields_list VARCHAR2(4000 CHAR);
    v_t_col_list             VARCHAR2(4000 CHAR);
    v_e_col_list             VARCHAR2(4000 CHAR);
    v_ab_col_list            VARCHAR2(4000 CHAR);
    v_et_col_list            VARCHAR2(4000 CHAR);
    v_sql                    CLOB;
    -- pi_table_name can have at most 30 characters => the value stored here can not have more than 150 characters
    v_table_name           clob;
    v_list_of_rejected_ids TABLETYPE_ID_NAME;
    v_stamp                VARCHAR2(100 CHAR);
  BEGIN
    v_stamp := 'COMMONS_TABLES.ADJUSTMENT_OVERLAP_CHECK - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    -- log input parameters
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTVARCHAR2(pi_table_name),
                             ',pi_table_name => <value>',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCLOB(pi_key_Fields),
                             ',pi_key_Fields => <value>',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTVARCHAR2(pi_effective_start_date),
                             ',pi_effective_start_date => <value>',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTVARCHAR2(pi_effective_end_date),
                             ',pi_effective_end_date => <value>',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTNUMBER(pi_period_check),
                             ',pi_period_check => <value>',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCLOB(pi_data),
                             ',pi_data => <value>',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCLOB(pi_table_clob),
                             ',pi_table_clob => <value>',
                             pi_table_clob);

    IF (pi_key_Fields IS NULL) THEN
      v_table_name := '(select 1 F_' || pi_table_name || ',' ||
                      pi_table_name || '.* from ' || pi_table_name || ') ';

      v_prior_join_filter := '(prior e_' || 'F_' || pi_table_name || '=t_' || 'F_' ||
                             pi_table_name || ' or (e_' || 'F_' ||
                             pi_table_name || ' is null and t_' || 'F_' ||
                             pi_table_name || ' is null) )';

      v_key_fields_join_filter := 'NVL(distinct_edited.e_' || 'F_' ||
                                  pi_table_name || ',1E38)=NVL(TAB.' || 'F_' ||
                                  pi_table_name || ',1E38)';

      v_uniq_filter := 'NVL(a.e_' || 'F_' || pi_table_name ||
                       ',1E38)=NVL(t_' || 'F_' || pi_table_name || ',1E38)';

      v_tab_key_fields_list := 'TAB.' || 'F_' || pi_table_name || ' as t_' || 'F_' ||
                               pi_table_name;

      v_t_col_list := 't_' || 'F_' || pi_table_name;

      v_edited_key_fields_list := 'EDITED.' || 'F_' || pi_table_name ||
                                  ' as e_' || 'F_' || pi_table_name;

      v_e_col_list := 'e_' || 'F_' || pi_table_name;

      v_ab_col_list := 'NVL(a.e_' || 'F_' || pi_table_name ||
                       ',1E38)=NVL(b.e_' || 'F_' || pi_table_name ||
                       ',1E38)';

      v_et_col_list := 'NVL(t_' || 'F_' || pi_table_name || ',1E38)=NVL(e_' || 'F_' ||
                       pi_table_name || ',1E38)';
    ELSE

      if (pi_table_clob is null) then
        v_table_name := pi_table_name;
      elsif (pi_table_clob is not null) then
        v_table_name := ' ( ' || pi_table_clob || ' ) ';
      end if;

      SELECT
      -- v_prior_join_filter
       '(prior ' || LISTAGG(CASE
                              WHEN DATA_TYPE LIKE 'VARCHAR%' THEN
                               'UPPER(e_' || column_name || ') = UPPER(t_' || column_name ||
                               ') or (e_' || column_name || ' is null and t_' || column_name ||
                               ' is null) )'
                              ELSE
                               'e_' || column_name || '=t_' || column_name || ' or (e_' ||
                               column_name || ' is null and t_' || column_name || ' is null) )'
                            END,
                            ' and (prior ') WITHIN GROUP(ORDER BY NULL),
       -- v_key_fields_join_filter
       LISTAGG(CASE
                 WHEN DATA_TYPE LIKE 'VARCHAR%' THEN
                  'NVL(UPPER(distinct_edited.e_' || column_name ||
                  '),chr(0))=NVL(UPPER(TAB.' || column_name || '),chr(0))'
                 WHEN DATA_TYPE LIKE 'DATE%' OR DATA_TYPE LIKE 'TIMESTAMP%' THEN
                  'NVL(distinct_edited.e_' || column_name ||
                  ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(TAB.' ||
                  column_name || ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
                 WHEN DATA_TYPE = 'NUMBER' THEN
                  'NVL(distinct_edited.e_' || column_name || ',1E38)=NVL(TAB.' ||
                  column_name || ',1E38)'
                 ELSE
                  'NVL(distinct_edited.e_' || column_name || ',chr(0))=NVL(TAB.' ||
                  column_name || ',chr(0))'
               END,
               ' and ') WITHIN GROUP(ORDER BY NULL),
       -- v_uniq_filter
       LISTAGG(CASE
                 WHEN DATA_TYPE LIKE 'VARCHAR%' THEN
                  'NVL(UPPER(a.e_' || column_name || '),chr(0))=NVL(UPPER(t_' ||
                  column_name || '),chr(0))'
                 WHEN DATA_TYPE LIKE 'DATE%' OR DATA_TYPE LIKE 'TIMESTAMP%' THEN
                  'NVL(a.e_' || column_name ||
                  ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(t_' || column_name ||
                  ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
                 WHEN DATA_TYPE = 'NUMBER' THEN
                  'NVL(a.e_' || column_name || ',1E38)=NVL(t_' || column_name ||
                  ',1E38)'
                 ELSE
                  'NVL(a.e_' || column_name || ',chr(0))=NVL(t_' || column_name ||
                  ',chr(0))'
               END,
               ' and ') WITHIN GROUP(ORDER BY NULL),
       -- v_tab_key_fields_list
       LISTAGG('TAB.' || column_name || ' as t_' || column_name, ',') WITHIN GROUP(ORDER BY NULL),
       -- v_t_col_list
       LISTAGG('t_' || column_name, ',') WITHIN GROUP(ORDER BY NULL),
       -- v_edited_key_fields_list
       LISTAGG('EDITED.' || column_name || ' as e_' || column_name, ',') WITHIN GROUP(ORDER BY NULL),
       -- v_e_col_list
       LISTAGG('e_' || column_name, ',') WITHIN GROUP(ORDER BY NULL),
       -- v_ab_col_list
       LISTAGG(CASE
                 WHEN DATA_TYPE LIKE 'VARCHAR%' THEN
                  'NVL(UPPER(a.e_' || column_name || '),chr(0))=NVL(UPPER(b.e_' ||
                  column_name || '),chr(0))'
                 WHEN DATA_TYPE LIKE 'DATE%' OR DATA_TYPE LIKE 'TIMESTAMP%' THEN
                  'NVL(a.e_' || column_name ||
                  ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(b.e_' ||
                  column_name || ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
                 WHEN DATA_TYPE = 'NUMBER' THEN
                  'NVL(a.e_' || column_name || ',1E38)=NVL(b.e_' || column_name ||
                  ',1E38)'
                 ELSE
                  'NVL(a.e_' || column_name || ',chr(0))=NVL(b.e_' || column_name ||
                  ',chr(0))'
               END,
               ' and ') WITHIN GROUP(ORDER BY NULL),
       -- v_et_col_list
       LISTAGG(CASE
                 WHEN DATA_TYPE LIKE 'VARCHAR%' THEN
                  'NVL(UPPER(t_' || column_name || '),chr(0))=NVL(UPPER(e_' ||
                  column_name || '),chr(0))'
                 WHEN DATA_TYPE LIKE 'DATE%' OR DATA_TYPE LIKE 'TIMESTAMP%' THEN
                  'NVL(t_' || column_name ||
                  ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))=NVL(e_' || column_name ||
                  ',TO_DATE(''01/01/1800'',''DD/MM/sYYYY''))'
                 WHEN DATA_TYPE = 'NUMBER' THEN
                  'NVL(t_' || column_name || ',1E38)=NVL(e_' || column_name ||
                  ',1E38)'
                 ELSE
                  'NVL(t_' || column_name || ',chr(0))=NVL(e_' || column_name ||
                  ',chr(0))'
               END,
               ' and ') WITHIN GROUP(ORDER BY NULL)
        INTO v_prior_join_filter,
             v_key_fields_join_filter,
             v_uniq_filter,
             v_tab_key_fields_list,
             v_t_col_list,
             v_edited_key_fields_list,
             v_e_col_list,
             v_ab_col_list,
             v_et_col_list
        FROM user_tab_columns
       WHERE table_name = upper(pi_table_name)
         AND INSTR(upper(pi_key_fields), COLUMN_NAME) > 0;

    END IF;

    IF (pi_period_check = 0) THEN
      v_sql := 'with
  edited as (
    select "UpdatedInsertedFlag", row_identifier e_id, row_version, nvl(' ||
               pi_effective_start_date ||
               ', to_date(''1/1/1900'', ''mm/dd/yyyy'')) e_start_date ,  nvl(' ||
               pi_effective_end_date ||
               ', to_date(''12/31/9999'', ''mm/dd/yyyy'')) e_end_date , ' ||
               v_edited_key_fields_list || '
    from (' || pi_data || ') EDITED
  ),

distinct_edited as

(
select *
    from edited
   where e_id not in
         ((select nvl(a.e_id,0)
            from edited a, edited b
           where ' || v_ab_col_list || '
             and
                ---overlap condition
                 (
                  ((nvl(a.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                  nvl(b.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                  nvl(a.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) >=
                  nvl(b.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))

                  ) and a.e_id <> b.e_id)))

))
,
combined_data_inter as (
     select e_id, t_id,  "UpdatedInsertedFlag", ' ||
               v_t_col_list || ', ' || v_e_col_list || '
     ,e_start_date,e_end_date, t_start_date, t_end_date
     from (
      select /*+ INDEX_JOIN (TAB) */ distinct_edited."UpdatedInsertedFlag"
       ,TAB.row_identifier t_id, distinct_edited.e_id, ' ||
               v_tab_key_fields_list || ', ' || v_e_col_list || '
       ,e_start_date,e_end_date,TAB.' ||
               pi_effective_start_date || ' t_start_date , TAB.' ||
               pi_effective_end_date || ' t_end_date
        from ' || v_table_name || ' TAB inner join distinct_edited distinct_edited on
             (distinct_edited.e_id=TAB.row_identifier and distinct_edited.row_version=TAB.row_version)
         or
         (
         (' || v_key_fields_join_filter || ' )
          and
         (

            (
                (
                (
                 nvl(TAB.' || pi_effective_start_date ||
               ',to_date(''1/1/1900'',''mm/dd/yyyy''))
                 <= nvl(distinct_edited.e_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 and
                 nvl(TAB.' || pi_effective_end_date ||
               ',to_date(''12/31/9999'',''mm/dd/yyyy''))
                 >= nvl(distinct_edited.e_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))

                 )


                 )
                 and

      TAB.row_identifier <> distinct_edited.e_id)
            )

         )

      where "UpdatedInsertedFlag"=0

        -- order by t_id -- NOT NECESSARY
     )
  ),
 combined_data  as
(
select * from combined_data_inter where e_id not in (

            select e_id from distinct_edited where "UpdatedInsertedFlag"=0
    minus
  select e_id from combined_data_inter where "UpdatedInsertedFlag"=0 and e_id=t_id
          )

           -- order by t_id -- NOT NECESSARY

),
 distinct_combined_data as (
    select * from combined_data
    where (e_id,t_id) not in
         (select a.e_id,a.t_id
              from combined_data a
        where ' || v_et_col_list ||
               ' and
        (

            (
                (
                 nvl(a.t_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))
                 <= nvl(a.e_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 and
                 nvl(a.t_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 >= nvl(a.e_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))

                 )
                 and
                 a.t_id <> a.e_id)
            )
        )

  ),

 failed as (
    select a.*
        , connect_by_root e_id root
    from  distinct_combined_data a
    where connect_by_isleaf =1
         and exists (select 1 from combined_data b where ' ||
               v_uniq_filter || '
         and (

                   (nvl(b.t_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                   nvl(a.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                   nvl(b.t_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy''))

                   >= nvl(a.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))

              ) and b.t_id <> a.e_id) )
    connect by
    nocycle
    (' || v_prior_join_filter || ')
    and


    (

                   (nvl(t_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                   nvl( prior e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                   nvl(t_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy''))

                   >= nvl(prior e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))

              )and  (e_id <> prior t_id or t_id <> prior  e_id and not (e_id = prior t_id and t_id = prior  e_id)))
  )
 ,
 passed_update_clob as
 (select *
    from distinct_combined_data
   where not exists (select 1
            from failed
           where e_id = distinct_combined_data.e_id
             and t_id = distinct_combined_data.t_id)
             and "UpdatedInsertedFlag" =0
             ),

overlap_with_insert as
(
select distinct e_id
from ( select /*+ INDEX_JOIN (TAB) */ distinct_edited.e_id e_id
       from ' || v_table_name ||
               ' TAB
       inner join distinct_edited on ' ||
               v_key_fields_join_filter || '
                                     and
                                        ---overlap condition
                                         (((nvl(TAB.' ||
               pi_effective_start_date ||
               ', to_date(''1/1/1900'', ''mm/dd/yyyy'')) <= nvl(distinct_edited.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                                          nvl(TAB.' ||
               pi_effective_end_date ||
               ', to_date(''12/31/9999'', ''mm/dd/yyyy'')) >= nvl(distinct_edited.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))
                                          ) and TAB.row_identifier <> distinct_edited.e_id))
        where not exists (select 1 from passed_update_clob where e_id=tab.row_identifier )
          and distinct_edited."UpdatedInsertedFlag" = 1

        union all

        select b.e_id        t_id
        from distinct_edited a
        inner join distinct_edited b on ' || v_ab_col_list || '
                                     and
                                        ---overlap condition
                                         (((nvl(a.e_end_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <= nvl(b.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                                          nvl(a.e_start_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) >= nvl(b.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))
                                          ) and a.e_id <> b.e_id))
        where a.e_id in (select e_id from passed_update_clob )
         and b."UpdatedInsertedFlag" = 1
     )
)

select e_id,''I'' flag from overlap_with_insert
  union all
  select * from (
select e_id, case when "UpdatedInsertedFlag" = 0 then ''U'' else ''I'' end flag
  from edited
minus
select e_id, case when "UpdatedInsertedFlag" = 0 then ''U'' else ''I'' end flag
  from distinct_edited)

  UNION ALL
  select e_id,''S'' from distinct_edited where "UpdatedInsertedFlag"=0
    minus
  select e_id,''S'' from combined_data_inter where "UpdatedInsertedFlag"=0 and e_id=t_id




  union all
  select  root,''U'' flag from  failed
                   ';
    ELSIF (pi_period_check = 1) THEN
      v_sql := 'with
  edited as (
    select "UpdatedInsertedFlag", row_identifier e_id, row_version, nvl(tupr1.tupr_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) e_start_date , nvl(tupr2.tupr_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) e_end_date ,  ' ||
               v_edited_key_fields_list || '
    from (' || pi_data ||
               ') EDITED
     LEFT OUTER join tu_periods_range TUPR1  on EDITED.' ||
               pi_effective_start_date ||
               ' = tupr1.tupr_id
    LEFT OUTER join tu_periods_range TUPR2  on EDITED.' ||
               pi_effective_end_date || ' = tupr2.tupr_id
  ),

distinct_edited as

(
select *
    from edited
   where e_id not in
         ((select nvl(a.e_id,0)
            from edited a, edited b
           where ' || v_ab_col_list || '
             and
                ---overlap condition
                 (
                  ((nvl(a.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                  nvl(b.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                  nvl(a.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) >=
                  nvl(b.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))

                  ) and a.e_id <> b.e_id)))

))
,

combined_data_inter as (
     select e_id, t_id,  "UpdatedInsertedFlag", ' ||
               v_t_col_list || ', ' || v_e_col_list || '
     ,e_start_date,e_end_date, t_start_date, t_end_date
     from (
      select /*+ INDEX_JOIN (TAB) */ distinct_edited."UpdatedInsertedFlag"
       ,TAB.row_identifier t_id, distinct_edited.e_id, ' ||
               v_tab_key_fields_list || ', ' || v_e_col_list || '
       ,e_start_date,e_end_date,
        tupr1.tupr_start_date t_start_date , tupr2.tupr_end_date t_end_date
        from ' || v_table_name ||
               ' TAB
        LEFT OUTER join tu_periods_range TUPR1  on TAB.' ||
               pi_effective_start_date ||
               ' = tupr1.tupr_id
        LEFT OUTER join tu_periods_range TUPR2  on TAB.' ||
               pi_effective_end_date || ' = tupr2.tupr_id
        inner join distinct_edited distinct_edited on
             (distinct_edited.e_id=TAB.row_identifier and distinct_edited.row_version=TAB.row_version)
         or
         (
         (' || v_key_fields_join_filter || ' )
          and
         (

            (
                (
                (
                 nvl(tupr1.tupr_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))
                 <= nvl(distinct_edited.e_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 and
                 nvl(tupr2.tupr_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 >= nvl(distinct_edited.e_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))

                 )


                 )
                 and

      TAB.row_identifier <> distinct_edited.e_id)
            )

         )


where "UpdatedInsertedFlag"=0
        -- order by t_id -- NOT NECESSARY
     )
  )

   ,
 combined_data  as
(
select * from combined_data_inter where e_id not in (

            select e_id from distinct_edited where "UpdatedInsertedFlag"=0
    minus
  select e_id from combined_data_inter where "UpdatedInsertedFlag"=0 and e_id=t_id

          )
          -- order by t_id -- NOT NECESSARY

)


  ,

 distinct_combined_data as (
    select * from combined_data
    where (e_id,t_id) not in
         (select /*+ NL_AJ */ a.e_id,a.t_id
              from combined_data a
        where ' || v_et_col_list ||
               ' and
        (

            (
                (
                 nvl(a.t_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))
                 <= nvl(a.e_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 and
                 nvl(a.t_end_date,to_date(''12/31/9999'',''mm/dd/yyyy''))
                 >= nvl(a.e_start_date,to_date(''1/1/1900'',''mm/dd/yyyy''))

                 )
                 and
                 a.t_id <> a.e_id)
            )
        )

  ),

 failed as (
    select a.*
        , connect_by_root e_id root
        /*, connect_by_root decode("UpdatedInsertedFlag",0,''U'',''I'') root_flag*/
        --, connect_by_isleaf
        --, connect_by_iscycle
        --,level
     /*   ,''U'' flag*/
    from  distinct_combined_data a
    where connect_by_isleaf =1
         and exists (select 1 from combined_data b where ' ||
               v_uniq_filter || '
         and (

                   (nvl(b.t_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                   nvl(a.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                   nvl(b.t_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy''))

                   >= nvl(a.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))

              ) and b.t_id <> a.e_id) /*and "UpdatedInsertedFlag"=0*/)
       /* and (connect_by_iscycle=0 or level=1)*/
    /*start with
    "UpdatedInsertedFlag" is not null*/
    connect by
    nocycle
    (' || v_prior_join_filter || ')


    and
    (

                   (nvl(t_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <=
                   nvl( prior e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                   nvl(t_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy''))

                   >= nvl(prior e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))

              ) and  (e_id <> prior t_id or t_id <> prior  e_id and not (e_id = prior t_id and t_id = prior  e_id)))

  )
 ,
 passed_update_clob as
 (select *
    from distinct_combined_data
   where not exists (select 1
            from failed
           where e_id = distinct_combined_data.e_id
             and t_id = distinct_combined_data.t_id)
             and "UpdatedInsertedFlag" =0
             ),

overlap_with_insert as
(
select distinct e_id
from ( select /*+ INDEX_JOIN (TAB) */ distinct_edited.e_id e_id
       from ' || v_table_name ||
               ' TAB
       LEFT OUTER join tu_periods_range TUPR1  on TAB.' ||
               pi_effective_start_date ||
               ' = tupr1.tupr_id
       LEFT OUTER join tu_periods_range TUPR2  on TAB.' ||
               pi_effective_end_date ||
               ' = tupr2.tupr_id
       inner join distinct_edited on ' ||
               v_key_fields_join_filter || '
                                     and
                                        ---overlap condition
                                         (((nvl(tupr1.tupr_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <= nvl(distinct_edited.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                                          nvl(tupr2.tupr_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) >= nvl(distinct_edited.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))
                                          ) and TAB.row_identifier <> distinct_edited.e_id))
        where not exists (select 1 from passed_update_clob where e_id=tab.row_identifier )
          and distinct_edited."UpdatedInsertedFlag" = 1

        union all

        select b.e_id        t_id
        from distinct_edited a
        inner join distinct_edited b on ' || v_ab_col_list || '
                                     and
                                        ---overlap condition
                                         (((nvl(a.e_end_date, to_date(''1/1/1900'', ''mm/dd/yyyy'')) <= nvl(b.e_end_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) and
                                          nvl(a.e_start_date, to_date(''12/31/9999'', ''mm/dd/yyyy'')) >= nvl(b.e_start_date, to_date(''1/1/1900'', ''mm/dd/yyyy''))
                                          ) and a.e_id <> b.e_id))
        where a.e_id in (select e_id from passed_update_clob )
         and b."UpdatedInsertedFlag" = 1
     )
)

select e_id,''I'' flag from overlap_with_insert
  union all
  select * from (
select e_id, case when "UpdatedInsertedFlag" = 0 then ''U'' else ''I'' end flag
  from edited
minus
select e_id, case when "UpdatedInsertedFlag" = 0 then ''U'' else ''I'' end flag
  from distinct_edited)
  UNION ALL
  select e_id,''S'' from distinct_edited where "UpdatedInsertedFlag"=0
    minus
  select e_id,''S'' from combined_data_inter where "UpdatedInsertedFlag"=0 and e_id=t_id



  union all
  select  root,''U'' flag from  failed
                   ';
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCLOB(v_sql),
                             ',v_sql => <value>',
                             v_stamp);

    EXECUTE IMMEDIATE --dbms_output.put_line(
     'select cast(multiset(select e_id, flag from(' || v_sql || ')
                       )
               as TABLETYPE_ID_NAME
              )
        from dual
    '
      INTO v_list_of_rejected_ids;

    SELECT id
      BULK COLLECT
      INTO po_list_of_stale_ids
      FROM TABLE(v_list_of_rejected_ids)
     WHERE name = 'S';

    SELECT id
      BULK COLLECT
      INTO po_list_of_failed_ids
      FROM TABLE(v_list_of_rejected_ids)
     WHERE name != 'S';
  END Adjustment_Overlap_Check;

  PROCEDURE Adjustment_Overlap_Check(pi_table_name           IN VARCHAR2,
                                     pi_key_Fields           IN CLOB,
                                     pi_effective_start_date IN VARCHAR2,
                                     pi_effective_end_date   IN VARCHAR2,
                                     pi_period_check         IN NUMBER,
                                     pi_data                 IN CLOB,
                                     po_list_of_stale_ids    OUT COLTYPE_ID,
                                     po_list_of_failed_ids   OUT COLTYPE_ID) AS
  begin
    Adjustment_Overlap_Check(pi_table_name => pi_table_name,

                             pi_key_Fields           => pi_key_Fields,
                             pi_effective_start_date => pi_effective_start_date,
                             pi_effective_end_date   => pi_effective_end_date,
                             pi_period_check         => pi_period_check,
                             pi_data                 => pi_data,
                             po_list_of_stale_ids    => po_list_of_stale_ids,
                             po_list_of_failed_ids   => po_list_of_failed_ids,
                             pi_table_clob           => null);

  end;

  PROCEDURE DELETE_ALL_ST_DATA(table_name    VARCHAR2,
                               entity_fields TABLETYPE_NAME_MAP,
                               period_fields TABLETYPE_NAME_MAP,
                               where_clause  VARCHAR2)
  -- Assumptions:
    -- Input Parameters are built using valid column names
    -- when WHERE_CLAUSE parameter is passed it should have "WHERE" clause in it.
    -- when ORDERBY_CLAUSE parameter is passed it should have "ORDER" clause in it.
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    TABLE_NAME                Standard Table name from where to delete records
    --    ENTITY_FIELDS             List of column names from table representing entity fields. It is an array containing elements like ('F1','E1'), ('F2','E2')
    --                              where E1,E2 are table names for each Entity table used in joins
    --    PERIOD_FIELDS             List of column names from table representing period fields. It is an array containing elements like ('F3','TPR1'), ('F4','TPR2')
    --                              where TPR1,TPR2 are aliases for each TU_PERIODS_RANGE instance used in joins
    --    WHERE_CLAUSE              Filter clause containing filters on normal fields, entity fields, period fields
    -----------------------------------------------------------------------------------------
    -- Output : None
    -----------------------------------------------------------------------------------------
    /*
    -- Example:
    begin
        common_tables.DELETE_ALL_ST_DATA (
        'T166264_1900_1 TAB'
        , TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F3','E1'))
        , TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F345','TPR1'))
        , 'TAB.F120903 IS NOT NULL') ;
    end;
    */
   IS
    strsql                VARCHAR2(32767);
    period_join_condition VARCHAR2(32767);
    entity_join_condition VARCHAR2(32767);
    t_table_name          VARCHAR2(32767);
    v_where_clause        VARCHAR2(32767);
  BEGIN
    IF where_clause IS NOT NULL THEN
      v_where_clause := ' WHERE ' || where_clause;
    END IF;

    t_table_name := SUBSTR(table_name, 1, INSTR(table_name, ' '));

    --check if entity_fields is NULL and build entity_join_condition appropiately
    IF entity_fields IS NOT NULL THEN
      BEGIN
        FOR i IN 1 .. entity_fields.COUNT LOOP
          entity_join_condition := entity_join_condition || ' INNER JOIN ' || entity_fields(i)
                                  .NAME2 || '
                         ON ' || entity_fields(i)
                                  .NAME2 || '.E_INTERNAL_ID' || '=TAB.' || entity_fields(i)
                                  .NAME1;
        END LOOP;
      END;
    END IF;

    --check if period_fields is NULL and build period_join_condition appropiately
    IF period_fields IS NOT NULL THEN
      BEGIN
        FOR i IN 1 .. period_fields.COUNT LOOP
          period_join_condition := period_join_condition ||
                                   ' LEFT JOIN TU_PERIODS_RANGE ' || period_fields(i)
                                  .NAME2 || '
                         ON ' || period_fields(i)
                                  .NAME2 || '.TUPR_ID' || '=' || period_fields(i)
                                  .NAME1;
        END LOOP;
      END;
    END IF;

    strsql := ' DELETE FROM ' || t_table_name || '
           WHERE ROW_IDENTIFIER IN (SELECT TAB.ROW_IDENTIFIER
                 FROM ' || table_name || entity_join_condition ||
              period_join_condition || v_where_clause || ')';

    -- dbms_output.put_line(STRSQL);

    EXECUTE IMMEDIATE strsql;
  END DELETE_ALL_ST_DATA;

  PROCEDURE Copy_Dependencies(pi_data_table VARCHAR2,
                              pi_dump_table VARCHAR2) AS
    ---********* variable declaration ************--------

    v_dump_table     VARCHAR2(30) := UPPER(pi_dump_table);
    v_data_table     VARCHAR2(30) := UPPER(pi_data_table);
    v_index_ddl_name commons_utils.type_index_ddl_composite;
    v_cons_ddl_name  commons_utils.type_constraint_ddl_composite;
    v_trg_ddl_name   commons_utils.type_trigger_ddl_composite;
    v_ddl_query      CLOB;
    v_undo_ddl_query CLOB;
    v_status         NUMBER(1) := 0;
    v_index          NUMBER := 1;
    v_condition      LONG;
    v_count_new      VARCHAR(250);
    v_count_reset    NUMBER;
    v_seq_status     BOOLEAN := FALSE;
    v_seq_ori        NUMBER;
  BEGIN
    --dbms_output.put_line('step1');
    --get constraint ddl
    commons_utils.get_constraint_ddl(pi_table          => v_data_table,
                                     pi_where_clause   => 'constraint_type in (''C'', ''P'', ''U'', ''R'')',
                                     po_constraint_ddl => v_cons_ddl_name);

    --iterate through constarints defination
    FOR C IN 1 .. v_cons_ddl_name.COUNT LOOP
      --dbms_output.put_line('step2');
      SELECT search_condition
        INTO v_condition
        FROM user_constraints
       WHERE constraint_name = v_cons_ddl_name(c).const_name;

      --ignore not null constraints
      IF NVL(SUBSTR(v_condition, -11), 'Dummy_For_Null') != 'IS NOT NULL' THEN
        --dbms_output.put_line('step3');
        v_ddl_query := REPLACE(v_cons_ddl_name(c).ddl_stmt,
                               v_data_table,
                               v_dump_table);
        --dbms_output.put_line('apply_constraints');
        --dbms_output.put_line('v_ddl_query:' || v_ddl_query);
        commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      END IF;
    END LOOP;

    --get_index_ddl
    commons_utils.get_index_ddl(pi_table        => v_data_table,
                                pi_where_clause => 'index_name not in
                            (SELECT /*+ NL_AJ */
                             index_name
                             FROM all_cons_columns A
                             JOIN all_constraints C
                             ON A.constraint_name = C.constraint_name
                             WHERE C.table_name = ''' ||
                                                   v_data_table || '''
                             AND C.constraint_type in (''P'', ''U''))',
                                po_index_ddl    => v_index_ddl_name);

    --iterate through indexes defination
    FOR C IN 1 .. v_index_ddl_name.COUNT LOOP
      v_ddl_query := REPLACE(v_index_ddl_name(c).ddl_stmt,
                             v_data_table,
                             v_dump_table);

      --dbms_output.put_line('apply_index');
      --dbms_output.put_line('v_ddl_query:' || v_ddl_query);
      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      ---call at

    END LOOP;

    --get_Trigger_ddl
    commons_utils.get_Trigger_ddl(pi_table        => v_data_table,
                                  pi_where_clause => NULL,
                                  po_trigger_ddl  => v_trg_ddl_name);

    FOR C IN 1 .. v_trg_ddl_name.COUNT LOOP
      v_ddl_query := REPLACE(v_trg_ddl_name(c).ddl_stmt,
                             v_data_table,
                             v_dump_table);

      --dbms_output.put_line('apply_trigger');
      --dbms_output.put_line('v_ddl_query:' || v_ddl_query);

      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      ---call at
    END LOOP;
  END Copy_Dependencies;

  PROCEDURE get_list_of_data_tables(pi_ent_fld     TABLETYPE_ID_ID,
                                    pi_fld         coltype_id,
                                    po_data_tables OUT SYS_REFCURSOR) AS
    v_sql              CLOB;
    v_sql_select       CLOB;
    v_sql_from         CLOB;
    v_sql_from_sub     CLOB;
    v_sql_where        CLOB;
    v_ent_fld_flag     NUMBER;
    v_sql_from_sub_fld CLOB;
    v_fields_id        CLOB;
    v_entity_fields_id CLOB;
    v_entity_id        CLOB;
    v_fields_where     CLOB;
    v_entity_where     CLOB;
  BEGIN
    IF (pi_ent_fld IS NULL AND pi_fld IS NULL) THEN
      raise_application_error(-20001,
                              'pi_ent_fld and pi_fld both cannot be simultaneously null');
    END IF;

    --Select part of the Query
    v_sql_select := ' select dt.* ';
    --From part of the Query
    v_sql_from := ' from tables t inner join  (select tc.tc_tables_id,';

    --check if entities are present
    IF (pi_ent_fld IS NOT NULL) THEN
      FOR c IN 1 .. pi_ent_fld.COUNT LOOP
        --build the select clause for entities and crooseponding fields for subquery

        -- Add conditional ','
        SELECT NVL2(v_sql_from_sub, v_sql_from_sub || ' , ', NULL),
               NVL2(v_entity_fields_id, v_entity_fields_id || ' , ', NULL),
               NVL2(v_entity_id, v_entity_id || ' , ', NULL),
               NVL2(v_entity_where, v_entity_where || ' and ', NULL),
               DECODE(pi_ent_fld(c).id1,
                      NULL,
                      1,
                      DECODE(pi_ent_fld(c).id2, NULL, 1, 0))
          INTO v_sql_from_sub,
               v_entity_fields_id,
               v_entity_id,
               v_entity_where,
               v_ent_fld_flag
          FROM DUAL;

        --raise error if entity to field mapping is missing
        IF (v_ent_fld_flag = 1) THEN
          raise_application_error(-20001, 'Entity to fields mapping error');
        END IF;

        v_sql_from_sub := v_sql_from_sub ||
                          ' max(Case tc.tc_entity_id when ' || pi_ent_fld(c).id1 ||
                          ' then 1 else 0 end)  as e' || c || ',';
        --build the select clause for buisness keys in entities
        v_sql_from_sub := v_sql_from_sub || ' max(Case tc.tc_fld_id when ' || pi_ent_fld(c).id2 ||
                          ' then 1 else 0 end)  as ef' || c;

        --build field where clause for sub query
        v_entity_fields_id := v_entity_fields_id || pi_ent_fld(c).id2;
        --build entity where clause for sub query
        v_entity_id := v_entity_id || pi_ent_fld(c).id1;
        --build entity where clause for query
        v_entity_where := v_entity_where || '(e' || c || '=1 or ef' || c ||
                          '=1 ) ';
      END LOOP;
    END IF;

    --check if fields are present
    IF (pi_fld IS NOT NULL) THEN
      FOR c IN 1 .. pi_fld.COUNT LOOP
        SELECT NVL2(v_sql_from_sub_fld, v_sql_from_sub_fld || ' , ', NULL),
               NVL2(v_fields_id, v_fields_id || ' , ', NULL),
               NVL2(v_fields_where, v_fields_where || ' and ', NULL)
          INTO v_sql_from_sub_fld, v_fields_id, v_fields_where
          FROM DUAL;

        --build the select clause for fields
        v_sql_from_sub_fld := v_sql_from_sub_fld ||
                              ' max(Case tc.tc_fld_id when ' || pi_fld(c) ||
                              ' then 1 else 0 end)  as f' || c;
        --build field where clause for sub query
        v_fields_id := v_fields_id || pi_fld(c);
        --build entity where clause for query
        v_fields_where := v_fields_where || '( ' || 'f' || c || '=1 )  ';
      END LOOP;

      SELECT NVL2(v_sql_from_sub,
                  v_sql_from_sub || ',' || v_sql_from_sub_fld,
                  v_sql_from_sub_fld)
        INTO v_sql_from_sub
        FROM DUAL;
    END IF;

    --build the complete from clause combining the entity and field where clauses conditionally
    SELECT v_sql_from || ' ' || v_sql_from_sub ||
           ' from table_columns tc   where ' ||
           NVL2(v_entity_id,
                '   tc.tc_entity_id in (' || v_entity_id || ') ',
                NULL) ||
           NVL2(v_fields_id,
                NVL2(v_entity_id,
                     ' or  tc.tc_fld_id in (' || v_fields_id || ' , ' ||
                     v_entity_fields_id || ') ',
                     '  tc.tc_fld_id in (' || v_fields_id || ') '),
                NVL2(v_entity_fields_id,
                     ' or tc.tc_fld_id in (' || v_entity_fields_id || ') ',
                     NULL)) || ' Group by tc.tc_tables_id) tc1

                on t.tables_id=tc1.tc_tables_id

                inner join data_tables dt

                on dt.dt_tables_id=t.tables_id
                '
      INTO v_sql_from
      FROM DUAL;

    --build the where clause
    SELECT ' where ' || v_entity_where ||
           NVL2(v_entity_where,
                NVL2(v_fields_where,
                     ' and ' || v_fields_where,
                     v_fields_where),
                v_fields_where)
      INTO v_sql_where
      FROM DUAL;

    --build the complete query
    v_sql := v_sql_select || v_sql_from || v_sql_where;

    -- dbms_output.put_line(v_sql);
    OPEN po_data_tables FOR v_sql;
  END get_list_of_data_tables;

  /*
  PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE           IN VARCHAR2,
                           pi_QI_TABLE             IN VARCHAR2,
                           pi_KEY_COLUMNS          IN CLOB,
                           pi_DATA_COLUMNS         IN CLOB,
                           pi_START                IN VARCHAR2,
                           pi_END                  IN VARCHAR2,
                           pi_RECORD_DATING_OPTION IN NUMBER,
                           pi_DEST_TABLE           IN VARCHAR2,
                           pi_IS_AUTO_VALUED       IN NUMBER,
                           pi_AGGREGATION_RULE     IN TABLETYPE_NAME_MAP,
                           pi_AGGREGATION_ORDER    IN VARCHAR2,
                           pi_ENTITY_COL_MAPPING   IN TABLETYPE_NAME_MAP,
                           pi_PERIOD_COL_MAPPING   IN TABLETYPE_NAME_MAP

                           ) IS

    v_SQL             CLOB;
    v_AGGREGATION_SQL CLOB;
    v_WHERE_SQL       VARCHAR2(32767);
    v_TEMP_SQL        CLOB;
    V_INTRANS_VALUE   NUMBER;
    l_offset          NUMBER default 1;
    v_KEY_COLUMNS     CLOB := pi_KEY_COLUMNS;
    v_INTERNAL_WHERE  VARCHAR2(32767);
    v_FIELDS VARCHAR2(30);

  begin

    if (pi_START is not null) then
      v_KEY_COLUMNS := v_KEY_COLUMNS || ' , ' || pi_START;

    end if;

    SELECT max(PR_VALUE)
      INTO V_INTRANS_VALUE
      FROM PROPERTIES
     WHERE PR_NAME = 'INITRANS';
  --  dbms_output.put_line('Initrans');
    --initial CTAS with select limited to key cols
    select ' CREATE TABLE ' || pi_QI_TABLE || ' ROWDEPENDENCIES INITRANS ' ||
           V_INTRANS_VALUE || ' NOLOGGING TABLESPACE ' || USER || '_DTS' ||
           ' AS SELECT ' || v_KEY_COLUMNS
      into v_sql
      from dual;

    --check if both aggregation list and data table list is empty
    if (
       (pi_AGGREGATION_RULE IS NOT null AND pi_DATA_COLUMNS IS NOT NULL)) then

      raise_application_error(-20001,
                              'pi_AGGREGATION_RULE and pi_DATA_COLUMNS both cannot be simultaneously not null');

    elsif (pi_DATA_COLUMNS IS NOT NULL) then
    --  dbms_output.put_line('No agrgregation');
      SELECT v_sql || ' , ' || pi_DATA_COLUMNS ||
             decode(pi_END, null, null, ' , ' || pi_END)
        INTO v_sql
        FROM DUAL;
    ELSIF (pi_AGGREGATION_RULE IS NOT NULL AND pi_AGGREGATION_ORDER IS NULL) then
      raise_application_error(-20001,
                              'pi_AGGREGATION_RULE needs pi_AGGREGATION_ORDER along with it');

      -- AGGREGATION COLUMNS
    ELSIF (pi_AGGREGATION_RULE IS NOT NULL AND
          pi_AGGREGATION_ORDER IS NOT NULL) then
      --dbms_output.put_line('agrgregation');
      IF (pi_AGGREGATION_RULE.COUNT <> 0) THEN

        FOR I IN 1 .. pi_AGGREGATION_RULE.COUNT LOOP
        --  dbms_output.put_line(pi_AGGREGATION_RULE(I).name1);
          if (pi_AGGREGATION_RULE(I).name2 = 'LAST') then

            SELECT v_AGGREGATION_SQL || '
           ,max(' || pi_AGGREGATION_RULE(I).name1 ||
                   ') KEEP(DENSE_RANK LAST ORDER BY ' || pi_AGGREGATION_ORDER ||
                   ' ) as ' || pi_AGGREGATION_RULE(I).name1
              INTO v_AGGREGATION_SQL
              FROM DUAL;

          ELSE

            SELECT v_AGGREGATION_SQL || '
           ,' || pi_AGGREGATION_RULE(I).name2 || ' ( ' || pi_AGGREGATION_RULE(I)
                   .name1 || ' ) AS ' || pi_AGGREGATION_RULE(I).name1
              INTO v_AGGREGATION_SQL
              FROM DUAL;

          end if;

        END LOOP;

        if (pi_END is not null) then
          SELECT v_AGGREGATION_SQL || '
           ,max(' || pi_END ||
                 ') KEEP(DENSE_RANK LAST ORDER BY ' || pi_AGGREGATION_ORDER ||
                 ' ) as ' || pi_END
            INTO v_AGGREGATION_SQL
            FROM DUAL;

        end if;

        SELECT v_sql || v_AGGREGATION_SQL INTO v_sql FROM DUAL;
      END IF;

    end if;

    -- add dump table name
    SELECT v_sql || ' FROM ' || pi_DUMP_TABLE || ' dp 'INTO v_sql FROM DUAL;

    --where clause

    IF (pi_ENTITY_COL_MAPPING IS NOT NULL
       ) THEN
      --dbms_output.put_line(' pi_ENTITY_COL_MAPPING');


      IF (pi_ENTITY_COL_MAPPING.COUNT <> 0) THEN
        --dbms_output.put_line(pi_ENTITY_COL_MAPPING.COUNT);
        FOR I IN 1 .. pi_ENTITY_COL_MAPPING.COUNT LOOP

          v_TEMP_SQL := ' (
                 (' || pi_ENTITY_COL_MAPPING(I).name1 ||
                        ' is  null and ' || pi_ENTITY_COL_MAPPING(I).name2 ||
                        ' is null)
                 or  ' || pi_ENTITY_COL_MAPPING(I).name2 ||
                        ' is not  null
                 ) ';

          SELECT DECODE(v_WHERE_SQL,
                        NULL,
                        v_WHERE_SQL || v_TEMP_SQL,
                        v_WHERE_SQL || ' AND ' || v_TEMP_SQL)
            INTO v_WHERE_SQL
            FROM DUAL;

        END LOOP;

      END IF;

    END IF;

    IF (
        pi_PERIOD_COL_MAPPING IS NOT NULL) THEN

      --dbms_output.put_line('pi_PERIOD_COL_MAPPING');
      IF (pi_PERIOD_COL_MAPPING.COUNT <> 0) THEN
        dbms_output.put_line(pi_PERIOD_COL_MAPPING.COUNT);
        FOR I IN 1 .. pi_PERIOD_COL_MAPPING.COUNT LOOP

          v_TEMP_SQL := ' (
                 (' || pi_PERIOD_COL_MAPPING(I).name1 ||
                        ' is  null and ' || pi_PERIOD_COL_MAPPING(I).name2 ||
                        ' is null)
                 or  ' || pi_PERIOD_COL_MAPPING(I).name2 ||
                        ' is not  null
                 ) ';

          SELECT DECODE(v_WHERE_SQL,
                        NULL,
                        v_WHERE_SQL || v_TEMP_SQL,
                        v_WHERE_SQL || ' AND ' || v_TEMP_SQL)
            INTO v_WHERE_SQL
            FROM DUAL;

        END LOOP;

      END IF;

    END IF;

      FOR i IN 1 .. REGEXP_COUNT(v_KEY_COLUMNS, ',')+1
      LOOP
          SELECT regexp_substr(v_KEY_COLUMNS, '[^,]+', 1, i) INTO v_FIELDS FROM DUAL;



    SELECT decode(v_INTERNAL_WHERE, null,

    v_INTERNAL_WHERE||' ( '||'op.'||v_FIELDS||'= dp.'||v_FIELDS||' or (op.'||v_FIELDS||' is null and dp.'||v_FIELDS||' is null ) ) ',

      v_INTERNAL_WHERE||' and '||' ( '||'op.'||v_FIELDS||'= dp.'||v_FIELDS||' or (op.'||v_FIELDS||' is null and dp.'||v_FIELDS||' is null ) ) ')
      into v_INTERNAL_WHERE from dual;



      END LOOP;


  v_TEMP_SQL:=' WHERE NOT EXISTS (SELECT 1 FROM '||pi_DEST_TABLE
                   ||' op WHERE  '||v_INTERNAL_WHERE||'  )';

  SELECT decode(v_WHERE_SQL, null,v_TEMP_SQL,
      v_TEMP_SQL||' and '||v_WHERE_SQL)
      into v_WHERE_SQL from dual;


    SELECT v_sql || v_WHERE_SQL INTO v_sql FROM DUAL;

    IF (pi_AGGREGATION_RULE IS NOT NULL) then

      select v_sql || ' group by ' || v_KEY_COLUMNS into v_sql from dual;

    end if;

    loop
      exit when l_offset > dbms_lob.getlength(v_sql);
      dbms_output.put_line(dbms_lob.substr(v_sql, 3000, l_offset));
      l_offset := l_offset + 3000;
    end loop;

    commons_ddl_handling.execute_ddl_nolog(v_sql);

  end;*/

  PROCEDURE HIERARCHY_OVERLAP_CHECK(pin_Table            IN CLOB,
                                    pin_KeyFields        IN CLOB,
                                    pin_EntityUpperAlias IN VARCHAR2,
                                    pin_ValueUpperAlias  IN VARCHAR2,
                                    pin_EffectiveStart   IN VARCHAR2,
                                    pin_EffectiveEnd     IN VARCHAR2,
                                    pin_IsPeriod         IN NUMBER,
                                    pin_Data             IN CLOB DEFAULT NULL,
                                    pout_OverlapChkRes   OUT NUMBER)
  -----------------------------------------------------------------------------------------
    -- Assumptions:
    -- Input Parameters are built using valid column names
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_Table                  The table or view name in which the unique is checked
    --    pin_KeyFields              The fields that are used to check unique upon
    --    pin_EntityUpperAlias       The alias of the upper entity
    --    pin_ValueUpperAlias        The alias of the lower entity
    --    pin_EffectiveStart         The column name of the start time unit
    --    pin_EffectiveEnd           The column name of the end time unit
    --    pin_IsPeriod               0 - if the hierarchy is effective for a range of dates, 1 - if the hierarchy is effective for a range of periods
    --    pout_OverlapChkRes         The output of the procedure: 1 - the values in key fields are unique, 0 - the values in key fields are not unique
    -----------------------------------------------------------------------------------------
    -- Output : Returns 1 if the validations pass, 0 if there are overlapping records
    -----------------------------------------------------------------------------------------
    /*
    -- Example:
    DECLARE
       V_RESULT PLS_INTEGER;
    BEGIN
       V_RESULT := COMMONS_TABLES.HIERARCHY_OVERLAP_CHECK(pin_Table            => 'T100',
                                                          pin_KeyFields        => 'F1,F2',
                                                          pin_EntityUpperAlias => 'ENTITY_UPPER',
                                                          pin_ValueUpperAlias  => 'VALUE_UPPER',
                                                          pin_EffectiveStart   => 'F1000',
                                                          pin_EffectiveEnd     => 'F1001',
                                                          pout_OverlapChkRes   => V_RESULT);
    END;
     */
    -----------------------------------------------------------------------------------------
   IS
    V_KEY_COLS       CLOB := pin_KeyFields || ',';
    V_JOIN_CONDITION CLOB := '';
    V_FIELDS         VARCHAR2(30 CHAR) := '';
    V_OVERLAP_STR    CLOB := '';
    V_OVERLAP_RESULT NUMBER;
    ROW_IDENTIFIER CONSTANT VARCHAR2(30 CHAR) := 'ROW_IDENTIFIER';
  BEGIN
    IF (pin_KeyFields IS NULL) THEN
      V_JOIN_CONDITION := NULL;
    ELSE
      V_JOIN_CONDITION := ' AND ';

      -- Create the string v_JOIN_CONDITION (logic to parse comma separated pi_KEY_FIELDS)
      FOR I IN 1 .. REGEXP_COUNT(V_KEY_COLS, ',') LOOP
        SELECT REGEXP_SUBSTR(V_KEY_COLS, '[^,]+', 1, I)
          INTO V_FIELDS
          FROM DUAL;

        /*V_JOIN_CONDITION := V_JOIN_CONDITION || ' (( A.' || V_FIELDS ||
        ' = B.' || V_FIELDS || ') OR (A.' || V_FIELDS ||
        ' IS NULL AND B.' || V_FIELDS ||
        ' IS NULL )) AND';*/
        V_JOIN_CONDITION := V_JOIN_CONDITION || ' ( A.' || V_FIELDS ||
                            ' = B.' || V_FIELDS || ')  AND';
      END LOOP;

      V_JOIN_CONDITION := SUBSTR(V_JOIN_CONDITION,
                                 1,
                                 LENGTH(V_JOIN_CONDITION) - 4);
    END IF;

    -- Overlap and date check
    --
    IF (pin_IsPeriod = 0) THEN
      IF (pin_Data IS NULL) THEN
        V_OVERLAP_STR := 'WITH C AS ' || pin_Table ||
                         'SELECT COUNT(*) FROM DUAL ' ||
                         'WHERE EXISTS(SELECT /*+ USE_HASH(A,B) */ A.* FROM (SELECT * FROM C) A, (SELECT * FROM C) B ' ||
                         'WHERE NVL(A.' || pin_EffectiveStart ||
                         ', TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) <= NVL(B.' ||
                         pin_EffectiveEnd ||
                         ', TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) AND ' ||
                         'NVL(A.' || pin_EffectiveEnd ||
                         ', TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) >= NVL(B.' ||
                         pin_EffectiveStart ||
                         ', TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) AND ' ||
                         '(A.' || pin_EntityUpperAlias || ' <> B.' ||
                         pin_EntityUpperAlias || ' OR A.' ||
                         pin_ValueUpperAlias || ' <> B.' ||
                         pin_ValueUpperAlias || ' OR A.' || ROW_IDENTIFIER ||
                         ' <> B.' || ROW_IDENTIFIER || ')' ||
                         V_JOIN_CONDITION || ')';
      ELSE
        V_OVERLAP_STR := pin_Data || ', C AS ' || pin_Table ||
                         'SELECT COUNT(*) FROM DUAL ' ||
                         'WHERE EXISTS(SELECT /*+ USE_HASH(A,B) */ A.* FROM (SELECT * FROM C) A, (SELECT * FROM C) B ' ||
                         'WHERE NVL(A.' || pin_EffectiveStart ||
                         ', TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) <= NVL(B.' ||
                         pin_EffectiveEnd ||
                         ', TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) AND ' ||
                         'NVL(A.' || pin_EffectiveEnd ||
                         ', TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) >= NVL(B.' ||
                         pin_EffectiveStart ||
                         ', TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) AND ' ||
                         '(A.' || pin_EntityUpperAlias || ' <> B.' ||
                         pin_EntityUpperAlias || ' OR A.' ||
                         pin_ValueUpperAlias || ' <> B.' ||
                         pin_ValueUpperAlias || ' OR A.' || ROW_IDENTIFIER ||
                         ' <> B.' || ROW_IDENTIFIER || ')' ||
                         V_JOIN_CONDITION || ')';
      END IF;
    ELSE
      IF (pin_Data IS NULL) THEN
        V_OVERLAP_STR := 'WITH C AS ' || pin_Table ||
                         'SELECT COUNT(*)  FROM DUAL ' ||
                         'WHERE EXISTS (SELECT /*+ USE_HASH(A,B) */ A.* FROM (SELECT * FROM C) A, (SELECT * FROM C) B, TU_PERIODS_RANGE A_TUPR_START, TU_PERIODS_RANGE A_TUPR_END, TU_PERIODS_RANGE B_TUPR_START, TU_PERIODS_RANGE B_TUPR_END ' ||
                         'WHERE NVL(A_TUPR_START.TUPR_START_DATE,TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) <= NVL(B_TUPR_END.TUPR_END_DATE, TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) AND ' ||
                         'NVL(A_TUPR_END.TUPR_END_DATE,TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) >= NVL(B_TUPR_START.TUPR_START_DATE, TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) AND ' || 'A.' ||
                         pin_EffectiveStart ||
                         ' = A_TUPR_START.TUPR_ID(+) AND A.' ||
                         pin_EffectiveEnd ||
                         ' = A_TUPR_END.TUPR_ID(+) AND ' || 'B.' ||
                         pin_EffectiveStart ||
                         ' = B_TUPR_START.TUPR_ID(+) AND B.' ||
                         pin_EffectiveEnd ||
                         ' = B_TUPR_END.TUPR_ID(+) AND ' || '(A.' ||
                         pin_EntityUpperAlias || ' <> B.' ||
                         pin_EntityUpperAlias || ' OR A.' ||
                         pin_ValueUpperAlias || ' <> B.' ||
                         pin_ValueUpperAlias || ' OR A.' || ROW_IDENTIFIER ||
                         ' <> B.' || ROW_IDENTIFIER || ')' ||
                         V_JOIN_CONDITION || ')';
      ELSE
        V_OVERLAP_STR := pin_Data || ', C AS ' || pin_Table ||
                         'SELECT COUNT(*)  FROM DUAL ' ||
                         'WHERE EXISTS (SELECT /*+ USE_HASH(A,B) */ A.* FROM (SELECT * FROM C) A, (SELECT * FROM C) B, TU_PERIODS_RANGE A_TUPR_START, TU_PERIODS_RANGE A_TUPR_END, TU_PERIODS_RANGE B_TUPR_START, TU_PERIODS_RANGE B_TUPR_END ' ||
                         'WHERE NVL(A_TUPR_START.TUPR_START_DATE,TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) <= NVL(B_TUPR_END.TUPR_END_DATE, TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) AND ' ||
                         'NVL(A_TUPR_END.TUPR_END_DATE,TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')) >= NVL(B_TUPR_START.TUPR_START_DATE, TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')) AND ' || 'A.' ||
                         pin_EffectiveStart ||
                         ' = A_TUPR_START.TUPR_ID(+) AND A.' ||
                         pin_EffectiveEnd ||
                         ' = A_TUPR_END.TUPR_ID(+) AND ' || 'B.' ||
                         pin_EffectiveStart ||
                         ' = B_TUPR_START.TUPR_ID(+) AND B.' ||
                         pin_EffectiveEnd ||
                         ' = B_TUPR_END.TUPR_ID(+) AND ' || '(A.' ||
                         pin_EntityUpperAlias || ' <> B.' ||
                         pin_EntityUpperAlias || ' OR A.' ||
                         pin_ValueUpperAlias || ' <> B.' ||
                         pin_ValueUpperAlias || ' OR A.' || ROW_IDENTIFIER ||
                         ' <> B.' || ROW_IDENTIFIER || ')' ||
                         V_JOIN_CONDITION || ')';
      END IF;
    END IF;

    /*DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_OVERLAP_STR,amount => 1000,offset => 1));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_OVERLAP_STR,amount => 1000,offset => 1001));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_OVERLAP_STR,amount => 1000,offset => 2001));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_OVERLAP_STR,amount => 1000,offset => 3001));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_OVERLAP_STR,amount => 1000,offset => 4001));
    DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');*/
    EXECUTE IMMEDIATE v_OVERLAP_STR
      INTO V_OVERLAP_RESULT;

    -- Overlap check
    IF V_OVERLAP_RESULT = 1 THEN
      pout_OverlapChkRes := 0;
    ELSE
      pout_OverlapChkRes := 1;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      /*DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.format_error_stack);
      DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.format_error_backtrace);
      RAISE;*/
      raise_application_error(-20101,
                              'Hierarchy Overlap Check encountered an error');
  END HIERARCHY_OVERLAP_CHECK;

  PROCEDURE HIERARCHY_UNIQUE_CHECK(pin_Table         IN CLOB,
                                   pin_KeyFields     IN CLOB,
                                   pout_UniqueChkRes OUT NUMBER)
  -----------------------------------------------------------------------------------------
    -- Assumptions:
    -- Input Parameters are built using valid column names
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_Table                  The table or view name in which the unique is checked
    --    pin_KeyFields              The fields that are used to check unique upon
    --    pout_UniqueChkRes          The output of the procedure: 1 - the values in key fields are unique, 0 - the values in key fields are not unique
    -----------------------------------------------------------------------------------------
    -- Output : Returns 1 if the validations pass, 0 if there are duplicate values
    -----------------------------------------------------------------------------------------
    /*
    -- Example:
    DECLARE
       V_RESULT PLS_INTEGER;
    BEGIN
       V_RESULT := COMMONS_TABLES.HIERARCHY_UNIQUE_CHECK(pin_Table          => 'T100',
                                                         pin_KeyFields      => 'F1,F2',
                                                         pout_UniqueChkRes  => V_RESULT);
    END;
     */
    -----------------------------------------------------------------------------------------
   IS
    V_DUPLICATE_CNT NUMBER(10);
  BEGIN
    EXECUTE IMMEDIATE ' SELECT MAX(COUNT(*)) FROM ' || pin_Table ||
                      ' GROUP BY ' || pin_KeyFields
      INTO V_DUPLICATE_CNT;

    IF NVL(V_DUPLICATE_CNT, 1) = 1 THEN
      pout_UniqueChkRes := 1;
    ELSE
      pout_UniqueChkRes := 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      raise_application_error(-20101,
                              'Hierarchy Unique Check encountered an error');
      --DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.format_error_stack || ' ' || DBMS_UTILITY.format_error_backtrace);
  END HIERARCHY_UNIQUE_CHECK;

  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /* pin_table_name             IN  VARCHAR2   the table for which the multi edit save is done (usually a T table)
     pin_add_fields            IN  VARCHAR2   fields to be merged in final resultset; these fields valid table fields and they aren`t found in pin_data
     pin_data                   IN  CLOB        a CLOB variable holding the edited data in the form of a cursor
  */
  /*example:
   DECLARE
       pin_table_name    VARCHAR2(32);
       pin_add_fields  VARCHAR2(32767);
       pin_data       clob;
       c             sys_refCursor;
   BEGIN
       pin_table_name := 'T152';
       pin_add_fields := 'F11, F25';
       pin_data :=
         'SELECT 1 ROW_IDENTIFIER, 0 ROW_VERSION, TO_DATE(''01.01.2006'',''DD.MM.YYYY'') START_DATE, TO_DATE(''01.01.2011'',''DD.MM.YYYY'') END_DATE, 1001 F100, 3423 E_INTERNAL_ID FROM DUAL UNION ALL
          SELECT 2 ,               0,             TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         1002,      15                 FROM DUAL';

      c:=Resultset_Merge_Fields(pin_table_name,pin_add_fields,pin_data);
   END;
  */
  -----------------------------------------------------------------------------------------

  FUNCTION Resultset_Merge_Fields(pin_table_name VARCHAR2,
                                  pin_add_fields VARCHAR2,
                                  pin_data       CLOB,
                                  stale_check    SIMPLE_INTEGER DEFAULT 0)
    RETURN SYS_REFCURSOR IS
    v_refc       SYS_REFCURSOR;
    v_sql        CLOB;
    v_listofcols VARCHAR2(32767);
  BEGIN
    v_listofcols := 'T.' || REPLACE(pin_add_fields, ',', ', T.');
    -- dbms_output.put_line(v_listofcols);

    v_sql := '
      select data.*, ' || v_listofcols || ' from (' || pin_data ||
             ') data
      left join ' || pin_table_name || ' T
           on data.row_identifier=t.row_identifier ' ||
             CASE stale_check
               WHEN 1 THEN
                ' where data.row_version=t.row_version'
               ELSE
                NULL
             END;

    --dbms_output.put_line(v_sql);
    OPEN v_refc FOR v_sql;

    RETURN v_refc;
  END;

  FUNCTION HIERARCHY_VALIDATIONS(pin_RelationshipTables IN TABLETYPE_RELATIONSHIP_TABLES,
                                 pin_TimeUnit           IN NUMBER DEFAULT NULL,
                                 pin_StartTimeUnitCol   IN VARCHAR2 DEFAULT NULL,
                                 pin_EndTimeUnitCol     IN VARCHAR2 DEFAULT NULL,
                                 pin_Data               IN CLOB DEFAULT NULL)
    RETURN NUMBER
  -- Assumptions:
    -- Input Parameters are built using valid column names
    -- the pin_RelationshipTables parameter should contain the top relationship table as the first object in collection
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_RelationshipTables    Collection that contains all the relationship tables
    --    pin_TimeUnit              If the hierarchy is effective for a range of dates or periods, can have the following values: 0 - effective for a range of dates,
    --                              1 - effective for a range of periods. If hierarchy is not effective for a range of dates or periods, it will be NULL
    --    pin_StartTimeUnitCol      If the hierarchy is effective for a range of dates or periods then it is the column name for the start time unit, else NULL
    --    pin_EndTimeUnitCol        If the hierarchy is effective for a range of dates or periods then it is the column name for the end time unit, else NULL
    -----------------------------------------------------------------------------------------
    -- Output : Returns 0 if the validations pass, 1 if there are cycles or 2 if there is an entity with more than one parent
    -----------------------------------------------------------------------------------------
    /*
    -- Example:
    DECLARE
       V_RELATIONSHIP_TABLES TABLETYPE_RELATIONSHIP_TABLES:=TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE('TERRITORY_2_MANAGER2',1,2,'VALUE_UPPER','VALUE_LOWER'),
                                                                                          OBJTYPE_RELATIONSHIP_TABLE('AGENT_2_TERRITORY2',2,3,'VALUE_UPPER','VALUE_LOWER'),
                                                                                          OBJTYPE_RELATIONSHIP_TABLE('STORE_2_AGENT2',3,4,'VALUE_UPPER','VALUE_LOWER'),
                                                                                          OBJTYPE_RELATIONSHIP_TABLE('MANAGER_2_STORE2',4,1,'VALUE_UPPER','VALUE_LOWER'));
       V_RESULT PLS_INTEGER;
    BEGIN
       V_RESULT := COMMONS_TABLES.HIERARCHY_VALIDATIONS(pin_RelationshipTables => V_RELATIONSHIP_TABLES,
                                                        pin_TimeUnit => 1,
                                                        pin_StartTimeUnitCol => 'START_QUARTER',
                                                        pin_EndTimeUnitCol => 'END_QUARTER');
    END;
     */
   IS
    V_HIERARCHICAL_QUERY CLOB;
    V_RELATIONSHIP_QUERY CLOB;
    V_UNION_ALL          CLOB := '(';
    V_SELECT_CLAUSE      CLOB;
    V_START_WITH_CLAUSE  CLOB;
    V_CONNECT_BY_CLAUSE  CLOB;
    --
    V_RELATIONSHIP_SELECT CLOB;
    V_RELATIONSHIP_FROM   CLOB;
    --
    V_TU_PERIODS_TABLE       CONSTANT VARCHAR2(30 CHAR) := 'TU_PERIODS_RANGE';
    V_TU_PERIODS_TAB_ALIAS1  CONSTANT VARCHAR2(30 CHAR) := 'TUPR1';
    V_TU_PERIODS_TAB_ALIAS2  CONSTANT VARCHAR2(30 CHAR) := 'TUPR2';
    V_TUPR_ID                CONSTANT VARCHAR2(30 CHAR) := 'TUPR_ID';
    V_TUPR_START_DATE        CONSTANT VARCHAR2(30 CHAR) := 'TUPR_START_DATE';
    V_TUPR_END_DATE          CONSTANT VARCHAR2(30 CHAR) := 'TUPR_END_DATE';
    V_RELATIONSHIP_TAB_ALIAS CONSTANT VARCHAR2(30 CHAR) := 'T';
    V_LOWEST_DATE            CONSTANT VARCHAR2(50 CHAR) := 'TO_DATE(''01/01/0001'', ''DD/MM/YYYY'')';
    V_GREATEST_DATE          CONSTANT VARCHAR2(50 CHAR) := 'TO_DATE(''31/12/9999'', ''DD/MM/YYYY'')';
    --
    V_MULTIPARENT_CHECK PLS_INTEGER;
    V_CYCLE_CHECK       NUMBER;
    --
    ENTITY_UPPER_ALIAS CONSTANT VARCHAR2(100) := 'ENTITY_UPPER';
    ENTITY_LOWER_ALIAS CONSTANT VARCHAR2(100) := 'ENTITY_LOWER';
    VALUE_UPPER_ALIAS  CONSTANT VARCHAR2(100) := 'VALUE_UPPER';
    VALUE_LOWER_ALIAS  CONSTANT VARCHAR2(100) := 'VALUE_LOWER';
    ROW_IDENTIFIER     CONSTANT VARCHAR2(100) := 'ROW_IDENTIFIER';
    --
    E_CYCLE_EXCEPTION EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_CYCLE_EXCEPTION, -1436);
    --
  BEGIN
    -- VALIDATION PART
    IF pin_RelationshipTables IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'pin_RelationshipTables parameter can not be null');
    END IF;

    IF pin_TimeUnit IS NOT NULL AND pin_TimeUnit NOT IN (0, 1) THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'pin_TimeUnit parameter has invalid values');
    END IF;

    IF pin_TimeUnit IS NOT NULL AND
       (pin_StartTimeUnitCol IS NULL OR pin_EndTimeUnitCol IS NULL) THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'pin_StartTimeUnitCol or pin_EndTimeUnitCol parameter cannot be NULL');
    END IF;

    -- CREATE "SELECT" CLAUSE,"START WITH" AND "CONNECT BY" OF THE HIERARCHICAL QUERY
    V_SELECT_CLAUSE     := ENTITY_UPPER_ALIAS || ',' || ENTITY_LOWER_ALIAS || ',' ||
                           VALUE_UPPER_ALIAS || ',' || VALUE_LOWER_ALIAS;
    V_START_WITH_CLAUSE := VALUE_UPPER_ALIAS || ' IN (SELECT ' || pin_RelationshipTables(1)
                          .VALUE_UPPER_COL || ' FROM ' || pin_RelationshipTables(1)
                          .TABLE_NAME || ') ' || 'AND ' ||
                           ENTITY_UPPER_ALIAS || ' = ' || pin_RelationshipTables(1)
                          .ENTITY_UPPER;
    V_CONNECT_BY_CLAUSE := 'PRIOR ' || VALUE_LOWER_ALIAS || ' = ' ||
                           VALUE_UPPER_ALIAS || ' AND PRIOR ' ||
                           ENTITY_LOWER_ALIAS || ' = ' ||
                           ENTITY_UPPER_ALIAS;

    -- CREATE UNION ALL VIEW OF THE RELATIONSHIP TABLES
    FOR I IN 1 .. pin_RelationshipTables.COUNT LOOP
      -- CREATE SELECT STATEMENT FOR EVERY RELATIONSHIP TABLE AND APPEND IT TO HIERARCHICHAL QUERY
      V_RELATIONSHIP_SELECT := pin_RelationshipTables(I)
                               .ENTITY_UPPER || ' ' || ENTITY_UPPER_ALIAS || ', ' || pin_RelationshipTables(I)
                               .ENTITY_LOWER || ' ' || ENTITY_LOWER_ALIAS || ', ' ||
                                V_RELATIONSHIP_TAB_ALIAS || TO_CHAR(I) || '.' || pin_RelationshipTables(I)
                               .VALUE_UPPER_COL || ' ' || VALUE_UPPER_ALIAS || ', ' ||
                                V_RELATIONSHIP_TAB_ALIAS || TO_CHAR(I) || '.' || pin_RelationshipTables(I)
                               .VALUE_LOWER_COL || ' ' || VALUE_LOWER_ALIAS || ', ' ||
                                V_RELATIONSHIP_TAB_ALIAS || TO_CHAR(I) || '.' ||
                                ROW_IDENTIFIER || ' ' || ROW_IDENTIFIER;

      IF pin_TimeUnit IS NOT NULL THEN
        V_RELATIONSHIP_SELECT := V_RELATIONSHIP_SELECT || ', ' ||
                                 V_RELATIONSHIP_TAB_ALIAS || TO_CHAR(I) || '.' ||
                                 pin_StartTimeUnitCol || ', ' ||
                                 V_RELATIONSHIP_TAB_ALIAS || TO_CHAR(I) || '.' ||
                                 pin_EndTimeUnitCol;
      END IF;

      V_RELATIONSHIP_FROM  := pin_RelationshipTables(I)
                              .TABLE_NAME || ' ' || V_RELATIONSHIP_TAB_ALIAS ||
                               TO_CHAR(I);
      V_RELATIONSHIP_QUERY := 'SELECT ' || V_RELATIONSHIP_SELECT ||
                              ' FROM ' || V_RELATIONSHIP_FROM;
      V_UNION_ALL          := V_UNION_ALL || V_RELATIONSHIP_QUERY ||
                              ' UNION ALL ';
    END LOOP;

    -- REMOVE THE LAST ' UNION ALL ' AND APPEND ')'
    -- OF-4647 - Remove call to DBMS_LOB in COMMONS_TABLES - START
    -- V_UNION_ALL := DBMS_LOB.substr(V_UNION_ALL,DBMS_LOB.getlength(V_UNION_ALL) - 11,1) || ')';
    V_UNION_ALL := SUBSTR(TO_CHAR(V_UNION_ALL),
                          1,
                          LENGTH(TO_CHAR(V_UNION_ALL)) - 11) || ')';

    -- OF-4647 - Remove call to DBMS_LOB in COMMONS_TABLES - END
    /*DBMS_OUTPUT.PUT_LINE('-------------------------------------------   UNION ALL   ---------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_UNION_ALL,amount => 1000,offset => 1));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_UNION_ALL,amount => 1000,offset => 1001));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_UNION_ALL,amount => 1000,offset => 2001));
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------------------------------------------');*/
    --
    IF pin_TimeUnit IS NULL THEN
      -- IF HIERARCHY IS NOT EFFECTIVE FOR A RANGE OF DATES OR PERIODS, UNIQUE CHECK COVERS PARENT CHECK
      IF (pin_data IS NULL) THEN
        COMMONS_TABLES.HIERARCHY_UNIQUE_CHECK(pin_Table         => V_UNION_ALL,
                                              pin_KeyFields     => ENTITY_LOWER_ALIAS || ',' ||
                                                                   VALUE_LOWER_ALIAS,
                                              pout_UniqueChkRes => V_MULTIPARENT_CHECK);
      ELSE
        COMMONS_TABLES.HIERARCHY_UNIQUE_CHECK(pin_Table         => '(' ||
                                                                   pin_data ||
                                                                   V_UNION_ALL || ')',
                                              pin_KeyFields     => ENTITY_LOWER_ALIAS || ',' ||
                                                                   VALUE_LOWER_ALIAS,
                                              pout_UniqueChkRes => V_MULTIPARENT_CHECK);
      END IF;
    ELSE
      -- IF HIERARCHY IS EFFECTIVE FOR A RANGE OF DATES OR PERIOD
      -- OVERLAP CHECK COVERS PARENT CHECK
      COMMONS_TABLES.HIERARCHY_OVERLAP_CHECK(pin_Table            => V_UNION_ALL,
                                             pin_KeyFields        => ENTITY_LOWER_ALIAS || ',' ||
                                                                     VALUE_LOWER_ALIAS,
                                             pin_EntityUpperAlias => ENTITY_UPPER_ALIAS,
                                             pin_ValueUpperAlias  => VALUE_UPPER_ALIAS,
                                             pin_EffectiveStart   => pin_StartTimeUnitCol,
                                             pin_EffectiveEnd     => pin_EndTimeUnitCol,
                                             pin_IsPeriod         => pin_TimeUnit,
                                             pin_Data             => pin_Data,
                                             pout_OverlapChkRes   => V_MULTIPARENT_CHECK);

      -- CREATE HIERARCHICAL QUERY
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ',' || pin_StartTimeUnitCol || ',' ||
                         pin_EndTimeUnitCol;

      -- IF THE HIERARCHY IS EFFECTIVE FOR A RANGE OF PERIODS, JOIN WITH TU_PERIODS_RANGE
      IF pin_TimeUnit = 1 THEN
        V_UNION_ALL         := V_UNION_ALL || ' LEFT JOIN ' ||
                               V_TU_PERIODS_TABLE || ' ' ||
                               V_TU_PERIODS_TAB_ALIAS1 || ' ON ' ||
                               pin_StartTimeUnitCol || ' = ' ||
                               V_TU_PERIODS_TAB_ALIAS1 || '.' || V_TUPR_ID ||
                               ' LEFT JOIN ' || V_TU_PERIODS_TABLE || ' ' ||
                               V_TU_PERIODS_TAB_ALIAS2 || ' ON ' ||
                               pin_EndTimeUnitCol || ' = ' ||
                               V_TU_PERIODS_TAB_ALIAS2 || '.' || V_TUPR_ID;
        V_CONNECT_BY_CLAUSE := V_CONNECT_BY_CLAUSE || ' AND PRIOR NVL(' ||
                               V_TU_PERIODS_TAB_ALIAS1 || '.' ||
                               V_TUPR_START_DATE || ',' || V_LOWEST_DATE ||
                               ') <= NVL(' || V_TU_PERIODS_TAB_ALIAS2 || '.' ||
                               V_TUPR_END_DATE || ',' || V_GREATEST_DATE || ')' ||
                               ' AND PRIOR NVL(' || V_TU_PERIODS_TAB_ALIAS2 || '.' ||
                               V_TUPR_END_DATE || ',' || V_GREATEST_DATE ||
                               ') >= NVL(' || V_TU_PERIODS_TAB_ALIAS1 || '.' ||
                               V_TUPR_START_DATE || ',' || V_LOWEST_DATE || ')';
      ELSE
        V_CONNECT_BY_CLAUSE := V_CONNECT_BY_CLAUSE || ' AND PRIOR NVL(' ||
                               pin_StartTimeUnitCol || ',' || V_LOWEST_DATE ||
                               ') <= NVL(' || pin_EndTimeUnitCol || ',' ||
                               V_GREATEST_DATE || ')' || ' AND PRIOR NVL(' ||
                               pin_EndTimeUnitCol || ',' || V_GREATEST_DATE ||
                               ') >= NVL(' || pin_StartTimeUnitCol || ',' ||
                               V_LOWEST_DATE || ')';
      END IF;
    END IF;

    -- IF THERE ARE NODES WITH MORE THAN ONE PARENT RETURN 2
    IF V_MULTIPARENT_CHECK = 0 THEN
      RETURN 2;
    END IF;

    -- CREATE HIERARCHICAL QUERY AND EXECUTE, IF THERE ARE CYCLES IN THE HIERARCHY RETURN 1
    -- CHECK IF Pin_Data IS NOT NULL TO ADD THE WITH CLAUSE
    IF pin_Data IS NULL THEN
      V_HIERARCHICAL_QUERY := 'SELECT COUNT(*) FROM ' || V_UNION_ALL ||
                              ' CONNECT BY ' || V_CONNECT_BY_CLAUSE; --' START WITH ' || V_START_WITH_CLAUSE ||
    ELSE
      V_HIERARCHICAL_QUERY := pin_Data || 'SELECT COUNT(*) FROM ' ||
                              V_UNION_ALL || ' CONNECT BY ' ||
                              V_CONNECT_BY_CLAUSE; --' START WITH ' || V_START_WITH_CLAUSE ||
    END IF;

    /*DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_HIERARCHICAL_QUERY,amount => 1000,offset => 1));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_HIERARCHICAL_QUERY,amount => 1000,offset => 1001));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(lob_loc => V_HIERARCHICAL_QUERY,amount => 1000,offset => 2001));*/
    -- dbms_output.put_line(V_HIERARCHICAL_QUERY);

    EXECUTE IMMEDIATE V_HIERARCHICAL_QUERY
      INTO V_CYCLE_CHECK;

    --
    --DBMS_OUTPUT.put_line(DBMS_LOB.substr(V_UNION_ALL,1000,1));
    RETURN 0;
  EXCEPTION
    WHEN E_CYCLE_EXCEPTION THEN
      RETURN 1;
    WHEN OTHERS THEN
      -- dbms_output.put_line(DBMS_UTILITY.format_error_stack || ' ' ||
      --                    DBMS_UTILITY.format_error_backtrace);
      RAISE;
  END HIERARCHY_VALIDATIONS;

  FUNCTION ADJ_HIERARCHY_VALIDATIONS(pin_RelationshipTable  IN VARCHAR2,
                                     pin_Data               IN CLOB,
                                     pin_RelationshipTables IN TABLETYPE_RELATIONSHIP_TABLES,
                                     pin_TimeUnit           IN NUMBER DEFAULT NULL,
                                     pin_StartTimeUnitCol   IN VARCHAR2 DEFAULT NULL,
                                     pin_EndTimeUnitCol     IN VARCHAR2 DEFAULT NULL)
    RETURN NUMBER
  -- Assumptions:
    -- Input Parameters are built using valid column names
    -- the pin_RelationshipTables parameter should contain the top relationship table as the first object in collection
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_RelationshipTable     The adjusted table name
    --    pin_Data                  The adjusted data
    --    pin_RelationshipTables    Collection that contains all the relationship tables
    --    pin_TimeUnit              If the hierarchy is effective for a range of dates or periods, can have the following values: 0 - effective for a range of dates,
    --                              1 - effective for a range of periods. If hierarchy is not effective for a range of dates or periods, it will be NULL
    --    pin_StartTimeUnitCol      If the hierarchy is effective for a range of dates or periods then it is the column name for the start time unit, else NULL
    --    pin_EndTimeUnitCol        If the hierarchy is effective for a range of dates or periods then it is the column name for the end time unit, else NULL
    -----------------------------------------------------------------------------------------
    -- Output : Returns 0 if the validations pass, 1 if there are cycles or 2 if there is an entity with more than one parent
    -----------------------------------------------------------------------------------------
    /*
    -- Example:
    DECLARE
       V_RELATIONSHIP_TABLES TABLETYPE_RELATIONSHIP_TABLES:=TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE('TERRITORY_2_MANAGER2',1,2,'VALUE_UPPER','VALUE_LOWER'),
                                                                                          OBJTYPE_RELATIONSHIP_TABLE('AGENT_2_TERRITORY2',2,3,'VALUE_UPPER','VALUE_LOWER'),
                                                                                          OBJTYPE_RELATIONSHIP_TABLE('STORE_2_AGENT2',3,4,'VALUE_UPPER','VALUE_LOWER'),
                                                                                          OBJTYPE_RELATIONSHIP_TABLE('MANAGER_2_STORE2',4,1,'VALUE_UPPER','VALUE_LOWER'));
       V_RESULT PLS_INTEGER;
       PIN_DATA :='SELECT 0 "UpdatedInsertedFlag",8 ROW_IDENTIFIER,0 ROW_VERSION,  TO_DATE(''01.01.2006'',''DD.MM.YYYY'') START_DATE, TO_DATE(''01.01.2011'',''DD.MM.YYYY'') END_DATE, ''Territory 6'' F11, 600 F25, 1001 F100, 3423 E_INTERNAL_ID FROM DUAL UNION ALL
                   SELECT 0,                      2,               5,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 2'' ,    200    , 1002 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                      3,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 4'' ,    400    , 1003 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                      5,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 4'' ,    400    , 1004 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                      4,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 3'' ,    900    , 1006 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                      6,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 5'' ,    44     , 1007 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                      7,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 1'' ,    100    , 1008 F100, 15                 FROM DUAL UNION ALL
                   SELECT 1,                    -10,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''Territory 6'' ,    600    , 1009 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                     11,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,         ''T12''         ,    99     , 1010 F100, 15                 FROM DUAL UNION ALL
                   SELECT 0,                      9,               0,              TO_DATE(''01.01.2001'',''DD.MM.YYYY'') ,           TO_DATE(''01.01.2021'',''DD.MM.YYYY'') ,          null           ,    77     , 1011 F100, 15                 FROM DUAL';
    BEGIN
       V_RESULT := COMMONS_TABLES.ADJ_HIERARCHY_VALIDATIONS(pin_RelationshipTable => 'AGENT_2_TERRITORY2',
                                                            pin_Data => PIN_DATA,
                                                            pin_RelationshipTables => V_RELATIONSHIP_TABLES,
                                                            pin_TimeUnit => 1,
                                                            pin_StartTimeUnitCol => 'START_QUARTER',
                                                            pin_EndTimeUnitCol => 'END_QUARTER');
    END;
     */
   IS
    V_MODIFIED_REL_TAB CLOB;
    V_REL_TAB_COL_LIST CLOB;
    V_ED_DATA_COL_LIST CLOB;
    V_MAIN_COL_LIST    CLOB;
    V_REL_TAB_ALIAS         CONSTANT VARCHAR2(30 CHAR) := 'T1';
    V_ED_DATA_ALIAS         CONSTANT VARCHAR2(30 CHAR) := 'TBL2';
    V_REL_TAB_COL_ALIAS_SUF CONSTANT VARCHAR2(30 CHAR) := '1';
    V_ED_DATA_COL_ALIAS_SUF CONSTANT VARCHAR2(30 CHAR) := '2';
    V_ROW_IDENTIFIER        CONSTANT VARCHAR2(30 CHAR) := 'ROW_IDENTIFIER';
    V_JOIN_CONDITION         CLOB;
    V_JOINED_REL_TAB         CLOB;
    V_DATA                   CLOB;
    V_RELATIONSHIPTABLES_AUX TABLETYPE_RELATIONSHIP_TABLES := pin_RelationshipTables;
    --
  BEGIN
    -- CREATE COLUMN LISTS WITH ALIASES FOR RELATIONSHIP TABLE AND EDITED DATA AND THE COLUMN LIST FOR THE MAIN SELECT
    -- THE ALIASES FOR THE COLUMNS IN THE MAIN SELECT WILL BE THE COLUMN NAMES IN THE pin_RelationshipTable TO KEEP THE LOGIC IN THE VALIDATION FUNCTION
    SELECT LISTAGG(V_REL_TAB_ALIAS || '.' || T.COLUMN_NAME || ' ' ||
                   T.COLUMN_NAME || V_REL_TAB_COL_ALIAS_SUF,
                   ',') WITHIN GROUP(ORDER BY NULL),
           LISTAGG(V_ED_DATA_ALIAS || '.' || T.COLUMN_NAME || ' ' ||
                   T.COLUMN_NAME || V_ED_DATA_COL_ALIAS_SUF,
                   ',') WITHIN GROUP(ORDER BY NULL),
           LISTAGG('NVL(' || T.COLUMN_NAME || V_ED_DATA_COL_ALIAS_SUF || ',' ||
                   T.COLUMN_NAME || V_REL_TAB_COL_ALIAS_SUF || ') ' ||
                   T.COLUMN_NAME,
                   ',') WITHIN GROUP(ORDER BY NULL)
      INTO V_REL_TAB_COL_LIST, V_ED_DATA_COL_LIST, V_MAIN_COL_LIST
      FROM USER_TAB_COLS T
     WHERE T.TABLE_NAME = pin_RelationshipTable;

    -- REPLACE THE DATE/PERIOD COLUMNS FROM NVL TO CASE
    IF (pin_StartTimeUnitCol IS NOT NULL) THEN
      V_MAIN_COL_LIST := REPLACE(REPLACE(V_MAIN_COL_LIST,
                                         'NVL(' || pin_StartTimeUnitCol ||
                                         V_ED_DATA_COL_ALIAS_SUF || ',' ||
                                         pin_StartTimeUnitCol ||
                                         V_REL_TAB_COL_ALIAS_SUF || ')',
                                         'CASE WHEN ROW_IDENTIFIER2 IS NULL THEN ' ||
                                         pin_StartTimeUnitCol ||
                                         V_REL_TAB_COL_ALIAS_SUF || ' ELSE ' ||
                                         pin_StartTimeUnitCol ||
                                         V_ED_DATA_COL_ALIAS_SUF || ' END '),
                                 'NVL(' || pin_EndTimeUnitCol ||
                                 V_ED_DATA_COL_ALIAS_SUF || ',' ||
                                 pin_EndTimeUnitCol ||
                                 V_REL_TAB_COL_ALIAS_SUF || ')',
                                 'CASE WHEN ROW_IDENTIFIER2 IS NULL THEN ' ||
                                 pin_EndTimeUnitCol ||
                                 V_REL_TAB_COL_ALIAS_SUF || ' ELSE ' ||
                                 pin_EndTimeUnitCol ||
                                 V_ED_DATA_COL_ALIAS_SUF || ' END ');
    END IF;

    -- CREATE JOIN CONDITION
    V_JOIN_CONDITION := V_REL_TAB_ALIAS || '.' || V_ROW_IDENTIFIER || ' = ' ||
                        V_ED_DATA_ALIAS || '.' || V_ROW_IDENTIFIER;
    -- CREATE JOINED RELATIONSHIP DATA SOURCE
    V_JOINED_REL_TAB := 'SELECT ' || V_REL_TAB_COL_LIST || ',' ||
                        V_ED_DATA_COL_LIST || ' FROM ' ||
                        pin_RelationshipTable || ' ' || V_REL_TAB_ALIAS ||
                        ' FULL OUTER JOIN ' || V_ED_DATA_ALIAS || ' ON ' ||
                        V_JOIN_CONDITION;
    -- CREATE MODIFIED RELATIONSHIP DATA SOURCE
    V_MODIFIED_REL_TAB := '(SELECT ' || V_MAIN_COL_LIST || ' FROM (' ||
                          V_JOINED_REL_TAB || '))';

    -- REPLACE RELATIONSHIP TABLE IN THE COLLECTION WITH THE MODIFIED RELATIONSHIP DATA SOURCE
    FOR I IN 1 .. V_RELATIONSHIPTABLES_AUX.COUNT LOOP
      IF V_RELATIONSHIPTABLES_AUX(I).TABLE_NAME = pin_RelationshipTable THEN
        V_RELATIONSHIPTABLES_AUX(I).TABLE_NAME := V_MODIFIED_REL_TAB;
      END IF;
    END LOOP;

    -- Construct the WITH query
    V_DATA := 'WITH ' || V_ED_DATA_ALIAS || ' AS (' || pin_Data || ')';
    -- CALL VALIDATION FUNCTION
    RETURN COMMONS_TABLES.HIERARCHY_VALIDATIONS(pin_RelationshipTables => V_RELATIONSHIPTABLES_AUX,
                                                pin_TimeUnit           => pin_TimeUnit,
                                                pin_StartTimeUnitCol   => pin_StartTimeUnitCol,
                                                pin_EndTimeUnitCol     => pin_EndTimeUnitCol,
                                                pin_Data               => V_DATA);
    -- FOR TESTS
    /*DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(V_MODIFIED_REL_TAB,1000,1));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(V_MODIFIED_REL_TAB,1000,1001));
    DBMS_OUTPUT.PUT_LINE(DBMS_LOB.substr(V_MODIFIED_REL_TAB,1000,2001));
    RETURN 0;*/
  END ADJ_HIERARCHY_VALIDATIONS;

  /*
  -- 14.May.2013 -- P.1. CREATE_INDEX
  PROCEDURE CREATE_INDEX(pi_tablename         in VARCHAR2,
                         pi_indexname         in VARCHAR2,
                         pi_col_list          in CLOB,
                         pi_uniqueness        in NUMBER,
                         pi_composite         in NUMBER,
                         pi_col_is_primarykey in NUMBER,
                         pi_initrans          in NUMBER DEFAULT 5,
                         pi_index_tablespace  in VARCHAR2 DEFAULT USER ||
                                                                  '_IND',
                         pi_nls_sort          in VARCHAR2 DEFAULT null,
                         po_indexing_info     OUT CLOB) IS
    v_transaction_id VARCHAR2(30 CHAR);
    v_index          NUMBER(10, 0);
    v_ddl            CLOB;
    v_undo_ddl       CLOB;
    --Get column list in collection
    TYPE COL_LIST_TYPE is TABLE OF VARCHAR2(30);
    v_col_list COL_LIST_TYPE := COL_LIST_TYPE();
    --v_composite_col_list COL_LIST_TYPE := COL_LIST_TYPE();

    TYPE RECTYPE_INDEX_EXP_POSITION IS RECORD(
      v_ind_expression  CLOB,
      v_column_position INTEGER);

    TYPE COLTYPE_INDEX_EXP_POSITION IS TABLE OF RECTYPE_INDEX_EXP_POSITION;

    v_records COLTYPE_INDEX_EXP_POSITION;

    v_count             INTEGER := 0;
    v_comma_position    PLS_INTEGER;
    v_position          PLS_INTEGER := 1;
    v_comma_count       INTEGER;
    v_decision_to_index INTEGER := 0;
    --v_column_count      INTEGER;
    v_indexname VARCHAR2(30) := UPPER(pi_indexname);
    v_data_type VARCHAR2(106);
    --v_long              LONG;
    --v_cnt               integer := 0;
    v_nlssort_column VARCHAR2(100);
    maximum_key_length_exceeded EXCEPTION;
    PRAGMA EXCEPTION_INIT(maximum_key_length_exceeded, -1450);
    v_new_line VARCHAR2(30) := CHR(13) || CHR(10);
  BEGIN

    if pi_col_list is not null THEN

      v_comma_count := REGEXP_COUNT(pi_col_list, ',');
      DBMS_OUTPUT.PUT_LINE('pi_col_list -> ' || pi_col_list);

      --Get the column list into a nested table collection
      WHILE (v_comma_count > -1) LOOP

        if v_comma_count = 0 then
          v_col_list.EXTEND;
          v_col_list(v_col_list.COUNT) := SUBSTR(pi_col_list, v_position);
          v_comma_count := v_comma_count - 1;
        else
          v_comma_position := INSTR(pi_col_list, ',', v_position);
          v_col_list.EXTEND;
          v_col_list(v_col_list.COUNT) := SUBSTR(pi_col_list,
                                                 v_position,
                                                 v_comma_position - v_position);
          v_position := v_comma_position + 1;
          v_comma_count := v_comma_count - 1;
        end if;

      END LOOP;

      -- GET the column count
      --v_column_count := v_col_list.LAST;

      --Get the transaction id
      SELECT commons_ddl_handling.get_transaction_id
        into v_transaction_id
        FROM dual;

      --Get the UD_INDEX
      select nvl(MAX(UD_INDEX), 0)
        into v_index
        FROM UNDO_DDL
       WHERE UD_TRANSACTION_ID = v_transaction_id;

      --Create primary key constraint and index
      IF (pi_col_is_primarykey = 1) THEN

        --Check if there's a primary key present on the table or not. If no primary key exists, then only create the primary key
        for c in (SELECT 1
                    from dual
                   where not exists
                   (SELECT null
                            FROM USER_CONSTRAINTS uc
                           WHERE uc.TABLE_NAME = pi_tablename
                             and uc.constraint_type = 'P'
                              or (uc.constraint_name = 'PK_' || pi_tablename and
                                 uc.index_name = 'PK_' || pi_tablename))) LOOP

          --v_count incremented to 1 if primary key is not present
          v_count := v_count + 1;

          --Create Primary Key on the table
          v_ddl := 'ALTER TABLE ' || pi_tablename || ' ADD CONSTRAINT PK_' ||
                   pi_tablename || ' PRIMARY KEY (' || PI_COL_LIST ||
                   ') USING INDEX  INITRANS ' || pi_initrans ||
                   ' TABLESPACE ' || pi_index_tablespace;

          --Drop the primary key constraint along with the index
          \* v_undo_ddl := 'ALTER TABLE ' || pi_tablename ||
          ' DROP PRIMARY KEY DROP INDEX';*\

          v_undo_ddl := '
      BEGIN
        FOR C in (SELECT 1
                    from dual
                   where exists (SELECT null
                        FROM USER_CONSTRAINTS uc
                       WHERE uc.TABLE_NAME = ''' ||
                        pi_tablename ||
                        ''' and uc.constraint_type = ''P''
                       and (uc.constraint_name = ''PK_' ||
                        pi_tablename || ''' and  uc.index_name = ''PK_' ||
                        pi_tablename ||
                        ''')) ) LOOP

         EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                        pi_tablename || ' DROP PRIMARY KEY DROP INDEX'';

       END LOOP;
     END;';

          --Create the primary key index, only if v_count is increased to 1 from the above loop code
          commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                           pi_description    => 'Creates primary key constraint and index on table ' ||
                                                                pi_tablename,
                                           pi_ddl            => v_ddl,
                                           pi_undo_ddl       => v_undo_ddl,
                                           pi_index          => v_index + 1);

          po_indexing_info := po_indexing_info || v_new_line ||
                              'Primary Key and index PK_' || pi_tablename ||
                              ' created on ROW_IDENTIFIER column';

        END LOOP;

      END IF;

      --FOR single column indexes
      IF V_COL_LIST.COUNT = 1 and pi_composite = 0 and
         pi_col_is_primarykey = 0 THEN

        --get the datatype of the single column
        SELECT data_type
          into v_data_type
          FROM USER_TAB_COLUMNS
         where table_name = upper(pi_tablename)
           and column_name = upper(v_col_list(1));

        DBMS_OUTPUT.PUT_LINE('pi_nls_sort : ' || pi_nls_sort);
        -- if pi_nls_sort is null i.e. no NLSSORT function is needed for the column
        if pi_nls_sort is null then

          --Add brackets to the column
          v_ddl := '(' || pi_col_list || ')';

          DBMS_OUTPUT.PUT_LINE('The index name is ' || v_indexname);

          --Check if the index is not present with the same name
          -- and if the column is not already indexed with column position 1
          for c in (SELECT 1
                      from dual
                     where not exists (SELECT null
                              from user_indexes
                             where index_name = v_indexname)
                       and not exists
                     (SELECT null
                              from user_ind_columns uic
                             where uic.table_name = pi_tablename
                               and uic.column_name = v_col_list(1)
                               and uic.column_position = 1)) LOOP

            DBMS_OUTPUT.PUT_LINE('In single column loop');
            -- Make the index decision variable as 1 i.e. create the index
            v_decision_to_index := 1;

          --Create DDL based on uniqueness

          END LOOP;

          --if pi_nls_sort is not null i.e. NLSSORT function is needed to be applied on the column
        else

          --check the datatype of column
          if v_data_type = 'VARCHAR2' then
            --Add the NLS SORT funtion on the column, only if the datatype is VARCHAR2
            v_nlssort_column := 'NLSSORT(' || '"' || v_col_list(1) || '"' ||
                                ',''nls_sort=''''' || 'BINARY_CI' ||
                                ''''''')';

            v_decision_to_index := 1;
          else

            --Check if the index is not present with the same name
            -- and if the column is not already indexed with column position 1
            for c in (SELECT 1
                        from dual
                       where not exists (SELECT null
                                from user_indexes
                               where index_name = v_indexname)
                         and not exists
                       (SELECT null
                                from user_ind_columns uic
                               where uic.table_name = pi_tablename
                                 and uic.column_name = v_col_list(1)
                                 and uic.column_position = 1)) LOOP

              DBMS_OUTPUT.PUT_LINE('In single column loop');
              -- Make the index decision variable as 1 i.e. create the index
              v_decision_to_index := 1;

              v_nlssort_column := v_col_list(1);

            END LOOP;

          end if;

          --Check if index is not present with the same name
          -- and if the column is not already indexed with column position 1
          WITH xml AS
           (SELECT DBMS_XMLGEN.GETXMLTYPE('SELECT * FROM USER_IND_EXPRESSIONS WHERE TABLE_NAME = ''' ||
                                          pi_tablename ||
                                          ''' and column_position = 1 ') AS xml
              FROM dual)
          SELECT extractValue(xs.object_value, '/ROW/COLUMN_EXPRESSION') AS COLUMN_EXPRESSION,
                 extractValue(xs.object_value, '/ROW/COLUMN_POSITION') AS COLUMN_POSITION BULK COLLECT
            INTO v_records
            FROM xml x, TABLE(XMLSEQUENCE(EXTRACT(x.xml, '/ROWSET/ROW'))) xs;

          -- records exist in USER_IND_EXPRESSIONS for function based indexes
          if v_records.COUNT > 0 then
            --iterate through such records
            for i in v_records.FIRST .. v_records.LAST LOOP
              -- if there exists an expression , index should not be created on that column with NLSSORT
              if v_records(i).v_ind_expression = v_nlssort_column then
                DBMS_OUTPUT.PUT_LINE('Index will not be created');
                v_decision_to_index := 2;
                --exit from the loop
                EXIT;
              end if;
            END LOOP;
          end if;

          --Add brackets to the column
          v_ddl := '(' || v_nlssort_column || ')';
          DBMS_OUTPUT.PUT_LINE('The keys are' || v_ddl);
        end if;
        DBMS_OUTPUT.PUT_LINE('Index creation decision: ' ||
                             v_decision_to_index);
        --CREATE INDEX if v_decision_to_index is 1
        if v_decision_to_index = 1 then
          --CREATE DDL statements based on uniqueness
          if pi_uniqueness = 1 then
            v_ddl := 'CREATE UNIQUE INDEX ' || v_indexname || ' ON ' ||
                     pi_tablename || v_ddl || ' INITRANS ' || pi_initrans ||
                     ' TABLESPACE ' || pi_index_tablespace;

          elsif pi_uniqueness = 0 then

            v_ddl := 'CREATE INDEX ' || v_indexname || ' ON ' || pi_tablename ||
                     v_ddl || ' INITRANS ' || pi_initrans || ' TABLESPACE ' ||
                     pi_index_tablespace;
          end if;

          --UNDO DDL statement
          --v_undo_ddl := 'DROP INDEX ' || v_indexname;
          v_undo_ddl := 'BEGIN
        FOR C in (SELECT 1 from dual WHERE EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                        v_indexname || '''))) LOOP

        EXECUTE IMMEDIATE ''DROP INDEX ' || v_indexname || ''';

        END LOOP ;
      END;';

          --Execute the Create DDl through COMMONS DDL Handling service
          commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                           pi_description    => 'Created index ' ||
                                                                v_indexname ||
                                                                ' on column ' ||
                                                                PI_COL_LIST ||
                                                                ' of table ' ||
                                                                pi_tablename,
                                           pi_ddl            => v_ddl,
                                           pi_undo_ddl       => v_undo_ddl,
                                           pi_index          => v_index + 1);

          po_indexing_info := po_indexing_info || v_new_line || 'Index ' ||
                              v_indexname || ' created on column ' ||
                              PI_COL_LIST;

        end if;

      END IF;

      --For composite indexes
      IF V_COL_LIST.COUNT > 1 and pi_composite = 1 and
         pi_col_is_primarykey = 0 THEN

        --Check if the index is not present with the same name
        for d in (SELECT 1
                    from dual
                   where not exists (SELECT null
                            from user_indexes
                           where index_name = v_indexname)) LOOP

          --if pi_nls_sort is not null
          --i.e. NLSSORT function is needed to be applied on the VARCHAR2 columns
          if pi_nls_sort is not null THEN

            For i in v_col_list.FIRST .. v_col_list.LAST LOOP

              -- get datatype for a particular column in the list
              SELECT data_type
                into v_data_type
                FROM USER_TAB_COLUMNS
               where table_name = upper(pi_tablename)
                 and column_name = upper(v_col_list(i));

              --Prepare the column list
              --Applying NLSSORT only for VARCHAR2 columns
              if v_data_type = 'VARCHAR2' then
                v_ddl := v_ddl || 'NLSSORT(' || '"' || v_col_list(i) || '"' ||
                         ',''nls_sort=''''' || pi_nls_sort || '''''''),';
              else
                v_ddl := v_ddl || v_col_list(i) || ',';
              end if;

              if i = v_col_list.LAST THEN
                v_ddl := SUBSTR(v_ddl, 1, LENGTH(v_ddl) - 1);
              end if;

            end loop;

            DBMS_OUTPUT.PUT_LINE('The keys are' || v_ddl);

            -- Make the index decision variable as 1 i.e. create the index
            v_decision_to_index := 1;

            --Check if the list created matches the column list already indexed
            for c in (SELECT res.index_name,
                             LISTAGG(res.COLUMN_LIST, ',') WITHIN Group(Order By res.COLUMN_POSITION) As COLUMN_EXPRESSION
                        FROM (SELECT uic.INDEX_NAME,
                                     uic.COLUMN_POSITION,
                                     CASE
                                       WHEN t.column_expression is not null then
                                        t.column_expression
                                       ELSE
                                        uic.COLUMN_NAME
                                     END as COLUMN_LIST
                                from user_ind_columns uic
                                full outer join (SELECT extractValue(xs.object_value,
                                                                    '/ROW/INDEX_NAME') AS INDEX_NAME,
                                                       extractValue(xs.object_value,
                                                                    '/ROW/TABLE_NAME') AS TABLE_NAME,
                                                       extractValue(xs.object_value,
                                                                    '/ROW/COLUMN_EXPRESSION') AS COLUMN_EXPRESSION,
                                                       extractValue(xs.object_value,
                                                                    '/ROW/COLUMN_POSITION') AS COLUMN_POSITION
                                                  FROM (SELECT XMLTYPE.CREATEXML(DBMS_XMLGEN.GETXML('SELECT * FROM USER_IND_EXPRESSIONS WHERE TABLE_NAME = ''' ||
                                                                                                    pi_tablename || '''')) AS xml
                                                          FROM dual) x,
                                                       TABLE(XMLSEQUENCE(EXTRACT(x.xml,
                                                                                 '/ROWSET/ROW'))) xs) t
                                  on t.index_name = uic.INDEX_NAME
                                 and t.table_name = uic.TABLE_NAME
                                 and t.column_position = uic.COLUMN_POSITION
                               where uic.table_name = pi_tablename) res
                       group by res.index_name) loop

              if c.column_expression = v_ddl then
                DBMS_OUTPUT.put_line(c.column_expression);
                --list is already indexed, Hence, don't create the index. make the index decision variable 2
                v_decision_to_index := 2;
                --if column list is already indexed , exit the loop
                EXIT;
              end if;

            end loop;

            --Add brackets to the column
            v_ddl := '(' || v_ddl || ')';

            -- if pi_nls_sort is null i.e. NO NLSSORT function is needed
          else
            -- Make the index decision variable as 1 i.e. create the index
            v_decision_to_index := 1;

            --Check if the column list already indexed
            for c in (SELECT uic.INDEX_NAME,
                             LISTAGG(uic.COLUMN_NAME, ',') WITHIN Group(Order By UIC.COLUMN_POSITION) AS COLUMN_LIST
                        FROM USER_IND_COLUMNS UIC
                       where uic.TABLE_NAME = pi_tablename
                       group by uic.INDEX_NAME) LOOP

              --if list matches, don't create index i.e. make the index decision variable as 2
              if c.column_list = pi_col_list then
                v_decision_to_index := 2;
                EXIT;
                DBMS_OUTPUT.put_line(c.index_name);
              end if;
            END LOOP;

            --Add brackets to the column
            v_ddl := '(' || pi_col_list || ')';

          end if;

          --CREATE INDEX if v_decision_to_index is 1
          if v_decision_to_index = 1 then
            --CREATE DDL statements based on uniqueness
            if pi_uniqueness = 1 then
              v_ddl := 'CREATE UNIQUE INDEX ' || v_indexname || ' ON ' ||
                       pi_tablename || v_ddl || ' INITRANS ' || pi_initrans ||
                       ' TABLESPACE ' || pi_index_tablespace;

            elsif pi_uniqueness = 0 then

              v_ddl := 'CREATE INDEX ' || v_indexname || ' ON ' ||
                       pi_tablename || v_ddl || ' INITRANS ' || pi_initrans ||
                       ' TABLESPACE ' || pi_index_tablespace;
            end if;

            --UNDO DDL statement
            --v_undo_ddl := 'DROP INDEX ' || v_indexname;
            v_undo_ddl := 'BEGIN
        FOR C in (SELECT 1 from dual WHERE EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                          v_indexname ||
                          '''))) LOOP

        EXECUTE IMMEDIATE ''DROP INDEX ' ||
                          v_indexname || ''';

        END LOOP ;
      END;';

            --Execute the Create DDl through COMMONS DDL Handling service
            commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                             pi_description    => 'Create index on columns ' ||
                                                                  PI_COL_LIST ||
                                                                  ' of table ' ||
                                                                  pi_tablename,
                                             pi_ddl            => v_ddl,
                                             pi_undo_ddl       => v_undo_ddl,
                                             pi_index          => v_index + 1);

            po_indexing_info := po_indexing_info || v_new_line || 'Index ' ||
                                v_indexname || ' created on columns ' ||
                                PI_COL_LIST;

          end if;
        end loop;
      end if;
    end if;

  EXCEPTION
    WHEN maximum_key_length_exceeded THEN
      --do nothing
      po_indexing_info := po_indexing_info || v_new_line ||
                          'Index cannot be created because of ORA-01450 - Maximum key length exceeded for columns';
  END CREATE_INDEX;
  */
  /*
  -- 14.May.2013 -- P.2. CREATE_INDEXES
  PROCEDURE CREATE_INDEXES(pi_tables_id in NUMBER, po_log_msg OUT CLOB) IS
    v_sql              CLOB := '';
    v_sql1             CLOB := '';
    V_TABLENAME        VARCHAR2(30);
    v_initrans         VARCHAR2(10);
    v_index_tablespace VARCHAR2(30) := USER || '_IND';
    maximum_key_length_exceeded EXCEPTION;
    PRAGMA EXCEPTION_INIT(maximum_key_length_exceeded, -1450);
    v_new_line VARCHAR2(30) := CHR(13) || CHR(10);
    v_out1     CLOB := '';
    v_out2     CLOB := '';
    v_out3     CLOB := '';
    v_out4     CLOB := '';
    v_out5     CLOB := '';
  BEGIN

    SELECT MIN(PR_VALUE)
      INTO v_INITRANS
      FROM PROPERTIES
     WHERE PR_NAME = 'INITRANS';

    \*  SELECT count(TC_PHYSICAL_NAME)
     INTO v_count
     FROM TABLE_COLUMNS
    WHERE TC_TABLES_ID = pi_tables_id
      and (TC_LOGIC_TYPE = 1 or TC_LOGIC_TYPE = 3);*\

    SELECT MIN(TABLE_NAME)
      into V_TABLENAME
      FROM USER_TABLES ut, TABLES t
     WHERE ut.TABLE_NAME = t.TABLES_PHYSICAL_NAME
       and t.tables_id = pi_tables_id
       \*and t.TABLES_IS_PREDEFINED = 0*\;

    if V_TABLENAME is not null then

      po_log_msg := '       Indexes created on Table: ' || V_TABLENAME;
      po_log_msg := po_log_msg || v_new_line ||
                    '       =====================================  ';
      FOR c in (SELECT TC_PHYSICAL_NAME,
                       TC_LOGIC_TYPE,
                       TC_COLUMN_TYPE,
                       TC_IS_NULLABLE
                  from TABLE_COLUMNS
                 WHERE TC_TABLES_ID = pi_tables_id
                 order by TC_IS_NULLABLE, TC_ORDER) LOOP

        if c.TC_PHYSICAL_NAME = 'ROW_IDENTIFIER' THEN
          --Call the create_index proc to create primary key constraint and index
          BEGIN
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => 'PK_' ||
                                                                v_tablename,
                                        pi_col_list          => 'ROW_IDENTIFIER',
                                        pi_uniqueness        => null,
                                        pi_composite         => null,
                                        pi_col_is_primarykey => 1,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        po_indexing_info     => v_out1);
            po_log_msg := po_log_msg || v_out1;
          END;

        END IF;

        --Entity columns
        if c.TC_COLUMN_TYPE = 1 THEN
          --Call the create_index proc to create index on the entity column
          BEGIN
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       12) || '_' ||
                                                                SUBSTR(c.TC_PHYSICAL_NAME,
                                                                       1,
                                                                       15) ||
                                                                '_SI',
                                        pi_col_list          => c.TC_PHYSICAL_NAME,
                                        pi_uniqueness        => 0,
                                        pi_composite         => 0,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        po_indexing_info     => v_out2);

            po_log_msg := po_log_msg || v_out2;

          END;

        END IF;

        --E_INTERNAL_ID column
        if c.TC_PHYSICAL_NAME = 'E_INTERNAL_ID' and c.TC_COLUMN_TYPE = 3 THEN

          --Create unique index on 'E_INTERNAL_ID' column
          BEGIN
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       12) ||
                                                                '_E_INTERNAL_ID_UI',
                                        pi_col_list          => 'E_INTERNAL_ID',
                                        pi_uniqueness        => 1,
                                        pi_composite         => 0,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        po_indexing_info     => v_out3);

            po_log_msg := po_log_msg || v_out3;

          END;
        END IF;

        if (c.TC_LOGIC_TYPE = 6 or c.TC_LOGIC_TYPE = 7 or c.TC_LOGIC_TYPE = 8) THEN
          --Create normal index on TUPR columns
          BEGIN
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       12) || '_' ||
                                                                SUBSTR(c.TC_PHYSICAL_NAME,
                                                                       1,
                                                                       15) ||
                                                                '_SI',
                                        pi_col_list          => c.TC_PHYSICAL_NAME,
                                        pi_uniqueness        => 0,
                                        pi_composite         => 0,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        po_indexing_info     => v_out4);

            po_log_msg := po_log_msg || v_out4;

          END;
        end if;

        --unique composite key columns append required key columns
        if (c.TC_LOGIC_TYPE = 1 or c.TC_LOGIC_TYPE = 3 or c.TC_LOGIC_TYPE = 6 or
           c.TC_LOGIC_TYPE = 8 or c.TC_LOGIC_TYPE = 9) THEN
          v_sql := v_sql || c.TC_PHYSICAL_NAME || ',';
        end if;

        --auto value key column
        if (c.TC_LOGIC_TYPE = 5) THEN
          v_sql1 := v_sql1 || c.TC_PHYSICAL_NAME || ',';
        end if;
      END LOOP;

      if v_sql1 is not null THEN
        v_sql := SUBSTR(v_sql1, 1, LENGTH(v_sql1) - 1);

        BEGIN
          COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                      pi_indexname         => SUBSTR(v_tablename,
                                                                     1,
                                                                     15) ||
                                                              '_BUSINESSKEY_UI',
                                      pi_col_list          => v_sql,
                                      pi_uniqueness        => 1,
                                      pi_composite         => 0,
                                      pi_col_is_primarykey => 0,
                                      pi_initrans          => v_initrans,
                                      pi_index_tablespace  => v_index_tablespace,
                                      pi_nls_sort          => 'BINARY_CI',
                                      po_indexing_info     => v_out5);

          po_log_msg := po_log_msg || v_out5;

        END;

      elsif v_sql is not null then
        -- remove the last ',' from the list
        v_sql := SUBSTR(v_sql, 1, LENGTH(v_sql) - 1);

        --if more than 1 key column is present, create composite index
        if regexp_count(v_sql, ',') > 0 then

          BEGIN
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       15) ||
                                                                '_BUSINESSKEY_UI',
                                        pi_col_list          => v_sql,
                                        pi_uniqueness        => 1,
                                        pi_composite         => 1,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        pi_nls_sort          => 'BINARY_CI',
                                        po_indexing_info     => v_out5);

            po_log_msg := po_log_msg || v_out5;

          END;

          --if only 1 key column is present, create unique non-composite index
        elsif regexp_count(v_sql, ',') = 0 then

          BEGIN
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       15) ||
                                                                '_BUSINESSKEY_UI',
                                        pi_col_list          => v_sql,
                                        pi_uniqueness        => 1,
                                        pi_composite         => 0,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        pi_nls_sort          => 'BINARY_CI',
                                        po_indexing_info     => v_out5);

            po_log_msg := po_log_msg || v_out5;

          END;

        end if;

      end if;

    end if;
  END CREATE_INDEXES;
  */
  /*
  -- 14.May.2013 -- P.3. DELETE_INDEXES
  --after adding CLOB parameter
  PROCEDURE DELETE_INDEXES(pi_tables_id  in NUMBER,
                           pi_process_id in NUMBER DEFAULT null,
                           pi_run_id     in NUMBER DEFAULT null,
                           po_log_msg    OUT CLOB) IS
    V_TABLENAME  VARCHAR2(30);
    v_process_id NUMBER(10) := pi_process_id;
    v_run_id     NUMBER(10) := pi_run_id;
    v_new_line   VARCHAR2(30) := CHR(13) || CHR(10);

  BEGIN

    SELECT MIN(TABLE_NAME)
      into V_TABLENAME
      FROM USER_TABLES ut, TABLES t
     WHERE ut.TABLE_NAME = t.TABLES_PHYSICAL_NAME
       and t.tables_id = pi_tables_id
       \*and t.TABLES_IS_PREDEFINED = 0*\;

    DBMS_OUTPUT.PUT_LINE('Delete Indexes V_TABLENAME :' || V_TABLENAME);
    -- if table exists
    if V_TABLENAME is not null THEN

      po_log_msg := v_new_line || 'Indexes to be deleted on table ' ||
                    V_TABLENAME;

      FOR c in (SELECT INDEX_NAME
                  FROM USER_INDEXES
                 WHERE TABLE_NAME = v_TABLENAME
                   and index_type != 'LOB') LOOP

        COMMONS_TABLES.RENAME_INDEX(pi_index_name => c.INDEX_NAME,
                                    pi_unique_id  => CT_INDEX_RENAME_SEQ.NEXTVAL,
                                    pi_process_id => v_process_id,
                                    pi_run_id     => v_run_id);

        po_log_msg := po_log_msg || v_new_line || 'Index ' || C.INDEX_NAME ||
                      ' renamed successfully';

      END LOOP;
    END IF;
  END DELETE_INDEXES;
  */

  /*
  -- 14.May.2013 -- P.4. RENAME_INDEX
  PROCEDURE RENAME_INDEX(pi_index_name in VARCHAR2,
                         pi_unique_id  in NUMBER DEFAULT null,
                         pi_process_id in NUMBER DEFAULT null,
                         pi_run_id     in NUMBER DEFAULT null) IS
    v_transaction_id VARCHAR2(30 CHAR);
    v_index          NUMBER(10, 0);
    v_ddl            CLOB;
    v_undo_ddl       CLOB;
    v_old_index      VARCHAR2(30) := pi_index_name;
    v_unique_id      NUMBER(10) := pi_unique_id;
    v_process_id     NUMBER(10) := pi_process_id;
    v_run_id         NUMBER(10) := pi_run_id;
    V_OLD_CONSTRAINT VARCHAR2(30);
    V_NEW_CONSTRAINT VARCHAR2(30);
    v_tablename      VARCHAR2(30);
    v_new_index      VARCHAR2(30);
  BEGIN

    --Get the transaction id
    v_transaction_id := commons_ddl_handling.get_transaction_id;

    select nvl(MAX(UD_INDEX), 0)
      into v_index
      FROM UNDO_DDL
     WHERE UD_TRANSACTION_ID = v_transaction_id;

    if pi_unique_id is not null and pi_process_id is not null and
       pi_run_id is not null then
      v_new_index := 'I_' || v_unique_id || '_' || v_process_id || '_' ||
                     v_run_id;
      DBMS_OUTPUT.PUT_LINE('The index renamed is :' || v_new_index);
    else
      v_new_index := SUBSTR(v_old_index, 1, 26) || '_BKP';
    end if;

    SELECT UI.TABLE_NAME,
           CASE
             WHEN UC.CONSTRAINT_NAME is not null then
              UC.CONSTRAINT_NAME
           END
      into v_tablename, V_OLD_CONSTRAINT
      FROM USER_INDEXES UI
      LEFT JOIN USER_CONSTRAINTS UC
        ON UI.TABLE_NAME = UC.TABLE_NAME
       AND UI.INDEX_NAME = UC.INDEX_NAME
     WHERE UI.INDEX_NAME = v_old_index;

    if V_OLD_CONSTRAINT is not null then

      if pi_unique_id is not null and pi_process_id is not null and
         pi_run_id is not null then
        V_NEW_CONSTRAINT := 'C_' || v_unique_id || '_' || v_process_id || '_' ||
                            v_run_id;
      else
        V_NEW_CONSTRAINT := SUBSTR(V_OLD_CONSTRAINT, 1, 26) || '_BKP';
      end if;

      v_ddl := 'BEGIN
         EXECUTE IMMEDIATE ''ALTER INDEX ' || v_old_index ||
               ' RENAME TO ' || v_new_index ||
               ''' ;
         EXECUTE IMMEDIATE ''ALTER TABLE ' || v_tablename ||
               ' RENAME CONSTRAINT ' || V_OLD_CONSTRAINT || ' TO ' ||
               V_NEW_CONSTRAINT || ''' ;
        END;';

      v_undo_ddl := 'BEGIN
        FOR C in (SELECT 1 from dual WHERE EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                    v_new_index ||
                    '''))) LOOP
        FOR D in (SELECT 1 from dual WHERE NOT EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                    V_OLD_INDEX || '''))) LOOP
        EXECUTE IMMEDIATE ''ALTER INDEX ' || v_new_index ||
                    ' RENAME TO ' || V_OLD_INDEX || ''';
        EXECUTE IMMEDIATE ''ALTER TABLE ' || v_tablename ||
                    ' RENAME CONSTRAINT ' || V_NEW_CONSTRAINT || ' TO ' ||
                    V_OLD_CONSTRAINT || ''' ;

        END LOOP ;
        END LOOP ;
      END;';

    elsif V_OLD_CONSTRAINT is null then
      v_ddl := 'ALTER INDEX ' || v_old_index || ' RENAME TO ' || v_new_index;

      v_undo_ddl := 'BEGIN
          FOR C in (SELECT 1 from dual WHERE EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                    v_new_index ||
                    '''))) LOOP
          FOR D in (SELECT 1 from dual WHERE NOT EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                    V_OLD_INDEX || '''))) LOOP
          EXECUTE IMMEDIATE ''ALTER INDEX ' || v_new_index ||
                    ' RENAME TO ' || V_OLD_INDEX || ''';
          END LOOP ;
          END LOOP ;
        END;';

    end if;
    --DBMS_OUTPUT.PUT_LINE(v_undo_ddl);

    commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                     pi_description    => 'Rename index ' ||
                                                          pi_index_name,
                                     pi_ddl            => v_ddl,
                                     pi_undo_ddl       => v_undo_ddl,
                                     pi_index          => v_index + 1);

  END RENAME_INDEX;
  */
  /*
  -- 14.May.2013 -- P.5. UPDATE_INDEXES
  PROCEDURE UPDATE_INDEXES(pi_tables_id  in NUMBER,
                           pi_process_id in NUMBER DEFAULT null,
                           pi_run_id     in NUMBER DEFAULT null,
                           po_log_msg    OUT CLOB) IS
    TYPE clob_data_type is table of varchar2(32767);
    TYPE number_data_type is table of number;
    v_clob_new_col_list       clob_data_type;
    v_clob_old_col_list       clob_data_type;
    v_new_tc_is_required_list number_data_type;
    v_old_tc_is_required_list number_data_type;
    v_long                    LONG;
    v_cnt                     integer := 0;
    v_count                   integer := 0;
    v_count1                  integer := 0;
    v_decision_to_index       INTEGER := 0;
    v_sql                     CLOB := '';
    v_undo_ddl                CLOB;
    v_ddl                     CLOB;
    V_TABLENAME               VARCHAR2(30);
    v_initrans                VARCHAR2(10);
    v_index_tablespace        VARCHAR2(30) := USER || '_IND';
    v_index                   NUMBER(10, 0);
    v_new_index               VARCHAR2(30);
    v_new_index_unique        NUMBER;
    v_transaction_id          VARCHAR2(30 CHAR);
    v_process_id              NUMBER(10);
    v_process_id1             NUMBER(10) := pi_process_id;
    v_run_id                  NUMBER(10) := pi_run_id;
    maximum_key_length_exceeded EXCEPTION;
    PRAGMA EXCEPTION_INIT(maximum_key_length_exceeded, -1450);
    v_new_line VARCHAR2(30) := CHR(13) || CHR(10);
    v_out1     CLOB;
  BEGIN

    --Get the transaction id
    SELECT commons_ddl_handling.get_transaction_id
      into v_transaction_id
      FROM dual;

    -- Get the initrans value
    SELECT MIN(PR_VALUE)
      INTO v_INITRANS
      FROM PROPERTIES
     WHERE PR_NAME = 'INITRANS';

    SELECT MIN(TABLE_NAME)
      into V_TABLENAME
      FROM USER_TABLES ut, TABLES t
     WHERE ut.TABLE_NAME = t.TABLES_PHYSICAL_NAME
       and t.tables_id = pi_tables_id
       \*and t.TABLES_IS_PREDEFINED = 0*\;

    if V_TABLENAME is not null then
      po_log_msg := po_log_msg || '    Indexes to be updated on table ' ||
                    V_TABLENAME;
      --For Entity and TUPR columns
      FOR c in (SELECT TC_PHYSICAL_NAME, TC_COLUMN_TYPE, TC_LOGIC_TYPE
                  FROM TABLE_COLUMNS TC
                  LEFT OUTER JOIN USER_IND_COLUMNS UIC
                    on uic.table_name = V_TABLENAME
                   and uic.index_name like
                       SUBSTR(v_tablename, 1, 11) || '_' ||
                       SUBSTR(TC.TC_PHYSICAL_NAME, 1, 15) || '_%'
                 where (TC.TC_COLUMN_TYPE = 1 or TC.TC_LOGIC_TYPE = 6 or
                       TC.TC_LOGIC_TYPE = 7 or TC.TC_LOGIC_TYPE = 8)
                   and tc.tc_tables_id = pi_tables_id
                   and uic.index_name is null) LOOP

        --Call the create_index proc to create index on the entity column

        BEGIN
          COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                      pi_indexname         => SUBSTR(v_tablename,
                                                                     1,
                                                                     12) || '_' ||
                                                              SUBSTR(c.TC_PHYSICAL_NAME,
                                                                     1,
                                                                     15) ||
                                                              '_SI',
                                      pi_col_list          => c.TC_PHYSICAL_NAME,
                                      pi_uniqueness        => 0,
                                      pi_composite         => 0,
                                      pi_col_is_primarykey => 0,
                                      pi_initrans          => v_initrans,
                                      pi_index_tablespace  => v_index_tablespace,
                                      po_indexing_info     => v_out1);

          if c.tc_column_type = 1 and v_out1 is not null THEN
            po_log_msg := po_log_msg || v_new_line || v_out1 ||
                          ' Index created on added Entity column.';
          elsif c.tc_column_type != 1 and v_out1 is not null THEN
            po_log_msg := po_log_msg || v_new_line || v_out1 ||
                          ' Index created on  effective period column.';
          end if;

        END;

      END LOOP;

      -- FOr KEY COLUMNS
      SELECT CASE
               WHEN TC_LOGIC_TYPE = 5 THEN
                TC_PHYSICAL_NAME
               WHEN TC_LOGIC_TYPE IN (1, 3, 6, 8, 9) AND NOT EXISTS
                (SELECT 1
                       FROM TABLE_COLUMNS TC1
                      WHERE TC1.TC_TABLES_ID = TC.TC_TABLES_ID
                        AND TC1.TC_LOGIC_TYPE = 5) THEN
                (CASE
                  WHEN (F.FLD_DATA_TYPE = 1 or F.FLD_DATA_TYPE = 4) THEN
                   'NLSSORT("' || TC_PHYSICAL_NAME ||
                   '",''nls_sort=''''BINARY_CI'''''')'
                  ELSE
                   TC_PHYSICAL_NAME
                END)
             END BUSINESSKEY_LIST,
             TC_IS_NULLABLE BULK COLLECT
        INTO v_clob_new_col_list, v_new_tc_is_required_list
        FROM TABLES T
       inner join TABLE_COLUMNS TC
          on T.TABLES_ID = TC.TC_TABLES_ID
         and T.TABLES_ID = pi_tables_id
        LEFT JOIN FIELDS F
          ON TC.TC_FLD_ID = F.FLD_ID
         and TC.TC_PHYSICAL_NAME = F.FLD_COLUMN_NAME
       WHERE CASE
               WHEN TC_LOGIC_TYPE = 5 THEN
                TC_PHYSICAL_NAME
               WHEN TC_LOGIC_TYPE IN (1, 3, 6, 8, 9) AND NOT EXISTS
                (SELECT 1
                       FROM TABLE_COLUMNS TC1
                      WHERE TC1.TC_TABLES_ID = TC.TC_TABLES_ID
                        AND TC1.TC_LOGIC_TYPE = 5) THEN
                (CASE
                  WHEN (F.FLD_DATA_TYPE = 1 or F.FLD_DATA_TYPE = 4) THEN
                   'NLSSORT("' || TC_PHYSICAL_NAME ||
                   '",''nls_sort=''''BINARY_CI'''''')'
                  ELSE
                   TC_PHYSICAL_NAME
                END)
             END is not null
       order by TC.TC_IS_NULLABLE ASC, TC.TC_ORDER ASC;

      --For displaying list of New Key Columns
      \*    DBMS_OUTPUT.PUT_LINE('The key column list is :');
      for i in v_clob_new_col_list.FIRST .. v_clob_new_col_list.LAST LOOP
        DBMS_OUTPUT.PUT_LINE(v_clob_new_col_list(i));
      END LOOP;*\

      --    v_decision_to_index := 1;
      --collection for fetching old list of key columns already indexed
      v_clob_old_col_list       := clob_data_type();
      v_old_tc_is_required_list := number_data_type();
      for C in (SELECT UIE.INDEX_NAME        ind1,
                       UIE.COLUMN_EXPRESSION,
                       UIC.INDEX_NAME        ind2,
                       UIC.COLUMN_NAME
                  FROM USER_IND_EXPRESSIONS UIE
                  FULL OUTER JOIN USER_IND_COLUMNS UIC
                    ON UIE.index_name = uic.INDEX_NAME
                   and uie.table_name = uic.TABLE_NAME
                   and uie.column_position = uic.COLUMN_POSITION
                 WHERE UIC.index_name =
                       SUBSTR(v_tablename, 1, 15) || '_BUSINESSKEY_UI'
                 order by uic.COLUMN_POSITION) LOOP

        if C.ind1 is null then
          v_clob_old_col_list.extend;
          v_old_tc_is_required_list.extend;
          v_cnt := v_cnt + 1;
          v_clob_old_col_list(v_cnt) := c.column_name;

          \*        dbms_output.put_line('v_clob_old_col_list(v_cnt): ' ||
          v_clob_old_col_list(v_cnt));*\
          BEGIN
            SELECT TC_IS_NULLABLE
              into v_old_tc_is_required_list(v_cnt)
              FROM TABLE_COLUMNS
             WHERE TC_TABLES_ID = pi_tables_id
               and TC_PHYSICAL_NAME = v_clob_old_col_list(v_cnt);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_old_tc_is_required_list.DELETE(v_old_tc_is_required_list.LAST);
          END;
        else
          v_clob_old_col_list.extend;
          v_old_tc_is_required_list.extend;
          v_cnt := v_cnt + 1;
          v_long := c.column_expression;
          v_clob_old_col_list(v_cnt) := c.column_expression;
          BEGIN
            SELECT TC_IS_NULLABLE
              into v_old_tc_is_required_list(v_cnt)
              FROM TABLE_COLUMNS
             WHERE TC_TABLES_ID = pi_tables_id
               and TC_PHYSICAL_NAME = (SELECT SUBSTR(REGEXP_SUBSTR(v_clob_old_col_list(v_cnt),
                                                                   '"[^"]+'),
                                                     2)
                                         FROM DUAL);

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_old_tc_is_required_list.DELETE(v_old_tc_is_required_list.LAST);
          END;

          --SELECT v_long into v_clob_old_col_list(v_cnt) FROM DUAL;
        end if;

      END LOOP;

      \*    if v_clob_old_col_list.COUNT > 0 THEN
        --For displaying list of Old Key Columns
        for i in v_clob_old_col_list.FIRST .. v_clob_old_col_list.LAST LOOP
          DBMS_OUTPUT.PUT_LINE(v_clob_old_col_list(i));
        END LOOP;
      end if;*\

      --if new list of columns is same as old list of key columns, then create an index only if TC_IS_REQUIRED is changed for the key columns
      if v_clob_new_col_list is not null and v_clob_new_col_list.COUNT > 0 and
         v_clob_new_col_list = v_clob_old_col_list then

        --check if required property (actual matching of TC_IS_NULLABLE technical column) matches for the indexes
        for i in v_clob_new_col_list.FIRST .. v_clob_new_col_list.LAST LOOP

          --Check if the columns match exactly
          if v_old_tc_is_required_list(i) = v_new_tc_is_required_list(i) THEN
            v_count := v_count + 1;
          END IF;
        END LOOP;
        --If the columns match exactly, no need of creating index.
        -- Set the decision_to_index variable to 1
        IF (v_count = v_clob_new_col_list.LAST) THEN
          v_decision_to_index := v_decision_to_index + 1;
          --if the required property does not match, create the index with new set of key values,
          --and register the old index in TEMP_RESOURCES table
        ELSE

          -- Set the decision_to_index variable to 2, meaning that index should be created
          v_decision_to_index := 2;

          --Check if these columns match to the list of columns provided
          -- if they match, no need of creating the index
          For i in v_clob_new_col_list.FIRST .. v_clob_new_col_list.LAST LOOP
            --Check if the columns match exactly
            if v_clob_new_col_list(i) = v_clob_old_col_list(i) THEN
              v_count1 := v_count1 + 1;
            END IF;

            -- Set the decision_to_index variable to 3, meaning that index should not be created
            IF (v_count1 = v_clob_new_col_list.LAST) THEN
              v_decision_to_index := v_decision_to_index + 1;
              po_log_msg          := po_log_msg || v_new_line ||
                                     'Index already present. No Update required  ';
              EXIT;
            END IF;

          END LOOP;

        END IF;

      end if;

      -- if new list of columns is not same as old list of key columns,
      --create an index on new key columns and drop the old index
      if v_clob_new_col_list is not null and v_clob_new_col_list.COUNT > 0 and
         v_clob_new_col_list != v_clob_old_col_list then
        \* DBMS_OUTPUT.PUT_LINE('New Key columns don''t match with old key columns');*\
        -- Set the decision_to_index variable to 2, meaning that index should be created
        v_decision_to_index := 2;

      end if;

      --if only one column is present in the new key column list and that column is already indexed with another name,
      --do not create the new key column index
      if v_clob_new_col_list.COUNT = 1 then
        for c in (SELECT 1
                    from dual
                   where exists (SELECT null
                            FROM user_ind_columns
                           WHERE table_name = v_tablename
                             and column_name = v_clob_new_col_list(1)
                             and index_name != SUBSTR(v_tablename, 1, 15) ||
                                 '_BUSINESSKEY_UI'
                             and column_position = 1)) LOOP
          \*        DBMS_OUTPUT.put_line('v_clob_new_col_list(1) : ' ||
          v_clob_new_col_list(1));*\
          v_decision_to_index := 4;
        END LOOP;

      end if;

      --If index is to be created,
      if v_decision_to_index = 2 or v_decision_to_index = 4 then

        --Drop the old index
        if v_clob_old_col_list.COUNT > 0 THEN

          SELECT CT_INDEX_RENAME_SEQ.NEXTVAL
            into v_new_index_unique
            from dual;

          if pi_process_id is not null and pi_run_id is not null then
            v_new_index := 'I_' || v_new_index_unique || '_' || v_process_id1 || '_' ||
                           v_run_id;
            \*          DBMS_OUTPUT.put_line('Index registered in Temp Resources table: ' ||
            v_new_index);*\
          else
            v_new_index := SUBSTR(v_tablename || '_BUSINESSKEY_UI', 1, 26) ||
                           '_BKP';
            \*          DBMS_OUTPUT.put_line('Index registered in Temp Resources table: ' ||
            v_new_index);*\
          end if;

          --storing process_id as 1 if not owned by a process and 0 if owned
          SELECT DECODE(pi_process_id, null, 1, 0)
            into v_process_id
            from dual;

          --Register the Key column index in TEMP_RESOURCES table
          EXECUTE IMMEDIATE ' INSERT INTO TEMP_RESOURCES (tr_id,tr_name, tr_type,tr_path,tr_lifecycle,tr_run_id,tr_transaction_id, tr_column_table_name)
                        VALUES (UID_SEQUENCE.nextval,:1,6,null,:2,:3,:4,null)'
            using v_new_index, v_process_id, v_run_id, v_transaction_id;

          COMMONS_TABLES.RENAME_INDEX(v_tablename || '_BUSINESSKEY_UI',
                                      v_new_index_unique,
                                      v_process_id1,
                                      v_run_id);

        END IF;

        if v_decision_to_index = 2 then
          --initialize to null for new key columns
          v_sql := '';

          --get the list of new key columns in comma separated list
          for i in v_clob_new_col_list.FIRST .. v_clob_new_col_list.LAST LOOP

            if i = v_clob_new_col_list.LAST THEN
              v_sql := v_sql || v_clob_new_col_list(i);
            ELSE
              v_sql := v_sql || v_clob_new_col_list(i) || ',';
            END IF;
          END LOOP;

          --display the list of new key columns in comma separated list
          \*        DBMS_OUTPUT.PUT_LINE(v_sql);*\

          v_ddl := 'CREATE UNIQUE INDEX ' || SUBSTR(v_tablename, 1, 15) ||
                   '_BUSINESSKEY_UI ON ' || v_tablename || '(' || v_sql ||
                   ') INITRANS ' || v_initrans || ' TABLESPACE ' ||
                   v_index_tablespace;

          \*      v_undo_ddl := ' DROP INDEX ' || SUBSTR(v_tablename, 1, 15) ||
          '_BUSINESSKEY_UI';*\

          v_undo_ddl := 'BEGIN
        FOR C in (SELECT 1 from dual WHERE EXISTS (SELECT null FROM user_indexes WHERE index_name =UPPER(''' ||
                        TO_CHAR(SUBSTR(v_tablename, 1, 15) ||
                                '_BUSINESSKEY_UI') ||
                        '''))) LOOP

        EXECUTE IMMEDIATE ''DROP INDEX ' ||
                        TO_CHAR(SUBSTR(v_tablename, 1, 15) ||
                                '_BUSINESSKEY_UI') || ''';

        END LOOP ;
      END;';

          --display the ddl of new index
          \*        DBMS_OUTPUT.PUT_LINE('Create ddl from Update indexes: ' || v_ddl);*\

          select nvl(MAX(UD_INDEX), 0)
            into v_index
            FROM UNDO_DDL
           WHERE UD_TRANSACTION_ID = v_transaction_id;

          commons_ddl_handling.execute_ddl(pi_transaction_id => v_transaction_id,
                                           pi_description    => 'Update index on Key columns',
                                           pi_ddl            => v_ddl,
                                           pi_undo_ddl       => v_undo_ddl,
                                           pi_index          => v_index + 1);

          po_log_msg := po_log_msg || v_new_line ||
                        'Index updated and created with name ' ||
                        SUBSTR(v_tablename, 1, 15) || '_BUSINESSKEY_UI' ||
                        ' successfully on columns ' || v_sql || v_new_line;

        end if;
      end if;

    end if;
  EXCEPTION
    WHEN maximum_key_length_exceeded THEN
      po_log_msg := po_log_msg || v_new_line ||
                    'Index cannot be created because of ORA-01450 Maximum key length exceeded for key columns:-  ' ||
                    v_sql;
  END UPDATE_INDEXES;
  */

  FUNCTION RUN_QUERY(pin_sql            IN CLOB,
                     pin_using_bind_var IN coltype_NAME_VALUE)
    RETURN SYS_REFCURSOR AS
    v_cursor  BINARY_INTEGER := DBMS_SQL.OPEN_CURSOR;
    v_execute BINARY_INTEGER;
  BEGIN
    DBMS_SQL.PARSE(v_cursor, pin_sql, DBMS_SQL.NATIVE);

    FOR C IN (SELECT NAME, VALUE FROM TABLE(pin_using_bind_var)) LOOP
      DBMS_SQL.BIND_VARIABLE(v_cursor, c.NAME, c.VALUE);
    END LOOP;

    v_execute := DBMS_SQL.EXECUTE(v_cursor);

    RETURN DBMS_SQL.TO_REFCURSOR(v_cursor);
  END RUN_QUERY;

  -- Description: used in LOAD_DBA_QUERY SP to compute the sql_id from the full_query
  -----**************************************************************************************------------------------
  FUNCTION compute_sql_id(sql_text IN CLOB) RETURN VARCHAR2 IS
    BASE_32 CONSTANT VARCHAR2(32) := '0123456789abcdfghjkmnpqrstuvwxyz';
    v_raw_128  RAW(128);
    v_hex_32   VARCHAR2(32);
    v_low_16   VARCHAR(16);
    v_q3       VARCHAR2(8);
    v_q4       VARCHAR2(8);
    v_low_16_m VARCHAR(16);
    v_number   NUMBER;
    v_idx      INTEGER;
    v_sql_id   VARCHAR2(13);
  BEGIN
    v_raw_128 :=  /* use md5 algorithm on sqv_text and produce 128 bit hash */
     DBMS_CRYPTO.hash(TRIM(CHR(0) FROM sql_text) || CHR(0),
                                  DBMS_CRYPTO.hash_md5);
    v_hex_32  := RAWTOHEX(v_raw_128); /* 32 hex characters */
    v_low_16  := SUBSTR(v_hex_32, 17, 16); /* we only need lower 16 */
    v_q3      := SUBSTR(v_low_16, 1, 8); /* 3rd quarter (8 hex characters) */
    v_q4      := SUBSTR(v_low_16, 9, 8); /* 4th quarter (8 hex characters) */
    /* need to reverse order of each of the 4 pairs of hex characters */
    v_q3 := SUBSTR(v_q3, 7, 2) || SUBSTR(v_q3, 5, 2) || SUBSTR(v_q3, 3, 2) ||
            SUBSTR(v_q3, 1, 2);
    v_q4 := SUBSTR(v_q4, 7, 2) || SUBSTR(v_q4, 5, 2) || SUBSTR(v_q4, 3, 2) ||
            SUBSTR(v_q4, 1, 2);
    /* assembly back lower 16 after reversing order on each quarter */
    v_low_16_m := v_q3 || v_q4;
    /* convert to number */
    v_number := TO_NUMBER(v_low_16_m, 'xxxxxxxxxxxxxxxx');
    /* 13 pieces base-32 (5 bits each) make 65 bits. we do have 64 bits */
    FOR i IN 1 .. 13 LOOP
      v_idx    := TRUNC(v_number / POWER(32, (13 - i))); /* index on BASE_32 */
      v_sql_id := v_sql_id || SUBSTR(BASE_32, (v_idx + 1), 1); /* stitch 13 characters */
      v_number := v_number - (v_idx * POWER(32, (13 - i))); /* for next piece */
    END LOOP;
    RETURN v_sql_id;
  END compute_sql_id;

  -----**************************************************************************************------------------------

  PROCEDURE CLEANUP_DBA_QUERIES AS
    V_LIMIT NUMBER(10);
  BEGIN
    -- delete queries from deleted views
    DELETE FROM TABLE_DBA_QUERIES DEL
     WHERE DEL.TDQ_OBJECT_ID NOT IN (SELECT PVV_ID FROM PV_VIEWS);

    -- get the value from properties
    SELECT PR_VALUE
      INTO V_LIMIT
      FROM PROPERTIES
     WHERE PR_NAME = 'DAYS_DBA_QUERIES';

    -- delete unusued queries
    EXECUTE IMMEDIATE '
               DELETE FROM TABLE_DBA_QUERIES DEL
                WHERE DEL.TDQ_PIN = 0 AND DEL.TDQ_LAST_DATE < SYSDATE - ' ||
                      V_LIMIT;

    -- get the value from properties
    SELECT PR_VALUE
      INTO V_LIMIT
      FROM PROPERTIES
     WHERE PR_NAME = 'RECORD_NR_DBA_QUERIES';

    -- delete entries for the objects which have are over the threshold of number of queries saved
    EXECUTE IMMEDIATE '
         DELETE FROM TABLE_DBA_QUERIES DEL
         WHERE (DEL.TDQ_OBJECT_ID, DEL.TDQ_SQL_ID) IN
               (SELECT TDQ.TDQ_OBJECT_ID, TDQ.TDQ_SQL_ID
                  FROM (SELECT TDQ.TDQ_OBJECT_ID,
                               TDQ.TDQ_SQL_ID,
                               TDQ.TDQ_PIN,
                               ROW_NUMBER() OVER (PARTITION BY TDQ.TDQ_OBJECT_ID ORDER BY TDQ.TDQ_NUMBER_OF_ACCESSES DESC, TDQ.TDQ_LAST_DATE DESC) RN
                          FROM TABLE_DBA_QUERIES TDQ
                         WHERE TDQ.TDQ_PIN = 0) TDQ
                 WHERE TDQ.RN > ' || V_LIMIT || ')';

    -- delete hints from deleted views
    DELETE FROM TABLE_DBA_HINTS DEL
     WHERE DEL.TDH_OBJECT_ID NOT IN (SELECT PVV_ID FROM PV_VIEWS);

    -- delete plans
    DELETE FROM SQL_EXEC_PLAN_TABLE
     WHERE (SQL_ID, CHILD_NUMBER) IN
           (SELECT P.TQP_SQL_ID, P.TQP_CHILD_NUMBER
              FROM TABLE_QUERY_PLANS P
             WHERE (P.TQP_OBJECT_ID, P.TQP_SQL_ID) NOT IN
                   (SELECT TDQ_OBJECT_ID, TDQ_SQL_ID
                      FROM TABLE_DBA_QUERIES
                    UNION ALL
                    SELECT TDQ_OBJECT_ID, TDQ_DBA_SQL_ID
                      FROM TABLE_DBA_QUERIES
                     WHERE TDQ_DBA_SQL_ID IS NOT NULL));

    -- delete dba plans from deleted queries
    DELETE FROM TABLE_QUERY_PLANS P
     WHERE (P.TQP_OBJECT_ID, P.TQP_SQL_ID) NOT IN
           (SELECT TDQ_OBJECT_ID, TDQ_SQL_ID
              FROM TABLE_DBA_QUERIES
            UNION ALL
            SELECT TDQ_OBJECT_ID, TDQ_DBA_SQL_ID
              FROM TABLE_DBA_QUERIES
             WHERE TDQ_DBA_SQL_ID IS NOT NULL);
    COMMIT;
  END;

  -- Author     : Kristo, Robert
  -- Description: used in LOAD_DBA_QUERY SP to load dba hints if exist
  -----**************************************************************************************------------------------
  PROCEDURE LOAD_DBA_HINTS(pin_object_id IN NUMBER,
                           pin_dba_hints IN TABLETYPE_ID_HINT,

                           pio_full_query IN OUT NOCOPY CLOB,

                           pout_dba_hints OUT NUMBER) AS
    v_hint_identifier VARCHAR2(1300 CHAR);
    v_full_dba_hint   VARCHAR2(2000);
  BEGIN

    FOR i IN (SELECT TDH_HINT_IDENTIFIER,
                     TDH_DBA_HINT,
                     TDH_ORDER,
                     1 TDH_HINT_TYPE
                FROM TABLE_DBA_HINTS
               WHERE TDH_OBJECT_ID = pin_object_id
                 AND TDH_USE_DBA_HINT = 1
              UNION ALL
              SELECT IDENTIFIER TDH_HINT_IDENTIFIER,
                     HINT       TDH_DBA_HINT,
                     HINT_ORDER TDH_ORDER,
                     0          TDH_HINT_TYPE
                FROM TABLE(pin_dba_hints)
               ORDER BY TDH_HINT_IDENTIFIER, TDH_ORDER)

     LOOP
      IF v_hint_identifier IS NULL THEN
        -- first hint
        v_hint_identifier := i.tdh_hint_identifier;
        v_full_dba_hint   := i.tdh_dba_hint;
        -- check if it's a db hint
        IF i.tdh_hint_type = 1 THEN
          pout_dba_hints := 1;
        END IF;
      ELSIF v_hint_identifier = i.tdh_hint_identifier THEN
        -- concatenate the hints
        v_full_dba_hint := v_full_dba_hint || ' ' || i.tdh_dba_hint;
        IF i.tdh_hint_type = 1 THEN
          pout_dba_hints := 1;
        END IF;
      ELSE
        -- add the hints in the main query
        pio_full_query    := regexp_replace(pio_full_query,
                                            '/\* <DBAQH>' ||
                                            v_hint_identifier ||
                                            '</DBAQH> \*/ ',
                                            '/*+ ' || v_full_dba_hint ||
                                            ' <DBAQH>' || v_hint_identifier ||
                                            '</DBAQH> */');
        v_hint_identifier := i.tdh_hint_identifier;
        v_full_dba_hint   := i.tdh_dba_hint;
        IF i.tdh_hint_type = 1 THEN
          pout_dba_hints := 1;
        END IF;
      END IF;
    END LOOP;

    -- add the last hints
    IF v_hint_identifier IS NOT NULL THEN
      pio_full_query := regexp_replace(pio_full_query,
                                       '/\* <DBAQH>' || v_hint_identifier ||
                                       '</DBAQH> \*/ ',
                                       '/*+ ' || v_full_dba_hint ||
                                       ' <DBAQH>' || v_hint_identifier ||
                                       '</DBAQH> */');
    END IF;

  END LOAD_DBA_HINTS;

  -- Author     : Kristo, Robert
  -- Description: used in GET_DATA_FROM_QUERY SP to load dba query if exists
  -----**************************************************************************************------------------------
  PROCEDURE LOAD_DBA_QUERY(pin_object_id IN NUMBER,
                           pin_dba_hints IN TABLETYPE_ID_HINT,

                           pio_full_query IN OUT NOCOPY CLOB,

                           pout_sql_id OUT VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_use_dba_query NUMBER(1);
    v_dba_query     CLOB;
    v_dba_hints     NUMBER(1);
    v_sql_id        VARCHAR2(13) := compute_sql_id(regexp_replace(pio_full_query,
                                                                  '/\* <DBAQH>[^,;*.]+</DBAQH> \*/ '));
  BEGIN
    -- check if there is a row already saved in the DBA_QUERIES table
    SELECT TDQ_USE_DBA_QUERY, TDQ_DBA_QUERY
      INTO v_use_dba_query, v_dba_query
      FROM TABLE_DBA_QUERIES
     WHERE TDQ_OBJECT_ID = pin_object_id
       AND TDQ_SQL_ID = v_sql_id;

    -- check if there is a dba query created
    IF (v_use_dba_query = 1 AND v_dba_query IS NOT NULL) THEN
      pio_full_query := v_dba_query;
      -- use dba hints
    ELSE
      LOAD_DBA_HINTS(pin_object_id => pin_object_id,
                     pin_dba_hints => pin_dba_hints,

                     pio_full_query => pio_full_query,

                     pout_dba_hints => v_dba_hints);
    END IF;

    -- increase count number of the times the query has been used
    UPDATE TABLE_DBA_QUERIES
       SET TDQ_NUMBER_OF_ACCESSES = CASE
                                      WHEN v_use_dba_query = 1 AND
                                           v_dba_query IS NOT NULL THEN
                                       TDQ_NUMBER_OF_ACCESSES
                                      ELSE
                                       TDQ_NUMBER_OF_ACCESSES + 1
                                    END,
           TDQ_DBA_NUMBER_OF_ACCESSES = CASE
                                          WHEN v_use_dba_query = 1 AND
                                               v_dba_query IS NOT NULL THEN
                                           NVL(TDQ_DBA_NUMBER_OF_ACCESSES, 0) + 1
                                          ELSE
                                           TDQ_DBA_NUMBER_OF_ACCESSES
                                        END,
           TDQ_LAST_DATE              = SYSDATE,
           TDQ_HINTED_QUERY = CASE
                                WHEN (v_dba_hints = 1) THEN
                                 pio_full_query
                                ELSE
                                 NULL
                              END
     WHERE tdq_object_id = pin_object_id
       AND tdq_sql_id = v_sql_id;

    -- return the sql_id
    pout_sql_id := v_sql_id;

    COMMIT;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        -- check for dba hints
        LOAD_DBA_HINTS(pin_object_id => pin_object_id,
                       pin_dba_hints => pin_dba_hints,

                       pio_full_query => pio_full_query,

                       pout_dba_hints => v_dba_hints);
        -- insert new value
        INSERT INTO TABLE_DBA_QUERIES
          (TDQ_OBJECT_ID,
           TDQ_LAST_DATE,
           TDQ_FULL_QUERY,
           TDQ_SQL_ID,
           TDQ_USE_DBA_QUERY,
           TDQ_PIN,
           TDQ_NUMBER_OF_ACCESSES,
           TDQ_HINTED_QUERY)
        VALUES
          (pin_object_id,
           SYSDATE,
           pio_full_query,
           v_sql_id,
           0,
           0,
           1,
           CASE WHEN(v_dba_hints = 1) THEN pio_full_query ELSE NULL END);

        -- return sql id
        pout_sql_id := v_sql_id;
        COMMIT;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          -- increase count number of the times the query has been used
          UPDATE TABLE_DBA_QUERIES
             SET TDQ_NUMBER_OF_ACCESSES = TDQ_NUMBER_OF_ACCESSES + 1,
                 TDQ_LAST_DATE          = SYSDATE
           WHERE tdq_object_id = pin_object_id
             AND tdq_sql_id = v_sql_id;

          -- return the sql_id
          pout_sql_id := v_sql_id;

          COMMIT;
      END;
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'there is more than one record in table TABLE_DBA_QUERIES with the same object and sql ID');
  END LOAD_DBA_QUERY;

  PROCEDURE GET_DATA_FROM_QUERY(pin_query                CLOB,
                                pin_where_clause_vals    coltype_NAME_VALUE,
                                pin_orderby_clause       VARCHAR2,
                                pin_object_id            NUMBER,
                                pin_select_rowstartindex NUMBER --0 IF LAST PAGE
                               ,
                                pin_page_size            NUMBER,
                                pin_lastpage_flag        NUMBER,

                                pout_result            IN OUT SYS_REFCURSOR,
                                pout_sql_id            IN OUT VARCHAR2,
                                pout_exec_plan_enabled IN OUT VARCHAR2) AS
  BEGIN
    GET_DATA_FROM_QUERY(pin_query                => pin_query,
                        pin_where_clause_vals    => pin_where_clause_vals,
                        pin_orderby_clause       => pin_orderby_clause,
                        pin_object_id            => pin_object_id,
                        pin_select_rowstartindex => pin_select_rowstartindex,
                        pin_page_size            => pin_page_size,
                        pin_lastpage_flag        => pin_lastpage_flag,
                        pin_dba_hints            => NULL,
                        pout_result              => pout_result,
                        pout_sql_id              => pout_sql_id,
                        pout_exec_plan_enabled   => pout_exec_plan_enabled);
  END;

  PROCEDURE GET_DATA_FROM_QUERY(pin_query                CLOB,
                                pin_where_clause_vals    coltype_NAME_VALUE,
                                pin_orderby_clause       VARCHAR2,
                                pin_object_id            NUMBER,
                                pin_select_rowstartindex NUMBER --0 IF LAST PAGE
                               ,
                                pin_page_size            NUMBER,
                                pin_lastpage_flag        NUMBER,
                                pin_dba_hints            TABLETYPE_ID_HINT,

                                pout_result            OUT SYS_REFCURSOR,
                                pout_sql_id            OUT VARCHAR2,
                                pout_exec_plan_enabled OUT VARCHAR2)
  -- Assumptions:
    -- Input Parameters are built using valid column names
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_select_clause         List of column names from tables; NOT NULL
    --    pin_from_clause           Table name from where to select records joined with other tables needed for filters; NOT NULL
    --    pin_where_clause          Filter clause; it should NOT have "WHERE" clause in it; NULL if there is no filter condition
    --    pin_where_clause_vals     dynamic values for where clause (user name/id, current date) - object of bind name - value; NULL for no bindings
    --    pin_orderby_clause        Order by clause; IF NULL THEN ORDER BY ROW_ID; if not null it should NOT have "ORDER" clause in it; object of field (physical name) - alias
    --    pin_table_alias           alias of the table; NOT NULL

    --    pin_object_id             ID of the view to be displayed in order to activate catching feature
    --    pin_object_type           type of the view to be displayed; 1 = data view; 2 = report view; 3 = custom view

    --    pin_select_rowstartindex  start position used to return rows (0 if last page, 1 if first page, >=1 for any other page); if NULL then no paging - used for totals and count
    --    pin_page_size             100/250/500...; NOT NULL if pin_lastpage_flag = 0
    --    pin_lastpage_flag         1 - last page; 0 - any other page

    -----------------------------------------------------------------------------------------
    -- Output : CURSOR having columns specified in COLUMN_NAMES parameter
    -----------------------------------------------------------------------------------------
    -- Return :
    ----------------------------------------------------------------------------------------
    /*
    -- Example : 1 - "first page" .
        variable r1 refcursor
        declare c sys_refcursor;
        begin
          commons_portal_views.GET_PV_DATA(pin_select_clause => ' TAB.F1 ', pin_from_clause => ' T10 TAB ', pin_where_clause => NULL, pin_where_clause_vals => NULL, pin_orderby_clause => NULL, pin_object_id => NULL, pin_object_type => NULL, pin_select_rowstartindex => 1, pin_page_size => 3, pin_lastpage_flag => 0, c => c);
          :r1 := c;
        end;
        print r1;

    -- Example : where_clause_vals and orderby_clause
        variable rc refcursor;
        declare
        c sys_refcursor;
        begin
          commons_portal_views.GET_PV_DATA(
          pin_select_clause => ' T10.F1 AS a, F2, F3, F4, F5 '
          , pin_from_clause => ' T10  '
          , pin_where_clause => ' T10.F3 = to_date(:v1, ''mm/dd/yyyy HH:MI:SS'') '
          , pin_where_clause_vals => coltype_NAME_VALUE(rtype_NAME_VALUE(':v1', '2/28/2012 11:54:40'))
          , pin_orderby_clause => COLTYPE_FIELD_ALIAS(rtype_FIELD_ALIAS('T10.F1','a'))
          , pin_object_id => NULL
          , pin_object_type => NULL
          , pin_select_rowstartindex => 1
          , pin_page_size => 3
          , pin_lastpage_flag => 0
          , pout_result => c);
        :rc := c;
        end;
        print rc;
    */

   AS
    v_select_rowendindex      NUMBER;
    v_strsql                  CLOB;
    v_orderby_clause_new      VARCHAR2(32767);
    v_orderby_clause_reversed VARCHAR2(32767);

    v_table_alias VARCHAR2(30) := 'TAB';

    v_pagination_filter1 VARCHAR2(200);
    v_pagination_filter2 VARCHAR2(200);

    v_lp_row_identifiers CLOB;
    v_lp_listagg         CLOB;
    v_row_count          PLS_INTEGER;
    v_stamp              VARCHAR2(200 CHAR);
    v_listagg            SYS_REFCURSOR;
    v_where_clause_vals  coltype_NAME_VALUE := NVL(pin_where_clause_vals,
                                                   coltype_NAME_VALUE());

    vcol_lp_row_ids   TABLETYPE_DT_NUMBER;
    vcol_lp_row_count TABLETYPE_DT_NUMBER;
  BEGIN
    v_stamp := 'COMMONS_TABLES.GET_DATA_FROM_QUERY - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    -- log parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(pin_query),
                               ',pin_select_clause => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(pin_where_clause_vals),
                               ',pin_where_clause_vals => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(pin_orderby_clause),
                               ',pin_orderby_clause => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(pin_object_id),
                               ',pin_object_id => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(pin_select_rowstartindex),
                               ',pin_select_rowstartindex => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(pin_page_size),
                               ',pin_page_size => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(pin_lastpage_flag),
                               ',pin_lastpage_flag => <value>',
                               v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(pin_dba_hints),
                               ',pin_dba_hints => <value>',
                               v_stamp);
    END;

    begin
      commons_tables.ALTER_SESSION_NLS_BINARY;
    END;

    --pout_exec_plan_enabled := NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('VIEWS_EXEC_PLAN_ENABLED'), 'FALSE');

    pout_exec_plan_enabled := 'FALSE';
    for i in (select 1
                from properties
               where pr_name = 'DISABLE_SQL_STATS_UI'
                 and pr_value = '0') loop
      pout_exec_plan_enabled := 'TRUE';
    END LOOP;

    v_orderby_clause_new := REPLACE(REPLACE(' ORDER BY ' ||
                                            pin_orderby_clause,
                                            ' NULLS FIRST ',
                                            ' '),
                                    ' NULLS LAST ',
                                    ' '); --orderby_clause_new || hidden_cols ;

    IF pin_select_rowstartindex IS NOT NULL THEN
      IF pin_lastpage_flag = 0 THEN

        -- set the end index and additional bind variables
        v_select_rowendindex := pin_select_rowstartindex + pin_page_size;
        v_where_clause_vals.extend;
        v_where_clause_vals(v_where_clause_vals.last) := RTYPE_NAME_VALUE('pin_select_rowstartindex',
                                                                          pin_select_rowstartindex);
        v_where_clause_vals.extend;
        v_where_clause_vals(v_where_clause_vals.last) := RTYPE_NAME_VALUE('v_select_rowendindex',
                                                                          v_select_rowendindex);

        --if page size is null then we need to return all the data from the input table
        IF pin_page_size IS NULL THEN
          v_pagination_filter1 := '';
          v_pagination_filter2 := '';
        ELSE
          v_pagination_filter1 := ' where rownum <= :v_select_rowendindex';
          v_pagination_filter2 := ' where rowno >= :pin_select_rowstartindex';
        END IF;

        v_strsql := ' SELECT *
                     from (select ' || v_table_alias || '.*
                               , rownum rowno--row_number() over (' ||
                    v_orderby_clause_new ||
                    ') ROWNO
                           from (select ' ||
                    v_table_alias ||
                    '.*, null as TotalCount
                                 from (select   /*+ first_rows(' ||
                    pin_page_size || ') */ ' || pin_query || ') ' ||
                    v_table_alias || REGEXP_REPLACE(REGEXP_REPLACE(v_orderby_clause_new,
                                                                   '(TPR[0-9]+)',
                                                                   v_table_alias),
                                                    '(E[0-9]+)\.',
                                                    '\1_') || ') ' ||
                    v_table_alias || v_pagination_filter1 || ') ' ||
                    v_table_alias || ' ' || v_pagination_filter2 ||
                    REGEXP_REPLACE(REGEXP_REPLACE(v_orderby_clause_new,
                                                  '(TPR[0-9]+)',
                                                  v_table_alias),
                                   '(E[0-9]+)\.',
                                   '\1_');
      ELSE
        --its a "last page" call

        v_orderby_clause_reversed := REPLACE(REPLACE(replace(upper(v_orderby_clause_new),
                                                             'ASC',
                                                             'DESTEMP'),
                                                     'DESC',
                                                     'ASC'),
                                             'DESTEMP',
                                             'DESC');

        v_orderby_clause_reversed := REPLACE(REPLACE(REPLACE(REPLACE(replace(upper(v_orderby_clause_reversed),
                                                                             'FIRST',
                                                                             'DESTEMP'),
                                                                     'LAST',
                                                                     'FIRST'),
                                                             'DESTEMP',
                                                             'LAST'),
                                                     ' NULLS FIRST ',
                                                     ' '),
                                             ' NULLS LAST ',
                                             ' ');

        -- get row_identifiers of the last page
        v_lp_listagg := 'SELECT TAB.ROW_IDENTIFIER, ROW_COUNT ' ||
                        'FROM (SELECT COUNT(*) OVER () ROW_COUNT, TAB.ROW_IDENTIFIER ' ||
                        'FROM (SELECT ' || pin_query || ') TAB ' ||
                        v_orderby_clause_reversed || ') TAB ' ||
                        'WHERE ROWNUM <= 1+MOD(ROW_COUNT-1,' ||
                        TO_CHAR(pin_page_size) || ')';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                 ANYDATA.CONVERTCLOB(v_lp_listagg),
                                 'V_LAST_PAGE_SQL := <value>;',
                                 v_stamp);

        -- bulk collect the last rows
        IF pin_where_clause_vals IS NULL THEN
          EXECUTE IMMEDIATE v_lp_listagg BULK COLLECT
            INTO vcol_lp_row_ids, vcol_lp_row_count;
        ELSE
          v_listagg := RUN_QUERY(pin_sql            => v_lp_listagg,
                                 pin_using_bind_var => pin_where_clause_vals);

          FETCH v_listagg BULK COLLECT
            INTO vcol_lp_row_ids, vcol_lp_row_count;
        END IF;

        -- loop through the collections
        for i in 1 .. vcol_lp_row_ids.count loop
          v_lp_row_identifiers := v_lp_row_identifiers ||
                                  vcol_lp_row_ids(i) || ',';
        end loop;

        v_lp_row_identifiers := substr(v_lp_row_identifiers,
                                       1,
                                       length(v_lp_row_identifiers) - 1);

        v_row_count := CASE
                         WHEN vcol_lp_row_count.count = 0 THEN
                          0
                         ELSE
                          vcol_lp_row_count(1)
                       END;

        -- check if no records are present
        IF v_row_count = 0 THEN
          v_lp_row_identifiers := 'NULL';
        END IF;

        v_strsql := ' SELECT *
                     from (
                        select ' || v_table_alias ||
                    '.*, ' || TO_CHAR(v_row_count) ||
                    ' AS TotalCount
                             from (
                                select  ' || pin_query ||
                    ' ) ' || v_table_alias || ' ) ' || v_table_alias ||
                    ' where  TAB.ROW_IDENTIFIER IN (' ||
                    v_lp_row_identifiers || ')' ||
                    REGEXP_REPLACE(REGEXP_REPLACE(v_orderby_clause_new,
                                                  '(TPR[0-9]+)',
                                                  v_table_alias),
                                   '(E[0-9]+)\.',
                                   '\1_');
      END IF;
    ELSE
      --only totals and count
      v_strsql := '  SELECT * from   (select  ' || pin_query || ') ' ||
                  v_table_alias;
    END IF;

    -- get the dba query
    IF pin_object_id IS NOT NULL THEN
      LOAD_DBA_QUERY(pin_object_id => pin_object_id,
                     pin_dba_hints => pin_dba_hints,

                     pio_full_query => v_strsql,

                     pout_sql_id => pout_sql_id);
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCLOB(V_STRSQL),
                             'V_STRSQL := <value>;',
                             v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTVARCHAR2(pout_sql_id),
                             'SQL_ID := <value>;',
                             v_stamp);

    -- return the cursor
    IF v_where_clause_vals IS NULL THEN
      OPEN pout_result FOR v_strsql;
    ELSE
      pout_result := RUN_QUERY(pin_sql            => v_strsql,
                               pin_using_bind_var => v_where_clause_vals);
    END IF;

  END GET_DATA_FROM_QUERY;

  /* PROCEDURE SAVE_EXEC_PLAN(pin_where_clause_vals IN coltype_NAME_VALUE,
  pin_object_id         IN NUMBER,
  pin_differntiator     IN NUMBER,
  pi_sql_id             IN VARCHAR2,
  pi_child_number       IN NUMBER)*/

  PROCEDURE SAVE_EXEC_PLAN(pin_where_clause_vals IN coltype_NAME_VALUE,
                           pin_object_id         IN NUMBER)
  -- Assumptions:
    -- Input Parameters are built using valid column names
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_where_clause_vals         The list of bind variables used in the query
    --    pin_object_id             ID of the view to be displayed in order to activate catching feature
    -----------------------------------------------------------------------------------------
    -- Output :
    -----------------------------------------------------------------------------------------
    -- Return :
    ----------------------------------------------------------------------------------------
    /*
      -- Example :
          DECLARE
      v_temp NUMBER(10);
    BEGIN
      SELECT 1
      INTO v_temp
      FROM dual;

      COMMONS_TABLES.SAVE_EXEC_PLAN(pin_where_clause_vals => coltype_NAME_VALUE(RTYPE_NAME_VALUE(':qpv1','23'), RTYPE_NAME_VALUE(':qpv1','46')),
             pin_object_id             => 1);

    END;
      */
   AS

    PRAGMA AUTONOMOUS_TRANSACTION;
    v_client_id    VARCHAR2(200 CHAR);
    v_plan_hash    NUMBER;
    v_sql_fulltext CLOB;
    v_stamp        VARCHAR2(200 CHAR);
    --v_order_id     sql_execution_stats.ses_order_id%TYPE;

    v_sql_id       VARCHAR2(30 CHAR);
    v_child_number NUMBER;
    v_sql          CLOB;
    v_where_clause VARCHAR2(32767);
    v_flag         number(1) := '1';
    v_call_job     boolean := FALSE;
  BEGIN
    /*    dba_utils.saveLastRawExecPlan
    (   pin_save_query       => 'FALSE',
        pout_client_id       => v_client_id,
        pout_sql_id          => v_sql_id,
        pout_child_number    => v_child_number,
        pout_plan_hash_value => v_plan_hash,
        pout_sql_fulltext    => v_sql_fulltext
    );*/
    --commons_utils.insert_logs('SAVE_EXEC_PLAN');
    dba_utils.GET_SQL_ID(pout_sql_id       => v_sql_id,
                         pout_child_number => v_child_number);

    /*SELECT COUNT(*)
      INTO v_cnt
      FROM TABLE_QUERY_PLANS TQP
     WHERE TQP.TQP_OBJECT_ID = pin_object_id
       AND TQP.TQP_SQL_ID = v_sql_id
       AND TQP.TQP_CHILD_NUMBER = v_child_number;
    IF (v_cnt > 0) THEN*/

    UPDATE TABLE_QUERY_PLANS
       SET TQP_LAST_USAGE_TIME    = SYSDATE,
           TQP_NUMBER_OF_ACCESSES = TQP_NUMBER_OF_ACCESSES + 1,
           TQP_LAST_USAGE_BINDS   = pin_where_clause_vals
     WHERE TQP_OBJECT_ID = pin_object_id
       AND TQP_SQL_ID = v_sql_id
       AND TQP_CHILD_NUMBER = v_child_number;

    IF (SQL%rowcount = 0) THEN
      v_call_job := TRUE;

      /* IF (pin_where_clause_vals IS NOT NULL) THEN
        v_where_clause := 'COLTYPE_NAME_VALUE(';

        FOR c IN 1 .. pin_where_clause_vals.count LOOP

          v_where_clause := v_where_clause || 'rtype_NAME_VALUE(''' || pin_where_clause_vals(c).NAME ||
                            ''',''' || pin_where_clause_vals(c).VALUE ||
                            '''),';
        END LOOP;

        v_where_clause := TRIM(',' FROM v_where_clause);
        v_where_clause := v_where_clause || ')';
      END IF;*/

      BEGIN
        INSERT INTO TABLE_QUERY_PLANS
          (TQP_OBJECT_ID,
           TQP_SQL_ID,
           TQP_CHILD_NUMBER,
           TQP_PLAN_HASH_VALUE,
           TQP_LAST_USAGE_TIME,
           TQP_NUMBER_OF_ACCESSES,
           TQP_LAST_USAGE_BINDS)
        VALUES
          (pin_object_id,
           v_sql_id,
           v_child_number,
           nvl(v_plan_hash, null),
           SYSDATE,
           1,
           nvl(pin_where_clause_vals, null));

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          UPDATE TABLE_QUERY_PLANS
             SET TQP_LAST_USAGE_TIME    = SYSDATE,
                 TQP_NUMBER_OF_ACCESSES = TQP_NUMBER_OF_ACCESSES + 1,
                 TQP_LAST_USAGE_BINDS   = nvl(pin_where_clause_vals, NULL)
           WHERE TQP_OBJECT_ID = pin_object_id
             AND TQP_SQL_ID = v_sql_id
             AND TQP_CHILD_NUMBER = v_child_number;
      END;
    END IF;
    /*      SELECT ses_order_id
        INTO v_order_id
        FROM sql_execution_stats
       WHERE ses_sql_id = pi_sql_id
         AND ses_child_number = pi_child_number
         AND ROWNUM = 1;

      IF v_order_id IS NULL THEN
        UPDATE_ORDER_ID(PI_SQL_ID       => v_sql_id,
                        PI_CHILD_NUMBER => v_child_number);
      END IF;
    ELSE*/
    IF v_call_job THEN
      --(SQL%rowcount = 0) THEN
      --v_plan_hash := nvl(v_plan_hash, 'null');

      v_sql := 'dba_utils.saveRawExecPlans(PI_SQL_ID       => ''' ||
               v_sql_id || ''',
                                     PI_CHILD_NUMBER => ' ||
               v_child_number || ');

          COMMONS_UTILS.PERSIST_EXEC_PLAN;';

      commons_utils.Async_Plsql_Run(pi_plsql_code     => v_sql,
                                    pi_comment        => 'Stats gather',
                                    pi_differentiator => v_flag);

    END IF;

    --END IF;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_stamp := 'COMMONS_TABLES.SAVE_EXEC_PLAN - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR,
                              DBMS_UTILITY.FORMAT_ERROR_STACK ||
                              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                              SQLCODE,
                              SQLERRM,
                              v_stamp);
  END SAVE_EXEC_PLAN;

  /* PROCEDURE UPDATE_ORDER_ID(pi_sql_id VARCHAR2, pi_child_number NUMBER) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_sql_id       VARCHAR2(13 CHAR) := pi_sql_id;
    v_child_number NUMBER := pi_child_number;
    v_stamp        VARCHAR2(200 CHAR);
  BEGIN
    dba_utils.saverawexecplans(pi_sql_id       => v_sql_id,
                               pi_child_number => v_child_number);

    DELETE from sql_execution_stats
     where ses_sql_id = v_sql_id
       and ses_child_number = v_child_number;

    INSERT INTO sql_execution_stats
      (ses_id,
       ses_sql_id,
       ses_run_id,
       ses_hash_value,
       ses_child_number,
       ses_operation,
       ses_options,
       ses_object_name,
       ses_optimizer,
       ses_cost,
       ses_cardinality,
       ses_access_predicates,
       ses_timestamp,
       ses_order_id,
       ses_projection,
       ses_filter_predicates)
      SELECT ses_id_seq.NEXTVAL,
             sei_sql_id,
             NULL, --pi_run_id
             sei_hash_value,
             sei_child_number,
             sei_operation,
             sei_options,
             sei_object_name,
             sei_optimizer,
             sei_cost,
             sei_cardinality,
             sei_access_predicates,
             sei_timestamp,
             sei_order_id,
             sei_projection,
             sei_filter_predicates
        FROM TEMP_SQL_EXECUTION_STATS;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      v_stamp := 'COMMONS_TABLES.UPDATE_ORDER_ID - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR,
                              DBMS_UTILITY.FORMAT_ERROR_STACK ||
                              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                              SQLCODE,
                              SQLERRM,
                              v_stamp);
  END UPDATE_ORDER_ID;*/

  /*PROCEDURE SAVE_EXEC_PLAN(pin_where_clause_vals IN coltype_NAME_VALUE,
                           pin_object_id         IN NUMBER) AS

    v_sql_id       VARCHAR2(30 CHAR);
    v_child_number NUMBER;
    v_sql          CLOB;
    v_where_clause VARCHAR2(32767);
    v_flag         number(1) := '1';
  BEGIN

    dba_utils.GET_SQL_ID(pout_sql_id       => v_sql_id,
                         pout_child_number => v_child_number);

    IF (pin_where_clause_vals IS NOT NULL) THEN
      v_where_clause := 'COLTYPE_NAME_VALUE(';

      FOR c IN 1 .. pin_where_clause_vals.count LOOP
        --v_where_clause := v_where_clause || 'rtype_NAME_VALUE(''' || pin_where_clause_vals(c).NAME ||''',''' || pin_where_clause_vals(c).VALUE || '''),';
        v_where_clause := v_where_clause || 'rtype_NAME_VALUE(q''`' || pin_where_clause_vals(c).NAME ||
                          '`'',q''`' || pin_where_clause_vals(c).VALUE ||
                          '`''),';
      END LOOP;

      v_where_clause := TRIM(',' FROM v_where_clause);
      v_where_clause := v_where_clause || ')';
    END IF;
    if v_sql_id is not null and pin_object_id is not null then
      v_sql := '
  declare
  v_sqlerrm VARCHAR2(500 CHAR);
  v_sqlcode NUMBER;

  begin
    COMMONS_TABLES.SAVE_EXEC_PLAN(pin_where_clause_vals => ' ||
               nvl(v_where_clause, 'null') || ' ,
                                               pin_object_id =>' ||
               pin_object_id || ',
                                               pin_differntiator =>1,
                                               pi_sql_id=>''' ||
               v_sql_id || ''',
                                               pi_child_number=>' ||
               v_child_number || '
                                               );
  EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode := SQLCODE;
    v_sqlerrm := substr(SQLERRM, 1, 500);
    begin
    INSERT INTO sql_stats_error_log
      (ssel_id,
       ssel_error_code,
       ssel_error_msg,
       ssel_run_id,
       ssel_object_id,
       ssel_create_date,
       ssel_flag)
    VALUES
      (sql_stats_error_log_seq.nextval,
       v_sqlcode,
       v_sqlerrm,
       null,
       ' || pin_object_id || ',
       SYSDATE,
       ' || v_flag || ');
       exception
         when others then
       null;
       end;
    COMMIT;
     end;';
      commons_utils.Async_Plsql_Run(pi_plsql_code     => v_sql,
                                    pi_comment        => 'Stats gather',
                                    pi_differentiator => v_flag);
    else
      begin
        INSERT INTO sql_stats_error_log
          (ssel_id,
           ssel_error_code,
           ssel_error_msg,
           ssel_run_id,
           ssel_object_id,
           ssel_create_date,
           ssel_flag)
        VALUES
          (sql_stats_error_log_seq.nextval,
           null,
           null,
           null,
           pin_object_id,
           SYSDATE,
           v_flag);
      exception
        when others then
          null;
      end;
    end if;

  END;*/

  -- Description: used in SAVE_STATS to SAVE the elapsed time during Java fetch of records
  -----**************************************************************************************------------------------
  PROCEDURE SAVE_FETCH_ELAPSED_TIME(pin_object_id    NUMBER,
                                    pin_sql_id       VARCHAR2,
                                    pin_elapsed_time NUMBER) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    UPDATE TABLE_DBA_QUERIES TDQ
       SET TDQ_MAX_ELAPSED_TIME = CASE
                                    WHEN NVL(TDQ_MAX_ELAPSED_TIME, 0) <
                                         PIN_ELAPSED_TIME AND
                                         NVL(TDQ_USE_DBA_QUERY, 0) = 0 THEN
                                     PIN_ELAPSED_TIME
                                    ELSE
                                     TDQ_MAX_ELAPSED_TIME
                                  END,
           TDQ_AVERAGE_ELAPSED_TIME = CASE
                                        WHEN TDQ_AVERAGE_ELAPSED_TIME IS NULL AND
                                             NVL(TDQ_USE_DBA_QUERY, 0) = 0 THEN
                                         PIN_ELAPSED_TIME
                                        WHEN TDQ_USE_DBA_QUERY = 1 THEN
                                         TDQ_AVERAGE_ELAPSED_TIME
                                        ELSE
                                         (TDQ_AVERAGE_ELAPSED_TIME *
                                         (TDQ_NUMBER_OF_ACCESSES - 1) +
                                         PIN_ELAPSED_TIME) /
                                         TDQ_NUMBER_OF_ACCESSES
                                      END,
           TDQ_DBA_MAX_ELAPSED_TIME = CASE
                                        WHEN NVL(TDQ_DBA_MAX_ELAPSED_TIME, 0) <
                                             PIN_ELAPSED_TIME AND
                                             TDQ_USE_DBA_QUERY = 1 THEN
                                         PIN_ELAPSED_TIME
                                        ELSE
                                         TDQ_DBA_MAX_ELAPSED_TIME
                                      END,
           TDQ_DBA_AVERAGE_ELAPSED_TIME = CASE
                                            WHEN TDQ_DBA_AVERAGE_ELAPSED_TIME IS NULL AND
                                                 TDQ_USE_DBA_QUERY = 1 THEN
                                             NVL(TDQ_DBA_AVERAGE_ELAPSED_TIME,
                                                 PIN_ELAPSED_TIME)
                                            WHEN NVL(TDQ_USE_DBA_QUERY, 0) = 0 THEN
                                             TDQ_DBA_AVERAGE_ELAPSED_TIME
                                            ELSE
                                             (TDQ_DBA_AVERAGE_ELAPSED_TIME *
                                             (TDQ_DBA_NUMBER_OF_ACCESSES - 1) +
                                             PIN_ELAPSED_TIME) /
                                             TDQ_DBA_NUMBER_OF_ACCESSES
                                          END
     WHERE TDQ_OBJECT_ID = PIN_OBJECT_ID
       AND TDQ_SQL_ID = PIN_SQL_ID;

    COMMIT;
  END;

  -----**************************************************************************************------------------------
  PROCEDURE SAVE_STATS(pin_where_clause_vals IN coltype_NAME_VALUE,
                       pin_object_id         IN NUMBER,
                       pin_tdq_sql_id        IN VARCHAR2,
                       pin_elapsed_time      IN NUMBER) AS
    v_stamp VARCHAR2(200 CHAR);
  BEGIN

    SAVE_EXEC_PLAN(pin_where_clause_vals => pin_where_clause_vals,
                   pin_object_id         => pin_object_id);

    SAVE_FETCH_ELAPSED_TIME(pin_object_id    => pin_object_id,
                            pin_sql_id       => pin_tdq_sql_id,
                            pin_elapsed_time => pin_elapsed_time);

  EXCEPTION
    WHEN OTHERS THEN
      v_stamp := 'COMMONS_TABLES.SAVE_STATS - ' ||
                 TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR,
                              DBMS_UTILITY.FORMAT_ERROR_STACK ||
                              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                              SQLCODE,
                              SQLERRM,
                              v_stamp);
  END;

  /*
  -- 14.May.2013 -- P.6. CREATE_UNIQUE_INDEXES
    PROCEDURE CREATE_UNIQUE_INDEXES(pi_tables_id in NUMBER) IS
      v_sql              CLOB := '';
      v_sql1             CLOB := '';
      V_TABLENAME        VARCHAR2(30);
      v_initrans         VARCHAR2(10);
      v_index_tablespace VARCHAR2(30) := USER || '_IND';
      v_out1             CLOB := '';
      v_out2             CLOB := '';
    BEGIN

      SELECT MIN(PR_VALUE)
        INTO v_INITRANS
        FROM PROPERTIES
       WHERE PR_NAME = 'INITRANS';

      SELECT TABLE_NAME
        into V_TABLENAME
        FROM USER_TABLES ut, TABLES t
       WHERE ut.TABLE_NAME = t.TABLES_PHYSICAL_NAME
         and t.tables_id = pi_tables_id
         \*and t.TABLES_IS_PREDEFINED = 0*\;

      if V_TABLENAME is not null then

        FOR c in (SELECT TC_PHYSICAL_NAME,
                         TC_LOGIC_TYPE,
                         TC_COLUMN_TYPE,
                         TC_IS_NULLABLE
                    from TABLE_COLUMNS
                   WHERE TC_TABLES_ID = pi_tables_id
                   order by TC_IS_NULLABLE, TC_ORDER) LOOP

          --E_INTERNAL_ID column
          if c.TC_PHYSICAL_NAME = 'E_INTERNAL_ID' and c.TC_COLUMN_TYPE = 3 THEN

            --Create unique index on 'E_INTERNAL_ID' column
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       12) || '_' ||
                                                                SUBSTR(c.TC_PHYSICAL_NAME,
                                                                       1,
                                                                       15) ||
                                                                '_UI',
                                        pi_col_list          => 'E_INTERNAL_ID',
                                        pi_uniqueness        => 1,
                                        pi_composite         => 0,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        po_indexing_info     => v_out1);
          END IF;

          --unique composite key columns append required key columns
          if (c.TC_LOGIC_TYPE = 1 or c.TC_LOGIC_TYPE = 3 or
             c.TC_LOGIC_TYPE = 6 or c.TC_LOGIC_TYPE = 8 or
             c.TC_LOGIC_TYPE = 9) THEN
            v_sql := v_sql || c.TC_PHYSICAL_NAME || ',';
          end if;

          --auto value key column
          if (c.TC_LOGIC_TYPE = 5) THEN
            v_sql1 := v_sql1 || c.TC_PHYSICAL_NAME || ',';
          end if;
        END LOOP;

        --Concat column key list
        if v_sql1 is not null THEN
          v_sql := SUBSTR(v_sql1, 1, LENGTH(v_sql1) - 1);
          DBMS_OUTPUT.PUT_LINE('Auto Value Columns :- ' || v_sql);
          COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                      pi_indexname         => SUBSTR(v_tablename,
                                                                     1,
                                                                     15) ||
                                                              '_BUSINESSKEY_UI',
                                      pi_col_list          => v_sql,
                                      pi_uniqueness        => 1,
                                      pi_composite         => 0,
                                      pi_col_is_primarykey => 0,
                                      pi_initrans          => v_initrans,
                                      pi_index_tablespace  => v_index_tablespace,
                                      pi_nls_sort          => 'BINARY_CI',
                                      po_indexing_info     => v_out2);

        elsif v_sql is not null then
          -- remove the last ',' from the list
          v_sql := SUBSTR(v_sql, 1, LENGTH(v_sql) - 1);
          DBMS_OUTPUT.PUT_LINE('Key Columns :- ' || v_sql);
          --if more than 1 key column is present, create composite index
          if regexp_count(v_sql, ',') > 0 then
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       15) ||
                                                                '_BUSINESSKEY_UI',
                                        pi_col_list          => v_sql,
                                        pi_uniqueness        => 1,
                                        pi_composite         => 1,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        pi_nls_sort          => 'BINARY_CI',
                                        po_indexing_info     => v_out2);
            --if only 1 key column is present, create unique non-composite index
          elsif regexp_count(v_sql, ',') = 0 then
            COMMONS_TABLES.CREATE_INDEX(pi_tablename         => v_tablename,
                                        pi_indexname         => SUBSTR(v_tablename,
                                                                       1,
                                                                       15) ||
                                                                '_BUSINESSKEY_UI',
                                        pi_col_list          => v_sql,
                                        pi_uniqueness        => 1,
                                        pi_composite         => 0,
                                        pi_col_is_primarykey => 0,
                                        pi_initrans          => v_initrans,
                                        pi_index_tablespace  => v_index_tablespace,
                                        pi_nls_sort          => 'BINARY_CI',
                                        po_indexing_info     => v_out2);
          end if;

        end if;

      end if;
    END CREATE_UNIQUE_INDEXES;
  */

  PROCEDURE GET_SET_AUTO_VALUE(PI_TABLE_ID         IN NUMBER,
                               PI_OFFSET_VAL       IN NUMBER,
                               PO_AV_RANGE_WITH_TS OUT SYS_REFCURSOR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    V_TABLE_NEXT_VAL NUMBER;
    V_UTC_TIMESTAMP  TIMESTAMP;
  BEGIN
    UPDATE AUTO_VALUE
       SET AV_NEXT_VALUE    = AV_NEXT_VALUE + PI_OFFSET_VAL,
           AV_UTC_TIMESTAMP = SYS_EXTRACT_UTC(SYSTIMESTAMP)
     WHERE AV_TABLES_ID = PI_TABLE_ID
    RETURNING AV_NEXT_VALUE, AV_UTC_TIMESTAMP INTO V_TABLE_NEXT_VAL, V_UTC_TIMESTAMP;

    --Handling if the input table_id doest not exists.
    IF (V_TABLE_NEXT_VAL IS NULL) THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'Given table_id does not exists in AUTO_VALUE table');
    END IF;

    --Handling  out of range offset.
    IF (V_TABLE_NEXT_VAL - 1 >= 10000000000000) THEN
      RAISE_APPLICATION_ERROR(-20310,
                              'Auto-value range not within system bounds');
    END IF;

    COMMIT;

    OPEN PO_AV_RANGE_WITH_TS FOR
      SELECT V_TABLE_NEXT_VAL - PI_OFFSET_VAL AS MIN_VALUE,
             V_TABLE_NEXT_VAL - 1 AS MAX_VALUE,
             V_UTC_TIMESTAMP AS TIME_STAMP
        FROM DUAL;
  END GET_SET_AUTO_VALUE;

  PROCEDURE Delete_Entity_Check(pi_Entity_IDs              VARCHAR2,
                                pi_Ent_Del_Run_Param_ID    NUMBER,
                                pi_Entity_Usage_Table_Name VARCHAR2,
                                pi_intl_Col_name           VARCHAR2,
                                pi_TempUsage_Table_Name    VARCHAR2) IS

  BEGIN

    /*v_sql := 'insert into ' || pi_Entity_Usage_Table_Name || '
    With Entity_Usage_Temp As
     (
    Select Cr_Definition_Id,Col_Tab_List.Table_Name Table_Name,Col_Tab_List.COLUMN_Name, CASE WHEN  Utc.Column_Name IS NULL THEN 0 ELSE 1 END AS COLUMN_IS_ACCESSIBLE
      FROM ((
      SELECT TABLES_PHYSICAL_NAME TABLE_NAME, --sql block to get the list of columns having entity_id usage as passed below.
          TC_PHYSICAL_NAME COLUMN_NAME ,
          CR_DEFINITION_ID,
          TABLES_ID
         FROM TABLE_COLUMNS
        Inner Join
        (     SELECT TABLES_PHYSICAL_NAME,--query to get the tables physical name for all the tables from categorization.
              CR_DEFINITION_ID,
              TABLES_ID
              FROM TABLES T INNER JOIN CATEGORY_RELATIONSHIPS CR
              ON ( CR.CR_DEFINITION_ID = T.TABLES_DEFINITION_ID
              Or Cr.Cr_Definition_Id   = T.Tables_Id )
              WHERE CR_CD_ID          <> 3
      ) On Tc_Tables_Id                          =Tables_Id
       Where Tc_Entity_Id In ( ' || pi_Entity_IDs || ' ) --Entity_id to be passed for searching
       And Tc_Column_Type = 1) Col_Tab_List Left Outer Join User_Tab_Cols Utc On Col_Tab_List.Column_Name=Utc.Column_Name And Col_Tab_List.Table_Name=Utc.Table_Name)
       )
       SELECT Cr_Definition_Id,E_INERTNAL_ID  FROM(
       Select Cr_Definition_Id, E_INERTNAL_ID_TAB.COLUMN_VALUE E_INERTNAL_ID, TABLE_NAME,COLUMN_NAME,COLUMN_IS_ACCESSIBLE FROM ENTITY_USAGE_TEMP,
        (Select  ' || pi_intl_Col_name || ' Column_Value From ' ||
                 pi_TempUsage_Table_Name ||
                 ' ) E_Inertnal_Id_Tab ,
       TABLE (XMLSEQUENCE (DBMS_XMLGEN.GETXMLTYPE (''select ''
      || COLUMN_NAME
      || '' from ''
      || Table_Name
      || '' where ''
      || Column_Name
      || '' = ''
      || E_Inertnal_Id_Tab.Column_Value
      || ''and rownum=1'').Extract (''ROWSET/ROW/*'')))  Where Entity_Usage_Temp.Column_Is_Accessible=1)';*/

    execute immediate '
begin
for I in (
With Entity_Usage_Temp As
 (
Select Cr_Definition_Id,Col_Tab_List.Table_Name Table_Name,Col_Tab_List.COLUMN_Name, CASE WHEN  Utc.Column_Name IS NULL THEN 0 ELSE 1 END AS COLUMN_IS_ACCESSIBLE
  FROM ((
  SELECT TABLES_PHYSICAL_NAME TABLE_NAME, --sql block to get the list of columns having entity_id usage as passed below.
      TC_PHYSICAL_NAME COLUMN_NAME ,
      CR_DEFINITION_ID,
      TABLES_ID
     FROM TABLE_COLUMNS
    Inner Join
    (     SELECT TABLES_PHYSICAL_NAME,--query to get the tables physical name for all the tables from categorization.
          CR_DEFINITION_ID,
          TABLES_ID
          FROM TABLES T INNER JOIN CATEGORY_RELATIONSHIPS CR
          ON ( CR.CR_DEFINITION_ID = T.TABLES_DEFINITION_ID
          Or Cr.Cr_Definition_Id   = T.Tables_Id )
          WHERE CR_CD_ID          <> 3
  ) On Tc_Tables_Id                          =Tables_Id
   Where Tc_Entity_Id In ( ' || pi_Entity_IDs || ')
   And Tc_Column_Type = 1) Col_Tab_List Left Outer Join User_Tab_Cols Utc On Col_Tab_List.Column_Name=Utc.Column_Name And Col_Tab_List.Table_Name=Utc.Table_Name )
   )
   Select CR_DEFINITION_ID,TABLE_NAME,COLUMN_NAME,COLUMN_IS_ACCESSIBLE FROM ENTITY_USAGE_TEMP) loop
    execute immediate ''insert into ' ||
                      pi_Entity_Usage_Table_Name ||
                      ' select ''||i.CR_DEFINITION_ID ||'' cr_id ,E_Inertnal_Id_Tab.Column_Value int_id from ''||I.TABLE_NAME||'' t inner join (Select  ' ||
                      pi_intl_Col_name || ' Column_Value From ' ||
                      pi_TempUsage_Table_Name || ' ) E_Inertnal_Id_Tab
                         on (t.''||I.COLUMN_NAME||'' = E_Inertnal_Id_Tab.Column_Value)'';


   end loop;
   end;';

    COMMIT;
    --insert_sql_clob('DELETE_ENTITY_CHECK ','Oracle SP Process Completed');

  END delete_entity_check;

  procedure all_null_col_check(pi_table_name           IN varchar2,
                               pi_ea_entity_id_ra_list IN COL_LIST_30,
                               po_status               OUT number) is
    sql_query    clob;
    where_clause clob;
    null_rows    number(10);
    num_rows     number;

  begin
    po_status := 0;
    if pi_ea_entity_id_ra_list.count = 0 then
      execute immediate 'select count(*) from ' || pi_table_name ||
                        ' where rownum=1'
        into num_rows;
      if num_rows = 0 then
        po_status := 1;
      end if;
    else
      for i in pi_ea_entity_id_ra_list.first .. pi_ea_entity_id_ra_list.last loop
        if pi_ea_entity_id_ra_list(i) is not null then
          where_clause := where_clause || '  ' ||
                          pi_ea_entity_id_ra_list(i) || ' is null and ';
        end if;
      end loop;
      where_clause := substr(where_clause, 1, length(where_clause) - 4);
      --dbms_output.put_line(where_clause);
      sql_query := ' select count(*) from dual where exists (select 1 from ' ||
                   pi_table_name || ' where ' || where_clause || ' )';
      --dbms_output.put_line(sql_query);
      execute immediate sql_query
        into null_rows;

      --  dbms_output.put_line(null_rows);
      if null_rows = 0 then
        po_status := 1;
      end if;
    end if;
  end all_null_col_check;
  procedure all_null_col_records(pi_table_name           IN varchar2,
                                 pi_return_col_list      IN COL_LIST_30,
                                 pi_ea_entity_id_ra_list IN COL_LIST_30,
                                 po_null_col_rec         OUT sys_refcursor) is
    sql_query     clob;
    where_clause  clob;
    select_clause clob;
  begin
    for i in pi_ea_entity_id_ra_list.first .. pi_ea_entity_id_ra_list.last loop
      if pi_ea_entity_id_ra_list(i) is not null then
        where_clause := where_clause || '  ' || pi_ea_entity_id_ra_list(i) ||
                        ' is null and ';
      end if;
    end loop;
    where_clause := substr(where_clause, 1, length(where_clause) - 4);
    -- dbms_output.put_line(where_clause);
    for i in pi_return_col_list.first .. pi_return_col_list.last loop
      if pi_return_col_list(i) is not null then
        select_clause := select_clause || pi_return_col_list(i) || ',';
      end if;
    end loop;
    select_clause := trim(trailing ',' from select_clause);
    -- dbms_output.put_line('select '||select_clause|| ' from '||pi_table_name||' where '||where_clause);
    open po_null_col_rec for 'select ' || select_clause || ' from ' || pi_table_name || ' where ' || where_clause;

  end all_null_col_records;

  FUNCTION index_column_expression_char(tab_name     VARCHAR2,
                                        ind_name     VARCHAR2,
                                        col_position NUMBER) RETURN VARCHAR2 IS
    temporary_varchar VARCHAR2(4000);
  BEGIN
    SELECT column_expression
      INTO temporary_varchar
      FROM user_ind_expressions
     WHERE table_name = tab_name
       AND index_name = ind_name
       AND column_position = col_position;
    RETURN temporary_varchar;
  END;

  -- used in view TOTALS
  PROCEDURE SQL_INPUT_CARDINALITY(pin_input_table_name IN VARCHAR2,
                                  pin_full_sql         IN CLOB,
                                  pin_input_threshold  IN NUMBER,
                                  pin_sql_threshold    IN NUMBER,

                                  pout_cardinality_threshold OUT NUMBER) AS
    v_input_cardinality NUMBER;
  BEGIN
    pout_cardinality_threshold := 0;
    BEGIN
      -- check the input table size
      EXECUTE IMMEDIATE 'SELECT COALESCE(UT.NUM_ROWS, 0) + COALESCE(UTM.INSERTS - UTM.DELETES, 0)
                           FROM USER_TABLES UT
                           LEFT JOIN USER_TAB_MODIFICATIONS UTM
                             ON UTM.TABLE_NAME = ''' ||
                        pin_input_table_name || '''
                          WHERE  UT.TABLE_NAME = ''' ||
                        pin_input_table_name || ''''
        INTO v_input_cardinality;
      IF (v_input_cardinality > pin_input_threshold) THEN
        -- if the threshold is exceeded
        pout_cardinality_threshold := 1;
      ELSE
        -- check the execution plan threshold
        IF (optymyze_admin.dba_analysis.getEstimatedCardinalityForSQL(pin_full_sql) >
           pin_sql_threshold) THEN
          pout_cardinality_threshold := 1;
        END IF;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        pout_cardinality_threshold := 1;
      WHEN OTHERS THEN
        DECLARE
          v_stamp VARCHAR2(200 CHAR);
        BEGIN
          v_stamp := 'COMMONS_TABLES.SQL_INPUT_CARDINALITY - ' ||
                     TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
          -- log table name
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_ERROR,
                                   ANYDATA.CONVERTVARCHAR2(pin_input_table_name),
                                   ',pin_input_table_name => <value>',
                                   v_stamp);
        END;
        -- return the output
        pout_cardinality_threshold := 1;
    END;
  END;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************
END COMMONS_TABLES;
/
