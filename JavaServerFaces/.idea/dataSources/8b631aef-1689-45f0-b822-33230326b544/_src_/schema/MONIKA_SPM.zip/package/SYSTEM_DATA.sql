CREATE PACKAGE SYSTEM_DATA AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.

 -- ========================================================
  -- Author     : Filip, Catalin
  -- Create date: 20140120
  -- Description: Inserts a new predefined entity.
  --              If the project already contains an user defined entity (category Other) with the same name as the new predefined entity, the procedure will rename the users's entity.
  --              If another predefined entity with the same name already exists, the procedure will raise an error.
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
	 pin_ENTITY_NAME                    VARCHAR2	   NOT NULL		Name of the Entity
   pin_ENTITY_CATEGORY_TYPE           NUMBER       NOT NULL		Entity Category Type
	 pin_ENTITY_TABLES_ID               NUMBER		   NULL		    Tables Id
	 pin_ENTITY_CUSTOM_VERSION          NUMBER       NOT NULL   Custom object versioning for RHP
	 pin_ENTITY_BASE_ENTITY             NUMBER       NULL			  Stores base entity id in case of equivalent entities
	 pin_ENTITY_FOL_ID                  NUMBER	     NULL			  Folder Id
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
	begin
	  system_data.ADD_SYSTEM_ENTITY(pin_ENTITY_NAME =>'Test',
									pin_ENTITY_CATEGORY_TYPE =>4,
									pin_ENTITY_TABLES_ID => null,
									pin_ENTITY_CUSTOM_VERSION =>1,
									pin_ENTITY_BASE_ENTITY => null,
									pin_ENTITY_FOL_ID => null);
	end;
  */
  -----------------------------------------------------------------------------------------
PROCEDURE ADD_PREDEFINED_ENTITY(
		  pin_ENTITY_NAME                    VARCHAR2
		  ,pin_ENTITY_CATEGORY_TYPE           NUMBER
		  ,pin_ENTITY_TABLES_ID               NUMBER
		  ,pin_ENTITY_CUSTOM_VERSION          NUMBER
		  ,pin_ENTITY_BASE_ENTITY             NUMBER
		  ,pin_ENTITY_FOL_ID                  NUMBER
		 );



--Example
/*
BEGIN

EXECUTE IMMEDIATE SYSTEM_DATA.REGISTER_EXISTING_OBJECT (
           pi_TABLE_NAME =>'DATA_TABLES'
          ,pi_ID_COLUMN =>'DT_ID'
          ,pi_NAME_COLUMN =>'DT_NAME'
          ,pi_DEFINITION_TYPE_ID =>10

          ) ;


END;
*/


  FUNCTION REGISTER_EXISTING_OBJECT(pi_TABLE_NAME             IN varchar2,
                                    pi_ID_COLUMN              IN varchar2,
                                    pi_NAME_COLUMN            IN varchar2,
                                    pi_DEFINITION_TYPE_ID     IN NUMBER default null,
                                    pi_DEFINITION_TYPE_COLUMN IN varchar2 default NULL,
									pi_CONTAINER_ID_COLUMN    IN varchar2 default NULL)
    return varchar2;




--Example
/*
BEGIN

EXECUTE IMMEDIATE SYSTEM_DATA.REGISTRATION_INSERT_TRIGGER(pi_TRIGGER_NAME =>'DATA_TABLES_BI_TRG',
                                     pi_TABLE_NAME  =>'DATA_TABLES',
                                     pi_ID_COLUMN  =>'DT_ID',
                                     pi_NAME_COLUMN  =>'DT_NAME',
                                     pi_DEFINITION_TYPE_ID        =>10

                                     )  ;


END;
*/
FUNCTION REGISTRATION_INSERT_TRIGGER(pi_TRIGGER_NAME           IN varchar2,
                                       pi_TABLE_NAME             IN varchar2,
                                       pi_ID_COLUMN              IN varchar2,
                                       pi_NAME_COLUMN            IN varchar2,
                                       pi_DEFINITION_TYPE_ID     IN NUMBER default null,
                                       pi_DEFINITION_TYPE_COLUMN IN varchar2 default null,
									   pi_CONTAINER_ID_COLUMN    IN varchar2 default NULL)
return varchar2;


--Example
/*
BEGIN

EXECUTE IMMEDIATE SYSTEM_DATA.REGISTRATION_UPDATE_TRIGGER(pi_TRIGGER_NAME =>'DATA_TABLES_BU_TRG',
                                     pi_TABLE_NAME    =>'DATA_TABLES',
                                     pi_ID_COLUMN    =>'DT_ID',
                                     pi_NAME_COLUMN  =>'DT_NAME'
                                     )  ;


END;

  */
FUNCTION REGISTRATION_UPDATE_TRIGGER(pi_TRIGGER_NAME IN varchar2,
                                     pi_TABLE_NAME   IN varchar2,
                                     pi_ID_COLUMN    IN varchar2,
                                     pi_NAME_COLUMN  IN varchar2,
									 pi_CONTAINER_ID_COLUMN    IN varchar2 default NULL)
  return varchar2;

--Example
/*
BEGIN

EXECUTE IMMEDIATE SYSTEM_DATA.REGISTRATION_DELETE_TRIGGER(pi_TRIGGER_NAME =>'DATA_TABLES_BD_TRG',
                                     pi_TABLE_NAME  =>'DATA_TABLES',
                                     pi_ID_COLUMN    =>'DT_ID'
                                     )  ;


END;
*/

FUNCTION REGISTRATION_DELETE_TRIGGER(pi_TRIGGER_NAME IN varchar2,
                                     pi_TABLE_NAME   IN varchar2,
                                     pi_ID_COLUMN    IN varchar2)
  return varchar2;

  /*
  Example:-
    begin
    -- Call the procedure
    SYSTEM_DATA.register_object(pi_or_id => 1000,
                                           pi_or_name => 'test',
                                           pi_or_type => '2');
  end;
    */
  procedure REGISTER_OBJECT(PI_OR_ID   NUMBER,
                            PI_OR_NAME VARCHAR2,
                            PI_OR_TYPE NUMBER,
							PI_OR_CONTAINER_ID NUMBER DEFAULT NULL);

                            /*
  Example:-
    begin
    -- Call the procedure
    SYSTEM_DATA.deregister_object(pi_or_id => 1000);
  end;
  */
  procedure DEREGISTER_OBJECT(PI_OR_ID NUMBER);

  /*
  Example:-
  begin
    -- Call the procedure
    SYSTEM_DATA.modify_registration(pi_or_id   => 1000,
                                               pi_or_name => 'rename');
  end;
  */
  procedure MODIFY_REGISTRATION(PI_OR_ID NUMBER,
								PI_OR_NAME VARCHAR2,
								PI_OR_CONTAINER_ID NUMBER DEFAULT NULL);

    -- *******************************    PUBLIC PROCEDURES END         *******************************
END SYSTEM_DATA;
/
