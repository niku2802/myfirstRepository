CREATE package body DT_WGTSUM as
  function check_overlap(pi_data_type varchar2, pi_tab ws_overlap_tab)
    return number is
    x1_num  number;
    x2_num  number;
    y1_num  number;
    y2_num  number;
    x1_date date;
    x2_date date;
    y1_date date;
    y2_date date;
    i       number;
    j       number;
  begin
    if pi_tab.count > 0 then
      if pi_data_type = 'NUMERIC' then
        /*commons_utils.insert_logs('pi_tab.count : ' || to_char(pi_tab.count));*/
        for i in 1 .. pi_tab.count loop

          x1_num := to_number(pi_tab(i).low_bound);
          x2_num := to_number(pi_tab(i).up_bound);
          /*commons_utils.insert_logs(x1_num || ' - ' || x2_num);*/
          for j in 1 .. pi_tab.count loop
            y1_num := to_number(pi_tab(j).low_bound);
            y2_num := to_number(pi_tab(j).up_bound);
            if i <> j and (x1_num <= y2_num and x2_num >= y1_num) then
              return 1;
            end if;
          end loop;
        end loop;
      end if;
      if pi_data_type in ('DATE', 'PERIOD') then
        for i in 1 .. pi_tab.count loop

          x1_date := to_date(pi_tab(i).low_bound, 'YYYY-MM-DD');
          x2_date := to_date(pi_tab(i).up_bound, 'YYYY-MM-DD');
          /*commons_utils.insert_logs(to_char(x1_date) || ' - ' ||
          to_char(x2_date));*/
          for j in 1 .. pi_tab.count loop
            y1_date := to_date(pi_tab(j).low_bound, 'YYYY-MM-DD');
            y2_date := to_date(pi_tab(j).up_bound, 'YYYY-MM-DD');
            if i <> j and (x1_date <= y2_date and x2_date >= y1_date) then
              return 1;
            end if;
          end loop;
        end loop;
      end if;
      if pi_data_type = 'DATE_TIME' then
        for i in 1 .. pi_tab.count loop

          x1_date := to_date(pi_tab(i).low_bound, 'YYYY-MM-DD HH24:MI:SS');
          x2_date := to_date(pi_tab(i).up_bound, 'YYYY-MM-DD HH24:MI:SS');

          for j in 1 .. pi_tab.count loop
            y1_date := to_date(pi_tab(j).low_bound, 'YYYY-MM-DD HH24:MI:SS');
            y2_date := to_date(pi_tab(j).up_bound, 'YYYY-MM-DD HH24:MI:SS');
            if i <> j and (x1_date <= y2_date and x2_date >= y1_date) then
              return 1;
            end if;
          end loop;
        end loop;
      end if;
    end if;
    return 0;

  end;

  procedure calculate_weighted_sum(pi_dto_id         in number,
                                   pi_in_table       in number,
                                   pi_result_table   in number,
                                   pi_io_alias       in varchar2,
                                   pi_ip_filter      in varchar2,
                                   pi_ip_join_clause in varchar2,
                                   pi_op_filter      in varchar2,
                                   pi_op_join_clause in varchar2,
                                   po_error_code     out number,
                                   po_parameter_name out varchar2,
                                   po_records_count  out number) is

    v_param_sql         clob := '';
    v_insert_sql        clob := '';
    v_main_sql          clob := '';
    v_opp_tab           varchar2(100);
    v_param_tab         varchar2(100);
    v_result_table      varchar2(100);
    v_prev_parameter    varchar2(100) := '';
    v_prev_weight       number;
    v_prev_distinct_val varchar2(250) := '';
    v_first_flag        number(1) := 1;
    v_res_fld_col_name  varchar2(250);
    v_parameter         varchar2(250);
    v_parameter_name    varchar2(250);
    v_weight            number;
    v_distinct_value    varchar2(250);
    v_lower_bound       varchar2(250);
    v_upper_bound       varchar2(250);
    v_importance        number;
    --v_no_enabled_param_flag number(1);
    v_total_weight        number := 0;
    v_data_type           varchar2(30);
    v_parameter_name_o    varchar2(250);
    v_is_overlap          number(1);
    v_col_list            clob;
    v_select_list         clob;
    v_period_ovlap_sql    clob;
    v_op_filter_sql       clob;
    v_opp_tab_seq_name    varchar2(250);
    v_tupr_ids            COLTYPE_ID := COLTYPE_ID();
    v_tupr_ids_list       varchar2(2000);
    v_lower_tu_id         number;
    v_upper_tu_id         number;
    v_fld_tu_id           number;
    v_start_tupr          number;
    v_end_tupr            number;
    v_date_format_check_l date;
    v_date_format_check_u date;
    v_join_clause         varchar2(2000);
    type join_tab is table of varchar2(2000);
    v_join_tab             join_tab := join_tab();
    v_cursor               sys_refcursor;
    v_cnt                  number := 1;
    v_display_name         varchar2(250);
    v_col_present          number;
    v_tab_empty_flag       number(1) := 0;
    v_overlap_tab          ws_overlap_tab := ws_overlap_tab();
    v_overlap_counter      number := 1;
    v_prev_data_type       varchar2(30);
    v_prev_display_name    varchar2(250);
    v_low_num              number;
    v_up_num               number;
    v_period_l_date        varchar2(250);
    v_period_u_date        varchar2(250);
    v_percentage_flag      number(1) := 0;
    v_result_fld_precision number;
    v_is_valid_date        number := 0;
    v_res_tab_seq_name     varchar2(50);
  begin
    po_records_count := 0;
    /* commons_utils.insert_logs('Filter : '||pi_ip_filter);
    commons_utils.insert_logs('join Clause : '||pi_ip_join_clause);*/
    /*commons_utils.insert_logs('pi_op_filter : '||pi_op_filter);*/
    /* commons_utils.insert_logs('pi_in_table : '||pi_in_table);
    commons_utils.insert_logs('pi_result_table : '||pi_result_table);*/
    --can be combined to one

    select tables_physical_name
      into v_param_tab
      from dt_weighted_sum dws, tables t
     where dws.dtws_dto_id = pi_dto_id
       and dws.dtws_dt_id = t.tables_definition_id;

    /*  commons_utils.insert_logs('v_param_tab : ' || v_param_tab);*/

    select tables_physical_name, tables_rowid_seq_name
      into v_opp_tab, v_opp_tab_seq_name
      from tables t
     where t.tables_id = pi_in_table;

    /* select tables_rowid_seq_name
     into v_res_tab_seq_name
     from tables t
    where t.tables_id = pi_result_table;*/

    /*commons_utils.insert_logs('v_opp_tab : ' || v_opp_tab);*/

    select tables_physical_name, tables_rowid_seq_name
      into v_result_table, v_res_tab_seq_name
      from tables t
     where t.tables_id = pi_result_table;

    select f.fld_column_name, f.fld_length
      into v_res_fld_col_name, v_result_fld_precision
      from fields f, dt_weighted_sum dtws
     where dtws.dtws_dto_id = pi_dto_id
       and f.fld_id = dtws.dtws_res_fld_id;

    v_is_overlap := 0;

    /* insert into ws_gtt_temp (wspmg_id,wspmg_entity_id,wspmg_fld_id,wspmg_column_name)
    select * from WS_parameter_MAP_GTT;
    commit;*/
    /*select count(*) into v_row_count from ws_gtt_temp;
    commons_utils.insert_logs('v_row_count in GTT : ' ||
                              to_char(v_row_count));*/
    -- v_param_sql is used for getting the records from parameter table.
    v_param_sql := 'select
       case
         when ent.entity_id is null then
          param_tab.parameter1
         else
          ''ENT_'' || wspmg.wspmg_id || ''.'' || fld.fld_column_name
       end parameter,
       param_tab.weight,
       param_tab.distinct_value,
       param_tab.lower_bound,
       param_tab.upper_bound,
       param_tab.importance,
       case fld.fld_data_type
                  when 1 then
                   ''CHAR''
                  when 2 then
                   ''BOOLEAN''
                  when 3 then
                   ''DATE''
                  when 4 then
                   ''NOTE''
                  when 5 then
                  ''DATE_TIME''
                  when 6 then
                   ''NUMERIC''
                  when 8 then
                  ''PERIOD''
                  when 9 then
                   ''ATTACHMENT''
                  when 10 then
                    ''PICTURE''
                end data_type,
       case
         when ent.entity_id is not null then
          '' LEFT outer join '' || ent_tab.tables_physical_name || '' ENT_'' ||
          wspmg.wspmg_id || '' on '' || '' ENT_'' || wspmg.wspmg_id ||
          ''.E_INTERNAL_ID =' || v_opp_tab ||
                   '.E'' || ent.entity_id
         else
          null
       end join_clause,
       wspmg.wspmg_id col_present,
       wspmg.wspmg_column_name display_name,
       fld.fld_timeunit
  from (
        select ';

    for i in (select case
                       when ent.entity_id is null then
                        f.fld_column_name
                       else
                        'ENT_' || dwsp.dtwsp_id || '.' || f.fld_column_name
                     end field,
                     case dtwsp_type_id
                       when 1 then
                        'parameter1'
                       when 2 then
                        'weight'
                       when 3 then
                        'distinct_value'
                       when 4 then
                        'lower_bound'
                       when 5 then
                        'upper_bound'
                       when 6 then
                        'importance'
                       when 7 then
                        'enabled'
                     end type,
                     case
                       when ent.entity_id is not null then
                        ' LEFT outer join ' || ent_tab.tables_physical_name ||
                        ' ENT_' || dwsp.dtwsp_id || ' on ' || ' ENT_' ||
                        dwsp.dtwsp_id || '.E_INTERNAL_ID =t.E' ||
                        ent.entity_id
                       else
                        null
                     end join_clause,
                     f.fld_display_as_percent percentage_flag
                from dt_weighted_sum           dws,
                     DT_WEIGHTED_SUM_PARAMETER dwsp,
                     fields                    f,
                     entities                  ent,
                     tables                    ent_tab
               where dws.dtws_dto_id = pi_dto_id
                 and dws.dtws_dto_id = dwsp.dtwsp_dtws_dto_id
                 and dwsp.dtwsp_fld_id = f.fld_id
                 and ent.entity_id(+) = dwsp.dtwsp_entity_id
                 and ent_tab.tables_id(+) = ent.entity_tables_id
               order by dwsp.dtwsp_type_id) loop

      if i.type = 'weight' and i.percentage_flag = 0 then
        v_percentage_flag := 1;
      end if;
      v_param_sql := v_param_sql || i.field || ' ' || i.type || ',';

      if i.join_clause is not null then
        v_join_tab.extend();
        v_join_tab(v_cnt) := i.join_clause;
        v_cnt := v_cnt + 1;
      end if;
    end loop;
    v_param_sql := rtrim(v_param_sql, ',');
    v_param_sql := v_param_sql || ' from ' || v_param_tab || ' t ';
    for j in 1 .. v_join_tab.count loop
      v_param_sql := v_param_sql || v_join_tab(j) || ' ';
    end loop;
    v_param_sql := v_param_sql ||
                   ') param_tab
  left outer join WS_parameter_MAP_GTT wspmg
    on upper(param_tab.parameter1) = upper(wspmg_Column_name)
  left outer join fields fld
    on wspmg.wspmg_fld_id = fld.fld_id
  left outer join entities ent
    on ent.entity_id = wspmg_entity_id
  left outer join tables ent_tab
    on ent_tab.tables_id = ent.entity_tables_id
    where param_tab.enabled = 1
    order by upper(parameter),param_tab.distinct_value ';

    for c in (select tc.tc_physical_name, f.fld_data_type data_type
                from table_columns tc
                left outer join fields f
                  on tc.tc_fld_id = f.fld_id
               where tc.tc_tables_id = pi_in_table
                 and tc.tc_column_type <> 3) loop
      if (c.data_type not in (9, 10) or c.data_type is null) then
        v_col_list := v_col_list || case
                        when c.tc_physical_name not in
                             ('ROW_IDENTIFIER', 'ROW_VERSION') then
                         c.tc_physical_name || ','
                      end;
        v_select_list := v_select_list || case
                           when c.tc_physical_name not in
                                ('ROW_IDENTIFIER', 'ROW_VERSION') then
                            v_opp_tab || '.' || c.tc_physical_name || ','
                         end;
      end if;
    end loop;
/*    commons_utils.insert_logs('v_param_sql : ' || v_param_sql);*/
    v_col_list := v_col_list || v_res_fld_col_name;
    /*commons_utils.insert_logs('v_col_list : '||v_col_list );
    commons_utils.insert_logs('v_select_list : '||v_select_list );*/
    v_join_tab.delete;
    v_cnt      := 1;
    v_main_sql := 'select ' || v_res_tab_seq_name || '.nextval,0,' ||
                  v_result_table || '.* from ( SELECT ' || v_select_list ||
                  'round(';

    open v_cursor for v_param_sql;
    loop

      fetch v_cursor
        into v_parameter_name,
             v_weight,
             v_distinct_value,
             v_lower_bound,
             v_upper_bound,
             v_importance,
             v_data_type,
             v_join_clause,
             v_col_present,
             v_display_name,
             v_fld_tu_id;

      exit when v_cursor%NOTFOUND;
      /*commons_utils.insert_logs('v_parameter_name : '||v_parameter_name);*/
      v_distinct_value := replace(v_distinct_value, '''', '''''');

      if v_percentage_flag = 1 then
        v_weight := v_weight / 100;
      end if;
      v_tab_empty_flag := 1;
      v_tupr_ids_list  := '';
      if v_join_clause is null then
        begin
          select fld_column_name
            into v_parameter
            from fields f
           where upper(f.fld_business_name) = upper(v_parameter_name);
        exception
          when others then
            null;
        end;
      else
        v_parameter := v_parameter_name;
      end if;
      -- check for duplicate distinct value.
      if (v_first_flag = 0 and v_data_type in ('CHAR', 'BOOLEAN') and
         v_prev_parameter = v_parameter) then
        if v_distinct_value = v_prev_distinct_val then
          po_error_code := 17;
          return;
        end if;
      end if;
      if (v_data_type in ('CHAR', 'BOOLEAN')) then
        v_prev_distinct_val := v_distinct_value;
      else
        v_prev_distinct_val := null;
      end if;

      if v_prev_parameter is null or v_prev_parameter <> v_parameter then
        if v_join_clause is not null then
          v_join_tab.extend();
          v_join_tab(v_cnt) := v_join_clause;
          v_cnt := v_cnt + 1;
        end if;
      end if;
      if v_data_type in ('NOTE', 'ATTACHMENT', 'PICTURE') then
        po_error_code     := 3;
        po_parameter_name := v_display_name;
        /*commons_utils.insert_logs('po_error_code : '||po_error_code);*/
        return;
      end if;

      if v_col_present is null then
        po_error_code     := 4;
        po_parameter_name := v_parameter_name;
        /*commons_utils.insert_logs('po_error_code : '||po_error_code);*/
        return;
      end if;

      if v_importance is null then
        po_error_code     := 5;
        po_parameter_name := v_display_name;
        return;
      end if;

      if v_weight is null then
        po_error_code     := 6;
        po_parameter_name := v_display_name;
        return;
      end if;

      if v_data_type in ('CHAR') and v_distinct_value is null then
        po_error_code     := 8;
        po_parameter_name := v_display_name;
        /*commons_utils.insert_logs('Inside distinct check v_error_code : ');*/
        return;
      end if;

      if v_data_type in ('BOOLEAN') and v_distinct_value is null then
        po_error_code     := 9;
        po_parameter_name := v_display_name;
        return;
      end if;

      if v_data_type in ('DATE', 'DATE_TIME', 'NUMERIC', 'PERIOD') and
         (v_lower_bound is null or v_upper_bound is null) then
        po_error_code     := 7;
        po_parameter_name := v_display_name;
        return;
      end if;

      if v_data_type = 'DATE' then
        begin
          v_is_valid_date := regexp_instr(v_lower_bound,
                                          '[0-9]{4,}?-[0-9]{1,2}?-[0-9]{1,2}?');
          v_is_valid_date := v_is_valid_date +
                             regexp_instr(v_upper_bound,
                                          '[0-9]{4,}?-[0-9]{1,2}?-[0-9]{1,2}?');
          if v_is_valid_date < 2 then
            po_error_code     := 13;
            po_parameter_name := v_display_name;
            return;
          end if;
          v_is_valid_date := 0;
          select to_date(v_lower_bound, 'YYYY-MM-DD')
            into v_date_format_check_l
            from dual;
          select to_date(v_upper_bound, 'YYYY-MM-DD')
            into v_date_format_check_u
            from dual;
          if v_date_format_check_l > v_date_format_check_u then
            po_error_code     := 15;
            po_parameter_name := v_display_name;
            return;
          end if;
        exception
          when others then
            po_error_code     := 13;
            po_parameter_name := v_display_name;
            return;
        end;
      end if;

      if v_data_type = 'DATE_TIME' then
        begin
          v_is_valid_date := regexp_instr(v_lower_bound,
                                          '[0-9]{4,}?-[0-9]{1,2}?-[0-9]{1,2}? [0-9]{1,2}?:[0-9]{1,2}?:[0-9]{1,2}?');
          v_is_valid_date := v_is_valid_date +
                             regexp_instr(v_upper_bound,
                                          '[0-9]{4,}?-[0-9]{1,2}?-[0-9]{1,2}? [0-9]{1,2}?:[0-9]{1,2}?:[0-9]{1,2}?');
          if v_is_valid_date < 2 then
            po_error_code     := 13;
            po_parameter_name := v_display_name;
            return;
          end if;
          v_is_valid_date       := 0;
          v_date_format_check_l := to_date(v_lower_bound,
                                           'YYYY-MM-DD HH24:MI:SS');
          v_date_format_check_u := to_date(v_upper_bound,
                                           'YYYY-MM-DD HH24:MI:SS');
          if v_date_format_check_l > v_date_format_check_u then
            po_error_code     := 15;
            po_parameter_name := v_display_name;
            return;
          end if;
        exception
          when others then
            po_error_code     := 13;
            po_parameter_name := v_display_name;
            return;
        end;
      end if;
      if v_data_type = 'NUMERIC' then
        begin
          v_low_num := to_number(v_lower_bound);
          v_up_num  := to_number(v_upper_bound);
        exception
          when others then
            po_error_code     := 16;
            po_parameter_name := v_display_name;
            return;
        end;
        if v_low_num > v_up_num then
          po_error_code     := 15;
          po_parameter_name := v_display_name;
          return;
        end if;
      end if;
      -- checking valididty of period value.
      if v_data_type = 'PERIOD' then
        begin
          select tupr_id, to_char(tupr_start_date, 'YYYY-MM-DD')
            into v_start_tupr, v_period_l_date
            from tu_periods_range
           where tupr_period_range_name_upper = upper(v_lower_bound)
             and tupr_tu_id = v_fld_tu_id;
          select tupr_id, to_char(tupr_end_date, 'YYYY-MM-DD')
            into v_end_tupr, v_period_u_date
            from tu_periods_range
           where tupr_period_range_name_upper = upper(v_upper_bound)
             and tupr_tu_id = v_fld_tu_id;
        exception
          when no_data_found then
            po_error_code     := 14;
            po_parameter_name := v_display_name;
            return;
        end;
        if v_period_l_date > v_period_u_date then
          po_error_code     := 15;
          po_parameter_name := v_display_name;
          return;
        end if;
        v_tupr_ids := commons_timeunits.get_period_range_id_within(v_fld_tu_id,
                                                                   v_start_tupr,
                                                                   v_end_tupr);

        for i in 1 .. v_tupr_ids.count loop
          v_tupr_ids_list := v_tupr_ids_list || to_char(v_tupr_ids(i)) || ',';
        end loop;
        v_tupr_ids_list := rtrim(v_tupr_ids_list, ',');
        /*commons_utils.insert_logs('v_tupr_ids_list : ' || v_tupr_ids_list);*/
      end if;

      if (v_first_flag = 1) then

        v_first_flag := 0;
        --overlap check code start
        if v_data_type in ('DATE', 'DATE_TIME', 'NUMERIC', 'PERIOD') then
          -- preparing the collection to pass to overlap check.
          v_overlap_tab.extend();
          /*commons_utils.insert_logs('v_overlap_counter : '||to_char(v_overlap_counter));*/
          v_overlap_tab(v_overlap_counter).low_bound := case
                                                          when v_data_type =
                                                               'PERIOD' then
                                                           v_period_l_date
                                                          else
                                                           v_lower_bound
                                                        end;
          v_overlap_tab(v_overlap_counter).up_bound := case
                                                         when v_data_type = 'PERIOD' then
                                                          v_period_u_date
                                                         else
                                                          v_upper_bound
                                                       end;
          /*commons_utils.insert_logs(to_char(v_overlap_tab(v_overlap_counter)
                  .low_bound) || ' : ' ||
          to_char(v_overlap_tab(v_overlap_counter)
                  .up_bound));*/

          v_overlap_counter := v_overlap_counter + 1;

        end if;
        --overlap check code end;
        v_total_weight := v_total_weight + v_weight;
        v_main_sql     := v_main_sql || chr(13);
        v_main_sql := v_main_sql || case
                        when v_data_type = 'CHAR' then
                         '(CASE WHEN UPPER(' || v_parameter || ')= UPPER(''' ||
                         v_distinct_value || ''')'
                        when v_data_type = 'BOOLEAN' then
                         '(CASE WHEN ' || v_parameter || ' = ' || case
                           when upper(v_distinct_value) = 'YES' then
                            ' 1 '
                           when upper(v_distinct_value) = 'NO' then
                            ' 0 '
                         end
                        when v_data_type = 'NUMERIC' then
                         '(CASE WHEN ' || v_parameter || ' BETWEEN to_number(' ||
                         v_lower_bound || ') AND to_number(' || v_upper_bound || ')'
                        when v_data_type = 'DATE' then
                         '(CASE WHEN ' || v_parameter || ' BETWEEN to_date(''' ||
                         v_lower_bound || ''',''YYYY-MM-DD'') AND to_date(''' ||
                         v_upper_bound || ''',''YYYY-MM-DD'')'
                        when v_data_type = 'DATE_TIME' then
                         '(CASE WHEN ' || v_parameter || ' BETWEEN to_date(''' ||
                         v_lower_bound ||
                         ''',''YYYY-MM-DD HH24:MI:SS'') AND to_date(''' ||
                         v_upper_bound || ''',''YYYY-MM-DD HH24:MI:SS'')'
                        when v_data_type = 'PERIOD' then
                         '(CASE WHEN ' || v_parameter || ' IN (' ||
                         v_tupr_ids_list || ')'
                      end;
        v_main_sql     := v_main_sql || ' then ' || v_importance;
        v_first_flag   := 0;

      elsif (v_parameter = v_prev_parameter) then
        if v_weight <> v_prev_weight then
          po_error_code     := 12;
          po_parameter_name := v_display_name;
          return;
        end if;
        --overlap check code start
        if v_data_type in ('DATE', 'DATE_TIME', 'NUMERIC', 'PERIOD') then
          /* commons_utils.insert_logs('inside v_parameter = v_prev_parameter');*/
          /*commons_utils.insert_logs('v_overlap_counter : ' ||
          v_overlap_counter);*/
          v_overlap_tab.extend;

          /*commons_utils.insert_logs('v_overlap_counter : '||to_char(v_overlap_counter));*/
          v_overlap_tab(v_overlap_counter).low_bound := case
                                                          when v_data_type =
                                                               'PERIOD' then
                                                           v_period_l_date
                                                          else
                                                           v_lower_bound
                                                        end;
          v_overlap_tab(v_overlap_counter).up_bound := case
                                                         when v_data_type = 'PERIOD' then
                                                          v_period_u_date
                                                         else
                                                          v_upper_bound
                                                       end;
          /*commons_utils.insert_logs(to_char(v_overlap_tab(v_overlap_counter)
                  .low_bound) || ' : ' ||
          to_char(v_overlap_tab(v_overlap_counter)
                  .up_bound));*/
          /*commons_utils.insert_logs(to_char(v_overlap_counter));*/

          v_overlap_counter := v_overlap_counter + 1;
          /*commons_utils.insert_logs('v_overlap_counter : ' ||
          v_overlap_counter);*/
        end if;
        --overlap check code end
        v_main_sql := v_main_sql || chr(13);
        v_main_sql := v_main_sql || case
                        when v_data_type = 'CHAR' then
                         ' WHEN UPPER(' || v_parameter || ')= UPPER(''' ||
                         v_distinct_value || ''')'
                        when v_data_type = 'BOOLEAN' then
                         ' WHEN ' || v_parameter || ' = ' || case
                           when upper(v_distinct_value) = 'YES' then
                            ' 1 '
                           when upper(v_distinct_value) = 'NO' then
                            ' 0 '
                         end
                        when v_data_type = 'NUMERIC' then
                         ' WHEN ' || v_parameter || ' BETWEEN to_number(' ||
                         v_lower_bound || ') AND to_number(' || v_upper_bound || ')'
                        when v_data_type = 'DATE' then
                         ' WHEN ' || v_parameter || ' BETWEEN to_date(''' ||
                         v_lower_bound || ''',''YYYY-MM-DD'') AND to_date(''' ||
                         v_upper_bound || ''',''YYYY-MM-DD'')'
                        when v_data_type = 'DATE_TIME' then
                         ' WHEN ' || v_parameter || ' BETWEEN to_date(''' ||
                         v_lower_bound ||
                         ''',''YYYY-MM-DD HH24:MI:SS'') AND to_date(''' ||
                         v_upper_bound || ''',''YYYY-MM-DD HH24:MI:SS'')'
                        when v_data_type = 'PERIOD' then
                         ' WHEN ' || v_parameter || ' IN (' || v_tupr_ids_list || ')'
                      end;
        v_main_sql := v_main_sql || ' then ' || v_importance;

      elsif (v_parameter <> v_prev_parameter) then
        v_total_weight := v_total_weight + v_weight;
        --overlap check code start
        if v_prev_data_type in ('DATE', 'DATE_TIME', 'NUMERIC', 'PERIOD') then
          /*commons_utils.insert_logs('v_prev_display_name : ' ||
          v_prev_display_name);*/
          v_is_overlap := check_overlap(v_prev_data_type, v_overlap_tab);
          /*commons_utils.insert_logs('v_is_overlap : ' || v_is_overlap);*/
          if v_is_overlap = 1 then
            po_error_code     := 11;
            po_parameter_name := v_prev_display_name;
            return;
          end if;
          v_overlap_tab.delete;
          v_overlap_counter := 1;
          /*commons_utils.insert_logs('v_overlap_counter : ' ||
          v_overlap_counter);*/

        end if;

        if v_data_type in ('DATE', 'DATE_TIME', 'NUMERIC', 'PERIOD') then

          v_overlap_tab.extend;

          v_overlap_tab(v_overlap_counter).low_bound := case
                                                          when v_data_type =
                                                               'PERIOD' then
                                                           v_period_l_date
                                                          else
                                                           v_lower_bound
                                                        end;
          v_overlap_tab(v_overlap_counter).up_bound := case
                                                         when v_data_type = 'PERIOD' then
                                                          v_period_u_date
                                                         else
                                                          v_upper_bound
                                                       end;
          /*commons_utils.insert_logs(to_char(v_overlap_tab(v_overlap_counter)
                  .low_bound) || ' : ' ||
          to_char(v_overlap_tab(v_overlap_counter)
                  .up_bound));*/

          v_overlap_counter := v_overlap_counter + 1;

        end if;

        --overlap check code end
        v_main_sql := v_main_sql || ' ELSE NULL END *' || (v_prev_weight) ||
                      ') + ';
        v_main_sql := v_main_sql || chr(13);
        v_main_sql := v_main_sql || case
                        when v_data_type = 'CHAR' then
                         '(CASE WHEN UPPER(' || v_parameter || ')= UPPER(''' ||
                         v_distinct_value || ''')'
                        when v_data_type = 'BOOLEAN' then
                         '(CASE WHEN ' || v_parameter || ' = ' || case
                           when upper(v_distinct_value) = 'YES' then
                            ' 1 '
                           when upper(v_distinct_value) = 'NO' then
                            ' 0 '
                         end
                        when v_data_type = 'NUMERIC' then
                         '(CASE WHEN ' || v_parameter || ' BETWEEN to_number(' ||
                         v_lower_bound || ') AND to_number(' || v_upper_bound || ')'
                        when v_data_type = 'DATE' then
                         '(CASE WHEN ' || v_parameter || ' BETWEEN to_date(''' ||
                         v_lower_bound || ''',''YYYY-MM-DD'') AND to_date(''' ||
                         v_upper_bound || ''',''YYYY-MM-DD'')'
                        when v_data_type = 'DATE_TIME' then
                         '(CASE WHEN ' || v_parameter || ' BETWEEN to_date(''' ||
                         v_lower_bound ||
                         ''',''YYYY-MM-DD HH24:MI:SS'') AND to_date(''' ||
                         v_upper_bound || ''',''YYYY-MM-DD HH24:MI:SS'')'
                        when v_data_type = 'PERIOD' then
                         '(CASE WHEN ' || v_parameter || ' IN (' ||
                         v_tupr_ids_list || ')'
                      end;
        v_main_sql := v_main_sql || ' then ' || v_importance;
      end if;

      v_prev_parameter    := v_parameter;
      v_prev_weight       := v_weight;
      v_prev_data_type    := v_data_type;
      v_prev_display_name := v_display_name;
    end loop;

    if v_tab_empty_flag = 0 then
      po_error_code := 2;
      return;
    end if;
    if v_total_weight <> 1 then
      /*commons_utils.insert_logs('v_total_weight : ' || v_total_weight);*/
      po_error_code := 10;
      return;
    end if;

    /*commons_utils.insert_logs('went for check' || v_data_type);*/
    if v_prev_data_type in ('DATE', 'DATE_TIME', 'NUMERIC', 'PERIOD') then
      v_is_overlap := check_overlap(v_prev_data_type, v_overlap_tab);
      /*commons_utils.insert_logs('went for check');*/
      if v_is_overlap = 1 then
        po_error_code     := 11;
        po_parameter_name := v_display_name;
        return;
      end if;
    end if;
    v_main_sql := v_main_sql || ' ELSE NULL END *' || (v_weight) || '),' ||
                  v_result_fld_precision || ') ' || v_res_fld_col_name ||
                  ' from ' || v_opp_tab || ' ' || v_opp_tab;
    for j in 1 .. v_join_tab.count loop
      v_main_sql := v_main_sql || v_join_tab(j) || chr(13);
    end loop;
    if pi_ip_join_clause is not null then
      v_main_sql := v_main_sql || ' ' || pi_ip_join_clause || chr(13);
    end if;
    if pi_ip_filter is not null then
      v_main_sql := v_main_sql || ' where ' || pi_ip_filter;
      /*end if;*/
    end if;
    v_main_sql := v_main_sql || ') ' || v_result_table || chr(13);
    if pi_op_join_clause is not null then
      v_main_sql := v_main_sql || pi_op_join_clause;
    end if;
    if pi_op_filter is not null then
      v_main_sql := v_main_sql || ' where ' || pi_op_filter;
    end if;

    v_insert_sql := 'insert into ' || v_result_table ||
                    '(ROW_IDENTIFIER,ROW_VERSION,' || v_col_list || ') ' ||
                    v_main_sql;

    /*commons_utils.insert_logs('v_insert_sql : ' || v_insert_sql);*/
    begin
      execute immediate v_insert_sql;
      po_records_count := SQL%ROWCOUNT;
      /*    commit;*/
      /*      commons_utils.insert_logs('done');*/
      po_error_code := 1;
      /*exception
      when others then

        commons_utils.insert_logs('Problem while inserting');
        commons_utils.insert_logs(sqlerrm);
        raise;*/
    end;
    /*exception
    when others then
      commons_utils.insert_logs(sqlerrm);
      commons_utils.insert_logs(dbms_utility.format_error_backtrace);*/
  end;
end;
/
