CREATE PACKAGE CALCULATE_RUNNING_TOTALS AS

  -- ========================================================
  -- Author     : Ionut Hrubaru
  -- Create date: 20130205
  -- Description: Runs Calculate Running Totals processing
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
/*

      pin_input_table     IN VARCHAR2
       - NOT NULL
       - the input table physical name (ex: 'T1')

      pin_input_table_alias IN VARCHAR2
       - NOT NULL
       - the alias of the input table (ex: 'T_0_0')

      pin_output_table    IN VARCHAR2
        - NOT NULL
        - the output table physical name (ex: 'T2')

      pin_input_columns   IN VARCHAR2
         - NOT NULL
         - the columns to be selected from the input table (except the total columns for each calculation) (ex: 'F1,F2,F3')

      pin_output_columns   IN VARCHAR2
         - NOT NULL
         - the columns from the output in which data is inserted

      pin_calculations    IN TABLETYPE_DT_CRT_CALCULATION
         - NOT NULL
         - an array in which each element is a calculation. Each calculation si composed by the following elements:
             i)   Field_to_Total   - VARCHAR2 - NOT NULL
                                              - the field on which SUM is applied - (ex: 'F7')
             ii)  Result_Field     - TABLETYPE_DT_CHAR - NOT NULL -
                                              - the field in which the field to total is stored (ex: 'F8'), plus the alias for the calculated field (needed in case filtering is applied)
             iii) Grouping_Columns - VARCHAR2 - NULL
                                              - list of columns on which the grouping is done ex('F8,F9')
                                              - NULL in case the running totals are calculated for the whole table (group of records is not checked)
             iv)  Larger_Time_Span - OBJTYPE_DT_MF_ID_NAME_ALIAS - NULL
                                              - contains a time unit id (number) and the field from input to group by, plus the alias for this field
                                              - if the user wants to group by time unit Quarter based on field F10 which is a period field (month), the parameter looks like:
                                                OBJTYPE_ID_NAME(126, 'F10', 'A10')
                                                (126 is the time unit id of Quarter)
                                              - if the selected time unit is Day, then the time unit id is 0 ex: TABLETYPE_ID_NAME(0, 'F10', 'A10')
                                              - if the option is not selected at all then this element is empty (NULL)
             v)   Ordering_Columns - VARCHAR2 - NULL
                                              - list of columns for order.
                                              - each column is followed by the type of ordering ASC/DESC for instance: 'F1 ASC, F2 DESC'
                                              - if treat empty values as zero is checked then for that column a NVL function is used for instance: 'NVL(F1,0) ASC, F2 DESC'
                                              - for character, date fields empty values should be at the beginning when sorted in ascending order, and end when descending: 'F1 ASC NULLS FIRST, F2 DESC NULLS LAST'
                                              - NULLS FIRST/LAST will be used in all cases (for all data types), exception when for numeric fields the check to treat empty values as 0 is checked.
	   pin_output_filters				IN CLOB
		    -	NULL
		    -	filters defined on the output of the operation

       pin_flashback           IN NUMBER
          - NULL
          -	this represents a SCN valid for all tables which will be part of the processing and need read consistency:
			    -	all entity tables part of validations, filtering, matching conditions
			    -	TU_PERIODS_RANGE
			    -	all inputs which are not operation outputs
       pin_period_join				IN CLOB
		    -	NULL
		    -	in case joins are needed for period filtering
       pout_vld_results			OUT SYS_REFCURSOR
          -	NULL
		      -	a cursor returning all values that have not passed the validations
          - it can contain
                   i)  The distinct list of date/date-time values from the input that are not in any period of the time unit to group records by, with each value on a separate row
                   ii) The distinct list of periods from the input that do not correspond to any period of the time unit to group records by, with each value on a separate row

       pout_insert_rowcount OUT NUMBER
          - NULL
          - return  the number of records inserted in the output result table
	*/
   -----------------------------------------------------------------------------------------------
      --    Call statement:

      /*
      declare pout_vld_results sys_refcursor;
              pout_insert_rowcount NUMBER;
      begin
              CALCULATE_RUNNING_TOTALS.RUN_CRT(
                            pin_input_table        => 'T1',
                            pin_input_table_alias  => 'T_0_0'
                            pin_output_table       => 'T2',
                            pin_input_columns      => 'F1, F2, F3',
                            pin_output_columns     => 'F4, F5, F6',
                            pin_calculations       => TABLETYPE_DT_CRT_CALCULATION
                                                   (OBJTYPE_DT_CRT_CALCULATION('F7', TABLETYPE_DT_CHAR('F8', 'A47'), 'F9', OBJTYPE_ID_NAME(126, 'F25'), 'F10 ASC, NVL(F11,0) DESC')
                                                   ,OBJTYPE_DT_CRT_CALCULATION('F45', TABLETYPE_DT_CHAR('F11', 'A45'), NULL, NULL, 'F12 ASC'))
                                                   ,OBJTYPE_DT_CRT_CALCULATION('F45', TABLETYPE_DT_CHAR('F49', 'A46'), NULL, NULL, NULL)),
                            pin_output_filters     => 'WHERE E2303.F6521 = ''employee001'' AND E2328.F4241 = ''territory002'' AND F40.TUPR_START_DATE = A_DATE_CONSTANT AND DTIN123.F26319 > 100',
                            pin_flashback          => 123456789,
                            pout_vld_results       => pout_vld_results,
                            pout_insert_rowcount   => pout_insert_rowcount
                  );
         end

         */
   -----------------------------------------------------------------------------------------------

  -----------------------------------------------------------------------------------------
PROCEDURE RUN_CRT
(  pin_input_view           IN CLOB
  ,pin_input_table          IN VARCHAR2
  ,pin_input_table_alias    IN VARCHAR2
  ,pin_output_table         IN VARCHAR2
  ,pin_input_columns        IN VARCHAR2
  ,pin_output_columns       IN VARCHAR2
  ,pin_calculations         IN TABLETYPE_DT_CRT_CALCULATION
  ,pin_output_filters       IN CLOB
  ,pin_flashback            IN NUMBER
  ,pin_period_join          IN CLOB
  ,pout_vld_results			    OUT SYS_REFCURSOR
  ,pout_insert_rowcount     OUT NUMBER
);


/* GET_TABLE_NAME_BY_ENTITY_ID
-- Author		: Hrubaru, Ionut
-- Create date	: 20130207
-- Reviewer		:
-- Review date	:
-- Description	: return the physical table name for an entity id
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_NAME_BY_ENTITY_ID
(	pin_entity_id IN NUMBER
) RETURN VARCHAR2;

FUNCTION GET_FIELD_TYPE
(	pin_field_name IN VARCHAR2
) RETURN NUMBER;

FUNCTION GET_FIELD_NAME
(	pin_field_name IN VARCHAR2
) RETURN VARCHAR2;

FUNCTION GET_FIELD_TU_ID
(	pin_field_name IN VARCHAR2
) RETURN NUMBER;

FUNCTION GET_FIELD_SCALE
(    pin_field_name IN VARCHAR2
) RETURN NUMBER;

end CALCULATE_RUNNING_TOTALS;
/
