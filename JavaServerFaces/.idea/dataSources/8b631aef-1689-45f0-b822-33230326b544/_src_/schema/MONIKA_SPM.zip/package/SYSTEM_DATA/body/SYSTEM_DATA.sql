CREATE PACKAGE BODY SYSTEM_DATA AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type  : (SPM or CENTRAL)
-- Product    :
-- Module    :
-- Requester    :
-- Author    :  Lazarescu, Bogdan
-- Reviewer    :
-- Review date    :
-- Description    :  provide add functionality for FIELDS
-- ---------------------------------------------------------------------------
    -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
    -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

    -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
    -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

    -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************


PROCEDURE ADD_PREDEFINED_ENTITY(pin_ENTITY_NAME                    VARCHAR2,
                            pin_ENTITY_CATEGORY_TYPE           NUMBER,
                            pin_ENTITY_TABLES_ID               NUMBER,
                            pin_ENTITY_CUSTOM_VERSION          NUMBER,
                            pin_ENTITY_BASE_ENTITY             NUMBER,
                            pin_ENTITY_FOL_ID                  NUMBER) AS
BEGIN

  --1 - rename user entity if it has the same name as the new predefined entity
  EXECUTE IMMEDIATE '
          DECLARE V_CNT NUMBER(10);
          BEGIN
               FOR c in (select ENTITY_NAME as text FROM ENTITIES where UPPER(ENTITY_NAME) = UPPER(''' || pin_ENTITY_NAME || ''') AND ENTITY_IS_PREDEFINED = 0) LOOP
                   FOR i in 1..99 LOOP
                     SELECT (SELECT COUNT(1) FROM ENTITIES WHERE ROWNUM <= 1 AND ENTITY_NAME = SUBSTR(c.text, 1, 30 - (CASE WHEN LENGTH(c.text || i) - 30 < 1 THEN 0 ELSE LENGTH(c.text || i) - 30 END)) || i) into v_cnt FROM DUAL;
                     IF (v_cnt = 0) THEN
                       UPDATE ENTITIES SET ENTITY_NAME = SUBSTR(c.text, 1, 30 - (CASE WHEN LENGTH(c.text || i) - 30 < 1 THEN 0 ELSE LENGTH(c.text || i) - 30 END)) || i WHERE ENTITY_NAME = c.text;
                     END IF;
                     EXIT WHEN v_cnt = 0;
                   END LOOP;
               END LOOP;
           END;
  ' ;

  --2 - raise error if the predefined entity already exists
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (select 1 FROM ENTITIES where UPPER(ENTITY_NAME) = UPPER(''' || pin_ENTITY_NAME || ''') AND ENTITY_IS_PREDEFINED = 1) LOOP
            raise_application_error(-20001, ''A system entity <<' ||
                    pin_ENTITY_NAME || '>> already exists. Cannot add the new entity.'');
          END LOOP;
          END;
  ' ;


  --3 - add new predefined entity if there is no old entity with the same name
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ENTITIES WHERE UPPER(ENTITY_NAME) = UPPER(''' || pin_ENTITY_NAME || '''))) LOOP
            INSERT INTO ENTITIES(ENTITY_ID,ENTITY_NAME,ENTITY_CATEGORY_TYPE,ENTITY_IS_PREDEFINED,ENTITY_TABLES_ID,OBJECT_VERSION,ENTITY_CUSTOM_VERSION,ENTITY_BASE_ENTITY,ENTITY_FOL_ID)
            VALUES (UID_Sequence.nextval,
                    :ENTITY_NAME,
                    :ENTITY_CATEGORY_TYPE,
                    1,
                    :ENTITY_TABLES_ID,
					0,
                    :ENTITY_CUSTOM_VERSION,
                    :ENTITY_BASE_ENTITY,
                    :ENTITY_FOL_ID);
          END LOOP;
          END;'
          using pin_ENTITY_NAME,pin_ENTITY_CATEGORY_TYPE,pin_ENTITY_TABLES_ID,pin_ENTITY_CUSTOM_VERSION,pin_ENTITY_BASE_ENTITY,pin_ENTITY_FOL_ID;

END ADD_PREDEFINED_ENTITY;


FUNCTION REGISTER_EXISTING_OBJECT
(  pi_TABLE_NAME             IN VARCHAR2,
  pi_ID_COLUMN              IN VARCHAR2,
  pi_NAME_COLUMN            IN VARCHAR2,
  pi_DEFINITION_TYPE_ID     IN NUMBER DEFAULT NULL,
  pi_DEFINITION_TYPE_COLUMN IN VARCHAR2 DEFAULT NULL,
  pi_CONTAINER_ID_COLUMN    IN varchar2 default NULL
) RETURN VARCHAR2
AS
  v_sql    CLOB;
  v_footer  CLOB;
BEGIN
  IF (pi_TABLE_NAME IS NULL
    OR pi_ID_COLUMN IS NULL
    OR pi_NAME_COLUMN IS NULL
    OR (  pi_DEFINITION_TYPE_ID IS NULL
      AND pi_DEFINITION_TYPE_COLUMN IS NULL))
  THEN
    RAISE_APPLICATION_ERROR
      (  -20000,
        'pi_TABLE_NAME , pi_ID_COLUMN or pi_NAME_COLUMN or  ( pi_DEFINITION_TYPE_ID AND pi_DEFINITION_TYPE_COLUMN ) cannot be null '
      );
  END IF;

  IF (UPPER(pi_TABLE_NAME) = 'TABLES')
  THEN
    v_footer := '
    WHERE TABLES_DEFINITION_ID IS NULL';
  END IF;

  v_sql := '
  INSERT INTO OBJECT_REGISTRATION (OR_ID,OR_NAME,OR_TYPE,OR_CONTAINER_ID)
  SELECT   ' || pi_ID_COLUMN || '
      ,' || pi_NAME_COLUMN || '
      ,' || NVL(pi_DEFINITION_TYPE_COLUMN, TO_CHAR(pi_DEFINITION_TYPE_ID)) || '
      ,' || NVL(pi_CONTAINER_ID_COLUMN, 'NULL') || '
  FROM ' || pi_TABLE_NAME
  || v_footer;

  RETURN v_sql;
END REGISTER_EXISTING_OBJECT;


FUNCTION REGISTRATION_INSERT_TRIGGER
(  pi_TRIGGER_NAME           IN VARCHAR2,
  pi_TABLE_NAME             IN VARCHAR2,
  pi_ID_COLUMN              IN VARCHAR2,
  pi_NAME_COLUMN            IN VARCHAR2,
  pi_DEFINITION_TYPE_ID     IN NUMBER DEFAULT NULL,
  pi_DEFINITION_TYPE_COLUMN IN VARCHAR2 DEFAULT NULL,
  pi_CONTAINER_ID_COLUMN    IN varchar2 default NULL
) RETURN VARCHAR2
AS
  v_header  CLOB;
  v_footer  CLOB;
  v_sql    CLOB;
BEGIN
  IF (pi_TABLE_NAME is NULL
    OR pi_ID_COLUMN is NULL
    OR pi_NAME_COLUMN is NULL
    OR (  pi_DEFINITION_TYPE_ID is NULL
      AND pi_DEFINITION_TYPE_COLUMN IS NULL))
  THEN
    RAISE_APPLICATION_ERROR
      (   -20000
        ,'pi_TABLE_NAME , pi_ID_COLUMN or pi_NAME_COLUMN or  ( pi_DEFINITION_TYPE_ID AND pi_DEFINITION_TYPE_COLUMN ) cannot be null '
      );
  END IF;

  IF (UPPER(pi_TABLE_NAME) = 'TABLES')
  THEN
    v_header := '
    IF (:new.TABLES_DEFINITION_ID IS NULL)
    THEN';
    v_footer := '
    END IF;';
  END IF;

  v_sql := '
  CREATE OR REPLACE TRIGGER ' || pi_TRIGGER_NAME || '
  AFTER INSERT ON ' || pi_TABLE_NAME || ' FOR EACH ROW
  BEGIN'
    || v_header
    || '
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.' || pi_ID_COLUMN || ',
      pi_or_name => :new.' || pi_NAME_COLUMN || ',
      pi_or_type => ' || CASE WHEN pi_DEFINITION_TYPE_COLUMN IS NULL THEN TO_CHAR(pi_DEFINITION_TYPE_ID) ELSE ':new.' || pi_DEFINITION_TYPE_COLUMN END || ',
	  pi_or_container_id => ' || CASE WHEN pi_CONTAINER_ID_COLUMN IS NULL THEN 'NULL' ELSE ':new.' || pi_CONTAINER_ID_COLUMN END || ');'
    || v_footer
    || '
  END;';

  RETURN v_sql;
END REGISTRATION_INSERT_TRIGGER;


FUNCTION REGISTRATION_UPDATE_TRIGGER(pi_TRIGGER_NAME IN varchar2,
                                     pi_TABLE_NAME   IN varchar2,
                                     pi_ID_COLUMN    IN varchar2,
                                     pi_NAME_COLUMN  IN varchar2,
									 pi_CONTAINER_ID_COLUMN    IN varchar2 default NULL)
  return varchar2 as

BEGIN
  if (pi_TRIGGER_NAME is null or pi_TABLE_NAME is null or
     pi_ID_COLUMN is null or pi_NAME_COLUMN is null) then

    raise_application_error(-20000,
                            'pi_TRIGGER_NAME , pi_TABLE_NAME , pi_ID_COLUMN or pi_NAME_COLUMN cannot be null ');

  end if;
  RETURN '
CREATE OR REPLACE TRIGGER ' || pi_TRIGGER_NAME || '  AFTER UPDATE
	OF ' || pi_NAME_COLUMN || CASE WHEN pi_CONTAINER_ID_COLUMN IS NOT NULL THEN ',' || pi_CONTAINER_ID_COLUMN ELSE NULL END ||'
    ON ' || pi_TABLE_NAME || ' FOR EACH ROW
BEGIN
	SYSTEM_DATA.MODIFY_REGISTRATION
	(	pi_or_id => :new.' || pi_ID_COLUMN || ',
        pi_or_name => :new.' || pi_NAME_COLUMN || ',
        pi_or_container_id => ' || CASE WHEN pi_CONTAINER_ID_COLUMN IS NULL THEN 'NULL' ELSE ':new.' || pi_CONTAINER_ID_COLUMN END || ');
END ;';

END;

FUNCTION REGISTRATION_DELETE_TRIGGER(pi_TRIGGER_NAME IN varchar2,
                                     pi_TABLE_NAME   IN varchar2,
                                     pi_ID_COLUMN    IN varchar2)
  return varchar2 as

BEGIN
  if (pi_TRIGGER_NAME is null or pi_TABLE_NAME is null or
     pi_ID_COLUMN is null) then

    raise_application_error(-20000,
                            'pi_TRIGGER_NAME , pi_TABLE_NAME , pi_ID_COLUMN cannot be null ');

  end if;
  RETURN '
CREATE OR REPLACE TRIGGER ' || pi_TRIGGER_NAME || '  BEFORE DELETE
      ON ' || pi_TABLE_NAME || ' FOR EACH ROW
BEGIN
	SYSTEM_DATA.DEREGISTER_OBJECT(pi_or_id => :old.' || pi_ID_COLUMN || ');
END ;';

END;


procedure REGISTER_OBJECT(PI_OR_ID   NUMBER,
                            PI_OR_NAME VARCHAR2,
                            PI_OR_TYPE NUMBER,
							PI_OR_CONTAINER_ID NUMBER DEFAULT NULL) AS

 v_sql varchar(32767);

  BEGIN

     if PI_OR_ID is null  then

      raise_application_error(-20000,
                              'PI_OR_ID cannot be null ');

     elsif PI_OR_NAME is null then

       raise_application_error(-20000,
                              'PI_OR_NAME  cannot be null ');

     elsif PI_OR_TYPE is null then

        raise_application_error(-20000,
                              'PI_OR_TYPE  cannot be null ');

    end if;

  /*  dbms_output.put_line('insert into Object_registration (OR_ID,OR_NAME,OR_TYPE) values(' ||
                         PI_OR_ID || ' , ''' || PI_OR_NAME || ''' , ' ||
                         PI_OR_TYPE || ' )');
*/
  /*  execute immediate 'insert into Object_registration (OR_ID,OR_NAME,OR_TYPE) values(' ||
                      PI_OR_ID || ' , ''' || PI_OR_NAME || ''' , ' ||
                      PI_OR_TYPE || ' )';*/

      v_sql:= 'insert into Object_registration (OR_ID,OR_NAME,OR_TYPE, OR_CONTAINER_ID)
       values (:1 ,:2 , :3, :4)';

           execute immediate v_sql using PI_OR_ID,PI_OR_NAME,PI_OR_TYPE,PI_OR_CONTAINER_ID;

  END;



  procedure DEREGISTER_OBJECT(PI_OR_ID NUMBER) AS
  v_sql varchar(32767);
  BEGIN
    if (PI_OR_ID is null) then

      raise_application_error(-20000, 'PI_OR_ID  cannot be null ');

    end if;
    v_sql:='DELETE FROM Object_registration WHERE OR_ID=:1';

    execute immediate v_sql using PI_OR_ID;

  end;

  procedure MODIFY_REGISTRATION(PI_OR_ID NUMBER,
  								PI_OR_NAME VARCHAR2,
								PI_OR_CONTAINER_ID NUMBER DEFAULT NULL) AS
   v_sql varchar(32767);
  BEGIN
    if (PI_OR_ID is null or PI_OR_NAME is null) then

      raise_application_error(-20000,
                              'PI_OR_ID or PI_OR_NAME cannot be null ');

    end if;

    v_sql:='update Object_registration set  OR_NAME = :1, OR_CONTAINER_ID = :2 where OR_ID = :3';

    execute immediate v_sql using PI_OR_NAME,PI_OR_CONTAINER_ID,PI_OR_ID;

  end;

    -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END SYSTEM_DATA;
/
