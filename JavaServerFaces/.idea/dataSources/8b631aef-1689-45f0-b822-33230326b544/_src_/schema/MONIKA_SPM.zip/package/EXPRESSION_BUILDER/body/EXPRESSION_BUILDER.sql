CREATE package body EXPRESSION_BUILDER is
  -- --------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------
--  ========= PRIVATE METHODS ================================================================


--  ========= PUBLIC METHODS ================================================================

  function SYNYGY_PERIOD_NUMBER(pin_Date date, pin_TimeUnit number, pin_Date_Time number) return number is
    v_period_number number;
  begin
    if (pin_Date is null) then
		return null;
	else
		select tupr_period_number into v_period_number from tu_periods_range where tupr_tu_id = pin_TimeUnit and TRUNC(pin_Date) between tupr_start_date and tupr_end_date;
		return v_period_number;
	end if;
  exception
    when NO_DATA_FOUND then
			if (pin_Date_Time = 1) THEN
				RAISE_APPLICATION_ERROR(-20002, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_Date, 'YYYY-MM-DD HH24:MI:SS'));
			else
				RAISE_APPLICATION_ERROR(-20002, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_Date, 'YYYY-MM-DD'));
			end if;
  end;
--
--
  function SYNYGY_PERIOD_YEAR(pin_Date date, pin_TimeUnit number, pin_Date_Time number) return number is
    v_period_year number;
  begin
    if (pin_Date is null) then
		return null;
	else
		select tupr_year into v_period_year from tu_periods_range where tupr_tu_id = pin_TimeUnit and TRUNC(pin_Date) between tupr_start_date and tupr_end_date;
		return v_period_year;
	end if;
  exception
    when NO_DATA_FOUND then
			if (pin_Date_Time = 1) THEN
				RAISE_APPLICATION_ERROR(-20002, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_Date, 'YYYY-MM-DD HH24:MI:SS'));
			else
				RAISE_APPLICATION_ERROR(-20002, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_Date, 'YYYY-MM-DD'));
			end if;
  end;
--
--
  function SYNYGY_RIGHT(pin_string varchar2, pin_length number) return varchar2 is
  begin
    if pin_length >= length(pin_string) THEN
      return pin_string;
    end if;
    return SUBSTR(pin_string, length(pin_string) - trunc(pin_length) + 1, trunc(pin_length));
  end;
--
--
  function SYNYGY_PERIOD_VALUE(pin_Date date, pin_TimeUnit number, pin_Date_Time number) return number is
    v_period_value NUMBER;
    v_stamp        VARCHAR2(250 CHAR);
  begin

    if (pin_Date is null) then
		return null;
	else
		select tupr_id into v_period_value from tu_periods_range where tupr_tu_id = pin_TimeUnit and TRUNC(pin_Date) between tupr_start_date and tupr_end_date;

    return v_period_value;
	end if;
  exception
    when NO_DATA_FOUND then
			if (pin_Date_Time = 1) THEN
				RAISE_APPLICATION_ERROR(-20002, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_Date, 'YYYY-MM-DD HH24:MI:SS'));
			else
				RAISE_APPLICATION_ERROR(-20002, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_Date, 'YYYY-MM-DD'));
			end if;
  end;
--
--
  function SYNYGY_PERIOD(pin_TimeUnit number, pin_PeriodNumber number, pin_year number) return number is
    v_period_value NUMBER;
  begin
    if (pin_PeriodNumber is null or pin_year is null) then
        return null;
    else
      select tupr_id into v_period_value from tu_periods_range where tupr_tu_id = pin_TimeUnit and tupr_period_number = TRUNC(pin_PeriodNumber) and tupr_year = TRUNC(pin_year);
      return v_period_value;
    end if;
  exception
    when NO_DATA_FOUND then
	       RAISE_APPLICATION_ERROR(-20003, ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_TimeUnit) || ',' || to_char(pin_PeriodNumber) || ',' || to_char(pin_year));
  end;
--
--
  function ADD_PERIOD(pin_period_id number, pin_periods_to_add number) return number
  as
    v_return number;
  begin
    if (pin_period_id IS NULL) then
      return NULL;
    else
      with a as
       (select tupr_id, RANK() OVER(ORDER BY tupr_start_Date) as "PERIOD_RANK"
          from tu_periods_range tupr
         where tupr.tupr_tu_id =
               (select tupr_tu_id from tu_periods_range where tupr_id = pin_period_id))
      select tupr_id
      into v_return
        from a
       where PERIOD_RANK =
             (select PERIOD_RANK from a where tupr_id = pin_period_id) + NVL(TRUNC(pin_periods_to_add), 0);
     --
     return v_return;
    end if;
  exception
    when NO_DATA_FOUND then
	       RAISE_APPLICATION_ERROR(-20004, ',' || pin_periods_to_add || ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_PERIOD(pin_period_id) || ',after,' || commons_timeunits.GET_PERIOD_NAME_FROM_ID(pin_period_id));
  end;
--
--
  function SUBSTRACT_PERIOD(pin_period_id number, pin_periods_to_substract number) return number
  as
    v_return number;
  begin
    if (pin_period_id IS NULL) then
      return NULL;
    else
      with a as
       (select tupr_id, RANK() OVER(ORDER BY tupr_start_Date) as "PERIOD_RANK"
          from tu_periods_range tupr
         where tupr.tupr_tu_id =
               (select tupr_tu_id from tu_periods_range where tupr_id = pin_period_id))
      select tupr_id
      into v_return
        from a
       where PERIOD_RANK =
             (select PERIOD_RANK from a where tupr_id = pin_period_id) - NVL(TRUNC(pin_periods_to_substract), 0);
     --
     return v_return;
    end if;
  exception
    when NO_DATA_FOUND then
	       RAISE_APPLICATION_ERROR(-20004, ',' || pin_periods_to_substract || ',' || commons_timeunits.GET_TIME_UNIT_NAME_FROM_PERIOD(pin_period_id) || ',before,' || commons_timeunits.GET_PERIOD_NAME_FROM_ID(pin_period_id));
  end;
--
--
  function CORRESPONDING_PERIOD(pin_period_id number,
                                pin_time_unit_id number)
  return number
  as
    v_return number;
	v_tu_id NUMBER;
  BEGIN
	IF (pin_period_id IS NULL)
	THEN
		RETURN NULL;
	ELSE
		SELECT TUPR_TU_ID INTO v_tu_id
		FROM TU_PERIODS_RANGE WHERE TUPR_ID = pin_period_id;

		IF (pin_time_unit_id = v_tu_id)
		THEN
			RETURN pin_period_id;
		ELSE
			v_return := COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER(   pi_small_period_id => pin_period_id
																			,pi_large_corr_tu_id => pin_time_unit_id);
			RETURN v_return;
		END IF;
	END IF;
  END;

--
--

  function PERIOD_NUMBER_FOR_PERIOD(pin_period_id number)
  return number
  as
    V_PERIOD_NUMBER number(3);
  begin
    IF (pin_period_id IS NULL) THEN
      RETURN NULL;
    ELSE
      SELECT TUPR.TUPR_PERIOD_NUMBER
      INTO V_PERIOD_NUMBER
      FROM TU_PERIODS_RANGE TUPR
      WHERE TUPR.TUPR_ID = pin_period_id;
      --
      RETURN V_PERIOD_NUMBER;
    END IF;
  end;

--
--

  function PERIOD_YEAR_FOR_PERIOD(pin_period_id number)
  return number
  as
    V_PERIOD_NUMBER number(4);
  begin
    IF (pin_period_id IS NULL) THEN
      RETURN NULL;
    ELSE
      SELECT TUPR.TUPR_YEAR
      INTO V_PERIOD_NUMBER
      FROM TU_PERIODS_RANGE TUPR
      WHERE TUPR.TUPR_ID = pin_period_id;
      --
      RETURN V_PERIOD_NUMBER;
    END IF;
  end;

--
--

  FUNCTION PERIOD_NAME_FOR_PERIOD(pin_period_id NUMBER)
    RETURN VARCHAR2
    AS
      v_period_name VARCHAR2(30 CHAR);
    BEGIN
      IF (pin_period_id IS NULL) THEN
        RETURN NULL;
      ELSE
        SELECT tup.tup_name
          INTO v_period_name
          FROM tu_periods_range tupr
         INNER JOIN tu_periods tup
            ON tupr.tupr_tup_id = tup.tup_id
         WHERE tupr.tupr_id = pin_period_id;

        RETURN v_period_name;
      END IF;
    END PERIOD_NAME_FOR_PERIOD;

--
--

  function LAST_PERIOD_IN_TABLE(pin_period_column VARCHAR2, pin_table_name VARCHAR2)
  return number
  as
    V_LAST_PERIOD NUMBER;
  begin
    EXECUTE IMMEDIATE
    'WITH TUPR AS
     (SELECT TUPR_ID, TUPR_START_DATE
        FROM TU_PERIODS_RANGE TUPR
       INNER JOIN ' || pin_table_name ||
         ' ON TUPR.TUPR_ID = ' || pin_period_column || ')
    SELECT DISTINCT TUPR.TUPR_ID
      FROM TUPR
     WHERE TUPR.TUPR_START_DATE =
           (SELECT MAX(TUPR.TUPR_START_DATE) FROM TUPR)'
      INTO V_LAST_PERIOD;
    RETURN V_LAST_PERIOD;
  exception
    WHEN NO_DATA_FOUND
      THEN RETURN NULL;
  end;

--
--

  function FIRST_PERIOD_IN_TABLE(pin_period_column VARCHAR2, pin_table_name VARCHAR2)
  return number
  as
    V_FIRST_PERIOD NUMBER;
  begin
    EXECUTE IMMEDIATE
    'WITH TUPR AS
     (SELECT TUPR_ID, TUPR_START_DATE
        FROM TU_PERIODS_RANGE TUPR
       INNER JOIN ' || pin_table_name ||
         ' ON TUPR.TUPR_ID = ' || pin_period_column || ')
    SELECT DISTINCT TUPR.TUPR_ID
      FROM TUPR
     WHERE TUPR.TUPR_START_DATE =
           (SELECT MIN(TUPR.TUPR_START_DATE) FROM TUPR)'
      INTO V_FIRST_PERIOD;
    RETURN V_FIRST_PERIOD;
  exception
    WHEN NO_DATA_FOUND
      THEN RETURN NULL;
  end;

--
--

  function MAX_PERIOD(pin_period_ids TABLETYPE_NUMBER)
  return number
  as
    V_MAX_PERIOD NUMBER;
  begin
    WITH TUPR AS
     (SELECT TUPR_ID, TUPR_START_DATE
        FROM TU_PERIODS_RANGE TUPR
       INNER JOIN TABLE(pin_period_ids)
          ON TUPR.TUPR_ID = COLUMN_VALUE)
    SELECT DISTINCT TUPR.TUPR_ID
      INTO V_MAX_PERIOD
      FROM TUPR
     WHERE TUPR.TUPR_START_DATE =
           (SELECT MAX(TUPR.TUPR_START_DATE) FROM TUPR);
    RETURN V_MAX_PERIOD;
  exception
    WHEN NO_DATA_FOUND
      THEN RETURN NULL;
  end;

--
--

  function MIN_PERIOD(pin_period_ids TABLETYPE_NUMBER)
  return number
  as
    V_MIN_PERIOD NUMBER;
  begin
    WITH TUPR AS
     (SELECT TUPR_ID, TUPR_START_DATE
        FROM TU_PERIODS_RANGE TUPR
       INNER JOIN TABLE(pin_period_ids)
          ON TUPR.TUPR_ID = COLUMN_VALUE)
    SELECT DISTINCT TUPR.TUPR_ID
      INTO V_MIN_PERIOD
      FROM TUPR
     WHERE TUPR.TUPR_START_DATE =
           (SELECT MIN(TUPR.TUPR_START_DATE) FROM TUPR);
    RETURN V_MIN_PERIOD;
  exception
    WHEN NO_DATA_FOUND
      THEN RETURN NULL;
  end;

--
--

  function PERIOD_IN(pin_period_id NUMBER, pin_period_ids TABLETYPE_NUMBER)
  return number
  as
    V_EXISTS NUMBER(1);
  begin
    if (pin_period_id IS NULL) then
       select 1
         into V_EXISTS
         from dual
        where exists (select 1
                 from TABLE(pin_period_ids)
                where COLUMN_VALUE is null);
       RETURN 1;
    else
       select 1
         into V_EXISTS
         from dual
        where exists (select 1
                 from TABLE(pin_period_ids)
                where COLUMN_VALUE = pin_period_id);
       RETURN 1;
    end if;
       exception
         when NO_DATA_FOUND
           then return 0;
  end;

--
--

  function PERIOD_NOT_IN(pin_period_id NUMBER, pin_period_ids TABLETYPE_NUMBER)
  return number
  as
    V_EXISTS NUMBER(1);
  begin
    if (pin_period_id IS NULL) then
       select 0
         into V_EXISTS
         from dual
        where exists (select 0
                 from TABLE(pin_period_ids)
                where COLUMN_VALUE is null);
       RETURN 0;
    else
       select 0
         into V_EXISTS
         from dual
        where exists (select 0
                 from TABLE(pin_period_ids)
                where COLUMN_VALUE = pin_period_id);
       RETURN 0;
    end if;
       exception
         when NO_DATA_FOUND
           then return 1;
  end;

/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.27 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION FIRST_DAY_OF_PERIOD
(	pi_period_id	NUMBER
) RETURN DATE
AS
	v_start_date	DATE;
	v_end_date		DATE;
BEGIN
	COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
	(	 pi_tupr_id		=> pi_period_id
		,po_start_date	=> v_start_date
		,po_end_date	=> v_end_date);

	RETURN v_start_date;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.27 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION LAST_DAY_OF_PERIOD
(	pi_period_id	NUMBER
) RETURN DATE
AS
	v_start_date	DATE;
	v_end_date		DATE;
BEGIN
	COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
	(	 pi_tupr_id		=> pi_period_id
		,po_start_date	=> v_start_date
		,po_end_date	=> v_end_date);

	RETURN v_end_date;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION EQUALS_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_period_start_date	DATE;
	v_period_end_date	DATE;
BEGIN
	-- a NULL date is only equal to a NULL period when they are both start/end eff dating values
	IF	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
		AND (	(pi_lv_eff_option = 3 AND pi_rv_eff_option = 6)
			OR	(pi_lv_eff_option = 4 AND pi_rv_eff_option = 7)))
	THEN
		v_result := 1;

	-- a NOT NULL date is equal to a NOT NULL period when date is between start date and end date of that period
	ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
	THEN
		BEGIN
			SELECT TUPR_START_DATE, TUPR_END_DATE
			INTO v_period_start_date, v_period_end_date
			FROM TU_PERIODS_RANGE
			WHERE TUPR_ID = pi_right_period_value;
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			NULL;
		END;

		IF (TRUNC(pi_left_value) BETWEEN v_period_start_date AND v_period_end_date)
		THEN
			v_result := 1;
		END IF;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION EQUALS_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
BEGIN
	-- if period = date
	IF (pi_right_period_tu_id IS NULL)
	THEN
		v_result := EXPRESSION_BUILDER.EQUALS_DATE_VS_OTHER
			(pi_left_value				=> pi_right_date_value
			,pi_lv_eff_option			=> pi_rv_eff_option
			,pi_right_period_value		=> pi_left_value
			,pi_right_period_tu_id		=> pi_left_period_tu_id
			,pi_rv_eff_option			=> pi_lv_eff_option);

	-- if period = period
	ELSE
		-- a NULL regular/single eff value = a NULL regular/single eff value, when timeunit is the same
		-- a NULL start eff value = a NULL start eff value, regardless of type/timeunit
		-- a NULL end eff value = a NULL end eff value, regardless of type/timeunit
		IF	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
			AND (	(pi_lv_eff_option IN (0, 1, 2, 5, 8) AND pi_rv_eff_option IN (0, 1, 2, 5, 8) AND pi_left_period_tu_id = pi_right_period_tu_id)
				OR	(pi_lv_eff_option IN (6, 7) AND pi_rv_eff_option = pi_lv_eff_option)))
		THEN
			v_result := 1;

		-- if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
		THEN
			v_result := CASE	WHEN pi_tu_correspondence = 1 AND pi_left_value = pi_right_period_value THEN 1
								WHEN pi_tu_correspondence = 2 AND COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																		(pi_small_period_id		=> pi_left_value
																		,pi_large_corr_tu_id	=> pi_right_period_tu_id) = pi_right_period_value THEN 1
								WHEN pi_tu_correspondence = 3 AND COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																		(pi_small_period_id		=> pi_right_period_value
																		,pi_large_corr_tu_id	=> pi_left_period_tu_id) = pi_left_value THEN 1
								ELSE 0 END;
		END IF;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION NOT_EQUALS_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER;
	v_equals			NUMBER;
BEGIN
	v_equals := EXPRESSION_BUILDER.EQUALS_DATE_VS_OTHER
					(pi_left_value			=> pi_left_value
					,pi_lv_eff_option		=> pi_lv_eff_option
					,pi_right_period_value	=> pi_right_period_value
					,pi_right_period_tu_id	=> pi_right_period_tu_id
					,pi_rv_eff_option		=> pi_rv_eff_option);

	v_result := CASE WHEN v_equals = 1 THEN 0 ELSE 1 END;
	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION NOT_EQUALS_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER;
	v_equals			NUMBER;
BEGIN
	v_equals := EXPRESSION_BUILDER.EQUALS_PERIOD_VS_OTHER
					(pi_left_value			=> pi_left_value
					,pi_left_period_tu_id	=> pi_left_period_tu_id
					,pi_lv_eff_option		=> pi_lv_eff_option
					,pi_right_date_value	=> pi_right_date_value
					,pi_right_period_value	=> pi_right_period_value
					,pi_right_period_tu_id	=> pi_right_period_tu_id
					,pi_tu_correspondence	=> pi_tu_correspondence
					,pi_rv_eff_option		=> pi_rv_eff_option);

	v_result := CASE WHEN v_equals = 1 THEN 0 ELSE 1 END;
	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GREATER_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_per_start_date	DATE;
	v_per_end_date		DATE;
BEGIN
	-- a NULL end eff value > a NULL start eff value
	-- a NULL end eff value > any NOT NULL value
	-- any NOT NULL value > a NULL start eff value
	IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
			AND	(pi_lv_eff_option = 4 AND pi_rv_eff_option = 6))
		OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
			AND	pi_lv_eff_option = 4)
		OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
			AND	pi_rv_eff_option = 6))
	THEN
		v_result := 1;

	-- if both values are NOT NULL
	ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
	THEN
		COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
		(	 pi_tupr_id		=> pi_right_period_value
			,po_start_date	=> v_per_start_date
			,po_end_date	=> v_per_end_date);

		v_result := CASE WHEN TRUNC(pi_left_value) > v_per_end_date THEN 1 ELSE 0 END;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GREATER_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_l_per_start_date	DATE;
	v_l_per_end_date	DATE;
	v_r_per_start_date	DATE;
	v_r_per_end_date	DATE;
BEGIN
	-- if period > date
	IF (pi_right_period_tu_id IS NULL)
	THEN
		-- a NULL end eff value > a NULL start eff value
		-- a NULL end eff value > any NOT NULL value
		-- any NOT NULL value > a NULL start eff value
		IF (	(	(pi_left_value IS NULL AND pi_right_date_value IS NULL)
				AND	(pi_lv_eff_option = 7 AND pi_rv_eff_option = 3))
			OR	(	(pi_left_value IS NULL AND pi_right_date_value IS NOT NULL)
				AND	pi_lv_eff_option = 7)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_date_value IS NULL)
				AND	pi_rv_eff_option = 3))
		THEN
			v_result := 1;

		-- if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_date_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> pi_left_value
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			v_result := CASE WHEN v_l_per_start_date > TRUNC(pi_right_date_value) THEN 1 ELSE 0 END;
		END IF;

	-- if period > period
	ELSE
		-- a NULL end eff value > a NULL start eff value, regardless of type/timeunit
		-- a NULL end eff value > any NOT NULL value, regardless of type/timeunit
		-- any NOT NULL value > a NULL start eff value, regardless of type/timeunit
		IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
				AND	(pi_lv_eff_option = 7 AND pi_rv_eff_option = 6))
			OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
				AND	pi_lv_eff_option = 7)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
				AND	pi_rv_eff_option = 6))
		THEN
			v_result := 1;

		-- if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 2 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_left_value
																				,pi_large_corr_tu_id	=> pi_right_period_tu_id)
										ELSE pi_left_value END
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 3 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_right_period_value
																				,pi_large_corr_tu_id	=> pi_left_period_tu_id)
										ELSE pi_right_period_value END
				,po_start_date	=> v_r_per_start_date
				,po_end_date	=> v_r_per_end_date);

			v_result := CASE WHEN v_l_per_start_date > v_r_per_start_date THEN 1 ELSE 0 END;
		END IF;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GREATER_EQ_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_per_start_date	DATE;
	v_per_end_date		DATE;
BEGIN
	-- a NULL start eff value >= a NULL start eff value
	-- a NULL end eff value >= a NULL start/end eff value
	-- a NULL end eff value >= any NOT NULL value
	-- any NOT NULL value >= a NULL start eff value
	IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
			AND	(	(pi_lv_eff_option = 3 AND pi_rv_eff_option = 6)
				OR	(pi_lv_eff_option = 4 AND pi_rv_eff_option IN (6, 7))))
		OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
			AND	pi_lv_eff_option = 4)
		OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
			AND	pi_rv_eff_option = 6))
	THEN
		v_result := 1;

	-- else if both values are NOT NULL
	ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
	THEN
		COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
		(	 pi_tupr_id		=> pi_right_period_value
			,po_start_date	=> v_per_start_date
			,po_end_date	=> v_per_end_date);

		v_result := CASE WHEN TRUNC(pi_left_value) >= v_per_start_date THEN 1 ELSE 0 END;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GREATER_EQ_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_l_per_start_date	DATE;
	v_l_per_end_date	DATE;
	v_r_per_start_date	DATE;
	v_r_per_end_date	DATE;
BEGIN
	-- period >= date
	IF (pi_right_period_tu_id IS NULL)
	THEN
		-- a NULL start eff value >= a NULL start eff value
		-- a NULL end eff value >= a NULL start/end eff value
		-- a NULL end eff value >= any NOT NULL value
		-- any NOT NULL value >= a NULL start eff value
		IF (	(	(pi_left_value IS NULL AND pi_right_date_value IS NULL)
				AND	(	(pi_lv_eff_option = 6 AND pi_rv_eff_option = 3)
					OR	(pi_lv_eff_option = 7 AND pi_rv_eff_option IN (3, 4))))
			OR	(	(pi_left_value IS NULL AND pi_right_date_value IS NOT NULL)
				AND	pi_lv_eff_option = 7)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_date_value IS NULL)
				AND	pi_rv_eff_option = 3))
		THEN
			v_result := 1;

		-- else if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_date_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> pi_left_value
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			v_result := CASE WHEN v_l_per_end_date >= TRUNC(pi_right_date_value) THEN 1 ELSE 0 END;
		END IF;

	-- if period >= period
	ELSE
		-- a NULL regular/single eff value >= a NULL regular/single eff value, when timeunit is the same
		-- a NULL start eff value >= a NULL start eff value, regardless of type/timeunit
		-- a NULL end eff value >= a NULL start/end eff value, regardless of type/timeunit
		-- a NULL end eff value >= any NOT NULL value, regardless of type/timeunit
		-- any NOT NULL value >= a NULL start eff value, regardless of type/timeunit
		IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
				AND	(	(pi_lv_eff_option IN (0, 1, 2, 5, 8) AND pi_rv_eff_option IN (0, 1, 2, 5, 8) AND pi_left_period_tu_id = pi_right_period_tu_id)
					OR	(pi_lv_eff_option = 6 AND pi_rv_eff_option = 6)
					OR	(pi_lv_eff_option = 7 AND pi_rv_eff_option IN (6, 7))))
			OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
				AND	pi_lv_eff_option = 7)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
				AND	pi_rv_eff_option = 6))
		THEN
			v_result := 1;

		-- else if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 2 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_left_value
																				,pi_large_corr_tu_id	=> pi_right_period_tu_id)
										ELSE pi_left_value END
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 3 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_right_period_value
																				,pi_large_corr_tu_id	=> pi_left_period_tu_id)
										ELSE pi_right_period_value END
				,po_start_date	=> v_r_per_start_date
				,po_end_date	=> v_r_per_end_date);

			v_result := CASE WHEN v_l_per_start_date >= v_r_per_start_date THEN 1 ELSE 0 END;
		END IF;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION LESS_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_per_start_date	DATE;
	v_per_end_date		DATE;
BEGIN
	-- a NULL start eff value < a NULL end eff value
	-- a NULL start eff value < any NOT NULL value
	-- any NOT NULL value < a NULL end eff value
	IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
			AND	(pi_lv_eff_option = 3 AND pi_rv_eff_option = 7))
		OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
			AND	pi_lv_eff_option = 3)
		OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
			AND	pi_rv_eff_option = 7))
	THEN
		v_result := 1;

	-- if both values are NOT NULL
	ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
	THEN
		COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
		(	 pi_tupr_id		=> pi_right_period_value
			,po_start_date	=> v_per_start_date
			,po_end_date	=> v_per_end_date);

		v_result := CASE WHEN TRUNC(pi_left_value) < v_per_start_date THEN 1 ELSE 0 END;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION LESS_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_l_per_start_date	DATE;
	v_l_per_end_date	DATE;
	v_r_per_start_date	DATE;
	v_r_per_end_date	DATE;
BEGIN
	-- if period < date
	IF (pi_right_period_tu_id IS NULL)
	THEN
		-- a NULL start eff value < a NULL end eff value
		-- a NULL start eff value < any NOT NULL value
		-- any NOT NULL value < a NULL end eff value
		IF (	(	(pi_left_value IS NULL AND pi_right_date_value IS NULL)
				AND	(pi_lv_eff_option = 6 AND pi_rv_eff_option = 4))
			OR	(	(pi_left_value IS NULL AND pi_right_date_value IS NOT NULL)
				AND	pi_lv_eff_option = 6)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_date_value IS NULL)
				AND	pi_rv_eff_option = 4))
		THEN
			v_result := 1;

		-- if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_date_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> pi_left_value
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			v_result := CASE WHEN v_l_per_end_date < TRUNC(pi_right_date_value) THEN 1 ELSE 0 END;
		END IF;

	-- if period < period
	ELSE
		-- a NULL start eff value < a NULL end eff value, regardless of type/timeunit
		-- a NULL start eff value < any NOT NULL value, regardless of type/timeunit
		-- any NOT NULL value < a NULL end eff value, regardless of type/timeunit
		IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
				AND	(pi_lv_eff_option = 6 AND pi_rv_eff_option = 7))
			OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
				AND	pi_lv_eff_option = 6)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
				AND	pi_rv_eff_option = 7))
		THEN
			v_result := 1;

		-- if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 2 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_left_value
																				,pi_large_corr_tu_id	=> pi_right_period_tu_id)
										ELSE pi_left_value END
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 3 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_right_period_value
																				,pi_large_corr_tu_id	=> pi_left_period_tu_id)
										ELSE pi_right_period_value END
				,po_start_date	=> v_r_per_start_date
				,po_end_date	=> v_r_per_end_date);

			v_result := CASE WHEN v_l_per_start_date < v_r_per_start_date THEN 1 ELSE 0 END;
		END IF;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION LESS_EQ_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_per_start_date	DATE;
	v_per_end_date		DATE;
BEGIN
	-- a NULL end eff value <= a NULL end eff value
	-- a NULL start eff value <= a NULL end/start eff value
	-- a NULL start eff value <= any NOT NULL value
	-- any NOT NULL value <= a NULL end eff value
	IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
			AND	(	(pi_lv_eff_option = 4 AND pi_rv_eff_option = 7)
				OR	(pi_lv_eff_option = 3 AND pi_rv_eff_option IN (6, 7))))
		OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
			AND	pi_lv_eff_option = 3)
		OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
			AND	pi_rv_eff_option = 7))
	THEN
		v_result := 1;

	-- else if both values are NOT NULL
	ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
	THEN
		COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
		(	 pi_tupr_id		=> pi_right_period_value
			,po_start_date	=> v_per_start_date
			,po_end_date	=> v_per_end_date);

		v_result := CASE WHEN TRUNC(pi_left_value) <= v_per_end_date THEN 1 ELSE 0 END;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2013.AUG.07 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION LESS_EQ_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER
AS
	v_result			NUMBER := 0;
	v_l_per_start_date	DATE;
	v_l_per_end_date	DATE;
	v_r_per_start_date	DATE;
	v_r_per_end_date	DATE;
BEGIN
	-- period <= date
	IF (pi_right_period_tu_id IS NULL)
	THEN
		-- a NULL end eff value <= a NULL end eff value
		-- a NULL start eff value <= a NULL end/start eff value
		-- a NULL start eff value <= any NOT NULL value
		-- any NOT NULL value <= a NULL end eff value
		IF (	(	(pi_left_value IS NULL AND pi_right_date_value IS NULL)
				AND	(	(pi_lv_eff_option = 7 AND pi_rv_eff_option = 4)
					OR	(pi_lv_eff_option = 6 AND pi_rv_eff_option IN (3, 4))))
			OR	(	(pi_left_value IS NULL AND pi_right_date_value IS NOT NULL)
				AND	pi_lv_eff_option = 6)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_date_value IS NULL)
				AND	pi_rv_eff_option = 4))
		THEN
			v_result := 1;

		-- else if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_date_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> pi_left_value
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			v_result := CASE WHEN v_l_per_start_date <= TRUNC(pi_right_date_value) THEN 1 ELSE 0 END;
		END IF;

	-- if period <= period
	ELSE
		-- a NULL regular/single eff value <= a NULL regular/single eff value, when timeunit is the same
		-- a NULL end eff value <= a NULL end eff value, regardless of type/timeunit
		-- a NULL start eff value <= a NULL end/start eff value, regardless of type/timeunit
		-- a NULL start eff value <= any NOT NULL value, regardless of type/timeunit
		-- any NOT NULL value <= a NULL end eff value, regardless of type/timeunit
		IF (	(	(pi_left_value IS NULL AND pi_right_period_value IS NULL)
				AND	(	(pi_lv_eff_option IN (0, 1, 2, 5, 8) AND pi_rv_eff_option IN (0, 1, 2, 5, 8) AND pi_left_period_tu_id = pi_right_period_tu_id)
					OR	(pi_lv_eff_option = 7 AND pi_rv_eff_option = 7)
					OR	(pi_lv_eff_option = 6 AND pi_rv_eff_option IN (6, 7))))
			OR	(	(pi_left_value IS NULL AND pi_right_period_value IS NOT NULL)
				AND	pi_lv_eff_option = 6)
			OR	(	(pi_left_value IS NOT NULL AND pi_right_period_value IS NULL)
				AND	pi_rv_eff_option = 7))
		THEN
			v_result := 1;

		-- else if both values are NOT NULL
		ELSIF (pi_left_value IS NOT NULL AND pi_right_period_value IS NOT NULL)
		THEN
			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 2 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_left_value
																				,pi_large_corr_tu_id	=> pi_right_period_tu_id)
										ELSE pi_left_value END
				,po_start_date	=> v_l_per_start_date
				,po_end_date	=> v_l_per_end_date);

			COMMONS_TIMEUNITS.GET_PERIOD_START_END_DATE
			(	 pi_tupr_id		=> CASE	WHEN pi_tu_correspondence = 3 THEN COMMONS_TIMEUNITS.GET_CORR_PERIOD_FROM_SMALL_PER
																				(pi_small_period_id		=> pi_right_period_value
																				,pi_large_corr_tu_id	=> pi_left_period_tu_id)
										ELSE pi_right_period_value END
				,po_start_date	=> v_r_per_start_date
				,po_end_date	=> v_r_per_end_date);

			v_result := CASE WHEN v_l_per_start_date <= v_r_per_start_date THEN 1 ELSE 0 END;
		END IF;
	END IF;

	RETURN v_result;
END;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2014.JAN.23 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_NUMBER_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN NUMBER AS
	v_sql			CLOB;
	v_retval		NUMBER;
BEGIN
	v_sql := '
	SELECT '||pi_expr||'
	FROM '||pi_from_sql||'
	WHERE '||pi_id_column||' = :1';

	EXECUTE IMMEDIATE v_sql INTO v_retval USING pi_id_value;

	RETURN v_retval;
EXCEPTION
WHEN OTHERS THEN
	RETURN NULL;
END GET_CF_NUMBER_VALUE;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2014.JAN.23 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_VARCHAR2_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN VARCHAR2 AS
	v_sql			CLOB;
	v_retval		VARCHAR2(2000 CHAR);
BEGIN
	v_sql := '
	SELECT '||pi_expr||'
	FROM '||pi_from_sql||'
	WHERE '||pi_id_column||' = :1';

	EXECUTE IMMEDIATE v_sql INTO v_retval USING pi_id_value;

	RETURN v_retval;
EXCEPTION
WHEN OTHERS THEN
	RETURN NULL;
END GET_CF_VARCHAR2_VALUE;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2014.JAN.23 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_DATE_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN DATE AS
	v_sql			CLOB;
	v_retval		DATE;
BEGIN
	v_sql := '
	SELECT '||pi_expr||'
	FROM '||pi_from_sql||'
	WHERE '||pi_id_column||' = :1';

	EXECUTE IMMEDIATE v_sql INTO v_retval USING pi_id_value;

	RETURN v_retval;
EXCEPTION
WHEN OTHERS THEN
	RETURN NULL;
END GET_CF_DATE_VALUE;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2014.JAN.23 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_TIMESTAMP_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN TIMESTAMP AS
	v_sql			CLOB;
	v_retval		TIMESTAMP;
BEGIN
	v_sql := '
	SELECT '||pi_expr||'
	FROM '||pi_from_sql||'
	WHERE '||pi_id_column||' = :1';

	EXECUTE IMMEDIATE v_sql INTO v_retval USING pi_id_value;

	RETURN v_retval;
EXCEPTION
WHEN OTHERS THEN
	RETURN NULL;
END GET_CF_TIMESTAMP_VALUE;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2014.JUN.04 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
FUNCTION GET_FILTER_EXPRESSION
(	pi_str CLOB
) RETURN CLOB AS
	v_idx		PLS_INTEGER;
	v_len		PLS_INTEGER;
	v_chr		CHAR(1);
	v_num_str	VARCHAR2(250 CHAR);
	v_num_pos	PLS_INTEGER;
	v_name		VARCHAR2(250 CHAR);
	v_str		CLOB;
	v_in_str	BOOLEAN := FALSE;
	v_in_plc	BOOLEAN := FALSE;
	v_in_num	BOOLEAN := FALSE;
BEGIN
	v_str := pi_str;
	v_len := NVL(LENGTH(pi_str), 0);
	v_idx := 0;
	LOOP
		EXIT WHEN v_idx = v_len;
		v_idx := v_idx + 1;
		v_chr := SUBSTR(pi_str, v_idx, 1);

		-- if current char is a digit
		IF (TRIM(TRANSLATE(v_chr, '0123456789', ' ')) IS NULL)
		THEN
			-- if we are inside a number
			IF (v_in_num = TRUE)
			THEN
				v_num_str := v_num_str||v_chr;
			-- if we are inside a placeholder and this is the first digit in a number
			ELSIF (v_in_plc = TRUE)
			THEN
				v_in_num := TRUE;
				v_num_pos := v_idx;
				v_num_str := v_num_str||v_chr;
			END IF;
		-- if current char is not a digit
		ELSE
			-- if we just exited a number
			IF (v_in_num = TRUE)
			THEN
				-- replace number with object name
				BEGIN
					SELECT COMMONS_APPFRAMEWORK.GET_NAME(OR_NAME) INTO v_name
					FROM OBJECT_REGISTRATION WHERE OR_ID = TO_NUMBER(v_num_str);
					v_str := REGEXP_REPLACE(v_str, v_num_str, v_name, v_num_pos, 1);
				EXCEPTION
				WHEN OTHERS THEN NULL;
				END;

				-- reset and wait for a new number
				v_in_num := FALSE;
				v_num_str := NULL;
				v_num_pos := NULL;
			END IF;

			-- set whether you are in a string or a placeholder
			IF		(v_chr = '"') THEN v_in_str := NOT(v_in_str);
			ELSIF	(v_chr = '[' AND v_in_str = FALSE) THEN v_in_plc := TRUE;
			ELSIF	(v_chr = ']' AND v_in_str = FALSE) THEN v_in_plc := FALSE; END IF;
		END IF;
	END LOOP;

	RETURN v_str;
EXCEPTION
WHEN OTHERS THEN
	RETURN pi_str;
END GET_FILTER_EXPRESSION;


/*	-----------------------------------------------------------------------------------------
	Change history:
	2014.JUN.04 - Dumitriu, Cosmin - created
	-----------------------------------------------------------------------------------------*/
PROCEDURE SAVE_FILTER_EXPRESSIONS
AS
BEGIN
    DELETE FROM TEMP_LONG_TO_CLOB_HELPER;

    INSERT INTO TEMP_LONG_TO_CLOB_HELPER(ID, TEXT)
    SELECT  EXP_ID, EXPRESSION_BUILDER.GET_FILTER_EXPRESSION(EXP_EXPRESSION)
    FROM    EXPRESSIONS;
END SAVE_FILTER_EXPRESSIONS;

FUNCTION NATURAL_LOGARITHM_CALCULATION(PI_LN_VARIABLE       NUMBER)
  RETURN NUMBER AS
  VALUE_ERROR EXCEPTION;
  BEGIN
    IF PI_LN_VARIABLE <= 0 THEN
      RAISE VALUE_ERROR;
    ELSE
      RETURN LN(PI_LN_VARIABLE);
    END IF;
EXCEPTION
  WHEN VALUE_ERROR THEN
    RAISE_APPLICATION_ERROR(-20006, 'The value for ln operation must be strictly greater then 0!');
END NATURAL_LOGARITHM_CALCULATION;

end EXPRESSION_BUILDER;
/
