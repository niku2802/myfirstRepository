CREATE PACKAGE BODY ALIGNMENTS AS
  -- --------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : alignments-commons
  -- Requester      : Sharma, Pooja
  -- Author         : Vijaywargiya, Abhishek
  -- Create date    : 11-Oct-2013
  -- Reviewer       : Rohit, Maxim
  -- Review date    :
  -- Description    : Package for Alignments
  --ls
  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- OF-27136 - START
  PROCEDURE EXECUTE_DDL_AUTONOMOUS(PI_DDL           IN CLOB,
                                   PI_PROCESS_NAME  IN CLOB,
                                   PI_TYPE_NUMBER_1 IN SYS.HSBLKNAMLST DEFAULT SYS.HSBLKNAMLST(),
                                   PI_TYPE_NUMBER_2 IN SYS.HSBLKNAMLST DEFAULT SYS.HSBLKNAMLST()) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- INSERT_LOGS('TX_ID IN autonomous_transaction for  '|| PI_PROCESS_NAME ||' - '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
    IF PI_TYPE_NUMBER_1.COUNT > 0 THEN
      --PI_TYPE_NUMBER_1 IS NOT NULL THEN
      IF PI_TYPE_NUMBER_2.COUNT > 0 THEN
        --PI_TYPE_NUMBER_2 IS NOT NULL THEN
        EXECUTE IMMEDIATE PI_DDL
          USING PI_TYPE_NUMBER_1, PI_TYPE_NUMBER_2;
      ELSE
        EXECUTE IMMEDIATE PI_DDL
          USING PI_TYPE_NUMBER_1;
      END IF;
    ELSE
      EXECUTE IMMEDIATE PI_DDL;
    END IF;
    COMMIT;
  END;
  -- OF-27136 - END
  FUNCTION GET_MODIFIED_HIERARCHY_FILTER(PI_FILTER_ORI IN CLOB) RETURN CLOB IS
    V_FILTER_MOD   CLOB;
    V_CHECK_STRING VARCHAR2(30 CHAR) := 'IS NULL';
    V_ADD_STRING   CLOB;
    V_ENT_ALIAS    VARCHAR2(30 CHAR);

    I_COUNTER    NUMBER := 1;
    V_ISNULL_POS NUMBER;
    V_DOT_POS_0  NUMBER;
    V_ENT_POS    NUMBER;
    V_DOT_POS    NUMBER;
    V_SPACE_POS  NUMBER;
    V_BRACE_POS  NUMBER;
  BEGIN
    V_FILTER_MOD := PI_FILTER_ORI;
    V_ISNULL_POS := INSTR(V_FILTER_MOD, V_CHECK_STRING, 1, I_COUNTER);

    WHILE V_ISNULL_POS > 0 LOOP
      V_DOT_POS_0 := INSTR(V_FILTER_MOD,
                           '.',
                           (V_ISNULL_POS - LENGTH(V_FILTER_MOD)),
                           1);
      V_DOT_POS   := V_DOT_POS_0 - LENGTH(V_FILTER_MOD);

      V_SPACE_POS := INSTR(V_FILTER_MOD, ' ', V_DOT_POS, 1);
      V_BRACE_POS := INSTR(V_FILTER_MOD, '(', V_DOT_POS, 1);

      V_ENT_POS := (CASE
                     WHEN V_SPACE_POS > V_BRACE_POS THEN
                      V_SPACE_POS
                     ELSE
                      V_BRACE_POS
                   END) + 1;

      V_ENT_ALIAS := SUBSTR(V_FILTER_MOD,
                            V_ENT_POS,
                            V_DOT_POS_0 - V_ENT_POS);

      V_ADD_STRING := V_CHECK_STRING || ' AND ' || V_ENT_ALIAS ||
                      '.E_INTERNAL_ID IS NOT NULL';
      V_FILTER_MOD := REGEXP_REPLACE(V_FILTER_MOD,
                                     V_CHECK_STRING,
                                     V_ADD_STRING,
                                     1,
                                     I_COUNTER);

      I_COUNTER    := I_COUNTER + 1;
      V_ISNULL_POS := INSTR(V_FILTER_MOD, V_CHECK_STRING, 1, I_COUNTER);
    END LOOP;

    RETURN V_FILTER_MOD;
  END GET_MODIFIED_HIERARCHY_FILTER;

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
  PROCEDURE EVALUATE_ALIGNMENTS(PI_ALIGNMENT_ENTITY_OBJECT    IN COLTYPE_ALIGNMENT_ENTITY,
                                PI_ALIGNED_ENTITIES_OBJECT    IN COLTYPE_ALIGNED_ENTITIES,
                                PI_CONDITIONS_OBJECT          IN COLTYPE_ALIGNMENTS_CONDITIONS,
                                PI_FILTERS_OBJECT             IN COLTYPE_ALIGNMENTS_FILTERS,
                                PI_ALIGNMENT_TABLE_NAME       IN VARCHAR2,
                                PI_OVERLAPPING_TABLE_NAME     IN VARCHAR2,
                                PI_CONTRADICTORY_TABLE_NAME   IN VARCHAR2,
                                PI_DUAL_ALIGNMENTS_TABLE_NAME IN VARCHAR2) IS
    V_CONDITIONS_INTERNAL_OBJECT COLTYPE_CONDITIONS_INTERNAL := COLTYPE_CONDITIONS_INTERNAL();
    V_DATE_RANGE_INTERNAL_OBJECT COLTYPE_DATE_RANGE_INTERNAL := COLTYPE_DATE_RANGE_INTERNAL();
    V_NEEDED                     NUMBER(1) := 0; -- Boolean variable
    v_CONDITION_IS_EXCLUDE       NUMBER(1); -- Boolean variable
    v_counter                    NUMBER := 0; -- OF-8882 -- Increased the size by replacing NUMBER(1) with NUMBER
    --v_Select                         VARCHAR2 (32000 CHAR) := 'SELECT ';
    v_Select_Both               VARCHAR2(32000 CHAR) := 'SELECT DISTINCT ';
    v_Select_Include_Of_Exclude VARCHAR2(32000 CHAR) := 'SELECT DISTINCT ';
    v_Select_Total_Set          VARCHAR2(32000 CHAR) := 'SELECT DISTINCT '; -- 'SELECT DISTINCT ';
    v_Select_Conditions         VARCHAR2(32000 CHAR);
    v_From                      VARCHAR2(32000 CHAR); -- := ' FROM ';   -- OF-7719 and OF-7722
    v_Aligned_FROM              VARCHAR2(32000 CHAR);
    v_Order_By                  VARCHAR2(32000 CHAR) := ' ORDER BY 1, 2, 3, ';
    v_Exclude_FOR_ALIGNMENT     VARCHAR2(10 CHAR) := NULL;
    v_Exclude_FOR_BOTH          VARCHAR2(10 CHAR) := NULL;
    v_Exclude_FOR_EXCLUDE       VARCHAR2(10 CHAR) := NULL;
    --v_SQL_DROP                 VARCHAR2 (32000 CHAR) := 'DROP TABLE ';
    v_WHERE_BOTH                  CLOB := NULL;
    v_WHERE_Include_Of_Exclude    CLOB := NULL;
    v_AND_Alignment_Filter_Clause VARCHAR2(32000 CHAR);
    v_AND_Filter_Clause           CLOB;
    v_AND_Entities_Clause         VARCHAR2(32000 CHAR);
    v_ENTITY_DATE_RANGE_PART_1    VARCHAR2(1000 CHAR) := NULL;
    v_ENTITY_DATE_RANGE_PART_2    VARCHAR2(1000 CHAR) := NULL;
    V_DATE_RANGE_CLAUSE           VARCHAR2(32000 CHAR);
    v_SELECT_Entities_Clause      VARCHAR2(32000 CHAR);
    --      v_SQL_FOR_BOTH                CLOB;
    --      v_SQL_FOR_Include_Of_Exclude     CLOB;
    v_SQL_BOTH_Set                CLOB;
    v_SQL_Include_Of_Exclude_Set  CLOB;
    v_SQL_Contradiction_Set       CLOB;
    v_SQL_Overlap_Set             CLOB;
    v_SQL_Contradiction_Aggregate CLOB;
    v_SQL_Overlap_Aggregate       CLOB;
    v_SQL_FINAL                   CLOB;
    v_SQL_Total_Set               CLOB;
    V_SQL_CTAS_TOTAL              CLOB;
    V_SQL_CTAS_FINAL              CLOB;
    v_SQL_TRUNCATE                CLOB;
    v_SQL_INSERT                  CLOB;
    v_INSERT_INTO_COL_LIST        CLOB;
    v_INSERT_VALUES_COL_LIST      CLOB;
    -- Variables to hold record level data from the input objects
    -- Alignment Entity
    v_Alignment_Table_Name         VARCHAR2(30 CHAR);
    v_Alignment_Entity_Table_Alias VARCHAR2(30 CHAR);
    v_Alignment_EIntId_Alias       VARCHAR2(30 CHAR);
    v_Alignment_ENTITY_COL_NAME    VARCHAR2(30 CHAR);
    -- Aligned Entities
    v_Aligned_Table_Name          VARCHAR2(30 CHAR);
    v_Aligned_Entity_Table_Alias  VARCHAR2(30 CHAR);
    v_Aligned_EIntId_Alias        VARCHAR2(30 CHAR);
    v_Assignment_Table_Name       VARCHAR2(30 CHAR);
    v_Assignment_Table_Alias      VARCHAR2(30 CHAR);
    v_Assigned_Entity_Table_Name  VARCHAR2(30 CHAR);
    v_Assigned_Entity_Table_Alias VARCHAR2(30 CHAR);
    v_Assigned_Entity_Column_Name VARCHAR2(30 CHAR);
    v_Aligned_Entity_Column_Name  VARCHAR2(30 CHAR);
    v_Aligned_ENTITIES_COL_NAME   VARCHAR2(32000 CHAR);
    v_ALLOCATION_COL              VARCHAR2(30 CHAR);
    --      v_SQL_TRUNCATE                   CLOB;
    --      v_SQL_INSERT                     CLOB;
    -- Internal Table names
    v_Total_Set_Table              VARCHAR2(30 CHAR) := 'T' ||
                                                        UID_SEQUENCE.NEXTVAL;
    v_FINAL_Table                  VARCHAR2(30 CHAR) := 'T' ||
                                                        UID_SEQUENCE.NEXTVAL;
    v_Overlap_Table                VARCHAR2(30 CHAR);
    v_ALIAS_FOR_BOTH               VARCHAR2(30 CHAR);
    v_ALIAS_FOR_Include_Of_Exclude VARCHAR2(30 CHAR);

    v_ALLOW_DUAL_ALIGNMENTS NUMBER(1); -- Boolean variable
    --v_dual_rows_list                 CLOB;
    v_Aligned_EIntId_Alias_List CLOB;
    v_sql_dual_rows             CLOB;
    v_AND_Dual_Aligned_Clause   CLOB;

    -- OF-6945 - START

    v_clob  CLOB;
    v_count NUMBER := 0;
    -- OF-6945 - END

    -- OF-22214 - START
    V_SQL_GTT         CLOB;
    V_TYPE_CLOB       TABLETYPE_CLOB;
    V_TYPE_NUMBER     SYS.Hsblknamlst;
    v_Dual_Rows_Table VARCHAR2(30 CHAR) := 'T' || UID_SEQUENCE.NEXTVAL;
    -- OF-22214 - END

    -- OF-7719 and OF-7722 - START
    v_ALIGNMENT_FLT_VIA_HIERARCHY NUMBER(1) := 0; -- Boolean variable
    v_Relationship_Table_Alias    VARCHAR2(30 CHAR) := '';

    v_Alignment_Ent_Via_Hier_FROM CLOB;
    v_Aligned_Ent_Via_Hier_FROM   CLOB;
    v_Aligned_FROM_TOTAL          CLOB;
    v_Alignment_FROM              CLOB;
    v_FROM_1                      CLOB;
    v_FROM_2                      CLOB;
    v_SQL_Total_Set_1             CLOB;
    v_SQL_Total_Set_2             CLOB;
    v_WHERE_BOTH_1                CLOB := NULL;
    v_WHERE_BOTH_2                CLOB := NULL;
    v_WHERE_Include_Of_Exclude_1  CLOB := NULL;
    v_WHERE_Include_Of_Exclude_2  CLOB := NULL;
    v_Select_Total_Set_1          CLOB := NULL;
    v_Select_Total_Set_2          CLOB := NULL;
    -- v_SQL_Include_Of_Exclude_Set_1   CLOB := NULL;
    -- v_SQL_Include_Of_Exclude_Set_2   CLOB := NULL;
    -- v_SQL_BOTH_Set_1                 CLOB := NULL;
    -- v_SQL_BOTH_Set_2                 CLOB := NULL;
    V_Count_1 NUMBER;
    V_Count_2 NUMBER;
    -- OF-7719 and OF-7722 - END

    -- No OF-id, internal testing post fix for OF-8834 - START
    v_Select_Total_Set_FINAL   CLOB := 'SELECT ';
    v_Group_By_Total_Set_FINAL CLOB := 'GROUP BY ';
    -- No OF-id, internal testing post fix for OF-8834 - END

    -- OF-8890 - START
    v_COND_FOR_BOTH               CLOB := NULL;
    v_COND_FOR_INCLUDE_OF_EXCLUDE CLOB := NULL;
    V_ALIAS_oN_CLAUSE             VARCHAR2(100 CHAR);
    V_MOD_ON_CLAUSE               CLOB;
    DATE_RANGE_COUNTER            NUMBER := 1;
    v_ALIGNED_FLT_VIA_HIERARCHY   NUMBER := 0;
    -- V_FILTER_EVALUATION              CLOB;                 -- OF-4022 and OF-10094 - Commented this, since V_FILTER_EVALUATION is now replaced with V_FILTER_EVALUATION_INCLUDE
    V_ALIGNMENT_FILTER_EVALUATION CLOB := NULL; -- OF-9829
    -- OF-8890 - END

    -- OF-4022 and OF-10094 - START
    V_FILTER_EVALUATION_INCLUDE CLOB;
    V_FILTER_EVALUATION_EXCLUDE CLOB;
    v_AND_Filter_Clause_INCLUDE CLOB;
    v_AND_Filter_Clause_EXCLUDE CLOB;
    v_AND_Filter_Clause_BOTH    CLOB;
    -- OF-4022 and OF-10094 - END

    /*AV - START*/
    v_RT_LtoU_Date_Range_Clause CLOB;
    /*AV - END*/

  BEGIN
    -- If input objects are valid
    IF ((PI_ALIGNMENT_ENTITY_OBJECT IS NOT NULL) AND
       (PI_ALIGNED_ENTITIES_OBJECT IS NOT NULL) AND
       (PI_CONDITIONS_OBJECT IS NOT NULL) AND
       (PI_FILTERS_OBJECT IS NOT NULL) AND
       (PI_ALIGNMENT_TABLE_NAME IS NOT NULL) AND
       (PI_OVERLAPPING_TABLE_NAME IS NOT NULL) AND
       (PI_CONTRADICTORY_TABLE_NAME IS NOT NULL) AND
       (PI_DUAL_ALIGNMENTS_TABLE_NAME IS NOT NULL)) THEN
      -- IF_1 START

      -- AV - OF_0 - START - Commenting the following code, since Java layer already passes the blank result tables.
      /*
      -- Truncate the 3 Tables (names passed as input parameters) to be populated with the Final output
      BEGIN
        v_SQL_TRUNCATE      :=
             '
             BEGIN
                FOR I IN (SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME IN ('''
          || PI_ALIGNMENT_TABLE_NAME
          || ''', '''
          || PI_OVERLAPPING_TABLE_NAME
          || ''', '''
          || PI_CONTRADICTORY_TABLE_NAME
          || ''', '''
          || PI_DUAL_ALIGNMENTS_TABLE_NAME
          || '''))
                LOOP
                  EXECUTE IMMEDIATE ''TRUNCATE TABLE '' || I.TABLE_NAME;
                END LOOP;
             END;';

        EXECUTE IMMEDIATE v_SQL_TRUNCATE;
      END;
      */
      -- AV - OF_0 - END

      -- 1. Loop through the Alignment Entity object
      FOR I IN 1 .. PI_ALIGNMENT_ENTITY_OBJECT.COUNT LOOP
        -- Set variables
        v_Alignment_Table_Name         := PI_ALIGNMENT_ENTITY_OBJECT(I)
                                          .ENTITY_TABLE_NAME;
        v_Alignment_Entity_Table_Alias := PI_ALIGNMENT_ENTITY_OBJECT(I)
                                          .ENTITY_TABLE_ALIAS;
        v_Alignment_EIntId_Alias       := SUBSTR(PI_ALIGNMENT_ENTITY_OBJECT(I)
                                                 .ENTITY_TABLE_ALIAS,
                                                 1,
                                                 21) || '_E_INT_ID';
        -- Form the Alignment SELECT clause part
        v_Select_Total_Set          := v_Select_Total_Set ||
                                       v_Alignment_Entity_Table_Alias ||
                                       '.E_INTERNAL_ID ' ||
                                       v_Alignment_EIntId_Alias || ', ';
        v_Select_Both               := v_Select_Both ||
                                       v_Alignment_EIntId_Alias || ', ';
        v_Select_Include_Of_Exclude := v_Select_Include_Of_Exclude ||
                                       v_Alignment_EIntId_Alias || ', ';
        v_SELECT_Entities_Clause    := v_SELECT_Entities_Clause ||
                                       v_Alignment_EIntId_Alias || ', ';

        -- No OF-id, internal testing post fix for OF-8834 -- START
        v_Select_Total_Set_FINAL   := v_Select_Total_Set_FINAL ||
                                      v_Alignment_EIntId_Alias || ', ';
        v_Group_By_Total_Set_FINAL := v_Group_By_Total_Set_FINAL ||
                                      v_Alignment_EIntId_Alias || ', ';
        -- No OF-id, internal testing post fix for OF-8834 -- END

        -- OF-9829 -- START -- Removing ', ' from here and adding it while using v_Alignment_ENTITY_COL_NAME, wherever required
        -- Form the Alignment COLUMN part
        -- v_Alignment_ENTITY_COL_NAME    := PI_ALIGNMENT_ENTITY_OBJECT ( I).ENTITY_COLUMN_NAME || ', ';
        v_Alignment_ENTITY_COL_NAME := PI_ALIGNMENT_ENTITY_OBJECT(I)
                                       .ENTITY_COLUMN_NAME;
        -- OF-9829 -- END

        -- Form the ALLOCATION COLUMN part
        v_ALLOCATION_COL := CASE
                              WHEN PI_ALIGNMENT_ENTITY_OBJECT(I)
                               .IS_ALLOCATION_APPLICABLE = 1 THEN
                               'ALLOCATION, '
                              ELSE
                               NULL
                            END;

        -- Form the Alignment FROM clause part
        -- OF-7719 and OF-7722 - START
        -- Reset Hierarchy FROM Clause to NULL to start
        v_Alignment_Ent_Via_Hier_FROM := NULL;

        -- Form the Alignment Entity Hierarchy FROM Clause, if required
        IF (PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO IS NOT NULL) THEN
          -- INSERT_LOGS('PI_ALIGNMENT_ENTITY_OBJECT ( I).DATE_RANGE_OPTION = ' || PI_ALIGNMENT_ENTITY_OBJECT ( I).DATE_RANGE_OPTION);
          FOR J IN REVERSE 1 .. PI_ALIGNMENT_ENTITY_OBJECT(I)
                                .ENTITY_HIERARCHY_INFO.COUNT LOOP
            v_Relationship_Table_Alias := PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .RELATIONSHIP_TABLE_ALIAS;

            -- INSERT_LOGS(' J = ' || J || '  PI_ALIGNMENT_ENTITY_OBJECT ( I).DATE_RANGE_OPTION = ' || PI_ALIGNMENT_ENTITY_OBJECT ( I).DATE_RANGE_OPTION);

            -- Form the Hierarchy Date Range clause part
            CASE PI_ALIGNMENT_ENTITY_OBJECT(I).DATE_RANGE_OPTION
              WHEN 1 --1 = FIRST DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              WHEN 2 --2 = LAST DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              WHEN 3 --3 = ANY DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              WHEN 4 --4 = EVERY DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              ELSE
                v_ENTITY_DATE_RANGE_PART_1 := NULL;
                v_ENTITY_DATE_RANGE_PART_2 := NULL;
            END CASE;

            /*AV - START*/
            v_RT_LtoU_Date_Range_Clause := NULL; -- Initializing

            /*AV - END*/

            IF PI_ALIGNMENT_ENTITY_OBJECT(I).DATE_RANGE_OPTION IS NOT NULL THEN
              -- Set values
              -- INSERT_LOGS ('I = ' || I || '  J = '|| J) ;
              V_DATE_RANGE_INTERNAL_OBJECT.EXTEND;
              v_counter := V_DATE_RANGE_INTERNAL_OBJECT.COUNT;
              V_DATE_RANGE_INTERNAL_OBJECT(v_counter) := OBJTYPE_DATE_RANGE_INTERNAL(ENTITY_COLUMN_NAME       => v_Alignment_ENTITY_COL_NAME, -- OF-9829 -- PI_ALIGNMENT_ENTITY_OBJECT ( I).ENTITY_COLUMN_NAME,
                                                                                     RELATIONSHIP_TABLE_ALIAS => v_Relationship_Table_Alias, -- OF-8890
                                                                                     ENTITY_DATE_RANGE_PART_1 => v_ENTITY_DATE_RANGE_PART_1,
                                                                                     ENTITY_DATE_RANGE_PART_2 => v_ENTITY_DATE_RANGE_PART_2);
              -- INSERT_LOGS ('V_DATE_RANGE_INTERNAL_OBJECT ( K).ENTITY_COLUMN_NAME = ' || v_Alignment_ENTITY_COL_NAME);
              -- INSERT_LOGS ('v_ENTITY_DATE_RANGE_PART_1 = ' || v_ENTITY_DATE_RANGE_PART_1);
              -- INSERT_LOGS ('v_ENTITY_DATE_RANGE_PART_2 = ' || v_ENTITY_DATE_RANGE_PART_2);
              -- INSERT_LOGS ('v_Relationship_Table_Alias = ' || v_Relationship_Table_Alias);
              -- INSERT_LOGS ('v_counter' || v_counter);

              /*AV - START*/
              v_RT_LtoU_Date_Range_Clause := NULL; -- Initializing
              v_RT_LtoU_Date_Range_Clause := CASE
                                               WHEN J = PI_ALIGNMENT_ENTITY_OBJECT(I)
                                                   .ENTITY_HIERARCHY_INFO.COUNT THEN
                                                NULL
                                               ELSE
                                                ' AND ( (NVL (TO_DATE (' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J + 1)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.END_DATE, ''DD/MM/RRRR''), TO_DATE ( ''31/12/9999'', ''DD/MM/RRRR'')) >=
               NVL (TO_DATE (' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.START_DATE, ''DD/MM/RRRR''), TO_DATE ( ''01/01/1900'', ''DD/MM/RRRR'')))
       AND (NVL (TO_DATE (' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J + 1)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.START_DATE, ''DD/MM/RRRR''), TO_DATE ( ''01/01/1900'', ''DD/MM/RRRR'')) <=
              NVL (TO_DATE (' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.END_DATE, ''DD/MM/RRRR''), TO_DATE ( ''31/12/9999'', ''DD/MM/RRRR''))))'
                                             END;
              /*AV - END*/
            END IF;

            -- /* -- abhi
            v_Alignment_Ent_Via_Hier_FROM := v_Alignment_Ent_Via_Hier_FROM ||
                                             '  LEFT OUTER JOIN ' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .RELATIONSHIP_TABLE_NAME || ' ' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .RELATIONSHIP_TABLE_ALIAS ||
                                             ' ON (' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .RELATIONSHIP_TABLE_ALIAS || '.' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .LOWER_ENTITY_COLUMN_NAME ||
                                             ' = ' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .LOWER_ENTITY_TABLE_ALIAS ||
                                             '.E_INTERNAL_ID '
                                            /*AV - START*/
                                             || v_RT_LtoU_Date_Range_Clause
                                            /*AV - END*/
                                             || ')   LEFT OUTER JOIN ' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .UPPER_ENTITY_TABLE_NAME || ' ' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .UPPER_ENTITY_TABLE_ALIAS ||
                                             ' ON (' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .UPPER_ENTITY_TABLE_ALIAS ||
                                             '.E_INTERNAL_ID = ' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .RELATIONSHIP_TABLE_ALIAS || '.' || PI_ALIGNMENT_ENTITY_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                            .UPPER_ENTITY_COLUMN_NAME || ')';
            -- abhi */
          END LOOP;
        END IF;

        -- Replace the 1st "LEFT OUTER" with "INNER" so that the Hierarchy is considered while computing Alignment Entity values.
        v_Alignment_Ent_Via_Hier_FROM := REGEXP_REPLACE(v_Alignment_Ent_Via_Hier_FROM,
                                                        'LEFT OUTER',
                                                        'INNER',
                                                        1,
                                                        1);

        -- v_From                         :=  v_From || v_Alignment_Table_Name || ' ' || v_Alignment_Entity_Table_Alias || v_Alignment_Ent_Via_Hier_FROM || ' CROSS JOIN ';
        -- OF-7719 and OF-7722 - END

        -- Form the Alignment v_AND_Entities_Clause and v_AND_Dual_Aligned_Clause
        v_AND_Entities_Clause     := v_AND_Entities_Clause || ' AND A.' ||
                                     v_Alignment_EIntId_Alias || ' = B.' ||
                                     v_Alignment_EIntId_Alias;
        v_AND_Dual_Aligned_Clause := v_AND_Dual_Aligned_Clause || ' A.' ||
                                     v_Alignment_EIntId_Alias || ' <> B.' ||
                                     v_Alignment_EIntId_Alias;

        -- Set Allow Dual Alignments -- 1.25
        v_ALLOW_DUAL_ALIGNMENTS := PI_ALIGNMENT_ENTITY_OBJECT(I)
                                   .ALLOW_DUAL_ALIGNMENTS;
      END LOOP;

      -- 2. Loop through Aligned Entities object
      FOR I IN 1 .. PI_ALIGNED_ENTITIES_OBJECT.COUNT LOOP
        -- Set variables
        v_Aligned_Table_Name         := PI_ALIGNED_ENTITIES_OBJECT(I)
                                        .ENTITY_TABLE_NAME;
        v_Aligned_Entity_Table_Alias := PI_ALIGNED_ENTITIES_OBJECT(I)
                                        .ENTITY_TABLE_ALIAS;
        v_Aligned_EIntId_Alias       := SUBSTR(PI_ALIGNED_ENTITIES_OBJECT(I)
                                               .ENTITY_TABLE_ALIAS,
                                               1,
                                               21) || '_E_INT_ID';

        -- Form the Aligned SELECT clause part
        v_Select_Total_Set          := v_Select_Total_Set ||
                                       v_Aligned_Entity_Table_Alias ||
                                       '.E_INTERNAL_ID ' ||
                                       v_Aligned_EIntId_Alias || ', ';
        v_Select_Both               := v_Select_Both ||
                                       v_Aligned_EIntId_Alias || ', ';
        v_Select_Include_Of_Exclude := v_Select_Include_Of_Exclude ||
                                       v_Aligned_EIntId_Alias || ', ';
        v_SELECT_Entities_Clause    := v_SELECT_Entities_Clause ||
                                       v_Aligned_EIntId_Alias || ', ';

        -- No OF-id, internal testing post fix for OF-8834 -- START
        v_Select_Total_Set_FINAL   := v_Select_Total_Set_FINAL ||
                                      v_Aligned_EIntId_Alias || ', ';
        v_Group_By_Total_Set_FINAL := v_Group_By_Total_Set_FINAL ||
                                      v_Aligned_EIntId_Alias || ', ';
        -- No OF-id, internal testing post fix for OF-8834 -- END

        -- Form the Aligned COLUMNS part
        v_Aligned_ENTITIES_COL_NAME := v_Aligned_ENTITIES_COL_NAME || PI_ALIGNED_ENTITIES_OBJECT(I)
                                      .ENTITY_COLUMN_NAME || ', ';
        v_Aligned_EIntId_Alias_List := v_Aligned_EIntId_Alias_List || 'A.' ||
                                       v_Aligned_EIntId_Alias || ', ';
        -- Form the Assignment Table Name and its Alias
        v_Assignment_Table_Name       := PI_ALIGNED_ENTITIES_OBJECT(I)
                                         .ASSIGNMENT_TABLE_NAME;
        v_Assignment_Table_Alias      := 'AT_' || I;
        v_Assigned_Entity_Table_Name  := PI_ALIGNED_ENTITIES_OBJECT(I)
                                         .ASSIGNED_ENTITY_TABLE_NAME;
        v_Assigned_Entity_Table_Alias := PI_ALIGNED_ENTITIES_OBJECT(I)
                                         .ASSIGNED_ENTITY_TABLE_ALIAS;
        v_Assigned_Entity_Column_Name := PI_ALIGNED_ENTITIES_OBJECT(I)
                                         .ASSIGNED_ENTITY_COLUMN_NAME;
        v_Aligned_Entity_Column_Name  := PI_ALIGNED_ENTITIES_OBJECT(I)
                                         .ENTITY_COLUMN_NAME;

        -- OF-7719 and OF-7722 - START
        -- Reset Aligned Entity Hierarchy FROM Clause to NULL to start
        v_Aligned_Ent_Via_Hier_FROM := NULL;

        -- Loop through Hierarchy object, if it is not empty
        IF (PI_ALIGNED_ENTITIES_OBJECT(I).ALIGNMENT_METHOD_OPTION = 4 AND PI_ALIGNED_ENTITIES_OBJECT(I)
           .ENTITY_HIERARCHY_INFO IS NOT NULL) THEN
          FOR J IN REVERSE 1 .. PI_ALIGNED_ENTITIES_OBJECT(I)
                                .ENTITY_HIERARCHY_INFO.COUNT -- REVERSE loop order has been used to make sure all Entities in the Hierarchy are joined with their corresponding Relationship tables and complete the Hierarchy route.
           LOOP
            v_Relationship_Table_Alias := PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .RELATIONSHIP_TABLE_ALIAS;

            -- Form the Hierarchy Date Range clause part
            CASE PI_ALIGNED_ENTITIES_OBJECT(I).DATE_RANGE_OPTION
              WHEN 1 --1 = FIRST DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              WHEN 2 --2 = LAST DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              WHEN 3 --3 = ANY DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              WHEN 4 --4 = EVERY DAY
               THEN
                v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
                v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                              v_Relationship_Table_Alias ||
                                              '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
              ELSE
                v_ENTITY_DATE_RANGE_PART_1 := NULL;
                v_ENTITY_DATE_RANGE_PART_2 := NULL;
            END CASE;

            /*AV - START*/
            v_RT_LtoU_Date_Range_Clause := NULL; -- Initializing

            /*AV - END*/
            IF PI_ALIGNED_ENTITIES_OBJECT(I).DATE_RANGE_OPTION IS NOT NULL THEN
              -- Set values
              V_DATE_RANGE_INTERNAL_OBJECT.EXTEND;
              v_counter := V_DATE_RANGE_INTERNAL_OBJECT.COUNT;
              V_DATE_RANGE_INTERNAL_OBJECT(v_counter) := OBJTYPE_DATE_RANGE_INTERNAL(ENTITY_COLUMN_NAME       => v_Aligned_Entity_Column_Name,
                                                                                     RELATIONSHIP_TABLE_ALIAS => v_Relationship_Table_Alias, -- OF-8890
                                                                                     ENTITY_DATE_RANGE_PART_1 => v_ENTITY_DATE_RANGE_PART_1,
                                                                                     ENTITY_DATE_RANGE_PART_2 => v_ENTITY_DATE_RANGE_PART_2);

              /*AV - START*/
              v_RT_LtoU_Date_Range_Clause := NULL; -- Initializing
              v_RT_LtoU_Date_Range_Clause := CASE
                                               WHEN J = PI_ALIGNED_ENTITIES_OBJECT(I)
                                                   .ENTITY_HIERARCHY_INFO.COUNT THEN
                                                NULL
                                               ELSE
                                                ' AND ( (NVL (TO_DATE (' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J + 1)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.END_DATE, ''DD/MM/RRRR''), TO_DATE ( ''31/12/9999'', ''DD/MM/RRRR'')) >=
               NVL (TO_DATE (' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.START_DATE, ''DD/MM/RRRR''), TO_DATE ( ''01/01/1900'', ''DD/MM/RRRR'')))
       AND (NVL (TO_DATE (' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J + 1)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.START_DATE, ''DD/MM/RRRR''), TO_DATE ( ''01/01/1900'', ''DD/MM/RRRR'')) <=
              NVL (TO_DATE (' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                               .RELATIONSHIP_TABLE_ALIAS ||
                                                '.END_DATE, ''DD/MM/RRRR''), TO_DATE ( ''31/12/9999'', ''DD/MM/RRRR''))))'
                                             END;
              /*AV - END*/
            END IF;

            --  Form the Hierarchy FROM Clause
            v_Aligned_Ent_Via_Hier_FROM := v_Aligned_Ent_Via_Hier_FROM ||
                                           '  LEFT OUTER JOIN ' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .RELATIONSHIP_TABLE_NAME || ' ' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .RELATIONSHIP_TABLE_ALIAS ||
                                           ' ON (' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .RELATIONSHIP_TABLE_ALIAS || '.' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .LOWER_ENTITY_COLUMN_NAME ||
                                           ' = ' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .LOWER_ENTITY_TABLE_ALIAS ||
                                           '.E_INTERNAL_ID '
                                          /*AV - START*/
                                           || v_RT_LtoU_Date_Range_Clause
                                          /*AV - END*/
                                           || ')   LEFT OUTER JOIN ' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .UPPER_ENTITY_TABLE_NAME || ' ' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .UPPER_ENTITY_TABLE_ALIAS ||
                                           ' ON (' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .UPPER_ENTITY_TABLE_ALIAS ||
                                           '.E_INTERNAL_ID = ' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .RELATIONSHIP_TABLE_ALIAS || '.' || PI_ALIGNED_ENTITIES_OBJECT(I).ENTITY_HIERARCHY_INFO(J)
                                          .UPPER_ENTITY_COLUMN_NAME || ')';
          END LOOP;

          -- Replace the 1st "LEFT OUTER" with "INNER" so that the Hierarchy is considered while computing Aligned Entity values.
          v_Aligned_Ent_Via_Hier_FROM := REGEXP_REPLACE(v_Aligned_Ent_Via_Hier_FROM,
                                                        'LEFT OUTER',
                                                        'INNER',
                                                        1,
                                                        1);
        END IF; -- (PI_ALIGNED_ENTITIES_OBJECT ( I).ALIGNMENT_METHOD_OPTION = 4 AND PI_ALIGNED_ENTITIES_OBJECT ( I).ENTITY_HIERARCHY_INFO IS NOT NULL)

        -- OF-7719 and OF-7722 - END

        -- OF-9829 -- START -- Restructuring formation of v_Aligned_FROM to add ' CROSS JOIN ' or ' INNER JOIN ' conditionally
        -- Form the Aligned FROM clause part
        v_Aligned_FROM := CASE
                            WHEN PI_ALIGNED_ENTITIES_OBJECT(I)
                             .ALIGNMENT_METHOD_OPTION = 1 /*1 = ALIGNED ENTITY VIA SPECIFIED VALUES*/
                             THEN
                            /*OF-9829 - START*/
                             ' CROSS JOIN ' || v_Aligned_Table_Name || ' ' ||
                             v_Aligned_Entity_Table_Alias
                            WHEN PI_ALIGNED_ENTITIES_OBJECT(I)
                             .ALIGNMENT_METHOD_OPTION = 2 /*2 = ALIGNED ENTITY VIA ASSIGNMENT TABLE BETWEEN ALIGNED ENTITY AND ALIGNMENT ENTITY*/
                             THEN
                             ' INNER JOIN ' || v_Assignment_Table_Name || ' ' ||
                             v_Assignment_Table_Alias || ' ON (' ||
                             v_Assignment_Table_Alias || '.' ||
                             v_Alignment_ENTITY_COL_NAME || ' = ' ||
                             v_Alignment_Entity_Table_Alias ||
                             '.E_INTERNAL_ID)
                             INNER JOIN ' ||
                             v_Aligned_Table_Name || ' ' ||
                             v_Aligned_Entity_Table_Alias || ' ON (' ||
                             v_Aligned_Entity_Table_Alias || '.E_INTERNAL_ID = ' ||
                             v_Assignment_Table_Alias || '.' ||
                             v_Aligned_Entity_Column_Name || ')'
                          /*OF-9829 - END*/
                            WHEN PI_ALIGNED_ENTITIES_OBJECT(I)
                             .ALIGNMENT_METHOD_OPTION = 3 /*3 = ALIGNED ENTITY VIA ASSIGNMENT TABLE BETWEEN ALIGNED ENTITY AND ANOTHER ENTITY*/
                             THEN
                            -- OF-9829 -- START -- Adding ' CROSS JOIN ' here and removing it while appending to form final FROM Clause
                             ' CROSS JOIN ' || v_Aligned_Table_Name || ' ' ||
                             v_Aligned_Entity_Table_Alias || /*OF-9829 - END*/
                             ' INNER JOIN ' || v_Assignment_Table_Name || ' ' ||
                             v_Assignment_Table_Alias || ' ON (' ||
                             v_Assignment_Table_Alias || '.' ||
                             v_Aligned_Entity_Column_Name || ' = ' ||
                             v_Aligned_Entity_Table_Alias ||
                             '.E_INTERNAL_ID)
                             INNER JOIN ' ||
                             v_Assigned_Entity_Table_Name || ' ' ||
                             v_Assigned_Entity_Table_Alias || ' ON (' ||
                             v_Assigned_Entity_Table_Alias || '.E_INTERNAL_ID = ' ||
                             v_Assignment_Table_Alias || '.' ||
                             v_Assigned_Entity_Column_Name || ')'
                            WHEN PI_ALIGNED_ENTITIES_OBJECT(I)
                             .ALIGNMENT_METHOD_OPTION = 4 /*4 = ALIGNED ENTITY HIERARCHY TABLE*/
                            -- OF-7719 and OF-7722
                             THEN
                            -- OF-9829 -- START -- Adding ' CROSS JOIN ' here and removing it while appending to form final FROM Clause
                             ' CROSS JOIN ' || v_Aligned_Table_Name || ' ' ||
                             v_Aligned_Entity_Table_Alias || /*OF-9829 - END*/
                             v_Aligned_Ent_Via_Hier_FROM -- OF-7719 and OF-7722
                          END;
        -- OF-9829 -- END

        -- Append the Aligned FROM Clause part
        -- OF-7719 and OF-7722 START
        -- v_From                        := v_From || v_Aligned_FROM || ' CROSS JOIN ';
        -- OF-9829 -- START -- Removing ' CROSS JOIN ' from here and adding it conditionally while creating v_Aligned_FROM
        -- v_Aligned_FROM_TOTAL          := v_Aligned_FROM_TOTAL || v_Aligned_FROM || ' CROSS JOIN ';
        v_Aligned_FROM_TOTAL := v_Aligned_FROM_TOTAL || v_Aligned_FROM;

        -- OF-9829 -- END
        -- OF-7719 and OF-7722 END

        -- Form the Assignment Table Date Range clause part
        IF PI_ALIGNED_ENTITIES_OBJECT(I).ALIGNMENT_METHOD_OPTION IN (2, 3) THEN
          CASE PI_ALIGNED_ENTITIES_OBJECT(I).DATE_RANGE_OPTION
            WHEN 1 --1 = FIRST DAY
             THEN
              v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
              v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
            WHEN 2 --2 = LAST DAY
             THEN
              v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
              v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
            WHEN 3 --3 = ANY DAY
             THEN
              v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
              v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
            WHEN 4 --4 = EVERY DAY
             THEN
              v_ENTITY_DATE_RANGE_PART_1 := '  ((NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) >= NVL(TO_DATE(''';
              v_ENTITY_DATE_RANGE_PART_2 := ' AND (NVL(TO_DATE (' ||
                                            v_Assignment_Table_Alias ||
                                            '.END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) <= NVL(TO_DATE(''';
            ELSE
              v_ENTITY_DATE_RANGE_PART_1 := NULL;
              v_ENTITY_DATE_RANGE_PART_2 := NULL;
          END CASE;

          IF PI_ALIGNED_ENTITIES_OBJECT(I).DATE_RANGE_OPTION IS NOT NULL THEN
            -- Set values
            V_DATE_RANGE_INTERNAL_OBJECT.EXTEND;
            v_counter := V_DATE_RANGE_INTERNAL_OBJECT.COUNT;
            V_DATE_RANGE_INTERNAL_OBJECT(v_counter) := OBJTYPE_DATE_RANGE_INTERNAL(ENTITY_COLUMN_NAME       => v_Aligned_Entity_Column_Name,
                                                                                   RELATIONSHIP_TABLE_ALIAS => v_Assignment_Table_Alias, -- OF-8890
                                                                                   ENTITY_DATE_RANGE_PART_1 => v_ENTITY_DATE_RANGE_PART_1,
                                                                                   ENTITY_DATE_RANGE_PART_2 => v_ENTITY_DATE_RANGE_PART_2);
          END IF;
        END IF; -- PI_ALIGNED_ENTITIES_OBJECT ( I).ALIGNMENT_METHOD_OPTION IN (2, 3)

        -- Form the Aligned v_AND_Entities_Clause and v_AND_Dual_Aligned_Clause
        v_AND_Entities_Clause     := v_AND_Entities_Clause || ' AND A.' ||
                                     v_Aligned_EIntId_Alias || ' = B.' ||
                                     v_Aligned_EIntId_Alias;
        v_AND_Dual_Aligned_Clause := v_AND_Dual_Aligned_Clause || ' AND A.' ||
                                     v_Aligned_EIntId_Alias || ' = B.' ||
                                     v_Aligned_EIntId_Alias;
      END LOOP;

      -- Trimming the Extra ", " from Where clauses
      v_Aligned_EIntId_Alias_List := SUBSTR(v_Aligned_EIntId_Alias_List,
                                            1,
                                            (LENGTH(v_Aligned_EIntId_Alias_List) - 2));

      --------------------------------------- PART 1 :SETTING INTERNAL CONDITIONS OBJECT ----------------------------------------------------------------
      -- 3. Loop through the Conditions object for each Condition ID
      FOR J IN 1 .. PI_CONDITIONS_OBJECT.COUNT LOOP
        V_CONDITIONS_INTERNAL_OBJECT.EXTEND;
        V_NEEDED                   := 0;
        v_WHERE_BOTH               := NULL;
        v_WHERE_Include_Of_Exclude := NULL;
        v_CONDITION_IS_EXCLUDE     := 0; -- 0= Include, And we set by default Include
        -- OF-3403
        v_DATE_RANGE_CLAUSE           := NULL;
        v_ALIGNMENT_FLT_VIA_HIERARCHY := 0; -- OF-7719 and OF-7722  ALIGNMENT_FLT_VIA_HIERARCHY

        -- 4. Loop through the Filters object for each Filter ID
        FOR I IN 1 .. PI_FILTERS_OBJECT.COUNT LOOP
          v_Exclude_FOR_BOTH      := NULL;
          v_Exclude_FOR_EXCLUDE   := NULL;
          v_Exclude_FOR_ALIGNMENT := NULL;

          -- OF-4022 and OF-10094 - START
          -- v_AND_Filter_Clause     := NULL;
          v_AND_Filter_Clause_INCLUDE := NULL;
          v_AND_Filter_Clause_EXCLUDE := NULL;

          -- OF-4022 and OF-10094 - END

          -- Depending on Filter Criteria (1-INCLUDE, 2 -EXCLUDE, 3-ALL), Set Variable
          IF (PI_FILTERS_OBJECT(I).LOGIC_CONDITION_ID = PI_CONDITIONS_OBJECT(J)
             .LOGIC_CONDITION_ID) THEN
            -- IF_2 START
            -- OF-7719 and OF-7722 and OF-8890 -- START
            IF PI_FILTERS_OBJECT(I).ENTITY_TYPE = 1 -- Alignment Entity
             THEN
              -- OF-7719 and OF-7722 -- START
              -- Set flag to 1 if the Alignment Entity filter is based on Hierarchy else set it to 0; irrespective whether or not Aligned Entities are based on Hierarchy
              v_ALIGNMENT_FLT_VIA_HIERARCHY := PI_FILTERS_OBJECT(I)
                                               .ALIGNMENT_FLT_VIA_HIERARCHY;

              -- OF-8890 - START
              IF v_ALIGNMENT_FLT_VIA_HIERARCHY = 1 THEN
                -- OF-4022 and OF-10094 - START
                -- V_FILTER_EVALUATION := GET_MODIFIED_HIERARCHY_FILTER(PI_FILTERS_OBJECT(I).FILTER_EVALUATION);
                V_FILTER_EVALUATION_INCLUDE := GET_MODIFIED_HIERARCHY_FILTER(PI_FILTERS_OBJECT(I)
                                                                             .FILTER_EVALUATION_INCLUDE);
                V_FILTER_EVALUATION_EXCLUDE := GET_MODIFIED_HIERARCHY_FILTER(PI_FILTERS_OBJECT(I)
                                                                             .FILTER_EVALUATION_EXCLUDE);
                -- OF-4022 and OF-10094 - END

                -- OF-9829 -- START -- V_ALIGNMENT_FILTER_EVALUATION is not needed any more as per the required change
                -- V_ALIGNMENT_FILTER_EVALUATION := GET_MODIFIED_HIERARCHY_FILTER ( PI_FILTERS_OBJECT ( I).ALIGNMENT_FILTER_EVALUATION);
                -- OF-9829 -- END
              ELSE
                -- OF-4022 and OF-10094 - START
                -- V_FILTER_EVALUATION := PI_FILTERS_OBJECT(I).FILTER_EVALUATION;
                V_FILTER_EVALUATION_INCLUDE := PI_FILTERS_OBJECT(I)
                                               .FILTER_EVALUATION_INCLUDE;
                V_FILTER_EVALUATION_EXCLUDE := PI_FILTERS_OBJECT(I)
                                               .FILTER_EVALUATION_EXCLUDE;
                -- OF-4022 and OF-10094 - END

                -- OF-9829 -- START -- V_ALIGNMENT_FILTER_EVALUATION is not needed any more as per the required change
                -- V_ALIGNMENT_FILTER_EVALUATION := PI_FILTERS_OBJECT ( I).ALIGNMENT_FILTER_EVALUATION;
                -- OF-9829 -- END
              END IF;
              -- OF-8890 - END

            ELSE
              -- Aligned Entities
              -- OF-8890 - START
              -- Initializing v_ALIGNED_FLT_VIA_HIERARCHY
              v_ALIGNED_FLT_VIA_HIERARCHY := 0;

              <<L1>>
              FOR C IN 1 .. PI_ALIGNED_ENTITIES_OBJECT.COUNT LOOP
                IF (PI_ALIGNED_ENTITIES_OBJECT(C).ENTITY_COLUMN_NAME = PI_FILTERS_OBJECT(I)
                   .ENTITY_COLUMN_NAME) THEN
                  IF PI_ALIGNED_ENTITIES_OBJECT(C)
                   .ALIGNMENT_METHOD_OPTION = 4 THEN
                    v_ALIGNED_FLT_VIA_HIERARCHY := 1;
                  ELSE
                    v_ALIGNED_FLT_VIA_HIERARCHY := 0;
                  END IF;

                  -- Break LOOP once the Filter for corresponding Entity is parsed.
                  EXIT L1;
                END IF;
              END LOOP L1;

              IF v_ALIGNED_FLT_VIA_HIERARCHY = 1 THEN
                -- OF-4022 and OF-10094 - START
                -- V_FILTER_EVALUATION := GET_MODIFIED_HIERARCHY_FILTER(PI_FILTERS_OBJECT(I).FILTER_EVALUATION);
                V_FILTER_EVALUATION_INCLUDE := GET_MODIFIED_HIERARCHY_FILTER(PI_FILTERS_OBJECT(I)
                                                                             .FILTER_EVALUATION_INCLUDE);
                V_FILTER_EVALUATION_EXCLUDE := GET_MODIFIED_HIERARCHY_FILTER(PI_FILTERS_OBJECT(I)
                                                                             .FILTER_EVALUATION_EXCLUDE);
                -- OF-4022 and OF-10094 - END

                -- OF-9829 -- START -- V_ALIGNMENT_FILTER_EVALUATION is not needed any more as per the required change
                -- V_ALIGNMENT_FILTER_EVALUATION := GET_MODIFIED_HIERARCHY_FILTER ( PI_FILTERS_OBJECT ( I).ALIGNMENT_FILTER_EVALUATION);
                -- OF-9829 -- END
              ELSE
                -- OF-4022 and OF-10094 - START
                -- V_FILTER_EVALUATION := PI_FILTERS_OBJECT(I).FILTER_EVALUATION;
                V_FILTER_EVALUATION_INCLUDE := PI_FILTERS_OBJECT(I)
                                               .FILTER_EVALUATION_INCLUDE;
                V_FILTER_EVALUATION_EXCLUDE := PI_FILTERS_OBJECT(I)
                                               .FILTER_EVALUATION_EXCLUDE;
                -- OF-4022 and OF-10094 - END

                -- OF-9829 -- START -- V_ALIGNMENT_FILTER_EVALUATION is not needed any more as per the required change
                -- V_ALIGNMENT_FILTER_EVALUATION := PI_FILTERS_OBJECT ( I).ALIGNMENT_FILTER_EVALUATION;
                -- OF-9829 -- END
              END IF;
              -- OF-8890 - END
            END IF;

            -- OF-7719 and OF-7722 and OF-8890 -- END

            -- OF-3403
            IF PI_FILTERS_OBJECT(I).FILTER_CRITERIA = 2 -- 2 = EXCLUDE
             THEN
              -- IF_4 START
              v_Exclude_FOR_BOTH     := ' NOT';
              v_CONDITION_IS_EXCLUDE := 1;

              IF PI_FILTERS_OBJECT(I).ENTITY_TYPE = 1 THEN
                -- IF_5 START  -- 1 = ALIGNMENT ENTITY
                v_Exclude_FOR_EXCLUDE := ' NOT';
              ELSE
                v_Exclude_FOR_EXCLUDE := NULL;
                V_NEEDED              := 1;
              END IF; -- IF_5 END
            ELSE
              v_Exclude_FOR_BOTH    := NULL;
              v_Exclude_FOR_EXCLUDE := NULL;
              --v_CONDITION_IS_EXCLUDE := 0;
            END IF; -- IF_4 END

            /* -- OF-9829 -- START -- ALIGNMENT_FILTER_EVALUATION and related parts not needed any more as per the required change
            -- Set ' NOT' clause for ALIGNMENT_FILTER_EVALUATION
            IF PI_FILTERS_OBJECT(I).ALIGNMENT_FILTER_CRITERIA = 2 -- 2 = EXCLUDE
            THEN
              -- IF_6 START
              v_Exclude_FOR_ALIGNMENT := ' NOT';
            ELSE
              v_Exclude_FOR_ALIGNMENT := NULL;
            END IF; -- IF_6 END
            OF-9829 -- END */

            /* END IF;  -- IF_3 END */
            -- OF-3403

            /* -- OF-9829 -- START -- V_ALIGNMENT_FILTER_EVALUATION is not needed any more as per the required change
            -- Form AND Clause for ALIGNMENT_FILTER_EVALUATION
            v_AND_Alignment_Filter_Clause      :=
              CASE
                WHEN V_ALIGNMENT_FILTER_EVALUATION IS NULL THEN NULL
                ELSE v_Exclude_FOR_ALIGNMENT || '(' || V_ALIGNMENT_FILTER_EVALUATION || ') ' || 'AND '
              END;
            OF-9829 -- END */

            -- Form AND Clause for FILTER_EVALUATION
            -- OF-4022 and OF-10094 - START
            -- v_AND_Filter_Clause := CASE WHEN V_FILTER_EVALUATION_INCLUDE IS NULL THEN NULL ELSE '(' || V_FILTER_EVALUATION_INCLUDE || ') ' || 'AND ' END;
            v_AND_Filter_Clause_INCLUDE := CASE
                                             WHEN V_FILTER_EVALUATION_INCLUDE IS NULL THEN
                                              NULL
                                             ELSE
                                              '(' || V_FILTER_EVALUATION_INCLUDE || ') ' ||
                                              'AND '
                                           END;
            v_AND_Filter_Clause_EXCLUDE := CASE
                                             WHEN V_FILTER_EVALUATION_EXCLUDE IS NULL THEN
                                              NULL
                                             ELSE
                                              '(' || V_FILTER_EVALUATION_EXCLUDE || ') ' ||
                                              'AND '
                                           END;
            -- OF-4022 and OF-10094 - END

            v_DATE_RANGE_CLAUSE := NULL; -- /*AV - Initializing*/

            --  Loop through Date Range Internal object
            FOR K IN 1 .. V_DATE_RANGE_INTERNAL_OBJECT.COUNT LOOP
              v_DATE_RANGE_CLAUSE :=-- AV /* OF-8890 - START */
               v_DATE_RANGE_CLAUSE || -- AV /* OF-8890 - END */
                                     CASE
                                     -- AV /* OF-11132 - START */
                                     -- WHEN V_DATE_RANGE_INTERNAL_OBJECT(K).ENTITY_COLUMN_NAME = PI_FILTERS_OBJECT(I).ENTITY_COLUMN_NAME
                                       WHEN (V_DATE_RANGE_INTERNAL_OBJECT(K)
                                            .ENTITY_COLUMN_NAME = PI_FILTERS_OBJECT(I).ENTITY_COLUMN_NAME AND
                                             ((PI_FILTERS_OBJECT(I)
                                             .ENTITY_TYPE = 1 AND v_ALIGNMENT_FLT_VIA_HIERARCHY = 1) OR
                                             (PI_FILTERS_OBJECT(I).ENTITY_TYPE = 2)))
                                       -- AV /* OF-11132 - END */
                                        THEN
                                        V_DATE_RANGE_INTERNAL_OBJECT(K)
                                        .ENTITY_DATE_RANGE_PART_1 || PI_CONDITIONS_OBJECT(J).EFFECTIVE_START_DATE ||
                                         ''', ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')))' || V_DATE_RANGE_INTERNAL_OBJECT(K)
                                        .ENTITY_DATE_RANGE_PART_2 || PI_CONDITIONS_OBJECT(J).EFFECTIVE_END_DATE ||
                                         ''', ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR''))))' ||
                                         ' AND '
                                       ELSE
                                        NULL
                                     END;
              -- AV /* OF-8890 - START */
            --V_ALIAS_oN_CLAUSE := '(' || V_DATE_RANGE_INTERNAL_OBJECT ( K).RELATIONSHIP_TABLE_ALIAS || ' ON \()';
            --V_MOD_ON_CLAUSE   := '\1 ' || V_DATE_RANGE_CLAUSE;
            --V_ALIAS_oN_CLAUSE := V_DATE_RANGE_INTERNAL_OBJECT ( K).RELATIONSHIP_TABLE_ALIAS || ' ON \(';

            /*
                          -- INSERT_LOGS ('V_DATE_RANGE_INTERNAL_OBJECT ( K).ENTITY_COLUMN_NAME = ' || V_DATE_RANGE_INTERNAL_OBJECT ( K).ENTITY_COLUMN_NAME || '   -- v_DATE_RANGE_CLAUSE = ' || v_DATE_RANGE_CLAUSE);
                        IF V_DATE_RANGE_CLAUSE IS NOT NULL
                        THEN
                          V_ALIAS_oN_CLAUSE := ' ON \(' || V_DATE_RANGE_INTERNAL_OBJECT ( K).RELATIONSHIP_TABLE_ALIAS;
                          V_MOD_ON_CLAUSE   := ' ON ( ' || V_DATE_RANGE_CLAUSE || V_DATE_RANGE_INTERNAL_OBJECT ( K).RELATIONSHIP_TABLE_ALIAS;

                          v_Alignment_Ent_Via_Hier_FROM      :=
                            REGEXP_REPLACE (v_Alignment_Ent_Via_Hier_FROM,
                                            V_ALIAS_oN_CLAUSE,
                                            V_MOD_ON_CLAUSE,
                                            1,
                                            1);
                          v_Aligned_FROM_TOTAL      :=
                            REGEXP_REPLACE (v_Aligned_FROM_TOTAL,
                                            V_ALIAS_oN_CLAUSE,
                                            V_MOD_ON_CLAUSE,
                                            1,
                                            1);
                          -- INSERT_LOGS (' v_Alignment_Ent_Via_Hier_FROM( ' || k || ') = '|| v_Alignment_Ent_Via_Hier_FROM);
                          -- INSERT_LOGS (' v_Aligned_FROM_TOTAL( ' || k || ') = '|| v_Aligned_FROM_TOTAL);
                        END IF;
                      -- AV /* OF-8890 - END */
            END LOOP;

            -- AV /* OF-8890 - START */
            -- Form the WHERE clauses
            -- OF-4022 and OF-10094 - START
            -- v_WHERE_BOTH        := v_WHERE_BOTH || v_AND_Alignment_Filter_Clause || v_Exclude_FOR_BOTH || v_AND_Filter_Clause || v_DATE_RANGE_CLAUSE;
            -- v_WHERE_Include_Of_Exclude      :=  v_WHERE_Include_Of_Exclude || v_AND_Alignment_Filter_Clause || v_Exclude_FOR_EXCLUDE || v_AND_Filter_Clause || v_DATE_RANGE_CLAUSE;
            v_AND_Filter_Clause_BOTH := CASE
                                          WHEN v_AND_Filter_Clause_EXCLUDE IS NOT NULL THEN
                                           v_AND_Filter_Clause_EXCLUDE
                                          ELSE
                                           v_AND_Filter_Clause_INCLUDE
                                        END;
            v_WHERE_BOTH               := v_WHERE_BOTH ||
                                          v_AND_Alignment_Filter_Clause ||
                                          v_AND_Filter_Clause_BOTH ||
                                          v_DATE_RANGE_CLAUSE;
            v_WHERE_Include_Of_Exclude := v_WHERE_Include_Of_Exclude ||
                                          v_AND_Alignment_Filter_Clause ||
                                          v_AND_Filter_Clause_INCLUDE ||
                                          v_DATE_RANGE_CLAUSE;
            -- OF-4022 and OF-10094 - END
            -- AV /* OF-8890 - END */

          END IF; -- IF_2 END
        END LOOP; -- PI_FILTERS_OBJECT

        IF V_NEEDED = 0 THEN
          v_WHERE_Include_Of_Exclude := NULL;
        END IF;

        -- Trimming the Extra " AND " from Where clauses
        v_WHERE_BOTH               := SUBSTR(v_WHERE_BOTH,
                                             1,
                                             (LENGTH(v_WHERE_BOTH) - 5));
        v_WHERE_Include_Of_Exclude := SUBSTR(v_WHERE_Include_Of_Exclude,
                                             1,
                                             (LENGTH(v_WHERE_Include_Of_Exclude) - 5));

        IF v_CONDITION_IS_EXCLUDE = 1 -- If condition belongs to EXCLUDE type
         THEN
          v_ALIAS_FOR_BOTH               := 'C' || PI_CONDITIONS_OBJECT(J)
                                           .LOGIC_CONDITION_ID ||
                                            '_EXCLUDE';
          v_ALIAS_FOR_Include_Of_Exclude := 'C' || PI_CONDITIONS_OBJECT(J)
                                           .LOGIC_CONDITION_ID ||
                                            '_Include_Of_Exclude';
        ELSE
          -- If condition belongs to INCLUDE type
          v_ALIAS_FOR_BOTH               := 'C' || PI_CONDITIONS_OBJECT(J)
                                           .LOGIC_CONDITION_ID ||
                                            '_INCLUDE';
          v_ALIAS_FOR_Include_Of_Exclude := NULL;
        END IF;

        -- Set values
        V_CONDITIONS_INTERNAL_OBJECT(J) := OBJTYPE_CONDITIONS_INTERNAL(LOGIC_CONDITION_ID           => PI_CONDITIONS_OBJECT(J)
                                                                                                       .LOGIC_CONDITION_ID,
                                                                       LOGIC_CONDITION_TEXT         => PI_CONDITIONS_OBJECT(J)
                                                                                                       .LOGIC_CONDITION_TEXT,
                                                                       EFFECTIVE_START_DATE         => PI_CONDITIONS_OBJECT(J)
                                                                                                       .EFFECTIVE_START_DATE, --NVL (PI_CONDITIONS_OBJECT (J).EFFECTIVE_START_DATE, TO_DATE ('01/01/1900', 'DD/MM/RRRR')),
                                                                       EFFECTIVE_END_DATE           => PI_CONDITIONS_OBJECT(J)
                                                                                                       .EFFECTIVE_END_DATE, --NVL (PI_CONDITIONS_OBJECT (J).EFFECTIVE_END_DATE, TO_DATE ('31/12/9999', 'DD/MM/RRRR')),
                                                                       ALLOCATION                   => CASE
                                                                                                         WHEN v_ALLOCATION_COL IS NULL THEN
                                                                                                          NULL
                                                                                                         ELSE
                                                                                                          PI_CONDITIONS_OBJECT(J).ALLOCATION
                                                                                                       END,
                                                                       CONDITION_IS_EXCLUDE         => v_CONDITION_IS_EXCLUDE,
                                                                       COND_FOR_BOTH                => v_COND_FOR_BOTH, -- OF-8890
                                                                       COND_FOR_INCLUDE_OF_EXCLUDE  => v_COND_FOR_INCLUDE_OF_EXCLUDE, -- OF-8890
                                                                       WHERE_FOR_BOTH               => v_WHERE_BOTH,
                                                                       WHERE_FOR_INCLUDE_OF_EXCLUDE => v_WHERE_Include_Of_Exclude,
                                                                       ALIAS_FOR_BOTH               => v_ALIAS_FOR_BOTH,
                                                                       ALIAS_FOR_INCLUDE_OF_EXCLUDE => v_ALIAS_FOR_Include_Of_Exclude,
                                                                       ALIGNMENT_FLT_VIA_HIERARCHY  => v_ALIGNMENT_FLT_VIA_HIERARCHY); -- OF-7719 and OF-7722 Added ALIGNMENT_FLT_VIA_HIERARCHY
      END LOOP; -- PI_CONDITIONS_OBJECT

      -- INSERT_LOGS (' v_Alignment_Ent_Via_Hier_FROM = '|| v_Alignment_Ent_Via_Hier_FROM);
      -- INSERT_LOGS (' v_Aligned_FROM_TOTAL = '|| v_Aligned_FROM_TOTAL);

      --------------------------------------- PART 1 : END : SETTING INTERNAL CONDITIONS OBJECT ----------------------------------------------------------------
      -- Initializing Final Clauses
      v_WHERE_BOTH               := ' WHERE (';
      v_WHERE_Include_Of_Exclude := ' OR (';

      -- INSERT_LOGS ( PI_CLOB => 'end of obj');

      -- testing -- logging object - end

      -- Set flags if Hierarchy and Non-Hierarchy based parts are needed.
      -- OF-8834 - START
      SELECT COUNT(DISTINCT CASE
                     WHEN NVL(ALIGNMENT_FLT_VIA_HIERARCHY, 0) = 0 THEN
                      1
                   END) Count_1,
             COUNT(DISTINCT CASE
                     WHEN ALIGNMENT_FLT_VIA_HIERARCHY = 1 THEN
                      1
                   END) Count_2
        INTO V_Count_1, V_Count_2
        FROM TABLE(V_CONDITIONS_INTERNAL_OBJECT);

      -- OF-8834 - END
      -- INSERT_LOGS ( PI_CLOB => ' -- Count_1 = ' || V_Count_1 || ' -- Count_2 = ' || V_Count_2);

      IF V_Count_1 > 0 THEN
        v_WHERE_BOTH_1               := v_WHERE_BOTH;
        v_WHERE_Include_Of_Exclude_1 := v_WHERE_Include_Of_Exclude;
        v_Select_Total_Set_1         := v_Select_Total_Set;
      END IF;

      IF V_Count_2 > 0 THEN
        v_WHERE_BOTH_2               := v_WHERE_BOTH;
        v_WHERE_Include_Of_Exclude_2 := v_WHERE_Include_Of_Exclude;
        v_Select_Total_Set_2         := v_Select_Total_Set;
      END IF;

      -- Iterating V_CONDITIONS_INTERNAL_OBJECT
      FOR J IN 1 .. V_CONDITIONS_INTERNAL_OBJECT.COUNT LOOP
        -- OF-7719 and OF-7722 -- START
        -- Form all clauses to distribute them either Hierarchy based or Non-Hierarchy based using ALIGNMENT_FLT_VIA_HIERARCHY
        IF V_CONDITIONS_INTERNAL_OBJECT(J).ALIGNMENT_FLT_VIA_HIERARCHY = 1 THEN
          -- Hierarchy based
          v_WHERE_BOTH               := v_WHERE_BOTH_2;
          v_WHERE_Include_Of_Exclude := v_WHERE_Include_Of_Exclude_2;
          v_Select_Total_Set         := v_Select_Total_Set_2;
          -- v_SQL_Include_Of_Exclude_Set := v_SQL_Include_Of_Exclude_Set_2;
          -- v_SQL_BOTH_Set := v_SQL_BOTH_Set_2;
        ELSE
          -- Non Hierarchy based
          v_WHERE_BOTH               := v_WHERE_BOTH_1;
          v_WHERE_Include_Of_Exclude := v_WHERE_Include_Of_Exclude_1;
          v_Select_Total_Set         := v_Select_Total_Set_1;
          -- v_SQL_Include_Of_Exclude_Set := v_SQL_Include_Of_Exclude_Set_1;
          -- v_SQL_BOTH_Set := v_SQL_BOTH_Set_1;
        END IF;

        -- OF-7719 and OF-7722 -- END
        -- Form final WHERE Clauses
        v_WHERE_BOTH := TO_CLOB(v_WHERE_BOTH || V_CONDITIONS_INTERNAL_OBJECT(J)
                                .WHERE_FOR_BOTH || ') OR (');

        v_WHERE_Include_Of_Exclude := CASE
                                        WHEN (V_CONDITIONS_INTERNAL_OBJECT(J)
                                             .CONDITION_IS_EXCLUDE = 1) THEN
                                         TO_CLOB(v_WHERE_Include_Of_Exclude || V_CONDITIONS_INTERNAL_OBJECT(J)
                                                 .WHERE_FOR_Include_Of_Exclude ||
                                                 ') OR (')
                                        ELSE
                                         v_WHERE_Include_Of_Exclude
                                      END;
        -- Append Conditions to SELECT Clauses
        v_Select_Total_Set  := v_Select_Total_Set || 'CASE WHEN ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                              .WHERE_FOR_BOTH /* || V_CONDITIONS_INTERNAL_OBJECT ( J).COND_FOR_BOTH     -- OF-8890  */
                               || ' THEN 1 ELSE 0 END ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                              .ALIAS_FOR_BOTH || ', ';
        v_Select_Conditions := V_CONDITIONS_INTERNAL_OBJECT(J)
                               .LOGIC_CONDITION_ID || ' ' || 'CONDITION_ID' ||
                                ', ''' || V_CONDITIONS_INTERNAL_OBJECT(J)
                               .LOGIC_CONDITION_TEXT || ''' CONDITION_TEXT' || ', ' ||
                                'CAST (''' || V_CONDITIONS_INTERNAL_OBJECT(J)
                               .EFFECTIVE_START_DATE || ''' AS DATE)' ||
                                ' EFFECTIVE_START_DATE' || ', ' || 'CAST (''' || V_CONDITIONS_INTERNAL_OBJECT(J)
                               .EFFECTIVE_END_DATE || ''' AS DATE)' ||
                                ' EFFECTIVE_END_DATE' || ', ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                               .ALLOCATION || CASE
                                  WHEN V_CONDITIONS_INTERNAL_OBJECT(J)
                                   .ALLOCATION IS NULL THEN
                                   NULL
                                  ELSE
                                   '/ 100'
                                END || ' ' || v_ALLOCATION_COL || V_CONDITIONS_INTERNAL_OBJECT(J)
                               .CONDITION_IS_EXCLUDE || ' ' ||
                                'CONDITION_IS_EXCLUDE';

        IF (V_CONDITIONS_INTERNAL_OBJECT(J).CONDITION_IS_EXCLUDE = 1) THEN
          v_Select_Total_Set           := v_Select_Total_Set ||
                                          'CASE WHEN ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                         .WHERE_FOR_Include_Of_Exclude /* || V_CONDITIONS_INTERNAL_OBJECT ( J).COND_FOR_INCLUDE_OF_EXCLUDE   -- OF-8890  */
                                          || ' THEN 1 ELSE 0 END ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                         .ALIAS_FOR_Include_Of_Exclude || ', ';
          v_SQL_Include_Of_Exclude_Set := v_SQL_Include_Of_Exclude_Set ||
                                          v_Select_Include_Of_Exclude ||
                                          v_Select_Conditions || ' FROM ' ||
                                          v_Total_Set_Table || ' WHERE ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                         .ALIAS_FOR_Include_Of_Exclude ||
                                          ' = 1 UNION ALL ';
        END IF;

        v_SQL_BOTH_Set := v_SQL_BOTH_Set || v_Select_Both ||
                          v_Select_Conditions || ' FROM ' ||
                          v_Total_Set_Table || ' WHERE ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                         .ALIAS_FOR_BOTH || ' = 1 UNION ALL ';

        -- OF-7719 and OF-7722 -- START
        -- Form all clauses to distribute them either Hierarchy based or Non-Hierarchy based using ALIGNMENT_FLT_VIA_HIERARCHY
        IF V_CONDITIONS_INTERNAL_OBJECT(J).ALIGNMENT_FLT_VIA_HIERARCHY = 1 THEN
          -- Hierarchy based
          v_WHERE_BOTH_2               := v_WHERE_BOTH;
          v_WHERE_Include_Of_Exclude_2 := v_WHERE_Include_Of_Exclude;

          -- No OF-id, internal testing post fix for OF-8834 -- START
          IF V_Count_1 > 0 THEN
            v_Select_Total_Set_1 := v_Select_Total_Set_1 || '0 ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                   .ALIAS_FOR_BOTH || ', ' || CASE
                                      WHEN (V_CONDITIONS_INTERNAL_OBJECT(J)
                                           .CONDITION_IS_EXCLUDE = 1) THEN
                                       '0 ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                      .ALIAS_FOR_Include_Of_Exclude || ', '
                                    END;
          END IF; -- IF V_Count_1 > 0

          -- No OF-id, internal testing post fix for OF-8834 -- END

          v_Select_Total_Set_2 := v_Select_Total_Set;
          -- v_SQL_Include_Of_Exclude_Set_2 := v_SQL_Include_Of_Exclude_Set;
          -- v_SQL_BOTH_Set_2 := v_SQL_BOTH_Set;
        ELSE
          -- Non Hierarchy based
          v_WHERE_BOTH_1               := v_WHERE_BOTH;
          v_WHERE_Include_Of_Exclude_1 := v_WHERE_Include_Of_Exclude;
          v_Select_Total_Set_1         := v_Select_Total_Set;

          -- No OF-id, internal testing post fix for OF-8834 -- START
          IF V_Count_2 > 0 THEN
            v_Select_Total_Set_2 := v_Select_Total_Set_2 || '0 ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                   .ALIAS_FOR_BOTH || ', ' || CASE
                                      WHEN (V_CONDITIONS_INTERNAL_OBJECT(J)
                                           .CONDITION_IS_EXCLUDE = 1) THEN
                                       '0 ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                      .ALIAS_FOR_Include_Of_Exclude || ', '
                                    END;
          END IF; -- IF V_Count_2 > 0
          -- No OF-id, internal testing post fix for OF-8834 -- END

          -- v_SQL_Include_Of_Exclude_Set_1 := v_SQL_Include_Of_Exclude_Set;
          -- v_SQL_BOTH_Set_1 := v_SQL_BOTH_Set;
        END IF;

        -- OF-7719 and OF-7722 -- END

        -- No OF-id, internal testing post fix for OF-8834
        v_Select_Total_Set_FINAL := v_Select_Total_Set_FINAL || ' SUM(' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                   .ALIAS_FOR_BOTH || ') ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                   .ALIAS_FOR_BOTH || ', ' || CASE
                                      WHEN (V_CONDITIONS_INTERNAL_OBJECT(J)
                                           .CONDITION_IS_EXCLUDE = 1) THEN
                                       ' SUM(' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                      .ALIAS_FOR_Include_Of_Exclude || ') ' || V_CONDITIONS_INTERNAL_OBJECT(J)
                                      .ALIAS_FOR_Include_Of_Exclude || ', '
                                    END;
      END LOOP;

      -----------------------------------------------------------------------------------------------------------------------------------------------------
      -- OF-7719 and OF-7722 START

      IF V_Count_1 > 0 THEN
        -- Trimming the Extra ", " once the complete SELECT Clause is ready
        v_Select_Total_Set_1 := SUBSTR(v_Select_Total_Set_1,
                                       1,
                                       (LENGTH(v_Select_Total_Set_1) - 2));
        -- Trimming the Extra " OR (" from WHERE clauses
        v_WHERE_BOTH_1               := SUBSTR(v_WHERE_BOTH_1,
                                               1,
                                               (LENGTH(v_WHERE_BOTH_1) - 5));
        v_WHERE_Include_Of_Exclude_1 := SUBSTR(v_WHERE_Include_Of_Exclude_1,
                                               1,
                                               (LENGTH(v_WHERE_Include_Of_Exclude_1) - 5));
        -- v_SQL_BOTH_Set_1                := SUBSTR ( v_SQL_BOTH_Set_1, 1, (LENGTH ( v_SQL_BOTH_Set_1) - 11));
        -- v_SQL_Include_Of_Exclude_Set_1  := SUBSTR ( v_SQL_Include_Of_Exclude_Set_1, 1, (LENGTH ( v_SQL_Include_Of_Exclude_Set_1) - 11));
        -- v_SQL_BOTH_Set_1                := 'SELECT ROWNUM ROW_NUM, INSIDE.*  FROM (' || v_SQL_BOTH_Set_1 || ') INSIDE';
      END IF;

      IF V_Count_2 > 0 THEN
        -- Trimming the Extra ", " once the complete SELECT Clause is ready
        v_Select_Total_Set_2 := CASE
                                  WHEN v_Select_Total_Set_2 IS NOT NULL THEN
                                   SUBSTR(v_Select_Total_Set_2,
                                          1,
                                          (LENGTH(v_Select_Total_Set_2) - 2))
                                END;
        -- Trimming the Extra " OR (" from WHERE clauses
        v_WHERE_BOTH_2 := CASE
                            WHEN v_WHERE_BOTH_2 IS NOT NULL THEN
                             SUBSTR(v_WHERE_BOTH_2,
                                    1,
                                    (LENGTH(v_WHERE_BOTH_2) - 5))
                          END;
        v_WHERE_Include_Of_Exclude_2 := CASE
                                          WHEN v_WHERE_Include_Of_Exclude_2 IS NOT NULL THEN
                                           SUBSTR(v_WHERE_Include_Of_Exclude_2,
                                                  1,
                                                  (LENGTH(v_WHERE_Include_Of_Exclude_2) - 5))
                                        END;
        -- v_SQL_BOTH_Set_2                := CASE WHEN v_SQL_BOTH_Set_2 IS NOT NULL THEN SUBSTR ( v_SQL_BOTH_Set_2, 1, (LENGTH ( v_SQL_BOTH_Set_2) - 11)) END;
        -- v_SQL_Include_Of_Exclude_Set_2  := CASE WHEN v_SQL_Include_Of_Exclude_Set_2 IS NOT NULL THEN SUBSTR ( v_SQL_Include_Of_Exclude_Set_2, 1, (LENGTH ( v_SQL_Include_Of_Exclude_Set_2) - 11)) END;
        -- v_SQL_BOTH_Set_2                := CASE WHEN v_SQL_BOTH_Set_2 IS NOT NULL THEN 'SELECT ROWNUM ROW_NUM, INSIDE.*  FROM (' || v_SQL_BOTH_Set_2 || ') INSIDE' END;
      END IF;

      -- No OF-id, internal testing post fix for OF-8834 - START
      -- Trimming the Extra ", " once the complete SELECT Clause is ready
      v_Select_Total_Set_FINAL := CASE
                                    WHEN v_Select_Total_Set_FINAL IS NOT NULL THEN
                                     SUBSTR(v_Select_Total_Set_FINAL,
                                            1,
                                            (LENGTH(v_Select_Total_Set_FINAL) - 2))
                                  END;
      v_Group_By_Total_Set_FINAL := CASE
                                      WHEN v_Group_By_Total_Set_FINAL IS NOT NULL THEN
                                       SUBSTR(v_Group_By_Total_Set_FINAL,
                                              1,
                                              (LENGTH(v_Group_By_Total_Set_FINAL) - 2))
                                    END;
      v_Order_By                 := REGEXP_REPLACE(v_Group_By_Total_Set_FINAL,
                                                   'GROUP BY ',
                                                   'ORDER BY ',
                                                   1,
                                                   1); -- Replace 1st occurrence of 'GROUP BY ' with 'ORDER BY '
      -- No OF-id, internal testing post fix for OF-8834 - END

      -- Trimming the Extra " CROSS JOIN " once the complete FROM Clause is ready
      -- v_From                          := SUBSTR ( v_From, 1, (LENGTH ( v_From) - 12));
      -- OF-9829 -- START -- Trimming not needed any more for ' CROSS JOIN ' since it is added conditionally while creating v_Aligned_FROM_TOTAL
      -- v_Aligned_FROM_TOTAL          := SUBSTR ( v_Aligned_FROM_TOTAL, 1, (LENGTH ( v_Aligned_FROM_TOTAL) - 12));
      -- OF-9829 -- END

      -- Trimming the Extra "," from ORDER BY Clause
      --v_Order_By                    := SUBSTR ( v_Order_By, 1, (LENGTH ( v_Order_By) - 2));  -- No OF-id, internal testing post fix for OF-8834

      -- Trimming the Extra " UNION ALL " from v_SQL_BOTH_Set and v_SQL_Include_Of_Exclude_Set
      v_SQL_BOTH_Set               := SUBSTR(v_SQL_BOTH_Set,
                                             1,
                                             (LENGTH(v_SQL_BOTH_Set) - 11));
      v_SQL_Include_Of_Exclude_Set := SUBSTR(v_SQL_Include_Of_Exclude_Set,
                                             1,
                                             (LENGTH(v_SQL_Include_Of_Exclude_Set) - 11));

      -----------------------------------------------------------------------------------------------------------------------------------------------------
      -- Forming Final queries by appending pre and post clauses
      v_SQL_BOTH_Set := 'SELECT ROWNUM ROW_NUM, INSIDE.*  FROM (' ||
                        v_SQL_BOTH_Set || ') INSIDE';

      -- OF-7719 and OF-7722 END
      v_SQL_Include_Of_Exclude_Set := CASE
                                        WHEN v_SQL_Include_Of_Exclude_Set IS NOT NULL THEN
                                         'SELECT ROWNUM ROW_NUM, INSIDE.*  FROM (' ||
                                         v_SQL_Include_Of_Exclude_Set ||
                                         ') INSIDE'
                                      END;
      -- v_SQL_Include_Of_Exclude_Set_1 := CASE WHEN v_SQL_Include_Of_Exclude_Set_1 IS NOT NULL THEN 'SELECT ROWNUM ROW_NUM, INSIDE.*  FROM (' || v_SQL_Include_Of_Exclude_Set_1 || ') INSIDE' END;
      -- v_SQL_Include_Of_Exclude_Set_2 := CASE WHEN v_SQL_Include_Of_Exclude_Set_2 IS NOT NULL THEN 'SELECT ROWNUM ROW_NUM, INSIDE.*  FROM (' || v_SQL_Include_Of_Exclude_Set_2 || ') INSIDE' END;

      -- Forming the Contradiction Set
      v_SQL_Contradiction_Set := '
            SELECT A.*, NVL2(B.' ||
                                 v_Alignment_EIntId_Alias ||
                                 ', 1, 0) CONTRADICTION_FLAG, B.CONDITION_TEXT CONTRADICTING_ROW
            FROM BOTH_SET A
            LEFT OUTER JOIN INCLUDE_OF_EXCLUDE_SET B
               ON (
                  (NVL(TO_DATE (A.EFFECTIVE_START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE (B.EFFECTIVE_END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR''))
                  AND
                  NVL(TO_DATE (A.EFFECTIVE_END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE (B.EFFECTIVE_START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR''))
                  )' ||
                                 v_AND_Entities_Clause || ')';
      -- Forming the v_SQL_Contradiction_Aggregate Query
      v_SQL_Contradiction_Aggregate := '
           SELECT ROW_NUM, ' ||
                                       v_SELECT_Entities_Clause ||
                                       'CONDITION_TEXT, ' ||
                                       v_ALLOCATION_COL ||
                                       'EFFECTIVE_START_DATE, EFFECTIVE_END_DATE
                  , LISTAGG (CONTRADICTING_ROW, '','') WITHIN GROUP (ORDER BY CONDITION_TEXT) AS CONTRADICTING_WITH
             FROM CONTRADICTION_SET
         GROUP BY ROW_NUM, ' ||
                                       v_SELECT_Entities_Clause ||
                                       'CONDITION_TEXT,' ||
                                       v_ALLOCATION_COL || 'EFFECTIVE_START_DATE, EFFECTIVE_END_DATE
         ';
      -- Selecting the Table as Input to check for Overlaps depending on whether there's at least 1 EXCLUDE filter condition for Aligned Entities
      v_Overlap_Table := CASE
                           WHEN v_SQL_Include_Of_Exclude_Set IS NULL THEN
                            'BOTH_SET'
                           ELSE
                            'CONTRADICTION_AGGREGATE'
                         END;
      -- Forming the Overlap Set
      v_SQL_Overlap_Set := '
            SELECT A.*, NVL2(B.' ||
                           v_Alignment_EIntId_Alias || ', 1, 0) OVERLAP_FLAG, B.CONDITION_TEXT OVERLAPPING_ROW
            FROM ' || v_Overlap_Table || ' A
            LEFT OUTER JOIN ' || v_Overlap_Table || ' B
               ON (
                  (NVL(TO_DATE (A.EFFECTIVE_START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR'')) <= NVL(TO_DATE (B.EFFECTIVE_END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR''))
                  AND
                  NVL(TO_DATE (A.EFFECTIVE_END_DATE, ''DD/MM/RRRR''), TO_DATE(''31/12/9999'', ''DD/MM/RRRR'')) >= NVL(TO_DATE (B.EFFECTIVE_START_DATE, ''DD/MM/RRRR''), TO_DATE(''01/01/1900'', ''DD/MM/RRRR''))
                  )' || v_AND_Entities_Clause ||
                           ' AND A.ROW_NUM <> B.ROW_NUM)';
      -- Forming the v_SQL_Overlap_Aggregate Query
      v_SQL_Overlap_Aggregate := '
           SELECT ROW_NUM, ' ||
                                 v_SELECT_Entities_Clause || 'CONDITION_TEXT,' ||
                                 v_ALLOCATION_COL ||
                                 'EFFECTIVE_START_DATE, EFFECTIVE_END_DATE' || CASE
                                   WHEN v_SQL_Include_Of_Exclude_Set IS NULL THEN
                                    NULL
                                   ELSE
                                    ',CONTRADICTING_WITH'
                                 END || '
                  ,LISTAGG (OVERLAPPING_ROW, '','') WITHIN GROUP (ORDER BY CONDITION_TEXT) AS OVERLAPPING_WITH
             FROM OVERLAP_ON_CONTRADICTION_SET
         GROUP BY ROW_NUM, ' ||
                                 v_SELECT_Entities_Clause || 'CONDITION_TEXT,' ||
                                 v_ALLOCATION_COL ||
                                 'EFFECTIVE_START_DATE, EFFECTIVE_END_DATE' || CASE
                                   WHEN v_SQL_Include_Of_Exclude_Set IS NULL THEN
                                    NULL
                                   ELSE
                                    ', CONTRADICTING_WITH'
                                 END;

      -- Forming the Final WITH Clause
      v_SQL_FINAL := '
            WITH BOTH_SET AS (' || v_SQL_BOTH_Set || CASE
                       WHEN v_SQL_Include_Of_Exclude_Set IS NULL THEN
                        NULL
                       ELSE
                        '), INCLUDE_OF_EXCLUDE_SET AS (' ||
                        v_SQL_Include_Of_Exclude_Set ||
                        '), CONTRADICTION_SET AS (' || v_SQL_Contradiction_Set ||
                        '), CONTRADICTION_AGGREGATE AS (' ||
                        v_SQL_Contradiction_Aggregate
                     END || '), OVERLAP_ON_CONTRADICTION_SET AS (' ||
                     v_SQL_Overlap_Set || '), OVERLAP_AGGREGATE AS (' ||
                     v_SQL_Overlap_Aggregate ||
                     ') SELECT * FROM OVERLAP_AGGREGATE';

      -- Forming the complete v_SQL_Total_Set
      -- OF-7719 and OF-7722 START
      -- v_SQL_Total_Set               := v_Select_Total_Set || ' ' || v_From || ' ' || v_WHERE_BOTH || v_WHERE_Include_Of_Exclude || ' ' || v_Order_By;

      -- Non Hierarchy Related Part (Common and always required, whether or not Hierarchy is in picture for Alignments)
      v_Alignment_FROM := ' FROM ' || v_Alignment_Table_Name || ' ' ||
                          v_Alignment_Entity_Table_Alias;

      -- FROM Part_1
      -- OF-9829 -- START -- Removing ' CROSS JOIN ' from here and adding it conditionally while creating v_Aligned_FROM_TOTAL
      -- v_FROM_1                      := v_Alignment_FROM || ' CROSS JOIN ' || v_Aligned_FROM_TOTAL;
      v_FROM_1 := v_Alignment_FROM || v_Aligned_FROM_TOTAL;
      -- OF-9829 -- END
      -- Complete SQL Part_1
      v_SQL_Total_Set_1 := v_Select_Total_Set_1 || ' ' || v_FROM_1 || ' ' ||
                           v_WHERE_BOTH_1 || v_WHERE_Include_Of_Exclude_1;

      -- FROM Part_2
      -- OF-9829 -- START -- Removing ' CROSS JOIN ' from here and adding it conditionally while creating v_Aligned_FROM_TOTAL
      -- v_FROM_2                      := v_Alignment_FROM || v_Alignment_Ent_Via_Hier_FROM || ' CROSS JOIN ' || v_Aligned_FROM_TOTAL;
      v_FROM_2 := v_Alignment_FROM || v_Alignment_Ent_Via_Hier_FROM ||
                  v_Aligned_FROM_TOTAL;
      -- OF-9829 -- END

      -- Complete Hierarchy related SQL Part_2
      v_SQL_Total_Set_2 := v_Select_Total_Set_2 || ' ' || v_FROM_2 || ' ' ||
                           v_WHERE_BOTH_2 || v_WHERE_Include_Of_Exclude_2;

      IF (V_Count_1 > 0 AND V_Count_2 > 0) THEN
        -- Complete SQL Union_ing Non-Hierarchy and Hierarchy related SQL Parts
        v_SQL_Total_Set := v_Select_Total_Set_FINAL || ' FROM (' ||
                           v_SQL_Total_Set_1 || ' UNION ' ||
                           v_SQL_Total_Set_2 || ') ' ||
                           v_Group_By_Total_Set_FINAL; -- No OF-id, internal testing post fix for OF-8834
      ELSIF V_Count_1 > 0 THEN
        v_SQL_Total_Set := v_SQL_Total_Set_1; -- Since no Hierarchy related SQL set is present, final SQL consists of only Non-Hierarchy related SQL.
      ELSIF V_Count_2 > 0 THEN
        v_SQL_Total_Set := v_SQL_Total_Set_2; -- Since no Non-Hierarchy related SQL set is present, final SQL consists of only Hierarchy related SQL.
      END IF;

      -- Append the ORDER BY Clause
      v_SQL_Total_Set := v_SQL_Total_Set || '  ' || v_Order_By;

      -- OF-7719 and OF-7722 END
      ----------------------------------------------------------------------------------------------------------------------------

      -- Form CTAS Queries
      -- i. For Intermediate Total Set
      V_SQL_CTAS_TOTAL := 'CREATE TABLE ' || v_Total_Set_Table || ' AS ' ||
                          v_SQL_Total_Set;
      -- ii. For Final Set (with Valid, Contradicting and Overlapping Alignment Records)
      V_SQL_CTAS_FINAL := 'CREATE TABLE ' || v_FINAL_Table || ' AS ' ||
                          v_SQL_FINAL;
      -- Forming the Column Lists
      -- OF-9829 -- START -- Adding ', ' after v_Alignment_ENTITY_COL_NAME here and removing it while creating v_Alignment_ENTITY_COL_NAME
      v_INSERT_INTO_COL_LIST := 'ROW_IDENTIFIER, ROW_VERSION, ' ||
                                v_Alignment_ENTITY_COL_NAME || ', ' ||
                                v_Aligned_ENTITIES_COL_NAME ||
                                v_ALLOCATION_COL || 'START_DATE, END_DATE';
      -- OF-9829 -- END
      v_INSERT_VALUES_COL_LIST := v_SELECT_Entities_Clause ||
                                  v_ALLOCATION_COL ||
                                  'EFFECTIVE_START_DATE, EFFECTIVE_END_DATE';

      -- OF-6945 - START

      -- Execute Query to create Main Data Set
      -- INSERT_LOGS(PI_CLOB => 'V_SQL_CTAS_TOTAL : ' || V_SQL_CTAS_TOTAL);

      -- INSERT_LOGS('TX_ID BEFORE autonomous_transaction for  V_SQL_CTAS_TOTAL '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      -- OF-27136 - START
      --EXECUTE IMMEDIATE V_SQL_CTAS_TOTAL;
      EXECUTE_DDL_AUTONOMOUS(V_SQL_CTAS_TOTAL, 'V_SQL_CTAS_TOTAL');
      -- OF-27136 - END
      -- INSERT_LOGS('TX_ID AFTER autonomous_transaction for V_SQL_CTAS_TOTAL '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

      -- Execute Final Query to Generate Valid, Contradicting and Overlapping Alignment Records
      -- INSERT_LOGS(PI_CLOB => 'V_SQL_CTAS_FINAL : ' || V_SQL_CTAS_FINAL);
      -- INSERT_LOGS('TX_ID BEFORE autonomous_transaction for V_SQL_CTAS_FINAL '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      -- OF-27136 - START
      --EXECUTE IMMEDIATE V_SQL_CTAS_FINAL;
      EXECUTE_DDL_AUTONOMOUS(V_SQL_CTAS_FINAL, 'V_SQL_CTAS_FINAL');
      -- OF-27136 - END
      -- INSERT_LOGS('TX_ID AFTER autonomous_transaction for V_SQL_CTAS_FINAL '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

      -- OF-22214 - START  -- modified the below query to replace listagg with xmlagg, along with corresponding code
      -- Forming SQL Query statement for retrieving Dual Alignment Rows

      v_sql_gtt := 'CREATE TABLE ' || v_Dual_Rows_Table ||
                   ' AS SELECT DISTINCT A.ROW_NUM, ' ||
                   v_Aligned_EIntId_Alias_List || ', A.' ||
                   v_Alignment_EIntId_Alias || ' FROM ' || v_FINAL_Table ||
                   ' A INNER JOIN ' || v_FINAL_Table || ' B ON (' ||
                   v_AND_Dual_Aligned_Clause || '
               AND ( (NVL (TO_DATE ( A.EFFECTIVE_START_DATE, ''DD/MM/RRRR''), TO_DATE ( ''01/01/1900'', ''DD/MM/RRRR'')) <=
                      NVL (TO_DATE ( B.EFFECTIVE_END_DATE, ''DD/MM/RRRR''), TO_DATE (''31/12/9999'', ''DD/MM/RRRR''))
                      AND NVL (TO_DATE ( A.EFFECTIVE_END_DATE, ''DD/MM/RRRR''), TO_DATE ( ''31/12/9999'', ''DD/MM/RRRR'')) >=
                      NVL (TO_DATE ( B.EFFECTIVE_START_DATE, ''DD/MM/RRRR''), TO_DATE ( ''01/01/1900'', ''DD/MM/RRRR'')))))
             WHERE A.OVERLAPPING_WITH IS NULL AND B.OVERLAPPING_WITH IS NULL ' || CASE
                     WHEN v_SQL_Include_Of_Exclude_Set IS NULL THEN
                      NULL
                     ELSE
                      ' AND A.CONTRADICTING_WITH IS NULL AND B.CONTRADICTING_WITH IS NULL '
                   END;

      v_sql_dual_rows := 'SELECT A.ROW_NUM FROM ' || v_Dual_Rows_Table ||
                         ' A WHERE (' || v_Aligned_EIntId_Alias_List ||
                         ') IN ( SELECT ' || v_Aligned_EIntId_Alias_List ||
                         ' FROM ' || v_Dual_Rows_Table || ' A GROUP BY ' ||
                         v_Aligned_EIntId_Alias_List || ' HAVING COUNT (A.' ||
                         v_Alignment_EIntId_Alias || ') > 1 ) ';

      -- INSERT_LOGS(PI_CLOB => 'v_sql_gtt : ' || v_sql_gtt);
      -- INSERT_LOGS('TX_ID BEFORE autonomous_transaction for v_sql_gtt '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      -- OF-27136 - START
      --EXECUTE IMMEDIATE v_sql_gtt;
      EXECUTE_DDL_AUTONOMOUS(v_sql_gtt, 'v_sql_gtt');
      -- OF-27136 - END
      -- INSERT_LOGS('TX_ID AFTER autonomous_transaction for v_sql_gtt '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

      -- INSERT_LOGS(PI_CLOB => 'v_sql_dual_rows : ' || v_sql_dual_rows);
      EXECUTE IMMEDIATE v_sql_dual_rows BULK COLLECT
        INTO V_TYPE_NUMBER;
      -- INSERT_LOGS('V_TYPE_CLOB.COUNT : ' || V_TYPE_NUMBER.COUNT);

      /*IF V_TYPE_NUMBER.COUNT > 0
      THEN
        SELECT COUNT(*) INTO v_count FROM TABLE(V_TYPE_NUMBER);
         -- INSERT_LOGS('v_count : ' || v_count);
        -- OF-22214 END
      END IF;*/
      -- deshmukha added the following statement for the above if V_TYPE_NUMBER.COUNT > 0
      v_count := V_TYPE_NUMBER.count;

      --------------------------------------- PART 2 : END :  ------------------------------------------------------------------------
      --------------------------------------- PART LAST_BUT_ONE : END : Insert Final Data in 4 Tables (names in Input) -------------------------

      -- Form Insert Queries for Final 4 tables
      v_SQL_INSERT := CASE
                        WHEN v_SQL_Include_Of_Exclude_Set IS NULL THEN
                         '
                  INSERT
                  WHEN (OVERLAPPING_WITH IS NULL' || CASE
                           WHEN v_count > 0 AND V_ALLOW_DUAL_ALIGNMENTS = 0 THEN
                            ' AND ROW_NUM NOT IN (SELECT * FROM TABLE(:1))'
                           ELSE
                            NULL
                         END || ') THEN
                  INTO ' || PI_ALIGNMENT_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_ALIGNMENT_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')' || CASE
                           WHEN v_count > 0 THEN
                            '
                  WHEN (OVERLAPPING_WITH IS NULL AND ROW_NUM IN (SELECT * FROM TABLE(:2))' ||
                            ') THEN
                  INTO ' ||
                            PI_DUAL_ALIGNMENTS_TABLE_NAME || '(' ||
                            v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                            PI_DUAL_ALIGNMENTS_TABLE_NAME ||
                            '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                            v_INSERT_VALUES_COL_LIST || ')'
                           ELSE
                            NULL
                         END || '
                  WHEN (OVERLAPPING_WITH IS NOT NULL) THEN
                  INTO ' || PI_OVERLAPPING_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_OVERLAPPING_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')' || '
                  SELECT 0 ROW_VERSION, ROW_NUM, ' ||
                         ' OVERLAPPING_WITH, ' || v_INSERT_VALUES_COL_LIST ||
                         ' FROM ' || v_FINAL_Table || ' ORDER BY ' ||
                         v_INSERT_VALUES_COL_LIST
                        ELSE
                         '
                  INSERT
                  WHEN (CONTRADICTING_WITH IS NULL AND OVERLAPPING_WITH IS NULL' || CASE
                           WHEN v_count > 0 AND V_ALLOW_DUAL_ALIGNMENTS = 0 THEN
                            ' AND ROW_NUM NOT IN (SELECT * FROM TABLE(:3))'
                           ELSE
                            NULL
                         END || ') THEN
                  INTO ' || PI_ALIGNMENT_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_ALIGNMENT_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')' || CASE
                           WHEN v_count > 0 THEN
                            '
                  WHEN (CONTRADICTING_WITH IS NULL AND OVERLAPPING_WITH IS NULL AND ROW_NUM IN (SELECT * FROM TABLE(:4))' ||
                            ') THEN
                  INTO ' ||
                            PI_DUAL_ALIGNMENTS_TABLE_NAME || '(' ||
                            v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                            PI_DUAL_ALIGNMENTS_TABLE_NAME ||
                            '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                            v_INSERT_VALUES_COL_LIST || ')'
                           ELSE
                            NULL
                         END || '
                  WHEN (CONTRADICTING_WITH IS NOT NULL AND OVERLAPPING_WITH IS NULL) THEN
                  INTO ' || PI_CONTRADICTORY_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_CONTRADICTORY_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')' || '
                  WHEN (CONTRADICTING_WITH IS NULL AND OVERLAPPING_WITH IS NOT NULL) THEN
                  INTO ' || PI_OVERLAPPING_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_OVERLAPPING_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')' || '
                  WHEN (CONTRADICTING_WITH IS NOT NULL AND OVERLAPPING_WITH IS NOT NULL) THEN
                  INTO ' || PI_CONTRADICTORY_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_CONTRADICTORY_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')' || '
                  INTO ' || PI_OVERLAPPING_TABLE_NAME || '(' ||
                         v_INSERT_INTO_COL_LIST || ')' || ' VALUES (' ||
                         PI_OVERLAPPING_TABLE_NAME ||
                         '_ROW_IDENTIFIER_SEQ.NEXTVAL, ROW_VERSION, ' ||
                         v_INSERT_VALUES_COL_LIST || ')

                  SELECT 0 ROW_VERSION, ROW_NUM, ' ||
                         ' CONTRADICTING_WITH, OVERLAPPING_WITH, ' ||
                         v_INSERT_VALUES_COL_LIST || ' FROM ' || v_FINAL_Table ||
                         ' ORDER BY ' || v_INSERT_VALUES_COL_LIST
                      END;

      -- INSERT_LOGS(PI_CLOB => 'v_SQL_INSERT : ' || v_SQL_INSERT);

      IF v_count > 0 THEN
        IF V_ALLOW_DUAL_ALIGNMENTS = 0 THEN
          -- OF-27136 - START
          -- EXECUTE IMMEDIATE v_SQL_INSERT USING V_TYPE_NUMBER, V_TYPE_NUMBER;
          EXECUTE_DDL_AUTONOMOUS(v_SQL_INSERT,
                                 'v_SQL_INSERT_2',
                                 V_TYPE_NUMBER,
                                 V_TYPE_NUMBER);
          -- OF-27136 - END
        ELSE
          -- OF-27136 - START
          -- EXECUTE IMMEDIATE v_SQL_INSERT USING V_TYPE_NUMBER;
          EXECUTE_DDL_AUTONOMOUS(v_SQL_INSERT,
                                 'v_SQL_INSERT_1',
                                 V_TYPE_NUMBER);
          -- OF-27136 - END
        END IF;
      ELSE
        -- OF-27136- START
        -- EXECUTE IMMEDIATE v_SQL_INSERT;
        EXECUTE_DDL_AUTONOMOUS(v_SQL_INSERT, 'v_SQL_INSERT_0');
        -- OF-27136 - END
      END IF;
      --COMMIT;  -- OF-27136

      -- OF-6945 - END
      --------------------------------------- PART LAST : END : CLEANUP ------------------------------------------------------------------------
      -- INSERT_LOGS('TX_ID BEFORE autonomous_transaction for v_Total_Set_Table '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      -- OF-27136- START
      --EXECUTE IMMEDIATE 'DROP TABLE ' || v_Total_Set_Table;
      EXECUTE_DDL_AUTONOMOUS('DROP TABLE ' || v_Total_Set_Table,
                             'DROP TABLE v_Total_Set_Table');
      -- INSERT_LOGS('TX_ID AFTER autonomous_transaction for v_Total_Set_Table '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

      -- INSERT_LOGS('TX_ID BEFORE autonomous_transaction for v_FINAL_Table '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      --EXECUTE IMMEDIATE 'DROP TABLE ' || v_FINAL_Table;
      EXECUTE_DDL_AUTONOMOUS('DROP TABLE ' || v_FINAL_Table,
                             'DROP TABLE v_FINAL_Table');
      -- INSERT_LOGS('TX_ID AFTER autonomous_transaction for v_FINAL_Table '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

      -- INSERT_LOGS('TX_ID BEFORE autonomous_transaction for v_Dual_Rows_Table '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      --EXECUTE IMMEDIATE 'DROP TABLE '||v_Dual_Rows_Table;
      EXECUTE_DDL_AUTONOMOUS('DROP TABLE ' || v_Dual_Rows_Table,
                             'DROP TABLE v_Dual_Rows_Table');
      -- INSERT_LOGS('TX_ID AFTER autonomous_transaction for v_Dual_Rows_Table '||COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);
      -- OF-27136- END
      -- Testing - print output
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, v_Total_Set_Table || ' -->' || 'v_SQL_Total_Set --' || v_SQL_Total_Set);
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'v_SQL_BOTH_Set --' || v_SQL_BOTH_Set);
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'v_SQL_Include_Of_Exclude_Set --' || v_SQL_Include_Of_Exclude_Set);
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'V_SQL_CTAS_TOTAL --' || V_SQL_CTAS_TOTAL);
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'V_SQL_CTAS_FINAL ' || V_SQL_CTAS_FINAL);
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'v_sql_dual_rows ' || v_sql_dual_rows);
      --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'v_SQL_INSERT ' || v_SQL_INSERT);

    END IF; -- IF_1 END
  END EVALUATE_ALIGNMENTS;
END ALIGNMENTS;
/
