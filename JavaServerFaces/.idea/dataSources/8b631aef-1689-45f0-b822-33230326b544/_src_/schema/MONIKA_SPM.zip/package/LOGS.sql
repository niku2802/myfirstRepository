CREATE PACKAGE logs AS
PRAGMA SERIALLY_REUSABLE;
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: commons
-- Module			: processing-commons
-- Requester		: Obreja, Petru
-- Author		: Lazarescu, Bogdan
-- Reviewer		:  Lazar, Lucian
-- Review date		:  20110328
-- Description		: create objects for LOGS insert/update/delete and LOGS counts refresh
-- ---------------------------------------------------------------------------
		-- *******************************    PUBLIC TYPES START       *******************************
    TYPE coltype_RD_IDS IS TABLE OF NUMBER(10);
		-- *******************************    PUBLIC TYPES END         *******************************

		-- *******************************    PUBLIC CURSORS START       *******************************
		-- *******************************    PUBLIC CURSORS END         *******************************

		-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
    v_RD_ID coltype_RD_IDS;
    empty coltype_RD_IDS;
		-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

		-- *******************************    PUBLIC FUNCTIONS START       *******************************
    FUNCTION SPLIT_ROOT_PATH 	 (
             pin_str   in varchar2
             , pin_delim in varchar2) RETURN coltype_RD_IDS;
		-- *******************************    PUBLIC FUNCTIONS END         *******************************

		-- *******************************    PUBLIC PROCEDURES START       *******************************
    PROCEDURE LOGS_UPSERT_DATA (
              pin_LM_RD_ID IN LOGS_MESSAGES.LM_RD_ID%TYPE
              , pin_LM_LEVEL IN LOGS_MESSAGES.LM_LEVEL%TYPE
              , pin_LM_MESSAGE IN LOGS_MESSAGES.LM_MESSAGE%TYPE
              , pin_LM_MESSAGE_DETAILS IN coltype_LOG_DETAILS
              , pin_LM_START_DATE IN LOGS_MESSAGES.LM_START_DATE%TYPE
              , pin_LM_UPDATE_DATE IN LOGS_MESSAGES.LM_UPDATE_DATE%TYPE
              , pinout_LM_ID IN OUT LOGS_MESSAGES.LM_ID%TYPE);

    PROCEDURE LOGS_DELETE_DATA (
              pin_RD_IDS IN coltype_ID);

    PROCEDURE LOGS_MESSAGE_COUNT_REFRESH (
              pin_RD_ID IN RUN_DATA.RD_ID%TYPE
              , pin_errors IN number
              , pin_warnings IN number);
		-- *******************************    PUBLIC PROCEDURES END         *******************************
END logs;
/
