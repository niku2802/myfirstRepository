CREATE PACKAGE BODY FIXUIDPK AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product		: central
-- Module		: central
-- Requester		: Cozac, Tudor
-- Author		: Lazarescu, Bogdan
-- Reviewer		:
-- Review date		:
-- Description		:  package used to give new uid ids to records from another schema during restore in existing schema
-- ---------------------------------------------------------------------------
		-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
		-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

		-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
		-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

		-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
FUNCTION newuidpk (olduidpk IN NUMBER)
RETURN NUMBER IS
newid NUMBER;
BEGIN
IF NOT id_remaps.EXISTS(olduidpk) THEN
-- Allocate a value from sequence LASTEMP
SELECT uid_sequence.NEXTVAL INTO newid FROM DUAL;
id_remaps(olduidpk) := newid;
END IF;
RETURN id_remaps(olduidpk);
END;
		-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END FIXUIDPK;
/
