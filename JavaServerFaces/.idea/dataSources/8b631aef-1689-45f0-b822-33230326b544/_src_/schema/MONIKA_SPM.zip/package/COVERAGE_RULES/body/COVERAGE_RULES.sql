CREATE PACKAGE BODY COVERAGE_RULES AS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2015 - 2017 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : coveragerules
-- Module           : coveragerules
-- Requester        :
-- Author           :
-- Reviewer         :
-- Review date      : 17 OCT 2017
-- Description      : Package used to handle all coverage rules processing
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- ========================================================
  -- Author     : Dobranici, Alexandru
  -- Create date: 20151017
  -- Description: GET_ALL_HIERARCHIES: function that returns all the non-recursive and not efective dated hierarchies.
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(COVERAGE_RULES.GET_ALL_HIERARCHIES)
  */
  -----------------------------------------------------------------------------------------
  FUNCTION GET_ALL_HIERARCHIES
  RETURN TABLETYPE_ID_NAME
  AS
  V_HIERARCHY_ID_NAME TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();
  BEGIN
     SELECT OBJTYPE_ID_NAME(HT.HT_ID, HT.HT_NAME)
       BULK COLLECT
       INTO V_HIERARCHY_ID_NAME
       FROM HIERARCHY_TABLES HT
       JOIN (SELECT HS_ID, HS_HT_ID
               FROM HIERARCHY_STRUCTURE
              WHERE HS_IS_DATED = 0
                AND HS_TIMEUNIT_ID IS NULL) HS
         ON HT.HT_ID = HS.HS_HT_ID
       JOIN (SELECT HN_HS_ID
               FROM (SELECT HN_HS_ID,
                            COUNT(DISTINCT(HN_ENTITY_ID)) DIST,
                            COUNT(HN_ENTITY_ID) EN_NUM
                       FROM HIERARCHY_NODE
                      GROUP BY HN_HS_ID)
              WHERE DIST = EN_NUM) HN
         ON HS.HS_ID = HN.HN_HS_ID
      ORDER BY HT.HT_NAME;
     RETURN V_HIERARCHY_ID_NAME;
  END GET_ALL_HIERARCHIES;

-- *******************************    PUBLIC FUNCTIONS END         *******************************

END COVERAGE_RULES;
/
