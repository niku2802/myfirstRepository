CREATE PACKAGE ROLLUP_HIERARCHY AS
   -----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Deletes from Portal Hierarchy
      -- Input Parameters:
      --    ->> INPUT
/*                          pin_inputview_columns               the columns from the input table (the entity column, followed by the columns to roll up)
              pin_inputview_ent_fld        the entity/field column name from the input table before the alias was given
                            pin_inputview                       the query for the input table
                            pin_relationship_tables             (TYPE TABLETYPE_RELATIONSHIP_TABLES)
                                  - relationship table name
                                  - upper entity id
                                  - lower entity id
                                  - upper column name
                                  - lower column name,
                            pin_is_effective_period             (1 for period, 0 for date, null for not effective dated)
                            pin_start_period_column             (for period, the columns' name from fields, ex ???start quarter???)
                            pin_end_period_column               (for period, the columns' name from fields, ex ???end quarter???)
                            pin_process_run_for                 the value selected in "<processing period/input field time frame> BETWEEN the <hierarchy relationship record time frame> of the hierarchy relationship record if:" (0 the first / 1 the last / 2 any / 3 every)
                            pin_roll_up_from_type               id (from the Entities table) of the entity selected in the Entity to roll up from drop down
                            pin_roll_up_to_type                 id (from the Entities table) of the entity selected in the Entity to roll up to drop down
                            pin_level_from                      level from (0 for roll up from the lowest level / 1 for roll up from all levels)
                            pin_level_to                        how many levels to roll up to
                            pin_aggregate_values                (0 to not aggregate values / 1 to aggregate values)
                            pin_include_input_records           (0 to not include input records / 1 to include input records)
                            pin_date_period_column              The column of the field selected in Hierarchy Records tab
                            pin_new_date_period_column          The column name of the field selected in Hierarchy Records tab after the alias was given
                            pin_entity_roll_up_to_column        The entity to roll up to column from the primary result table
                            pin_entity_roll_up_from_column      The entity to roll up from column from the primary result table (NULL if the column does not exist)
                            pin_levels_rolled_up_column         The levels rolled up column from the primary result table (NULL if the column does not exist)
                            pin_fields_columns                  The input records to roll up columns from the primary result table (the columns are comma separated)
                            pin_no_match_table_columns          The additional table for input records that do not match any entity values followed by the column names (NULL if the result table doesn't need to be created) (the table and the columns are comma separated)
                            pin_no_roll_up_table_columns        The additional table for input records that match the entity values but do not roll up to any other entity values followed by the column names (NULL if the result table doesn't need to be created) (the table and the columns are comma separated)
                            pin_output_where_clause             The where clause selected in Result Filter tab
                            pin_primary_table                   The primary table name
                            pin_date_run_for                    The date the process is run for (NULL if it???s not a date)
                            pin_period_run_for                  The period the process is run for (NULL if it???s not a period)

                            pout_primary_rows                   The output parameter which returns if rows have been inserted or not in the primary table (0/1)
                            pout_no_rollup_rows                 The output parameter which returns if rows have been inserted or not in the no rollup table (0/1)
                            pout_no_match_rows                  The output parameter which returns if rows have been inserted or not in the no match table (0/1)
   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      DECLARE
            pout_primary_rows   NUMBER;
            pout_no_rollup_rows NUMBER;
            pout_no_match_rows  NUMBER;

      BEGIN
          ROLLUP_HIERARCHY.ROLLUP_THE_HIERARCHY(
                                  pin_inputview_columns          => 'ENTITY, VALUE',
                                  pin_inputview_ent_fld          => 'ENTITY',
                                  pin_inputview                  => 'INPUT_DATA1',
                                  pin_relationship_tables        => TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE('MONTH_EFFECTIVE_HIERARCHY3',1,1,'ENT_UPPER','ENT_LOWER')),
                                  pin_levels_rolled_up_column    => null,
                                  pin_include_input_records      => null,
                                  pin_roll_up_from_type          => 1,
                                  pin_roll_up_to_type            => 1,
                                  pin_level_from                 => 1,
                                  pin_aggregate_values           => 1,
                                  pin_level_to                   => 0,
                                  pin_no_roll_up_table_columns   => 'NO_ROLLUP, ENTITY, VALUE',
                                  pin_no_match_table_columns     => 'NO_MATCH, ENTITY, VALUE',
                                  pin_is_effective_period        => 1,
                                  pin_start_period_column        => 'F463',
                                  pin_end_period_column          => 'F464',
                                  pin_process_run_for            => 1,
                                  pin_date_period_column         => null,
                                  pin_new_date_period_column     => null,
                                  pin_entity_roll_up_to_column   => 'ENTITY',
                                  pin_entity_roll_up_from_column => null,
                                  pin_fields_columns             => 'VALUE',
                                  pin_output_where_clause        => null,
                                  pin_primary_table              => 'PRIMARY1',
                                  pin_date_run_for               => null,
                                  pin_period_run_for             => 99,
                                  pout_primary_rows              => pout_primary_rows,
                                  pout_no_rollup_rows            => pout_no_rollup_rows,
                                  pout_no_match_rows             => pout_no_match_rows);

      END;
         */
   -----------------------------------------------------------------------------------------------
  PROCEDURE ROLLUP_THE_HIERARCHY(
    pin_InputView_columns           varchar2,
    pin_rollup_alias_columns        VARCHAR2,
    pin_inputview_ent_fld           varchar2,
    pin_InputView                   clob,
    pin_relationship_tables         TABLETYPE_RELATIONSHIP_TABLES,
    pin_levels_rolled_up_column     varchar2,
    pin_include_input_records       number,
    pin_roll_up_from_type           number,
    pin_roll_up_to_type             number,
    pin_level_from                  number,
    pin_aggregate_values            number,
    pin_level_to                    number,
    pin_no_roll_up_table_columns    varchar2,
    pin_no_match_table_columns      varchar2,
    pin_is_effective_period         number,
    pin_start_period_column         varchar2,
    pin_end_period_column           varchar2,
    pin_process_run_for             number,
    pin_date_period_column          varchar2,
    pin_new_date_period_column      varchar2,
    pin_entity_roll_up_to_column    varchar2,
    pin_entity_roll_up_from_column  varchar2,
    pin_fields_columns              varchar2,
    pin_output_where_clause         clob,
    pin_primary_table               varchar2,
    pin_date_run_for                date,
    pin_period_run_for              number,
    pin_operation_id                number,
    pin_run_id                      NUMBER,
    pout_primary_rows       OUT     number,
    pout_no_rollup_rows     OUT     number,
    pout_no_match_rows      OUT     number
  );
END ROLLUP_HIERARCHY;
/
