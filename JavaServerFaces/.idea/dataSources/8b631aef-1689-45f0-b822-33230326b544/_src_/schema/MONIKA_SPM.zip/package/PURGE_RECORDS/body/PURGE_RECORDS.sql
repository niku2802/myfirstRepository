CREATE PACKAGE BODY PURGE_RECORDS AS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type: SPM
-- Product      : commons
-- Module        : settings-commons
-- Requester    : Macoveiciuc Iulian
-- Author        : Filip Vlad-Catalin
-- Reviewer      : Lazar Lucian
-- Review date  :
-- Description  : Used to delete Processing, Login Histoy and Portal Usage logs older than a specified number of days by creating three jobs that will run daily.
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************



/***********************************************/
/**Procedure called to gather STATS for a list of tables logs**/
/***********************************************/
  PROCEDURE CALL_STATS(pin_table_list IN TABLETYPE_CHARMAX)
  AS

  BEGIN
    -- Gather stats for each table received as parameter and also on the cascaded tables
    for c in (select column_value TABLE_NAME from table(pin_table_list)) loop
      -- Gather stats for each table
      COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(PI_TABLE => c.TABLE_NAME ,PI_MODE => 2);

      -- Get all Dependencies
      for d in (select CASCADED_TAB
                  from (select distinct UCC.TABLE_NAME  CASCADED_TAB,
                                        UCPK.TABLE_NAME DELETED_TAB
                          from USER_CONS_COLUMNS UCC
                          join USER_CONSTRAINTS  UC
                            on UCC.CONSTRAINT_NAME    = UC.CONSTRAINT_NAME
                          join USER_CONSTRAINTS UCPK
                            on UC.R_CONSTRAINT_NAME   = UCPK.CONSTRAINT_NAME
                           and UC.CONSTRAINT_TYPE     = 'R'
                           and UC.DELETE_RULE         = 'CASCADE')
                 start with DELETED_TAB = c.TABLE_NAME
                connect by prior CASCADED_TAB = DELETED_TAB ) loop

        -- Gather stats for dependencies
        COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(PI_TABLE => d.CASCADED_TAB,PI_MODE => 2);
      end loop;
    end loop;

  END CALL_STATS;


/***********************************************/
/**Procedure called to delete records from: RUN_DATA, LOGS_MESSAGES, LOGS_MESSAGE_COUNT **/
/***********************************************/
 PROCEDURE PURGE_PROCESS_LOGS(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS
   run_ids              LOGS.COLTYPE_RD_IDS;
   v_runs               TABLETYPE_NUMBER;
   v_prop               NUMBER;

 BEGIN
    loop
        delete from RUN_DATA
        where RD_ROOT_ID in (select RD_ROOT_ID
                               from RUN_DATA rd
                               join RUN_STATUS_DATA rs
                                 on rd.RD_ID = rs.RS_ID
                              where rd.RD_ID = rd.RD_ROOT_ID
                                and rs.RS_POST_EXECUTION_END_TIME < pin_current_date - TO_NUMBER(pin_days)
                                and rs.RS_STATUS = 5
                              UNION ALL
                             SELECT RD_ROOT_ID
                               FROM RUN_DATA
                              WHERE RD_ROOT_ID NOT IN (SELECT RD_ID
                                                         FROM RUN_DATA))
        and rownum <= TO_NUMBER(pin_chunk_size)
        returning rd_id bulk collect into v_runs;

        exit when SQL%ROWCOUNT = 0;

        DELETE FROM LOGS_MESSAGES lm
           where LM.LM_RD_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

        DELETE FROM LOGS_MESSAGE_COUNT lmc
           where LMC.LMC_RD_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

        -- added in 15.5
        -- delete run id related statistics
        DELETE FROM SQL_EXEC_PLAN_TABLE S
           WHERE (S.SQL_ID, S.CHILD_NUMBER) IN (SELECT RQP_SQL_ID, RQP_CHILD_NUMBER
                                                FROM RUN_PROFILE_QUERY_PLANS
                                                WHERE RQP_RD_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs)));

    DELETE FROM SQL_EXECUTION_STATS S
           WHERE S.SES_RUN_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

        DELETE FROM RUN_PROFILE_QUERY_PLANS S
           WHERE S.RQP_RD_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

        DELETE FROM RUNTIME_STATISTICS_INFO S
           WHERE S.RSI_RUN_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

        commit;
    end loop;

    -- added in 15.5
    -- for resource intensive statistics - keep only the last 10 runs info

    BEGIN SELECT TO_NUMBER(PR_VALUE) INTO v_prop FROM PROPERTIES WHERE PR_NAME = 'PROC_EXEC_PLAN_MAX_KEEP';
    EXCEPTION WHEN OTHERS THEN NULL;
    END;

    --OF-57227
    --using bulk collect with limit
    DECLARE
      --the cursor where all the information is stored
      CURSOR v_data IS
      SELECT RD_ID
        FROM    (SELECT RD_ID, ROW_NUMBER() OVER (PARTITION BY R.RD_DEFINITION_ID ORDER BY RD_ID DESC) RN
                FROM RUN_DATA R
                WHERE R.RD_DEFINITION_ID IS NOT NULL) T
        WHERE RN > NVL(v_prop, 10);
    BEGIN

        OPEN v_data;
        LOOP
          v_runs := NULL;
          FETCH v_data
          --bulk collect with limit
          BULK COLLECT INTO v_runs LIMIT TO_NUMBER(pin_chunk_size);

          DELETE FROM SQL_EXEC_PLAN_TABLE S
          WHERE (S.SQL_ID, S.CHILD_NUMBER) IN (SELECT RQP_SQL_ID, RQP_CHILD_NUMBER
                                              FROM RUN_PROFILE_QUERY_PLANS
                                              WHERE RQP_RD_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs)));

          DELETE FROM RUN_PROFILE_QUERY_PLANS S
          WHERE S.RQP_RD_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

          DELETE FROM RUNTIME_STATISTICS_INFO S
          WHERE S.RSI_RUN_ID IN (SELECT COLUMN_VALUE FROM TABLE(v_runs));

          --this process will repeat until all the data from the coursor will be covered
          EXIT WHEN v_data%NOTFOUND;

        END LOOP;
        CLOSE v_data;
     END;

      -- added in 15.5
      -- keep only 30 days of logs
      BEGIN SELECT TO_NUMBER(PR_VALUE) INTO v_prop FROM PROPERTIES WHERE PR_NAME = 'L4O_DAYS_TO_KEEP';
      EXCEPTION WHEN OTHERS THEN NULL;
      END;

      DELETE FROM L4O_LOGS L
      WHERE L.L4OL_DATE < pin_current_date - NVL(v_prop, 30);

      COMMIT;

    -- GET STATS OF-20964
    CALL_STATS(TABLETYPE_CHARMAX('RUN_DATA','LOGS_MESSAGES','LOGS_MESSAGE_COUNT'));

 END PURGE_PROCESS_LOGS;


/***********************************************/
/**Procedure called to delete records from: ALERT_NOTIFICATION_LOGS - Alerts Email**/
/***********************************************/
 PROCEDURE PURGE_ALERTS_EMAIL(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS

 BEGIN
  loop
    delete from ALERT_NOTIFICATION_LOGS anl
      where anl.ANL_DATE_TIME < pin_current_date - TO_NUMBER(pin_days)
        and rownum <= TO_NUMBER(pin_chunk_size);
    exit when SQL%ROWCOUNT = 0;
    commit;
  end loop;

 END PURGE_ALERTS_EMAIL;


/***********************************************/
/**Procedure called to delete records from: AC_USER_LOGIN_HISTORY - Login History**/
/***********************************************/
 PROCEDURE PURGE_LOGIN_HISTORY(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop
        delete from AC_USER_LOGIN_HISTORY lh
         where lh.AULH_LOGIN_DATE < pin_current_date - TO_NUMBER(pin_days)
           and rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

   -- GET STATS OF-20964
   CALL_STATS(TABLETYPE_CHARMAX('AC_USER_LOGIN_HISTORY'));

 END PURGE_LOGIN_HISTORY;



/***********************************************/
/**Procedure called to delete records from: PORTAL_ERRORS_DAYS - PORTAL_ERRORS_DAYS**/
/***********************************************/
 PROCEDURE PURGE_PORTAL_ERRORS_DAYS(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop
        delete from PORTAL_ERRORS lh
         where lh.DATE_TIME < pin_current_date - TO_NUMBER(pin_days)
           and rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

 END PURGE_PORTAL_ERRORS_DAYS;

/***********************************************/
/**Procedure called to delete expired tables that were backed up**/
/***********************************************/
 PROCEDURE PURGE_BACKED_UP_TABLES(pin_current_date in timestamp, pin_chunk_size in varchar2)
    AS
    BEGIN
        LOOP
            DELETE FROM BACKED_UP_TABLES
            WHERE BUT_EXPIRATION_DATE < pin_current_date
            AND rownum <= TO_NUMBER(pin_chunk_size);
                EXIT WHEN SQL%ROWCOUNT = 0;
            COMMIT;
        END LOOP;
 END PURGE_BACKED_UP_TABLES;

/***********************************************/
/**Procedure called to delete records from: OAUTH_USER_AGREEMENTS - Auth User Agreements**/
/***********************************************/
 PROCEDURE PURGE_OAUTH_USER_AGREEMENTS(pin_current_date in timestamp, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop
        delete from OAUTH_USER_AGREEMENTS ou
         where ou.OUA_EXP_TIMESTAMP < pin_current_date
           and rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

 END PURGE_OAUTH_USER_AGREEMENTS;

/***********************************************/
/**Procedure called to delete records from: OAUTH_TOKENS - Tokens**/
/***********************************************/
 PROCEDURE PURGE_OAUTH_TOKENS(pin_current_date in timestamp, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop
        delete from OAUTH_TOKENS ot
         where ot.OT_EXP_TIMESTAMP < pin_current_date
           and rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

 END PURGE_OAUTH_TOKENS;

/***********************************************/
/**Procedure called to delete records from: OAUTH_PAM_TOKENS - Tokens**/
/***********************************************/
 PROCEDURE PURGE_OAUTH_PAM_TOKENS(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop
        delete from OAUTH_PAM_TOKENS opt
         where opt.OPT_LAST_USED < pin_current_date - TO_NUMBER(pin_days)
           and rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

 END PURGE_OAUTH_PAM_TOKENS;

/***********************************************/
/**Procedure called to delete unused hints**/
/***********************************************/
 PROCEDURE PURGE_HINTS(pin_current_date in timestamp, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop

    DELETE FROM processing_query_hints
    WHERE pqh_module_identifier IN ('MERGEFIELDS','RANK_RECORDS','AGGREGATE_RECORDS','CALCULATE_RUNNING_TOTALS','CALCULATE_FIELDS','DT_MERGE_RECORDS.RUN_MERGE_RECORDS','DELETERECORDS')
    AND pqh_process_def_id is not null
    AND NOT EXISTS ( SELECT 1 FROM dt_operations WHERE dto_id = pqh_process_def_id )
    AND rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

 END PURGE_HINTS;

/***********************************************/
/**Procedure called to delete unused hints**/
/***********************************************/
 PROCEDURE PURGE_HOOKS(pin_current_date in timestamp, pin_chunk_size in varchar2)
 AS

 BEGIN
   loop
      DELETE FROM PROCESSING_DBA_HOOKS
      WHERE prh_process_type_id IN (
            Select PROCESS_TYPE_ID from UTL_PROCESS_TYPE
            where process_type_name in ('Merge Fields','Rank Records','Aggregate Records','Calculate Running Totals','Calculate Fields','Merge Records','Delete Records')
        )
      AND prh_process_def_id is not null
      AND NOT EXISTS(SELECT 1 FROM dt_operations WHERE dto_id = prh_process_def_id)
      AND rownum <= TO_NUMBER(pin_chunk_size);
        exit when SQL%ROWCOUNT = 0;
        commit;
    end loop;

 END PURGE_HOOKS;

/***********************************************/
/**Procedure called to delete records from: PORTAL_USAGE - Portal Usage **/
/***********************************************/
 PROCEDURE PURGE_PORTAL_USAGE(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS

 BEGIN

  loop
    delete from PORTAL_USAGE p
     where p.date_time < pin_current_date - TO_NUMBER(pin_days)
       and rownum <= TO_NUMBER(pin_chunk_size);
    exit when SQL%ROWCOUNT = 0;
    commit;
  end loop;

  -- GET STATS OF-20964
  CALL_STATS(TABLETYPE_CHARMAX('PORTAL_USAGE'));

 END PURGE_PORTAL_USAGE;


 /***********************************************/
/**Procedure called to delete records from: UNDO_DDL_HISTORY **/
/***********************************************/
 PROCEDURE PURGE_UNDO_DDL_HISTORY(pin_current_date in timestamp,pin_days in varchar2, pin_chunk_size in varchar2)
 AS

 BEGIN

  loop
    delete from UNDO_DDL_HISTORY u
     where u.UD_CALLER_TIMESTAMP < pin_current_date - TO_NUMBER(pin_days)
       and rownum <= TO_NUMBER(pin_chunk_size);
    exit when SQL%ROWCOUNT = 0;
    commit;
  end loop;

 END PURGE_UNDO_DDL_HISTORY;



/***********************************************/
/**Procedure called to purge logs**/
/***********************************************/
  PROCEDURE PURGE_LOGS(pin_purge_type IN number)
  AS
    v_current_date       	TIMESTAMP;
    v_process_logs_days  	PROPERTIES.PR_VALUE%TYPE;
    v_login_history_days 	PROPERTIES.PR_VALUE%TYPE;
	  v_undo_ddl_history_days	PROPERTIES.PR_VALUE%TYPE;
    v_portal_usage_days  	PROPERTIES.PR_VALUE%TYPE;
    v_chunk_size         	PROPERTIES.PR_VALUE%TYPE;
    v_portal_error_days   PROPERTIES.PR_VALUE%TYPE;
    v_oauth_pam_tokens    PROPERTIES.PR_VALUE%TYPE;

  BEGIN

    select PR_VALUE into v_chunk_size from PROPERTIES where PR_NAME = 'PURGE_CHUNK_SIZE';
    select (CURRENT_TIMESTAMP AT TIME ZONE 'GMT') into v_current_date FROM DUAL;

    if pin_purge_type = 1 then -- 1. Purge LOGS for Process Logs
      select PR_VALUE into v_process_logs_days  from PROPERTIES where PR_NAME = 'PURGE_PROCESS_LOGS_DAYS';

      -- purge the process logs data
      PURGE_PROCESS_LOGS(v_current_date,v_process_logs_days,v_chunk_size);

      -- OF-12131 Integrate the Alerts Email logs into the Purge logs feature
      PURGE_ALERTS_EMAIL(v_current_date,v_process_logs_days,v_chunk_size);

      -- OF-41917 Cleanup all the unused hints
      PURGE_HINTS(v_current_date,v_chunk_size);

      -- OF-41917 Cleanup all the unused hooks
      PURGE_HOOKS(v_current_date,v_chunk_size);

      -- OF-66348 Cleanup BACKED_UP_TABLES
      PURGE_BACKED_UP_TABLES(v_current_date,v_chunk_size);

    elsif pin_purge_type = 2 then -- 2. Purge LOGS for Login History
      select PR_VALUE into v_login_history_days from PROPERTIES where PR_NAME = 'PURGE_LOGIN_HISTORY_DAYS';
      select PR_VALUE into v_undo_ddl_history_days from PROPERTIES where PR_NAME = 'PURGE_DDL_HISTORY';
      select PR_VALUE into v_oauth_pam_tokens from PROPERTIES where PR_NAME = 'PURGE_OAUTH_PAM_TOKENS';

      -- purge login history
      PURGE_LOGIN_HISTORY(v_current_date,v_login_history_days,v_chunk_size);

      -- purge undo ddl history
      PURGE_UNDO_DDL_HISTORY(v_current_date,v_undo_ddl_history_days,v_chunk_size);

      -- purge OAUTH_USER_AGREEMENTS
      PURGE_OAUTH_USER_AGREEMENTS(v_current_date,v_chunk_size);

      -- purge OAUTH_TOKENS
      PURGE_OAUTH_TOKENS(v_current_date,v_chunk_size);

      --purge OAUTH_PAM_TOKENS
      PURGE_OAUTH_PAM_TOKENS(v_current_date,v_oauth_pam_tokens,v_chunk_size);

    elsif pin_purge_type = 3 then -- 3. Purge LOGS for Portal Usage
      select PR_VALUE into v_portal_usage_days from PROPERTIES where PR_NAME = 'PURGE_PORTAL_USAGE_DAYS';
      -- purge portal usage
      PURGE_PORTAL_USAGE(v_current_date,v_portal_usage_days,v_chunk_size);

    elsif pin_purge_type = 4 then -- 4. Purge LOGS for PORTAL ERRORS
      SELECT PR_VALUE into v_portal_error_days from PROPERTIES where PR_NAME = 'PURGE_PORTAL_ERRORS_DAYS';
      -- purge portal errors
      PURGE_PORTAL_ERRORS_DAYS(v_current_date,v_portal_error_days,v_chunk_size);

    end if;

  END PURGE_LOGS;

/***********************************************/
/**Procedure called to create/update jobs and the schedule when the jobs are run. **/
/***********************************************/
  PROCEDURE REPROGRAM_PURGE_JOBS(pin_process_logs_days  IN VARCHAR2,
                           pin_login_history_days IN VARCHAR2,
                           pin_portal_usage_days  IN VARCHAR2,
                           pin_start_hour         IN VARCHAR2,
                           pin_start_minute       IN VARCHAR2,
                           pin_timezone           IN VARCHAR2,
						               pin_portal_errors_days IN VARCHAR2 DEFAULT '365')  AS

    TYPE job_list_type IS  TABLE OF varchar2(255) INDEX BY PLS_INTEGER;
    job_list               job_list_type;
    v_exists               NUMBER;
    v_timezone             TIME_ZONES.TZ_JAVA_ID%TYPE;
    v_scheduler_start_time VARCHAR2(250 CHAR);
    v_check_start_hour     PROPERTIES.PR_VALUE%TYPE;
    v_check_start_minute   PROPERTIES.PR_VALUE%TYPE;
    v_check_timezone       PROPERTIES.PR_VALUE%TYPE;
    v_check_portal_errors_days  PROPERTIES.PR_VALUE%TYPE;
    v_stamp                VARCHAR2(250);
  BEGIN

    v_stamp := 'PURGE_RECORDS.REPROGRAM_PURGE_JOBS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_process_logs_days), ',pin_process_logs_days => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_login_history_days),',pin_login_history_days => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_portal_usage_days), ',pin_portal_usage_days => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_start_hour),        ',pin_start_hour => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_start_minute),      ',pin_start_minute => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_timezone),          ',pin_oupin_timezonetput_columns => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_portal_errors_days),  ',pin_portal_errors_days => <value>', v_stamp);
    END;

    -- Get The current parameter values
    select PR_VALUE into v_check_start_hour    from PROPERTIES WHERE PR_NAME = 'PURGE_JOB_HOUR';
    select PR_VALUE into v_check_start_minute  from PROPERTIES WHERE PR_NAME = 'PURGE_JOB_MINUTE';
    select PR_VALUE into v_check_timezone      from PROPERTIES WHERE PR_NAME = 'PURGE_JOB_TIMEZONE';
    select PR_VALUE into v_check_portal_errors_days  from PROPERTIES WHERE PR_NAME = 'PURGE_PORTAL_ERRORS_DAYS';

    -- Update the properties table
    update PROPERTIES set PR_VALUE = pin_process_logs_days  where PR_NAME = 'PURGE_PROCESS_LOGS_DAYS';
    update PROPERTIES set PR_VALUE = pin_login_history_days where PR_NAME = 'PURGE_LOGIN_HISTORY_DAYS';
    update PROPERTIES set PR_VALUE = pin_portal_usage_days  where PR_NAME = 'PURGE_PORTAL_USAGE_DAYS';
    update PROPERTIES set PR_VALUE = pin_portal_errors_days  where PR_NAME = 'PURGE_PORTAL_ERRORS_DAYS';

    if v_check_start_hour != pin_start_hour then
      update PROPERTIES set PR_VALUE = pin_start_hour    where PR_NAME = 'PURGE_JOB_HOUR';
    end if;

    if v_check_start_minute != pin_start_minute then
      update PROPERTIES set PR_VALUE = pin_start_minute  where PR_NAME = 'PURGE_JOB_MINUTE';
    end if;

    if v_check_timezone != pin_timezone then
      update PROPERTIES set PR_VALUE = pin_timezone      where PR_NAME = 'PURGE_JOB_TIMEZONE';
    end if;

    -- get the start time for the schedule based on the timezone received as parameter
    select extractvalue(xmltype(OD_DEFINITION), '/timeZone/javaTimeZoneId') into v_timezone
      from OBJECT_DEFINITIONS where OD_TYPE = 30 AND OD_DEFINITION LIKE '%<abbreviation>' || pin_timezone || '</abbreviation>%';
    execute immediate 'select TO_CHAR((localtimestamp at time zone '''||v_timezone||'''),''DD/MON/YYYY HH:MI:SS AM TZR'') FROM DUAL' into v_scheduler_start_time;

    -- Create SCHEDULE if it does not exist
    select count(1) into v_exists from USER_SCHEDULER_SCHEDULES where SCHEDULE_NAME = 'PURGE_LOGS_SCHEDULE' AND ROWNUM <= 1;

    if v_exists = 0 then
      execute immediate 'BEGIN DBMS_SCHEDULER.CREATE_SCHEDULE(
                                      schedule_name => ''PURGE_LOGS_SCHEDULE'',
                                      start_date => '''|| to_timestamp_tz(v_scheduler_start_time,'DD/MON/YYYY HH:MI:SS AM TZR') || ''',
                                      repeat_interval => ''FREQ=DAILY; BYHOUR=' || pin_start_hour || '; BYMINUTE='|| pin_start_minute ||''',
                                      comments => ''Runs daily at the specified hour.''); END;';
    else
         -- update start_date if timezone changed
         if v_check_timezone != pin_timezone then
           execute immediate 'BEGIN DBMS_SCHEDULER.SET_ATTRIBUTE(
                                        name => ''PURGE_LOGS_SCHEDULE'',
                                        attribute => ''start_date'',
                                        value => '''|| v_scheduler_start_time || '''); END;';
         end if;
         -- update start_hour and start_minute
         if v_check_start_hour != pin_start_hour OR v_check_start_minute != pin_start_minute then
           execute immediate 'BEGIN DBMS_SCHEDULER.SET_ATTRIBUTE(
                                        name => ''PURGE_LOGS_SCHEDULE'',
                                        attribute => ''repeat_interval'',
                                        value => ''FREQ=DAILY; BYHOUR='|| pin_start_hour ||'; BYMINUTE='|| pin_start_minute ||'''); END;';
         end if;
    end if;

    -- Create the JOBS
    job_list(1) :='PURGE_PROCESS_LOGS_JOB';
    job_list(2) :='PURGE_LOGIN_HISTORY_JOB';
    job_list(3) :='PURGE_PORTAL_USAGE_JOB';
    job_list(4) :='PURGE_PORTAL_ERRORS_DAYS_JOB';

    for indx in 1..job_list.COUNT loop
      -- Check if the job already exists
      select count(1) into v_exists from USER_SCHEDULER_JOBS where JOB_NAME = job_list(indx) AND ROWNUM <= 1;

      if v_exists = 0 then
        dbms_output.put_line('Creating the job: ' ||  job_list(indx));
        DBMS_SCHEDULER.CREATE_JOB(
                        job_name => job_list(indx),
                        job_type => 'STORED_PROCEDURE',
                        job_action => 'PURGE_RECORDS.PURGE_LOGS',
                        number_of_arguments => 1,
                        schedule_name => 'PURGE_LOGS_SCHEDULE');
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(job_name => job_list(indx), argument_position => 1, argument_value => indx);
        DBMS_SCHEDULER.ENABLE(name => job_list(indx));
      end if;
    end loop;

  END REPROGRAM_PURGE_JOBS;

/***********************************************/
/**Procedure called to createa backup of a table **/
/***********************************************/
  PROCEDURE BACKUP_TABLES(
                   pin_table_name IN VARCHAR2,
                   pin_days IN NUMBER,
                   pin_comments IN VARCHAR2)
  AS
    v_stamp        VARCHAR2(250);
    v_name         VARCHAR2(30);
  BEGIN
    v_stamp := 'PURGE_RECORDS.BACKUP_TABLES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log the input parameters
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_table_name), ',pin_table_name => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pin_days),',pin_days => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_comments), ',pin_comments => <value>', v_stamp);

    --setting the backup name
    IF (LENGTH( pin_table_name ) > 19) THEN
      v_name := SUBSTR(pin_table_name,1,19) || '_' || UID_SEQUENCE.NEXTVAL;
    ELSE
       v_name := pin_table_name || '_' || UID_SEQUENCE.NEXTVAL;
    END IF;

    --creating the table and placing the data content
    EXECUTE IMMEDIATE 'CREATE TABLE '|| v_name ||' AS
           (
                 SELECT * FROM '|| pin_table_name ||'
           )';

    --inserting into the table that keeps track of the backed up tables
    INSERT INTO BACKED_UP_TABLES(
            BUT_ID,
            BUT_ORIGINAL_NAME,
            BUT_BACKEDUP_NAME,
            BUT_CREATION_DATE,
            BUT_EXPIRATION_DATE,
            BUT_COMMENTS)
    VALUES (
           UID_SEQUENCE.NEXTVAL,
           pin_table_name,
           v_name,
           CURRENT_TIMESTAMP,
           CURRENT_TIMESTAMP + pin_days,
           pin_comments
           );
    COMMIT;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(v_name), ',v_name => <value>', v_stamp);
  END BACKUP_TABLES;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END PURGE_RECORDS;
/
