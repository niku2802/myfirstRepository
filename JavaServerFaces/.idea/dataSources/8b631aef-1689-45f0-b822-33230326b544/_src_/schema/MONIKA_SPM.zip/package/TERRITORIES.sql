CREATE PACKAGE TERRITORIES AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : territories
-- Module           : territories
-- Requester        : Horlescu, Gabriel
-- Author           : Macarie, Sabina
-- Reviewer         :
-- Review date      : 21 JUL 2015
-- Description      : Package used to handle all TERRITORIES processing
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150721
  -- Description: Filter metrics tables: data tables that contain the entity represented by map pins
  --                                     data tables that have either non effective records, or have records effective for a period or
  --                                               range of periods for the same time unit as the territories period, or have records effective for a period or range of periods
  --                                               for a corresponding period higher in time unit than the territories period
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_terr_id            NUMBER   ID of the time unit specified in the Territories definition
     pi_pin_entity_id      NUMBER   The pin entity ID

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(TERRITORIES.FILTER_METRICS_TABLES(638, 2977260))
  */
  -----------------------------------------------------------------------------------------
  FUNCTION FILTER_METRICS_TABLES(pi_terr_frequency   NUMBER,
                                 pi_pin_entity_id    NUMBER,
                                 pi_is_dated         NUMBER)
    RETURN TABLETYPE_ID_NAME;


  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150722
  -- Description: Filter entity tables: entity tables that have in its structure the Latitude and Longitude system fields
  --                                    entity tables that are not nodes in the organization hierarchy
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_terr_org_entities_list   VARCHAR2   A list of entities that are in the organization hierarchy

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(TERRITORIES.FILTER_ENTITY_TABLES('123, 345'))
  */
  -----------------------------------------------------------------------------------------
    FUNCTION FILTER_ENTITY_TABLES(pi_terr_org_entities_list VARCHAR2)
    RETURN TABLETYPE_NUMBER;

  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150724
  -----------------------------------------------------------------------------------------
  -- Description: Filter hierarchy tables:
                  -- hierarchy tables that have in their structure nodes with either no subordinate or only one subordinate
                  -- hierarchy tables that either have no effective range, or have an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- Input Parameters:
  /*
     pi_terr_frequency   VARCHAR2   The frequency set in the territory definition

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(TERRITORIES.FILTER_HIERARCHY_TABLES(241))
  */
  -----------------------------------------------------------------------------------------
  FUNCTION FILTER_HIERARCHY_TABLES(pi_terr_frequency   NUMBER,
                                   pi_is_dated         NUMBER)
  RETURN TABLETYPE_NUMBER;
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  PROCEDURE GET_CUSTOMER_DATA (pin_assigned_entities_query  IN CLOB,
                               pin_leaf_entities_validation IN CLOB,
                               pin_leaf_customers_query     IN CLOB,
                               pin_fill_size_query          IN CLOB,
                               pout_customer_to_oh_entities OUT SYS_REFCURSOR,
                               pout_customer_fill_size      OUT SYS_REFCURSOR);

  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20160601
  -----------------------------------------------------------------------------------------
  -- Description: Territories View Validations

  /*

  -20920 - Metric tables validation
  -- If pin entity/territory entity is in metric table
  -- If the territory definition period is not Day :  -- metric table has either no effective range, or has an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- If the territory definition is Day -- metric table is either effective dated or not effective
  -- Field is in entity table or in metric table

  -20922 - Entities sub tab
  - The assignment table is an assignment between the specified entities (i.e., the entity that is the lowest node in the organization hierarchy and the entity represented by map pins)
  - If the territory definition period is not Day :  -- assign table has either no effective range, or has an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  - If the territory definition is Day -- assign table is either effective dated or not effective

  -20924 - User Assignments sub tab
  - The selected entity is still not in the User Table
  - The selected user entity still exists in the User Table
  - The selected assignment table is still an assignment between the selected Entity and User Entity entities (i.e., both the entity for which the assignment table
                     is specified and the user entity exist in the assignment table)
  - If the territory definition period is not Day :  -- assign tables have either no effective range, or have an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  - If the territory definition is Day -- assign table is either effective dated or not effective

  -20923 - Hierarchy Validations
  - If the territory definition period is not Day :  -- hierarchy table has either no effective range, or has an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  - If the territory definition is Day -- assign table is either effective dated or not effective

  -20921 - Lists Settings
  - One or more fields selected on the List Display sub tab are no longer fields for the entity table specified on the List Metrics sub tab

  -20925 - Panel Display sub tab
  -One or more fields specified on the Gauge Chart Metrics sub tab or on the List Metrics sub tab for lists that have the option to display a bar chart
                     for each entity instance in the list is selected are displayed as percentage fields

  */

  -- Input Parameters:
  /*
     pi_pin_entity_id              IN entities.entity_id%TYPE,
     pi_territory_entity_id        IN entities.entity_id%TYPE,
     pi_tu_id                      IN time_units.tu_id%TYPE,
     pi_table_fields_map           IN tabletype_territories_map,
     pi_metric_ent_field_map       IN tabletype_territories_map,
     pi_terr_to_cust_assignment_id IN NUMBER,
     pi_hierarchy_table_id         IN NUMBER,
     pi_user_assignment_ids        IN tabletype_territories_map,
     pi_fields_list                IN tabletype_number
     pi_option                     IN NUMBER                           - Option for Right Panel validations - if 1 then only first 3 validations are executed
  */
    -----------------------------------------------------------------------------------------
  PROCEDURE METRIC_VALIDATIONS(pi_pin_entity_id                  IN entities.entity_id%TYPE,
                               pi_territory_entity_id            IN entities.entity_id%TYPE,
                               pi_tu_id                          IN time_units.tu_id%TYPE,
                               pi_table_fields_map               IN tabletype_territories_map,
                               pi_metric_ent_field_map           IN tabletype_territories_map,
                               pi_terr_to_cust_assignment_id     IN NUMBER,
                               pi_hierarchy_table_id             IN NUMBER,
                               pi_user_assignment_ids            IN tabletype_territories_map,
                               pi_fields_list                    IN tabletype_number,
                               pi_option                         IN NUMBER,
                               pi_user_entity_id                 IN NUMBER
                              );
  -- *******************************    PUBLIC PROCEDURES END         *******************************

END TERRITORIES;
/
