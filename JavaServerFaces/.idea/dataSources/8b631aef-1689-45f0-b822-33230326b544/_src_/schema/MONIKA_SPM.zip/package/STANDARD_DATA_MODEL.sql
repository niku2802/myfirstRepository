CREATE PACKAGE STANDARD_DATA_MODEL AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2017 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.

  -- *******************************    PUBLIC PROCEDURES START         *******************************

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20170519
  -- Description: Returns the technical name of an equivalent entity based on the technical name of the base entity
  -- and the entity name of the equivalent entity
  -- plus link jira / confluence
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_entity_technical_name  varchar2 Technical name of the base entity
     pin_equivalent_entity_name varchar2 Entity name of the equivalent entity (ID replaces the entity id of the base entity)
  */
  -- plus output
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    v_equiv_entity_tech_name := standard_data_model.get_equivalent_entity ('Product Category_User'
                                                                          ,'|~ID~| Upper'
                                                                         );
  */
  -----------------------------------------------------------------------------------------
  function get_equivalent_entity(pin_entity_technical_name  varchar2,
                                 pin_equivalent_entity_name varchar2)
    return varchar2;
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20170519
  -- Description: Adds an equivalent entity based on the technical name of the base entity and the entity name of the equivalent entity
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_entity_technical_name  varchar2 Technical name of the base entity
     pin_equivalent_entity_name varchar2 Entity name of the equivalent entity (ID replaces the entity id of the base entity)
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    begin
      standard_data_model.add_equivalent_entity ('Product Category_User'
                                                ,'|~ID~| Upper'
                                                );
    end;
  */
  -----------------------------------------------------------------------------------------
  procedure add_equivalent_entity(pin_entity_technical_name  varchar2,
                                  pin_equivalent_entity_name varchar2);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20170510
  -- Description: Support for adding system folders
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_folder_name    varchar2 Folder name
     pin_object_type_id number   Object type IDs that can be stored in this folder
     pin_container_id   number   Folder container id/portal application id
     pin_folder_label   varchar2 The label of the folder
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    -- raise error if the folder name is longer than 26 characters (in case we may need to add ' SDM')
    raise_application_error(-20001,'Folder ' || pin_folder_name || ' has a name over 26 characters.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    begin
      standard_data_model.add_system_folder ('Standard Data Tables'
                                            ,10
                                            ,null
                                            ,'Standard Data Tables'
                                           );
    end;
  */
  -----------------------------------------------------------------------------------------
  procedure add_system_folder(pin_folder_name    varchar2,
                              pin_object_type_id number,
                              pin_container_id   number,
                              pin_folder_label   varchar2);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20170509
  -- Description: Support for adding system fields
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_fld_business_name          varchar2 The column name that appears in UI
     pin_fld_column_name            varchar2 Physical Name of column
     pin_fld_length                 number   The size of the field
     pin_fld_data_type              number   1-Character field, 2-Boolean field, 3-Date field, 4-Note field, 5-Datetime field, 6-Numeric field, 8 - Period Field, 9 - Attachment
     pin_fld_timeunit               number   TimeUnit ID
     pin_fld_base_field             number   Id of the refecenced field based upon this row's information
     pin_fld_display_1000_separator number   Specifies if Thousand Seperator is applicable - YES(1), NO(0). the property is applicable only to numeric fields i.e.fld_data_type = 6. For rest of the fields it will be null
     pin_fld_display_as_percent     number   Specifies if display as percent attribute is applicable - YES(1), NO(0). the property is applicable only to numeric fields i.e.fld_data_type = 6. For rest of the fields it will be null
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    -- raise error if the field business name is longer than 26 characters (in case we may need to add ' SDM')
    raise_application_error(-20001,'Field ' || pin_fld_business_name || ' has a name over 26 characters.');

    -- raise error if there is another system field with the same business name
    raise_application_error(-20002,'Field ' || pin_fld_business_name || ' already exists as a system field.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    begin
      standard_data_model.add_system_field ('Accelerator'
                                           ,'ACCELERATOR'
                                           ,4
                                           ,6
                                           ,null
                                           ,null
                                           ,1
                                           ,0
                                           );
    end;
  */
  -----------------------------------------------------------------------------------------
  procedure add_system_field(pin_fld_business_name          varchar2,
                             pin_fld_column_name            varchar2,
                             pin_fld_length                 number,
                             pin_fld_data_type              number,
                             pin_fld_timeunit               number,
                             pin_fld_base_field             number,
                             pin_fld_display_1000_separator number,
                             pin_fld_display_as_percent     number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20170516
  -- Description: Support for adding system entities
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_tx_id                varchar2 The transaction id retrieved with commons_ddl_handling.get_transaction_id
     pin_entity_name          varchar2 Name of the entity
     pin_entity_category_type number   Category type of the entity
     pin_entity_fields        clob     XML file containing details about the fields in the entity
                                       Has the following structure:
                                       <EntityFields>
                                         <field>
                                             <technical_name>ENTITIES.ENTITY_TECHNICAL_NAME</technical_name>
                                             <is_required>TABLE_COLUMNS.TC_IS_REQUIRED</is_required>
                                             <field_order>TABLE_COLUMNS.TC_ORDER</field_order>
                                             <display_order>Display order</display_order>
                                             <logic_type>TABLE_COLUMNS.TC_LOGIC_TYPE </logic_type>
                                         </field>
                                       </EntityFields>
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    -- raise error if the entity name is longer than 26 characters (in case we may need to add ' SDM')
    raise_application_error(-20001,'Entity ' || v_business_name || ' has a name over 26 characters.');

    -- raise error if there is another system entity with the same business name
    raise_application_error(-20002,'Entity ' || v_business_name || ' already exists as a system entity.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example: -- investigate using json instead of xml
  /*
  begin
    standard_data_model.add_system_entity(pin_tx_id => '1.1.1',
                                          pin_entity_name => 'SDM Test Entity',
                                          pin_entity_category_type => 1,
                                          pin_entity_fields => '<EntityFields>
                                                                     <field>
                                                                         <technical_name>Acceleratoru_User</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>1</field_order>
                                                                         <display_order>1</display_order>
                                                                         <logic_type>1</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Access URL_Sys</technical_name>
                                                                         <is_required>0</is_required>
                                                                         <field_order>2</field_order>
                                                                         <display_order></display_order>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Action Details_Sys</technical_name>
                                                                         <is_required>0</is_required>
                                                                         <field_order>3</field_order>
                                                                         <display_order></display_order>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Action Performed_Sys</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>4</field_order>
                                                                         <display_order></display_order>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Status_Sys</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>5</field_order>
                                                                         <display_order>2</display_order>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                </EntityFields>'
                                          );
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure add_system_entity(pin_tx_id                varchar2,
                              pin_entity_name          varchar2,
                              pin_entity_category_type number,
                              pin_entity_fields        clob);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20170520
  -- Description: Support for adding system hierarchies
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_tx_id              varchar2              The transaction id retrieved with commons_ddl_handling.get_transaction_id
     pin_hierarchy_name     varchar2              Name of the hierarchy
     pin_time_unit_name     varchar2              Name of the time unit
     pin_effective_dated    number                Flag if effective dated - 0 or 1
     pin_hierarchy_elements coltype_hier_cols_sdm Column contaning the order and XML files with details about the fields in the hierarchy
                                                  Has the following structure:
                                                  HIER_ORDER number
                                                  HIER_FIELDS clob - xml file with following structure
                                                    <HierFields>
                                                      <field>
                                                         <entity_technical_name>Product Category_User</entity_technical_name>
                                                         <is_lower>1</is_lower>
                                                         <is_upper></is_upper>
                                                      </field>
                                                    </HierFields>
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    -- raise error if the hierarchy name is longer than 26 characters (in case we may need to add ' SDM')
    raise_application_error(-20001,'Hierarchy ' || v_business_name || ' has a name over 26 characters.');

    -- raise error if there is another system hierarchy with the same business name
    raise_application_error(-20002,'Hierarchy ' || v_business_name || ' already exists as a system entity.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    -- Call the procedure
    standard_data_model.add_system_hierarchy(pin_tx_id => '1.1.1',
                                             pin_hierarchy_name => 'Test Hierarchy',
                                             pin_time_unit_name => null,
                                             pin_effective_dated => 1,
                                             pin_hierarchy_elements => coltype_hier_cols_sdm(objtype_hier_cols_sdm(1,'<HierFields>
                                                                                                                           <field>
                                                                                                                               <entity_technical_name>Product Category_User</entity_technical_name>
                                                                                                                               <is_lower>1</is_lower>
                                                                                                                               <is_upper></is_upper>
                                                                                                                           </field>
                                                                                                                           <field>
                                                                                                                               <entity_technical_name>Product Category_User</entity_technical_name>
                                                                                                                               <is_lower></is_lower>
                                                                                                                               <is_upper>1</is_upper>
                                                                                                                           </field>
                                                                                                                      </HierFields>'
                                                                                                                   ),
                                                                                             objtype_hier_cols_sdm(2,'<HierFields>
                                                                                                                           <field>
                                                                                                                               <entity_technical_name>Product_User</entity_technical_name>
                                                                                                                               <is_lower>1</is_lower>
                                                                                                                               <is_upper></is_upper>
                                                                                                                           </field>
                                                                                                                           <field>
                                                                                                                               <entity_technical_name>Product Category_User</entity_technical_name>
                                                                                                                               <is_lower></is_lower>
                                                                                                                               <is_upper>1</is_upper>
                                                                                                                           </field>
                                                                                                                      </HierFields>')));
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure add_system_hierarchy(pin_tx_id              varchar2,
                                 pin_hierarchy_name     varchar2,
                                 pin_time_unit_name     varchar2,
                                 pin_effective_dated    number,
                                 pin_hierarchy_elements coltype_hier_cols_sdm);
  -- ========================================================

  -- ========================================================
  -- Author     : Andries, Adriana
  -- Create date: 20170516
  -- Description: Support for adding system assignment tables
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     PIN_TX_ID               -varchar2- The transaction id retrieved with commons_ddl_handling.get_transaction_id
     PIN_ASSIGNMENT_NAME     -varchar2- Name of the entity
     PIN_ASSIGNMENT_FIELDS   -clob-     XML file containing details about the fields in the assignment table
                                       Has the following structure:
                                     <TableFields>
                                               <field>
                                                   <technical_name>Acceleratoru_User</technical_name>
                                                   <is_required>1</is_required>
                                                   <field_order>1</field_order>
                                                   <display_order>1</display_order>
                                                   <entity_technical_name></entity_technical_name>
                                                   <logic_type>NONE(0), KEY(1), DATA(2), EFFECTIVE_START_DATE(3), EFFECTIVE_END_DATE(4),
                                                   AUTO_NUMBERED(5), EFFECTIVE_PERIOD_START(6), EFFECTIVE_PERIOD_END(7), EFFECTIVE_PERIOD(8), EFFECTIVE_DATE(9)</logic_type>
                                               </field>
                                      </TableFields>
      PIN_LEFT_ASGN_ENTITY   -VARCHAR2- The left entity of the assignment
      PIN_IS_EFFECTIVE_DATED -NUMBER -  Flag 0/1 whether or not the assignment is effective dated
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    -- raise error if the entity name is longer than 26 characters (in case we may need to add ' SDM')
    raise_application_error(-20001,'Entity ' || v_business_name || ' has a name over 26 characters.');

    -- raise error if there is another system entity with the same business name
    raise_application_error(-20002,'Entity ' || v_business_name || ' already exists as a system entity.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    standard_data_model.add_system_assignment(pin_tx_id => '1.1.1',
                                              PIN_ASSIGNMENT_NAME => 'SDM Test Assignment',
                                              PIN_ASSIGNMENT_FIELDS => '<TableFields>
                                                                     <field>
                                                                         <technical_name>Acceleratoru_User</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>1</field_order>
                                                                         <display_order>1</display_order>
                                                                         <entity_technical_name></entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Access URL_Sys</technical_name>
                                                                         <is_required>0</is_required>
                                                                         <field_order>2</field_order>
                                                                         <display_order></display_order>
                                                                         <entity_technical_name></entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Action Details_Sys</technical_name>
                                                                         <is_required>0</is_required>
                                                                         <field_order>3</field_order>
                                                                         <display_order></display_order>
                                                                         <entity_technical_name></entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>E6040672</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>4</field_order>
                                                                         <display_order></display_order>
                                                                         <entity_technical_name>MUCI7_User</entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                </TableFields>',
                                             PIN_LEFT_ASGN_ENTITY => 'MUCI7_User' ,
                                             PIN_IS_EFFECTIVE_DATED => 0
                                          );
  end;
  */

  PROCEDURE ADD_SYSTEM_ASSIGNMENT(PIN_TX_ID              VARCHAR2,
                                  PIN_ASSIGNMENT_NAME    VARCHAR2,
                                  PIN_ASSIGNMENT_FIELDS  CLOB,
                                  PIN_LEFT_ASGN_ENTITY   VARCHAR2,
                                  PIN_IS_EFFECTIVE_DATED NUMBER);

  -- ========================================================
  -- Author     : Andries, Adriana
  -- Create date: 20170516
  -- Description: Support for adding system tables
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_tx_id                varchar2 The transaction id retrieved with commons_ddl_handling.get_transaction_id
     pin_data_table_name          varchar2 Name of the entity
     pin_data_table_fields        clob     XML file containing details about the fields in the table
                                       Has the following structure:
                                       <TableFields>
                                               <field>
                                                   <technical_name>Acceleratoru_User</technical_name>
                                                   <is_required>1</is_required>
                                                   <field_order>1</field_order>
                                                   <display_order>1</display_order>
                                                   <entity_technical_name></entity_technical_name>
                                                   <logic_type>NONE(0), KEY(1), DATA(2), EFFECTIVE_START_DATE(3), EFFECTIVE_END_DATE(4),
                                                   AUTO_NUMBERED(5), EFFECTIVE_PERIOD_START(6), EFFECTIVE_PERIOD_END(7), EFFECTIVE_PERIOD(8), EFFECTIVE_DATE(9)</logic_type>
                                               </field>
                                      </TableFields>
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    -- raise error if the entity name is longer than 26 characters (in case we may need to add ' SDM')
    raise_application_error(-20001,'Entity ' || v_business_name || ' has a name over 26 characters.');

    -- raise error if there is another system entity with the same business name
    raise_application_error(-20002,'Entity ' || v_business_name || ' already exists as a system entity.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    standard_data_model.add_system_data_table(pin_tx_id => '1.1.1',
                                              PIN_DT_NAME => 'SDM Test Data table',
                                              PIN_DT_FIELDS => '<TableFields>
                                                                     <field>
                                                                         <technical_name>Acceleratoru_User</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>1</field_order>
                                                                         <display_order>1</display_order>
                                                                         <entity_technical_name></entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Access URL_Sys</technical_name>
                                                                         <is_required>0</is_required>
                                                                         <field_order>2</field_order>
                                                                         <display_order></display_order>
                                                                         <entity_technical_name></entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>Action Details_Sys</technical_name>
                                                                         <is_required>0</is_required>
                                                                         <field_order>3</field_order>
                                                                         <display_order></display_order>
                                                                         <entity_technical_name></entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                     <field>
                                                                         <technical_name>E6040672</technical_name>
                                                                         <is_required>1</is_required>
                                                                         <field_order>4</field_order>
                                                                         <display_order></display_order>
                                                                         <entity_technical_name>MUCI7_User</entity_technical_name>
                                                                         <logic_type>2</logic_type>
                                                                     </field>
                                                                </TableFields>'
                                          );
  end;
  */

  PROCEDURE ADD_SYSTEM_DATA_TABLE(PIN_TX_ID     VARCHAR2,
                                  PIN_DT_NAME   VARCHAR2,
                                  PIN_DT_FIELDS CLOB);

  -- used for testing the renaming of the system fields
  function get_new_field_name(pin_fld_business_name varchar2) return varchar2;

  -- ========================================================
  -- Author     : Dumitriu, Cosmin
  -- Create date: 20170728
  -- Description: Support for setting existing entity attributes as display fields.
  --              The procedure will add the provided fields to the already existing display fields.
  --              This is because the user might have already changed the order of display fields so we do not want to lose that.
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_entity_qualified_name      VARCHAR2 - not null
                                    - the technical name of the system entity
    ,pin_display_fields_list        CLOB - not null
                                    - an xml list of <field technical name, order of display field> pairs
  */
  -----------------------------------------------------------------------------------------
  -- Exceptions returned by the procedure:
  /*
    RAISE_APPLICATION_ERROR(-20001, 'Entity ' || pin_entity_qualified_name ||' has not been found.');
    RAISE_APPLICATION_ERROR(-20001, 'Field ' || c.EDF_TECHNICAL_NAME ||' has been specified more than once.');
    RAISE_APPLICATION_ERROR(-20001, 'Field ' || c.EDF_TECHNICAL_NAME ||' has not been found.');
    RAISE_APPLICATION_ERROR(-20001, 'Field ' || c.EDF_TECHNICAL_NAME ||' is not part of the entity structure.');
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    STANDARD_DATA_MODEL.ADD_ENTITY_DISPLAY_FIELDS
    (    pin_entity_qualified_name  => 'Territory_Sys'
        ,pin_display_fields_list    => '<display_fields><field><technical_name>Territory ID_Sys</technical_name>    <display_order>1</display_order></field>
                                                        <field><technical_name>Territory Name_Sys</technical_name>  <display_order>2</display_order></field>
                                                        <field><technical_name>Description_Sys</technical_name>     <display_order>3</display_order></field>
                                                        <field><technical_name>Active_Sys</technical_name>          <display_order>4</display_order></field></display_fields>'
    );
  end;
  */
  -----------------------------------------------------------------------------------------
  PROCEDURE ADD_ENTITY_DISPLAY_FIELDS(pin_entity_qualified_name VARCHAR2,
                                      pin_display_fields_list   CLOB);
  PROCEDURE ADD_CDM_TIME_UNIT(PI_TU_NAME       IN VARCHAR2,
                              PI_YEARS_RANGE   IN v_tu_years_type,
                              PI_PERIODS_RANGE v_TU_PERIODS_RANGE_type);
  PROCEDURE ADD_CDM_TIME_UNIT_CORR(PI_TU_NAME VARCHAR2);
  -- *******************************    PUBLIC PROCEDURES END         *******************************

END STANDARD_DATA_MODEL;
/
