CREATE PACKAGE COMMONS_PROCESSING AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: commons
-- Module			: processing-commons
-- Requester		: Cozac, Tudor
-- Author			: Dumitriu, Cosmin
-- Reviewer			: Cozac, Tudor
-- Review date		: 2012.03.19
-- Description		: This package contains utilities related to processing commons
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************

/* EXECUTE_PROCESSING_HOOK
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2012.03.14
-- Description	: This procedure is executed by the processing framework before and after each process in order to run any
                  aiding queries included by the DBA for that particular process (in PROCESSING_DBA_HOOKS table).
                  It can also be called from any client process code with a particular location name.
-----------------------------------------------------------
Parameters:
	 pi_process_def_id	        NUMBER
        - NOT NULL
        - the ID of the process for which the hooks have to be executed
    ,pi_process_type_id         NUMBER
        - NOT NULL
        - the type of the process - this is needed for ICM where roster, plan and payment process have the same def_id
	,pi_hook_location	        VARCHAR2
        - NOT NULL
        - the type of hooks to execute for the given process.
        - At least two possible values exist:
            * 'BEFORE' - for any hooks to be executed before running the process
            * 'AFTER' - for any hooks to be executed after running the process, but before clearing temporary resources
            * any other location specified by developers that are different then 'BEFORE' and 'AFTER' reserved location identifiers
    ,pi_run_id                  NUMBER
        - NULL
        - if available, the run_id of the process being executed.
    ,pi_run_completion_status   NUMBER
        - NULL
        - if the hooks are called for an 'AFTER' location, then specify the completion status of the process
        - possible values:
            NOT_RUN_SUCCESSFUL(0),
            SUCCESSFUL(1),
            WITH_WARNINGS(2),
            WITH_ERRORS(3),
            FAILED(4),
            ABORTED(5),
            CANCELLED(6),
            NOT_RUN_FAILED(7)

-----------------------------------------------------------
Examples:
1. Executing the 'BEFORE' hooks for process 10
BEGIN	COMMONS_PROCESSING.EXECUTE_PROCESSING_HOOK
        (pi_process_def_id          => 10
        ,pi_process_type_id         => 3
        ,pi_hook_location           => 'BEFORE'
        ,pi_run_id                  => 2413
        ,pi_run_completion_status   => NULL
        );
END;

2. Executing the 'AFTER' hooks for process 10
BEGIN	COMMONS_PROCESSING.EXECUTE_PROCESSING_HOOK
        (pi_process_def_id          => 10
        ,pi_process_type_id         => 3
        ,pi_hook_location           => 'AFTER'
        ,pi_run_id                  => 5673
        ,pi_run_completion_status   => 1
        );
END;

-- ===============================================*/
PROCEDURE EXECUTE_PROCESSING_HOOK
(    pi_process_def_id          NUMBER
    ,pi_process_type_id         NUMBER
    ,pi_hook_location           VARCHAR2
    ,pi_run_id                  NUMBER
    ,pi_run_completion_status   NUMBER
);


/* GET_HINT_LOCATION_NAME
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2012.05.10
-- Description	: This function is executed by a process which wants to log the identifier of a location where hints might be inserted.
					The function will always be used together with GET_HINTS function executed with the same exact parameter values
					as in the example below.
-----------------------------------------------------------
Parameters:
	 pi_module_id	 VARCHAR2 - NOT NULL - the identifier of the module that contains the requested location
	,pi_hint_id		 VARCHAR2 - NULL - the identifier of the hint requested location within the module, either this or pi_hint_id_list must be null
	,pi_proc_id		 NUMBER - NOT NULL - the ID of the process which will execute the hints at the requested location
    ,pi_hint_id_list TABLETYPE_CHARMAX - NULL - a list of identifiers of hints

-----------------------------------------------------------
Usually within a module you will want to create a unique hint id for each SELECT, INSERT ... word. So that the hints to be applied by the DBA
will be applied to it's specific location.

Ex:
    SELECT <SEL_MAIN> ...
    FROM (SELECT <SEL_EMP> ...
          FROM ...) T1
          INNER JOIN
         (SELECT <SEL_DEPT> ...
          FROM ...) T2 ON ...

However there are examples where you might want a hint to be applied to multiple SELECT words, specially for DT operations with multiple inputs
Ex:

    SELECT <SEL_MAIN> ...
    FROM (SELECT <SEL_I1><SEL_ALL_I> ...
          FROM ...) IN_1
          UNION ALL
         (SELECT <SEL_I2><SEL_ALL_I> ...
          FROM ...) IN_2
          UNION ALL
         (SELECT <SEL_I3><SEL_ALL_I> ...
          FROM ...) IN_3

Notice how I want hints for SEL_I1 , SEL_I2 to be applied to different subqueries, but I also want the posibility for a hint to be
registered with the <SEL_ALL_I> so that it will be applied to all inputs. In this case I can use the last parameter of the function.
Example for first input:

COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'RUN_COMPONENT'
                                         ,pi_hint_id => NULL
                                         ,pi_proc_id => 3142
                                         ,pi_hint_id_list => TABLETYPE_CHARMAX('SEL_I1','SEL_ALL_I'));
-----------------------------------------------------------
Examples:

DECLARE
	v_sql CLOB;
BEGIN
	v_sql := 'INSERT INTO TABLE_DEST(COL1, COL2) '
		|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('RUN_COMPONENT','SEL1',3142)
		|| ' SELECT '
		|| COMMONS_PROCESSING.GET_HINTS('RUN_COMPONENT','SEL1',3142)
		||' COL10, COL20 FROM TABLE_SOURCE';

	DBMS_OUTPUT.PUT_LINE(v_sql);
	EXECUTE IMMEDIATE (v_sql);
END;

SQL printed and executed:

    INSERT INTO TABLE_DEST(COL1, COL2) /~*<module>RUN_COMPONENT</><hint>SEL1</><proc>3142</>*~/ SELECT /~*+ any hints from that location *~/ COL10, COL20 FROM TABLE_SOURCE
-- ===============================================*/
FUNCTION GET_HINT_LOCATION_NAME
(	 pi_module_id	    VARCHAR2
	,pi_hint_id		    VARCHAR2
	,pi_proc_id		    NUMBER
    ,pi_hint_id_list    TABLETYPE_CHARMAX DEFAULT NULL
) RETURN VARCHAR2;


/* GET_HINTS
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2012.05.10
-- Description	: This function is executed by a process in order to append hints at a specific location within the query of a module.
					Please see also the specification of GET_HINT_LOCATION_NAME, a function to be used in tandem with this one.
					These 2 functions can be used to apend hints after the following words: SELECT, INSERT, UPDATE, DELETE, MERGE
-----------------------------------------------------------
Parameters:
	 pi_module_id	VARCHAR2 - NOT NULL - the identifier of the module that contains the requested location
	,pi_hint_id		VARCHAR2 - NOT - the identifier of the hint requested location within the module, either this or pi_hint_id_list must be null
	,pi_proc_id		NUMBER - NOT NULL - the ID of the process which will execute the hints at the requested location
    ,pi_other_hints VARCHAR2 - NULL - if the list to be computed must be appended to other hints passed by the user
    ,pi_hint_id_list TABLETYPE_CHARMAX - NULL - a list of identifiers of hints, see header of GET_HINT_LOCATION_NAME function for usage guide
-----------------------------------------------------------
Examples:

DECLARE
	v_sql CLOB;
BEGIN
	v_sql := 'INSERT INTO TABLE_DEST(COL1, COL2) '
		|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('RUN_COMPONENT','SEL1',3142)
		|| ' SELECT '
		|| COMMONS_PROCESSING.GET_HINTS('RUN_COMPONENT','SEL1',3142)
		||' COL10, COL20 FROM TABLE_SOURCE';

	DBMS_OUTPUT.PUT_LINE(v_sql);
	EXECUTE IMMEDIATE (v_sql);
END;

SQL printed and executed:

    INSERT INTO TABLE_DEST(COL1, COL2) /~*<module>RUN_COMPONENT</><hint>SEL1</><proc>3142</>*~/
    SELECT /~*+ hint1 <comment1> hint2 <comment2> *~/ COL10, COL20 FROM TABLE_SOURCE
-- ===============================================*/
FUNCTION GET_HINTS
(	 pi_module_id	    VARCHAR2
	,pi_hint_id		    VARCHAR2
	,pi_proc_id		    NUMBER
    ,pi_other_hints     VARCHAR2 DEFAULT NULL
    ,pi_hint_id_list    TABLETYPE_CHARMAX DEFAULT NULL
) RETURN VARCHAR2;


/* SAVE_EXEC_PLAN
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2015.01.22
-- Description	: This function will be used to save execution plans of queries fired by processes
-----------------------------------------------------------
Parameters:
	 pi_run_id          IN NUMBER DEFAULT NULL
        - if the code calling the procedure knows the RD_ID value of the process from RUN_DATA table then pass it to the proc
        - if the RUN ID is not known then we will try to take it from the session's CLIENT_IDENTIFIER value.
    ,pi_query_identifier    IN VARCHAR2 DEFAULT NULL
        - it would be good to save a small description of the query, especially if for the same RUN_ID multiple execution plans are saved
	,pi_bind_variables  IN COLTYPE_NAME_VALUE DEFAULT NULL
        - if the query is executed with bind variables then try to also pass those as it would be much easier for a DBA to debug the query
-----------------------------------------------------------
Examples:

DECLARE
	v_sql CLOB;
BEGIN
	v_sql := 'INSERT INTO T123 (C1) VALUES ('ASD')';
    EXECUTE IMMEDIATE V_SQL;
    COMMONS_PROCESSING.SAVE_EXEC_PLAN();
END;
-- ===============================================*/
PROCEDURE SAVE_EXEC_PLAN
(    pi_run_id              IN NUMBER DEFAULT NULL
    ,pi_query_identifier    IN VARCHAR2 DEFAULT NULL
    ,pi_bind_variables      IN COLTYPE_NAME_VALUE DEFAULT NULL
);


/* SAVE_EXEC_PLAN_FOR_ABORT
-- ===============================================
-- Author		: Kristo, Robert
-- Create date	: 2015.02.20
-- Description	: This function will be used to save execution plans of all active queries that belong to a certain RUN_ID
-----------------------------------------------------------
Parameters:
	 pi_run_id          IN NUMBER DEFAULT NULL
        - the RUN ID that will be searched in all session's CLIENT_IDENTIFIER value.
-----------------------------------------------------------

-- ===============================================*/
PROCEDURE SAVE_EXEC_PLAN_FOR_ABORT
(    pi_run_id IN NUMBER DEFAULT NULL
);


/* SAVE_PROC_SESS_STATS
-- ========================================================
-- Author     : Andries, Adriana
-- Create date: 20150202
-- Description: Collects session statistics BEFORE or AFTER the
-----------------------------------------------------------
pin_sesstat_type = 'BEFORE'/'AFTER'
-----------------------------------------------------------       */
PROCEDURE SAVE_SESS_STATS
(    pin_sesstat_type   IN VARCHAR2
    ,pin_run_id         IN NUMBER
    ,pin_definition_id  IN NUMBER DEFAULT NULL
);


/* EXEC_START_PROC_TRANSACTION
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2015.07.14
-- Description	: This procedure must be executed by any process transaction before doing any work
                in order to catch the status of resource consumption within the corresponding session.
                A similar SP would be called at the end of the transaction on the same session.
-----------------------------------------------------------
Parameters:
	 pi_run_id                  NUMBER
        - NULL
        - if available, the run_id of the process being executed. if not available then
          it will be extracted from the CLIENT_IDENTIFIER column of v$session
    ,pi_process_def_id	        NUMBER
        - NULL
        - the definition ID of the process for which stats are gathered
-- ===============================================*/
PROCEDURE EXEC_START_PROC_TRANSACTION
(    pin_run_id         IN NUMBER DEFAULT NULL
    ,pin_definition_id  IN NUMBER DEFAULT NULL
);


/* EXEC_END_PROC_TRANSACTION
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2015.07.14
-- Description	: This procedure must be executed by any process transaction after doing all the work
                in order to catch the status of resource consumption within the corresponding session.
                A similar SP would be called at the start of the transaction on the same session.
-----------------------------------------------------------
Parameters:
	 pi_run_id                  NUMBER
        - NULL
        - if available, the run_id of the process being executed. if not available then
          it will be extracted from the CLIENT_IDENTIFIER column of v$session
    ,pi_process_def_id	        NUMBER
        - NULL
        - the definition ID of the process for which stats are gathered
-- ===============================================*/
PROCEDURE EXEC_END_PROC_TRANSACTION
(    pin_run_id         IN NUMBER DEFAULT NULL
    ,pin_definition_id  IN NUMBER DEFAULT NULL
);

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20160804
  -- Description: Removes processing hints for a certain definition id
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_process_def_id  number  not null  The definition id to which the hint has been registered
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    merge_fields.run_merge_fields(pin_operation_id => 12345678);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure remove_hints(pin_process_def_id in number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20160804
  -- Description: Adds processing hints corresponding to a certain autotune option for a certain definition id
  --              (for now aplicable only for Merge Fields processes)
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_process_def_id   number  not null  The definition id to which the hint has been registered
     pin_autotune_option  number  not null  Tuning option from AUTO_TUNE_OPTIONS
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    merge_fields.run_merge_fields(pin_operation_id => 12345678, pin_autotune_option => 1);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure add_autotune_hints(pin_process_def_id in number, pin_autotune_option in number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20160809
  -- Description: Logs the autotune option applied for a run of a certain definition id
  --              (for now aplicable only for Merge Fields processes)
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_run_data_id      number  not null  Processing run id from RUN_DATA
     pin_autotune_option  number  not null  Tuning option from AUTO_TUNE_OPTIONS
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  begin
    merge_fields.log_autotune_run(pin_run_data_id => 999, pin_autotune_option => 1);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure log_autotune_run(pin_run_data_id in number, pin_autotune_option in number);
  -- ========================================================

-- *******************************    PUBLIC PROCEDURES END         *******************************
END COMMONS_PROCESSING;
/
