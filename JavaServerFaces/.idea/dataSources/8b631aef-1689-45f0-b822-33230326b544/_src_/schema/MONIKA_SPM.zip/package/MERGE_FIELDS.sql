CREATE package merge_fields as

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20121108
  -- Description: Runs Merge Fields processing
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pin_operation_id         number                        not null  The id of the operation in DT_OPERATIONS ad DT_MERGE_FIELDS
     pin_inputs               tabletype_dt_mf_table_list    not null  Tables used in the processing of the operation
                                                                      Columns:
                                                                       - TABLE_NAME            - varchar2 - not null - input table
                                                                       - JOIN_TYPE             - varchar2 - not null - join type: left join, right join, inner join, full outer join
                                                                       - JOIN_CLAUSE           - clob     - null     - match condition
                                                                       - INPUT_FILTER          - clob     - null     - filtered input
                                                                       - TABLE_TYPE            - number   - not null - 1 - initial input, 2 - merge input
                                                                       - INPUT_NUMBER          - number   - not null - order of the inputs (initial input is 0, merged inputs start from 1)
                                                                       - ROW_IDENTIFIER_ALIAS  - varchar2 - not null - alias of the row identifier in the query
                                                                       - ROW_IDENTIFIER_OUTPUT - varchar2 - not null - alias of the row identifier in the primary output
                                                                       - INPUT_ALIAS           - varchar2 - null     - alias of the input used for existence check on all inputs when more fields are mapped to the same entity
                                                                       - INPUT_ID              - number   - not null - id from DT_INPUTS
                                                                       - TABLE_ALIAS           - varchar2 - not null - alias of the table inside the input
                                                                      Example:
                                                                       TABLETYPE_DT_MF_TABLE_LIST(OBJTYPE_DT_MF_TABLE_LIST('T100007', null,         null     , '(select T100007.F100011 A1, T100007.F100014 A4, T100054.F100014 A5, T100007.ROW_IDENTIFIER ROW100007 from T100007 as of scn 4373578751 T100007 left join T100054 as of scn 4373578751 T100054 on T100007.F100014 = T100054.F100014)', 1, 0, 'ROW100007', 'RW100007', 'IA1', 100017, 'T100007'),
                                                                                                  OBJTYPE_DT_MF_TABLE_LIST('T100008', 'inner join', 'A1 = A2', '(select T100008.F100012 A2, T100008.ROW_IDENTIFIER ROW100008 from T100008 as of scn 4373578751 T100008 where T100008.F100012 > 0)'                                                                                                  , 2, 1, 'ROW100008', 'RW100008', 'IA2', 100018, 'T100008'),
                                                                                                  OBJTYPE_DT_MF_TABLE_LIST('T100009', 'inner join', 'A4 = A3', '(select T100009.F100013 A3, T100055.F100013 A6, T100009.ROW_IDENTIFIER ROW100009 from T100009 as of scn 4373578751 T100009 left join T100055 as of scn 4373578751 T100055 on T100009.F100013 = T100055.F100013)'                    , 2, 2, 'ROW100009', 'RW100009', 'IA3', 100019, 'T100009')
                                                                                                  )
     pin_column_mappings      tabletype_dt_mf_col_map_list  not null  Column mappings
                                                                      Columns:
                                                                       - COLUMN_NAME      - varchar2 - not null - name of the column from the result table
                                                                       - COLUMN_TYPE      - number   - not null - 1 - entity, 2 - field
                                                                       - COLUMN_ORDER     - number   - not null - order of the column within the result
                                                                       - INPUT_NUMBER     - number   - not null - corresponding INPUT_NUMBER from pin_inputs to the input being mapped; will have negative values for the fields with all inputs option
                                                                       - MAPPING_VALUE    - clob     - not null - the input field used at mapping or an expression like coalesce(alias3,alias2,alias1) for the fields with all inputs option
                                                                       - ALIAS_VALUE      - varchar2 - null     - alias of the input field used at mapping
                                                                       - EXISTENCE_CHECK  - varchar2 - null     - alias of the entity used at mapping; will be null for the fields with all inputs option
                                                                       - IS_BOOLEAN       - number   - null     - 1 - field is boolean, 0 - field is not boolean
                                                                      Example:
                                                                       TABLETYPE_DT_MF_COL_MAP_LIST(OBJTYPE_DT_MF_COL_MAP_LIST('F1', 2, 1,  0, 'F100011',         'A1', null,0),
                                                                                                    OBJTYPE_DT_MF_COL_MAP_LIST('F2', 2, 2,  1, 'F100012',         'A2', null,1),
                                                                                                    OBJTYPE_DT_MF_COL_MAP_LIST('E3', 1, 3,  2, 'F100013',         'A3', 'A6',1),
                                                                                                    OBJTYPE_DT_MF_COL_MAP_LIST('E4', 1, 4,  0, 'F100014',         'A4', 'A5',0),
                                                                                                    OBJTYPE_DT_MF_COL_MAP_LIST('F5', 2, 5, -1, 'coalesce(A4,A2)', 'A7', 'A5',0)
                                                                                                    )
     pin_outputs              tabletype_id_name             not null  Additional outputs
                                                                      Columns:
                                                                       - ID   - number   - not null - output type id (from DT_OUTPUT_TYPES)
                                                                       - NAME - varchar2 - not null - table name
                                                                      Example:
                                                                       TABLETYPE_ID_NAME(OBJTYPE_ID_NAME(3,'T100051'),
                                                                                         OBJTYPE_ID_NAME(5,'T100052'),
                                                                                         OBJTYPE_ID_NAME(6,'T100053')
                                                                                         )
     pin_outputs_structure    tabletype_dt_mf_id_name_alias null      Columns from initial input that need to be in additional outputs
                                                                      Columns:
                                                                       - ID    - number   - not null - column order
                                                                       - NAME  - varchar2 - not null - column name
                                                                       - ALIAS - varchar2 - not null - alias
                                                                      Example:
                                                                       TABLETYPE_ID_NAME(OBJTYPE_ID_NAME(1,'F100011','A1'),
                                                                                         OBJTYPE_ID_NAME(2,'F100014','A4')
                                                                                         )
     pin_period_filter_joins  clob                          null      Join with period tables/correspondence view for period filter
     pin_output_filter        clob                          null      Filter on primary output
     pin_run_data_id          number                        not null  Processing run id from RUN_DATA
     pin_autotune_option      number                        null      Tuning option from AUTO_TUNE_OPTIONS (values 1-6) plus option 0 - remove existing options
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     pout_invalid_records  sys_refcursor  not null  Entity ids missing from entity table when mapped with a field
                                                    Columns:
                                                     - INPUT_NUMBER  - number   - not null - corresponding INPUT_NUMBER from pin_inputs to the input being mapped
                                                     - COLUMN_NAME   - varchar2 - not null - name of the column from the input table
                                                     - COLUMN_ORDER  - number   - not null - order of the column within the result
                                                     - RECORD_VALUES - varchar2 - not null - first 1000 values of failed records separated by ";"
     pout_record_count     sys_refcursor  not null  Number of records inserted in each output
                                                    Columns:
                                                     - ID - number - not null - output type id (from DT_OUTPUT_TYPES)
                                                     - NO - number - not null - number of records inserted
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  declare
    l_invalid_records sys_refcursor;
    l_record_count sys_refcursor;
  begin
    merge_fields.run_merge_fields(pin_operation_id        => 12345678,
                                  pin_inputs              => TABLETYPE_DT_MF_TABLE_LIST(OBJTYPE_DT_MF_TABLE_LIST('T100007', null,         null     , '(select T100007.F100011 A1, T100007.F100014 A4, T100054.F100014 A5, T100007.ROW_IDENTIFIER ROW100007 from T100007 as of scn 4373578751 T100007 left join T100054 as of scn 4373578751 T100054 on T100007.F100014 = T100054.F100014)', 1, 0, 'ROW100007', 'RW100007', 'IA1', 100017, 'T100007'),
                                                                                        OBJTYPE_DT_MF_TABLE_LIST('T100008', 'inner join', 'A1 = A2', '(select T100008.F100012 A2, T100008.ROW_IDENTIFIER ROW100008 from T100008 as of scn 4373578751 T100008 where T100008.F100012 > 0)'                                                                                                  , 2, 1, 'ROW100008', 'RW100008', 'IA2', 100018, 'T100008'),
                                                                                        OBJTYPE_DT_MF_TABLE_LIST('T100009', 'inner join', 'A4 = A3', '(select T100009.F100013 A3, T100055.F100013 A6, T100009.ROW_IDENTIFIER ROW100009 from T100009 as of scn 4373578751 T100009 left join T100055 as of scn 4373578751 T100055 on T100009.F100013 = T100055.F100013)'                    , 2, 2, 'ROW100009', 'RW100009', 'IA3', 100019, 'T100009')
                                                                                        ),
                                  pin_column_mappings     => TABLETYPE_DT_MF_COL_MAP_LIST(OBJTYPE_DT_MF_COL_MAP_LIST('F1', 2, 1,  0, 'F100011',         'A1', null,0),
                                                                                          OBJTYPE_DT_MF_COL_MAP_LIST('F2', 2, 2,  1, 'F100012',         'A2', null,1),
                                                                                          OBJTYPE_DT_MF_COL_MAP_LIST('E3', 1, 3,  2, 'F100013',         'A3', 'A6',1),
                                                                                          OBJTYPE_DT_MF_COL_MAP_LIST('E4', 1, 4,  0, 'F100014',         'A4', 'A5',0),
                                                                                          OBJTYPE_DT_MF_COL_MAP_LIST('F5', 2, 5, -1, 'coalesce(A4,A2)', 'A7', 'A5',0)
                                                                                          ),
                                  pin_outputs             => TABLETYPE_ID_NAME(OBJTYPE_ID_NAME(3,'T100051'),
                                                                               OBJTYPE_ID_NAME(5,'T100052'),
                                                                               OBJTYPE_ID_NAME(6,'T100053')
                                                                               ),
                                  pin_outputs_structure   => TABLETYPE_DT_MF_ID_NAME_ALIAS(OBJTYPE_DT_MF_ID_NAME_ALIAS(1,'F100011','A1'),
                                                                                           OBJTYPE_DT_MF_ID_NAME_ALIAS(2,'F100014','A4')
                                                                                           ),
                                  pin_period_filter_joins => null,
                                  pin_output_filter       => 'A1 < 4',
                                  pin_run_data_id         => 999,
                                  pin_autotune_option     => null,
                                  pout_invalid_records    => l_invalid_records,
                                  pout_record_count       => l_record_count);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure run_merge_fields(pin_operation_id        in number,
                             pin_inputs					     in tabletype_dt_mf_table_list,
                             pin_column_mappings		 in tabletype_dt_mf_col_map_list,
                             pin_outputs             in tabletype_id_name,
                             pin_outputs_structure   in tabletype_dt_mf_id_name_alias,
                             pin_period_filter_joins in clob,
                             pin_output_filter       in clob,
                             pin_run_data_id         in number,
                             pin_autotune_option     in number default null,
                             pout_invalid_records   out sys_refcursor,
                             pout_record_count      out sys_refcursor);
  -- ========================================================

end merge_fields;
/
