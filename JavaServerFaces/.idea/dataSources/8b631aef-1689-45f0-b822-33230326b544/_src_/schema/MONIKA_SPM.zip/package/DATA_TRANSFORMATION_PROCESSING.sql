CREATE PACKAGE DATA_TRANSFORMATION_PROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Product    : DataManagement
  -- Module   :   DataTransformation
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
   ERROR_NUMBER   CONSTANT NUMBER   := -1E125;
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************

-- ############################# SEL_INPUT_FIELDS START #############################
	/*
	Author     : Cozac, Tudor
	Create date: 20120925
	Description:
	---------------------------------------------------------------------------------------
	Input Parameters:
	   pin_input_table_list	IN COLTYPE_ID		NULL :list of input table ids for which the fields are required
											NOT NULL for the case when fields are required for a specific list of inputs; NULL for the rest
	   pin_operation_id 	IN NUMBER			NULL : operation id for which the fields from all its inputs are required
	-----------------------------------------------------------------------------------------
	Result set:
	 FIELD_ID				NUMBER field id
	 ENTITY_ID				NUMBER entity id
	 INPUT_TABLE_ID			NUMBER input table id
	-----------------------------------------------------------------------------------------
	Example:
	variable c refcursor
	exec :c:= DATA_TRANSFORMATION_PROCESSING.INPUT_FIELDS(COLTYPE_ID(2,3,4),NULL)
	print c

	variable c refcursor
	exec :c:= DATA_TRANSFORMATION_PROCESSING.INPUT_FIELDS(NULL,5)
	print c
	*/

	FUNCTION SEL_INPUT_FIELDS(
	  pin_input_table_list	IN COLTYPE_ID
	 ,pin_operation_id 	IN NUMBER
	  ) RETURN SYS_REFCURSOR;

	-- ############################# SEL_INPUT_FIELDS END   #############################

-- ############################# INPUT_FIELDS START #############################
	/*
	Author     : Cozac, Tudor
	Create date: 20120925
	Description: Return the available fields for an operation based on its inputs.
				1.	pin_operation_id			NOT NULL
					pin_output_type_id 				NULL
					pin_input_list					NULL
					=> available fields for an operation based on all its inputs
				2.	pin_operation_id			NOT NULL
					pin_output_type_id 			NOT NULL
					pin_input_list					NULL
					=> result fields for an operation result
				3.	pin_operation_id			NOT NULL
					pin_output_type_id 				NULL
					pin_input_list				NOT NULL
					=> available fields for an operation based on a list of inputs
			Fields are sent in a specific order established by the FD DT Result Fields
	---------------------------------------------------------------------------------------
	Input Parameters:
	   pin_operation_id			IN NUMBER		NOT NULL : operation id for which the fields are required
	   pin_output_type_id 		IN NUMBER		    NULL : output id for which the fields are required case 2
															if NOT NULL then the fields of the output id of the operation pin_operation_id
   	   pin_input_list			IN CLOB				NULL : comma separated list of input IDs of the pin_operation_id case 3
	-----------------------------------------------------------------------------------------
	Result set: Records are send in the order of the field
	 RESULTS_FIELDS_DETERMINED			NUMBER 0 for at least one record if the result fields can not be determined; 1 all records if OK
	 INPUT_ID							NUMBER input id
	 FIELD_ID							NUMBER field id
	 ENTITY_ID							NUMBER entity id
	-----------------------------------------------------------------------------------------
	Example:
	variable c refcursor
	exec :c:= DATA_TRANSFORMATION_PROCESSING.INPUT_FIELDS(3,NULL,NULL)
	print c
	variable c refcursor
	exec :c:= DATA_TRANSFORMATION_PROCESSING.INPUT_FIELDS(6,2,NULL)
	print c
	variable c refcursor
	exec :c:= DATA_TRANSFORMATION_PROCESSING.INPUT_FIELDS(1,NULL,'1,14')
	print c
	*/

	FUNCTION INPUT_FIELDS(
	  pin_operation_id			IN NUMBER
	 ,pin_output_type_id 		IN NUMBER
	 ,pin_input_list			IN CLOB
	  ) RETURN SYS_REFCURSOR;

	-- ############################# INPUT_FIELDS END   #############################

-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************

	-- ############################# get_inputs_cardinality start   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Lazar, Lucian
	Create date	: 20140514
	Description	: Checks the cardinality of the inputs in RUN_DATA_PROFILE and returns it and the cardinality hint.
                The procedure will be called from each Data Transformation operation.
	----------------------------------------------------------------------------------------
	Input Parameters:
    pi_inputs  not null  tabletype_dt_op_inputs  The operation inputs that are outputs from previous operations
                                                 Columns contained:
                                                 - INPUT_ID    number(10)    not null  The id of the input (DT_INPUTS.DTIN_ID)
                                                 - OUTPUT_ID   number(10)    not null  The id of the output (DT_OUTPUTS.DTOUT_ID, DT_INPUTS.DTIN_DTOUT_ID)
                                                 - TABLE_NAME  varchar2(30)  not null  The name of the physical input table
                                                 - ALIAS_NAME  varchar2(30)  null      The alias of the physical input table in query
	----------------------------------------------------------------------------------------
	Output Parameters:
    po_inputs_cardinality  not null  tabletype_dt_op_inputs_card  The operation inputs that are outputs from previous operations with their cardinality and cardinality hint
                                                                  Columns contained:
                                                                  - INPUT_ID       number(10)     not null  The id of the input (DT_INPUTS.DTIN_ID)
                                                                  - OUTPUT_ID      number(10)     not null  The id of the output (DT_OUTPUTS.DTOUT_ID, DT_INPUTS.DTIN_DTOUT_ID)
                                                                  - CARDINAL       number         not null  The cardinality of the input table
                                                                  - CARDINAL_HINT  varchar2(100)  not null  The CARDINALITY hint for the input table in query
	----------------------------------------------------------------------------------------
	Example:
    declare
      po_inputs_cardinality tabletype_dt_op_inputs_card;
    begin
      data_transformation_processing.get_inputs_cardinality(tabletype_dt_op_inputs(objtype_dt_op_inputs(2589751340,2589751336,'T100','A100')),
                                                            po_inputs_cardinality);
    end;
	----------------------------------------------------------------------------------------
	*/
  procedure get_inputs_cardinality(pi_inputs             in tabletype_dt_op_inputs,
                                   po_inputs_cardinality out tabletype_dt_op_inputs_card);
	-- ############################# get_inputs_cardinality end   #############################

	-- ############################# get_input_cardinality_hint start   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Lazar, Lucian
	Create date	: 20140603
	Description	: Checks the cardinality of a input and returns the cardinality hint.
                It is a wrapper over get_inputs_cardinality designed to be used from Java for operations with one input.
	----------------------------------------------------------------------------------------
	Input Parameters:
    pi_input_id    number(10)    not null  The id of the input (DT_INPUTS.DTIN_ID)
    pi_output_id   number(10)    not null  The id of the output (DT_OUTPUTS.DTOUT_ID, DT_INPUTS.DTIN_DTOUT_ID)
    pi_table_name  varchar2(30)  not null  The name of the physical input table
    pi_alias_name  varchar2(30)  null      The alias of the physical input table in query
	----------------------------------------------------------------------------------------
	Input Parameters:
    po_hint        varchar2(100)  null  The CARDINALITY hint for the input table in query
	----------------------------------------------------------------------------------------
	Example:
    declare
      v_hint varchar2(100)
    begin
      data_transformation_processing.get_input_cardinality_hint(2589796723,2589796673,'T100','A100',v_hint);
    end;
	----------------------------------------------------------------------------------------
	*/
  procedure get_input_cardinality_hint(pi_input_id   in number,
                                       pi_output_id  in number,
                                       pi_table_name in varchar2,
                                       pi_alias_name in varchar2,
                                       po_hint       out varchar2);
	-- ############################# get_input_cardinality_hint end   #############################

-- *******************************    PUBLIC PROCEDURES END         *******************************

END DATA_TRANSFORMATION_PROCESSING;
/
