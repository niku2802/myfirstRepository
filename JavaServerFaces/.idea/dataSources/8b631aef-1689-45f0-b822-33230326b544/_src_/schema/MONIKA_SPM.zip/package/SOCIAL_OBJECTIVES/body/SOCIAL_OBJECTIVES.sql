CREATE PACKAGE BODY SOCIAL_OBJECTIVES
IS
-- *******************************    PUBLIC METHODS START    *******************************

-- #############################  ADD_OBJECTIVE  #############################
--  Author     : Ivanov, Ioan
--  Modify date: 2015/03/31
--  Description: Insert data for an objective into objective, metric and roles tables.
--               Initiative data is inserted only in objective table
--  ---------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table        in varchar2   - the name of the objective table
--    pi_period_column          in varchar2   - the name of the period column
--    pi_period_id              in number     - the time frequency id
--    pi_objective              in varchar2   - the name of the objective
--    pi_objective_description  in varchar2   - the description of the objective (max 1300 char)
--    pi_parent_objective       in varchar2   - the name of the parent objective
--    pi_parent_objective_id    in number     - the id of the parent objective
--    pi_objective_type         in varchar2   - the objective type (Objective, Initiative, Organizational)
--    pi_strategy_lever         in varchar2   - the strategy lever
--    pi_initiative_category    in varchar2   - the initiative category
--    pi_organization_column    in varchar2   - the organization entity
--    pi_organization_id        in number     - the id of the organization entity
--    pi_objective_privacy      in varchar2   - the privacy level of the objective(Public, Participants Only, Organizations)
--    pi_roles_table            in varchar2   - the table that stores owners and assignees
--    pi_entity_column          in varchar2   - the name of the entity column
--    pi_owner_id               in number     - the id of the owner of the objective
--    pi_assignees              in tabletype_number - the collection of assignees id
--    pi_metric_table           in varchar2   - the name of the metric table
--    pi_metric_name            in varchar2   - the name of the objective metric
--    pi_metric_description     in varchar2   - the description of the metric (max 1300 char)
--    pi_target_value           in number     - the target value for the objective metric
--    pi_child_objectives       in tabletype_number - the list of objectives to be added as child
--    po_objective_id           out number    - the id of the inserted objective
--  -----------------------------------------------------------------------------------------
--  Example:
--        social_objectives.add_objective(
--                                  pi_objective_table       => 'T3128342',
--                                  pi_period_column         => 'F462',
--                                  pi_period_id             =>  255,
--                                  pi_objective             => 'Increase sales',
--                                  pi_objective_description => 'Try to increase sales',
--                                  pi_parent_objective      => 'Increase team sales 01',
--                                  pi_parent_objective_id   =>  21,
--                                  pi_objective_type        => 'OBJECTIVE',
--                                  pi_strategy_lever        => 'Best strategy',
--                                  pi_initiative_category   => 'First category',
--                                  pi_organization_column   => 'E3492833',
--                                  pi_organization_id       => 11,
--                                  pi_objective_privacy     => 'PUBLIC',
--                                  pi_roles_table           => 'T3128362',
--                                  pi_entity_column         => 'E3128174',
--                                  pi_owner_id              => 77,
--                                  pi_assignees             => tabletype_number (23, 70),
--                                  pi_metric_table          => 'T3128352',
--                                  pi_metric_name           => 'Performace',
--                                  pi_metric_description    => 'Measure performance',
--                                  pi_target_value          => 100,
--                                  pi_child_objectives      => tabletype_number(10, 20, 23),
--                                  po_objective_id          => v_objective_id);
--  -----------------------------------------------------------------------------------------

 PROCEDURE ADD_OBJECTIVE
  (
    pi_objective_table        in varchar2,
    pi_period_column          in varchar2,
    pi_period_id              in number,
    pi_objective              in varchar2,
    pi_objective_description  in varchar2 := NULL,
    pi_parent_objective       in varchar2 := NULL,
    pi_parent_objective_id    in number   := NULL,
    pi_objective_type         in varchar2,
    pi_strategy_lever         in varchar2 := NULL,
    pi_initiative_category    in varchar2 := NULL,
    pi_organization_column    in varchar2 := NULL,
    pi_organization_id        in number   := NULL,
    pi_objective_privacy      in varchar2,
    pi_roles_table            in varchar2 := NULL,
    pi_entity_column          in varchar2 := NULL,
    pi_owner_id               in number   := NULL,
    pi_assignees              in tabletype_number := NULL,
    pi_metric_table           in varchar2 := NULL,
    pi_metric_name            in varchar2 := NULL,
    pi_metric_description     in varchar2 := NULL,
    pi_target_value           in number   := NULL,
    pi_child_objectives       in tabletype_number := NULL,
    po_objective_id           out number
  )
  IS
    v_sql clob;
    v_stamp varchar2(200 char);
    v_organization_id number(10);
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.ADD_OBJECTIVE - '|| TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_table), ',pi_objective_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_period_column), ',pi_period_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id) ,',pi_period_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective), ',pi_objective => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_parent_objective), ',pi_parent_objective => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_description), ',pi_objective_description => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_parent_objective_id), ',pi_parent_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_type), ',pi_objective_type => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_strategy_lever), ',pi_strategy_lever => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_initiative_category), ',pi_initiative_category => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_privacy), ',pi_objective_privacy => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_organization_column), ',pi_organization_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_organization_id) ,',pi_organization_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roles_table), ',pi_roles_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_entity_column), ',pi_entity_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_owner_id) ,',pi_owner_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_assignees),   ',pi_assignees => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_name), ',pi_metric_name => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_description), ',pi_metric_description => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_target_value), ',pi_target_value => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_child_objectives),   ',pi_child_objectives => <value>', v_stamp);
    END;

    -- If objective type set organization to organizational objective organization
    if pi_objective_type = 'OBJECTIVE' and pi_organization_id is null
    then
      v_sql := 'SELECT ' || pi_organization_column                              || CHR(10) ||
               'FROM ('                                                         || CHR(10) ||
               '       SELECT OBJECTIVE_TYPE, ' || pi_organization_column       || CHR(10) ||
               '       FROM ' || pi_objective_table                             || CHR(10) ||
               '       CONNECT BY   ROW_IDENTIFIER = PRIOR PARENT_OBJECTIVE_ID' || CHR(10) ||
               '       START WITH ROW_IDENTIFIER = :pi_objective_id'            || CHR(10) ||
               '      ) T'                                                      || CHR(10) ||
               'WHERE OBJECTIVE_TYPE = ''ORGANIZATIONAL''';

      execute immediate v_sql into v_organization_id using pi_parent_objective_id;
    else
      v_organization_id := pi_organization_id;
    end if;

    v_sql := 'INSERT INTO ' ||  pi_objective_table
                            || ' ('
                            ||  pi_period_column || ', '
                            || 'OBJECTIVE, '
                            || 'OBJECTIVE_DESCRIPTION, '
                            || 'PARENT_OBJECTIVE, '
                            || 'PARENT_OBJECTIVE_ID, '
                            || 'OBJECTIVE_TYPE, '
                            || 'STRATEGY_LEVER, '
                            || 'INITIATIVE_CATEGORY, '
                            || 'OBJECTIVE_PRIVACY, '
                            ||  pi_organization_column || ','
                            || 'ROW_IDENTIFIER, '
                            || 'ROW_VERSION'
                            || ')' || CHR(10) ||
                 'VALUES (' || TO_CHAR(pi_period_id) || ', '
                            || ':pi_objective, '
                            || COALESCE(':pi_objective_description, ', 'NULL, ')
                            || COALESCE(':pi_parent_objective, ', 'NULL, ')
                            || COALESCE(':pi_parent_objective_id, ', 'NULL, ')
                            || ':pi_objective_type, '
                            || COALESCE(':pi_strategy_lever, ', 'NULL, ')
                            || COALESCE(':pi_initiative_category, ', 'NULL, ')
                            || ':pi_objective_privacy, '
                            || COALESCE(':v_organization_id, ', 'NULL, ')
                            || pi_objective_table ||'_ROW_IDENTIFIER_SEQ.NEXTVAL, '
                            || '0'
                            || ')' || CHR(10) ||
             'RETURNING ROW_IDENTIFIER INTO :po_objective_id';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,',v_objective_sql => <value>', v_stamp);

    execute immediate v_sql using in pi_objective, in pi_objective_description, in pi_parent_objective, in pi_parent_objective_id,
                                  in pi_objective_type, in pi_strategy_lever, in pi_initiative_category, in pi_objective_privacy,
                                  in v_organization_id, out po_objective_id;

    if pi_objective_type != 'INITIATIVE' then
      -- Add objective metric
      v_sql := 'INSERT INTO ' || pi_metric_table
                            || ' ('
                            || 'OBJECTIVE_ID, '
                            || 'OBJECTIVE_METRIC_NAME, '
                            || 'METRIC_DESCRIPTION, '
                            || 'TARGET_VALUE, '
                            || 'ATTAINMENT, '
                            || 'ROW_IDENTIFIER, '
                            || 'ROW_VERSION'
                            || ')' || CHR(10) ||
               'VALUES   ('
                            || TO_CHAR(po_objective_id) || ', '
                            || ':pi_metric_name, '
                            || ':pi_metric_description, '
                            || TO_CHAR(pi_target_value) || ', '
                            || '0, '
                            || pi_metric_table ||'_ROW_IDENTIFIER_SEQ.NEXTVAL, '
                            || '0)';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using pi_metric_name, pi_metric_description;

      -- Add objective assignees
      v_sql := 'INSERT INTO ' || pi_roles_table
                             ||' ('
                             || 'OBJECTIVE_ID, '
                             ||  pi_entity_column || ', '
                             || 'ROLE_TYPE, '
                             || 'ROW_IDENTIFIER, '
                             || 'ROW_VERSION'
                             || ')' || CHR(10) ||
               'SELECT '     || TO_CHAR(po_objective_id) || ', '
                             || 'T.COLUMN_VALUE, '
                             || '1' || ', '
                             || pi_roles_table ||'_ROW_IDENTIFIER_SEQ.NEXTVAL, '
                             || '0' || CHR(10) ||
               'FROM TABLE(:pi_assignees) T';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using pi_assignees;
    end if;

    -- Add objective owner
    v_sql := 'INSERT INTO ' || pi_roles_table
                          || ' ('
                          || 'OBJECTIVE_ID, '
                          ||  pi_entity_column || ', '
                          || 'ROLE_TYPE, '
                          || 'ROW_IDENTIFIER, '
                          || 'ROW_VERSION'
                          || ')' || CHR(10) ||
             'VALUES   (' || TO_CHAR(po_objective_id) || ', '
                          || TO_CHAR(pi_owner_id) || ', '
                          || '0, '
                          || pi_roles_table ||'_ROW_IDENTIFIER_SEQ.NEXTVAL, '
                          || '0)';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql;

    -- Add child objectives to objective
    v_sql := 'UPDATE ' || pi_objective_table || CHR(10) ||
             'SET PARENT_OBJECTIVE_ID = :po_objective_id,' || CHR(10) ||
             '    PARENT_OBJECTIVE = :pi_objective' || CHR(10) ||
             'WHERE ROW_IDENTIFIER IN (SELECT * FROM TABLE(:pi_child_objectives))';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_objective_id) ,',po_objective_id => <value>', v_stamp);
    execute immediate v_sql using po_objective_id, pi_objective, pi_child_objectives;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_objective_id) ,',po_objective_id => <value>', v_stamp);
  EXCEPTION
  WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
  END ADD_OBJECTIVE;



-- ###################################  UPDATE_OBJECTIVE  ######################################
--  Author     : Ivanov, Ioan
--  Modified date: 2016/03/31
--  Description: Update an objective. Objective and organizational types updates objective,
--               metric and roles tables. The period of objective and organizational types
--               are set to initiative period. Child objectives that are not in the input child
--               list are deleted. The assignees and owners of deleted child objectives are
--               inserted into activity feed entities table.
--  --------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table        in varchar2   - the name of the objective table
--    pi_objective_id           in number     - the id of the objective to be updated
--    pi_period_column          in varchar2   - the name of the period column
--    pi_period_id              in number     - the time frequency id
--    pi_objective              in varchar2   - the name of the objective
--    pi_objective_description  in varchar2   - the description of the objective (max 1300 char)
--    pi_parent_objective       in varchar2   - the name of the parent objective
--    pi_parent_objective_id    in number     - the id of the parent objective
--    pi_objective_type         in varchar2   - the objective type (Objective, Initiative, Organizational)
--    pi_strategy_lever         in varchar2   - the strategy lever
--    pi_initiative_category    in varchar2   - the initiative category
--    pi_organization_column    in varchar2   - the organization entity
--    pi_organization_id        in number     - the id of the organization entity
--    pi_row_version            in number     - the version of the row to be updated
--    pi_initiative_id          in number     - the id of the initiative
--    pi_roles_table            in varchar2   - the table that stores owners and assignees
--    pi_entity_column          in varchar2   - the name of the entity column
--    pi_owner_id               in number     - the id of the owner of the objective
--    pi_assignees              in tabletype_number - the collection of assignees id
--    pi_metric_table           in varchar2   - the name of the metric table
--    pi_metric_name            in varchar2   - the name of the objective metric
--    pi_metric_description     in varchar2   - the description of the metric (max 1300 char)
--    pi_target_value           in number     - the target value for the objective metric
--    pi_child_objectives       in tabletype_objective_list - the list of objectives to be added as child
--                                 objtype_objective_list
--                                  (
--                                     objective_id    number(10),
--                                     objective       varchar2(250 char),
--                                     target_value    number,
--                                     attainment      number,
--                                     weight          number
--                                  )
--    po_objective_id           out number    - the id of the inserted objective

--  Return: 0 - function executed successfully
--          1 - function failed due to row version
--  ----------------------------------------------------------------------------------------
--  Example:   social_objectives.update_objective (pi_objective_table       => 'T3128342',
--                                                 pi_objective_id          => 21,
--                                                 pi_period_column         => 'F462',
--                                                 pi_period_id             =>  255,
--                                                 pi_objective             => 'Increase sales',
--                                                 pi_objective_description => 'Try to increase sales',
--                                                 pi_parent_objective      => 'Increase team sales',
--                                                 pi_parent_objective_id   => 23,
--                                                 pi_objective_type        => 'Organizational',
--                                                 pi_strategy_lever        => 'Improved strategy',
--                                                 pi_initiative_category   => 'Second category',
--                                                 pi_organization_column   => 'E3492833',
--                                                 pi_organization_id       => 11,
--                                                 pi_row_version           => 1,
--                                                 pi_initiative_id         => 16,
--                                                 pi_roles_table           => 'T3128362',
--                                                 pi_entity_column         => 'E3128174',
--                                                 pi_owner_id              => 99,
--                                                 pi_assignees             => tabletype_number(31, 60),
--                                                 pi_metric_table          => 'T3128352',
--                                                 pi_metric_name           => 'Quantity',
--                                                 pi_metric_description    => 'Sales quantity',
--                                                 pi_target_value          => 90,
--                                                 pi_child_objectives      => tabletype_objective_list(objtype_objective_list(14, null, null, null, 0.70),
--                                                                                                      objtype_objective_list(15, null, null, null, 0.30)),
--                                                 pi_context_id            => 3493086
--                                               );
--  --------------------------------------------------------------------------------------------

 FUNCTION UPDATE_OBJECTIVE
  (
    pi_objective_table        in varchar2,
    pi_objective_id           in number,
    pi_period_column          in varchar2,
    pi_period_id              in number,
    pi_objective              in varchar2,
    pi_objective_description  in varchar2 := NULL,
    pi_parent_objective       in varchar2 := NULL,
    pi_parent_objective_id    in number   := NULL,
    pi_objective_type         in varchar2,
    pi_strategy_lever         in varchar2 := NULL,
    pi_initiative_category    in varchar2 := NULL,
    pi_organization_column    in varchar2 := NULL,
    pi_organization_id        in number   := NULL,
    pi_row_version            in number,
    pi_initiative_id          in number,
    pi_roles_table            in varchar2 := NULL,
    pi_entity_column          in varchar2 := NULL,
    pi_owner_id               in number   := NULL,
    pi_assignees              in tabletype_number := NULL,
    pi_metric_table           in varchar2 := NULL,
    pi_metric_name            in varchar2 := NULL,
    pi_metric_description     in varchar2 := NULL,
    pi_target_value           in number   := NULL,
    pi_child_objectives       in tabletype_objective_list := NULL
  )
    RETURN NUMBER
  IS
    v_result number(10) := 0;
    v_sql clob;
    v_stamp varchar2(200 char);
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.UPDATE_OBJECTIVE - '|| TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_table), ',pi_objective_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_objective_id) ,',pi_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_period_column), ',pi_period_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id) ,',pi_period_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective), ',pi_objective => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_description), ',pi_objective_description => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_parent_objective), ',pi_parent_objective => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_parent_objective_id), ',pi_parent_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_type), ',pi_objective_type => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_strategy_lever), ',pi_strategy_lever => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_initiative_category), ',pi_initiative_category => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_organization_column), ',pi_organization_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_organization_id) ,',pi_organization_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_row_version) ,',pi_row_version => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_initiative_id), ',pi_initiative_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roles_table), ',pi_roles_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_entity_column), ',pi_entity_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_owner_id) ,',pi_owner_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_assignees), ',pi_assignees => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_name), ',pi_metric_name => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_description), ',pi_metric_description => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_target_value), ',pi_target_value => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_child_objectives), ',pi_child_objectives => <value>', v_stamp);
    END;

    -- Update objective table --
    v_sql := 'UPDATE ' || pi_objective_table || CHR(10) ||
             'SET ' || pi_period_column ||    ' = :pi_period_id, '             || CHR(10) ||
                  ' OBJECTIVE                   = :pi_objective,'              || CHR(10) ||
                  ' OBJECTIVE_DESCRIPTION       = :pi_objective_description,'  || CHR(10) ||
                  ' PARENT_OBJECTIVE            = :pi_parent_objective,'       || CHR(10) ||
                  ' PARENT_OBJECTIVE_ID         = :pi_parent_objective_id,'    || CHR(10) ||
                  ' OBJECTIVE_TYPE              = :pi_objective_type,'         || CHR(10) ||
                  ' INITIATIVE_CATEGORY         = :pi_initiative_category,'    || CHR(10) ||
                  ' STRATEGY_LEVER              = :pi_strategy_lever,'         || CHR(10) ||
                    pi_organization_column || ' = :pi_organization_id,'        || CHR(10) ||
                  ' ROW_VERSION                 = :pi_row_version + 1'         || CHR(10) ||
             'WHERE ROW_IDENTIFIER = :pi_objective_id AND ROW_VERSION = :pi_row_version' || CHR(10) ||
             'RETURNING ROW_IDENTIFIER INTO :v_result';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_period_id, pi_objective, pi_objective_description, pi_parent_objective,
                                  pi_parent_objective_id, pi_objective_type, pi_initiative_category, pi_strategy_lever,
                                  pi_organization_id, pi_row_version, pi_objective_id, pi_row_version, out v_result;

    if v_result is null then
      return 1;
    end if;

    -- Update the parent name of child objectives --
    v_sql := 'UPDATE ' || pi_objective_table                                           || CHR(10) ||
             'SET PARENT_OBJECTIVE    = :pi_objective'                                 || CHR(10) ||
             'WHERE ROW_IDENTIFIER IN '                                                || CHR(10) ||
             '      (SELECT ROW_IDENTIFIER FROM ' || pi_objective_table || ' WHERE PARENT_OBJECTIVE_ID = :pi_objective_id)';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_objective, pi_objective_id ;

    -- For organizational objective and individual objective update the organization of all child objectives
    if pi_objective_type = 'ORGANIZATIONAL' or pi_objective_type = 'OBJECTIVE'
    then
      v_sql := 'UPDATE ' || pi_objective_table                                                   || CHR(10) ||
               'SET ' || pi_organization_column || ' = :pi_organization_id'                      || CHR(10) ||
               'WHERE ROW_IDENTIFIER IN (SELECT ROW_IDENTIFIER'                                  || CHR(10) ||
               '                         FROM ' || pi_objective_table || ' C'                    || CHR(10) ||
               '                         CONNECT BY PRIOR ROW_IDENTIFIER = PARENT_OBJECTIVE_ID'  || CHR(10) ||
               '                         START WITH ROW_IDENTIFIER = :pi_objective_id)';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using pi_organization_id, pi_objective_id;
    end if;

    if pi_objective_type != 'INITIATIVE' then
      -- Update metric table --
      v_sql := 'UPDATE ' || pi_metric_table                          || CHR(10) ||
               'SET OBJECTIVE_METRIC_NAME = :pi_metric_name,'        || CHR(10) ||
               ' METRIC_DESCRIPTION       = :pi_metric_description,' || CHR(10) ||
               ' TARGET_VALUE             = :pi_target_value,'       || CHR(10) ||
               ' ROW_VERSION              = :pi_row_version + 1'     || CHR(10) ||
           'WHERE OBJECTIVE_ID = :pi_objective_id AND ROW_VERSION = :pi_row_version';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using pi_metric_name, pi_metric_description, pi_target_value,
                                    pi_row_version, pi_objective_id, pi_row_version;

      -- Update objective assingnees --
      v_sql := 'DELETE FROM ' || pi_roles_table                               || CHR(10) ||
               'WHERE OBJECTIVE_ID = :pi_objective_id AND ROLE_TYPE = 1 AND ' || pi_entity_column || CHR(10) ||
               '      NOT IN (SELECT COLUMN_VALUE FROM TABLE(:pi_assingees))';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using pi_objective_id, pi_assignees;

      v_sql := 'INSERT INTO ' || pi_roles_table
                             ||' ('
                             || 'OBJECTIVE_ID, '
                             ||  pi_entity_column || ', '
                             || 'ROLE_TYPE, '
                             || 'WEIGHT, '
                             || 'ROW_IDENTIFIER, '
                             || 'ROW_VERSION'
                             || ')' || CHR(10) ||
               'SELECT '     || TO_CHAR(pi_objective_id) || ', '
                             || 'T.COLUMN_VALUE, '
                             || '1, '
                             || '0, '
                             || pi_roles_table ||'_ROW_IDENTIFIER_SEQ.NEXTVAL, '
                             || TO_CHAR(pi_row_version + 1) || CHR(10) ||
               'FROM TABLE(:pi_assignees) T' || CHR(10) ||
               'WHERE T.COLUMN_VALUE NOT IN (SELECT ' || pi_entity_column || ' FROM ' || pi_roles_table || CHR(10) ||
               '                             WHERE OBJECTIVE_ID = :pi_objective_id AND ROLE_TYPE = 1)';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using pi_assignees, pi_objective_id;
    end if;

    -- Update the owner of the objective
    v_sql := 'UPDATE ' || pi_roles_table                      || CHR(10) ||
             'SET ' || pi_entity_column || ' = :pi_owner_id,' || CHR(10) ||
             'ROW_VERSION = ' || TO_CHAR(pi_row_version + 1)  || CHR(10) ||
             'WHERE ROLE_TYPE = 0 AND OBJECTIVE_ID = :pi_objective_id';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_owner_id, pi_objective_id;

    -- Set weight for child objectives in metric table --
    v_sql := 'MERGE INTO ' || pi_metric_table || ' T1'                          || CHR(10) ||
             'USING'                                                            || CHR(10) ||
             '  ('                                                              || CHR(10) ||
             '    SELECT OBJECTIVE_ID, WEIGHT FROM TABLE(:pi_child_objectives)' || CHR(10) ||
             '  ) T2'                                                           || CHR(10) ||
             ' ON(T1.objective_id = T2.objective_id)'                           || CHR(10) ||
             'WHEN MATCHED THEN'                                                || CHR(10) ||
             '   UPDATE SET T1.weight = T2.weight';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_child_objectives;

    return 0;
  EXCEPTION
  WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
  END UPDATE_OBJECTIVE;



-- #############################  DELETE_OBJECTIVE  #############################
--  Author     : Ivanov, Ioan
--  Modify date: 2016/03/08
--  Description: Delete an objective and all his children
--  ----------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table     in varchar2   - the name of the objective table
--    pi_metric_name         in varchar2   - the name of the objective metric
--    pi_roles_table         in varchar2   - the table that stores owners and assignees
--    pi_objective_id        in number     - the id of the objective to be deleted
--    pi_entity_column       in varchar2   - the name of the entity column
--    pi_context_id          in number     - the id of the social objective definition
--  ----------------------------------------------------------------------------------------
--  Example: social_objectives.delete_objective(pi_objective_table => 'T3345048',
--                                              pi_objective_id    => 24,
--                                              pi_metric_table    => 'T3345059',
--                                              pi_roles_table     => 'T3345067'
--                                              pi_entity_column   => 'E3490709',
--                                              pi_context_id         => 3493332
--                                             );
--  -----------------------------------------------------------------------------------------

  PROCEDURE DELETE_OBJECTIVE
  (
    pi_objective_table    in varchar2,
    pi_metric_table       in varchar2,
    pi_roles_table        in varchar2,
    pi_objective_id       in number,
    pi_entity_column      in varchar2,
    pi_context_id         in number
  )
  IS
    v_sql     clob;
    v_stamp   varchar2(200 char);
    v_ids     tabletype_id_name := tabletype_id_name();
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.DELETE_OBJECTIVE - '|| TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_table), ',pi_objective_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roles_table), ',pi_roles_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_objective_id) ,',pi_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_entity_column), ',pi_entity_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_context_id) ,',pi_context_id => <value>', v_stamp);
    END;

    -- Delete objective and all his children
    v_sql :=  'DELETE FROM ' || pi_objective_table                                          || CHR(10) ||
              'WHERE ROW_IDENTIFIER = :pi_objective_id OR'                                  || CHR(10) ||
              'ROW_IDENTIFIER IN ( SELECT ROW_IDENTIFIER'                                   || CHR(10) ||
              '                    FROM ' || pi_objective_table                             || CHR(10) ||
              '                    CONNECT BY PRIOR ROW_IDENTIFIER = PARENT_OBJECTIVE_ID'   || CHR(10) ||
              '                    START WITH PARENT_OBJECTIVE_ID = :pi_objective_id'       || CHR(10) ||
              '                   )'                                                        || CHR(10) ||
              'RETURNING OBJTYPE_ID_NAME(ROW_IDENTIFIER, OBJECTIVE_PRIVACY) INTO :1';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_objective_id, pi_objective_id returning bulk collect into v_ids;

    -- Insert deleted objectives in activity feed entities --
    v_sql := 'INSERT INTO ACTIVITY_FEED_SO_ENTITIES'         || CHR(10) ||
             '     ( AFSE_ID,'                               || CHR(10) ||
             '       AFSE_ENTITY_ID,'                        || CHR(10) ||
             '       AFSE_ROLE_TYPE,'                        || CHR(10) ||
             '       AFSE_SOURCE_ID,'                        || CHR(10) ||
             '       AFSE_CONTEXT_ID'                        || CHR(10) ||
             '     )'                                        || CHR(10) ||
             'SELECT ACTIVITY_FEED_SO_ENTITIES_SEQ.NEXTVAL,' || CHR(10) ||
             '       ' || pi_entity_column || ','            || CHR(10) ||
             '       ROLE_TYPE,'                             || CHR(10) ||
             '       OBJECTIVE_ID,'                          || CHR(10) ||
             '       :pi_context_id'                         || CHR(10) ||
             'FROM ' || pi_roles_table                       || CHR(10) ||
             'WHERE OBJECTIVE_ID IN (SELECT ID FROM TABLE(:v_ids))';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_context_id, v_ids;

    -- Insert privacy for deleted objectives --
    v_sql := 'INSERT INTO ACTIVITY_FEED_SO_PRIVACY'          || CHR(10) ||
             '     ( AFSP_ID,'                               || CHR(10) ||
             '       AFSP_SOURCE_ID,'                        || CHR(10) ||
             '       AFSP_SOURCE_PRIVACY,'                   || CHR(10) ||
             '       AFSP_CONTEXT_ID'                        || CHR(10) ||
             '     )'                                        || CHR(10) ||
             'SELECT ACTIVITY_FEED_SO_PRIVACY_SEQ.NEXTVAL,'  || CHR(10) ||
             '       ID,'                                    || CHR(10) ||
             '       NAME,'                                  || CHR(10) ||
             '       :pi_context_id'                         || CHR(10) ||
             'FROM TABLE(:v_ids)';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_context_id, v_ids;

    -- Delete objective metric
    v_sql :=  'DELETE FROM ' || pi_metric_table  || CHR(10) ||
              'WHERE OBJECTIVE_ID IN (SELECT ID FROM TABLE(:v_ids))';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using v_ids;

    -- Delete objective assingees and owner
    v_sql :=  'DELETE FROM ' || pi_roles_table  || CHR(10) ||
              'WHERE OBJECTIVE_ID IN (SELECT ID FROM TABLE(:v_ids))';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using v_ids;

  EXCEPTION
  WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
  END DELETE_OBJECTIVE;



-- ##########################################  GET_OBJECTIVE  ###############################################
--  Author     : Ivanov, Ioan
--  Modify date: 2016/11/03
--  Description: Get an objective and his children. Objective data is retrieved from objective,
--               metric, roles and checkin tables through a cursor.
--  ---------------------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table     in varchar2      - the name of the objective table
--    pi_objective_id        in number        - the id of the objective to be deleted
--    pi_period_columns      in col_list_30   - the list of periods columns contained by objectives table
--    pi_metric_table        in varchar2      - the metric table name
--    pi_roles_table         in varchar2      - the roles table name
--    pi_entity_column       in varchar2      - the entity column name
--    pi_checkin_table       in varchar2      - the name of the checkin history table
--    pi_organization_column in varchar2      - the name of the organization from objectives table
--    po_objectives          out sys_refcursor - the cursor that contains objective and its children
--                                               PERIOD_RANGE_ID, OBJECTIVE, OBJECTIVE_DESCRIPTION, OBJECTIVE_TYPE,
--                                               STRATEGY_LEVER, INITIATIVE_CATEGORY, E3492833(organization id),
--                                               ROW_IDENTIFIER, ROW_VERSION, OBJECTIVE_PRIVACY, CREATED_DATE_TIME
--                                               PARENT_PERIOD_ID, PARENT_OBJECTIVE_ID, PARENT_OBJECTIVE, PARENT_OBJECTIVE_PRIVACY, PARENT_PROGRESS,
--                                               OBJECTIVE_METRIC_NAME, METRIC_DESCRIPTION, TARGET_VALUE, ATTAINMENT, WEIGHT,
--                                                (metric columns have value only for OBJECTIVE and ORGANIZATIONAL type)
--                                               LAST_CHECKIN_VALUE, LAST_CHECKIN_DATE_TIME,
--                                               INITIATIVE_PERIOD_ID, INITIATIVE_ID, INITIATIVE, INITIATIVE_ORGANIZATION, INITIATIVE_PRIVACY, INITIATIVE_PROGRESS
--                                               ORGANIZATIONAL_PERIOD_ID, ORGANIZATIONAL_ID, ORGANIZATIONAL_OBJECTIVE, ORGANIZATIONAL_PROGRESS, ORGANIZATIONAL_PRIVACY,
--                                                (organizational columns have value only for OBJECTIVE type), ORGANIZATIONAL_ORGANIZATION,
--                                               ASSIGNEES(NULL for initiative), OWNER_ID, CHILD_OBJECTIVES, PARENT_ASSIGNEES_COUNT
--                                                 - ASSIGNEES = tabletype_objective_assignees - the collection of objective assignees,
--                                                     objtype_objective_assignee
--                                                     (
--                                                       entity_id  number(10),
--                                                       weight     number
--                                                      )
--                                                 - CHILD_OBJECTIVES = tabletype_objective_list - the collection of child objectives
--                                                    objtype_objective_list
--                                                     (
--                                                        period_range_id   number(10),
--                                                        objective_id      number(10),
--                                                        objective         varchar2(250 char),
--                                                        objective_privacy varchar(30 char),
--                                                        organization_id   number,
--                                                        target_value      number,
--                                                        attainment        number,
--                                                        weight            number,
--                                                        assignees_number  number
--                                                     )
--  ---------------------------------------------------------------------------------------------------------
--  Example:  social_objectives.get_objective(pi_objective_table     => 'T3215089',
--                                            pi_objective_id        => 12,
--                                            pi_period_columns       => col_list_30('F462', 'F563', 'F635')
--                                            pi_metric_table        => 'T3128352',
--                                            pi_roles_table         => 'T3128362',
--                                            pi_entity_column       => 'E3128174',
--                                            pi_checkin_table       =>  'T3128378',
--                                            pi_organization_column => 'E3492604'
--                                            po_objectives          => c_objectives);
--  ------------------------------------------------------------------------------------------------------
  PROCEDURE GET_OBJECTIVE
  (
    pi_objective_table        in varchar2,
    pi_objective_id           in number,
    pi_period_columns         col_list_30,
    pi_metric_table           in varchar2,
    pi_roles_table            in varchar2,
    pi_entity_column          in varchar2,
    pi_checkin_table          in varchar2 := NULL,
    pi_organization_column    in varchar2,
    po_objectives             out sys_refcursor
  )
  IS
    v_sql                       clob;
    v_stamp                     varchar2(200 char);
    v_initiative_id             number(10);
    v_initiative                varchar2(250 char);
    v_initiative_period_id      number(10);
    v_organizational_period_id  number(10);
    v_objective_type            varchar2(250 char);
    v_organizational_id         number(10);
    v_organizational_org_id     number(10);
    v_organizational_objective  varchar2(250 char);
    v_initiative_org_id         number(10);
    v_organizational_progress   number;
    v_parent_objective_id       number(10);
    v_period_range_id           number(10);
    v_objective_privacy         varchar(30 char);
    v_initiative_privacy        varchar(30 char);
    v_organizational_privacy    varchar(30 char);
    v_last_checkin_value        number;
    v_last_checkin_date_time    timestamp(6);
    v_period_sql                varchar2(1000 char);
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.GET_OBJECTIVE - ' || TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_table), ',pi_objective_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_objective_id), ',pi_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_period_columns), ',pi_period_columns => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roles_table), ',pi_roles_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_entity_column), ',pi_entity_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_checkin_table), ',pi_checkin_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_organization_column), ',pi_organization_column => <value>', v_stamp);
    END;

    -- Build statement that return not null column period id --
    select listagg(column_value, ', ') within group(order by column_value)
    into v_period_sql
    from TABLE(pi_period_columns);

    v_period_sql := '  COALESCE(' || v_period_sql || ', null)';

    -- Get initiative data --
    BEGIN
      v_sql :=   'SELECT  CONNECT_BY_ROOT O.ROW_IDENTIFIER INITIATIVE_ID,'          || CHR(10) ||
                 '        CONNECT_BY_ROOT O.OBJECTIVE      INITIATIVE,'             || CHR(10) ||
                 '        CONNECT_BY_ROOT O.OBJECTIVE_PRIVACY INITIATIVE_PRIVACY,'  || CHR(10) ||
                 '        CONNECT_BY_ROOT O.' || pi_organization_column || ','      || CHR(10) ||
                 '        O.OBJECTIVE_TYPE,'                                        || CHR(10) ||
                 '        O.PARENT_OBJECTIVE_ID,'                                   || CHR(10) ||
                 '        CONNECT_BY_ROOT ' || v_period_sql                         || CHR(10) ||
                 'FROM ' || pi_objective_table || ' O '                             || CHR(10) ||
                 'WHERE ROW_IDENTIFIER = :pi_objective_id '                         || CHR(10) ||
                 'CONNECT BY PRIOR O.ROW_IDENTIFIER = O.PARENT_OBJECTIVE_ID'        || CHR(10) ||
                 'START WITH O.PARENT_OBJECTIVE_ID IS NULL';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);

      execute immediate v_sql into v_initiative_id, v_initiative, v_initiative_privacy, v_initiative_org_id, v_objective_type, v_parent_objective_id,  v_initiative_period_id
      using pi_objective_id;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
    END;

    -- Get organizational objective data for objective type --
    BEGIN
      if v_objective_type = 'OBJECTIVE'
      then
        v_sql := 'SELECT  CONNECT_BY_ROOT O.ROW_IDENTIFIER,'                                    || CHR(10) ||
                 '        CONNECT_BY_ROOT O.OBJECTIVE,'                                         || CHR(10) ||
                 '        CONNECT_BY_ROOT O.OBJECTIVE_PRIVACY,'                                 || CHR(10) ||
                 '        CONNECT_BY_ROOT O.' || pi_organization_column || ','                  || CHR(10) ||
                 '        CONNECT_BY_ROOT ' || v_period_sql ||','                               || CHR(10) ||
                 '        DECODE(CONNECT_BY_ROOT M.TARGET_VALUE,'                               || CHR(10) ||
                 '               NULL, TO_NUMBER(0),'                                           || CHR(10) ||
                 '               0, TO_NUMBER(0),'                                              || CHR(10) ||
                 '              (CONNECT_BY_ROOT M.ATTAINMENT/CONNECT_BY_ROOT M.TARGET_VALUE) * 100)'   || CHR(10) ||
                 'FROM ' || pi_objective_table || ' O INNER JOIN '
                         || pi_metric_table || ' M ON O.ROW_IDENTIFIER = M.OBJECTIVE_ID'        || CHR(10) ||
                 'WHERE O.ROW_IDENTIFIER = :pi_objective_id'                                    || CHR(10) ||
                 'CONNECT BY PRIOR O.ROW_IDENTIFIER = O.PARENT_OBJECTIVE_ID'                    || CHR(10) ||
                 'START WITH OBJECTIVE_TYPE = ''ORGANIZATIONAL''';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);

        execute immediate v_sql into v_organizational_id, v_organizational_objective, v_organizational_privacy, v_organizational_org_id,
                                     v_organizational_period_id, v_organizational_progress
        using pi_objective_id;
      end if;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
    END;

    -- If the objective is organizational, get last checkin data --
    BEGIN
      if pi_checkin_table is not null and (v_objective_type = 'ORGANIZATIONAL' OR v_objective_type = 'OBJECTIVE')
      then
        v_sql := 'SELECT CHECKIN_VALUE, CHECKIN_DATE_TIME'         || CHR(10) ||
                 'FROM (SELECT CHECKIN_VALUE, CHECKIN_DATE_TIME'   || CHR(10) ||
                 '      FROM ' || pi_checkin_table                 || CHR(10) ||
                 '      WHERE OBJECTIVE_ID = :pi_objective_id'     || CHR(10) ||
                 '      ORDER BY CHECKIN_DATE_TIME DESC'           || CHR(10) ||
                 '     )'                                          || CHR(10) ||
                 'WHERE ROWNUM = 1';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
        execute immediate v_sql into v_last_checkin_value, v_last_checkin_date_time using pi_objective_id;
      end if;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
    END;

    -- Get parent objective data --
    if v_objective_type != 'INITIATIVE'
    then
      v_sql := 'SELECT ' || v_period_sql              || CHR(10) ||
               '       ,OBJECTIVE_PRIVACY'            || CHR(10) ||
               'FROM ' || pi_objective_table          || CHR(10) ||
               'WHERE ROW_IDENTIFIER = :v_parent_objective_id';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
        execute immediate v_sql into v_period_range_id, v_objective_privacy
        using v_parent_objective_id;
    end if;

    v_sql := 'SELECT ' || v_period_sql || ' AS PERIOD_RANGE_ID,'                          || CHR(10) ||
             '        O.OBJECTIVE,'                                                       || CHR(10) ||
             '        O.OBJECTIVE_DESCRIPTION,'                                           || CHR(10) ||
             '        O.OBJECTIVE_TYPE,'                                                  || CHR(10) ||
             '        O.STRATEGY_LEVER,'                                                  || CHR(10) ||
             '        O.INITIATIVE_CATEGORY,'                                             || CHR(10) ||
             '        O.' || pi_organization_column || ','                                || CHR(10) ||

             '        O.ROW_IDENTIFIER,'                                                  || CHR(10) ||
             '        O.ROW_VERSION,'                                                     || CHR(10) ||
             '        O.OBJECTIVE_PRIVACY,'                                               || CHR(10) ||
             '        O.CREATED_DATE_TIME,'                                               || CHR(10) ||

             '        :v_period_range_id AS PARENT_PERIOD_ID,'                            || CHR(10) ||
             '         O.PARENT_OBJECTIVE_ID,'                                            || CHR(10) ||
             '         O.PARENT_OBJECTIVE,'                                               || CHR(10) ||
             '        :v_parent_objective_privacy AS PARENT_OBJECTIVE_PRIVACY,'           || CHR(10) ||

             '        (SELECT DECODE(TARGET_VALUE,'                                       || CHR(10) ||
             '                       NULL, TO_NUMBER(0),'                                 || CHR(10) ||
             '                       0, TO_NUMBER(0),'                                    || CHR(10) ||
             '                       (ATTAINMENT/TARGET_VALUE) * 100)'                    || CHR(10) ||
             '         FROM ' || pi_metric_table                                          || CHR(10) ||
             '         WHERE OBJECTIVE_ID = O.PARENT_OBJECTIVE_ID'                        || CHR(10) ||
             '        ) AS PARENT_PROGRESS,'                                              || CHR(10) ||

             '        M.OBJECTIVE_METRIC_NAME, '                                          || CHR(10) ||
             '        M.METRIC_DESCRIPTION, '                                             || CHR(10) ||
             '        M.TARGET_VALUE, '                                                   || CHR(10) ||
             '        M.ATTAINMENT, '                                                     || CHR(10) ||
             '        M.WEIGHT, '                                                         || CHR(10) ||

             '        :v_last_checkin_value      AS LAST_CHECKIN_VALUE, '                 || CHR(10) ||
             '        :v_last_checkin_date_time  AS LAST_CHECKIN_DATE_TIME, '             || CHR(10) ||

             '        :v_initiative_period_id    AS INITIATIVE_PERIOD_ID,'                || CHR(10) ||
             '        :v_initiative_id           AS INITIATIVE_ID,'                       || CHR(10) ||
             '        :v_initiative              AS INITIATIVE,'                          || CHR(10) ||
             '        :v_initiative_org_id       AS INITIATIVE_ORGANIZATION,'             || CHR(10) ||
             '        :v_initiative_privacy      AS INITIATIVE_PRIVACY,'                  || CHR(10) ||

             '        (SELECT DECODE(SUM(WEIGHT),'                                        || CHR(10) ||
             '                       NULL, TO_NUMBER(0),'                                 || CHR(10) ||
             '                       0, TO_NUMBER(0),'                                    || CHR(10) ||
             '                       SUM(DECODE(TARGET_VALUE,'                            || CHR(10) ||
             '                                  NULL, TO_NUMBER(0),'                      || CHR(10) ||
             '                                  0, TO_NUMBER(0),'                         || CHR(10) ||
             '                                  (ATTAINMENT/TARGET_VALUE) * WEIGHT) * 100))' || CHR(10) ||
             '         FROM ' || pi_objective_table || ' O INNER JOIN ' || pi_metric_table
                              || ' M ON O.ROW_IDENTIFIER = M.OBJECTIVE_ID'                || CHR(10) ||
             '         WHERE O.PARENT_OBJECTIVE_ID = :v_initiative_id'                    || CHR(10) ||
             '        ) AS INITIATIVE_PROGRESS,'                                          || CHR(10) ||

             '        :v_organizational_period_id  AS ORGANIZATIONAL_PERIOD_ID,'          || CHR(10) ||
             '        :v_organizational_id         AS ORGANIZATIONAL_ID,'                 || CHR(10) ||
             '        :v_organizational_objective  AS ORGANIZATIONAL_OBJECTIVE,'          || CHR(10) ||
             '        :v_organizational_org_id     AS ORGANIZATIONAL_ORGANIZATION,'       || CHR(10) ||
             '        :v_organizational_progress   AS ORGANIZATIONAL_PROGRESS,'           || CHR(10) ||
             '        :v_organizational_privacy    AS ORGANIZATIONAL_PRIVACY,'            || CHR(10) ||

             '        (SELECT ' || pi_entity_column || ' FROM ' || pi_roles_table || ' R' || CHR(10) ||
             '         WHERE ROLE_TYPE = 0 AND R.OBJECTIVE_ID = O.ROW_IDENTIFIER'         || CHR(10) ||
             '        ) AS OWNER_ID, '                                                    || CHR(10) ||

             case when v_objective_type != 'INITIATIVE' then
             '        CAST(MULTISET(SELECT OBJTYPE_OBJECTIVE_ASSIGNEE(E.' || pi_entity_column || ', E.WEIGHT)' || CHR(10) ||
             '                      FROM ' || pi_roles_table || ' E WHERE E.ROLE_TYPE = 1 AND E.OBJECTIVE_ID = O.ROW_IDENTIFIER' || CHR(10) ||
             '                     ) AS TABLETYPE_OBJECTIVE_ASSIGNEES'                    || CHR(10) ||
             '            )'
                  else
             '        CAST(NULL AS TABLETYPE_OBJECTIVE_ASSIGNEES)'
             end ||   ' AS ASSIGNEES,'                                                    || CHR(10) ||

             '        CAST(MULTISET(SELECT OBJTYPE_OBJECTIVE_LIST'                        || CHR(10) ||
             '                              (' || v_period_sql || ', C.ROW_IDENTIFIER, C.OBJECTIVE, C.OBJECTIVE_PRIVACY, C.'
                                               || pi_organization_column || ', CM.TARGET_VALUE, CM.ATTAINMENT, CM.WEIGHT,' || CHR(10) ||
             '                               (SELECT COUNT(*) FROM ' || pi_roles_table    || CHR(10) ||
             '                                WHERE ROLE_TYPE = 1 AND OBJECTIVE_ID = C.ROW_IDENTIFIER)'                 || CHR(10) ||
             '                              )'                                           	|| CHR(10) ||
             '                     FROM ' || pi_objective_table || ' C LEFT OUTER JOIN ' || pi_metric_table || ' CM '
                                          || 'ON C.ROW_IDENTIFIER = CM.OBJECTIVE_ID'      || CHR(10) ||
             '                     WHERE C.PARENT_OBJECTIVE_ID = O.ROW_IDENTIFIER'        || CHR(10) ||
             '                    ) AS TABLETYPE_OBJECTIVE_LIST'                          || CHR(10) ||
             '            ) CHILD_OBJECTIVES,'                                            || CHR(10) ||

             '        (SELECT COUNT(*) FROM ' || pi_roles_table                           || CHR(10) ||
             '         WHERE OBJECTIVE_ID = O.PARENT_OBJECTIVE_ID AND ROLE_TYPE = 1'      || CHR(10) ||
             '        ) AS PARENT_ASSIGNEES_COUNT'                                        || CHR(10) ||

             'FROM  ' || pi_objective_table || ' O LEFT OUTER JOIN ' || pi_metric_table || ' M ON O.ROW_IDENTIFIER = M.OBJECTIVE_ID' || CHR(10) ||
             'WHERE O.ROW_IDENTIFIER = :pi_objective_id';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);

    open po_objectives for v_sql
    using v_period_range_id, v_objective_privacy, v_last_checkin_value, v_last_checkin_date_time, v_initiative_period_id, v_initiative_id,
          v_initiative, v_initiative_org_id, v_initiative_privacy, v_initiative_id,
          v_organizational_period_id, v_organizational_id, v_organizational_objective,
          v_organizational_org_id, v_organizational_progress, v_organizational_privacy, pi_objective_id;

  EXCEPTION
  WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
  END GET_OBJECTIVE;



-- #############################  CHECKIN_OBJECTIVE  #############################
--  Description: Update the attainment of an objective and log the information
--               in checkin history table
--  Author     : Ivanov, Ioan
--  Modify date: 2016/01/12
--  ---------------------------------------------------------------------------------------
--  Parameters:
--    pi_metric_table        in varchar2      - the metric table name
--    pi_objective_id        in number        - the id of the objective to be updated
--    pi_attainment          in number        - the objective attainment to be updated
--    pi_checkin_table       in varchar2      - the checkin history table
--    pi_entity_column       in varchar2      - the entity column name
--    pi_entity_id           in number        - the id of the entity who made the checkin
--    pi_comment             in varchar2      - the checkin comment

--  Return: 0 - function executed successfully
--          1 - function failed if attainment after applying checkin gets negative
--  ----------------------------------------------------------------------------------------
--  Example:  social_objectives.checkin_objective(pi_metric_table   => 'T3128352',
--                                                pi_objective_id   => 10,
--                                                pi_attainment     => 90
--                                                pi_checkin_table  => 'T3128390',
--                                                pi_entity_column  => 'E3128174',
--                                                pi_entity_id      => 22,
--                                                pi_comment        => 'Products sold');
--  -----------------------------------------------------------------------------------------

  FUNCTION CHECKIN_OBJECTIVE
  (
    pi_metric_table   in varchar2,
    pi_objective_id   in number,
    pi_attainment     in number,
    pi_checkin_table  in varchar2,
    pi_entity_column  in varchar2,
    pi_entity_id      in number,
    pi_comment        in varchar2 := NULL
  )
  RETURN NUMBER
  IS
    v_result number(10) := 0;
    v_sql clob;
    v_stamp varchar2(200 char);
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.CHECKIN_OBJECTIVE - '|| TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_objective_id), ',pi_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_attainment) ,',pi_attainment => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_checkin_table), ',pi_checkin_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_entity_column), ',pi_entity_column => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_entity_id), ',pi_entity_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_comment), ',pi_comment => <value>', v_stamp);
    END;

    -- Update attainment value in metric table
    v_sql := 'UPDATE ' || pi_metric_table || CHR(10) ||
             'SET ATTAINMENT = ATTAINMENT + :pi_attainment'   || CHR(10) ||
             'WHERE OBJECTIVE_ID = :pi_objective_id AND'      || CHR(10) ||
             '      (CASE WHEN :pi_attainment < 0 AND ATTAINMENT + :pi_attainment < 0 ' || CHR(10) ||
             '             THEN 0 ELSE 1'                     || CHR(10) ||
             '      END) = 1'                                 || CHR(10) ||
             'RETURNING ROW_IDENTIFIER INTO :v_result';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_attainment, pi_objective_id, pi_attainment, pi_attainment, out v_result;

    if v_result is null then
      return 1;
    end if;

    -- Insert checkin value into checkin history table
    v_sql := 'INSERT INTO ' || pi_checkin_table
                            || ' ('
                            || 'OBJECTIVE_ID, '
                            || 'CHECKIN_VALUE, '
                            ||  pi_entity_column || ', '
                            || 'CHECKIN_COMMENT, '
                            || 'CHECKIN_DATE_TIME, '
                            || 'ROW_IDENTIFIER, '
                            || 'ROW_VERSION'
                            || ')'                        || CHR(10) ||
             'VALUES   ('   || TO_CHAR(pi_objective_id)   || ', '
                            || TO_CHAR(pi_attainment)     || ', '
                            || TO_CHAR(pi_entity_id)      || ', '
                            || ':pi_comment, '
                            || 'SYSDATE, '
                            || pi_checkin_table ||'_ROW_IDENTIFIER_SEQ.NEXTVAL, '
                            || '0)';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_comment;

    return 0;
  EXCEPTION
  WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
  END CHECKIN_OBJECTIVE;



-- ##################################  REALIGN_CHILDREN  ######################################
--  Description: Add children to an objective.
--  --------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table        in varchar2   - the name of the objective table
--    pi_parent_objective_id    in number     - the id of the parent objective
--    pi_parent_objective       in varchar2   - the name of the parent objective
--    pi_metric_table           in varchar2   - the name of the metric table
--    pi_child_objectives       in coltype_id - the list of objectives ids to be added as child
--    pi_row_version            in number     - the version of the row to be updated

--  Return: 0 - function executed successfully
--          1 - function failed due to row version
--  ----------------------------------------------------------------------------------------
--  result := social_objectives.realign_children(pi_objective_table    => 'T3493333',
--                                               pi_objective_id       => 1,
--                                               pi_objective          => 'Team Objective 01',
--                                               pi_metric_table       => 'T3493377',
--                                               pi_child_objectives   => coltype_id(11, 12),
--                                               pi_row_version        => 0);
--  ----------------------------------------------------------------------------------------
  FUNCTION REALIGN_CHILDREN
  (
    pi_objective_table        in varchar2,
    pi_objective_id           in number,
    pi_objective              in varchar2,
    pi_metric_table           in varchar2,
    pi_child_objectives       in coltype_id,
    pi_row_version            in number
  )
  RETURN NUMBER
  IS
    v_sql       clob;
    v_result    number(10) := 0;
    v_stamp     varchar2(200 char);
    v_has_cycle number(1);
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.REALIGN_CHILDREN - '|| TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective_table), ',pi_objective_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_objective), ',pi_parent_objective => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_objective_id), ',pi_parent_objective_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_row_version) ,',pi_row_version => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_child_objectives), ',pi_child_objectives => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_row_version) ,',pi_row_version => <value>', v_stamp);
    END;

    -- Check if objective was modified --
    v_sql := 'UPDATE ' || pi_objective_table           || CHR(10) ||
             'SET ROW_VERSION = :pi_row_version + 1'   || CHR(10) ||
             'WHERE ROW_IDENTIFIER = :pi_objective_id AND ROW_VERSION = :pi_row_version' || CHR(10) ||
             'RETURNING ROW_IDENTIFIER INTO :v_result';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_row_version, pi_objective_id, pi_row_version, out v_result;

    if v_result is null then
      return 1;
    end if;

    -- Check hierarchy cycles --
    v_sql := 'SELECT count(*) as HAS_CYCLES'                                                 || CHR(10) ||
             'FROM TABLE(:pi_child_objectives)'                                              || CHR(10) ||
             'WHERE (COLUMN_VALUE IN (SELECT PARENT_OBJECTIVE_ID'                            || CHR(10) ||
             '                        FROM ' || pi_objective_table                           || CHR(10) ||
             '                        CONNECT BY PRIOR PARENT_OBJECTIVE_ID = ROW_IDENTIFIER' || CHR(10) ||
             '                        START WITH ROW_IDENTIFIER = :pi_objective_id'          || CHR(10) ||
             '                       ))'                                                     || CHR(10) ||
             '       OR COLUMN_VALUE = :pi_objective_id';

    execute immediate v_sql into v_has_cycle using pi_child_objectives, pi_objective_id, pi_objective_id;

    if (v_has_cycle > 0)
    then
      raise_application_error(-20801, 'HIERARCHY CYCLE');
    end if;

    -- Set organizational objectives weight to zero if they are transfered to other initiative --
    v_sql := 'UPDATE ' || pi_metric_table                                                  || CHR(10) ||
             'SET WEIGHT = 0'                                                              || CHR(10) ||
             'WHERE OBJECTIVE_ID IN (SELECT COLUMN_VALUE FROM TABLE(:pi_child_objectives)' || CHR(10) ||
             '                       MINUS'                                                || CHR(10) ||
             '                       SELECT ROW_IDENTIFIER FROM ' || pi_objective_table    || CHR(10) ||
             '                       WHERE PARENT_OBJECTIVE_ID = :pi_objective_id'         || CHR(10) ||
             '                      )';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_child_objectives, pi_objective_id;

    -- Set child objectives --
    v_sql := 'UPDATE ' || pi_objective_table                                              || CHR(10) ||
             'SET PARENT_OBJECTIVE_ID = :pi_objective_id,'                                || CHR(10) ||
             '    PARENT_OBJECTIVE    = :pi_objective'                                    || CHR(10) ||
             'WHERE ROW_IDENTIFIER IN (SELECT COLUMN_VALUE FROM TABLE(:pi_child_objectives))';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_objective_id, pi_objective, pi_child_objectives;

    return 0;
  END REALIGN_CHILDREN;




-- ##########################################  DELETE_CHILDREN  #############################################
--  Description: Delete the objectives from the input list and all their children
--  Author     : Ivanov, Ioan
--  Modify date: 2016/09/28
--  ---------------------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table     in varchar2   - the name of the objective table
--    pi_metric_name         in varchar2   - the name of the objective metric
--    pi_roles_table         in varchar2   - the table that stores owners and assignees
--    pi_child_objectives    in coltype_id - the ids of the objectives to be deleted
--    pi_entity_column       in varchar2   - the name of the entity column
--    pi_context_id          in number     - the id of the social objective definition
--  ---------------------------------------------------------------------------------------------------------
  PROCEDURE DELETE_CHILDREN
  (
    pi_objective_table    in varchar2,
    pi_metric_table       in varchar2,
    pi_roles_table        in varchar2,
    pi_objective_ids      in coltype_id,
    pi_entity_column      in varchar2,
    pi_context_id         in number
  )
  IS
    v_sql     clob;
    v_stamp   varchar2(200 char);
    v_ids     tabletype_id_name := tabletype_id_name();
    v_subtree tabletype_id_name := tabletype_id_name();
    v_id      number;
  BEGIN
    v_stamp := 'SOCIAL_OBJECTIVES.DELETE_CHILDREN - '|| TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertvarchar2(pi_objective_table), ',pi_objective_table => <value>', v_stamp);
      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertvarchar2(pi_metric_table), ',pi_metric_table => <value>', v_stamp);
      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertvarchar2(pi_roles_table), ',pi_roles_table => <value>', v_stamp);
      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertcollection(pi_objective_ids), ',pi_objectives_ids => <value>', v_stamp);
      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertvarchar2(pi_entity_column), ',pi_entity_column => <value>', v_stamp);
      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertnumber(pi_context_id) ,',pi_context_id => <value>', v_stamp);
    END;

    for id in pi_objective_ids.first..pi_objective_ids.last
    loop
      v_id := pi_objective_ids(id);

      -- Delete objective and all his children --
      v_sql :=  'DELETE FROM ' || pi_objective_table                                          || CHR(10) ||
                'WHERE ROW_IDENTIFIER = :pi_objective_id OR'                                  || CHR(10) ||
                '      ROW_IDENTIFIER IN ( SELECT ROW_IDENTIFIER'                             || CHR(10) ||
                '                    FROM ' || pi_objective_table                             || CHR(10) ||
                '                    CONNECT BY PRIOR ROW_IDENTIFIER = PARENT_OBJECTIVE_ID'   || CHR(10) ||
                '                    START WITH PARENT_OBJECTIVE_ID = :pi_objective_id'       || CHR(10) ||
                '                   )'                                                        || CHR(10) ||
                'RETURNING OBJTYPE_ID_NAME(ROW_IDENTIFIER, OBJECTIVE_PRIVACY) INTO :1';

      l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertclob(v_sql), 'v_sql := <value>;', v_stamp);
      execute immediate v_sql using v_id, v_id returning bulk collect into v_subtree;

      v_ids := v_ids multiset union v_subtree;
    end loop;

    -- Insert deleted objectives in activity feed entities --
    v_sql := 'INSERT INTO ACTIVITY_FEED_SO_ENTITIES'         || CHR(10) ||
             '     ( AFSE_ID,'                               || CHR(10) ||
             '       AFSE_ENTITY_ID,'                        || CHR(10) ||
             '       AFSE_ROLE_TYPE,'                        || CHR(10) ||
             '       AFSE_SOURCE_ID,'                        || CHR(10) ||
             '       AFSE_CONTEXT_ID'                        || CHR(10) ||
             '     )'                                        || CHR(10) ||
             'SELECT ACTIVITY_FEED_SO_ENTITIES_SEQ.NEXTVAL,' || CHR(10) ||
             '       ' || pi_entity_column || ','            || CHR(10) ||
             '       ROLE_TYPE,'                             || CHR(10) ||
             '       OBJECTIVE_ID,'                          || CHR(10) ||
             '       :pi_context_id'                         || CHR(10) ||
             'FROM ' || pi_roles_table                       || CHR(10) ||
             'WHERE OBJECTIVE_ID IN (SELECT ID FROM TABLE(:v_ids))';

    l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertclob(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_context_id, v_ids;

    -- Insert privacy for deleted objectives --
    v_sql := 'INSERT INTO ACTIVITY_FEED_SO_PRIVACY'          || CHR(10) ||
             '     ( AFSP_ID,'                               || CHR(10) ||
             '       AFSP_SOURCE_ID,'                        || CHR(10) ||
             '       AFSP_SOURCE_PRIVACY,'                   || CHR(10) ||
             '       AFSP_CONTEXT_ID'                        || CHR(10) ||
             '     )'                                        || CHR(10) ||
             'SELECT ACTIVITY_FEED_SO_PRIVACY_SEQ.NEXTVAL,'  || CHR(10) ||
             '       ID,'                                    || CHR(10) ||
             '       NAME,'                                  || CHR(10) ||
             '       :pi_context_id'                         || CHR(10) ||
             'FROM TABLE(:v_ids)';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using pi_context_id, v_ids;

    -- Delete objective metric
    v_sql :=  'DELETE FROM ' || pi_metric_table  || CHR(10) ||
              'WHERE OBJECTIVE_ID IN (SELECT ID FROM TABLE(:v_ids))';

    l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertclob(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using v_ids;

    -- Delete objective assingees and owner
    v_sql :=  'DELETE FROM ' || pi_roles_table  || CHR(10) ||
              'WHERE OBJECTIVE_ID IN (SELECT ID FROM TABLE(:v_ids))';

    l4o_logging.log_variable(l4o_logging.lvl_debug, anydata.convertclob(v_sql), 'v_sql := <value>;', v_stamp);
    execute immediate v_sql using v_ids;

  END DELETE_CHILDREN;

END SOCIAL_OBJECTIVES;
/
