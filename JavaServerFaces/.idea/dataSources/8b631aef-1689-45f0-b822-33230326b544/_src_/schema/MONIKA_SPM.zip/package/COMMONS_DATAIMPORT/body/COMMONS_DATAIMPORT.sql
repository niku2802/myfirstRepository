CREATE PACKAGE BODY commons_dataimport AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type     :  SPM
  -- Product           :  commons
  -- Module            :  dataimport-commons
  -- Requester       :  Agarwal, Ankita
  -- Author          :  Rohit, Maxim
  -- Reviewer          :  Homeuca, Victor-Stefan
  -- Review date       :  12-April-2011
  -- Description       :  This package handles raplace and merger mode of data import.
  -- ---------------------------------------------------------------------------

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

  /* OF-9163
  PROCEDURE ALTER_SESSION_NLS_BINARY IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''BINARY''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''BINARY''';
  END ALTER_SESSION_NLS_BINARY;

  PROCEDURE ALTER_SESSION_PROJ_NLS_SETTING IS
    V_NLS_SORT VARCHAR2(160 CHAR);
    V_NLS_COMP VARCHAR2(160 CHAR);
  BEGIN
    SELECT NVL(MAX(VALUE), 'LINGUISTIC')
      INTO V_NLS_COMP
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_COMP';

    SELECT NVL(MAX(VALUE), 'BINARY_CI')
      INTO V_NLS_SORT
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_SORT';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''' || V_NLS_COMP || '''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''' || V_NLS_SORT || '''';
  END ALTER_SESSION_PROJ_NLS_SETTING;
*/
  /*
          -- Author     : Maxim Rohit
          -- Create date: 1 FEB 2011
          -- Module     : DATA IMPORT
          -- Description: This procedure reads the information added to the DATA_IMPORT_TABLE
          to add constraints on to the Dump Table.

          -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME


          --Example
           begin
          -- Call the procedure
           apply_cons_on_dump(pin_data_table, pin_dump_table);
           end;
  */
  procedure apply_cons_on_dump(pin_data_table varchar2,
                               pin_dump_table varchar2) as
    cursor c_apply_cons is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type in ('CONSTRAINT', 'NOT NULL CONSTRAINT');

    v_get_cons  type_data_import_row;
    v_ddl_query clob;
  begin

    OPEN c_apply_cons;

    FETCH c_apply_cons BULK COLLECT
      into v_get_cons;

    CLOSE c_apply_cons;

    FOR C IN 1 .. v_get_cons.COUNT LOOP

      v_ddl_query := replace(replace(v_get_cons(c).dir_DDL_statement,
                                     v_get_cons(c).dir_Original_name,
                                     v_get_cons(c).DIR_Dump_name),
                             '."' || pin_data_table || '"',
                             '."' || pin_dump_table || '"');
      ---call at

      ----dbms_output.put_line('apply_cons_on_dump');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);

      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);

    end loop;

  end apply_cons_on_dump;

  /*
  -- Author     : Maxim Rohit
  -- Create date: 1 FEB 2011
  -- Module     : DATA IMPORT
  -- Description:This procedure will rename the constraints of  Data table
  to temporary name with the help of information present in the global temporary table DATA_IMPORT_TABLE
  -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME


  --Example
   begin
  -- Call the procedure
  data_const_rename(pin_data_table, pin_process_id, v_index);
  end;
  */

  procedure data_const_rename(pin_table      varchar2,
                              pin_process_id varchar2,
                              pin_index      in out number) as
    cursor c_rename_cons is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'CONSTRAINT';
    v_get_cons       type_data_import_row;
    v_ddl_query      clob;
    v_undo_ddl_query clob;
    v_description    varchar2(1300) := 'data_const_rename';
  begin

    OPEN c_rename_cons;

    FETCH c_rename_cons BULK COLLECT
      into v_get_cons;

    CLOSE c_rename_cons;

    FOR C IN 1 .. v_get_cons.COUNT LOOP

      --rename index first
      for j in (select 1
                  from user_constraints
                 where constraint_name = v_get_cons(C).dir_Original_name
                   and constraint_type in ('P', 'U')) loop
        v_ddl_query := 'ALTER INDEX ' || v_get_cons(C).dir_Original_name ||
                       ' RENAME TO ' || v_get_cons(C).dir_Backup_name;

        v_undo_ddl_query := 'ALTER INDEX ' || v_get_cons(C).dir_Backup_name ||
                            ' RENAME TO ' || v_get_cons(C)
                           .dir_Original_name;
        commons_ddl_handling.execute_ddl(pin_process_id,
                                         v_description,
                                         v_ddl_query,
                                         v_undo_ddl_query,
                                         pin_index);
        pin_index := pin_index + 1;

      end loop;

      v_ddl_query := 'ALTER TABLE ' || pin_table || ' RENAME CONSTRAINT ' || v_get_cons(C)
                    .dir_Original_name || ' TO ' || v_get_cons(C)
                    .dir_Backup_name;

      v_undo_ddl_query := 'ALTER TABLE ' || pin_table ||
                          ' RENAME CONSTRAINT ' || v_get_cons(C)
                         .dir_Backup_name || ' TO ' || v_get_cons(C)
                         .dir_Original_name;
      ----dbms_output.put_line('data_const_rename');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);
      --dbms_output.put_line('v_undo_ddl_query:'||v_undo_ddl_query);

      commons_ddl_handling.execute_ddl(pin_process_id,
                                       v_description,
                                       v_ddl_query,
                                       v_undo_ddl_query,
                                       pin_index);
      pin_index := pin_index + 1;

    ---call at
    end loop;
  end data_const_rename;

  /*
          -- Author     : Maxim Rohit
          -- Create date: 1 FEB 2011
          -- Module     : DATA IMPORT
          -- Description:This procedure Renames dump table constraint to the original Data table
          -- constraints name
          -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME
          --Example
           begin
          -- Call the procedure
           dump_const_rename(pin_dump_table);
           end;
  */
  procedure dump_const_rename(pin_table varchar2) as
    cursor c_rename_cons is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'CONSTRAINT';
    v_get_cons  type_data_import_row;
    v_ddl_query clob;

  begin

    OPEN c_rename_cons;

    FETCH c_rename_cons BULK COLLECT
      into v_get_cons;

    CLOSE c_rename_cons;

    FOR C IN 1 .. v_get_cons.COUNT LOOP

      ---rename index first
      for j in (select 1
                  from user_constraints
                 where constraint_name = v_get_cons(C).DIR_Dump_name
                   and constraint_type in ('P', 'U')) loop
        v_ddl_query := 'ALTER INDEX ' || v_get_cons(C).DIR_Dump_name ||
                       ' RENAME TO ' || v_get_cons(C).dir_Original_name;

        ----dbms_output.put_line('v_ddl_query:'||v_ddl_query);
        commons_ddl_handling.execute_ddl_nolog(v_ddl_query);

      end loop;

      v_ddl_query := 'ALTER TABLE ' || pin_table || ' RENAME CONSTRAINT ' || v_get_cons(C)
                    .DIR_Dump_name || ' TO ' || v_get_cons(C)
                    .dir_Original_name;

      ----dbms_output.put_line('dump_const_rename');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);

      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);

    ---call at

    end loop;
  end dump_const_rename;

  /*
            -- Author     : Maxim Rohit
            -- Create date: 1 FEB 2011
            -- Module     : DATA IMPORT
            -- Description:This procedure reads the information added to the DATA_IMPORT_TABLE
            to add constraints on to the Dump Table.
            -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME
                     --Example
           begin
          -- Call the procedure
           apply_index_on_dump(pin_data_table, pin_dump_table);
           end;
  */

  procedure apply_index_on_dump(pin_data_table varchar2,
                                pin_dump_table varchar2) as
    cursor c_apply_index is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'INDEX';
    v_get_index type_data_import_row;
    v_ddl_query varchar2(1300);
  begin

    OPEN c_apply_index;

    FETCH c_apply_index BULK COLLECT
      into v_get_index;

    CLOSE c_apply_index;

    FOR C IN 1 .. v_get_index.COUNT LOOP

      v_ddl_query := replace(replace(v_get_index(c).dir_DDL_statement,
                                     v_get_index(c).dir_Original_name,
                                     v_get_index(c).DIR_Dump_name),
                             '."' || pin_data_table || '"',
                             '."' || pin_dump_table || '"');

      ----dbms_output.put_line('apply_index_on_dump');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);
      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      ---call at

    end loop;

  end apply_index_on_dump;

  /*
            -- Author     : Maxim Rohit
            -- Create date: 1 FEB 2011
            -- Module     : DATA IMPORT
            -- Description:This procedure will rename the indexes of Data table
            to temporary name with the help of information present in the global temporary table DATA_IMPORT_TABLE.
            -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME
                          --Example
           begin
          -- Call the procedure
              data_index_rename(pin_process_id, v_index);
            end;
  */

  procedure data_index_rename(pin_process_id varchar2,
                              pin_index      in out number) as
    cursor c_rename_index is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'INDEX';
    v_get_index      type_data_import_row;
    v_ddl_query      clob;
    v_undo_ddl_query clob;
    v_description    varchar2(1300) := 'data_index_rename';
  begin

    OPEN c_rename_index;

    FETCH c_rename_index BULK COLLECT
      into v_get_index;

    CLOSE c_rename_index;

    FOR C IN 1 .. v_get_index.COUNT LOOP
      v_ddl_query := 'ALTER INDEX ' || v_get_index(C).dir_Original_name ||
                     ' RENAME TO ' || v_get_index(C).dir_Backup_name;

      v_undo_ddl_query := 'ALTER INDEX ' || v_get_index(C).dir_Backup_name ||
                          ' RENAME TO ' || v_get_index(C).dir_Original_name;

      ----dbms_output.put_line('data_index_rename');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);
      --dbms_output.put_line('v_undo_ddl_query:'||v_undo_ddl_query);

      commons_ddl_handling.execute_ddl(pin_process_id,
                                       v_description,
                                       v_ddl_query,
                                       v_undo_ddl_query,
                                       pin_index);

      pin_index := pin_index + 1;
      ---call at

    end loop;
  end data_index_rename;

  /*
            -- Author     : Maxim Rohit
            -- Create date: 1 FEB 2011
            -- Module     : DATA IMPORT
            -- Description:This procedure Renames dump table index to the original Data table index
            name
      -- Assumptions: Session based data is already added to TEMP_DATA_IMPORT_RENAME
                                   --Example
           begin
          -- Call the procedure
         dump_index_rename;
          end;
  */

  procedure dump_index_rename as
    cursor c_rename_index is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'INDEX';
    v_get_index type_data_import_row;
    v_ddl_query clob;

  begin

    OPEN c_rename_index;

    FETCH c_rename_index BULK COLLECT
      into v_get_index;

    CLOSE c_rename_index;

    FOR C IN 1 .. v_get_index.COUNT LOOP
      v_ddl_query := 'ALTER INDEX ' || v_get_index(C).DIR_Dump_name ||
                     ' RENAME TO ' || v_get_index(C).dir_Original_name;

      ----dbms_output.put_line('dump_index_rename');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);

      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      ---call at

    end loop;
  end dump_index_rename;

  procedure apply_trigger_on_dump(pin_data_table varchar2,
                                  pin_dump_table varchar2) as
    cursor c_apply_trigger is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'TRIGGER';
    v_get_trigger type_data_import_row;
    v_ddl_query   varchar2(1300);
  begin

    OPEN c_apply_trigger;

    FETCH c_apply_trigger BULK COLLECT
      into v_get_trigger;

    CLOSE c_apply_trigger;

    FOR C IN 1 .. v_get_trigger.COUNT LOOP

      v_ddl_query := replace(replace(v_get_trigger(c).dir_DDL_statement,
                                     v_get_trigger(c).dir_Original_name,
                                     v_get_trigger(c).DIR_Dump_name),
                             '."' || pin_data_table || '"',
                             '."' || pin_dump_table || '"');

      ----dbms_output.put_line('apply_trigger_on_dump');
      --dbms_output.put_line('v_ddl_query:'||v_ddl_query);

      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      ---call at

    end loop;

  end apply_trigger_on_dump;

  procedure data_trigger_rename(pin_process_id varchar2,
                                pin_trigger    in out number) as
    cursor c_rename_trigger is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'TRIGGER';
    v_get_trigger    type_data_import_row;
    v_ddl_query      clob;
    v_undo_ddl_query clob;
    v_description    varchar2(1300) := 'data_trigger_rename';
  begin

    OPEN c_rename_trigger;

    FETCH c_rename_trigger BULK COLLECT
      into v_get_trigger;

    CLOSE c_rename_trigger;

    FOR C IN 1 .. v_get_trigger.COUNT LOOP
      v_ddl_query := 'ALTER trigger ' || v_get_trigger(C).dir_Original_name ||
                     ' RENAME TO ' || v_get_trigger(C).dir_Backup_name;

      v_undo_ddl_query := 'ALTER trigger ' || v_get_trigger(C)
                         .dir_Backup_name || ' RENAME TO ' || v_get_trigger(C)
                         .dir_Original_name;

      commons_ddl_handling.execute_ddl(pin_process_id,
                                       v_description,
                                       v_ddl_query,
                                       v_undo_ddl_query,
                                       pin_trigger);

      pin_trigger := pin_trigger + 1;
      ---call at

    end loop;
  end data_trigger_rename;

  procedure dump_trigger_rename as
    cursor c_rename_trigger is
      select *
        from TEMP_DATA_IMPORT_RENAME
       where dir_object_type = 'TRRIGER';
    v_get_trigger type_data_import_row;
    v_ddl_query   clob;

  begin

    OPEN c_rename_trigger;

    FETCH c_rename_trigger BULK COLLECT
      into v_get_trigger;

    CLOSE c_rename_trigger;

    FOR C IN 1 .. v_get_trigger.COUNT LOOP
      v_ddl_query := 'ALTER TRRIGER ' || v_get_trigger(C).DIR_Dump_name ||
                     ' RENAME TO ' || v_get_trigger(C).dir_Original_name;

      commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      ---call at

    end loop;
  end dump_trigger_rename;

  /*
  PROCEDURE CREATE_DUMP_TABLE(pi_data_table varchar2,
                         pi_dump_table varchar2,
                         pi_col_list Clob,
                         pi_external_table varchar2,
                         pi_process_id integer) as

   v_ddl_query      clob;
   v_undo_ddl_query clob;
   v_dump_table             varchar2(30):=upper(pi_dump_table) ;
   v_data_table             varchar2(30):=upper(pi_data_table);
  begin

     v_ddl_query:='CREATE SEQUENCE '|| SUBSTR(v_dump_table, 0, 5)||'_SEQ_'||SUBSTR(v_dump_table, -5, 5)


  end;*/

  /*PROCEDURE MAIN_REPLACE(pi_data_table      varchar2,
                         pi_dump_table      varchar2,
                         pi_process_id      varchar2,
                         pi_id_column_name  VARCHAR2,
                         pi_seq_used_for_id VARCHAR2) as

    ---********* variable declaration ************--------
    v_dump_table     varchar2(30) := upper(pi_dump_table);
    v_data_table     varchar2(30) := upper(pi_data_table);
    v_index_ddl_name commons_utils.type_index_ddl_composite;
    v_cons_ddl_name  commons_utils.type_constraint_ddl_composite;
    v_trg_ddl_name   commons_utils.type_trigger_ddl_composite;
    v_ddl_query      clob;
    v_undo_ddl_query clob;
    v_status         number(1) := 0;
    v_index          number := 1;
    v_condition      long;
    v_count_new      varchar(250);
    v_count_reset    number;
    v_seq_status     boolean := false;
    v_seq_ori        number;
  begin
    --ALTER_SESSION_NLS_BINARY -- OF-9163();

    ---********* Retrieve DDL for constraints on the data table ************--------
    \*
        commons_utils.get_constraint_ddl(v_data_table, v_cons_ddl_name);

    *\
    --dbms_output.put_line('get_constraint_ddl');
    commons_utils.get_constraint_ddl(pi_table          => v_data_table,
                                     pi_where_clause   => 'constraint_type in (''C'', ''P'', ''U'', ''R'')',
                                     po_constraint_ddl => v_cons_ddl_name);
    ---********* Insert constraints rename related Information into TEMP_DATA_IMPORT_RENAME ************--------
    --Insert into the global temporary table
    FOR C IN 1 .. v_cons_ddl_name.COUNT LOOP
      select search_condition
        into v_condition
        from user_constraints
       where constraint_name = v_cons_ddl_name(c).const_name;

      ----to differtiate between NOT NULL and other constraints
      -- chnages for not copying not null constraint of ROW_IDENTIFIER and ROW_VERSION
      if substr(v_condition, -11) = 'IS NOT NULL' then
        -- changes for not copying not null constraint of ROW_IDENTIFIER and ROW_VERSION
        if v_condition not in
           ('"ROW_IDENTIFIER" IS NOT NULL', '"ROW_VERSION" IS NOT NULL') then
          insert into TEMP_DATA_IMPORT_RENAME
            (DIR_Original_name,
             DIR_DDL_statement,
             DIR_Dump_name,
             DIR_Backup_name,
             DIR_object_type)
          values
            (v_cons_ddl_name(c).const_name,
             v_cons_ddl_name(c).ddl_stmt,
             SUBSTR(v_cons_ddl_name(c).const_name, 0, 25) || '_DUMP',
             SUBSTR(v_cons_ddl_name(c).const_name, 0, 25) || '_DATA',
             'NOT NULL CONSTRAINT');
        end if;

      else
        insert into TEMP_DATA_IMPORT_RENAME
          (DIR_Original_name,
           DIR_DDL_statement,
           DIR_Dump_name,
           DIR_Backup_name,
           DIR_object_type)
        values
          (v_cons_ddl_name(c).const_name,
           v_cons_ddl_name(c).ddl_stmt,
           SUBSTR(v_cons_ddl_name(c).const_name, 0, 25) || '_DUMP',
           SUBSTR(v_cons_ddl_name(c).const_name, 0, 25) || '_DATA',
           'CONSTRAINT');
      end if;
    END loop;

    --get index ddl
    ---********* Retrieve DDL for Indexes on the data table ************--------
    \*    commons_utils.get_index_ddl(v_data_table, v_index_ddl_name);
    *\
    --dbms_output.put_line('get_index_ddl');
    commons_utils.get_index_ddl(pi_table        => v_data_table,
                                pi_where_clause => 'index_name not in
                            (SELECT \*+ NL_AJ *\
                             index_name
                             FROM  user_constraints C
                             WHERE C.table_name = ''' ||
                                                   v_data_table || '''
                             AND C.constraint_type in (''P'', ''U''))',
                                po_index_ddl    => v_index_ddl_name);

    ---********* Insert constraints rename related Information into TEMP_DATA_IMPORT_RENAME ************--------
    FOR C IN 1 .. v_index_ddl_name.COUNT LOOP

      insert into TEMP_DATA_IMPORT_RENAME
        (DIR_Original_name,
         DIR_DDL_statement,
         DIR_Dump_name,
         DIR_Backup_name,
         DIR_object_type)
      values
        (v_index_ddl_name(c).index_name,
         v_index_ddl_name(c).ddl_stmt,
         SUBSTR(v_index_ddl_name(c).index_name, 0, 25) || '_DUMP',
         SUBSTR(v_index_ddl_name(c).index_name, 0, 25) || '_DATA',
         'INDEX');

    END loop;

    ------get trrigeer ddl
    ---********* Retrieve DDL for Triggers on the data table ************--------
    \*
    commons_utils.get_Trigger_ddl(v_data_table, v_trg_ddl_name);
    *\
    --dbms_output.put_line('get_Trigger_ddl');
    commons_utils.get_Trigger_ddl(pi_table        => v_data_table,
                                  pi_where_clause => null,
                                  po_trigger_ddl  => v_trg_ddl_name);

    FOR C IN 1 .. v_trg_ddl_name.COUNT LOOP

      insert into TEMP_DATA_IMPORT_RENAME
        (DIR_Original_name,
         DIR_DDL_statement,
         DIR_Dump_name,
         DIR_Backup_name,
         DIR_object_type)
      values
        (v_trg_ddl_name(c).trigger_name,
         SUBSTR(v_trg_ddl_name(c).ddl_stmt,
                0,
                INSTR(v_trg_ddl_name(c).ddl_stmt, 'ALTER') - 1),
         SUBSTR(v_trg_ddl_name(c).trigger_name, 0, 25) || '_DUMP',
         SUBSTR(v_trg_ddl_name(c).trigger_name, 0, 25) || '_DATA',
         'TRIGGER');

    END loop;
    \*  commit;*\
    \*Apply  constraints to dump table*\

    \*commons_ddl_handling.execute_ddl_nolog('create table TEMP_DATA_IMPORT_RENAME_bkp as select * from TEMP_DATA_IMPORT_RENAME');*\
    apply_cons_on_dump(v_data_table, v_dump_table);

    \*Apply  indexes to dump table*\

    apply_index_on_dump(v_data_table, v_dump_table);

    \*Apply  trriger  to dump table*\

    apply_trigger_on_dump(v_data_table, v_dump_table);
    \*Rename the data table constraint*\

    data_const_rename(v_data_table, pi_process_id, v_index);

    \*Rename the data table Index*\

    data_index_rename(pi_process_id, v_index);
    \*Rename the data table trigger*\

    data_trigger_rename(pi_process_id, v_index);

    \*Rename the dump table constraint*\

    dump_const_rename(v_dump_table);

    \*Rename the dump table Index*\

    dump_index_rename;

    \*Rename the dump table trigger*\

    dump_trigger_rename;

    ---Rename the original data table

    v_ddl_query      := 'alter table ' || v_data_table || ' rename to ' ||
                        SUBSTR(v_dump_table, 0, 5) || '_BKP_' ||
                        SUBSTR(v_dump_table, -5, 5);
    v_undo_ddl_query := 'alter table ' || SUBSTR(v_dump_table, 0, 5) ||
                        '_BKP_' || SUBSTR(v_dump_table, -5, 5) ||
                        ' rename to ' || v_data_table;
    ---call at
    dbms_output.put_line('v_ddl_query:' || v_ddl_query);
    dbms_output.put_line('v_undo_ddl_query:' || v_undo_ddl_query);
    commons_ddl_handling.execute_ddl(pi_process_id,
                                     'Renaming original table to backup name',
                                     v_ddl_query,
                                     v_undo_ddl_query,
                                     v_index);

    v_status := 1;

    ---rename dump table to data table
    v_ddl_query      := 'alter table ' || v_dump_table || ' rename to ' ||
                        v_data_table;
    v_undo_ddl_query := null;
    dbms_output.put_line('v_ddl_query:' || v_ddl_query);
    dbms_output.put_line('v_undo_ddl_query:' || v_undo_ddl_query);
    commons_ddl_handling.execute_ddl_nolog(v_ddl_query);

    v_count_new := 'select ' || pi_seq_used_for_id || '.nextval from dual';
    execute immediate v_count_new
      into v_seq_ori;

    v_count_new := 'select max(' || pi_id_column_name || ') from ' ||
                   v_data_table;

    execute immediate v_count_new
      into v_count_reset;
    dbms_output.put_line(v_count_reset);

    --if input is empty then this value will be null
    if (v_count_reset is not null) then

      commons_utils.reset_seq(pi_seq_used_for_id, v_count_reset + 1);

      v_seq_status := true;

    end if;
    ---call AT

    v_status := 2;

    ---drop the original data table
    v_ddl_query      := 'DROP TABLE ' || SUBSTR(v_dump_table, 0, 5) ||
                        '_BKP_' || SUBSTR(v_dump_table, -5, 5);
    v_undo_ddl_query := null;

    dbms_output.put_line('v_ddl_query:' || v_ddl_query);

    commons_ddl_handling.execute_ddl_nolog(v_ddl_query);

    commons_ddl_handling.clean_ddl_log(pi_process_id);
    --gather stats
    commons_utils.Enable_logging(pi_data_table);
    commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => pi_data_table,
                                             PI_MODE  => 2);
    \*   commons_utils.generate_table_stats(pi_table      => pi_data_table,
    pi_percentage => null);*\

    --ALTER_SESSION_PROJ_NLS_SETTING -- OF-9163;
  exception
    when others then
      --dbms_output.put_line('Came to rollback');
      rollback;
      -- dbms_output.put_line(v_status);
      if v_status = 1 then

        v_ddl_query      := 'DROP TABLE ' || v_dump_table;
        v_undo_ddl_query := null;

      elsif v_status = 2 then
        v_ddl_query      := 'DROP TABLE ' || v_data_table;
        v_undo_ddl_query := null;

      else
        v_undo_ddl_query := null;
        v_ddl_query      := null;
      end if;
      --call at
      -- dbms_output.put_line(v_ddl_query);
      if (v_ddl_query is not null) then
        commons_ddl_handling.execute_ddl_nolog(v_ddl_query);
      end if;

      --reset seq to original value
      if (v_seq_status) then

        commons_utils.reset_seq(pi_seq_used_for_id, v_seq_ori);

      end if;

      --call roll back package

      commons_ddl_handling.rollback_ddl(pi_process_id);
      --ALTER_SESSION_PROJ_NLS_SETTING -- OF-9163;
      raise;
  end MAIN_REPLACE;
*/
  PROCEDURE MAIN_MERGE(pi_data_table      varchar2,
                       pi_dump_table      varchar2,
                       pi_process_id      varchar2,
                       pi_id_column_name  VARCHAR2,
                       pi_seq_used_for_id VARCHAR2,
                       po_index_created   out number) as
    v_dump_table              varchar2(30) := upper(pi_dump_table);
    v_data_table              varchar2(30) := upper(pi_data_table);
    V_SIZE_DATA               NUMBER;
    V_SIZE_DUMP               NUMBER;
    V_SIZE_DIFF               NUMBER;
    V_REBUILD                 number(1);
    V_BREAKPOINT_SIZE         NUMBER := 100;
    V_BREAKPOINT_SIMILAR_SIZE NUMBER := 45;
    V_BREAKPOINT_SIMILAR_DIFF NUMBER := 5;
    V_BREAKPOINT_DIFF_SMALL   NUMBER := 50;
    v_index                   number := 0;
    v_column_list             clob;
    v_select_column_list      clob;
    /* v_index_created  boolean:=false;*/
    v_index_created number(1) := 0;
    v_index_status  number := 1;
    e_Data_table_missing exception;
    e_Dump_table_missing exception;
    v_insert_status boolean := false;
    v_tables_id     number;
    v_in_log_msg    clob;
    v_out_log_msg   clob;
    v_before        number;
    v_post          number;

  Begin
    --ALTER_SESSION_NLS_BINARY;
    --check if data table exists
    FOR c IN (select 1
                from dual
               where not exists (SELECT 1
                        FROM user_tables
                       WHERE table_name = v_data_table)) LOOP
      raise e_Data_table_missing;
    END LOOP;

    --check if data table exists
    FOR c IN (select 1
                from dual
               where not exists (SELECT 1
                        FROM user_tables
                       WHERE table_name = v_dump_table)) LOOP
      raise e_Dump_table_missing;
    END LOOP;

    select min(TABLES_ID)
      into v_tables_id
      from tables
     where TABLES_PHYSICAL_NAME = v_data_table;
    /*---disable logging

    commons_utils.Disable_logging(v_data_table,

                                  pi_process_id,
                                  v_index);
    ---no need to uses the logging framework of undo_ddl
    commons_utils.Disable_logging(v_dump_table,

                                  pi_process_id,
                                  v_index);*/

    -------get size
    /*  commons_utils.GET_TABLE_SIZE(v_data_table, V_SIZE_DATA);
      commons_utils.GET_TABLE_SIZE(v_dump_table, V_SIZE_DUMP);
      ----dbms_output.put_line('V_SIZE_DATA= ' || V_SIZE_DATA);
      ----dbms_output.put_line('V_SIZE_DUMP= ' || V_SIZE_DUMP);

      V_SIZE_DIFF := ABS(V_SIZE_DATA - V_SIZE_DUMP);

      ---formula
      select case
               when ((V_SIZE_DIFF < V_BREAKPOINT_SIMILAR_DIFF) AND
                    (V_SIZE_DATA < V_BREAKPOINT_SIMILAR_SIZE)) then
                '0'
               WHEN ((V_SIZE_DIFF > V_BREAKPOINT_DIFF_SMALL) AND
                    (V_SIZE_DATA < V_BREAKPOINT_SIZE)) then
                '0'
               ELSE
                '1'
             end

        into V_REBUILD
        from dual;



      if V_REBUILD = '0' then
        v_index_created := 1;

      end if;

      ----disable indexes
      if V_REBUILD = 1 then

        COMMONS_INDEXING.DISABLE_ALL_INDEXES(PI_TABLES_ID      => v_tables_id,
                                             PI_PROCESS_ID     => NULL,
                                             PI_RUN_ID         => NULL,
                                             PI_TRANSACTION_ID => pi_process_id,
                                             PO_LOG_MSG        => v_in_log_msg);

        v_index_status  := 10;
        v_index_created := 0;



        \*      commons_utils.Disable_indexes(v_data_table, pi_process_id, v_index);
        v_index_created := 0;*\
        \*

          ---- changes for Defect#10526 starts

          commons_utils.Disable_nonunique_indexes(v_data_table,
                                                pi_process_id,
                                                v_index);
         v_index_created := 8;
         commons_utils.Drop_unique_indexes(v_data_table, pi_process_id, v_index);

        v_index_created := 4;


        --dbms_output.put_line(' Disable_indexes');
        commons_utils.Disable_Primary_Key_Cons(v_data_table,
                                               pi_process_id,
                                               v_index);
        -- dbms_output.put_line(' Disable_Primary_Key_Cons');
        v_index_created := 5;

          ---- changes for Defect#10526 ends
          *\

      end if;
    */
    ---- insert with append

    /*  select LISTAGG(tc.tc_physical_name, ',') WITHIN GROUP(ORDER BY tc.tc_order),
          LISTAGG(decode(tc.tc_physical_name,
                         pi_id_column_name,
                         pi_seq_used_for_id || '.nextval',
                         tc.tc_physical_name),
                  ',') WITHIN GROUP(ORDER BY tc.tc_order)

     into v_column_list, v_select_column_list
     from table_columns tc
    inner join tables t
       on t.tables_id = tc.tc_tables_id
    where t.tables_physical_name = upper(v_data_table);*/

    /* v_column_list := ' ( ' || v_column_list || ' ) ';*/

    v_column_list := '(';
    for i in (select tc.tc_physical_name column_name
                from table_columns tc
               inner join tables t
                  on t.tables_id = tc.tc_tables_id
               where t.tables_physical_name = upper(v_data_table)
               and not exists (select 1 from fields where tc_fld_id=fld_id and FLD_DATA_TYPE=9)
               ) loop
      v_column_list := v_column_list || i.column_name || ',';

      if (upper(i.column_name) = upper(pi_id_column_name)) then

        v_select_column_list := v_select_column_list || pi_seq_used_for_id ||
                                '.nextval,';

      else

        v_select_column_list := v_select_column_list || i.column_name || ',';
      end if;
    end loop;
    v_column_list        := substr(v_column_list,
                                   1,
                                   length(v_column_list) - 1);
    v_select_column_list := substr(v_select_column_list,
                                   1,
                                   length(v_select_column_list) - 1);
    v_column_list        := v_column_list || ')';
    /*dbms_output.put_line('Insert \*+ APPEND *\  into ' || v_data_table ||' '||v_column_list||
    ' select '||v_select_column_list||' from ' || v_dump_table);*/
    execute immediate '
  select /*+ PK_' || pi_data_table || '*/ count(' || pi_id_column_name || ') from ' ||
                      pi_data_table
      into v_before;
    v_before := case
                  when v_before = 0 then
                   1
                  else
                   v_before
                end;
 /*   EXECUTE IMMEDIATE 'Insert \*+ APPEND *\  into ' || v_data_table || ' ' ||
                      v_column_list || ' select ' || v_select_column_list ||
                      ' from ' || v_dump_table;*/

    EXECUTE IMMEDIATE 'Insert into ' || v_data_table || ' ' ||
          v_column_list || ' select ' || v_select_column_list ||
    ' from ' || v_dump_table;
    ----a way to roll back
    v_post := sql%rowcount;
    v_post          := nvl(v_post, 0);
  /*  commit;
    v_insert_status := true;*/
    -----rebuild indexes
    /*   if V_REBUILD = 1 then

      COMMONS_INDEXING.ENABLE_ALL_INDEXES(PI_TABLES_ID      => v_tables_id,
                                          PI_PROCESS_ID     => NULL,
                                          PI_RUN_ID         => NULL,
                                          PI_TRANSACTION_ID => pi_process_id,
                                          PO_LOG_MSG        => v_out_log_msg);

      v_index_status := 11;

      \*  ---- changes for Defect#10526 starts
       commons_utils.Enable_Primary_Key_Cons(v_data_table);

      v_index_created:= 2;
      --dbms_output.put_line(' Enable_Primary_Key_Cons');


      commons_tables.CREATE_UNIQUE_INDEXES(pi_tables_id => v_tables_id);
      v_index_created:= 9;
      commons_utils.Rebuild_nonunique_indexes(v_data_table);

      --commons_utils.Rebuild_indexes(v_data_table);

      v_index_created:= 3;
      dbms_output.put_line(' Rebuild_indexes');

        ---- changes for Defect#10526 ends
      *\

      \*
      commons_utils.Rebuild_indexes(v_data_table);
       v_index_created := 1;
       v_index_created  := 2;*\

    end if;*/
    ---OF-9363
   /* po_index_created := v_index_status;*/
    /*    po_index_created := v_index_created;*/
    /*commons_utils.Enable_logging(v_data_table);*/

  /*  commons_ddl_handling.clean_ddl_log(pi_process_id);
    commit;*/
    --gather stats
    if (v_post / v_before > 0.1) then
      commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => pi_data_table,
                                               PI_MODE  => 2);

    end if;
    /* commons_utils.generate_table_stats(pi_table      => pi_data_table,
                                         pi_percentage => null);
    */

    --ALTER_SESSION_PROJ_NLS_SETTING;

  exception
    when e_Data_table_missing then
      raise_application_error(-20101, 'Data table does not exist');
    when e_Dump_table_missing then
      raise_application_error(-20101, 'Dump table does not exist');
    when others then

    raise;
    --everthing below commented with removal of append hint
   /*   if (v_insert_status = false) then
        rollback;
        \*  if(v_index_created in (4,5)) then
        commons_tables.CREATE_UNIQUE_INDEXES(pi_tables_id => v_tables_id);
        end if;*\
        commons_ddl_handling.rollback_ddl(pi_process_id);
        --ALTER_SESSION_PROJ_NLS_SETTING;
        raise;
      elsif (v_insert_status = true) then
        po_index_created := v_index_status;
        --ALTER_SESSION_PROJ_NLS_SETTING;
      end if;

    \* if (v_index_created in (2, 3, 9)) then
       po_index_created := v_index_created;
     else
       \* ----dbms_output.put_line('rollback');
       ----dbms_output.put_line(SQLERRM);*\
    \*   rollback;*\
       commons_ddl_handling.rollback_ddl(pi_process_id);
       --commons_ddl_handling.clean_ddl_log(pi_process_id);
      \* commit;*\
       raise;

     end if;*\*/
  END MAIN_MERGE;

  /*PROCEDURE DI_UNIQUE_CHECK(    pi_DATA_TABLE       IN VARCHAR2,
                                                                 pi_DUMP_TABLE       IN VARCHAR2,
                                                                 pi_IMPORT_MODE      IN NUMBER,
                                                                 pi_KEY_FIELDS       IN CLOB,
                                                                 pi_START_DATE_FIELD IN VARCHAR2,
                                                                 pi_END_DATE_FIELD   IN VARCHAR2,
                                                                  pi_EFF_DATED_TABLE  IN NUMBER,

                                                                 po_UNIQUE_CHK_RES   OUT NUMBER
                                                                ) IS

         v_UNIQUE_STR      CLOB := '';
         v_KEY_COLS        CLOB := '';
         v_OBJECT_NAME     VARCHAR2(30) := '';
         v_CREATE_VIEW_STR VARCHAR2(1300) := '';
         v_DROP_VIEW_STR VARCHAR2(1300) := '';

         v_DUPLICATE_CNT NUMBER(10);
         V_VIEW_CREATED BOOLEAN:=FALSE;

     begin


    -- Create view for APPEND mode
    IF pi_IMPORT_MODE = 2 THEN
      v_OBJECT_NAME     :=SUBSTR(pi_DATA_TABLE, 0, 5) || '_VIEW' ||SUBSTR(pi_DATA_TABLE, -5, 5);

      v_KEY_COLS := 'ROW_IDENTIFIER, ' || pi_KEY_FIELDS || CASE WHEN pi_EFF_DATED_TABLE = 1
                                           THEN ',' || pi_START_DATE_FIELD || ',' || pi_END_DATE_FIELD
                                      ELSE '' END ;

      v_CREATE_VIEW_STR := ' CREATE OR REPLACE VIEW ' || v_OBJECT_NAME || ' AS SELECT ' || v_KEY_COLS ||
                           ' FROM ' || pi_DATA_TABLE ||
                           ' UNION ALL SELECT ' || v_KEY_COLS || ' FROM ' || pi_DUMP_TABLE;

     \* EXECUTE IMMEDIATE v_CREATE_VIEW_STR;*\

     v_DROP_VIEW_STR:='DROP VIEW '||v_OBJECT_NAME;
     ----dbms_output.put_line(v_CREATE_VIEW_STR);
     ----dbms_output.put_line(v_DROP_VIEW_STR);

     commons_ddl_handling.execute_ddl_nolog(v_CREATE_VIEW_STR);
    \*   commons_ddl_handling.execute_ddl(pi_process_id,
                                 'Create temporaray view for data import',
                                 v_CREATE_VIEW_STR,
                                 v_DROP_VIEW_STR,
                                 pio_index);*\
    \*  v_KEY_COLS := '';*\
      V_VIEW_CREATED := TRUE;



    END IF;

    -- INSERT mode
    IF pi_IMPORT_MODE = 1 THEN
      v_OBJECT_NAME := pi_DUMP_TABLE;
    END IF;

       -- Unique Record validation

        v_UNIQUE_STR := ' SELECT MAX(COUNT(*)) FROM ' || v_OBJECT_NAME || ' GROUP BY ' || pi_KEY_FIELDS ||
                      CASE
                        WHEN pi_EFF_DATED_TABLE = 1 THEN ',' || pi_START_DATE_FIELD
                        ELSE ''
                      END ;

       ----dbms_output.put_line(v_UNIQUE_STR);

        EXECUTE IMMEDIATE v_UNIQUE_STR
          INTO v_DUPLICATE_CNT;

        IF v_DUPLICATE_CNT = 1 THEN po_UNIQUE_CHK_RES := 1;
          ELSE po_UNIQUE_CHK_RES := 0;
        END IF;



     commons_ddl_handling.execute_ddl_nolog(v_DROP_VIEW_STR);

     EXCEPTION

     WHEN OTHERS THEN
       IF (V_VIEW_CREATED) THEN
      commons_ddl_handling.execute_ddl_nolog(v_DROP_VIEW_STR);
       END IF;

     end DI_UNIQUE_CHECK;
  */

  /*PROCEDURE DI_OVERLAP_CHECK(    pi_DATA_TABLE       IN VARCHAR2,
                                                                 pi_DUMP_TABLE       IN VARCHAR2,
                                                                 pi_IMPORT_MODE      IN NUMBER,
                                                                 pi_KEY_FIELDS       IN CLOB,
                                                                 pi_START_DATE_FIELD IN VARCHAR2,
                                                                 pi_END_DATE_FIELD   IN VARCHAR2,
                                                                 \* pi_EFF_DATED_TABLE  IN NUMBER,*\
                                                                \* pi_process_id       IN VARCHAR2,*\
                                                                 po_OVERLAP_CHK_RES   OUT NUMBER\*,
                                                                 pio_index           IN OUT NUMBER*\
                                                                ) IS


         v_KEY_COLS        CLOB := '';
         v_OBJECT_NAME     VARCHAR2(30) := '';
         v_CREATE_VIEW_STR VARCHAR2(1300) := '';
         v_DROP_VIEW_STR VARCHAR2(1300) := '';
         v_JOIN_CONDITION  CLOB := '';
         v_FIELDS          VARCHAR2(30) := '';
         v_VIEW_CREATED    BOOLEAN := FALSE;

           v_OVERLAP_STR     CLOB := '';


  V_OVERLAP_RESULT Number;

     begin


    -- Create view for APPEND mode
    IF pi_IMPORT_MODE = 2 THEN
      v_OBJECT_NAME     :=SUBSTR(pi_DATA_TABLE, 0, 5) || '_VIEW' ||SUBSTR(pi_DATA_TABLE, -5, 5);

      v_KEY_COLS := 'ROW_ID, ' || pi_KEY_FIELDS || ',' || pi_START_DATE_FIELD || ',' || pi_END_DATE_FIELD;

      v_CREATE_VIEW_STR := ' CREATE VIEW ' || v_OBJECT_NAME || ' AS SELECT ' || v_KEY_COLS ||
                           ' FROM ' || pi_DATA_TABLE ||
                           ' UNION ALL SELECT ' || v_KEY_COLS || ' FROM ' || pi_DUMP_TABLE;



     v_DROP_VIEW_STR:='DROP VIEW '||v_OBJECT_NAME;
      commons_ddl_handling.execute_ddl_nolog(v_CREATE_VIEW_STR);


      v_VIEW_CREATED := TRUE;
    END IF;

    -- INSERT mode
    IF pi_IMPORT_MODE = 1 THEN
      v_OBJECT_NAME := pi_DUMP_TABLE;
    END IF;

  v_KEY_COLS := pi_KEY_FIELDS || ',';

      -- Create the string v_JOIN_CONDITION (logic to parse comma separated pi_KEY_FIELDS)
      FOR i IN 1 .. REGEXP_COUNT(v_KEY_COLS, ',')
      LOOP
          SELECT regexp_substr(v_KEY_COLS, '[^,]+', 1, i) INTO v_FIELDS FROM DUAL;

          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( A.' || v_FIELDS || ' = B.' || v_FIELDS || ') OR (A.'||v_FIELDS|| ' IS NULL AND B.'||v_FIELDS||' IS NULL )) AND';
      END LOOP;

      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION, 1, LENGTH(v_JOIN_CONDITION) - 4);

      -- Overlap and date check
      v_OVERLAP_STR := ' SELECT MIN(DT_CHECK) FROM (' ||
                     ' SELECT CASE ' ||
                     ' WHEN ((nvl(A.' || pi_START_DATE_FIELD ||',to_date(''1/1/1900'', ''dd/mm/yyyy''))'||
                     ' BETWEEN  nvl(B.' || pi_START_DATE_FIELD ||',to_date(''1/1/1900'', ''dd/mm/yyyy'')) '||
                     ' AND nvl(B.' || pi_END_DATE_FIELD ||',to_date(''31/12/9999'', ''dd/mm/yyyy'')))'||
                     ' OR (nvl(A.' || pi_END_DATE_FIELD ||',to_date(''31/12/9999'', ''dd/mm/yyyy''))' ||
                     ' BETWEEN nvl(B.' || pi_START_DATE_FIELD ||',to_date(''1/1/1900'', ''dd/mm/yyyy''))' ||
                     ' AND nvl(B.' || pi_END_DATE_FIELD || ',to_date(''31/12/9999'', ''dd/mm/yyyy'')))) ' ||
                     ' AND NOT(A.ROW_ID = B.ROW_ID) THEN 100 ' ||
                     ' WHEN A.' || pi_START_DATE_FIELD || ' > A.' || pi_END_DATE_FIELD || ' THEN 200 ' ||
                     ' ELSE 150 END AS DT_CHECK FROM ' || v_OBJECT_NAME ||
                     ' A INNER JOIN ' || v_OBJECT_NAME  || ' B ' || ' ON ' || v_JOIN_CONDITION || ') SUB_Q';

     \* ----dbms_output.put_line(v_OVERLAP_STR);*\
      EXECUTE IMMEDIATE v_OVERLAP_STR INTO V_OVERLAP_RESULT;


      -- Overlap check
      IF V_OVERLAP_RESULT = 100 THEN po_OVERLAP_CHK_RES := 0;
        ELSE po_OVERLAP_CHK_RES := 1;
      END IF;

  commons_ddl_handling.execute_ddl_nolog(v_DROP_VIEW_STR);

     EXCEPTION

     WHEN OTHERS THEN
       IF (V_VIEW_CREATED) THEN
      commons_ddl_handling.execute_ddl_nolog(v_DROP_VIEW_STR);
       END IF;




    end DI_OVERLAP_CHECK;*/

  /*PROCEDURE DI_DATE_RANGE_CHECK(    pi_DATA_TABLE       IN VARCHAR2,
                                                                 pi_DUMP_TABLE       IN VARCHAR2,
                                                                 pi_IMPORT_MODE      IN NUMBER,
                                                                 pi_KEY_FIELDS       IN CLOB,
                                                                 pi_START_DATE_FIELD IN VARCHAR2,
                                                                 pi_END_DATE_FIELD   IN VARCHAR2,

                                                                 po_DATE_RANGE_RES   OUT NUMBER
                                                                ) IS


         v_KEY_COLS        CLOB := '';
         v_OBJECT_NAME     VARCHAR2(30) := '';
         v_CREATE_VIEW_STR VARCHAR2(1300) := '';
         v_DROP_VIEW_STR VARCHAR2(1300) := '';

         v_NULL_CONDITION  VARCHAR2(250) := '';
          v_NULL_RESULT  NUMBER(1);
          v_EFF_CONDITION  VARCHAR2(250) := '';
          v_EFF_RESULT  NUMBER(1);

         v_VIEW_CREATED    BOOLEAN := FALSE;




     begin


    -- Create view for APPEND mode
    IF pi_IMPORT_MODE = 2 THEN
      v_OBJECT_NAME     :=SUBSTR(pi_DATA_TABLE, 0, 5) || '_VIEW' ||SUBSTR(pi_DATA_TABLE, -5, 5);

      v_KEY_COLS := 'ROW_ID, ' || pi_KEY_FIELDS || ',' || pi_START_DATE_FIELD || ',' || pi_END_DATE_FIELD;

     v_CREATE_VIEW_STR := ' CREATE OR REPLACE VIEW ' || v_OBJECT_NAME || ' AS SELECT ' || v_KEY_COLS ||
                           ' FROM ' || pi_DATA_TABLE ||
                           ' UNION ALL SELECT ' || v_KEY_COLS || ' FROM ' || pi_DUMP_TABLE;



     v_DROP_VIEW_STR:='DROP VIEW '||v_OBJECT_NAME;
      commons_ddl_handling.execute_ddl_nolog(v_CREATE_VIEW_STR);

      v_VIEW_CREATED := TRUE;
    END IF;

    -- INSERT mode
    IF pi_IMPORT_MODE = 1 THEN
      v_OBJECT_NAME := pi_DUMP_TABLE;
    END IF;

  v_NULL_CONDITION:='SELECT COUNT(*) FROM DUAL WHERE EXISTS
  (SELECT * FROM '||v_OBJECT_NAME|| ' WHERE '|| pi_START_DATE_FIELD||' IS NULL)';
   ----dbms_output.put_line(v_NULL_CONDITION);
  EXECUTE IMMEDIATE v_NULL_CONDITION into v_NULL_RESULT;

  IF(v_NULL_RESULT=0) THEN

  v_EFF_CONDITION:='SELECT COUNT(*) FROM DUAL WHERE EXISTS
  (SELECT * FROM '||v_OBJECT_NAME||' WHERE '|| pi_START_DATE_FIELD||' > NVL('|| pi_END_DATE_FIELD||',to_date(''31/12/9999'', ''dd/mm/yyyy'')))';
   ----dbms_output.put_line(v_EFF_CONDITION);
  EXECUTE IMMEDIATE v_EFF_CONDITION into v_EFF_RESULT;

  IF (v_EFF_RESULT=0) THEN

  po_DATE_RANGE_RES:=1;

  ELSIF  (v_EFF_RESULT=1 )THEN

  po_DATE_RANGE_RES:=0;

  END IF;

  ELSIF (v_NULL_RESULT=1 )THEN

  po_DATE_RANGE_RES:=0;
  END IF;


  commons_ddl_handling.execute_ddl_nolog(v_DROP_VIEW_STR);

     EXCEPTION

     WHEN OTHERS THEN
       IF (V_VIEW_CREATED) THEN
      commons_ddl_handling.execute_ddl_nolog(v_DROP_VIEW_STR);
       END IF;


  END DI_DATE_RANGE_CHECK;*/

  PROCEDURE DI_ENTITY_CHECK(pi_DUMP_TABLE    IN VARCHAR2,
                            pi_ENTITY_FIELDS IN CLOB,
                            po_ENTITY_RES    OUT varchar2) IS

    v_KEY_COLS       CLOB;
    v_FIELDS         VARCHAR2(30);
    v_NULL_RESULT    NUMBER;
    v_NULL_CONDITION VARCHAR2(1300);
  BEGIN
    v_KEY_COLS := pi_ENTITY_FIELDS || ',';

    -- Create the string v_JOIN_CONDITION (logic to parse comma separated pi_KEY_FIELDS)
    FOR i IN 1 .. REGEXP_COUNT(v_KEY_COLS, ',') LOOP
      SELECT regexp_substr(v_KEY_COLS, '[^,]+', 1, i)
        INTO v_FIELDS
        FROM DUAL;
      v_NULL_CONDITION := 'SELECT COUNT(*) FROM DUAL WHERE EXISTS
(SELECT * FROM ' || pi_DUMP_TABLE || ' WHERE ' ||
                          v_FIELDS || ' = -1)';

      --dbms_output.put_line(v_NULL_CONDITION);
      EXECUTE IMMEDIATE v_NULL_CONDITION
        into v_NULL_RESULT;

      IF (v_NULL_RESULT = 1) THEN

        po_ENTITY_RES := po_ENTITY_RES || v_FIELDS || ',';

      END IF;

    END LOOP;
    po_ENTITY_RES := SUBSTR(po_ENTITY_RES, 1, LENGTH(po_ENTITY_RES) - 1);
    ----dbms_output.put_line(v_FIELDS);

  END;

  PROCEDURE DI_PERIOD_CHECK(pi_DUMP_TABLE    IN VARCHAR2,
                            pi_period_FIELDS IN CLOB,
                            po_PERIOD_RES    OUT varchar2) IS

    v_FIELDS         VARCHAR2(30);
    v_NULL_RESULT    NUMBER;
    v_NULL_CONDITION VARCHAR2(1300);
    v_KEY_COLS       clob := pi_period_FIELDS || ',';
  BEGIN
    /*  po_PERIOD_RES := 0;*/

    FOR i IN 1 .. REGEXP_COUNT(v_KEY_COLS, ',') LOOP
      SELECT regexp_substr(v_KEY_COLS, '[^,]+', 1, i)
        INTO v_FIELDS
        FROM DUAL;
      v_NULL_CONDITION := 'SELECT COUNT(*) FROM DUAL WHERE EXISTS
(SELECT * FROM ' || pi_DUMP_TABLE || ' WHERE ' ||
                          v_FIELDS || ' = -1)';

      EXECUTE IMMEDIATE v_NULL_CONDITION
        into v_NULL_RESULT;

      IF (v_NULL_RESULT = 1) THEN

        po_PERIOD_RES := po_PERIOD_RES || v_FIELDS || ',';

      END IF;

    END LOOP;

    po_PERIOD_RES := SUBSTR(po_PERIOD_RES, 1, LENGTH(po_PERIOD_RES) - 1);
    ----dbms_output.put_line(v_FIELDS);

  END DI_PERIOD_CHECK;

    PROCEDURE DI_OBJECT_CHECK(pi_DUMP_TABLE IN VARCHAR2,
                            pi_FIELDS     IN CLOB,
                            po_RES        OUT varchar2) IS
  begin
    DI_PERIOD_CHECK(pi_DUMP_TABLE    => pi_DUMP_TABLE,
                    pi_period_FIELDS => pi_FIELDS,
                    po_PERIOD_RES    => po_RES);

  end;


-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END commons_dataimport;
/
