CREATE PACKAGE UNLOADER AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			  : SPM
-- Module			    : COMMONS
-- Requester		  : Luca Alexandra
-- Author			    : Lazar Lucian
-- Reviewer			  : Filip Catalin
-- Review date		: 2 Jun 2014
-- Description		: Exports a list of tables with or without the tehnical columns / all tables / all metric tables to CSV.
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
	function run( p_query      in varchar2 default NULL,
                  p_cols       in varchar2 default '*',
                  p_town       in varchar2 default USER,
                  p_tname      in varchar2,
                  p_mode       in varchar2 default 'REPLACE',
                  p_dir        in varchar2,
                  p_filename   in varchar2,
                  p_separator  in varchar2 default ',',
                  p_enclosure  in varchar2 default '"',
                  p_terminator in varchar2 default '|',
                  p_ctl        in varchar2 default 'YES',
                  p_header     in varchar2 default 'NO',
                  p_order      in varchar2 default null )
    return number;
    --
    function run( p_query      in varchar2 default NULL,
                  p_cols       in varchar2 default '*',
                  p_town       in varchar2 default USER,
                  p_tname      in varchar2,
                  p_mode       in varchar2 default 'REPLACE',
                  p_dbdir      in varchar2,
                  p_filename   in varchar2,
                  p_separator  in varchar2 default ',',
                  p_enclosure  in varchar2 default '"',
                  p_terminator in varchar2 default '|',
                  p_ctl        in varchar2 default 'YES',
                  p_header     in varchar2 default 'NO',
                  p_order      in varchar2 default null )
    return number;
    --
    function remove( p_dbdir      in varchar2,
                     p_filename   in varchar2)
    return number;
    --
-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************
 PROCEDURE version;
    --
    PROCEDURE help;
    --
    -- Description:
    -- This procedure creates backup tables for all the tables containing timestamp columns with those columns as varchar
    -- Running the all_tables_to_csv procedure afterwards will generate csv files with the data from the timestamp columns in the right order
    -- Call example
    -- begin
    --   unloader.prepare_timestamp_columns;
    -- end;
    --
    PROCEDURE prepare_timestamp_columns;
    --
    -- Description:
    -- This procedure exports a list of tables from a given schema as CSV files on a given path
    -- Parameters:
    -- pin_schema - schema name
    -- pin_dbdir  - database directory name
    -- pin_tables - list of tables to be exported
    -- Call example
    -- begin
    --  unloader.tables_to_csv('FLORI_SPM',
    --                         'FLORI_SPM_PDIR',
    --                         TABLETYPE_INPUT_TABLE_LIST(OBJTYPE_INPUT_TABLE_LIST('T337934','C1,C2,C3',NULL,NULL,NULL),
    --                                           OBJTYPE_INPUT_TABLE_LIST('T338024','C1',NULL,NULL,NULL)
    --                                           )
    --                          );
    -- end;
    --
    PROCEDURE tables_to_csv(pin_schema VARCHAR2,
                            pin_dbdir  VARCHAR2,
                            pin_tables TABLETYPE_INPUT_TABLE_LIST);
    --
    -- Description:
    -- This procedure exports a list of tables from a given schema as CSV files on a given path excluding a list of columns: ROW_IDENTIFIER, ROW_VERSION, AUDIT_ID
    -- Parameters:
    -- pin_schema - schema name
    -- pin_dbdir  - database directory name
    -- pin_tables - list of tables to be exported
    -- Call example
    -- begin
    --  unloader.tables_to_csv_no_tech_col('FLORI_SPM',
    --                                     'FLORI_SPM_PDIR',
    --                                     TABLETYPE_INPUT_TABLE_LIST(OBJTYPE_INPUT_TABLE_LIST('T337934','C1,C2',NULL,NULL,NULL),
    --                                                       OBJTYPE_INPUT_TABLE_LIST('T338024', NULL,NULL,NULL,NULL)
    --                                                       )
    --                                      );
    -- end;
    --
    PROCEDURE tables_to_csv_no_tech_col(pin_schema VARCHAR2,
                                        pin_dbdir  VARCHAR2,
                                        pin_tables TABLETYPE_INPUT_TABLE_LIST);
    --
    -- Description:
    -- This procedure exports all the tables from a given schema as CSV files on a given path excluding a list of columns: ROW_IDENTIFIER, ROW_VERSION
    -- Parameters:
    -- pin_schema - schema name
    -- pin_dbdir  - database directory name
    -- pin_tables - list of tables to be exported
    -- Call example
    -- begin
    --  unloader.all_tables_to_csv('FLORI_SPM',
    --                             'FLORI_SPM_PDIR',
    --                             );
    -- end;
    --
    PROCEDURE all_tables_to_csv(pin_schema VARCHAR2,
                                pin_dbdir  VARCHAR2);

    PROCEDURE metric_tables_to_csv(pin_schema VARCHAR2,
                                   pin_dbdir  VARCHAR2);

-- *******************************    PUBLIC PROCEDURES END         *******************************
END UNLOADER;
/
