CREATE PACKAGE FIXUIDPK AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product		: central
-- Module		: central
-- Requester		: Cozac, Tudor
-- Author		: Lazarescu, Bogdan
-- Reviewer		:
-- Review date		:
-- Description		:  package used to give new uid ids to records from another schema during restore in existing schema
-- ---------------------------------------------------------------------------
		-- *******************************    PUBLIC TYPES START       *******************************
TYPE id_list IS TABLE OF NUMBER INDEX BY VARCHAR2(16);
		-- *******************************    PUBLIC TYPES END         *******************************

		-- *******************************    PUBLIC CURSORS START       *******************************
		-- *******************************    PUBLIC CURSORS END         *******************************

		-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
id_remaps id_list;
		-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

		-- *******************************    PUBLIC FUNCTIONS START       *******************************
FUNCTION newuidpk (olduidpk IN NUMBER) RETURN NUMBER;
		-- *******************************    PUBLIC FUNCTIONS END         *******************************

		-- *******************************    PUBLIC PROCEDURES START       *******************************
		-- *******************************    PUBLIC PROCEDURES END         *******************************
END FIXUIDPK;
/
