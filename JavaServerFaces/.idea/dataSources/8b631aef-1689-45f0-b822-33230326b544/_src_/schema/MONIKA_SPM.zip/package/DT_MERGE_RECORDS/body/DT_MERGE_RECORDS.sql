CREATE PACKAGE BODY DT_MERGE_RECORDS AS

/* GET_TABLE_COLUMNS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_COLUMNS
(   pin_table_id IN NUMBER
) RETURN TABLETYPE_DT_MR_COL_PROPS
IS
    vtab_cols TABLETYPE_DT_MR_COL_PROPS;
BEGIN
    SELECT OBJTYPE_DT_MR_COL_PROPS
    (        TC1.TC_PHYSICAL_NAME
            ,TC1.TC_ORDER
            ,TC1.TC_COLUMN_TYPE
            ,TC1.TC_ENTITY_ID
            ,TABLES_PHYSICAL_NAME
            ,TC2.TC_PHYSICAL_NAME
            ,F2.FLD_DATA_TYPE
            ,TC1.TC_FLD_ID
            ,F1.FLD_DATA_TYPE
            ,F1.FLD_TIMEUNIT
            ,TC1.TC_IS_NULLABLE
            ,TC1.TC_DEF_TYPE_ID
    )
    BULK COLLECT INTO vtab_cols
    FROM    TABLE_COLUMNS               TC1
            LEFT JOIN FIELDS            F1 ON TC1.TC_FLD_ID = F1.FLD_ID
            LEFT JOIN ENTITIES          ON TC1.TC_ENTITY_ID = ENTITY_ID
            LEFT JOIN TABLES            ON ENTITY_TABLES_ID = TABLES_ID
            LEFT JOIN TABLE_COLUMNS     TC2 ON ENTITY_TABLES_ID = TC2.TC_TABLES_ID AND TC2.TC_LOGIC_TYPE IN (1,5)
            LEFT JOIN FIELDS            F2 ON TC2.TC_FLD_ID = F2.FLD_ID
    WHERE   TC1.TC_TABLES_ID = pin_table_id;

    RETURN vtab_cols;
END GET_TABLE_COLUMNS;


/* GET_TABLE_NAME
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_NAME
(   pin_table_id IN NUMBER
) RETURN VARCHAR2
IS
    v_tab VARCHAR2(200);
BEGIN
    SELECT TABLES_PHYSICAL_NAME
    INTO v_tab
    FROM TABLES
    WHERE TABLES_ID = pin_table_id;

    RETURN v_tab;
END GET_TABLE_NAME;


/* GET_TABLE_SEQUENCE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_SEQUENCE
(   pin_table_id IN NUMBER
) RETURN VARCHAR2
IS
    v_seq VARCHAR2(200);
BEGIN
    SELECT TABLES_PHYSICAL_NAME||'_ROW_IDENTIFIER_SEQ'
    INTO v_seq
    FROM TABLES
    WHERE TABLES_ID = pin_table_id;

    RETURN v_seq;
END GET_TABLE_SEQUENCE;


/* GET_TABLE_ID_BY_REF
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_ID_BY_REF
(   pin_table_ref_id IN NUMBER
) RETURN NUMBER
IS
    v_tab_id NUMBER;
BEGIN
    SELECT  T.TABLES_ID
    INTO    v_tab_id
    FROM    TABLE_REFERENCES TR
            LEFT JOIN
            (   SELECT   OBR.OR_ID
                        ,OBR.OR_NAME
                        ,CR.CR_PARENT_DEFINITION_ID
                FROM    OBJECT_REGISTRATION OBR
                        INNER JOIN CATEGORY_RELATIONSHIPS CR ON CR.CR_DEFINITION_ID = OBR.OR_ID
            ) ORC ON ORC.OR_NAME = TR.TREF_DEFINITION_NAME
                    AND ORC.CR_PARENT_DEFINITION_ID = TR.TREF_PARENT_DEFINITION_ID
            LEFT JOIN TABLES T ON NVL(T.TABLES_DEFINITION_ID,T.TABLES_ID) = NVL(TR.TREF_DEFINITION_ID,ORC.OR_ID)
    WHERE   TR.TREF_ID = pin_table_ref_id;

    RETURN v_tab_id;
END GET_TABLE_ID_BY_REF;


/* GET_OPERATION_INPUTS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_OPERATION_INPUTS
(    pin_definition_id          IN NUMBER
    ,pin_processing_date        IN DATE
    ,pin_processing_period      IN NUMBER
    ,pin_run_type               IN NUMBER
) RETURN TABLETYPE_DT_MR_OP_INPUTS
IS
    vtab_inputs TABLETYPE_DT_MR_OP_INPUTS;
BEGIN
    SELECT  OBJTYPE_DT_MR_OP_INPUTS
    (        I.DTIN_ID
            ,I.DTIN_ORDER
            ,CASE   WHEN I.DTIN_TREF_ID IS NOT NULL THEN 0
                    ELSE 1 END -- 0 - TABLE; 1 - OPERATION_RESULT_TABLE
            ,I.DTIN_DTOUT_ID
            ,CASE   WHEN I.DTIN_TREF_ID IS NOT NULL THEN DT_MERGE_RECORDS.GET_TABLE_ID_BY_REF(I.DTIN_TREF_ID)
                    WHEN pin_run_type = 0 AND RT0.DTRT_TABLES_ID IS NOT NULL THEN RT0.DTRT_TABLES_ID
                    WHEN pin_run_type = 1 AND RT1.DTRT_TABLES_ID IS NOT NULL THEN RT1.DTRT_TABLES_ID
                    ELSE COALESCE(RT0.DTRT_TABLES_ID, RT1.DTRT_TABLES_ID) END
            ,CASE   WHEN I.DTIN_FILTER_ENABLED = 1 THEN I.DTIN_FILTER_ID
                    ELSE NULL END
    )
    BULK COLLECT INTO vtab_inputs
    FROM    DT_INPUTS                       I
            LEFT JOIN DT_RESULT_TABLES      RT0 ON I.DTIN_DTOUT_ID = RT0.DTRT_DTOUT_ID
                                                AND (pin_processing_date IS NULL OR RT0.DTRT_RUN_DATE = pin_processing_date)
                                                AND (pin_processing_period IS NULL OR RT0.DTRT_PERIOD_ID = pin_processing_period)
                                                AND RT0.DTRT_IS_FROM_JOB = 0
            LEFT JOIN DT_RESULT_TABLES      RT1 ON I.DTIN_DTOUT_ID = RT1.DTRT_DTOUT_ID
                                                AND (pin_processing_date IS NULL OR RT1.DTRT_RUN_DATE = pin_processing_date)
                                                AND (pin_processing_period IS NULL OR RT1.DTRT_PERIOD_ID = pin_processing_period)
                                                AND RT1.DTRT_IS_FROM_JOB = 1
    WHERE   I.DTIN_DTO_ID = pin_definition_id
    ORDER BY I.DTIN_ORDER;

    RETURN vtab_inputs;
END GET_OPERATION_INPUTS;


/* GET_COLUMN_MAPPINGS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.22 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_COLUMN_MAPPINGS
(    pin_output_cols    IN TABLETYPE_DT_MR_COL_PROPS
    ,pin_op_inputs      IN TABLETYPE_DT_MR_OP_INPUTS
) RETURN TABLETYPE_DT_MR_COL_MAP_LIST
IS
    vtab_col_map TABLETYPE_DT_MR_COL_MAP_LIST;
BEGIN
    SELECT OBJTYPE_DT_MR_COL_MAP_LIST
    (    RC.RESCOL_NAME
        ,RC.INPUT_ID
        ,CASE   WHEN IC.INCOL_NAME IS NOT NULL AND RC.RESCOL_TYPE = 1 THEN 4
                WHEN IC.INCOL_NAME IS NOT NULL AND RC.RESCOL_TYPE = 2 THEN 3
                ELSE 1 END
        ,CASE   WHEN IC.INCOL_NAME IS NOT NULL THEN IC.INCOL_NAME
                ELSE NULL END
    )
    BULK COLLECT INTO vtab_col_map
    FROM    (   SELECT   RC.COL_NAME        RESCOL_NAME
                        ,RC.COL_ORDER       RESCOL_ORDER
                        ,RC.COL_TYPE        RESCOL_TYPE
                        ,I.INPUT_ID
                        ,I.INPUT_ORDER
                FROM    TABLE(pin_output_cols) RC
                        CROSS JOIN
                        TABLE(pin_op_inputs) I
                WHERE RC.COL_TYPE IN (1, 2)
            ) RC
            LEFT JOIN
            (   SELECT   I.INPUT_ID
                        ,IC.COL_NAME INCOL_NAME
                FROM    TABLE(pin_op_inputs) I
                        ,TABLE(DT_MERGE_RECORDS.GET_TABLE_COLUMNS(I.INPUT_TABLE_ID)) IC
            ) IC ON RC.INPUT_ID = IC.INPUT_ID AND RC.RESCOL_NAME = IC.INCOL_NAME
    ORDER BY RC.INPUT_ORDER, RC.RESCOL_ORDER;

    RETURN vtab_col_map;
END GET_COLUMN_MAPPINGS;


/* GET_EQUAL_MATCH_CONDITION
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.12.10 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_EQUAL_MATCH_CONDITION
(    pin_left_member        IN CLOB
    ,pin_right_member       IN CLOB
    ,pin_members_col_type   IN NUMBER
    ,pin_members_data_type  IN NUMBER
) RETURN CLOB
IS
    v_condition CLOB;
BEGIN
    -- members can be column names or expressions:
    -- E450.F7898
    -- 31
    -- NULL
    -- TO_DATE('31/12/2012', 'DD/MM/YYYY')
    IF (pin_left_member = 'NULL' AND pin_right_member = 'NULL')
    THEN
        v_condition := '(1 = 1)';
    ELSIF (pin_left_member = 'NULL')
    THEN
        v_condition := '('||pin_right_member||' IS NULL)';
    ELSIF (pin_right_member = 'NULL')
    THEN
        v_condition := '('||pin_left_member||' IS NULL)';
    ELSE
        -- entity
        IF (pin_members_col_type = 1)
        THEN
            v_condition := '(NVL('||pin_left_member||', -1) = NVL('||pin_right_member||', -1))';
        -- boolean or period
        ELSIF (pin_members_data_type IN (2, 8))
        THEN
            v_condition := '(NVL('||pin_left_member||', -1) = NVL('||pin_right_member||', -1))';
        --character or note
        ELSIF (pin_members_data_type IN (1, 4))
        THEN
            v_condition := '(NVL(UPPER('||pin_left_member||'), CHR(0)) = NVL(UPPER('||pin_right_member||'), CHR(0)))';
        -- date
        ELSIF (pin_members_data_type = 3)
        THEN
            v_condition := '(NVL('||pin_left_member||', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) = NVL('||pin_right_member||', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')))';
        -- datetime
        ELSIF (pin_members_data_type = 5)
        THEN
            v_condition := '(NVL('||pin_left_member||', TO_TIMESTAMP(''01/01/1800 00:00:00'', ''DD/MM/YYYY HH24:MI:SS'')) = NVL('||pin_right_member||', TO_TIMESTAMP(''01/01/1800 00:00:00'', ''DD/MM/YYYY HH24:MI:SS'')))';
        -- numeric
        ELSIF (pin_members_data_type = 6)
        THEN
            v_condition := '(NVL('||pin_left_member||', 1E38) = NVL('||pin_right_member||', 1E38))';
        -- anything else
        ELSE
            v_condition := '('||pin_left_member||' = '||pin_right_member||' OR ('||pin_left_member||' IS NULL AND '||pin_right_member||' IS NULL))';
        END IF;
    END IF;

    RETURN v_condition;
END GET_EQUAL_MATCH_CONDITION;


/* GET_TUPR_BY_DATE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.22 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TUPR_BY_DATE
(    pin_timeunit_id    IN NUMBER
    ,pin_date           IN DATE
) RETURN NUMBER
IS
    v_period NUMBER;
BEGIN
    SELECT TUPR_ID
    INTO v_period
    FROM TU_PERIODS_RANGE
    WHERE TUPR_TU_ID = pin_timeunit_id
        AND pin_date BETWEEN TUPR_START_DATE AND TUPR_END_DATE;

    RETURN v_period;
END GET_TUPR_BY_DATE;


/* GET_TUPR_BY_CORR_TUPR
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.22 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TUPR_BY_CORR_TUPR
(    pin_timeunit_id    IN NUMBER
    ,pin_tupr_id        IN NUMBER
) RETURN NUMBER
IS
    v_tupr_timeunit     NUMBER;
    v_period            NUMBER;
BEGIN
    SELECT  TUPR_TU_ID
    INTO    v_tupr_timeunit
    FROM    TU_PERIODS_RANGE
    WHERE   TUPR_ID = pin_tupr_id;

    IF (v_tupr_timeunit = pin_timeunit_id)
    THEN
        v_period := pin_tupr_id;
    ELSE
        SELECT  TUPR_TPC.TUPR_ID
        INTO    v_period
        FROM    TU_PERIODS_RANGE TUPR_TP
                LEFT JOIN
                (   SELECT   TUPC_CORRESPONDENCE_TYPE
                            ,TUPC_TUP_ID
                            ,TUPC_TUP_ID_CORR
                            ,TUPC_PERIOD_NUMBER
                            ,TUPC_PERIOD_NUMBER_CORR
                            ,TUPC_YEAR_OFFSET
                    FROM    TU_CORRESPONDENCE
                            INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
                    WHERE   TUC_TU_ID = v_tupr_timeunit
                            AND TUC_TU_ID_CORR = pin_timeunit_id
                ) TUPC ON (TUPC.TUPC_CORRESPONDENCE_TYPE = 1 AND TUPR_TP.TUPR_TUP_ID = TUPC.TUPC_TUP_ID)
                        OR (TUPC.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_TP.TUPR_PERIOD_NUMBER = TUPC.TUPC_PERIOD_NUMBER)
                LEFT JOIN TU_PERIODS_RANGE TUPR_TPC ON (    (TUPC.TUPC_CORRESPONDENCE_TYPE = 1 AND TUPC.TUPC_TUP_ID_CORR = TUPR_TPC.TUPR_TUP_ID)
                                                        OR (TUPC.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_TPC.TUPR_TU_ID = pin_timeunit_id AND TUPC.TUPC_PERIOD_NUMBER_CORR = TUPR_TPC.TUPR_PERIOD_NUMBER))
                           AND CASE WHEN TUPC.TUPC_YEAR_OFFSET = 1 THEN TUPR_TP.TUPR_YEAR - 1
                                    WHEN TUPC.TUPC_YEAR_OFFSET = 2 THEN TUPR_TP.TUPR_YEAR
                                    WHEN TUPC.TUPC_YEAR_OFFSET = 3 THEN TUPR_TP.TUPR_YEAR + 1
                                    ELSE NULL END = TUPR_TPC.TUPR_YEAR
        WHERE   TUPR_TP.TUPR_ID = pin_tupr_id;
    END IF;

    RETURN v_period;
END GET_TUPR_BY_CORR_TUPR;


/* GET_ENTITY_BK_VALUE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.23 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ENTITY_BK_VALUE
(    pin_ent_tab_name   IN VARCHAR2
    ,pin_ent_bk_col     IN VARCHAR2
    ,pin_ent_id         IN NUMBER
) RETURN VARCHAR2
IS
    v_ent_value VARCHAR2(200);
BEGIN
    EXECUTE IMMEDIATE 'SELECT TO_CHAR('||pin_ent_bk_col||') FROM '||pin_ent_tab_name||' WHERE E_INTERNAL_ID = :1'
    INTO v_ent_value
    USING pin_ent_id;

    RETURN v_ent_value;
END GET_ENTITY_BK_VALUE;


/* GET_TUPR_NAME
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.23 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TUPR_NAME
(    pin_tupr_id IN NUMBER
) RETURN VARCHAR2
IS
    v_tupr_name VARCHAR2(200);
BEGIN
    SELECT TUPR_PERIOD_RANGE_NAME
    INTO v_tupr_name
    FROM TU_PERIODS_RANGE
    WHERE TUPR_ID = pin_tupr_id;

    RETURN v_tupr_name;
END GET_TUPR_NAME;


/* RUN_MERGE_RECORDS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2012.10.17 - Dumitriu, Cosmin - created
    2012.12.05 - Dumitriu, Cosmin - added pin_flashback_scn and the required functionality
    2013.01.16 - Dumitriu, Cosmin - changed pin_filters in order to include period filter joins
    2014.09.12 - Dumitriu, Cosmin - changed the way we get the result/output table id - received by parameter instead of being calculated
-----------------------------------------------------------------------------------------------
*/
PROCEDURE RUN_MERGE_RECORDS
(    pin_definition_id          IN NUMBER
    ,pin_processing_date        IN DATE
    ,pin_processing_period      IN NUMBER
    ,pin_run_type               IN NUMBER
    ,pin_result_table_id        IN NUMBER
    ,pin_filters                IN TABLETYPE_DT_MR_FILTER_LIST
    ,pin_column_mappings        IN TABLETYPE_DT_MR_COL_MAP_LIST
    ,pin_flashback_scn          IN NUMBER
    ,pout_insert_rowcount       OUT NUMBER
    ,pout_vld_results           OUT SYS_REFCURSOR
) IS
    TYPE TREC_MATCH_COLS IS RECORD(  COL_NAME       VARCHAR2(200)
                                    ,COL_DATA_TYPE  NUMBER(10));

    TYPE TCOL_MATCH_COLS IS TABLE OF TREC_MATCH_COLS INDEX BY VARCHAR2(200);

    TYPE TREC_INPUT_CLAUSES IS RECORD(   INPUT_ID       NUMBER(10)
                                        ,SELECT_STR     CLOB
                                        ,FROM_STR       CLOB
                                        ,WHERE_STR      CLOB
                                        ,QUERY_STR      CLOB
                                        ,MATCH_COLS     TCOL_MATCH_COLS);

    TYPE TCOL_INPUT_CLAUSES IS TABLE OF TREC_INPUT_CLAUSES INDEX BY PLS_INTEGER;

    v_output_id                 NUMBER;
    v_output_table_id           NUMBER;
    v_output_table_name         VARCHAR2(250);
    v_output_table_seq          VARCHAR2(250);
    v_output_flt_where_clause   CLOB;
    v_output_flt_from_clause    CLOB;
    v_output_flt_entities       TABLETYPE_DT_NUMBER;
    v_output_cols               TABLETYPE_DT_MR_COL_PROPS;
    v_op_included_recs          NUMBER;
    v_op_col_mappings           TABLETYPE_DT_MR_COL_MAP_LIST;
    v_op_inputs                 TABLETYPE_DT_MR_OP_INPUTS;
    v_op_inputs_card_in         TABLETYPE_DT_OP_INPUTS;
    v_op_inputs_card_out        TABLETYPE_DT_OP_INPUTS_CARD;

    v_outer_ins_col_list        CLOB;
    v_outer_ins_sel_list        CLOB;
    v_outer_vld_sel_list        CLOB;
    v_outer_vld_when_clause     CLOB;

    v_input_cols                TABLETYPE_DT_MR_COL_PROPS;
    v_input_clauses             TREC_INPUT_CLAUSES;
    v_sql_clauses               TCOL_INPUT_CLAUSES;
    v_match_value               CLOB;
    v_sel_value                 CLOB;

    v_idx1                      PLS_INTEGER;
    v_idx2                      PLS_INTEGER;
    v_not_exists                CLOB;
    v_with_sql                  CLOB;
    v_sel_sql                   CLOB;
    v_ins_sql                   CLOB;
    v_vld_sql                   CLOB;
    v_insert_rowcount           NUMBER;
    v_save_sql_plan             PROPERTIES.PR_VALUE%TYPE;
    v_stamp                     VARCHAR2(250 CHAR);
BEGIN
    v_stamp := 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    v_save_sql_plan := NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('PROC_EXEC_PLAN_ENABLED'), 'TRUE');

    -- log the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_definition_id),       ',pin_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(pin_processing_date),       ',pin_processing_date => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_processing_period),   ',pin_processing_period => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_run_type),            ',pin_run_type => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_result_table_id),     ',pin_result_table_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_filters),         ',pin_filters => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_column_mappings), ',pin_column_mappings => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_flashback_scn),       ',pin_flashback_scn => <value>', v_stamp);
    END;

    -- get the output table details: table id and name, UI filter
    -- 2014.09.12 - Dumitriu, Cosmin - changed where clause
    SELECT   O.DTOUT_ID
            ,RT.DTRT_TABLES_ID
            ,DT_MERGE_RECORDS.GET_TABLE_NAME(RT.DTRT_TABLES_ID)
            ,DT_MERGE_RECORDS.GET_TABLE_SEQUENCE(RT.DTRT_TABLES_ID)
            ,FLT.WHERE_CLAUSE
            ,FLT.FROM_CLAUSE
            ,FLT.FILTER_ENTITIES
    INTO     v_output_id
            ,v_output_table_id
            ,v_output_table_name
            ,v_output_table_seq
            ,v_output_flt_where_clause
            ,v_output_flt_from_clause
            ,v_output_flt_entities
    FROM    DT_OUTPUTS                      O
            INNER JOIN DT_RESULT_TABLES     RT ON O.DTOUT_ID = RT.DTRT_DTOUT_ID
                                                AND RT.DTRT_IS_FROM_JOB = pin_run_type
                                                AND (pin_processing_date IS NULL OR RT.DTRT_RUN_DATE = pin_processing_date)
                                                AND (pin_processing_period IS NULL OR RT.DTRT_PERIOD_ID = pin_processing_period)
            LEFT JOIN TABLE(pin_filters)    FLT ON O.DTOUT_FILTER_ENABLED = 1 AND O.DTOUT_FILTER_ID = FLT.FILTER_ID
    WHERE   RT.DTRT_TABLES_ID = pin_result_table_id;

    -- get included records option
    SELECT DTMRD_REC_IN_RESULT
    INTO v_op_included_recs
    FROM DT_MERGE_RECORDS_DEF
    WHERE DTMRD_ID = pin_definition_id;

    -- get output table columns
    v_output_cols := DT_MERGE_RECORDS.GET_TABLE_COLUMNS(v_output_table_id);

    -- get all operation inputs
    v_op_inputs := DT_MERGE_RECORDS.GET_OPERATION_INPUTS(pin_definition_id => pin_definition_id
                                                        ,pin_processing_date => pin_processing_date
                                                        ,pin_processing_period => pin_processing_period
                                                        ,pin_run_type => pin_run_type);

    -- get input cardinality for operation outputs
    SELECT OBJTYPE_DT_OP_INPUTS
    (        I.INPUT_ID
            ,I.INPUT_OUTPUT_ID
            ,DT_MERGE_RECORDS.GET_TABLE_NAME(I.INPUT_TABLE_ID)
            ,'DTIN'||TO_CHAR(I.INPUT_ID)
    )
    BULK COLLECT INTO v_op_inputs_card_in
    FROM    TABLE(v_op_inputs) I
    WHERE   I.INPUT_TYPE = 1;

    DATA_TRANSFORMATION_PROCESSING.GET_INPUTS_CARDINALITY(pi_inputs => v_op_inputs_card_in
                                                         ,po_inputs_cardinality => v_op_inputs_card_out);

    -- get the column mappings
    IF (pin_column_mappings IS NOT NULL)
    THEN
        v_op_col_mappings := pin_column_mappings;
    ELSE
        v_op_col_mappings := DT_MERGE_RECORDS.GET_COLUMN_MAPPINGS(v_output_cols, v_op_inputs);
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(v_op_col_mappings), 'v_op_col_mappings := <value>;', v_stamp);

    -- for every column in the output table:
    --  * build the outer insert lists (destination cols and select cols)
    --  * build the outer validation lists (select cols)
    --  * modify the where clause for entity col filters and build the period col filter joins
    FOR c IN
    (   SELECT   RESCOL_NAME, RESCOL_ORDER, RESCOL_TYPE, RESCOL_ENTITY_ID, RESCOL_ENTITY_TAB_NAME, RESCOL_ENTITY_BK, RESCOL_ENTITY_BK_DTYPE
                ,RESCOL_FLD_ID, RESCOL_FLD_DATA_TYPE, RESCOL_FLD_TIMEUNIT, RESCOL_IS_NULLABLE
                ,RESCOL_ENT_HAS_FILTER, RESCOL_ENT_HAS_FIELD_MAPPING
        FROM    -- all output table columns
                (   SELECT   COL_NAME               RESCOL_NAME
                            ,COL_ORDER              RESCOL_ORDER
                            ,COL_TYPE               RESCOL_TYPE
                            ,COL_ENTITY_ID          RESCOL_ENTITY_ID
                            ,COL_ENTITY_TAB_NAME    RESCOL_ENTITY_TAB_NAME
                            ,COL_ENTITY_BK          RESCOL_ENTITY_BK
                            ,COL_ENTITY_BK_DTYPE    RESCOL_ENTITY_BK_DTYPE
                            ,COL_FLD_ID             RESCOL_FLD_ID
                            ,COL_FLD_DATA_TYPE      RESCOL_FLD_DATA_TYPE
                            ,COL_FLD_TIMEUNIT       RESCOL_FLD_TIMEUNIT
                            ,COL_IS_NULLABLE        RESCOL_IS_NULLABLE
                    FROM    TABLE(v_output_cols)
                ) RC

                -- check if any output table columns of type=entity have output filters defined on them
                LEFT JOIN
                (   SELECT   1                      RESCOL_ENT_HAS_FILTER
                            ,COLUMN_VALUE           COL_ENTITY_ID
                    FROM    TABLE(v_output_flt_entities)
                ) OFLTE ON RC.RESCOL_TYPE = 1 AND RC.RESCOL_ENTITY_ID = OFLTE.COL_ENTITY_ID

                -- check if any output table columns of type=entity have mapping to fields in any of the inputs
                LEFT JOIN
                (   SELECT DISTINCT
                             1                      RESCOL_ENT_HAS_FIELD_MAPPING
                            ,COLUMN_NAME            COL_NAME
                    FROM    TABLE(v_op_col_mappings)
                    WHERE   MAPPING_OPTION = 3
                ) EM ON RC.RESCOL_TYPE = 1 AND RC.RESCOL_NAME = EM.COL_NAME
        ORDER BY RC.RESCOL_ORDER)
    LOOP
        -- build the outer insert lists (destination cols and select cols)
        IF (c.RESCOL_TYPE = 1)
        THEN
            v_outer_ins_col_list := v_outer_ins_col_list
                ||CASE  WHEN v_outer_ins_col_list IS NULL THEN NULL ELSE ',' END
                ||c.RESCOL_NAME;

            v_outer_ins_sel_list := v_outer_ins_sel_list
                ||CASE  WHEN v_outer_ins_sel_list IS NULL THEN NULL ELSE ',' END
                ||CASE  WHEN c.RESCOL_ENT_HAS_FIELD_MAPPING = 1
                        THEN 'CASE WHEN 1/(CASE WHEN DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME||' IS NULL AND DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME||'_V IS NOT NULL THEN 0 ELSE 1 END)'
                                    ||' = 1 THEN DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME||' ELSE NULL END'
                        ELSE 'DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME END;
        ELSIF (c.RESCOL_TYPE = 2)
        THEN
            v_outer_ins_col_list := v_outer_ins_col_list
                ||CASE  WHEN v_outer_ins_col_list IS NULL THEN NULL ELSE ',' END
                ||c.RESCOL_NAME;

            v_outer_ins_sel_list := v_outer_ins_sel_list
                ||CASE  WHEN v_outer_ins_sel_list IS NULL THEN NULL ELSE ',' END
                ||'DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME;
        ELSIF (c.RESCOL_TYPE = 3)
        THEN
            v_outer_ins_col_list := v_outer_ins_col_list
                ||CASE  WHEN v_outer_ins_col_list IS NULL THEN NULL ELSE ',' END
                ||c.RESCOL_NAME;

            v_outer_ins_sel_list := v_outer_ins_sel_list
                ||CASE  WHEN v_outer_ins_sel_list IS NULL THEN NULL ELSE ',' END
                ||CASE  WHEN c.RESCOL_NAME = 'ROW_IDENTIFIER' THEN v_output_table_seq||'.NEXTVAL'
                        WHEN c.RESCOL_NAME = 'ROW_VERSION' THEN '0'
                        ELSE NULL END;
        END IF;

        -- build the outer validation lists (select cols)
        IF (c.RESCOL_TYPE = 1
            AND c.RESCOL_ENT_HAS_FIELD_MAPPING = 1)
        THEN
            v_outer_vld_sel_list := v_outer_vld_sel_list
                ||CASE WHEN v_outer_vld_sel_list IS NULL THEN NULL ELSE ',' END
                ||c.RESCOL_NAME
                ||','||c.RESCOL_NAME||'_V';
        END IF;

        -- replace in v_output_flt_where_clause: RESCOL_NAME.RESCOL_ENTITY_BK with DTOUT_.RESCOL_NAME_V
        -- if output filters exist on this entity, on columns other than the business key then we need to add entity table joins
        -- example:
        -- v_output_flt_where_clause = '((Filters_PR_428629114.TUPR_START_DATE > Filters_PR_713045778.TUPR_START_DATE) AND (E2691063.F2691018 > 30))'
        -- v_output_flt_from_clause = 'LEFT OUTER JOIN TU_PERIODS_RANGE Filters_PR_428629114 ON(E2691060.F2691007 = Filters_PR_428629114.TUPR_ID)
        --                             LEFT OUTER JOIN TU_PERIODS_RANGE Filters_PR_713045778 ON(DTOUT2691263.F2691007 = Filters_PR_713045778.TUPR_ID)'
        -- search in both clauses for E2691060.<something_else_than_BK>
        IF (c.RESCOL_ENT_HAS_FILTER = 1)
        THEN
            v_output_flt_where_clause := REGEXP_REPLACE(v_output_flt_where_clause, c.RESCOL_NAME||'.'||c.RESCOL_ENTITY_BK, 'DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME||'_V');

            IF (    -- after changing RESCOL_NAME.RESCOL_ENTITY_BK with DTOUT_.RESCOL_NAME_V you still have RESCOL_NAME. then do stuff
                    v_output_flt_where_clause LIKE '%'||c.RESCOL_NAME||'.%'
                OR  v_output_flt_from_clause LIKE '%'||c.RESCOL_NAME||'.%')
            THEN
                v_output_flt_from_clause := CASE WHEN c.RESCOL_IS_NULLABLE = 0 THEN 'INNER' ELSE 'LEFT' END
                    ||' JOIN '||c.RESCOL_ENTITY_TAB_NAME||' AS OF SCN :SCN '||c.RESCOL_NAME
                    ||' ON DTOUT'||TO_CHAR(v_output_id)||'.'||c.RESCOL_NAME||' = '||c.RESCOL_NAME||'.E_INTERNAL_ID'
                    ||' '||v_output_flt_from_clause;
            END IF;
        END IF;
    END LOOP;

    v_outer_vld_sel_list := v_outer_vld_sel_list
        ||CASE  WHEN v_outer_vld_sel_list IS NULL THEN NULL ELSE ',' END
        ||'INPUT_ID';

    -- for every input of the operation - build the inner clauses
    FOR c IN
    (   SELECT   I.INPUT_ID                                         INPUT_ID
                ,I.INPUT_ORDER                                      INPUT_ORDER
                ,I.INPUT_TYPE                                       INPUT_TYPE
                ,I.INPUT_TABLE_ID                                   INPUT_TABLE_ID
                ,DT_MERGE_RECORDS.GET_TABLE_NAME(I.INPUT_TABLE_ID)  INPUT_TABLE_NAME
                ,FLT.WHERE_CLAUSE                                   INPUT_FLT_WHERE_CLAUSE
                ,FLT.FROM_CLAUSE                                    INPUT_FLT_FROM_CLAUSE
                ,FLT.FILTER_ENTITIES                                INPUT_FLT_ENTITIES
                ,CRD.CARDINAL_HINT                                  INPUT_CARDINALITY
        FROM    TABLE(v_op_inputs)              I
                LEFT JOIN TABLE(pin_filters)    FLT ON I.INPUT_FILTER_ID = FLT.FILTER_ID
                LEFT JOIN TABLE(v_op_inputs_card_out) CRD ON I.INPUT_ID = CRD.INPUT_ID
        ORDER BY I.INPUT_ORDER)
    LOOP
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, '==============================', NULL, NULL, v_stamp);
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, c.INPUT_TABLE_NAME||' - '||c.INPUT_FLT_FROM_CLAUSE||' - '||c.INPUT_FLT_WHERE_CLAUSE, NULL, NULL, v_stamp);

        v_input_cols := DT_MERGE_RECORDS.GET_TABLE_COLUMNS(c.INPUT_TABLE_ID);
        v_input_clauses := NULL;
        v_input_clauses.INPUT_ID := c.INPUT_ID;
        v_input_clauses.FROM_STR := c.INPUT_TABLE_NAME||CASE WHEN c.INPUT_TYPE = 0 THEN ' AS OF SCN :SCN' ELSE NULL END||' DTIN'||TO_CHAR(c.INPUT_ID);
        v_input_clauses.WHERE_STR := c.INPUT_FLT_WHERE_CLAUSE;

        -- for every entity column with filters from the input table - build the from clause
        FOR ci IN
        (   SELECT   COL_NAME               INCOL_NAME
                    ,COL_ENTITY_TAB_NAME    INCOL_ENTITY_TAB_NAME
                    ,COL_IS_NULLABLE        INCOL_IS_NULLABLE
            FROM    TABLE(v_input_cols) IC
                    INNER JOIN TABLE(c.INPUT_FLT_ENTITIES) IFLT ON IC.COL_ENTITY_ID = IFLT.COLUMN_VALUE)
        LOOP
            v_input_clauses.FROM_STR := v_input_clauses.FROM_STR||CHR(10)
                ||CASE WHEN ci.INCOL_IS_NULLABLE = 0 THEN 'INNER' ELSE 'LEFT' END
                ||' JOIN '||ci.INCOL_ENTITY_TAB_NAME||' AS OF SCN :SCN '||ci.INCOL_NAME
                ||' ON DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME||' = '||ci.INCOL_NAME||'.E_INTERNAL_ID';
        END LOOP;

        -- for every column of type reference - build the from clause
        FOR ci IN
        (   SELECT   COL_NAME               INCOL_NAME
                    ,COL_IS_NULLABLE        INCOL_IS_NULLABLE
                    ,COL_DEF_TYPE_ID        INCOL_DEF_TYPE_ID
            FROM    TABLE(v_input_cols) IC
            WHERE   COL_DEF_TYPE_ID IS NOT NULL)
        LOOP
            v_input_clauses.FROM_STR := v_input_clauses.FROM_STR||CHR(10)
                ||CASE WHEN ci.INCOL_IS_NULLABLE = 0 THEN 'INNER' ELSE 'LEFT' END
                ||' JOIN OBJECT_REGISTRATION AS OF SCN :SCN '||ci.INCOL_NAME
                ||' ON DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME||' = '||ci.INCOL_NAME||'.OR_ID';
        END LOOP;

        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG
            , RPAD('RESCOL_NAME',30)||RPAD('RESCOL_ORDER',15)||RPAD('RESCOL_TYPE',15)||RPAD('RESCOL_ENTITY_ID',20)
            ||RPAD('RESCOL_ENTITY_TAB_NAME',30)||RPAD('RESCOL_ENTITY_BK',30)||RPAD('RESCOL_ENTITY_BK_DTYPE',25)
            ||RPAD('RESCOL_FLD_ID',15)||RPAD('RESCOL_FLD_DATA_TYPE',25)||RPAD('RESCOL_FLD_TIMEUNIT',20)||RPAD('RESCOL_IS_NULLABLE',20)
            ||RPAD('RESCOL_ENT_HAS_FILTER',25)||RPAD('RESCOL_ENT_HAS_FIELD_MAPPING',30)||RPAD('RESCOL_IS_MATCHING',20) ||RPAD('RESCOL_MATCH_ID',20)
            ||RPAD('MAPPING_OPTION',15)||RPAD('MAPPING_VALUE',30)
            ||RPAD('INCOL_NAME',30)||RPAD('INCOL_ORDER',15)||RPAD('INCOL_TYPE',15)||RPAD('INCOL_ENTITY_ID',20)||RPAD('INCOL_ENTITY_TAB_NAME',25)||RPAD('INCOL_ENTITY_BK',30)
            ||RPAD('INCOL_FLD_ID',15)||RPAD('INCOL_FLD_DATA_TYPE',20)||RPAD('INCOL_FLD_TIMEUNIT',20)||RPAD('INCOL_IS_NULLABLE',20)||RPAD('INCOL_DEF_TYPE_ID',20)
            ||RPAD('INCOL_ENT_HAS_FILTER',25)||RPAD('INCOL_ENT_JOIN_ON_BK',25)||RPAD('INCOL_ENT_JOIN_ON_ID',25)||RPAD('INCOL_ENT_JOIN_ON_ID_ORDER',30)
            , NULL, NULL, v_stamp);
            -- replace "('" with "(NVL(TO_CHAR(ci."
            -- replace "'," with "), '-'),"

        -- for every column in the output table - build the rest of the clauses
        FOR ci IN
        (   SELECT T.*
                ,CASE   WHEN INCOL_ENT_JOIN_ON_ID = 1 THEN ROW_NUMBER() OVER (PARTITION BY CASE WHEN INCOL_ENT_JOIN_ON_ID = 1 THEN INCOL_NAME ELSE NULL END
                                                                            ORDER BY RESCOL_ORDER)
                        ELSE NULL END INCOL_ENT_JOIN_ON_ID_ORDER
            FROM
            (SELECT  RESCOL_NAME, RESCOL_ORDER, RESCOL_TYPE, RESCOL_ENTITY_ID, RESCOL_ENTITY_TAB_NAME, RESCOL_ENTITY_BK, RESCOL_ENTITY_BK_DTYPE
                    ,RESCOL_FLD_ID, RESCOL_FLD_DATA_TYPE, RESCOL_FLD_TIMEUNIT, RESCOL_IS_NULLABLE
                    ,RESCOL_ENT_HAS_FILTER, RESCOL_ENT_HAS_FIELD_MAPPING, RESCOL_IS_MATCHING, RESCOL_MATCH_ID
                    ,MAPPING_OPTION, MAPPING_VALUE
                    ,INCOL_NAME, INCOL_ORDER, INCOL_TYPE, INCOL_ENTITY_ID, INCOL_ENTITY_TAB_NAME, INCOL_ENTITY_BK
                    ,INCOL_FLD_ID, INCOL_FLD_DATA_TYPE, INCOL_FLD_TIMEUNIT, INCOL_IS_NULLABLE, INCOL_DEF_TYPE_ID
                    ,INCOL_ENT_HAS_FILTER
                                -- if the output column is an entity and is mapped from a field in the input
                    ,CASE   WHEN RESCOL_TYPE = 1 AND MAPPING_OPTION = 3
                            THEN 1
                            ELSE NULL END INCOL_ENT_JOIN_ON_BK

                                -- if the output column is an entity and is mapped from an entity in the input
                    ,CASE   WHEN RESCOL_TYPE = 1 AND MAPPING_OPTION = 4
                                -- and we need the BK values from the input entity
                                AND (RESCOL_ENT_HAS_FILTER = 1
                                    OR RESCOL_ENT_HAS_FIELD_MAPPING = 1
                                    OR RESCOL_IS_MATCHING = 1)
                                -- but the join has not already been added in the previous code
                                AND NVL(INCOL_ENT_HAS_FILTER, 0) = 0
                            THEN 1
                                -- if the output column is a field and is mapped from an entity in the input
                            WHEN RESCOL_TYPE = 2 AND MAPPING_OPTION = 4
                                -- but the join has not already been added in the previous code
                                AND NVL(INCOL_ENT_HAS_FILTER, 0) = 0
                            THEN 1
                            ELSE NULL END INCOL_ENT_JOIN_ON_ID
            FROM    -- all output table columns
                    (   SELECT   COL_NAME               RESCOL_NAME
                                ,COL_ORDER              RESCOL_ORDER
                                ,COL_TYPE               RESCOL_TYPE
                                ,COL_ENTITY_ID          RESCOL_ENTITY_ID
                                ,COL_ENTITY_TAB_NAME    RESCOL_ENTITY_TAB_NAME
                                ,COL_ENTITY_BK          RESCOL_ENTITY_BK
                                ,COL_ENTITY_BK_DTYPE    RESCOL_ENTITY_BK_DTYPE
                                ,COL_FLD_ID             RESCOL_FLD_ID
                                ,COL_FLD_DATA_TYPE      RESCOL_FLD_DATA_TYPE
                                ,COL_FLD_TIMEUNIT       RESCOL_FLD_TIMEUNIT
                                ,COL_IS_NULLABLE        RESCOL_IS_NULLABLE
                        FROM    TABLE(v_output_cols)
                    ) RC

                    -- check if any output table columns of type=entity have output filters defined on them
                    LEFT JOIN
                    (   SELECT   1                      RESCOL_ENT_HAS_FILTER
                                ,COLUMN_VALUE           COL_ENTITY_ID
                        FROM    TABLE(v_output_flt_entities)
                    ) OFLT ON RC.RESCOL_TYPE = 1 AND RC.RESCOL_ENTITY_ID = OFLT.COL_ENTITY_ID

                    -- check if any output table columns of type=entity have mapping to fields in any of the inputs
                    LEFT JOIN
                    (   SELECT DISTINCT
                                 1                      RESCOL_ENT_HAS_FIELD_MAPPING
                                ,COLUMN_NAME            COL_NAME
                        FROM    TABLE(v_op_col_mappings)
                        WHERE   MAPPING_OPTION = 3
                    ) EM ON RC.RESCOL_TYPE = 1 AND RC.RESCOL_NAME = EM.COL_NAME

                    -- check if any output table columns are defined as matching criteria
                    LEFT JOIN
                    (   SELECT   1                      RESCOL_IS_MATCHING
                                ,DTMRMR_ID              RESCOL_MATCH_ID
                                ,DTMRMR_ENTITY_ID       COL_ENTITY_ID
                                ,DTMRMR_FIELD_ID        COL_FLD_ID
                        FROM    DT_MR_MATCH_RECORDS
                        WHERE   DTMRMR_DTMRD_ID = pin_definition_id
                                AND v_op_included_recs <> 1
                    ) MRC ON (RC.RESCOL_TYPE = 1 AND RC.RESCOL_ENTITY_ID = MRC.COL_ENTITY_ID)
                            OR (RC.RESCOL_TYPE = 2 AND RC.RESCOL_FLD_ID = MRC.COL_FLD_ID)

                    -- map each output table column to the corresponding input mapping value
                    LEFT JOIN
                    (   SELECT   COLUMN_NAME            COL_NAME
                                ,MAPPING_OPTION         MAPPING_OPTION
                                ,MAPPING_VALUE          MAPPING_VALUE
                        FROM    TABLE(v_op_col_mappings)
                        WHERE   INPUT_ID = c.INPUT_ID
                    ) CM ON RC.RESCOL_NAME = CM.COL_NAME

                    -- get the entity/field properties from the input for any such mappings
                    LEFT JOIN
                    (   SELECT   COL_NAME               INCOL_NAME
                                ,COL_ORDER              INCOL_ORDER
                                ,COL_TYPE               INCOL_TYPE
                                ,COL_ENTITY_ID          INCOL_ENTITY_ID
                                ,COL_ENTITY_TAB_NAME    INCOL_ENTITY_TAB_NAME
                                ,COL_ENTITY_BK          INCOL_ENTITY_BK
                                ,COL_FLD_ID             INCOL_FLD_ID
                                ,COL_FLD_DATA_TYPE      INCOL_FLD_DATA_TYPE
                                ,COL_FLD_TIMEUNIT       INCOL_FLD_TIMEUNIT
                                ,COL_IS_NULLABLE        INCOL_IS_NULLABLE
                                ,COL_DEF_TYPE_ID        INCOL_DEF_TYPE_ID
                        FROM    TABLE(v_input_cols)
                    ) IC ON CM.MAPPING_OPTION IN (3,4) AND TO_CHAR(CM.MAPPING_VALUE) = IC.INCOL_NAME

                    -- check if any input table columns of type=entity have input filters defined on them
                    LEFT JOIN
                    (   SELECT   1                      INCOL_ENT_HAS_FILTER
                                ,COLUMN_VALUE           COL_ENTITY_ID
                        FROM    TABLE(c.INPUT_FLT_ENTITIES)
                    ) IFLT ON CM.MAPPING_OPTION IN (4) AND IC.INCOL_ENTITY_ID = IFLT.COL_ENTITY_ID
            ) T
            ORDER BY RESCOL_ORDER)
        LOOP
            L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG
                , RPAD(NVL(TO_CHAR(ci.RESCOL_NAME), '-'),30)||RPAD(NVL(TO_CHAR(ci.RESCOL_ORDER), '-'),15)||RPAD(NVL(TO_CHAR(ci.RESCOL_TYPE), '-'),15)||RPAD(NVL(TO_CHAR(ci.RESCOL_ENTITY_ID), '-'),20)
                ||RPAD(NVL(TO_CHAR(ci.RESCOL_ENTITY_TAB_NAME), '-'),30)||RPAD(NVL(TO_CHAR(ci.RESCOL_ENTITY_BK), '-'),30)||RPAD(NVL(TO_CHAR(ci.RESCOL_ENTITY_BK_DTYPE), '-'),25)
                ||RPAD(NVL(TO_CHAR(ci.RESCOL_FLD_ID), '-'),15)||RPAD(NVL(TO_CHAR(ci.RESCOL_FLD_DATA_TYPE), '-'),25)||RPAD(NVL(TO_CHAR(ci.RESCOL_FLD_TIMEUNIT), '-'),20)||RPAD(NVL(TO_CHAR(ci.RESCOL_IS_NULLABLE), '-'),20)
                ||RPAD(NVL(TO_CHAR(ci.RESCOL_ENT_HAS_FILTER), '-'),25)||RPAD(NVL(TO_CHAR(ci.RESCOL_ENT_HAS_FIELD_MAPPING), '-'),30)||RPAD(NVL(TO_CHAR(ci.RESCOL_IS_MATCHING), '-'),20) ||RPAD(NVL(TO_CHAR(ci.RESCOL_MATCH_ID), '-'),20)
                ||RPAD(NVL(TO_CHAR(ci.MAPPING_OPTION), '-'),15)||RPAD(NVL(TO_CHAR(ci.MAPPING_VALUE), '-'),30)
                ||RPAD(NVL(TO_CHAR(ci.INCOL_NAME), '-'),30)||RPAD(NVL(TO_CHAR(ci.INCOL_ORDER), '-'),15)||RPAD(NVL(TO_CHAR(ci.INCOL_TYPE), '-'),15)||RPAD(NVL(TO_CHAR(ci.INCOL_ENTITY_ID), '-'),20)||RPAD(NVL(TO_CHAR(ci.INCOL_ENTITY_TAB_NAME), '-'),25)||RPAD(NVL(TO_CHAR(ci.INCOL_ENTITY_BK), '-'),30)
                ||RPAD(NVL(TO_CHAR(ci.INCOL_FLD_ID), '-'),15)||RPAD(NVL(TO_CHAR(ci.INCOL_FLD_DATA_TYPE), '-'),20)||RPAD(NVL(TO_CHAR(ci.INCOL_FLD_TIMEUNIT), '-'),20)||RPAD(NVL(TO_CHAR(ci.INCOL_IS_NULLABLE), '-'),20)||RPAD(NVL(TO_CHAR(ci.INCOL_DEF_TYPE_ID), '-'),20)
                ||RPAD(NVL(TO_CHAR(ci.INCOL_ENT_HAS_FILTER), '-'),25)||RPAD(NVL(TO_CHAR(ci.INCOL_ENT_JOIN_ON_BK), '-'),25)||RPAD(NVL(TO_CHAR(ci.INCOL_ENT_JOIN_ON_ID), '-'),25)||RPAD(NVL(TO_CHAR(ci.INCOL_ENT_JOIN_ON_ID_ORDER), '-'),30)
                , NULL, NULL, v_stamp);

            -- destcol: entity
            IF (ci.RESCOL_TYPE = 1)
            THEN
                v_sel_value := CASE     -- empty
                                        WHEN ci.MAPPING_OPTION = 1 THEN 'NULL'
                                        -- constant
                                        WHEN ci.MAPPING_OPTION = 2 THEN ci.MAPPING_VALUE
                                        -- field from input
                                        WHEN ci.MAPPING_OPTION = 3 THEN ci.RESCOL_ENTITY_TAB_NAME||'.E_INTERNAL_ID'
                                        -- entity from input
                                        WHEN ci.MAPPING_OPTION = 4 THEN 'DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME
                                        ELSE NULL END;

                v_match_value := CASE   -- empty
                                        WHEN ci.MAPPING_OPTION = 1 THEN 'NULL'
                                        -- constant
                                        WHEN ci.MAPPING_OPTION = 2 AND ci.RESCOL_ENTITY_BK_DTYPE = 1 THEN ''''||REPLACE(DT_MERGE_RECORDS.GET_ENTITY_BK_VALUE
                                                                                                                            (ci.RESCOL_ENTITY_TAB_NAME
                                                                                                                            ,ci.RESCOL_ENTITY_BK
                                                                                                                            ,TO_NUMBER(ci.MAPPING_VALUE))
                                                                                                                        ,''''
                                                                                                                        ,'''''')||''''
                                        WHEN ci.MAPPING_OPTION = 2 AND ci.RESCOL_ENTITY_BK_DTYPE = 6 THEN DT_MERGE_RECORDS.GET_ENTITY_BK_VALUE
                                                                                                                    (ci.RESCOL_ENTITY_TAB_NAME
                                                                                                                    ,ci.RESCOL_ENTITY_BK
                                                                                                                    ,TO_NUMBER(ci.MAPPING_VALUE))
                                        -- field from input
                                        WHEN ci.MAPPING_OPTION = 3 AND ci.INCOL_DEF_TYPE_ID IS NULL THEN 'DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME
                                        WHEN ci.MAPPING_OPTION = 3 AND ci.INCOL_DEF_TYPE_ID IS NOT NULL THEN ci.INCOL_NAME||'.'||'OR_RESOLVED_NAME'
                                        -- entity from input
                                        WHEN ci.MAPPING_OPTION = 4 THEN ci.INCOL_NAME||'.'||ci.RESCOL_ENTITY_BK
                                        ELSE NULL END;

                v_input_clauses.SELECT_STR := v_input_clauses.SELECT_STR
                    ||CASE WHEN v_input_clauses.SELECT_STR IS NULL THEN ' ' ELSE CHR(10)||',' END
                    ||v_sel_value||' '||ci.RESCOL_NAME;

                IF (ci.RESCOL_ENT_HAS_FILTER = 1
                    OR ci.RESCOL_ENT_HAS_FIELD_MAPPING = 1
                    OR ci.RESCOL_IS_MATCHING = 1)
                THEN
                    v_input_clauses.SELECT_STR := v_input_clauses.SELECT_STR||CHR(10)||','||v_match_value||' '||ci.RESCOL_NAME||'_V';
                ELSE
                    v_input_clauses.SELECT_STR := v_input_clauses.SELECT_STR||CHR(10)||',NULL '||ci.RESCOL_NAME||'_V';
                END IF;

                IF (ci.INCOL_ENT_JOIN_ON_BK = 1)
                THEN
                    v_input_clauses.FROM_STR := v_input_clauses.FROM_STR||CHR(10)
                        ||'LEFT JOIN '||ci.RESCOL_ENTITY_TAB_NAME||' AS OF SCN :SCN '||ci.RESCOL_ENTITY_TAB_NAME
                        ||' ON UPPER('  ||CASE  WHEN ci.INCOL_DEF_TYPE_ID IS NULL THEN 'DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME
                                                WHEN ci.INCOL_DEF_TYPE_ID IS NOT NULL THEN ci.INCOL_NAME||'.'||'OR_RESOLVED_NAME'
                                                ELSE NULL END
                                        ||') = UPPER('||ci.RESCOL_ENTITY_TAB_NAME||'.'||ci.RESCOL_ENTITY_BK||')';
                ELSIF (ci.INCOL_ENT_JOIN_ON_ID = 1 AND ci.INCOL_ENT_JOIN_ON_ID_ORDER = 1)
                THEN
                    v_input_clauses.FROM_STR := v_input_clauses.FROM_STR||CHR(10)
                        ||CASE WHEN ci.INCOL_IS_NULLABLE = 0 THEN 'INNER' ELSE 'LEFT' END
                        ||' JOIN '||ci.INCOL_ENTITY_TAB_NAME||' AS OF SCN :SCN '||ci.INCOL_NAME
                        ||' ON DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME||' = '||ci.INCOL_NAME||'.E_INTERNAL_ID';
                END IF;

                IF (ci.MAPPING_OPTION = 3)
                THEN
                    v_outer_vld_when_clause := v_outer_vld_when_clause
                        ||CASE WHEN v_outer_vld_when_clause IS NULL THEN NULL ELSE CHR(10) END
                        ||'WHEN (INPUT_ID = '||c.INPUT_ID||' AND '||ci.RESCOL_NAME||' IS NULL AND '||ci.RESCOL_NAME||'_V IS NOT NULL)'
                        ||' THEN INTO TEMP_DT_INPUT_VALIDATION (VLD_DTIN_ID,VLD_FIELD_ID,VLD_ENTITY_ID,VLD_VALUE)'
                        ||' VALUES ('||TO_CHAR(c.INPUT_ID)||','||TO_CHAR(ci.INCOL_FLD_ID)||','||TO_CHAR(ci.RESCOL_ENTITY_ID)||','||ci.RESCOL_NAME||'_V)';
                END IF;

                IF (ci.RESCOL_IS_MATCHING = 1)
                THEN
                    v_input_clauses.MATCH_COLS(TO_CHAR(ci.RESCOL_MATCH_ID)).COL_NAME := ci.RESCOL_NAME||'_V';
                    v_input_clauses.MATCH_COLS(TO_CHAR(ci.RESCOL_MATCH_ID)).COL_DATA_TYPE := ci.RESCOL_ENTITY_BK_DTYPE;
                END IF;
            -- destcol: field
            ELSIF (ci.RESCOL_TYPE = 2)
            THEN
                v_sel_value := CASE     -- empty
                                        WHEN ci.MAPPING_OPTION = 1 AND ci.RESCOL_FLD_DATA_TYPE = 2 THEN '0'
                                        WHEN ci.MAPPING_OPTION = 1 AND ci.RESCOL_FLD_DATA_TYPE <> 2 THEN 'NULL'
                                        -- constant
                                        WHEN ci.MAPPING_OPTION = 2 AND ci.RESCOL_FLD_DATA_TYPE IN (1, 4) THEN ''''||REPLACE(ci.MAPPING_VALUE,'''','''''')||''''
                                        WHEN ci.MAPPING_OPTION = 2 AND ci.RESCOL_FLD_DATA_TYPE = 3 THEN 'TO_DATE('''||ci.MAPPING_VALUE||''', ''DD/MM/YYYY'')'
                                        WHEN ci.MAPPING_OPTION = 2 AND ci.RESCOL_FLD_DATA_TYPE = 5 THEN 'TO_TIMESTAMP('''||ci.MAPPING_VALUE||''', ''DD/MM/YYYY HH24:MI:SS'')'
                                        WHEN ci.MAPPING_OPTION = 2 AND ci.RESCOL_FLD_DATA_TYPE IN (2, 6, 8) THEN ci.MAPPING_VALUE
                                        -- field from input
                                        WHEN ci.MAPPING_OPTION = 3 AND ci.RESCOL_FLD_DATA_TYPE = 3 AND ci.INCOL_FLD_DATA_TYPE = 5 THEN 'CAST(TRUNC(DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME||') AS DATE)'
                                        WHEN ci.MAPPING_OPTION = 3 AND ci.RESCOL_FLD_DATA_TYPE = 5 AND ci.INCOL_FLD_DATA_TYPE = 3 THEN 'CAST(DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME||' AS TIMESTAMP(6))'
                                        WHEN ci.MAPPING_OPTION = 3 AND ci.INCOL_DEF_TYPE_ID IS NULL THEN 'DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME
                                        WHEN ci.MAPPING_OPTION = 3 AND ci.INCOL_DEF_TYPE_ID IS NOT NULL THEN ci.INCOL_NAME||'.'||'OR_RESOLVED_NAME'
                                        -- entity from input
                                        WHEN ci.MAPPING_OPTION = 4 THEN ci.INCOL_NAME||'.'||ci.INCOL_ENTITY_BK
                                        -- based on processing period
                                        WHEN ci.MAPPING_OPTION = 5 AND ci.RESCOL_FLD_DATA_TYPE = 3 THEN 'TO_DATE('''||TO_CHAR(pin_processing_date, 'DD/MM/YYYY')||''', ''DD/MM/YYYY'')'
                                        WHEN ci.MAPPING_OPTION = 5 AND ci.RESCOL_FLD_DATA_TYPE = 5 THEN 'TO_TIMESTAMP('''||TO_CHAR(pin_processing_date, 'DD/MM/YYYY')||''', ''DD/MM/YYYY'')'
                                        WHEN ci.MAPPING_OPTION = 5 AND ci.RESCOL_FLD_DATA_TYPE = 8 AND pin_processing_date IS NOT NULL THEN TO_CHAR(DT_MERGE_RECORDS.GET_TUPR_BY_DATE(ci.RESCOL_FLD_TIMEUNIT, pin_processing_date))
                                        WHEN ci.MAPPING_OPTION = 5 AND ci.RESCOL_FLD_DATA_TYPE = 8 AND pin_processing_period IS NOT NULL THEN TO_CHAR(DT_MERGE_RECORDS.GET_TUPR_BY_CORR_TUPR(ci.RESCOL_FLD_TIMEUNIT, pin_processing_period))
                                        ELSE NULL END;

                v_match_value := v_sel_value;

                v_input_clauses.SELECT_STR := v_input_clauses.SELECT_STR
                    ||CASE WHEN v_input_clauses.SELECT_STR IS NULL THEN ' ' ELSE CHR(10)||',' END
                    ||v_sel_value||' '||ci.RESCOL_NAME;

                IF (ci.INCOL_ENT_JOIN_ON_ID = 1 AND ci.INCOL_ENT_JOIN_ON_ID_ORDER = 1)
                THEN
                    v_input_clauses.FROM_STR := v_input_clauses.FROM_STR||CHR(10)
                        ||CASE WHEN ci.INCOL_IS_NULLABLE = 0 THEN 'INNER' ELSE 'LEFT' END
                        ||' JOIN '||ci.INCOL_ENTITY_TAB_NAME||' AS OF SCN :SCN '||ci.INCOL_NAME
                        ||' ON DTIN'||TO_CHAR(c.INPUT_ID)||'.'||ci.INCOL_NAME||' = '||ci.INCOL_NAME||'.E_INTERNAL_ID';
                END IF;

                IF (ci.RESCOL_IS_MATCHING = 1)
                THEN
                    v_input_clauses.MATCH_COLS(TO_CHAR(ci.RESCOL_MATCH_ID)).COL_NAME := ci.RESCOL_NAME;
                    v_input_clauses.MATCH_COLS(TO_CHAR(ci.RESCOL_MATCH_ID)).COL_DATA_TYPE := ci.RESCOL_FLD_DATA_TYPE;
                END IF;
            END IF;
        END LOOP;

        v_input_clauses.SELECT_STR := v_input_clauses.SELECT_STR
            ||CASE WHEN v_input_clauses.SELECT_STR IS NULL THEN ' ' ELSE CHR(10)||',' END
            ||c.INPUT_ID||' INPUT_ID';

        v_input_clauses.QUERY_STR := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS'
                                                                              ,pi_hint_id=> 'SEL_I'||TO_CHAR(c.INPUT_ID)
                                                                              ,pi_proc_id => pin_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS'
                                                     ,pi_hint_id=> 'SEL_I'||TO_CHAR(c.INPUT_ID)
                                                     ,pi_proc_id => pin_definition_id
                                                     ,pi_other_hints => CASE WHEN c.INPUT_TYPE = 1 THEN c.INPUT_CARDINALITY ELSE NULL END)||CHR(10)
            ||v_input_clauses.SELECT_STR||CHR(10)
            ||'FROM '||v_input_clauses.FROM_STR
            ||CASE WHEN c.INPUT_FLT_FROM_CLAUSE IS NOT NULL THEN CHR(10)||c.INPUT_FLT_FROM_CLAUSE ELSE NULL END||CHR(10)
            ||CASE WHEN v_input_clauses.WHERE_STR IS NULL THEN NULL ELSE 'WHERE '||v_input_clauses.WHERE_STR||CHR(10) END;

        v_sql_clauses(c.INPUT_ORDER) := v_input_clauses;
    END LOOP;

    -- build the inner select queries
    v_idx1 := v_sql_clauses.FIRST;
    WHILE (v_idx1 IS NOT NULL)
    LOOP
        v_with_sql := v_with_sql
            ||CASE WHEN v_with_sql IS NOT NULL THEN ',' ELSE 'WITH'||CHR(10)||' ' END
            ||'DTIN'||TO_CHAR(v_sql_clauses(v_idx1).INPUT_ID)||' AS'||CHR(10)
            ||'('||v_sql_clauses(v_idx1).QUERY_STR||')'||CHR(10);

        v_sel_sql := v_sel_sql
            ||CASE WHEN v_sel_sql IS NOT NULL THEN 'UNION ALL'||CHR(10) ELSE NULL END
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_INNER_I'||TO_CHAR(v_sql_clauses(v_idx1).INPUT_ID) ,pi_proc_id => pin_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_INNER_I'||TO_CHAR(v_sql_clauses(v_idx1).INPUT_ID) ,pi_proc_id => pin_definition_id)
            ||' * FROM DTIN'||TO_CHAR(v_sql_clauses(v_idx1).INPUT_ID)||' I'||CHR(10);

        v_not_exists := NULL;

        -- when record option used is: take records only from first/last input
        IF (v_op_included_recs IN (2, 3))
        THEN
            -- for every prior/next input
            v_idx2 := CASE  WHEN v_op_included_recs = 2 THEN v_sql_clauses.FIRST
                            WHEN v_op_included_recs = 3 THEN v_sql_clauses.LAST
                            ELSE NULL END;

            WHILE ( v_idx2 IS NOT NULL
                    AND (   (v_op_included_recs = 2 AND v_idx2 < v_idx1)
                        OR  (v_op_included_recs = 3 AND v_idx2 > v_idx1)))
            LOOP
                FOR c IN (SELECT DTMRMR_ID FROM DT_MR_MATCH_RECORDS WHERE DTMRMR_DTMRD_ID = pin_definition_id)
                LOOP
                    v_not_exists := v_not_exists
                        ||CASE WHEN v_not_exists IS NOT NULL THEN ' AND ' ELSE NULL END
                        ||DT_MERGE_RECORDS.GET_EQUAL_MATCH_CONDITION
                            (    pin_left_member => 'O.'||v_sql_clauses(v_idx2).MATCH_COLS(TO_CHAR(c.DTMRMR_ID)).COL_NAME
                                ,pin_right_member => 'I.'||v_sql_clauses(v_idx1).MATCH_COLS(TO_CHAR(c.DTMRMR_ID)).COL_NAME
                                ,pin_members_col_type => 2
                                ,pin_members_data_type => v_sql_clauses(v_idx1).MATCH_COLS(TO_CHAR(c.DTMRMR_ID)).COL_DATA_TYPE
                            );
                END LOOP;

                v_sel_sql := v_sel_sql
                    ||CASE  WHEN (v_op_included_recs = 2 AND v_idx2 = v_sql_clauses.FIRST)
                                OR (v_op_included_recs = 3 AND v_idx2 = v_sql_clauses.LAST)
                            THEN 'WHERE ' ELSE 'AND ' END
                    ||'NOT EXISTS ('         ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_I'||TO_CHAR(v_sql_clauses(v_idx1).INPUT_ID)||'_NE_I'||TO_CHAR(v_sql_clauses(v_idx2).INPUT_ID) ,pi_proc_id => pin_definition_id)
                                 ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_I'||TO_CHAR(v_sql_clauses(v_idx1).INPUT_ID)||'_NE_I'||TO_CHAR(v_sql_clauses(v_idx2).INPUT_ID) ,pi_proc_id => pin_definition_id)
                    ||' 1 FROM DTIN'||TO_CHAR(v_sql_clauses(v_idx2).INPUT_ID)||' O'
                    ||CASE WHEN v_not_exists IS NULL THEN NULL ELSE ' WHERE '||v_not_exists END
                    ||')'||CHR(10);

                v_idx2 := CASE  WHEN v_op_included_recs = 2 THEN v_sql_clauses.NEXT(v_idx2)
                                WHEN v_op_included_recs = 3 THEN v_sql_clauses.PRIOR(v_idx2)
                                ELSE NULL END;
            END LOOP;
        END IF;

        v_idx1 := v_sql_clauses.NEXT(v_idx1);
    END LOOP;

    -- build the final insert query
    v_ins_sql := 'DECLARE'||CHR(10)
        ||'v_scn NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
        ||'v_scn := :SCN;'||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'INS_RECS' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'INS_RECS' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||'INTO '||v_output_table_name||' ('||v_outer_ins_col_list||')'||CHR(10)
        ||v_with_sql
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_RECS_MAIN' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_RECS_MAIN' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||v_outer_ins_sel_list||CHR(10)
        ||'FROM ('||CHR(10)
        ||v_sel_sql
        ||') DTOUT'||TO_CHAR(v_output_id)||CHR(10)
        ||CASE WHEN v_output_flt_from_clause IS NOT NULL THEN v_output_flt_from_clause||CHR(10) ELSE NULL END
        ||CASE WHEN v_output_flt_where_clause IS NOT NULL THEN 'WHERE '||v_output_flt_where_clause||CHR(10) ELSE NULL END
        ||';'||CHR(10)
        ||':SQLROWCNT := SQL%ROWCOUNT;'||CHR(10)
        ||CASE WHEN v_save_sql_plan = 'TRUE' THEN 'COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id => NULL, pi_query_identifier => ''MAIN_INSERT'', pi_bind_variables => COLTYPE_NAME_VALUE(RTYPE_NAME_VALUE(''v_scn'', TO_CHAR(v_scn))));'||CHR(10) ELSE NULL END
        ||'END;';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_ins_sql), 'v_ins_sql := <value>;', v_stamp);

    -- build the final validation query
    v_vld_sql := 'DECLARE'||CHR(10)
        ||'v_scn NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
        ||'v_scn := :SCN;'||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'INS_VLD' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'INS_VLD' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||'ALL'||CHR(10)
        ||v_outer_vld_when_clause||CHR(10)
        ||v_with_sql
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_VLD_MAIN' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DT_MERGE_RECORDS.RUN_MERGE_RECORDS' ,pi_hint_id=> 'SEL_VLD_MAIN' ,pi_proc_id => pin_definition_id)||CHR(10)
        ||v_outer_vld_sel_list||CHR(10)
        ||'FROM ('||CHR(10)
        ||v_sel_sql
        ||') DTOUT'||TO_CHAR(v_output_id)||CHR(10)
        ||CASE WHEN v_output_flt_from_clause IS NOT NULL THEN v_output_flt_from_clause||CHR(10) ELSE NULL END
        ||CASE WHEN v_output_flt_where_clause IS NOT NULL THEN 'WHERE '||v_output_flt_where_clause||CHR(10) ELSE NULL END
        ||';'||CHR(10)
        ||CASE WHEN v_save_sql_plan = 'TRUE' THEN 'COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id => NULL, pi_query_identifier => ''VALIDATION_LOGIC'', pi_bind_variables => COLTYPE_NAME_VALUE(RTYPE_NAME_VALUE(''v_scn'', TO_CHAR(v_scn))));'||CHR(10) ELSE NULL END
        ||'END;';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_vld_sql), 'v_vld_sql := <value>;', v_stamp);

    -- execute queries
    BEGIN
        --COMMONS.TERMINATE_INSANE_QUERY(pi_sql => v_ins_sql, pi_run_id => pin_definition_id);

        COMMONS_PROCESSING.EXEC_START_PROC_TRANSACTION(pin_definition_id => pin_definition_id);

        EXECUTE IMMEDIATE v_ins_sql USING IN pin_flashback_scn, OUT v_insert_rowcount;

        COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pin_definition_id);

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_insert_rowcount), 'v_insert_rowcount := <value>;', v_stamp);
        pout_insert_rowcount := v_insert_rowcount;

        OPEN pout_vld_results FOR
        SELECT   CAST(NULL AS NUMBER(10)) VLD_DTIN_ID
                ,CAST(NULL AS NUMBER(10)) VLD_FIELD_ID
                ,CAST(NULL AS NUMBER(10)) VLD_ENTITY_ID
                ,CAST(NULL AS TABLETYPE_DT_CHAR) TRG_VALUES
        FROM dual
        WHERE 1 = 0;
    EXCEPTION
    WHEN ZERO_DIVIDE THEN
        COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pin_definition_id);

        v_insert_rowcount := 0;
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_insert_rowcount), 'v_insert_rowcount := <value>;', v_stamp);
        pout_insert_rowcount := v_insert_rowcount;

        --COMMONS.TERMINATE_INSANE_QUERY(pi_sql => v_vld_sql, pi_run_id => pin_definition_id);
        EXECUTE IMMEDIATE v_vld_sql USING IN pin_flashback_scn;

        OPEN pout_vld_results FOR
        SELECT   O.VLD_DTIN_ID
                ,O.VLD_FIELD_ID
                ,O.VLD_ENTITY_ID
                ,CAST(MULTISET( SELECT DISTINCT I.VLD_VALUE
                                FROM TEMP_DT_INPUT_VALIDATION I
                                WHERE I.VLD_DTIN_ID = O.VLD_DTIN_ID
                                    AND I.VLD_FIELD_ID = O.VLD_FIELD_ID
                                    AND I.VLD_ENTITY_ID = O.VLD_ENTITY_ID
                                ) AS TABLETYPE_DT_CHAR) TRG_VALUES
        FROM TEMP_DT_INPUT_VALIDATION O
        GROUP BY O.VLD_DTIN_ID
                ,O.VLD_FIELD_ID
                ,O.VLD_ENTITY_ID;

        /*  -- this is to get the count of all invalid values
            -- but only take the distinct values
        WITH VLD_DISTINCT AS
        (   SELECT DISTINCT
                 VLD_DTIN_ID
                ,VLD_FIELD_ID
                ,VLD_ENTITY_ID
                ,VLD_VALUE
            FROM TEMP_DT_INPUT_VALIDATION
        )
        SELECT   O.VLD_DTIN_ID
                ,O.VLD_FIELD_ID
                ,O.VLD_ENTITY_ID
                ,COUNT(*) TRG_COUNT
                ,CAST(MULTISET( SELECT I.VLD_VALUE
                                FROM VLD_DISTINCT I
                                WHERE I.VLD_DTIN_ID = O.VLD_DTIN_ID
                                    AND I.VLD_FIELD_ID = O.VLD_FIELD_ID
                                    AND I.VLD_ENTITY_ID = O.VLD_ENTITY_ID
                                    AND ROWNUM <= 1001
                                ) AS TABLETYPE_DT_CHAR) TRG_VALUES
        FROM TEMP_DT_INPUT_VALIDATION O
        GROUP BY O.VLD_DTIN_ID
                ,O.VLD_FIELD_ID
                ,O.VLD_ENTITY_ID;*/
    WHEN OTHERS THEN
        COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pin_definition_id);

        v_insert_rowcount := 0;
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_insert_rowcount), 'v_insert_rowcount := <value>;', v_stamp);
        pout_insert_rowcount := v_insert_rowcount;
        RAISE;
    END;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END RUN_MERGE_RECORDS;

END DT_MERGE_RECORDS;
/
