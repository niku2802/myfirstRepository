CREATE PACKAGE PURGE_RECORDS AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type: SPM
-- Product			: commons
-- Module			  : settings-commons
-- Requester		: Macoveiciuc Iulian
-- Author			  : Filip Catalin
-- Reviewer			: Lazar Lucian
-- Review date	:
-- Description	: Used to delete Processing, Login Histoy and Portal Usage logs older than a specified number of days by creating three jobs that will run daily.
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************

 /********************************************************************************************************************
   * TYPE              : PROCEDURE
   * PROCEDURE NAME    : PURGE_LOGS
   * AUTHOR            : Filip Catalin
   * REVIEWER          : Lazar Lucian
   * INPUT PARAMETERS  : pin_purge_type         : 1-Purge Process Logs 2-Purge Login History 3-Purge Portal History
   * OUTPUT PARAMETERS : None
   * DESCRIPTION       : Procedure used to delete Process/Login History/Portal History logs depending on the calling job(pin_purge_type).
   * Example           : The procedure is called by a job.
   *********************************************************************************************************************/
   PROCEDURE PURGE_LOGS(pin_purge_type IN NUMBER);

  /********************************************************************************************************************
   * TYPE              : PROCEDURE
   * PROCEDURE NAME    : BACKUP_TABLES
   * AUTHOR            : Alex Huiban
   * REVIEWER          : Lazar Lucian
   * INPUT PARAMETERS  : pin_table_name         : The name of the original table that is going to be backed up.
                         pin_days               : The number of days to keep the backed up table.
                         pin_comments           : The comments.
   * OUTPUT PARAMETERS : pout_table_name        : The name of the backedup table.
   * DESCRIPTION       : Procedure used to create a backup of the data from a table. The procedure is called by a user or a script.
   * Example           :
   *                   DECLARE
   *                       pout_table_name varchar2(50);
   *                   BEGIN
   *                       PURGE_RECORDS.BACKUP_TABLES(
   *                                      pin_table_name => 'USERS',
   *                                      pin_days => 32,
   *                                      pin_comments => 'Backing up the users for 32 days.',
   *                                      pout_table_name => pout_table_name);
   *                       DBMS_OUTPUT.PUT_LINE (pout_table_name);
   *                   END;
   *
   *********************************************************************************************************************/
   PROCEDURE BACKUP_TABLES(pin_table_name IN VARCHAR2,pin_days IN NUMBER,pin_comments IN VARCHAR2);

 /********************************************************************************************************************
   * TYPE              : PROCEDURE
   * PROCEDURE NAME    : REPROGRAM_PURGE_JOBS
   * AUTHOR            : Filip Catalin
   * REVIEWER          : Lazar Lucian
   * INPUT PARAMETERS  : pin_process_logs_days  : Delete proces logs older than the number of days received in this parameter.
   *                     pin_login_history_days : Delete login history logs older than the number of days received in this parameter.
   *                     pin_portal_usage_days  : Delete portal usage logs older than the number of days received in this parameter.
   *                     pin_start_hour         : The hour selected by the user for the jobs to start. - 24HH
   *                     pin_start_minute       : The minute selected by the user for the jobs to start.
   *                     pin_timezone           : The timezone selected by the user for the jobs to start.
    *                    pin_portal_errors_days : Delete portal errors older than the number of days received in this parameter.
   * OUTPUT PARAMETERS : None
   * DESCRIPTION       : Procedure used to create one schedule and three jobs using the previously created schedule. The procedure is also used to modify the
   *                     start hour/minute/timezone for the schedule, and update the following parameters in PROPERTIES: -	PURGE_JOB_HOUR
   *                                                                                                                     - PURGE_JOB_MINUTE
   *                                                                                                                     - PURGE_JOB_TIMEZONE
   *                                                                                                                     - PURGE_PROCESS_LOGS_DAYS
   *                                                                                                                     - PURGE_LOGIN_HISTORY_DAYS
   *                                                                                                                     - PURGE_PORTAL_USAGE_DAYS
   * Example           :
   *  BEGIN
   *    PURGE_RECORDS.REPROGRAM_PURGE_JOBS(
   *          pin_process_logs_days => '356',
   *          pin_login_history_days => '356',
   *          pin_portal_usage_days => '356',
   *          pin_start_hour => '23',
   *          pin_start_minute => '30',
   *          pin_timezone => 'ET',
   *          pin_portal_errors_days => '365' );
   *  END;
   *********************************************************************************************************************/
   PROCEDURE REPROGRAM_PURGE_JOBS(pin_process_logs_days  IN VARCHAR2,
                           pin_login_history_days IN VARCHAR2,
                           pin_portal_usage_days  IN VARCHAR2,
                           pin_start_hour         IN VARCHAR2,
                           pin_start_minute       IN VARCHAR2,
                           pin_timezone           IN VARCHAR2,
						               pin_portal_errors_days IN VARCHAR2 DEFAULT '365');

-- *******************************    PUBLIC PROCEDURES END         *******************************
END PURGE_RECORDS;
/
