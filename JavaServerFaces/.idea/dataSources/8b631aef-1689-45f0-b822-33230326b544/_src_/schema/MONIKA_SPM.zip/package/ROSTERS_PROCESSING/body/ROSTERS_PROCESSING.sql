CREATE package body rosters_processing is
  -- -----------------------------------------------------------------------------
  -- Copyright 2011, SPM Software LP. All Rights Reserved.
  -- This program belongs to SPM Software LP.  It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from SPM Software LP.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   compensation
  -- Module    :  compensation-processing
  -- Requester    :  Obreja, Petru
  -- Author    :  Lazar, Lucian
  -- Reviewer    :  Cozac, Tudor
  -- Review date    :  20110530
  -- Description    :  Used for roster processing
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC FUNCTIONS START         *******************************

  CON_EXTREME_NUMERIC    CONSTANT VARCHAR2(250) :=  '1E38';
  --CON_EXTREME_CHAR       CONSTANT VARCHAR2(250) :=  '''CHR(0)''';
  CON_EXTREME_DATE       CONSTANT VARCHAR2(250) :=  'TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')';
  CON_EXTREME_DATE_MAX   CONSTANT VARCHAR2(250) :=  'TO_DATE(''01/01/9999'', ''DD/MM/YYYY'')';
  --CON_EXTREME_DATE_TIME  CONSTANT VARCHAR2(250) :=  'TO_TIMESTAMP(''01/01/1800 00:00:00'', ''DD/MM/YYYY HH24:MI:SS'')';

  function check_selected_earnings_roster(pi_earning_entity_table    in varchar2,
                                          pi_earning_entity_id       in number,
                                          pi_assignment_table        in varchar2,
                                          pi_assignment_entity_table in varchar2,
                                          pi_assignment_entity_id    in number,
                                          pi_filter                  in varchar2,
                                          pi_date_filter             in varchar2,
                                          pi_selected_earning_roster in varchar2,
                                          pi_master_roster_table     in varchar2,
                                          pi_plan_id                 in number,
                                          pi_payment_period_id       in number,
                                          pi_projected_period_id     in number) return number as
    v_earning_entity        varchar2(30);
    v_assignment_entity     varchar2(30);
    v_check_sql             varchar2(32767);
    v_count                 integer;
    v_result                integer;
    v_start_date            date;
    v_end_date              date;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.CHECK_SELECTED_EARNINGS_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id )  ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_assignment_table)   ,',pi_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_assignment_entity_table)  ,',pi_assignment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_assignment_entity_id)    ,',pi_assignment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_filter)  ,',pi_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_date_filter)        ,',pi_date_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_selected_earning_roster) ,',pi_selected_earning_roster => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_master_roster_table)  ,',pi_master_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_plan_id)       ,',pi_plan_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_period_id )  ,',pi_payment_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_period_id )  ,',pi_projected_period_id => <value>', v_stamp);

    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get assignment entity name in roster table
    if pi_assignment_table is not null and pi_assignment_entity_table is not null then
      v_assignment_entity := 'E' || pi_assignment_entity_id;
    end if;
    -- get start date and end date for the period
    if pi_projected_period_id is null then
      commons_timeunits.get_period_start_end_date(pi_payment_period_id,v_start_date,v_end_date);
    else
      commons_timeunits.get_period_start_end_date(pi_projected_period_id,v_start_date,v_end_date);
    end if;
    -- check if all selected records can be reinserted: compare entity id from temp with entity id from earning entity / assignment
      if pi_assignment_table is not null and pi_assignment_entity_table is not null and pi_master_roster_table is null then
        v_check_sql := 'select count(*) cnt
                          from (select rownum
                                  from (select 1
                                          from ' || pi_selected_earning_roster ||
                                        ' where ' || v_earning_entity || ' not in (select ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                                                                                   ' from ' || pi_earning_entity_table ||
                                                                                   ' join (select ' || v_earning_entity || ',' || v_assignment_entity ||
                                                                                           ' from ' || pi_assignment_table ||
                                                                                 case when pi_date_filter is not null
                                                                                      then ' where ' || pi_date_filter
                                                                                  end || ' ) ass
                                                                                       on ' || pi_earning_entity_table || '.e_internal_id = ass.' || v_earning_entity ||
                                                                                   ' join ' || pi_assignment_entity_table ||
                                                                                     ' on ass.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id' ||
                                                                                   ' join ' || pi_selected_earning_roster ||
                                                                                     ' on ' || pi_earning_entity_table || '.e_internal_id = ' || pi_selected_earning_roster || '.' || v_earning_entity ||
                                                                        case when pi_filter is not null
                                                                             then ' where ' || pi_filter
                                                                         end || '  ) ' ||
                                      ' ) where rownum = 1
                                )';
      elsif pi_assignment_table is null and pi_assignment_entity_table is null and pi_master_roster_table is null then
        v_check_sql := 'select count(*) cnt
                          from (select rownum
                                  from (select 1
                                          from ' || pi_selected_earning_roster || '
                                         where ' || v_earning_entity || ' not in  (select e_internal_id
                                                                                     from ' || pi_earning_entity_table ||
                                                                          case when pi_filter is not null
                                                                               then ' where ' || pi_filter
                                                                           end ||  ')
                                        ) where rownum = 1
                                )';
      elsif pi_assignment_table is null and pi_assignment_entity_table is null and pi_master_roster_table is not null then
        v_check_sql := 'select count(*) cnt
                          from (select rownum
                                  from (select 1
                                          from ' || pi_selected_earning_roster || '
                                         where ' || v_earning_entity || ' not in  (select ' || pi_earning_entity_table || '.e_internal_id
                                                                                     from ' || '(select distinct ' || v_earning_entity ||
                                                                                                 ' from ' || pi_master_roster_table ||
                                                                                                ' where plan_name = ' || pi_plan_id ||
                                                                                                  ' and nvl(start_date,' || CON_EXTREME_DATE || ') <= nvl(''' || v_end_date || ''',' || CON_EXTREME_DATE || ')' ||
                                                                                                  ' and nvl(end_date,' || CON_EXTREME_DATE_MAX || ') >= nvl(''' || v_start_date || ''',' || CON_EXTREME_DATE_MAX || ')' ||
                                                                                                ') ' || pi_master_roster_table ||
                                                                                   ' join ' || pi_earning_entity_table || ' on ' || pi_master_roster_table || '.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                                                                          case when pi_filter is not null
                                                                               then ' where ' || pi_filter
                                                                           end ||  ')
                                        ) where rownum = 1
                                )';
      end if;
      --logg(v_check_sql);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(v_check_sql)  ,',v_check_sql => <value>', v_stamp);
    execute immediate v_check_sql into v_count;
    if v_count > 0 then
      -- some records won't be reinserted, abort process
      v_result := 0;
    elsif v_count = 0 then
      -- all records can be inserted, continue process
      v_result := 1;
    end if;
    return v_result;
  end check_selected_earnings_roster;

  function check_selected_payment_roster(pi_earning_entity_table      in varchar2,
                                         pi_earning_entity_id         in number,
                                         pi_payment_assignment_table  in varchar2,
                                         pi_payment_entity_table      in varchar2,
                                         pi_payment_entity_id         in number,
                                         pi_filter                    in varchar2,
                                         pi_date_filter               in varchar2,
                                         pi_selected_payment_roster   in varchar2,
                                         pi_earning_roster_table      in varchar2) return number as
    v_earning_entity        varchar2(30);
    v_payment_entity        varchar2(30);
    v_check_sql             varchar2(32767);
    v_count                 integer;
    v_result                integer;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.CHECK_SELECTED_PAYMENT_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id )  ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_assignment_table)   ,',pi_payment_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_entity_table)  ,',pi_payment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_entity_id)    ,',pi_payment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_filter)  ,',pi_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_date_filter)        ,',pi_date_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_selected_payment_roster)  ,',pi_selected_payment_roster => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_roster_table)  ,',pi_earning_roster_table => <value>', v_stamp);

    -- get earning entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get payment entity name in roster table
    v_payment_entity := 'E' || pi_payment_entity_id;
    -- check if all selected records can be reinserted: compare entity id from temp with entity id from earning entity and payment entity
    -- did not use NOT IN instead of NOT EXISTS because there can be nulls on payment entity
    v_check_sql := 'select count(*) cnt
                      from (select rownum
                              from (select 1
                                      from ' || pi_selected_payment_roster ||
                                   ' where not exists (select 1
                                                         from ' || '(select ' || pi_earning_roster_table || '.' || v_earning_entity || ',' ||
                                                                            pi_payment_assignment_table || '.' || v_payment_entity ||
                                                                     ' from ' || pi_earning_roster_table ||
                                                                ' left join ' || '(select ' || pi_payment_assignment_table || '.' || v_earning_entity || ',' ||
                                                                                          pi_payment_assignment_table || '.' || v_payment_entity ||
                                                                                   ' from ' ||
                                                                               case when pi_date_filter is not null
                                                                                    then '(select ' || v_earning_entity || ',' ||
                                                                                                  v_payment_entity ||
                                                                                           ' from ' || pi_payment_assignment_table ||
                                                                                          ' where ' || pi_date_filter ||
                                                                                          ') '
                                                                                end ||
                                                                                           pi_payment_assignment_table ||
                                                                                   ' join ' || pi_earning_entity_table ||
                                                                                     ' on ' || pi_payment_assignment_table || '.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.E_INTERNAL_ID' ||
                                                                                   ' join ' || pi_payment_entity_table ||
                                                                                     ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.E_INTERNAL_ID' ||
                                                                        case when pi_filter is not null
                                                                             then ' where ' || pi_filter end ||
                                                                                   ')' || pi_payment_assignment_table ||
                                                                       ' on ' || pi_earning_roster_table || '.' || v_earning_entity || ' = ' || pi_payment_assignment_table || '.' || v_earning_entity ||
                                                                    ') rst' ||
                                                      ' where ' || pi_selected_payment_roster || '.' || v_earning_entity || ' = rst.' || v_earning_entity ||
                                                        ' and ' || commons_utils.get_equal_match_condition(pi_selected_payment_roster || '.' || v_payment_entity,
                                                                                                           'rst.' || v_payment_entity,
                                                                                                           1,
                                                                                                           6) ||
                                                      ')
                                    )
                             where rownum = 1
                            )';
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(v_check_sql)  ,',v_check_sql => <value>', v_stamp);
    execute immediate v_check_sql into v_count;
    if v_count > 0 then
      -- some records won't be reinserted, abort process
      v_result := 0;
    elsif v_count = 0 then
      -- all records can be inserted, continue process
      v_result := 1;
    end if;
    return v_result;
  end check_selected_payment_roster;

  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  procedure recreate_temp_roster(pi_earning_entity_id         in number,
                                 pi_payment_entity_id         in number,
                                 pi_run_id                    in number,
                                 pi_selected_earning_roster   in varchar2,
                                 pi_selected_payment_roster   in varchar2,
                                 pi_roster_table              in varchar2,
                                 pi_roster_type               in number) as
    v_earning_entity        varchar2(30);
    v_payment_entity        varchar2(30);

    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.RECREATE_TEMP_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id) ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_entity_id) ,',pi_payment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id) ,',pi_run_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_selected_earning_roster) ,',pi_selected_earning_roster => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_selected_payment_roster) ,',pi_selected_payment_roster => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roster_table) ,',pi_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_roster_type) ,',pi_roster_type => <value>', v_stamp);

    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get payment entity name in roster table
    if pi_roster_type = 2 then
      v_payment_entity := 'E' || pi_payment_entity_id;
    end if;
    -- recreate selected roster table
    if pi_roster_type = 1 then
      execute immediate 'drop table ' || pi_selected_earning_roster;
      execute immediate 'create table ' || pi_selected_earning_roster || ' as
                         select *
                           from ' || pi_roster_table ||
                        ' where ' || v_earning_entity || ' in (select prdd_earning_entity_id
                                                                 from plan_run_data_details
                                                                where prdd_prd_id in (select prd_id
                                                                                        from plan_run_data
                                                                                       where prd_run_id = ' || pi_run_id || '
                                                                                      )
                                                               )';
    elsif pi_roster_type = 2 then
      execute immediate 'drop table ' || pi_selected_payment_roster;
      execute immediate 'create table ' || pi_selected_payment_roster || ' as
                         select *
                           from ' || pi_roster_table ||
                        ' where (' || v_earning_entity || ', nvl(' || v_payment_entity || ',' || CON_EXTREME_NUMERIC || '))
                             in (select prdd_earning_entity_id, nvl(prdd_payment_entity_id,' || CON_EXTREME_NUMERIC || ')
                                   from plan_run_data_details
                                  where prdd_prd_id in (select prd_id
                                                          from plan_run_data
                                                         where prd_run_id = ' || pi_run_id || '
                                                        )
                                 )';
    end if;

  end recreate_temp_roster;

  procedure repopulate_temp_roster(pi_roster_table            in varchar2,
                                   pi_roster_type             in number,
                                   pi_earning_entity_column   in varchar2,
                                   pi_payment_entity_column   in varchar2,
                                   pi_run_id                  in number,
                                   pi_temporary_roster_table  in varchar2)
  as
      v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.REPOPULATE_TEMP_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roster_table) ,',pi_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_roster_type) ,',pi_roster_type => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_earning_entity_column) ,',pi_earning_entity_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_entity_column) ,',pi_payment_entity_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id) ,',pi_run_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temporary_roster_table) ,',pi_temporary_roster_table => <value>', v_stamp);

    execute immediate 'delete ' || pi_temporary_roster_table;
    if pi_roster_type = 1 then
      execute immediate 'insert into ' || pi_temporary_roster_table ||
                       ' select *
                           from ' || pi_roster_table ||
                        ' where ' || pi_earning_entity_column || ' in (select prdd_earning_entity_id
                                                                         from plan_run_data_details
                                                                        where prdd_prd_id in (select prd_id
                                                                                                from plan_run_data
                                                                                               where prd_run_id = ' || pi_run_id || '
                                                                                              )
                                                                       )';
    elsif pi_roster_type = 2 then
      execute immediate 'insert into ' || pi_temporary_roster_table ||
                       ' select *
                           from ' || pi_roster_table ||
                        ' where (' || pi_earning_entity_column || ', nvl(' || pi_payment_entity_column || ',' || CON_EXTREME_NUMERIC || '))
                             in (select prdd_earning_entity_id, nvl(prdd_payment_entity_id,' || CON_EXTREME_NUMERIC || ')
                                   from plan_run_data_details
                                  where prdd_prd_id in (select prd_id
                                                          from plan_run_data
                                                         where prd_run_id = ' || pi_run_id || '
                                                        )
                                 )';
    end if;
  end repopulate_temp_roster;

  procedure update_earnings_roster(pi_earning_entity_table      in varchar2,
                                   pi_earning_entity_id         in number,
                                   pi_assignment_table          in varchar2,
                                   pi_assignment_entity_table   in varchar2,
                                   pi_assignment_entity_id      in number,
                                   pi_columns_list              in TABLETYPE_NAME_MAP,
                                   pi_payment_timeunit_column   in varchar2,
                                   pi_projected_timeunit_column in varchar2,
                                   pi_projected_field_column    in varchar2,
                                   pi_payment_period_id         in number,
                                   pi_projected_period_id       in number,
                                   pi_projected_field_value     in number,
                                   pi_filter                    in varchar2,
                                   pi_date_filter               in varchar2,
                                   pi_run_id                    in number,
                                   pi_selected_earning_roster   in varchar2,
                                   pi_earning_roster_table      in varchar2,
                                   pi_master_roster_table       in varchar2,
                                   pi_plan_id                   in number,
                                   pi_selected_from_job         in number,
                                   po_processed_records         out number) as
    v_delete_sql            varchar2(32767);
    v_insert_sql            clob;
    v_period_column         varchar2(30);
    v_period_id             number;
    v_period_columns_list   varchar2(62);
    v_period_values_list    varchar2(62);
    v_columns_list          varchar2(32767);
    v_prefixed_columns_list varchar2(32767);
    v_earning_entity        varchar2(30);
    v_assignment_entity     varchar2(30);
    v_projected_column      varchar2(30);
    v_projected             varchar2(30);
    v_input_columns_list    TABLETYPE_NAME_MAP;
    v_start_date            date;
    v_end_date              date;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.UPDATE_EARNINGS_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_earning_entity_id) ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_assignment_table) ,',pi_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_assignment_entity_table) ,',pi_assignment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_assignment_entity_id) ,',pi_assignment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(pi_columns_list) ,',pi_columns_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_timeunit_column) ,',pi_payment_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_projected_timeunit_column) ,',pi_projected_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_projected_field_column) ,',pi_projected_field_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_period_id) ,',pi_payment_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_period_id) ,',pi_projected_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_field_value) ,',pi_projected_field_value => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_filter) ,',pi_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_date_filter) ,',pi_date_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id) ,',pi_run_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_selected_earning_roster) ,',pi_selected_earning_roster => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_earning_roster_table) ,',pi_earning_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_master_roster_table) ,',pi_master_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_plan_id) ,',pi_plan_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_selected_from_job) ,',pi_selected_from_job => <value>', v_stamp);

    -- set period and projected period columns and values
    if pi_projected_timeunit_column is null then
      v_period_column       := pi_payment_timeunit_column;
      v_period_columns_list := ',' || pi_payment_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id;
      v_period_id           := pi_payment_period_id;
    else
      v_period_column       := pi_projected_timeunit_column;
      v_period_columns_list := ',' || pi_payment_timeunit_column || ',' || pi_projected_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id || ',' || pi_projected_period_id;
      v_period_id           := pi_projected_period_id;
    end if;
    -- set projected column
    if pi_projected_field_column is not null then
      v_projected_column := ',' || pi_projected_field_column;
      v_projected        := ',' || pi_projected_field_value;
    end if;
    -- set columns list (one non-prefixed list for the insert and one prefixed list for the select)
    if pi_columns_list is not null and pi_columns_list.first is not null then
      v_input_columns_list := pi_columns_list;
      for i in v_input_columns_list.first .. v_input_columns_list.last loop
        v_columns_list          := v_columns_list || ',' || v_input_columns_list(i).NAME2;
        v_prefixed_columns_list := v_prefixed_columns_list || ',' || v_input_columns_list(i).NAME1 || '.' || v_input_columns_list(i).NAME2;
      end loop;
    end if;
    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get assignment entity name in roster table
    if pi_assignment_table is not null and pi_assignment_entity_table is not null then
      v_assignment_entity := 'E' || pi_assignment_entity_id;
    end if;
    -- get start date and end date for the period
    if pi_projected_timeunit_column is null then
      commons_timeunits.get_period_start_end_date(pi_payment_period_id,v_start_date,v_end_date);
    else
      commons_timeunits.get_period_start_end_date(pi_projected_period_id,v_start_date,v_end_date);
    end if;
    -- build delete existing records from roster table statement
    v_delete_sql := 'delete
                       from ' || pi_earning_roster_table ||
                    ' where ' || v_period_column || ' = ' || v_period_id ||
            case when pi_selected_earning_roster is not null
                 then ' and ' || v_earning_entity || ' in (select ' || v_earning_entity ||
                                                           ' from ' || pi_selected_earning_roster ||
                                                          ')'
             end;
    -- build insert new records in roster table statement
    v_insert_sql := 'insert into ' || pi_earning_roster_table ||
                                    '(row_identifier,row_version,' ||
                                      v_earning_entity ||
                     case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                          then ',' || v_assignment_entity
                      end ||          v_period_columns_list ||
                                      v_columns_list ||
                                      v_projected_column ||
                                     ',PROCESSED_DATE_TIME)
                     select ' || commons_appframework.get_row_identifier_sequence(pi_earning_roster_table, v_period_id) || '.nextval,
                            0,' ||
                            v_earning_entity ||
           case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                then ',' || v_assignment_entity
            end ||          v_period_values_list ||
                            v_columns_list ||
                            v_projected ||
                         ', cast(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' as date)
                       from (select ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                  case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                       then ', ' || pi_assignment_entity_table || '.e_internal_id ' ||
                                    v_assignment_entity
                   end ||           v_period_values_list ||
                                    v_prefixed_columns_list ||
                             ' from ' ||
                          case when pi_master_roster_table is not null
                               then '(select distinct ' || v_earning_entity ||
                                      ' from ' || pi_master_roster_table ||
                                     ' where plan_name = ' || pi_plan_id ||
                                       ' and nvl(start_date,' || CON_EXTREME_DATE || ') <= nvl(''' || v_end_date || ''',' || CON_EXTREME_DATE || ')' ||
                                       ' and nvl(end_date,' || CON_EXTREME_DATE_MAX || ') >= nvl(''' || v_start_date || ''',' || CON_EXTREME_DATE_MAX || ')' ||
                                     ') ' || pi_master_roster_table ||
                             ' join '
                           end ||

                             '(select distinct ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                               case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                                    then ', max(' || pi_assignment_entity_table || '.e_internal_id) ' || v_assignment_entity end ||
                                     ' from ' || pi_earning_entity_table ||
                           case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                                then ' join (select ' || v_earning_entity || ',' ||
                                                    v_assignment_entity ||
                                             ' from ' || pi_assignment_table ||
                                  case when pi_date_filter is not null
                                       then ' where ' || pi_date_filter
                                   end ||
                                           ' ) ' || pi_assignment_table ||
                                       ' on ' || pi_earning_entity_table || '.e_internal_id = ' || pi_assignment_table || '.' || v_earning_entity ||
                                     ' join ' || pi_assignment_entity_table ||
                                       ' on ' ||  pi_assignment_table || '.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id'
                            end ||
                           case when pi_selected_earning_roster is not null
                                then ' join ' || pi_selected_earning_roster ||
                                       ' on ' || pi_earning_entity_table || '.e_internal_id = ' || pi_selected_earning_roster || '.' || v_earning_entity
                            end ||
                          case when pi_filter is not null
                               then ' where ' || pi_filter
                           end ||
                          case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                               then ' group by ' || pi_earning_entity_table || '.e_internal_id'
                           end ||
                                   ') ass' ||

                          case when pi_master_roster_table is not null
                               then ' on ' || pi_master_roster_table || '.' || v_earning_entity || ' = ass.' || v_earning_entity
                           end ||
                             ' join ' || pi_earning_entity_table ||
                             ' on ass.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                 case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                      then ' join ' || pi_assignment_entity_table ||
                             ' on ass.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id'
                  end ||
                            ')';

    -- delete existing records from roster table
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_delete_sql) ,',v_delete_sql', v_stamp);
    execute immediate v_delete_sql;
    -- insert new records in roster table
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_insert_sql') ,',v_insert_sql', v_stamp);
    execute immediate v_insert_sql;
    po_processed_records := sql%rowcount;
    -- repopulate temporary roster table to catch all data changes in the roster table
    if pi_selected_earning_roster is not null and (pi_selected_from_job = 0 or pi_selected_from_job is null) then
      repopulate_temp_roster(pi_earning_roster_table, 1, v_earning_entity, null, pi_run_id, pi_selected_earning_roster);
    end if;
  end update_earnings_roster;

  procedure update_payment_roster(pi_earning_entity_table      in varchar2,
                                  pi_earning_entity_id         in number,
                                  pi_payment_assignment_table  in varchar2,
                                  pi_payment_entity_table      in varchar2,
                                  pi_payment_entity_id         in number,
                                  pi_columns_list              in TABLETYPE_NAME_MAP,
                                  pi_payment_timeunit_column   in varchar2,
                                  pi_projected_timeunit_column in varchar2,
                                  pi_projected_field_column    in varchar2,
                                  pi_payment_period_id         in number,
                                  pi_projected_period_id       in number,
                                  pi_projected_field_value     in number,
                                  pi_filter                    in varchar2,
                                  pi_date_filter               in varchar2,
                                  pi_run_id                    in number,
                                  pi_selected_payment_roster   in varchar2,
                                  pi_earning_roster_table      in varchar2,
                                  pi_payment_roster_table      in varchar2,
                                  pi_selected_from_job         in number,
                                  po_processed_records         out number) as
    v_delete_sql            varchar2(32767);
    v_insert_sql            clob;
    v_period_column         varchar2(30);
    v_period_id             number;
    v_period_columns_list   varchar2(62);
    v_period_values_list    varchar2(62);
    v_columns_list          varchar2(32767);
    v_prefixed_columns_list varchar2(32767);
    v_earning_entity        varchar2(30);
    v_payment_entity        varchar2(30);
    v_projected_column      varchar2(30);
    v_projected             varchar2(30);
    v_input_columns_list    TABLETYPE_NAME_MAP;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.UPDATE_PAYMENT_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_earning_entity_id) ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_assignment_table) ,',pi_payment_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_entity_table) ,',pi_payment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_payment_entity_id) ,',pi_payment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(pi_columns_list) ,',pi_columns_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_timeunit_column) ,',pi_payment_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_projected_timeunit_column) ,',pi_projected_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_projected_field_column) ,',pi_projected_field_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_period_id) ,',pi_payment_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_period_id) ,',pi_projected_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_field_value) ,',pi_projected_field_value => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_filter) ,',pi_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_date_filter) ,',pi_date_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id) ,',pi_run_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_selected_payment_roster) ,',pi_selected_payment_roster => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_earning_roster_table) ,',pi_earning_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_roster_table) ,',pi_payment_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_selected_from_job) ,',pi_selected_from_job => <value>', v_stamp);

    -- set period and projected period columns and values
    if pi_projected_timeunit_column is null then
      v_period_column       := pi_payment_timeunit_column;
      v_period_columns_list := ',' || pi_payment_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id;
      v_period_id           := pi_payment_period_id;
    else
      v_period_column       := pi_projected_timeunit_column;
      v_period_columns_list := ',' || pi_payment_timeunit_column || ',' || pi_projected_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id || ',' || pi_projected_period_id;
      v_period_id           := pi_projected_period_id;
    end if;
    -- set projected column
    if pi_projected_field_column is not null then
      v_projected_column := ',' || pi_projected_field_column;
      v_projected        := ',' || pi_projected_field_value;
    end if;
    -- set columns list (one non-prefixed list for the insert and one prefixed list for the select)
    if pi_columns_list is not null then
      v_input_columns_list := pi_columns_list;
      for i in v_input_columns_list.first .. v_input_columns_list.last loop
        v_columns_list          := v_columns_list || ',' || v_input_columns_list(i).NAME2;
        v_prefixed_columns_list := v_prefixed_columns_list || ',' || v_input_columns_list(i).NAME1 || '.' || v_input_columns_list(i).NAME2;
      end loop;
    end if;
    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get payment entity name in roster table
    v_payment_entity := 'E' || pi_payment_entity_id;
    -- build delete existing records from roster table statement
    v_delete_sql := 'delete
                       from ' || pi_payment_roster_table ||
                    ' where ' || v_period_column || ' = ' || v_period_id ||
            case when pi_selected_payment_roster is not null
                 then ' and (' || v_earning_entity || ', nvl(' || v_payment_entity || ',' || CON_EXTREME_NUMERIC || '))
                         in (select ' || v_earning_entity || ',
                                    nvl(' || v_payment_entity || ',' || CON_EXTREME_NUMERIC || ')
                               from ' || pi_selected_payment_roster ||
                            ')'
             end;

    -- build insert new records in roster table statement
    v_insert_sql := 'insert into ' || pi_payment_roster_table ||
                                    '(row_identifier,
                                      row_version,' ||
                                      v_earning_entity || ',' ||
                                      v_payment_entity ||
                                      v_period_columns_list ||
                                      v_columns_list ||
                                      v_projected_column ||
                                    ',PROCESSED_DATE_TIME)
                     select ' || commons_appframework.get_row_identifier_sequence(pi_payment_roster_table, v_period_id) || '.nextval,
                            0,' ||
                            v_earning_entity || ',' ||
                            v_payment_entity ||
                            v_period_values_list ||
                            v_columns_list ||
                            v_projected ||
                         ', cast(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' as date)
                       from ' || '(select distinct ' || pi_earning_roster_table || '.' || v_earning_entity || ',' ||
                                          pi_payment_entity_table || '.e_internal_id ' || v_payment_entity ||
                                          v_period_values_list ||
                                          v_prefixed_columns_list ||
                                   ' from ' || pi_earning_roster_table ||
                              ' left join ' ||
                               case when pi_date_filter is not null or pi_filter is not null
                                    then '(select ' || pi_payment_assignment_table || '.' || v_earning_entity || ',' ||
                                                  pi_payment_assignment_table || '.' || v_payment_entity ||
                                           ' from ' ||
                                       case when pi_date_filter is not null
                                            then '(select *
                                                     from ' || pi_payment_assignment_table ||
                                                  ' where ' || pi_date_filter ||
                                                  ') '
                                        end ||
                                                     pi_payment_assignment_table ||
                                           ' join ' || pi_earning_entity_table ||
                                             ' on ' || pi_payment_assignment_table || '.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                                           ' join ' || pi_payment_entity_table ||
                                             ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.e_internal_id' ||
                                case when pi_filter is not null
                                     then ' where ' || pi_filter
                                 end ||
                                          ')'
                                end ||
                                             pi_payment_assignment_table ||
                                     ' on ' || pi_earning_roster_table || '.' || v_earning_entity || ' = ' || pi_payment_assignment_table || '.' || v_earning_entity ||
                              ' left join ' || pi_payment_entity_table ||
                                     ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.e_internal_id' ||
                         case when pi_selected_payment_roster is not null
                              then ' join ' || pi_selected_payment_roster ||
                                     ' on ' || pi_earning_roster_table || '.' || v_earning_entity || ' = ' || pi_selected_payment_roster || '.' || v_earning_entity ||
                                    ' and ' || commons_utils.get_equal_match_condition(pi_payment_assignment_table || '.' || v_payment_entity,
                                                                                       pi_selected_payment_roster || '.' || v_payment_entity,
                                                                                       1,
                                                                                       6)
                          end ||
                                  ')';
    -- delete existing records from roster table
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_delete_sql) ,',v_delete_sql', v_stamp);
    execute immediate v_delete_sql;
    -- insert new records in roster table
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_insert_sql') ,',v_insert_sql', v_stamp);
    execute immediate v_insert_sql;
    po_processed_records := sql%rowcount;
    -- repopulate temporary roster table to catch all data changes in the roster table
    if pi_selected_payment_roster is not null and (pi_selected_from_job = 0 or pi_selected_from_job is null) then
      repopulate_temp_roster(pi_payment_roster_table, 2, v_earning_entity, v_payment_entity, pi_run_id, pi_selected_payment_roster);
    end if;
  end update_payment_roster;

  procedure validate_roster(pi_earning_entity_column      in varchar2,
                            pi_payment_entity_column      in varchar2,
                            pi_payment_prior_period_id    in number,
                            pi_roster_table               in varchar2,
                            pi_prior_roster_table         in varchar2,
                            pi_selected_roster_table      in varchar2,
                            pi_added_validation           in number,
                            pi_removed_validation         in number,
                            po_validations_results        out sys_refcursor) as
    v_count                 integer;
    v_entity                varchar2(30);
    v_added_validation      varchar2(100);
    v_removed_validation    varchar2(100);
    v_added_validation_id   integer;
    v_removed_validation_id integer;
    v_added                 varchar2(10);
    v_removed               varchar2(10);
    v_validation_sql        clob;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.VALIDATE_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_earning_entity_column) ,',pi_earning_entity_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_payment_entity_column) ,',pi_payment_entity_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_prior_period_id) ,',pi_payment_prior_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_roster_table) ,',pi_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_prior_roster_table) ,',pi_prior_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_selected_roster_table) ,',pi_selected_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_added_validation) ,',pi_added_validation => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_removed_validation) ,',pi_removed_validation => <value>', v_stamp);
    -- check if the prior period is defined
	  if pi_payment_prior_period_id is null or pi_prior_roster_table is null then
      -- if not, skip validations
      open po_validations_results for select 0 validation, 0 entity from dual;
    else
      -- if the period is defined check for records for the prior period
      v_count := commons.check_record_existence('select * from ' || pi_prior_roster_table);
      if v_count = 0 then
        -- if there are no records, skip validations
        open po_validations_results for select 0 validation, 0 entity from dual;
      else
        -- if there are records, perform required validations
        -- set entity to be checked, earning or payment
        if pi_payment_entity_column is not null then
          v_entity := pi_payment_entity_column;
        else
          v_entity := pi_earning_entity_column;
        end if;
        -- set validation ids, earning or payment
        if pi_added_validation = 1 then
          v_added_validation := ' when added is not null then ';
          v_added := 'added';
          if pi_payment_entity_column is not null then
            v_added_validation_id := 3;
          else
            v_added_validation_id := 1;
          end if;
        end if;
        if pi_removed_validation = 1 then
          v_removed_validation := ' when removed is not null then ';
          v_removed := 'removed';
          if pi_payment_entity_column is not null then
            v_removed_validation_id := 4;
          else
            v_removed_validation_id := 2;
          end if;
        end if;
        -- build validation subquery
        v_validation_sql := 'with source as (select new.' || v_entity || ' added,
                                                    old.' || v_entity || ' removed
                                              from (select ' || v_entity ||
                                                    ' from ' || pi_roster_table ||
                                         case when pi_selected_roster_table is not null
                                              then ' where ' || v_entity || ' in (select ' || v_entity ||
                                                                                ' from ' || pi_selected_roster_table || ') '
                                            end || ') new
                                   full outer join (select ' || v_entity ||
                                                    ' from ' || pi_prior_roster_table ||
                                         case when pi_selected_roster_table is not null
                                              then ' where ' || v_entity || ' in (select ' || v_entity ||
                                                                                ' from ' || pi_selected_roster_table || ') '
                                            end || ') old
                                                on new.' || v_entity || ' = old.' || v_entity ||
                                           ' where new.' || v_entity || ' is null
                                                or old.' || v_entity || ' is null
                                             )';
        -- build validation query
        v_validation_sql := v_validation_sql || ' select distinct validation,
                                                         entity from (select case' || v_added_validation ||
                                                                                      v_added_validation_id ||
                                                                                      v_removed_validation ||
                                                                                      v_removed_validation_id ||
                                                                            ' end validation,
                                                                             case ' || v_added_validation ||
                                                                                       v_added ||
                                                                                       v_removed_validation ||
                                                                                       v_removed ||
                                                                            ' end entity
                                                                        from source)
                                                               where validation is not null
                                                            order by validation, entity';
        open po_validations_results for v_validation_sql;
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_validation_sql') ,',v_validation_sql', v_stamp);
      end if;
    end if;
  end validate_roster;

  procedure create_temp_earnings_for_jobs(pi_earning_entity_table       in varchar2,
                                          pi_earning_entity_id          in number,
                                          pi_assignment_table           in varchar2,
                                          pi_assignment_entity_table    in varchar2,
                                          pi_assignment_entity_id       in number,
                                          pi_columns_list               in TABLETYPE_NAME_MAP,
                                          pi_payment_timeunit_column    in varchar2,
                                          pi_projected_timeunit_column  in varchar2,
                                          pi_projected_field_column     in varchar2,
                                          pi_payment_period_id          in number,
                                          pi_projected_period_id        in number,
                                          pi_projected_field_value      in number,
                                          pi_run_id                     in number,
                                          pi_earning_roster_table       in varchar2,
                                          pi_master_roster_table        in varchar2,
                                          pi_plan_id                    in number,
                                          pi_temp_earnings_roster_table in varchar2)
  as
    v_insert_sql            clob;
    v_period_columns_list   varchar2(62);
    v_period_values_list    varchar2(62);
    v_period_id             number;
    v_columns_list          varchar2(32767);
    v_prefixed_columns_list varchar2(32767);
    v_earning_entity        varchar2(30);
    v_assignment_entity     varchar2(30);
    v_projected_column      varchar2(30);
    v_projected             varchar2(30);
    v_input_columns_list    TABLETYPE_NAME_MAP;
    v_start_date            date;
    v_end_date              date;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.CREATE_TEMP_EARNINGS_FOR_JOBS - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id )  ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_assignment_table)   ,',pi_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_assignment_entity_table)  ,',pi_assignment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_assignment_entity_id)    ,',pi_assignment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(pi_columns_list) ,',pi_columns_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_timeunit_column) ,',pi_payment_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_projected_timeunit_column ) ,',pi_projected_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_projected_field_column ) ,',pi_projected_field_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_period_id )  ,',pi_payment_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_period_id )  ,',pi_projected_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_field_value )  ,',pi_projected_field_value => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id )  ,',pi_run_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_roster_table)  ,',pi_earning_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_master_roster_table)  ,',pi_master_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_plan_id)       ,',pi_plan_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_temp_earnings_roster_table)       ,',pi_temp_earnings_roster_table => <value>', v_stamp);

    -- 1.30:
    -- this code is 90% duplicate of update_earnings_roster
    -- in a lighter sprint this code will be refactored

    -- 1.31:
    -- the code was triplicated in check_earnings_roster procedure
    -- i begin to accept the fact that the refactoring will never be performed

    -- create temporary roster with the same structure as the earnings roster
    execute immediate 'create table ' || pi_temp_earnings_roster_table || ' as select * from ' || pi_earning_roster_table || ' where 1 = 0';
    -- set period and projected period columns and values
    if pi_projected_timeunit_column is null then
      v_period_columns_list := ',' || pi_payment_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id;
      v_period_id           := pi_payment_period_id;
    else
      v_period_columns_list := ',' || pi_payment_timeunit_column || ',' || pi_projected_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id || ',' || pi_projected_period_id;
      v_period_id           := pi_projected_period_id;
    end if;
    -- set projected column
    if pi_projected_timeunit_column is not null then
      v_projected_column := ',' || pi_projected_field_column;
      v_projected        := ',' || pi_projected_field_value;
    end if;
    -- set columns list (one non-prefixed list for the insert and one prefixed list for the select)
    if pi_columns_list is not null and pi_columns_list.first is not null then
      v_input_columns_list := pi_columns_list;
      for i in v_input_columns_list.first .. v_input_columns_list.last loop
        v_columns_list          := v_columns_list || ',' || v_input_columns_list(i).NAME2;
        v_prefixed_columns_list := v_prefixed_columns_list || ',' || v_input_columns_list(i).NAME1 || '.' || v_input_columns_list(i).NAME2;
      end loop;
    end if;
    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get assignment entity name in roster table
    if pi_assignment_table is not null and pi_assignment_entity_table is not null then
      v_assignment_entity := 'E' || pi_assignment_entity_id;
    end if;
    -- get start date and end date for the period
    if pi_projected_timeunit_column is null then
      commons_timeunits.get_period_start_end_date(pi_payment_period_id,v_start_date,v_end_date);
    else
      commons_timeunits.get_period_start_end_date(pi_projected_period_id,v_start_date,v_end_date);
    end if;
    -- build insert new records in roster table statement
    v_insert_sql := 'insert into ' || pi_temp_earnings_roster_table ||
                                    '(row_identifier,row_version,' ||
                                      v_earning_entity ||
                     case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                          then ',' || v_assignment_entity
                      end ||          v_period_columns_list ||
                                      v_columns_list ||
                                      v_projected_column ||
                                     ',PROCESSED_DATE_TIME)
                     select ' || commons_appframework.get_row_identifier_sequence(pi_earning_roster_table, v_period_id) || '.nextval,
                            0,' ||
                            v_earning_entity ||
           case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                then ',' || v_assignment_entity
            end ||          v_period_values_list ||
                            v_columns_list ||
                            v_projected ||
                         ', cast(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' as date)
                       from (select ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                  case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                       then ', ' || pi_assignment_entity_table || '.e_internal_id ' ||
                                    v_assignment_entity
                   end ||           v_period_values_list ||
                                    v_prefixed_columns_list ||
                             ' from ' ||
                          case when pi_master_roster_table is not null
                               then '(select distinct ' || v_earning_entity ||
                                      ' from ' || pi_master_roster_table ||
                                     ' where plan_name = ' || pi_plan_id ||
                                       ' and nvl(start_date,' || CON_EXTREME_DATE || ') <= nvl(''' || v_end_date || ''',' || CON_EXTREME_DATE || ')' ||
                                       ' and nvl(end_date,' || CON_EXTREME_DATE_MAX || ') >= nvl(''' || v_start_date || ''',' || CON_EXTREME_DATE_MAX || ')' ||
                                     ') ' || pi_master_roster_table ||
                             ' join '
                           end ||

                             '(select distinct ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                               case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                                    then ', max(' || pi_assignment_entity_table || '.e_internal_id) ' || v_assignment_entity end ||
                                     ' from ' || pi_earning_entity_table ||
                           case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                                then ' join (select ' || v_earning_entity || ',' ||
                                                    v_assignment_entity ||
                                             ' from ' || pi_assignment_table ||
                                  /*case when pi_date_filter is not null
                                       then ' where ' || pi_date_filter
                                   end ||*/
                                           ' ) ' || pi_assignment_table ||
                                       ' on ' || pi_earning_entity_table || '.e_internal_id = ' || pi_assignment_table || '.' || v_earning_entity ||
                                     ' join ' || pi_assignment_entity_table ||
                                       ' on ' ||  pi_assignment_table || '.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id'
                            end ||

                                     -- plan run data details instead of pi selected
                                     ' join plan_run_data_details' ||
                                       ' on prdd_prd_id = ' || pi_run_id ||
                                      ' and ' || pi_earning_entity_table || '.e_internal_id = plan_run_data_details.prdd_earning_entity_id' ||

                          /*case when pi_filter is not null
                               then ' where ' || pi_filter
                           end ||*/
                          case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                               then ' group by ' || pi_earning_entity_table || '.e_internal_id'
                           end ||
                                   ') ass' ||

                          case when pi_master_roster_table is not null
                               then ' on ' || pi_master_roster_table || '.' || v_earning_entity || ' = ass.' || v_earning_entity
                           end ||
                             ' join ' || pi_earning_entity_table ||
                             ' on ass.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                 case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                      then ' join ' || pi_assignment_entity_table ||
                             ' on ass.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id'
                  end ||
                            ')';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_insert_sql') ,',v_insert_sql', v_stamp);
    execute immediate v_insert_sql;

  end create_temp_earnings_for_jobs;

  procedure create_temp_payment_for_jobs(pi_earning_entity_id          in number,
                                         pi_payment_assignment_table   in varchar2,
                                         pi_payment_entity_table       in varchar2,
                                         pi_payment_entity_id          in number,
                                         pi_columns_list               in TABLETYPE_NAME_MAP,
                                         pi_payment_timeunit_column    in varchar2,
                                         pi_projected_timeunit_column  in varchar2,
                                         pi_projected_field_column     in varchar2,
                                         pi_payment_period_id          in number,
                                         pi_projected_period_id        in number,
                                         pi_projected_field_value      in number,
                                         pi_run_id                     in number,
                                         pi_temp_earnings_roster_table in varchar2,
                                         pi_payment_roster_table       in varchar2,
                                         pi_temp_payment_roster_table  in varchar2) as
    v_insert_sql            clob;
    v_period_id             number;
    v_period_columns_list   varchar2(62);
    v_period_values_list    varchar2(62);
    v_columns_list          varchar2(32767);
    v_prefixed_columns_list varchar2(32767);
    v_earning_entity        varchar2(30);
    v_payment_entity        varchar2(30);
    v_projected_column      varchar2(30);
    v_projected             varchar2(30);
    v_input_columns_list    TABLETYPE_NAME_MAP;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.CREATE_TEMP_PAYMENT_FOR_JOBS - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id )  ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_assignment_table)   ,',pi_payment_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_entity_table)  ,',pi_payment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_entity_id)    ,',pi_payment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(pi_columns_list )    ,',pi_columns_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_timeunit_column )    ,',pi_payment_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_projected_timeunit_column)    ,',pi_projected_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_projected_field_column )    ,',pi_projected_field_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_period_id    )    ,',pi_payment_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_period_id )    ,',pi_projected_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_field_value)    ,',pi_projected_field_value => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id  )    ,',pi_run_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_temp_earnings_roster_table)    ,',pi_temp_earnings_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_roster_table )    ,',pi_payment_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_temp_payment_roster_table)    ,',pi_temp_payment_roster_table => <value>', v_stamp);

    -- same comments about refactoring as for create_temp_earnings_for_jobs

    -- create temporary roster with the same structure as the payment roster
    execute immediate 'create table ' || pi_temp_payment_roster_table || ' as select * from ' || pi_payment_roster_table || ' where 1 = 0';
    -- set period and projected period columns and values
    if pi_projected_timeunit_column is null then
      v_period_columns_list := ',' || pi_payment_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id;
      v_period_id           := pi_payment_period_id;
    else
      v_period_columns_list := ',' || pi_payment_timeunit_column || ',' || pi_projected_timeunit_column;
      v_period_values_list  := ',' || pi_payment_period_id || ',' || pi_projected_period_id;
      v_period_id           := pi_projected_period_id;
    end if;
    -- set projected column
    if pi_projected_timeunit_column is not null then
      v_projected_column := ',' || pi_projected_field_column;
      v_projected        := ',' || pi_projected_field_value;
    end if;
    -- set columns list (one non-prefixed list for the insert and one prefixed list for the select)
    if pi_columns_list is not null then
      v_input_columns_list := pi_columns_list;
      for i in v_input_columns_list.first .. v_input_columns_list.last loop
        v_columns_list          := v_columns_list || ',' || v_input_columns_list(i).NAME2;
        v_prefixed_columns_list := v_prefixed_columns_list || ',' || v_input_columns_list(i).NAME1 || '.' || v_input_columns_list(i).NAME2;
      end loop;
    end if;
    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get payment entity name in roster table
    v_payment_entity := 'E' || pi_payment_entity_id;
    -- build insert new records in roster table statement
    v_insert_sql := 'insert into ' || pi_temp_payment_roster_table ||
                                    '(row_identifier,
                                      row_version,' ||
                                      v_earning_entity || ',' ||
                                      v_payment_entity ||
                                      v_period_columns_list ||
                                      v_columns_list ||
                                      v_projected_column ||
                                    ',PROCESSED_DATE_TIME)
                     select ' || commons_appframework.get_row_identifier_sequence(pi_payment_roster_table, v_period_id) || '.nextval,
                            0,' ||
                            v_earning_entity || ',' ||
                            v_payment_entity ||
                            v_period_values_list ||
                            v_columns_list ||
                            v_projected ||
                         ', cast(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' as date)
                       from ' || '(select distinct ' || pi_temp_earnings_roster_table || '.' || v_earning_entity || ',' ||
                                          pi_payment_entity_table || '.e_internal_id ' || v_payment_entity ||
                                          v_period_values_list ||
                                          v_prefixed_columns_list ||
                                   ' from ' || pi_temp_earnings_roster_table ||
                              ' left join ' ||
                               /*case when pi_date_filter is not null or pi_filter is not null
                                    then '(select ' || pi_payment_assignment_table || '.' || v_earning_entity || ',' ||
                                                  pi_payment_assignment_table || '.' || v_payment_entity ||
                                           ' from ' ||
                                       case when pi_date_filter is not null
                                            then '(select *
                                                     from ' || pi_payment_assignment_table ||
                                                  ' where ' || pi_date_filter ||
                                                  ') '
                                        end ||
                                                     pi_payment_assignment_table ||
                                           ' join ' || pi_earning_entity_table ||
                                             ' on ' || pi_payment_assignment_table || '.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                                           ' join ' || pi_payment_entity_table ||
                                             ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.e_internal_id' ||
                                case when pi_filter is not null
                                     then ' where ' || pi_filter
                                 end ||
                                          ')'
                                end ||*/
                                             pi_payment_assignment_table ||
                                     ' on ' || pi_temp_earnings_roster_table || '.' || v_earning_entity || ' = ' || pi_payment_assignment_table || '.' || v_earning_entity ||
                              ' left join ' || pi_payment_entity_table ||
                                     ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.e_internal_id' ||

                                    -- plan run data details instead of pi selected
                                     ' join plan_run_data_details' ||
                                       ' on prdd_prd_id = ' || pi_run_id ||
                                      ' and ' || pi_temp_earnings_roster_table || '.' || v_earning_entity || ' = plan_run_data_details.prdd_earning_entity_id' ||
                                      ' and ' || commons_utils.get_equal_match_condition(pi_payment_entity_table || '.e_internal_id',
                                                                                         'plan_run_data_details.prdd_payment_entity_id',
                                                                                         1,
                                                                                         6) ||
                                  ')';
    -- insert new records in roster table
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_insert_sql') ,',v_insert_sql', v_stamp);
    execute immediate v_insert_sql;
  end create_temp_payment_for_jobs;

  procedure check_earnings_roster(pi_earning_entity_table      in varchar2,
                                  pi_earning_entity_id         in number,
                                  pi_assignment_table          in varchar2,
                                  pi_assignment_entity_table   in varchar2,
                                  pi_assignment_entity_id      in number,
                                  pi_projected_timeunit_column in varchar2,
                                  pi_payment_period_id         in number,
                                  pi_projected_period_id       in number,
                                  pi_filter                    in varchar2,
                                  pi_date_filter               in varchar2,
                                  pi_master_roster_table       in varchar2,
                                  pi_plan_id                   in number,
                                  po_records_exist            out number) as
    v_insert_sql            clob;
    v_earning_entity        varchar2(30);
    v_assignment_entity     varchar2(30);
    v_start_date            date;
    v_end_date              date;
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.CHECK_EARNINGS_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id )  ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_assignment_table)   ,',pi_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_assignment_entity_table)  ,',pi_assignment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_assignment_entity_id)    ,',pi_assignment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_projected_timeunit_column ) ,',pi_projected_timeunit_column => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_period_id)    ,',pi_payment_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_projected_period_id)     ,',pi_projected_period_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_filter)  ,',pi_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_date_filter)        ,',pi_date_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_master_roster_table)  ,',pi_master_roster_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_plan_id)       ,',pi_plan_id => <value>', v_stamp);

    -- same comments about refactoring as for create_temp_earnings_for_jobs

    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get assignment entity name in roster table
    if pi_assignment_table is not null and pi_assignment_entity_table is not null then
      v_assignment_entity := 'E' || pi_assignment_entity_id;
    end if;
    -- get start date and end date for the period
    if pi_projected_timeunit_column is null then
      commons_timeunits.get_period_start_end_date(pi_payment_period_id,v_start_date,v_end_date);
    else
      commons_timeunits.get_period_start_end_date(pi_projected_period_id,v_start_date,v_end_date);
    end if;
    -- build insert new records in roster table statement
    v_insert_sql := 'select 1
                       from (select ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                  case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                       then ', ' || pi_assignment_entity_table || '.e_internal_id ' ||
                                    v_assignment_entity
                   end ||
                             ' from ' ||
                          case when pi_master_roster_table is not null
                               then '(select distinct ' || v_earning_entity ||
                                      ' from ' || pi_master_roster_table ||
                                     ' where plan_name = ' || pi_plan_id ||
                                       ' and nvl(start_date,' || CON_EXTREME_DATE || ') <= nvl(''' || v_end_date || ''',' || CON_EXTREME_DATE || ')' ||
                                       ' and nvl(end_date,' || CON_EXTREME_DATE_MAX || ') >= nvl(''' || v_start_date || ''',' || CON_EXTREME_DATE_MAX || ')' ||
                                     ') ' || pi_master_roster_table ||
                             ' join '
                           end ||

                             '(select distinct ' || pi_earning_entity_table || '.e_internal_id ' || v_earning_entity ||
                               case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                                    then ', max(' || pi_assignment_entity_table || '.e_internal_id) ' || v_assignment_entity end ||
                                     ' from ' || pi_earning_entity_table ||
                           case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                                then ' join (select ' || v_earning_entity || ',' ||
                                                    v_assignment_entity ||
                                             ' from ' || pi_assignment_table ||
                                  case when pi_date_filter is not null
                                       then ' where ' || pi_date_filter
                                   end ||
                                           ' ) ' || pi_assignment_table ||
                                       ' on ' || pi_earning_entity_table || '.e_internal_id = ' || pi_assignment_table || '.' || v_earning_entity ||
                                     ' join ' || pi_assignment_entity_table ||
                                       ' on ' ||  pi_assignment_table || '.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id'
                            end ||
                          case when pi_filter is not null
                               then ' where ' || pi_filter
                           end ||
                          case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                               then ' group by ' || pi_earning_entity_table || '.e_internal_id'
                           end ||
                                   ') ass' ||

                          case when pi_master_roster_table is not null
                               then ' on ' || pi_master_roster_table || '.' || v_earning_entity || ' = ass.' || v_earning_entity
                           end ||
                             ' join ' || pi_earning_entity_table ||
                             ' on ass.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                 case when pi_assignment_table is not null and pi_assignment_entity_table is not null
                      then ' join ' || pi_assignment_entity_table ||
                             ' on ass.' || v_assignment_entity || ' = ' || pi_assignment_entity_table || '.e_internal_id'
                  end ||
                            ')';
    -- check if at least one record will be inserted
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_insert_sql') ,',v_insert_sql', v_stamp);
    po_records_exist := commons.check_record_existence(v_insert_sql);
  end check_earnings_roster;

  procedure check_payment_roster(pi_earning_entity_table      in varchar2,
                                 pi_earning_entity_id         in number,
                                 pi_payment_assignment_table  in varchar2,
                                 pi_payment_entity_table      in varchar2,
                                 pi_payment_entity_id         in number,
                                 pi_filter                    in varchar2,
                                 pi_date_filter               in varchar2,
                                 pi_earning_roster_table      in varchar2,
                                 po_records_exist            out number) as
    v_insert_sql            clob;
    v_earning_entity        varchar2(30);
    v_payment_entity        varchar2(30);
    v_stamp varchar2(250 char):= 'ROSTER_PROCESSING.CHECK_PAYMENT_ROSTER - Output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_entity_table) ,',pi_earning_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_earning_entity_id )  ,',pi_earning_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_assignment_table)   ,',pi_payment_assignment_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_payment_entity_table)  ,',pi_payment_entity_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_payment_entity_id)    ,',pi_payment_entity_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_filter)  ,',pi_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_date_filter)        ,',pi_date_filter => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_earning_roster_table)  ,',pi_earning_roster_table => <value>', v_stamp);

    -- same comments about refactoring as for create_temp_earnings_for_jobs

    -- get entity name in roster table
    v_earning_entity := 'E' || pi_earning_entity_id;
    -- get payment entity name in roster table
    v_payment_entity := 'E' || pi_payment_entity_id;
    -- build insert new records in roster table statement
    v_insert_sql := 'select 1
                       from ' || '(select distinct ' || pi_earning_roster_table || '.' || v_earning_entity || ',' ||
                                          pi_payment_entity_table || '.e_internal_id ' || v_payment_entity ||
                                   ' from ' || pi_earning_roster_table ||
                              ' left join ' ||
                               case when pi_date_filter is not null or pi_filter is not null
                                    then '(select ' || pi_payment_assignment_table || '.' || v_earning_entity || ',' ||
                                                  pi_payment_assignment_table || '.' || v_payment_entity ||
                                           ' from ' ||
                                       case when pi_date_filter is not null
                                            then '(select *
                                                     from ' || pi_payment_assignment_table ||
                                                  ' where ' || pi_date_filter ||
                                                  ') '
                                        end ||
                                                     pi_payment_assignment_table ||
                                           ' join ' || pi_earning_entity_table ||
                                             ' on ' || pi_payment_assignment_table || '.' || v_earning_entity || ' = ' || pi_earning_entity_table || '.e_internal_id' ||
                                           ' join ' || pi_payment_entity_table ||
                                             ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.e_internal_id' ||
                                case when pi_filter is not null
                                     then ' where ' || pi_filter
                                 end ||
                                          ')'
                                end ||
                                             pi_payment_assignment_table ||
                                     ' on ' || pi_earning_roster_table || '.' || v_earning_entity || ' = ' || pi_payment_assignment_table || '.' || v_earning_entity ||
                              ' left join ' || pi_payment_entity_table ||
                                     ' on ' || pi_payment_assignment_table || '.' || v_payment_entity || ' = ' || pi_payment_entity_table || '.e_internal_id' ||
                                  ')';
    -- check if at least one record will be inserted
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB('v_insert_sql') ,',v_insert_sql', v_stamp);
    po_records_exist := commons.check_record_existence(v_insert_sql);
  end check_payment_roster;

-- *******************************    PUBLIC PROCEDURES END         *******************************

end rosters_processing;
/
