CREATE package DT_WGTSUM as

  procedure calculate_weighted_sum(pi_dto_id         in number,
                                   pi_in_table       in number,
                                   pi_result_table   in number,
                                   pi_io_alias       in varchar2,
                                   pi_ip_filter      in varchar2,
                                   pi_ip_join_clause in varchar2,
                                   pi_op_filter      in varchar2,
                                   pi_op_join_clause in varchar2,
                                   po_error_code     out number,
                                   po_parameter_name out varchar2,
                                   po_records_count  out number);
  type ws_overlap_rec is record(
    low_bound varchar2(200),
    up_bound  varchar2(200));
  type ws_overlap_tab is table of ws_overlap_rec;

end;
/
