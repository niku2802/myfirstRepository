CREATE PACKAGE VALIDATIONS AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: COMPENSATION
-- Module			: COMPENSATION-PROCESSING
-- Description		: All validations related items
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************

TYPE RECTYPE_VALIDATION_RESULTS IS RECORD
(	 VALIDATION_ID		NUMBER
	,VALIDATION_TYPE	VARCHAR2(100)
	,VALIDATION_DETAILS	CLOB
);

TYPE TCOL_PRIOR_VALUES_COLS IS TABLE OF VARCHAR2(200 CHAR) INDEX BY PLS_INTEGER;
TYPE TREC_PRIOR_TABLE IS RECORD (TABLE_NAME      VARCHAR2(200 CHAR)
                                ,WHERE_CLAUSE    CLOB);
TYPE TCOL_PRIOR_TABLES IS TABLE OF TREC_PRIOR_TABLE INDEX BY PLS_INTEGER;

-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************

/* GET_PREV_FROM_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_PREV_FROM_STRING
(	 pin_curr_table_alias	IN VARCHAR2
	,pin_entity_cols		IN TABLETYPE_NAME_MAP
	,pin_prior_tables		IN TCOL_PRIOR_TABLES
) RETURN CLOB;


/* GET_TARGET_FROM_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TARGET_FROM_STRING
(	 pin_curr_table_alias	IN VARCHAR2
	,pin_entity_cols		IN TABLETYPE_NAME_MAP
	,pin_target_table		IN OBJTYPE_INPUT_TABLE_LIST
	,pin_target_agg_type	IN NUMBER
) RETURN CLOB;


/* GET_ROW_ID_COLUMNS_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ROW_ID_COLUMNS_STRING
(	pin_entity_cols		IN TABLETYPE_NAME_MAP
) RETURN CLOB;


/* GET_ROW_ID_VALUES_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ROW_ID_VALUES_STRING
(	pin_entity_cols		IN TABLETYPE_NAME_MAP
) RETURN CLOB;


/* GET_ENT_ID_COLUMNS_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ENT_ID_COLUMNS_STRING
(	pin_entity_cols		IN TABLETYPE_NAME_MAP
) RETURN CLOB;


/*	GET_WHEN_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_WHEN_STRING
(	 pin_validation_def		IN OBJTYPE_VALIDATION_DEF
	,pin_insert_col_list	IN CLOB
	,pin_insert_val_list	IN CLOB
) RETURN CLOB;


/*	GET_SELECT_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SELECT_STRING
(	 pin_validation_def		IN OBJTYPE_VALIDATION_DEF
	,pin_curr_val			IN VARCHAR2
	,pin_prior_val			IN VARCHAR2
	,pin_trgt_val			IN VARCHAR2
	,pin_avg_val			IN VARCHAR2
) RETURN CLOB;


/*	GET_VLD_STRING START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_VLD_STRING
(	 pin_validation_def		IN OBJTYPE_VALIDATION_DEF
) RETURN CLOB;

-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************

/*	PREPARE_PREREQUISITES START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	: intended to be private. they are public only for testing purposes.
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
PROCEDURE PREPARE_PREREQUISITES
(	 pin_prior_tables			IN TABLETYPE_INPUT_TABLE_LIST
	,pin_prior_values_cols		IN TABLETYPE_ID_NAME
    ,pio_validation_defs		IN OUT NOCOPY TABLETYPE_VALIDATION_DEF
	,pout_prior_tables			OUT TCOL_PRIOR_TABLES
    ,pout_prior_values_cols		OUT TCOL_PRIOR_VALUES_COLS
);


/* GET_VALIDATIONS_VALUES START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	:
-----------------------------------------------------------------------------------------------
-- Assumptions:
	 pin_validation_defs		IN TABLETYPE_VALIDATION_DEF
		-	NOT NULL.
		-	the list of definition properties for each validation.
		-	members:
			*	ID - NUMBER - NOT NULL - the id of the validation (1, 67, 75).
			*	VALUE_TO_VALIDATE - NUMBER - NOT NULL -	0	value_of_column
														1	change in value_of_column
														2	percent change in value_of_column
														3	value_of_column percent of target
														4	value_of_column minus average value
			*	COMPARISON_CONDITION - NUMBER - NOT NULL -	0	greater than
															1	greater than or equal to
															2	less than
															3	less than or equal to
			*	COMPARISON_VALUE - NUMBER - NOT NULL - the value to compare against.
			*	TRIGGER_CONDITION_TYPE - NUMBER - NOT NULL -	0	any records
																1	<value> or more records
																2	<value>% of records
			*	TRIGGER_CONDITION_VALUE - NUMBER - NOT NULL - the number/percent of records that trigger the validation.
			*	SEVERITY - NUMBER - NOT NULL -	0	warning
												1	error
			*	PRIOR_TABLE_ID - NUMBER - NOT NULL if validation uses prior period values - index of table from "pin_prior_tables"
		-	ex: TABLETYPE_VALIDATION_DEF(	 OBJTYPE_VALIDATION_DEF(432, 1, 1, 100, 1, 30, 0, 0)
											,OBJTYPE_VALIDATION_DEF(32, 0, 1, 100, 2, 40, 1, 1)
											,OBJTYPE_VALIDATION_DEF(5, 1, 3, 600, 2, 33, 1, 2))

	,pin_curr_table_alias		IN VARCHAR2
	 	-	NOT NULL
		-	it is the alias of the subquery which has to contain the columns below:
			*	all the entity columns in "pin_entity_cols" used to join with the previous period tables.
			*	if at least one of the validations requires average values, then a column named
				VALIDATIONS_AVG_VALUE that contains the average value of the field to be validated
				for all entities.
		-	ex: 'T1020', 'S', 'I', 'METRIC_TABLE'

	,pin_curr_values_col		IN VARCHAR2
		-	NOT NULL
		-	the name of the column from the current period that holds the values to be validated.
		-	ex: 'METRIC', 'DETAILED_EARNINGS', 'PAYMENTS_DUE'

	,pin_entity_cols			IN TABLETYPE_NAME_MAP
		-	NOT NULL
		-	the list of columns that form the entity.
		-	members:
			*	NAME1 - VARCHAR2 - NOT NULL - name of the entity internal id column or name of field.
			*	NAME2 - VARCHAR2 - NOT NULL if name1 is an internal id - name of the businees key column.
		-	ex: TABLETYPE_NAME_MAP(	 OBJTYPE_NAME_MAP('E10', 'F10')
									,OBJTYPE_NAME_MAP('E54', 'F54')
									,OBJTYPE_NAME_MAP('F344', null)
									,OBJTYPE_NAME_MAP('F654', null))

	,pin_prior_tables			IN TABLETYPE_INPUT_TABLE_LIST
		-	NOT NULL if there is at least one validation that uses prior periods.
		-	the list of prior period tables used in the validation definitions.
		-	members:
			*	TABLE_NAME - VARCHAR2 - NOT NULL - physical table name.
			*	FROM_CLAUSE - CLOB - NULL.
			*	WHERE_CLAUSE - CLOB - NOT NULL - where clause that contains the period filter.
			*	TABLE_TYPE - NUMBER - NULL.
			*	INPUT_NUMBER - NUMBER - NULL.
		-	ex: TABLETYPE_INPUT_TABLE_LIST(	 OBJTYPE_INPUT_TABLE_LIST('T1001', NULL, 'F50 = 243', NULL, NULL)
											,OBJTYPE_INPUT_TABLE_LIST('T1045', NULL, 'F50 = 453', NULL, NULL)
											,OBJTYPE_INPUT_TABLE_LIST('T4061', NULL, 'F50 = 432', NULL, NULL))

	,pin_prior_values_col		IN TABLETYPE_ID_NAME
		-	NOT NULL if there is at least one validation that uses previous periods.
		-	the name of the columns from the previous periods that hold the values to be validated.
		-	ex: 'METRIC', 'DETAILED_EARNINGS', 'PAYMENTS_DUE'
        -   for each period can be a different column name if they belong to differet periods
        -   members:
            *   ID - index of table from "pin_prior_tables" - the same as the one used in "pin_validation_defs"
            *   NAME - name of the column in the physical table

	,pin_target_table			IN OBJTYPE_INPUT_TABLE_LIST
		-	NOT NULL if there is at least one validation that uses target values and the alias
			specified in "pin_curr_tab_alias" does not contain the column TARGET_EARNINGS.
		-	the table that contains the target values for the current period.
		-	members:
			*	TABLE_NAME - VARCHAR2 - NOT NULL - physical table name.
			*	FROM_CLAUSE - CLOB - NULL.
			*	WHERE_CLAUSE - CLOB - NOT NULL - where clause that contains the period filter.
			*	TABLE_TYPE - NUMBER - NULL.
			*	INPUT_NUMBER - NUMBER - NULL.
		-	ex: OBJTYPE_INPUT_TABLE_LIST('T2545', NULL, 'F50 = 243', NULL, NULL)

	,pin_target_agg_type		IN NUMBER
		-	NOT NULL if "pin_target_tab" is not null and aggregate_earnings has been performed.
		-	the aggregation type used in the component processing for AGGREGATED_EARNINGS
		-	1 sum, 2 avg, 3 min, 4 max.

	,pout_vld_when				OUT CLOB
		-	NULL.
		-	the output string which holds the "insert when" clauses related to validations.

	,pout_vld_select			OUT CLOB
		-	NULL.
		-	the output string which holds the "select" clauses related to validations.

	,pout_vld_from				OUT CLOB
		-	NULL.
		-	the output string which holds the "from join" clauses related to validations.

	,pout_vld_get_values		OUT CLOB
		-	NULL.
		-	the output string which holds the query that selects the triggered validations.

-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_VALIDATIONS_VALUES
(	 pin_validation_defs		IN TABLETYPE_VALIDATION_DEF
	,pin_curr_table_alias		IN VARCHAR2
	,pin_curr_values_col		IN VARCHAR2
	,pin_entity_cols			IN TABLETYPE_NAME_MAP
	,pin_prior_tables			IN TABLETYPE_INPUT_TABLE_LIST
	,pin_prior_values_col		IN TABLETYPE_ID_NAME
	,pin_target_table			IN OBJTYPE_INPUT_TABLE_LIST
	,pin_target_agg_type		IN NUMBER
	,pout_vld_when				OUT CLOB
	,pout_vld_select			OUT CLOB
	,pout_vld_from				OUT CLOB
	,pout_vld_get_values		OUT CLOB
);


/* GET_VALIDATIONS_RESULTS START
-- Author		: Dumitriu, Cosmin
-- Create date	: 26 August 2011
-- Reviewer		:
-- Review date	:
-- Description	:
-----------------------------------------------------------------------------------------------
-- Assumptions:
	 pin_vld_query		IN CLOB
	 	-	NOT NULL.
		-	the query returned by the validation framework (4th output parameter).

	,pin_curr_rowcount	IN NUMBER
		-	NOT NULL.
		-	the number of rows from the current period result table.

	,pout_vld_results	OUT SYS_REFCURSOR
		-	NULL.
		-	this is a cursor that will return the validations which have been triggered.
		-	columns:
			*	VALIDATION_ID - NUMBER - the id of the validation which must be triggered
			*	VALIDATION_TYPE - VARCHAR2 - type of validation trigger ERROR/WARNING
			*	VALIDATION_ENT_CNT - NUMBER - the count of all entities that triggered the validation
			*	VALIDATION_DETAILS - TABLETYPE_CHARMAX - the business keys of all entities which have triggered this validation
		-	ex:
		VALIDATION_ID	VALIDATION_TYPE		VALIDATION_ENT_CNT	VALIDATION_DETAILS
		--------------	----------------	-------------------	-------------------
		30				ERROR				7430				TABLETYPE_CHARMAX('"iasi","agent1"', '"iasi","agent2"', '"pune","agent3"')
		60				WARNING				100078				TABLETYPE_CHARMAX('"pune","agent3"', '"iasi","agent1"')

-----------------------------------------------------------------------------------------------
-- Call statement:
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_VALIDATIONS_RESULTS
(	 pin_vld_query		IN CLOB
	,pin_curr_rowcount	IN NUMBER
	,pout_vld_results	OUT SYS_REFCURSOR
);

-- *******************************    PUBLIC PROCEDURES END         *******************************
END VALIDATIONS;
/
