CREATE PACKAGE BODY DATA_EXPORT_PROCESS IS

  PROCEDURE WRITE_TO_FILE(  PIN_QUERY              IN CLOB,
                                      PIN_SEPARATOR          IN VARCHAR2 DEFAULT ',',
                                      PIN_DIR                IN VARCHAR2,
                                      PIN_FILENAME           IN VARCHAR2,
                                      PIN_RECORD_DELIMITER   IN NUMBER,
                                      PIN_INCL_HEADER        IN NUMBER,
                                      PIN_COLUMN_ARRAY       IN COLUMN_ARR,
                                      PIN_CHARACTER_ENCODING VARCHAR2,
                                      POUT_ROW_COUNTER       OUT NUMBER,
                                      POUT_ERROR_CODE        OUT NUMBER) IS

    V_FH           OPTYMYZE_UTL_FILE_TYP.file_type%type;
    V_FILEHANDLER  v_fh%type;
    C               INTEGER DEFAULT DBMS_SQL.OPEN_CURSOR;
    V_COLUMNVALUE   VARCHAR2(31200);
    V_CONVERTED_COL VARCHAR2(31200);
    V_COLUMNHEADER  VARCHAR2(255);
    V_STATUS        INTEGER;
    V_SEPARATOR     VARCHAR2(10);
    V_COL_NO        NUMBER DEFAULT 0;
    V_ROW_COUNTER   NUMBER DEFAULT 0;
    V_CONVERSION    NUMBER(1) := 0;
    V_DB_ENCODING   VARCHAR2(30);
    V_ILLEGAL_CHAR  NUMBER := 0;
    CRLF CONSTANT VARCHAR2(2) := CHR(13) || CHR(10);
    LF   CONSTANT VARCHAR2(1) := CHR(10);
    I                         NUMBER := 0;
    PV_BOM_RAW_UTF8           RAW(3) := HEXTORAW('EFBBBF');
    PV_BOM_RAW_UTF16LE        RAW(2) := HEXTORAW('FFFE');
    PV_BOM_RAW_UTF16BE        RAW(2) := HEXTORAW('FEFF');
    PV_RAW_CRLF               RAW(4);
    --
  BEGIN
    SELECT value
    INTO V_DB_ENCODING
    FROM NLS_DATABASE_PARAMETERS
    where parameter = 'NLS_CHARACTERSET';
  --open file according to the encoding option
    IF PIN_CHARACTER_ENCODING = 'UTF8' THEN -- UTF8
      IF V_DB_ENCODING <> 'WE8MSWIN1252' THEN
        DBMS_XSLPROCESSOR.CLOB2FILE(UTL_I18N.RAW_TO_NCHAR(PV_BOM_RAW_UTF8,
                                                          'UTF8'),
                                    PIN_DIR,
                                    PIN_FILENAME,
                                    NLS_CHARSET_ID('UTF8'));
      END IF;
      V_FILEHANDLER := UTL_FILE_FOPEN(PIN_DIR, PIN_FILENAME, 'AB',32767);
      IF V_DB_ENCODING <> 'AL32UTF8' THEN
         V_CONVERSION  := 1;
      END IF;
    ELSIF PIN_CHARACTER_ENCODING = 'AL16UTF16' THEN -- UTF16BE
     IF V_DB_ENCODING <> 'WE8MSWIN1252' THEN
      DBMS_XSLPROCESSOR.CLOB2FILE(UTL_I18N.RAW_TO_NCHAR(PV_BOM_RAW_UTF16BE,
                                                        'AL16UTF16'),
                                  PIN_DIR,
                                  PIN_FILENAME,
                                  NLS_CHARSET_ID('AL16UTF16'));
      END IF;
   V_FILEHANDLER := UTL_FILE_FOPEN(PIN_DIR, PIN_FILENAME, 'AB',32767);
      V_CONVERSION  := 1;
    ELSIF PIN_CHARACTER_ENCODING = 'AL16UTF16LE' THEN -- UTF16lE
      IF V_DB_ENCODING <> 'WE8MSWIN1252' THEN
        DBMS_XSLPROCESSOR.CLOB2FILE(UTL_I18N.RAW_TO_NCHAR(PV_BOM_RAW_UTF16LE,
                                                          'AL16UTF16LE'),
                                    PIN_DIR,
                                    PIN_FILENAME,
                                    NLS_CHARSET_ID('AL16UTF16LE'));
      END IF;
      V_FILEHANDLER := UTL_FILE_FOPEN(PIN_DIR, PIN_FILENAME, 'AB',32767);
      V_CONVERSION  := 1;
    ELSIF PIN_CHARACTER_ENCODING = 'WE8MSWIN1252' THEN -- ASCII/LATIN1( windows-1252)
      V_FILEHANDLER := UTL_FILE_FOPEN(PIN_DIR, PIN_FILENAME, 'WB',32767);
      V_CONVERSION  := 1;
    ELSE -- OTHER
      V_FILEHANDLER := UTL_FILE_FOPEN(PIN_DIR, PIN_FILENAME, 'WB',32767);
    END IF;

    IF V_DB_ENCODING = PIN_CHARACTER_ENCODING THEN
       V_CONVERSION  := 0;
    END IF;

    PV_RAW_CRLF := CASE WHEN V_CONVERSION = 1 THEN  UTL_RAW.CAST_TO_RAW(CONVERT(CASE
                                                         WHEN PIN_RECORD_DELIMITER = 0 THEN
                                                          LF
                                                         ELSE
                                                          CRLF
                                                       END,
                                                       PIN_CHARACTER_ENCODING))
                   ELSE UTL_RAW.CAST_TO_RAW(CASE WHEN
                                               PIN_RECORD_DELIMITER = 0 THEN LF ELSE CRLF END) END;


    DBMS_SQL.PARSE(C, PIN_QUERY, DBMS_SQL.NATIVE);
    POUT_ERROR_CODE := 0;
    FOR I IN 1 .. 255 LOOP
      BEGIN
        DBMS_SQL.DEFINE_COLUMN(C, I, V_COLUMNVALUE, 31200);
        V_COL_NO := I;
      EXCEPTION
        WHEN OTHERS THEN
          IF (SQLCODE = -1007) THEN
            EXIT;
          ELSE
            RAISE;
          END IF;
      END;
    END LOOP;
    --
    IF PIN_INCL_HEADER = 1 THEN
      FOR I IN 1 .. PIN_COLUMN_ARRAY.LAST LOOP
        IF I = PIN_COLUMN_ARRAY.LAST THEN -- WRITE FILE HEADER
          V_COLUMNHEADER := SUBSTR(PIN_COLUMN_ARRAY(I),
                                   1,
                                   LENGTH(PIN_COLUMN_ARRAY(I)) - 1);
        ELSE
          V_COLUMNHEADER := PIN_COLUMN_ARRAY(I);
        END IF;
        --
        IF V_CONVERSION = 1 THEN
          UTL_FILE_PUT_RAW(V_FILEHANDLER,
                           UTL_RAW.CAST_TO_RAW(CONVERT(V_COLUMNHEADER,
                                                       PIN_CHARACTER_ENCODING)));

        ELSE
          UTL_FILE_PUT_RAW(V_FILEHANDLER,
                           UTL_RAW.CAST_TO_RAW(V_COLUMNHEADER));

        END IF;
      END LOOP;
      -- WRITE RECORD DELIMITER
      UTL_FILE_PUT_RAW(V_FILEHANDLER,PV_RAW_CRLF);
    END IF;

    DBMS_SQL.DEFINE_COLUMN(C, 1, V_COLUMNVALUE, 31200);
    --
    V_STATUS := DBMS_SQL.EXECUTE(C);
    -- PROCESS AND WRITE EACH RESULT COLUMN, ROW BY ROW
    LOOP
      EXIT WHEN(DBMS_SQL.FETCH_ROWS(C) <= 0 OR POUT_ERROR_CODE = 1);
      V_SEPARATOR    := '';
      V_ILLEGAL_CHAR := 0;
      FOR I IN 1 .. V_COL_NO LOOP
        DBMS_SQL.COLUMN_VALUE(C, I, V_COLUMNVALUE);
        V_COLUMNVALUE :=  V_SEPARATOR ||V_COLUMNVALUE;
         IF V_CONVERSION = 1 THEN
          V_CONVERTED_COL := CONVERT(V_COLUMNVALUE,
                                            PIN_CHARACTER_ENCODING,
                                            V_DB_ENCODING);
         ELSE
           V_CONVERTED_COL := V_COLUMNVALUE;
         END IF;
         IF PIN_CHARACTER_ENCODING = 'WE8MSWIN1252' AND  V_DB_ENCODING <> PIN_CHARACTER_ENCODING AND V_COLUMNVALUE IS NOT NULL THEN

              IF (CONVERT(V_CONVERTED_COL,V_DB_ENCODING,PIN_CHARACTER_ENCODING) = V_COLUMNVALUE) THEN

                    UTL_FILE_PUT_RAW(V_FILEHANDLER,
                                     UTL_RAW.CAST_TO_RAW(V_CONVERTED_COL));


              ELSE -- IF AN ILLEGAL (NON LATIN1 CHARACTER IN DB AND LATIN1 ENCODING SELECTED) IS FOUND, CLOSE AND REMOVE THE FILE.
                UTL_FILE_FFLUSH(V_FILEHANDLER);
                UTL_FILE_FCLOSE(V_FILEHANDLER);
                UTL_FILE_FREMOVE(PIN_DIR, PIN_FILENAME);
                V_ILLEGAL_CHAR  := 1;
                POUT_ERROR_CODE := 1;
                EXIT;
              END IF;
         ELSE
            IF V_CONVERSION = 1 THEN
                    UTL_FILE_PUT_RAW(V_FILEHANDLER,
                                     UTL_RAW.CAST_TO_RAW(V_CONVERTED_COL));
            ELSE
                    UTL_FILE_PUT_RAW(V_FILEHANDLER,
                                     UTL_RAW.CAST_TO_RAW(V_COLUMNVALUE));
            END IF;
         END IF;
        V_SEPARATOR := PIN_SEPARATOR;
      END LOOP;

      IF V_ILLEGAL_CHAR = 0 THEN
        UTL_FILE_PUT_RAW(V_FILEHANDLER,PV_RAW_CRLF);
        V_ROW_COUNTER := V_ROW_COUNTER + 1;
      END IF;
      IF V_ROW_COUNTER mod 100000 = 0 and nvl(POUT_ERROR_CODE,0) <> 1 THEN
           UTL_FILE_FFLUSH(V_FILEHANDLER);
      END IF;

    END LOOP;
    DBMS_SQL.CLOSE_CURSOR(C);
    --
    IF POUT_ERROR_CODE = 0 THEN
      UTL_FILE_FFLUSH(V_FILEHANDLER);
      UTL_FILE_FCLOSE(V_FILEHANDLER);
      POUT_ROW_COUNTER := V_ROW_COUNTER;
    ELSE
      POUT_ROW_COUNTER := 0;
    END IF;
    --
  END WRITE_TO_FILE;
  --

  PROCEDURE RUN_TXT_DATA_EXPORT(PIN_EXPORT_PROCESS_ID IN NUMBER,
                                PIN_OUTPUT_FILENAME   IN VARCHAR2,
                                PIN_INPUT_SOURCE      IN CLOB,
                                PIN_COLUMN_LIST       IN TABLETYPE_DE_COL_TYPE_LIST,
                                POUT_ROW_COUNTER      OUT NUMBER,
                                POUT_ERROR_CODE       OUT NUMBER) IS
    --
    V_OUTPUT_TYPE            NUMBER(2);
    V_OUTPUT_NAME            VARCHAR2(255 CHAR);
    V_OUTPUT_COLUMNS_LIST    CLOB;
    V_INCL_HEADER            NUMBER(1);
    V_DECIMAL_SEPARATOR      NUMBER(2);
    V_RECORD_DELIMITER       NUMBER(2);
    V_FIELD_DELIMITER        NUMBER(2);
    V_CHARACTER_ENCODING     NUMBER(2);
    V_TEXT_QUALIFIER         NUMBER(2);
    V_COLUMN_COUNTER         NUMBER(10) := 1;
    V_COLUMN_COUNTER_2       NUMBER(10) := 0;
    V_TOTAL_COLUMN_COUNTER   NUMBER(10) := 0;
    V_COLUMN_ARRAY           COLUMN_ARR := COLUMN_ARR();
    V_CHARACTER_ENCODING_STR VARCHAR2(15 CHAR);
    V_DATE_FORMAT            VARCHAR2(13 CHAR);
    V_FIELD_DELIMITER_CHR    VARCHAR2(1 CHAR);
    V_TEXT_QUALIFIER_CHR     VARCHAR2(2 CHAR);
    V_PREV_FLD_TYPE          NUMBER(10) := -1;
    V_FIXED_LENGTH           NUMBER(1)  :=0;
    V_SQL                    CLOB;
    V_DIR                    CLOB := SYS_CONTEXT('USERENV',
                                                 'CURRENT_SCHEMA') ||
                                     '_EDIR';

  BEGIN
    --
    SELECT DE_OUT_TYPE
      INTO V_OUTPUT_TYPE
      FROM DATA_EXPORT
     WHERE DE_ID = PIN_EXPORT_PROCESS_ID;
    --
    IF V_OUTPUT_TYPE = 1 THEN
      SELECT NVL(DET_INCL_HEADER, 0),
             NVL(DET_DECIMAL_SEPARATOR, 0),
             NVL(DET_RECORD_DELIMITER, 0),
             NVL(DET_FIELD_DELIMITER, 0),
             NVL(DET_CHARACTER_ENCODING, 0),
             DEDF_DATE_FORMAT,
             NVL(DET_TEXT_QUALIFIER, 2)
        INTO V_INCL_HEADER,
             V_DECIMAL_SEPARATOR,
             V_RECORD_DELIMITER,
             V_FIELD_DELIMITER,
             V_CHARACTER_ENCODING,
             V_DATE_FORMAT,
             V_TEXT_QUALIFIER
        FROM DATA_EXPORT_TXT DET
        LEFT JOIN DATA_EXPORT_DATE_FMT DEDF
          ON DEDF.DEDF_ID = DET.DET_DEDF_ID
       WHERE DET.DET_DE_ID = PIN_EXPORT_PROCESS_ID;
      --
      CASE
        WHEN V_FIELD_DELIMITER = 0 THEN
          V_FIELD_DELIMITER_CHR := ',';
        WHEN V_FIELD_DELIMITER = 1 THEN
          V_FIELD_DELIMITER_CHR := ';';
        WHEN V_FIELD_DELIMITER = 2 THEN
          V_FIELD_DELIMITER_CHR := CHR(9) ;
        WHEN V_FIELD_DELIMITER = 3 THEN
          V_FIELD_DELIMITER_CHR := '|';
        WHEN V_FIELD_DELIMITER = 9 THEN
          V_FIELD_DELIMITER_CHR := '';
          V_FIXED_LENGTH := 1;
      END CASE;
      --
      CASE
        WHEN V_TEXT_QUALIFIER = 0 THEN
          V_TEXT_QUALIFIER_CHR := '"';
        WHEN V_TEXT_QUALIFIER = 1 THEN
           V_TEXT_QUALIFIER_CHR := '''''';
        WHEN V_TEXT_QUALIFIER in (2,9) THEN
           V_TEXT_QUALIFIER_CHR := '';
      END CASE;
      --
      IF V_CHARACTER_ENCODING = 0 THEN
        V_CHARACTER_ENCODING_STR := 'WE8MSWIN1252';
      ELSIF V_CHARACTER_ENCODING = 1 THEN
        V_CHARACTER_ENCODING_STR := 'UTF8';
      ELSIF V_CHARACTER_ENCODING = 2 OR V_CHARACTER_ENCODING = 3 THEN
        V_CHARACTER_ENCODING_STR := 'AL16UTF16';
      ELSIF V_CHARACTER_ENCODING = 4 THEN
        V_CHARACTER_ENCODING_STR := 'AL16UTF16LE';
      END IF;
      V_COLUMN_COUNTER_2 := 1;
      V_TOTAL_COLUMN_COUNTER := 0;
      FOR C IN (SELECT COLUMN_NAME, COLUMN_HEADER, COLUMN_TYPE, DECIMAL_PRECISION,FIXED_LENGTH,  COUNT(1) OVER() ROWCNT
                  FROM TABLE(PIN_COLUMN_LIST)) LOOP
        IF ((V_COLUMN_COUNTER_2 < 17 AND V_COLUMN_COUNTER_2 >1) AND C.COLUMN_TYPE <> 4)  AND V_TOTAL_COLUMN_COUNTER < C.ROWCNT THEN
         V_OUTPUT_COLUMNS_LIST := V_OUTPUT_COLUMNS_LIST|| '||''' || V_FIELD_DELIMITER_CHR || '''' || '||';
        END IF;
        V_TOTAL_COLUMN_COUNTER := V_TOTAL_COLUMN_COUNTER + 1;
        IF C.COLUMN_TYPE = 4 AND V_TOTAL_COLUMN_COUNTER > 1 AND V_TOTAL_COLUMN_COUNTER < C.ROWCNT+1 AND V_PREV_FLD_TYPE <> 4 AND V_COLUMN_COUNTER_2 > 1 THEN
           V_OUTPUT_COLUMNS_LIST := V_OUTPUT_COLUMNS_LIST|| ',';
        END IF;
        V_PREV_FLD_TYPE :=  C.COLUMN_TYPE;
         V_OUTPUT_COLUMNS_LIST := V_OUTPUT_COLUMNS_LIST ||''''||V_TEXT_QUALIFIER_CHR||'''||'||
                                CASE WHEN V_FIXED_LENGTH = 1 THEN 'RPAD(NVL(' END ||
                                CASE -- COMPOSE OUTPUT COLUMN LIST AND CAST NUMBERS TO THE RIGHT FORMAT
                                   WHEN C.COLUMN_TYPE = 5 THEN -- FORMATTING SECTION FOR NUMBERS (USING THE SELECTED DECIMAL SEPARATOR)
                                    'TRIM(REPLACE(TO_CHAR(' || C.COLUMN_NAME ||
                                    ',''999999999999990'||case when nvl(C.DECIMAL_PRECISION,0) > 0
                                                          then '.'||(power(10,C.DECIMAL_PRECISION)-1) end ||'''),''.'',' || CASE
                                      WHEN V_DECIMAL_SEPARATOR = 0 THEN
                                       '''.'''
                                      ELSE
                                       ''','''
                                    END || ')) '
                                   WHEN C.COLUMN_TYPE = 0 THEN
                                     'REPLACE('||C.COLUMN_NAME||','''||V_TEXT_QUALIFIER_CHR||''','||''''||V_TEXT_QUALIFIER_CHR||V_TEXT_QUALIFIER_CHR||''')'
                                   WHEN C.COLUMN_TYPE = 2 AND -- FORMATTING SECTION FOR DATE FIELDS (USING THE SPECIFIED DATE FORMAT, IF ANY)
                                        V_DATE_FORMAT IS NOT NULL THEN
                                    'TO_CHAR(' || C.COLUMN_NAME || ', ''' ||
                                    V_DATE_FORMAT || ''') '
                                   WHEN C.COLUMN_TYPE = 3 AND -- FORMATTING SECTION FOR DATE TIME FIELDS (USING THE SPECIFIED DATE FORMAT, IF ANY)
                                        V_DATE_FORMAT IS NOT NULL THEN
                                    'TO_CHAR(' || C.COLUMN_NAME || ', ''' ||
                                    V_DATE_FORMAT || ' HH24:MI:SS' || ''') '
                                   WHEN C.COLUMN_TYPE = 4 THEN -- FORMATTING SECTION FOR NOTES (RPLACE TAB/CR/LF WITH WHITE SPACES)
                                    'REPLACE(REPLACE(REPLACE(' || 'REPLACE('||C.COLUMN_NAME||','''||V_TEXT_QUALIFIER_CHR||''','||''''||V_TEXT_QUALIFIER_CHR||V_TEXT_QUALIFIER_CHR||''')' ||
                                    ',CHR(9),'' ''),CHR(10),'' ''),CHR(13),'' '')'
                                   ELSE
                                   'TO_CHAR(' || C.COLUMN_NAME || ')'
                                 END  || CASE WHEN V_FIXED_LENGTH = 1 THEN ', '' ''),'||C.FIXED_LENGTH||', '' '')' END
                                 ||'||'''||V_TEXT_QUALIFIER_CHR||''''
                                 ;
        --
        IF (V_COLUMN_COUNTER_2 = 16 OR C.COLUMN_TYPE = 4 OR (V_FIXED_LENGTH = 1 AND NVL(C.FIXED_LENGTH,0)>249))  AND V_TOTAL_COLUMN_COUNTER < C.ROWCNT THEN
          V_COLUMN_COUNTER_2 := 1;
          V_OUTPUT_COLUMNS_LIST := V_OUTPUT_COLUMNS_LIST|| ',';
        ELSIF V_TOTAL_COLUMN_COUNTER < C.ROWCNT THEN
          V_COLUMN_COUNTER_2 := V_COLUMN_COUNTER_2 + 1;
        END IF;
        V_COLUMN_ARRAY.EXTEND;
        V_COLUMN_ARRAY(V_COLUMN_COUNTER) := NVL(C.COLUMN_HEADER,
                                                C.COLUMN_NAME) || -- COMPOSE HEADER
                                            V_FIELD_DELIMITER_CHR;
        V_COLUMN_COUNTER := V_COLUMN_COUNTER + 1;

      END LOOP;
      --
      V_OUTPUT_NAME := PIN_OUTPUT_FILENAME;
      --
      V_SQL := 'SELECT ' || V_OUTPUT_COLUMNS_LIST || ' FROM (' ||
               PIN_INPUT_SOURCE || ')';
      --
      COMMONS_PROCESSING.EXEC_START_PROC_TRANSACTION(    pin_run_id         => NULL
                                                      ,pin_definition_id  => PIN_EXPORT_PROCESS_ID
                                                    ) ;
      WRITE_TO_FILE(V_SQL,
                              V_FIELD_DELIMITER_CHR,
                              V_DIR,
                              V_OUTPUT_NAME,
                              V_RECORD_DELIMITER,
                              V_INCL_HEADER,
                              V_COLUMN_ARRAY,
                              V_CHARACTER_ENCODING_STR,
                              POUT_ROW_COUNTER         => POUT_ROW_COUNTER,
                              POUT_ERROR_CODE          => POUT_ERROR_CODE);

       COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(    pin_run_id         => NULL
                                                      ,pin_definition_id  => PIN_EXPORT_PROCESS_ID);

    END IF;
  END RUN_TXT_DATA_EXPORT;
END DATA_EXPORT_PROCESS;
/
