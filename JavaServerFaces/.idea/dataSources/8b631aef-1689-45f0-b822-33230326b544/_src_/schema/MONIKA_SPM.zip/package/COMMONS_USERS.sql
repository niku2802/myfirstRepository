CREATE package commons_users is
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  users-commons
  -- Requester    :  Irimiciuc, Laura
  -- Author    :  Lazar, Lucian
  -- Reviewer    :  Cozac, Tudor
  -- Review date    :  20120118
  -- Description    :  Used for user management
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20120524
  -- Description: Returns two clauses holding the results for two custom validations:
  --                - if there is more than one entity in the table, no more than one entity per record has a value
  --                - each role exists in the database
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_source_table  VARCHAR2                        Name of the source table containing users and roles
     pi_load_mode     NUMBER                          Load mode: 1 - replace (update), 2 - append (insert), 3 - UPDATE_EXISTING_DATA, 4 - UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA
     pi_append_roles  NUMBER                          Append roles: 0 - no, 1 - yes (only for the following load modes: UPDATE_EXISTING_DATA, UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA)
     pi_separator     VARCHAR2                        Role separator; can be ',' or ';'; if empty, roles column is not mapped
     pi_columns       TABLETYPE_COLUMN_MAPPED_ENTITY  Colection with column names and two flags: column is mapped (1/0) and column is entity (1/0)
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_entities_clause  CLOB  Contains the decode clause for the entities validation: 0 - fail, 1 - pass
     po_roles_clause     CLOB  Contains the case clause for the roles validation: 0 - fail, 1 - pass
     po_invalid_roles    CLOB  Contains the clause for the invalid roles; used for logging just in the data import for now
     po_40_roles_clause  CLOB  Contains the case clause for the maximum 40 roles validation: 0 - fail, 1 - pass
  */
  /*
     po_entities_clause will look like:
      decode(decode(E1001, null, 0, 1) +
              (select decode(E1002, null, 0, 1) +
                      decode(E1003, null, 0, 1)
                 from users
                where login_id = US.login_id),
              0,
              1,
              1,
              1,
              0)
     po_roles_clause will look like:
      case
       when role in
            (select role
               from (select role,
                            regexp_substr(role, '[^,]+', 1, level) elm
                       from T100001
                     connect by regexp_substr(role, '[^,]+', 1, level) is not null
                     )
              where trim(elm) not in (select rol_name
                                        from roles
                                       where trim(elm) = rol_name
                                      )
                and trim(elm) is not null
             )
       then 0
       else 1
      end
     po_invalid roles will look like:
      (select inv_roles
         from T100001 t2
         left join (select login_id,
                          listagg(role_name, ',') within group(order by role_name) inv_roles
                     from (select distinct login_id, elm role_name
                             from (select login_id,
                                          role,
                                          regexp_substr(role, '[^,]+', 1, level) elm
                                     from T100001
                                   connect by regexp_substr(role, '[^,]+', 1, level) is not null
                                   )
                            where not exists (select 1
                                                from roles
                                               where ROL_NAME = trim(elm)
                                              )
                              and elm is not null
                           )
                    group by login_id
                    ) x
           on t2.login_id = x.login_id
        where t2.login_id = T100001.login_id)
     po_40_roles_clause will look like:
       case when pi_load_mode in (1,2) or (pi_load_mode in (3,4) and pi_append_roles = 0) and regexp_count(role,',') + 1 > 40 then 0
            when pi_append_roles = 1 and login_id in (select login_id
                                          from (select login_id, rol_name
                                                  from users
                                                  join user_roles
                                                    on user_id = ur_user_id
                                                  join roles
                                                    on ur_role_id = rol_id
                                                 where login_id in (select login_id from testu)
                                                 union
                                                select distinct login_id, elm role_name
                                                  from (select login_id,
                                                               role,
                                                               regexp_substr(role,
                                                                             '[^,]+',
                                                                             1,
                                                                             level) elm
                                                          from testu
                                                        connect by regexp_substr(role,
                                                                                 '[^,]+',
                                                                                 1,
                                                                                 level) is not null)
                                                 where elm is not null
                                                )
                                         group by login_id having count(rol_name) > 40
                                        ) then 0
            else 1
             end
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  -- This procedure will be called by the UsersDataImportPlugin plugin, used for Custom Data Load Support For User Table
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_users.validation_clauses('T100001',
                                     4,
                                     0,
                                     ',',
                                     TABLETYPE_COLUMN_MAPPED_ENTITY(OBJTYPE_COLUMN_MAPPED_ENTITY('LOGIN_ID',
                                                                                                 1,
                                                                                                 0),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('FULL_NAME',
                                                                                                 1,
                                                                                                 0),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('EMAIL',
                                                                                                 1,
                                                                                                 0),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('E1001',
                                                                                                 1,
                                                                                                 1),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('E1002',
                                                                                                 0,
                                                                                                 1)),
                                     l_entities_clause,
                                     l_roles_clause,
                                     l_invalid_roles,
                                     l_40_roles_clause);
  */
  -----------------------------------------------------------------------------------------
  procedure validation_clauses_old(pi_source_table    in varchar2,
                               pi_load_mode       in number,
                               pi_append_roles    in number,
                               pi_separator       in varchar2,
                               pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                               po_entities_clause out clob,
                               po_roles_clause    out clob,
                               po_invalid_roles   out clob,
                               po_40_roles_clause out clob);
  procedure validation_clauses(pi_source_table    in varchar2,
                               pi_load_mode       in number,
                               pi_append_roles    in number,
                               pi_separator       in varchar2,
                               pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                               po_entities_clause out clob,
                               po_roles_clause    out clob,
                               po_invalid_roles   out clob,
                               po_40_roles_clause out clob);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20120524
  -- Description: Performs two custom validations and returns the rows that fail:
  --                - if there is more than one entity in the table, no more than one entity per record has a value
  --                - each role exists in the database
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_source_table  VARCHAR2                        Name of the source table containing users and roles
     pi_load_mode     NUMBER                          Load mode: 1 - replace (update), 2 - append (insert), 3 - UPDATE_EXISTING_DATA, 4 - UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA
     pi_append_roles  NUMBER                          Append roles: 0 - no, 1 - yes (only for the following load modes: UPDATE_EXISTING_DATA, UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA)
     pi_separator     VARCHAR2                        Role separator; can be ',' or ';'; if empty, roles column is not mapped
     pi_columns       TABLETYPE_COLUMN_MAPPED_ENTITY  Colection with column names and two flags: column is mapped (1/0) and column is entity (1/0)
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_validations  SYS_REFCURSOR  Contains the rows that failed the entities and/or roles validation.
                                    Has four columns:
                                     - login_id
                                     - entities_validation: 0 - fail, 1 - pass
                                     - roles_validation: 0 - fail, 1 - pass
                                     - invalid_roles: list of invalid roles, comma separated
                                     - forty_roles_validation: 0 - fail, 1 - pass
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  -- This procedure will be called by Data Import. In case one row fails the validations the import will be stopped.
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_users.validate_users('T100001',
                                 4,
                                 0,
                                 ',',
                                 TABLETYPE_COLUMN_MAPPED_ENTITY(OBJTYPE_COLUMN_MAPPED_ENTITY('LOGIN_ID',
                                                                                                 1,
                                                                                                 0),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('FULL_NAME',
                                                                                                 1,
                                                                                                 0),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('EMAIL',
                                                                                                 1,
                                                                                                 0),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('E1001',
                                                                                                 1,
                                                                                                 1),
                                                                    OBJTYPE_COLUMN_MAPPED_ENTITY('E1002',
                                                                                                 0,
                                                                                                 1)),
                                 l_validations);
  */
  -----------------------------------------------------------------------------------------
  procedure validate_users(pi_source_table    in varchar2,
                           pi_load_mode       in number,
                           pi_append_roles    in number,
                           pi_separator       in varchar2,
                           pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                           po_validations     out sys_refcursor);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110602
  -- Description: Loads users and their roles into db
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_source_table    VARCHAR2  Name of the source table containing users and roles
     pi_load_mode       NUMBER    Load mode: 1 - replace (update), 2 - append (insert), 3 - UPDATE_EXISTING_DATA, 4 - UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA
     pi_append_roles    NUMBER    Append roles: 0 - no, 1 - yes (only for the following load modes: UPDATE_EXISTING_DATA, UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA)
     pi_separator       VARCHAR2  Role separator; can be ',' or ';'
     pi_mapped_roles    NUMBER    Role column is mapped: 1 - yes, 0 - no
     pi_pam_server      NUMBER    Pam server: 1 - internal, 2 - external
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_counts_cursor  SYS_REFCURSOR  Contains number of rows appended or/and updated
     po_emails_cursor  SYS_REFCURSOR  Contains emails of the updated users with account
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  -- This procedure will be called by the UsersDataImportPlugin plugin, used for Custom Data Load Support For User Table and by Data Import
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_users.load_users('T100001',
                             4,
                             1,
                             ',',
                             1,
                             1,
                             TABLETYPE_COLUMN_MAPPED_ENTITY(OBJTYPE_COLUMN_MAPPED_ENTITY('LOGIN_ID',
                                                                                         1,
                                                                                         0),
                                                            OBJTYPE_COLUMN_MAPPED_ENTITY('FULL_NAME',
                                                                                         1,
                                                                                         0),
                                                            OBJTYPE_COLUMN_MAPPED_ENTITY('EMAIL',
                                                                                         1,
                                                                                         0),
                                                            OBJTYPE_COLUMN_MAPPED_ENTITY('E1001',
                                                                                         1,
                                                                                         1),
                                                            OBJTYPE_COLUMN_MAPPED_ENTITY('E1002',
                                                                                         0,
                                                                                         1)),
                             l_counts_cursor,
                             l_emails_cursor);
  */
  -----------------------------------------------------------------------------------------
  procedure load_users(pi_source_table    in varchar2,
                       pi_load_mode       in number,
                       pi_append_roles    in number,
                       pi_separator       in varchar2,
                       pi_mapped_roles    in number,
                       pi_pam_server      in number,
                       pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                       po_counts_cursor   out sys_refcursor,
                       po_emails_cursor   out sys_refcursor);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20120530
  -- Description: Sets roles to users, supporting 3 different modes:
  --                - add specified roles to existing roles
  --                - remove specified roles from existing roles
  --                - replace existing roles with specified roles
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_users_list      CLOB    List of users to be edited; comma separated
     pi_roles_list      CLOB    List of roles to be set; comma separated
     pi_update_mode     NUMBER  Update mode: 1 - add, 2 - remove, 3 - replace
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_too_many_roles  NUMBER  Flag if the process was stopped because a user had over 40 roles assigned: 1 - yes, 0 - no
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_users.set_roles('3,4,5',
                            '4,5',
                            1,
                            l_roles);
  */
  -----------------------------------------------------------------------------------------
  procedure set_roles(pi_users_list      in clob,
                      pi_roles_list      in clob,
                      pi_update_mode     in number,
                      po_too_many_roles out number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20130111
  -- Description: Updates role names and updates roles in users table as well
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_roles_list  TABLETYPE_ID_NAME  List of roles to be updated
                                       Collection with two columns:
                                       - ID    number(10)         not null
                                       - NAME  varchar2(50 char)  not null
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_users.update_roles(TABLETYPE_ID_NAME(OBJTYPE_ID_NAME(11,
                                                                 'ROLE11'),
                                                 OBJTYPE_ID_NAME(12,
                                                                 'ROLE12')));
  */
  -----------------------------------------------------------------------------------------
  procedure update_roles(pi_roles_list in TABLETYPE_ID_NAME);
  -- ========================================================

-- *******************************    PUBLIC PROCEDURES END         *******************************

end commons_users;
/
