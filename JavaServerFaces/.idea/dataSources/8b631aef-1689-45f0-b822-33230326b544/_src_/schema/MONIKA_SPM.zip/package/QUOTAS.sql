CREATE PACKAGE QUOTAS AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : quotas
-- Module           : quotas
-- Requester        : Horlescu, Gabriel
-- Author           : Banea, Elena; Macarie, Sabina
-- Reviewer         : Banea, Elena
-- Review date      : 29 JUL 2014
-- Description      : Package used to handle all quotas processing validations
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
   e_stop_processing EXCEPTION;
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- ========================================================
  -- Author     : Banea, Elena
  -- Create date: 20140704
  -- Description: Checks if hierarchies with the same structure as Entity Relationships exist
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_qd_id               QUOTA_DEFINITIONS.QD_ID%TYPE   ID of the Quota Definition
     pi_hierarchy_type      NUMBER                         The type of the hierarchy for which the check is made
                                                           1 - organization hierarchy
                                                           2 - product hierarchy
     pi_quota_entities_list VARCHAR2                       The list of quota entities as <entity_id-level>, <entity_id-level>.
                                                           When the values is NULL => all the not dated hierarchies from the system
                                                                              not NULL => all the hierarchies that match pi_quota_entities_list

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(QUOTAS.QUOTAS_CHECK_IF_HIERAR_EXISTS(205089, 1, NULL));
     select * from table(QUOTAS.QUOTAS_CHECK_IF_HIERAR_EXISTS(205089, 2, '12342-1,23632-2'));
  */
  -----------------------------------------------------------------------------------------
  FUNCTION QUOTAS_CHECK_IF_HIERAR_EXISTS(pi_qd_id IN QUOTA_DEFINITIONS.QD_ID%TYPE
                                        ,pi_hierarchy_type NUMBER
                                        ,pi_quota_entities_list VARCHAR2)
  RETURN TABLETYPE_ID_NAME;




-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160330
-- Description: Procedure used for upgrading quota definitions when removing Calculate Attainment option
-- Details : (Upgrade Considerations) - http://confluence.optymyze.net/display/Quotas/Quotas+-+Support+calculated+additional+fields+display+in+Quotas+Management+app
-----------------------------------------------------------------------------------------

  PROCEDURE UPGRADE_QUOTA_ATTAINMENT;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20151202
-- Description: Returns the list of additional fields that are set to be displayed from the definition
                -- option -- 1 - returns the list as a string separated by comma
                -- option -- 2 - returns the list as a sum(field) seprated by comma, used in case of product hieararchy
                --               to calculate the sum for each field for each level in product hierarchy

-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_qd_id  IN quota_definitions.qd_id%TYPE -- quota definition id
   pi_option IN NUMBER -- 1 - list as string, 2 - list as sum(field)
   pi_alias  IN VARCHAR2 - returns the list with the appended alias
*/
-----------------------------------------------------------------------------------------
FUNCTION GET_ADDITIONAL_FIELDS (pi_qd_id  IN quota_definitions.qd_id%TYPE,
                                pi_option IN NUMBER,
                                pi_alias  IN VARCHAR2 DEFAULT NULL
                               )
  RETURN VARCHAR2;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150528
-- Description: Functions that returns all data tables in the software (in alphabetical order) that have in their structure all entities specified
--- for the organization hierarchy, the entity that represents the product entity only when multiple quotas are setup for the entities
--  in the organization hierarchy and have either no effective period or range of periods or have an effective period or range of periods
--  with the same time unit as the time unit specified as the quota frequency
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_q_frequency         IN NUMBER     -- quota frequency time unit id
   pi_quota_entities_list IN VARCHAR2   -- the list of organization entities and quota entity (if multiple quotas)
*/
-----------------------------------------------------------------------------------------
  FUNCTION FILTER_PERFORMANCE_TABLES(pi_q_frequency         NUMBER,
                                     pi_quota_entities_list VARCHAR2)
  RETURN TABLETYPE_ID_NAME;

  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20140715
  -- Description: Returns a collection of error codes for Quotas Import validations:
  --              10001 - More than one entity ID in a row in the Initial Quota table
  --              10002 - No entity ID has been specified for a row in the Initial Quotas table
  --              10003 - The period specified in the Initial Quota table does not exist in the Quota Periods table
  --              10004 - The quota value in the Initial Quota table is a negative number
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_qp_table_name               VARCHAR2                        Quota Periods table name
     pi_qp_period_col_name          VARCHAR2                        Period column name from the Quota Periods table
     pi_iq_table_name               VARCHAR2                        Initial Quotas table name
     pi_iq_period_col_name          VARCHAR2                        Period column name from the Initial Quotas table
     pi_iq_entity_col_name_list     COLTYPE_ADD_FIELDS_TO_CREDIT    Collection of column names for entities from the Initial Quotas table
  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(QUOTAS.RUN_IMPORT_VALIDATIONS('T12345', 'F444', 'T123', 'F123', COLTYPE_ADD_FIELDS_TO_CREDIT('E123', 'E234')));
  */
  -----------------------------------------------------------------------------------------
  FUNCTION RUN_IMPORT_VALIDATIONS( pi_qp_table_name IN VARCHAR2
                                  ,pi_qp_period_col_name IN VARCHAR2
                                  ,pi_iq_table_name IN VARCHAR2
                                  ,pi_iq_period_col_name IN VARCHAR2
                                  ,pi_iq_entity_col_name_list IN COLTYPE_ADD_FIELDS_TO_CREDIT)
  RETURN TABLETYPE_NUMBER;

-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************
  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20140804
  -- Description: Validations for Quotas Data Load process:
  --              10001 - More than one entity ID in a row in the Initial Quota table
  --              10002 - No entity ID has been specified for a row in the Initial Quotas table
  --              10003 - The period specified in the Initial Quota table does not exist in the Quota Periods table
  --              10004 - The quota value in the Initial Quota table is a negative number
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_definition_id                 IN NUMBER                              The Quotas definition id
     pi_qp_table_name                 IN VARCHAR2                            Quota Periods table name
     pi_qp_period_col_name            IN VARCHAR2                            Period column name from the Quota Periods table
     pi_temp_table_name               IN VARCHAR2                            Temp table name used used for storing intermediate data from input
     pi_temp_period_col_name          IN VARCHAR2                            Period column name from the temp table
     pi_temp_entity_col_name_list     IN COLTYPE_ADD_FIELDS_TO_CREDIT        Collection of column names for entities from the temp table
  */

  -- Output Parameters:
  /*
     pio_validation_clauses           IN OUT TABLETYPE_OBJECTIVE_LOAD_VLD    A collection containing the validation when clauses to be appended in data load/post records;
                                                                             it will be sent with VLD_ID populated and VLD_WHEN_CLAUSE as NULL
  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     validations TABLETYPE_OBJECTIVE_LOAD_VLD := TABLETYPE_OBJECTIVE_LOAD_VLD(OBJTYPE_OBJECTIVE_LOAD_VLD(10001, null)
                                                                        ,OBJTYPE_OBJECTIVE_LOAD_VLD(10002, null)
                                                                        ,OBJTYPE_OBJECTIVE_LOAD_VLD(10003, null)
                                                                        ,OBJTYPE_OBJECTIVE_LOAD_VLD(10004, null));
     begin
      QUOTAS.RUN_LOAD_VALIDATIONS(205213, 'QUOTA_PERIODS', 'PERIOD_ID', 'INITIAL_QUOTAS', 'PIQ1', COLTYPE_ADD_FIELDS_TO_CREDIT('DIQ1', 'AIQ1', 'RIQ1'), validations);
    end;
  */
  -----------------------------------------------------------------------------------------
  PROCEDURE RUN_LOAD_VALIDATIONS( pi_qp_table_name             IN VARCHAR2
                                 ,pi_qp_period_col_name        IN VARCHAR2
                                 ,pi_temp_table_name           IN VARCHAR2
                                 ,pi_temp_period_col_name      IN VARCHAR2
                                 ,pi_temp_entity_col_name_list IN COLTYPE_ADD_FIELDS_TO_CREDIT
                                 ,pio_validation_clauses       IN OUT TABLETYPE_OBJECTIVE_LOAD_VLD);


  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20151215
  -- Description: Procedure that calculates quota contribution
  -----------------------------------------------------------------------------------------
  -- Parameters:
  /*
    pi_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
    pi_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
    pi_iq_q_mapping         IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quotas tables
    pi_hierarchy_query      IN CLOB                                    -- hierarchy query
    pi_create_temp_tables   IN BOOLEAN DEFAULT TRUE                    -- true - create temp tables in case the process in ran with attainment
                                                                                 as a stand alone process
                                                                       -- false - when the procedure is ran from Load Initial Quotas process
    pi_adjusting_records    IN NUMBER DEFAULT NULL                     -- 1 - procedure is called in SAVE_QUOTAS_MODIFY_MODE
                                                                       --     in this case, we don't call the procedure for all the records in the table,
                                                                       --     only for the ones that have adjustments applied.
                                                                       -- 0 - procedure is called from Load Initial Quotas or Calculate Additional Info

  */
  -----------------------------------------------------------------------------------------
  PROCEDURE CALCULATE_QUOTA_CONTRIBUTION( pi_qd_id                IN quota_definitions.qd_id%TYPE,
                                          pi_tupr_id              IN NUMBER,
                                          pi_iq_q_mapping         IN TABLETYPE_NAME_MAP,
                                          pi_hierarchy_query      IN CLOB,
                                          pi_ht_cardinality       IN NUMBER DEFAULT NULL,
                                          pi_create_temp_tables   IN BOOLEAN DEFAULT TRUE,
                                          pi_adjusting_records    IN NUMBER DEFAULT NULL,
                                          pi_no_of_adj_records    IN NUMBER DEFAULT NULL,
                                          pi_modified_parent_map  IN TABLETYPE_ID_ENTITY_VALUE,
                                          pi_no_of_updated_rec    OUT NUMBER
                                       );


 -- ========================================================
  -- Author     : Banea, Elena
  -- Create date: 20140808
  -- Description: Populates the QUOTAS ENTITIES and QUOTAS tables
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_tupr_id               IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
     pi_qd_id                 IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
     pi_iq_table_name         IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
     pi_iq_qe_mapping         IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
     pi_iq_q_mapping          IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quotas tables
     pi_temp_hierarchy_query  IN CLOB,                                   -- hierarchy query
     pi_user_assign_queries   IN TABLETYPE_QUOTAS_QUERY_MAP,             -- mapping between user assignment tables_id and user assignment queries

  -- Output Parameters:
     pout_result              OUT SYS_REFCURSOR,                         -- Cursor with rows that failed the validations
     pout_no_rec_failed       OUT NUMBER,                                -- Number of rows from pout_result cursor
     pout_no_rec_qe           OUT NUMBER,                                -- Number of rows from Quota Entities table
     pout_no_rec_q            OUT NUMBER                                 -- Number of rows from Quotas table
  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  DECLARE
      V_OUT SYS_REFCURSOR;
      V_NO_OF_FAILED_REC  NUMBER;
      V_NO_OF_REC_QE      NUMBER;
      V_NO_OF_REC_Q       NUMBER;
  BEGIN
  QUOTAS.LOAD_INITIAL_QUOTAS( pi_tupr_id => 476,
                              pi_qd_id   => 2589829231,
                              pi_iq_table_name => 'T2589830210',
                              pi_iq_qe_mapping => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('E8216','E8216'),OBJTYPE_NAME_MAP('E2589825941','E2589825941'),
                                                                      OBJTYPE_NAME_MAP('E2589826270','E2589826270'),OBJTYPE_NAME_MAP('E2589826250','E2589826250')),
                              pi_iq_q_mapping  => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('E8216','E8216'),OBJTYPE_NAME_MAP('E2589825941','E2589825941'),
                                                                      OBJTYPE_NAME_MAP('E2589826270','E2589826270'),OBJTYPE_NAME_MAP('E2589826250','E2589826250')),
                              pi_temp_hierarchy_query => 'WITH H AS (SELECT *
                                                                       FROM (SELECT 2589826250 UPPER_ENTITY_ID,
                                                                              2589826270 LOWER_ENTITY_ID,
                                                                              E2589826304 UPPER_VALUE,
                                                                              E2589826303 LOWER_VALUE
                                                                            FROM T2589830127 tt1
                                                                            UNION ALL
                                                                            SELECT 2589826270 UPPER_ENTITY_ID,
                                                                              8216 LOWER_ENTITY_ID,
                                                                              t2.e2589826305 UPPER_VALUE,
                                                                              t2.e90846 LOWER_VALUE
                                                                            FROM T2589830147 t2
                                                                            UNION ALL
                                                                            SELECT 2589826270 UPPER_ENTITY_ID,
                                                                              2589825941 LOWER_ENTITY_ID,
                                                                              t3.e2589826305 UPPER_VALUE,
                                                                              t3.e2589825985 LOWER_VALUE
                                                                            FROM T2589830167 t3
                                                                            ) TAB
                                                                      )
                                                            SELECT UPPER_ENTITY_ID,
                                                                   LOWER_ENTITY_ID LOWER_ENTITY_ID,
                                                                   UPPER_VALUE,
                                                                   LOWER_VALUE LOWER_VALUE,
                                                                   level+1 as hlevel,
                                                                   CONNECT_BY_ISLEAF Leafs,
                                                                   CONNECT_BY_ROOT UPPER_ENTITY_ID as con_UPPER_ENTITY_ID,
                                                                   CONNECT_BY_ROOT LOWER_ENTITY_ID as con_LOWER_ENTITY_ID,
                                                                   CONNECT_BY_ROOT UPPER_VALUE as con_UPPER_VALUE,
                                                                   CONNECT_BY_ROOT LOWER_VALUE as con_LOWER_VALUE
                                                            FROM H
                                                            START WITH (UPPER_ENTITY_ID         = 2589826250
                                                                        AND LOWER_ENTITY_ID = 2589826270
                                                                        AND UPPER_VALUE     IN (1) )-- select E2589826304 from T2589830127 -- toti uperii
                                                            CONNECT BY PRIOR LOWER_ENTITY_ID = UPPER_ENTITY_ID
                                                              AND PRIOR LOWER_VALUE          = UPPER_VALUE',
                                pi_user_assign_queries => TABLETYPE_QUOTAS_QUERY_MAP(OBJTYPE_QUOTAS_QUERY_MAP(2589827300,
                                                                                        'SELECT E2589826250 AS LEFT_ENTITY_COL, E8208 AS RIGHT_ENTITY_COL FROM T2589827300'),
                                                                                   OBJTYPE_QUOTAS_QUERY_MAP(2589827617,
                                                                                        'SELECT E2589826270 AS LEFT_ENTITY_COL, E8208 AS RIGHT_ENTITY_COL FROM T2589827617'),
                                                                                   OBJTYPE_QUOTAS_QUERY_MAP(2589828554,
                                                                                        'SELECT E8216 AS LEFT_ENTITY_COL, E8208 AS RIGHT_ENTITY_COL FROM T2589828554'),
                                                                                   OBJTYPE_QUOTAS_QUERY_MAP(2589828580,
                                                                                        'SELECT E2589825941 AS LEFT_ENTITY_COL, E2589672374 AS RIGHT_ENTITY_COL FROM T2589828580')
                                                                                  ),
                                pi_temp_prod_hierarchy_query => 'WITH H AS ( SELECT *  FROM ( SELECT 4595 UPPER_ENTITY_ID, 4700 LOWER_ENTITY_ID, E48232 UPPER_VALUE, E100058 LOWER_VALUE FROM T450900 UNION ALL SELECT 4700 UPPER_ENTITY_ID, 4593 LOWER_ENTITY_ID, E117067 UPPER_VALUE, E48231 LOWER_VALUE FROM T450916 ) TAB   )
                                                                SELECT UPPER_ENTITY_ID,
                                                                   LOWER_ENTITY_ID LOWER_ENTITY_ID,
                                                                   UPPER_VALUE,
                                                                   LOWER_VALUE LOWER_VALUE,
                                                                   level+1 as hlevel,
                                                                   CONNECT_BY_ISLEAF Leafs,
                                                                   CONNECT_BY_ROOT UPPER_VALUE as con_UPPER_VALUE,
                                                                   CONNECT_BY_ROOT LOWER_VALUE as con_LOWER_VALUE,
                                                                   CONNECT_BY_ROOT UPPER_ENTITY_ID as con_UPPER_ENTITY_ID,
                                                                   CONNECT_BY_ROOT LOWER_ENTITY_ID as con_LOWER_ENTITY_ID
                                                                FROM H
                                                                START WITH (  (UPPER_ENTITY_ID = 4595 AND LOWER_ENTITY_ID = 4700 AND UPPER_VALUE IN ( SELECT E48232 FROM (SELECT DISTINCT E48232 FROM T450900) t1  ))  OR  (UPPER_ENTITY_ID = 4700 AND LOWER_ENTITY_ID = 4593 AND UPPER_VALUE IN ( SELECT E117067 FROM (SELECT DISTINCT E117067 FROM T450916) t1

                                                                where not exists (select 1 from T450900 t2 where t1.E117067 = t2.E100058)  ))  )
                                                                CONNECT BY PRIOR  LOWER_ENTITY_ID = UPPER_ENTITY_ID AND PRIOR LOWER_VALUE = UPPER_VALUE;'
                              pout_result         => V_OUT,
                              pout_no_rec_failed  => V_NO_OF_FAILED_REC,
                              pout_no_rec_qe      => V_NO_OF_REC_QE,
                              pout_no_rec_q       => V_NO_OF_REC_Q
                );
        END;
  */
  -----------------------------------------------------------------------------------------
PROCEDURE LOAD_INITIAL_QUOTAS( pi_tupr_id                   IN tu_periods_range.tupr_id%type ,          -- the period for which the process is executed
                               pi_qd_id                     IN quota_definitions.qd_id%type ,           -- id of the definition
                               pi_iq_table_name             IN tables.tables_physical_name%type ,       -- the name of the INITIAL_QUOTAS table
                               pi_iq_qe_mapping             IN TABLETYPE_NAME_MAP,                      -- mapping between column names from Initial Quotas and Quota Entities tables
                               pi_iq_q_mapping              IN TABLETYPE_NAME_MAP,                      -- mapping between column names from Initial Quotas and Quotas tables
                               pi_temp_hierarchy_query      IN CLOB ,                                   -- hierarchy query
                               pi_temp_prod_hierarchy_query IN CLOB ,                                   -- product hierarchy query
                               pi_user_assign_queries       IN TABLETYPE_QUOTAS_QUERY_MAP,              -- mapping between user assignment tables_id and user assignment queries
                               pi_quotas_table_query        IN CLOB,
                               pi_qe_table_query1           IN CLOB,
                               pi_qe_table_query2           IN CLOB,
                               pi_qe_table_query3           IN CLOB,
                               pout_result                  OUT SYS_REFCURSOR,                          -- Cursor with rows that failed the validations
                               pout_no_rec_failed           OUT NUMBER ,                                -- Number of rows from pout_result cursor
                               pout_no_rec_qe               OUT NUMBER ,                                -- Number of rows from Quota Entities table
                               pout_no_rec_q                OUT NUMBER                                  -- Number of rows from Quotas table
                             );

  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150415
  -- Description: Procedure that calculates quota attainment

  -----------------------------------------------------------------------------------------
  -- Parameters:
  /*
        pi_tupr_id                   IN tu_periods_range.tupr_id%TYPE,          -- the period for which the process is executed
        pi_qd_id                     IN quota_definitions.qd_id%TYPE,           -- id of the definition
        pi_q_mapping             IN TABLETYPE_NAME_MAP                          -- quotas table column names
  */
  -----------------------------------------------------------------------------------------
  PROCEDURE CALCULATE_ADDITIONAL_INFO (  pi_tupr_id                   IN tu_periods_range.tupr_id%TYPE,          -- the period for which the process is executed
                                         pi_qd_id                     IN quota_definitions.qd_id%TYPE,           -- id of the definition
                                         pi_q_mapping                 IN TABLETYPE_NAME_MAP,                     -- quotas table column names
                                         pi_hierarchy_query           IN CLOB,                                   -- organization hierarchy query
                                         pi_quotas_table_query        IN CLOB,
                                         pi_qe_table_query1           IN CLOB,
                                         pi_qe_table_query2           IN CLOB,
                                         pi_qe_table_query3           IN CLOB,
                                         pout_no_rec_failed           OUT NUMBER,                                -- number of rows from pout_result cursor
                                         pout_no_rec_updated          OUT NUMBER,                                -- number of records updated
                                         pout_result                  OUT SYS_REFCURSOR,                         -- cursor with rows that failed the validations
                                         pout_updated_rows            OUT tabletype_id_id                        -- collection with no of records updated in each prod table
                                       );


  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20170508
  -- Description: Procedure that scans the organizational hierarchy to check for started requests
  --      (https://confluence.optymyze.net/display/Quotas/Quotas+-+Workflow+integration+to+support+quota+adjustments+approval)
  -----------------------------------------------------------------------------------------
  -- Parameters:
  /*
     pi_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
     pi_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
     pi_iq_q_mapping         IN TABLETYPE_NAME_MAP                      -- column names from Quotas table
     pi_svqmm_modified_col_mapping IN TABLETYPE_ID_ID_VALUE             -- adjustments for children
                                                                           -- mapping between:
                                                                           --         -> E_INTERNAL_ID for the product that is being modified
                                                                           --         -> ENTITIES.ENTITY_ID - ID of the entity being modified
                                                                           --         -> E_INTERNAL_ID of the value from Quota Entities table
                                                                           --         -> modified Quota value (Adjustments column from UI)
     pi_modified_parent_map  IN TABLETYPE_ID_ENTITY_VALUE                -- adjustments for current level
     pi_logged_entity_id     IN NUMBER
     pi_logged_entity_value  IN NUMBER
  */
-----------------------------------------------------------------------------------------
PROCEDURE SCAN_HIERARCHY_FOR_WF_REQUESTS(pi_qd_id IN NUMBER,
                                         pi_tupr_id                    IN NUMBER,
                                         pi_iq_q_mapping               IN TABLETYPE_NAME_MAP,
                                         pi_modified_col_mapping       IN TABLETYPE_ID_ENTITY_VALUE,
                                         pi_modified_parent_map        IN TABLETYPE_ID_ENTITY_VALUE,
                                         pi_logged_entity_id           IN NUMBER,
                                         pi_logged_entity_value        IN NUMBER,
                                         pi_scan_parents_or_children   IN NUMBER,
                                         pout_result                   OUT SYS_REFCURSOR,
                                         pout_canceled_requests_no     OUT NUMBER);


  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20170801
  -- Description: Procedure that populates Initial Quotas table from a Sales Planning model
  -----------------------------------------------------------------------------------------
  -- Parameters:
  /*
      pi_tupr_id                   IN tu_periods_range.tupr_id%TYPE - the period for which the process is executed
      pi_qd_id                     IN quota_definitions.qd_id%TYPE  - id of the definition
      pi_iq_qe_mapping             IN TABLETYPE_NAME_MAP            - iq column names
      pi_import_query              IN CLOB                          - the query from sales planning used to populate IQ
      pi_replace_or_append         IN NUMBER                        - option to replace or append records in IQ
      pout_result                  OUT SYS_REFCURSOR                - validations cursor
      pout_no_rec_failed           OUT NUMBER                       - number of records failed
      pout_no_rec_updated_inserted OUT NUMBER                       - number of records updated or inserted
  */
  -----------------------------------------------------------------------------------------
  PROCEDURE IMPORT_IQ_FROM_PLANNING_MODEL(pi_tupr_id                   IN tu_periods_range.tupr_id%TYPE,
                                          pi_qd_id                     IN quota_definitions.qd_id%TYPE,
                                          pi_iq_qe_mapping             IN TABLETYPE_NAME_MAP,
                                          pi_field_mapping             IN TABLETYPE_ID_ID,
                                          pi_hierarchy_mapping         IN TABLETYPE_ID_ID,
                                          pi_import_query              IN CLOB,
                                          pi_replace_or_append         IN NUMBER,
                                          pout_result                  OUT SYS_REFCURSOR,
                                          pout_no_rec_failed           OUT NUMBER,
                                          pout_no_rec_updated_inserted OUT NUMBER);

  -- ========================================================
  -- Author     : Banea, Elena
  -- Create date: 20140922
  -- Description: Procedure that saves and cascades the modifications made by the user
  --      (http://confluence.optymyze.net/display/SD/Saving+quotas)
  -----------------------------------------------------------------------------------------
  -- Parameters:
  /*
    pi_svqmm_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
    pi_svqmm_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
    pi_svqmm_modified_col_mapping IN TABLETYPE_ID_ID_VALUE                   -- mapping between:
                                                                             --         -> E_INTERNAL_ID for the product that is being modified
                                                                             --         -> ROW_IDENTIFIER of the Quota Entities table
                                                                             --         -> modified Quota value (Adjustments column from UI)
    pi_workflow_save              IN NUMBER                                  -- 0 - perform only save validations, no save; 1 - validations and save adjustments
  */
  -----------------------------------------------------------------------------------------
  PROCEDURE SAVE_QUOTAS_MODIFY_MODE ( pi_svqmm_qd_id                IN quota_definitions.qd_iq_tables_id%type,
                                      pi_svqmm_tupr_id              IN tu_periods_range.tupr_id%type,
                                      pi_svqmm_modified_col_mapping IN TABLETYPE_ID_ENTITY_VALUE,
                                      pi_svqmm_modified_parent_map  IN TABLETYPE_ID_ENTITY_VALUE,
                                      pi_svqmm_parent_allocation    IN TABLETYPE_ID_ENTITY_VALUE,
                                      pi_svqmm_hierarchy_query      IN CLOB,
                                      pi_svqmm_q_mapping            IN tabletype_name_map,
                                      pi_quotas_table_query         IN CLOB,
                                      pi_qe_table_query1            IN CLOB,
                                      pi_qe_table_query2            IN CLOB,
                                      pi_qe_table_query3            IN CLOB,
                                      pi_hierarchy_type             IN NUMBER,
                                      pi_save_exceed_threshold      IN NUMBER,
                                      pi_workflow_save              IN NUMBER,
                                      pi_logged_entity_id           IN NUMBER,
                                      pi_logged_entity_value        IN NUMBER,
                                      pout_threshold_validations    OUT SYS_REFCURSOR,
                                      pout_wf_validations           OUT SYS_REFCURSOR
                                    );
-- *******************************    PUBLIC PROCEDURES END         *******************************

END QUOTAS;
/
