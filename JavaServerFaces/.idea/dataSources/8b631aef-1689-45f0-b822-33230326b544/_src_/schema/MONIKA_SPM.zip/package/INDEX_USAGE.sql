CREATE PACKAGE index_usage AS
  PROCEDURE report_unusable_indexes;
  PROCEDURE post_modulewise_ind;
  PROCEDURE purge_sql_stats;
  PROCEDURE index_usage_job;
  PROCEDURE drop_unused_index;
  PROCEDURE report_used_indexes;
  FUNCTION get_ind_col_list(pi_type_col IN coltype_indexed_columns_list)
    RETURN VARCHAR2;
  FUNCTION get_ind_col_list1(pi_type_col IN coltype_indexed_columns_list1)
    RETURN VARCHAR2;



PROCEDURE is_create (pi_table_name           IN VARCHAR2,
                      pi_index_name           IN VARCHAR2,
                      pi_column_name_list     IN coltype_indexed_columns_list,
                      pi_column_list_function IN coltype_indexed_columns_list1,
                      pi_identifier           IN NUMBER DEFAULT 0, -- 0 - app_index, 1 - DBA Index, (core types start here) 2 - business, 3 - pk, 4 - entity,5-- period
                      po_flag                 OUT NUMBER);

  PROCEDURE is_delete(pi_index_name    IN VARCHAR2,
                      po_business_name OUT VARCHAR2,
                      po_def_id        OUT NUMBER,
                      po_flag          OUT NUMBER);

  PROCEDURE create_index;

  /*PROCEDURE create_index_call(pi_table_name IN VARCHAR2,
  pi_col_list   IN coltype_indexed_columns_list,
  pi_def_id in number,
  po_index_name out VARCHAR2,
  po_index_creation_status out number) ;s

  */
  PROCEDURE create_index_call;
  /*
  PROCEDURE save_recommendation(pi_table_name IN VARCHAR2,
                                pi_col_list   IN coltype_indexed_columns_list default null)*/

  PROCEDURE create_index_recommendation;

  procedure create_index_usage_job;

END index_usage;
/
