CREATE PACKAGE BODY TERRITORIES AS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : territories
-- Module           : territories
-- Requester        : Horlescu, Gabriel
-- Author           : Macarie, Sabina
-- Reviewer         :
-- Review date      : 21 JUL 2015
-- Description      : Package used to handle all TERRITORIES processing
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150721
  -- Description: Filter metrics tables: data tables that contain the entity represented by map pins
  --                                     data tables that have either non effective records, or have records effective for a period or
  --                                               range of periods for the same time unit as the territories period, or have records effective for a period or range of periods
  --                                               for a corresponding period higher in time unit than the territories period
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_terr_id            NUMBER   ID of the time unit specified in the Territories definition
     pi_pin_entity_id      NUMBER   The pin entity ID

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(TERRITORIES.FILTER_METRICS_TABLES(638, 2977260))
  */
  -----------------------------------------------------------------------------------------
FUNCTION FILTER_METRICS_TABLES(pi_terr_frequency   NUMBER,
                               pi_pin_entity_id    NUMBER,
                               pi_is_dated         NUMBER)
RETURN TABLETYPE_ID_NAME
AS

  v_data_tables_info TABLETYPE_ID_NAME;
  v_tu_corr_list VARCHAR2(4000 CHAR);
  v_sql CLOB;

BEGIN


  IF pi_pin_entity_id IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_pin_entity_id' ));
  END IF ;

  -- list of all corresponding periods for the period set in the territories definition
  SELECT LISTAGG(tuc.tuc_tu_id_corr, ', ') WITHIN GROUP(ORDER BY 1)
    INTO v_tu_corr_list
    FROM tu_correspondence tuc
   WHERE tuc.tuc_tu_id = pi_terr_frequency;


  v_sql := '
     SELECT objtype_id_name(dt.dt_id, dt.dt_name)
      FROM data_tables dt
     INNER JOIN tables t
        ON dt.dt_tables_id = t.tables_id
     INNER JOIN table_columns tc
        ON t.tables_id = tc.tc_tables_id
     ' || CASE WHEN pi_is_dated = 1
               THEN ' WHERE t.tables_record_dating_option IN (1,2,4) '
               ELSE ' WHERE (t.tables_record_dating_option = 1
                         OR (t.tables_record_dating_option IN (3, 5)
                        AND t.tables_tu_id IN (' || pi_terr_frequency || CASE WHEN v_tu_corr_list IS NOT NULL THEN ',' || v_tu_corr_list END || ')))
       ' END ||
       ' AND tc.tc_entity_id = ' || pi_pin_entity_id || '
     ORDER BY dt.dt_name';

 EXECUTE IMMEDIATE v_sql BULK COLLECT INTO v_data_tables_info;


RETURN v_data_tables_info;
END FILTER_METRICS_TABLES;


  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150722
  -- Description: Filter entity tables: entity tables that have in its structure the Latitude and Longitude system fields
  --                                    entity tables that are not nodes in the organization hierarchy
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_terr_org_entities_list   VARCHAR2   A list of entities that are in the organization hierarchy

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(TERRITORIES.FILTER_ENTITY_TABLES('123, 345'))
  */
  -----------------------------------------------------------------------------------------
FUNCTION FILTER_ENTITY_TABLES(pi_terr_org_entities_list VARCHAR2)
RETURN TABLETYPE_NUMBER
AS
  v_filtered_ent_ids TABLETYPE_NUMBER;
  v_fld_ids_list     VARCHAR2(100 CHAR);
  v_sql              CLOB;
BEGIN

  -- fields ids for Latitude and Longitude system fields
  SELECT LISTAGG(f.fld_id, ', ') WITHIN GROUP(ORDER BY f.fld_id)
    INTO v_fld_ids_list
    FROM fields f
   WHERE f.fld_technical_name IN ('Latitude_Sys', 'Longitude_Sys');

  v_sql :=
    'SELECT ent_fld.entity_id
      FROM
      (
        SELECT e.entity_id, LISTAGG(tc.tc_fld_id, '', '') WITHIN GROUP (ORDER BY tc.tc_fld_id) AS fld_list
          FROM entities e
         INNER JOIN tables t
            ON t.tables_id = e.entity_tables_id
         INNER JOIN table_columns tc
            ON t.tables_id = tc.tc_tables_id
         WHERE e.entity_base_entity IS NULL
           AND tc.tc_fld_id IN (' || v_fld_ids_list || ')
           ' || CASE WHEN pi_terr_org_entities_list IS NOT NULL
                     THEN 'AND e.entity_id NOT IN (' || pi_terr_org_entities_list || ') '
                END || '
         GROUP BY e.entity_id
      ) ent_fld
     WHERE ent_fld.fld_list = ''' || v_fld_ids_list || '''';

  EXECUTE IMMEDIATE v_sql BULK COLLECT INTO v_filtered_ent_ids;
RETURN v_filtered_ent_ids;
END FILTER_ENTITY_TABLES;


  -- ========================================================
  -- Author     : Macarie, Sabina
  -- Create date: 20150724
  -----------------------------------------------------------------------------------------
  -- Description: Filter hierarchy tables:
                  -- hierarchy tables that have in their structure nodes with either no subordinate or only one subordinate
                  -- hierarchy tables that either have no effective range, or have an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- Input Parameters:
  /*
     pi_terr_frequency   NUMBER   The frequency set in the territory definition

  */
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(TERRITORIES.FILTER_HIERARCHY_TABLES(241))
  */
  -----------------------------------------------------------------------------------------
FUNCTION FILTER_HIERARCHY_TABLES(pi_terr_frequency   NUMBER,
                                 pi_is_dated         NUMBER)
RETURN TABLETYPE_NUMBER
AS
  v_filtered_ht_ids  TABLETYPE_NUMBER;
  v_tu_corr_list     VARCHAR2(4000 CHAR);
  v_sql              CLOB;
BEGIN

  -- list of all corresponding periods for the period set in the territories definition
  SELECT LISTAGG(tuc.tuc_tu_id_corr, ', ') WITHIN GROUP(ORDER BY 1)
    INTO v_tu_corr_list
    FROM tu_correspondence tuc
   WHERE tuc.tuc_tu_id = pi_terr_frequency;

  v_sql := 'SELECT ht_id
              FROM (SELECT ht_id, MAX(cnt_children) AS max_children_on_lvl
                      FROM (SELECT ht.ht_id, COUNT(hn.hn_entity_id) AS cnt_children
                              FROM hierarchy_node hn
                             INNER JOIN hierarchy_structure hs
                                ON hs.hs_id = hn.hn_hs_id
                             INNER JOIN hierarchy_tables ht
                                ON ht.ht_id = hs.hs_ht_id
                             ' || CASE WHEN pi_is_dated = 1
                                       THEN ' WHERE hs.hs_timeunit_id IS NULL '
                                       ELSE ' WHERE hs.hs_is_dated = 0
                                                AND NVL(hs.hs_timeunit_id, ' || pi_terr_frequency || ')
                                                 IN (' || pi_terr_frequency || CASE WHEN v_tu_corr_list IS NOT NULL
                                                                                    THEN ',' || v_tu_corr_list
                                                                               END || ')
                                ' END || '
                             START WITH hn.hn_parent_node_id IS NULL
                            CONNECT BY PRIOR hn.hn_id = hn.hn_parent_node_id
                             GROUP BY hn.hn_hs_id, hn.hn_parent_node_id, ht.ht_id)
                     GROUP BY ht_id
                    HAVING MAX(cnt_children) = 1)';

  EXECUTE IMMEDIATE v_sql BULK COLLECT INTO v_filtered_ht_ids;
RETURN v_filtered_ht_ids;
END FILTER_HIERARCHY_TABLES;

PROCEDURE GET_CUSTOMER_DATA (pin_assigned_entities_query  IN CLOB,
                             pin_leaf_entities_validation IN CLOB,
                             pin_leaf_customers_query     IN CLOB,
                             pin_fill_size_query          IN CLOB,
                             pout_customer_to_oh_entities OUT SYS_REFCURSOR,
                             pout_customer_fill_size      OUT SYS_REFCURSOR)
AS

v_stamp           VARCHAR2(250 CHAR);
v_entities_count  NUMBER;
v_customers_count NUMBER;
v_leaf_ent_count  NUMBER;
v_sql             CLOB;

BEGIN
    v_stamp := 'TERRITORIES.TERRITORIES_GET_CUSTOMER_DATA - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_assigned_entities_query), ',pin_assigned_entities_query => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_leaf_entities_validation),',pin_leaf_entities_validation => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_leaf_customers_query),    ',pin_leaf_customers_query => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_leaf_customers_query),    ',pin_fill_size_query => <value>', v_stamp);
    END;

    -- ****************************************************************************************************
    -- I. Validate input parameters
    -- ****************************************************************************************************


    -- ****************************************************************************************************
    -- II. Get assignments between user entities and organization hierarchy entities
    -- ****************************************************************************************************

    -- execute query 1
    v_sql := 'INSERT INTO TEMP_ID_ID(ID1, ID2) ' || pin_assigned_entities_query;
    EXECUTE IMMEDIATE v_sql;
    v_entities_count := SQL%ROWCOUNT;

    -- check if there are no assigned entitites for user entity
    IF v_entities_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20920, 'No entitites are assigned to user entity through assignment or hierarchy tables');
    END IF;

    -- ********************************************************************************************************
    -- III. Validate that the assigned entities are in the hierarchy relationship
    -- ********************************************************************************************************

    EXECUTE IMMEDIATE pin_leaf_entities_validation INTO v_leaf_ent_count;
    IF v_leaf_ent_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20921, 'Assigned entities are not in the hierarchy relationships');
    END IF;

    -- ********************************************************************************************************
    -- IV. Return cursor for customer id, customer display fields, leaf id, leaf key field, pin fill, pin size
    -- ********************************************************************************************************

    -- execute query 3
    v_sql := 'INSERT INTO TEMP_ID(ID) SELECT DISTINCT CUSTOMER_ID FROM (' || pin_leaf_customers_query || ')';
    EXECUTE IMMEDIATE v_sql;
    v_customers_count := SQL%ROWCOUNT;

    EXECUTE IMMEDIATE 'INSERT INTO TEMP_TABLE_ID_NAME(ID, NAME) VALUES (' || v_customers_count || ', ''CUSTOMERS_COUNT'')';


    -- open cursor for query 3 and 4
    OPEN pout_customer_to_oh_entities FOR REPLACE(pin_leaf_customers_query, 'rec_for_card_hint', v_entities_count);
    OPEN pout_customer_fill_size FOR REPLACE(pin_fill_size_query, 'rec_for_card_hint', v_customers_count);


END;

-- procedure used for metric validations - will be modified in 16.4 to use a temporary table
PROCEDURE METRIC_VALIDATIONS(pi_pin_entity_id                IN entities.entity_id%TYPE,
                             pi_territory_entity_id          IN entities.entity_id%TYPE,
                             pi_tu_id                        IN time_units.tu_id%TYPE,
                             pi_table_fields_map             IN tabletype_territories_map,
                             pi_metric_ent_field_map         IN tabletype_territories_map, -- <metric table, entity, field>...
                             pi_terr_to_cust_assignment_id   IN NUMBER,          -- assignment table id between terr and customer
                             pi_hierarchy_table_id           IN NUMBER,
                             pi_user_assignment_ids          IN tabletype_territories_map, -- <assign id, org entity, user entity>
                             pi_fields_list                  IN tabletype_number,  -- field list to check if percentage
                             pi_option                       IN NUMBER,  -- 1 - only first 3 validations, 2 - all validations
                             pi_user_entity_id               IN NUMBER
                            )

IS

v_sql            CLOB;
v_failed_records NUMBER;
v_returned_rows  NUMBER;
v_tu_corr_list   VARCHAR2(4000 CHAR);
v_stamp          VARCHAR2(250 CHAR);

BEGIN
  v_stamp := 'TERRITORIES.METRIC_VALIDATIONS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_pin_entity_id),                ',pi_pin_entity_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_territory_entity_id),          ',pi_territory_entity_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_tu_id),                        ',pi_tu_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(pi_table_fields_map),         ',pi_table_fields_map => <value>', v_stamp);
  END;


  -- list of all corresponding periods for the period set in the territories definition
  IF pi_tu_id IS NOT NULL THEN
    SELECT LISTAGG(tuc.tuc_tu_id_corr, ', ') WITHIN GROUP(ORDER BY 1)
      INTO v_tu_corr_list
      FROM tu_correspondence tuc
     WHERE tuc.tuc_tu_id = pi_tu_id;
  END IF;

  -- ****************************************************************************************************
  -- I. Metric table validations
  -- ****************************************************************************************************
  -- If pin entity/territory entity is in metric table
  -- If the territory definition period is not Day :  -- metric table has either no effective range, or has an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- If the territory definition is Day -- metric table is either effective dated or not effective
  -- Field is in entity table or in metric table

  v_sql := ' SELECT COUNT(1)
               FROM TABLE(:table_field_coll) metric_tables
              WHERE (NOT EXISTS ( SELECT 1 FROM tables t
                              INNER JOIN table_columns tc
                                 ON t.tables_id = tc.tc_tables_id
                              WHERE tc.tc_entity_id IN (CASE WHEN search_option IN (0, 1) THEN ' || pi_pin_entity_id || ' END , CASE WHEN search_option = 1 THEN ' || CASE WHEN pi_territory_entity_id IS NULL THEN ' NULL ' ELSE '' || pi_territory_entity_id || '' END || ' END,
                                                        CASE WHEN search_option IN (1, 2) THEN ' ||  CASE WHEN pi_territory_entity_id IS NULL THEN ' NULL ' ELSE '' || pi_territory_entity_id || '' END  || ' END, CASE WHEN search_option = 1 THEN ' || pi_pin_entity_id || ' END,
                                                        CASE WHEN search_option = 3 THEN ' || CASE WHEN pi_user_entity_id IS NULL THEN ' NULL ' ELSE '' || pi_user_entity_id || '' END || ' END
                                                        ) ' ||

                               CASE WHEN pi_tu_id IS NULL
                                    THEN 'AND t.tables_record_dating_option IN (1, 2, 4) '
                                    ELSE 'AND (t.tables_record_dating_option = 1
                                           OR (t.tables_record_dating_option IN (3, 5)
                                          AND t.tables_tu_id IN (' || pi_tu_id || CASE WHEN v_tu_corr_list IS NOT NULL
                                                                                       THEN ',' || v_tu_corr_list
                                                                                  END || '))) '
                               END
                                     || ' AND metric_tables.metric_table_id = t.tables_id)
                OR NOT EXISTS (SELECT 1 FROM table_columns tc
                             WHERE tc.tc_tables_id = CASE WHEN metric_tables.entity_id IS NOT NULL
                                                          THEN (SELECT e.entity_tables_id FROM entities e WHERE e.entity_id = metric_tables.entity_id)
                                                          ELSE metric_tables.metric_table_id
                                                     END
                              AND tc.tc_fld_id = metric_tables.field_id))
                AND ROWNUM <= 1';

  EXECUTE IMMEDIATE v_sql INTO v_failed_records USING pi_table_fields_map;
  IF v_failed_records > 0 THEN
     RAISE_APPLICATION_ERROR(-20920, 'There is a problem displaying the view');
  END IF ;


  -- ****************************************************************************************************
  -- II. List Settings validations
  -- ****************************************************************************************************
  -- One or more fields selected on the List Display sub tab are no longer fields for the entity table specified on the List Metrics sub tab,
  -- entity no longer in metric table

  v_sql :=  'SELECT COUNT(1)'                                                       || chr(10) ||
            '  FROM TABLE(:pi_metric_ent_field_map) metric_tables'                  || chr(10) ||
            ' WHERE NOT EXISTS (SELECT 1'                                           || chr(10) ||
            '                     FROM tables t'                                    || chr(10) ||
            '                    INNER JOIN table_columns tc'                       || chr(10) ||
            '                       ON t.tables_id = tc.tc_tables_id'               || chr(10) ||
            '                    INNER JOIN entities e'                             || chr(10) ||
            '                       ON tc.tc_entity_id = e.entity_id'               || chr(10) ||
            '                    INNER JOIN table_columns tc_ent'                   || chr(10) ||
            '                       ON e.entity_tables_id = tc_ent.tc_tables_id'    || chr(10) ||
            '                    WHERE t.tables_id = metric_tables.metric_table_id' || chr(10) ||
            '                      AND tc.tc_entity_id = metric_tables.entity_id'   || chr(10) ||
            '                      AND tc_ent.tc_fld_id = metric_tables.field_id)'  || chr(10) ||
            ' AND ROWNUM <= 1';

  EXECUTE IMMEDIATE v_sql INTO v_failed_records USING pi_metric_ent_field_map;
  IF v_failed_records > 0 THEN
     RAISE_APPLICATION_ERROR(-20921, 'There is a problem displaying the view');
  END IF ;

  -- ****************************************************************************************************
  -- III. Panel Display sub tab validations - field is not percentage
  -- ****************************************************************************************************
  -- One or more fields specified on the Gauge Chart Metrics sub tab or on the List Metrics sub tab for lists that have the option to display a bar chart
  --             for each entity instance in the list is selected are displayed as percentage fields

  v_sql :=  ' SELECT COUNT(1)'                    || chr(10) ||
            '  FROM TABLE(:pi_fields_list)'       || chr(10) ||
            ' INNER JOIN fields f'                || chr(10) ||
            '    ON f.fld_id = column_value'      || chr(10) ||
            ' WHERE f.fld_display_as_percent = 1' || chr(10) ||
            '   AND ROWNUM <= 1';

    EXECUTE IMMEDIATE v_sql INTO v_failed_records USING pi_fields_list;
    IF v_failed_records > 0 THEN
       RAISE_APPLICATION_ERROR(-20925, 'There is a problem displaying the view');
    END IF ;


  IF pi_option = 2 THEN


  -- ****************************************************************************************************
  -- IV. Entities sub-tab validations
  -- ****************************************************************************************************
  -- The assignment table is an assignment between the specified entities (i.e., the entity that is the lowest node in the organization hierarchy and the entity represented by map pins)
  -- If the territory definition period is not Day :  -- assign table has either no effective range, or has an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- If the territory definition is Day -- assign table is either effective dated or not effective

    v_sql :=  'SELECT COUNT(1)'              || chr(10) ||
              '  FROM entity_assignments ea' || chr(10) ||
              ' INNER JOIN secondary_assignments sa' || chr(10) ||
              '    ON ea.ea_id = sa.sa_ea_id'        || chr(10) ||
              ' INNER JOIN tables t'                 || chr(10) ||
              '    ON ea.ea_tables_id = t.tables_id' || chr(10) ||
              ' WHERE ea.ea_tables_id = ' || pi_terr_to_cust_assignment_id                                  || chr(10) ||
              '   AND ea.ea_entity_id_la IN (' || pi_pin_entity_id || ', ' || pi_territory_entity_id || ')' || chr(10) ||
              '   AND sa.sa_entity_id IN (' || pi_pin_entity_id || ', ' || pi_territory_entity_id || ')'    || chr(10) ||
               CASE WHEN pi_tu_id IS NULL
                    THEN 'AND t.tables_record_dating_option IN (1, 2, 4) '
                    ELSE 'AND (t.tables_record_dating_option = 1
                           OR (t.tables_record_dating_option IN (3, 5)
                          AND t.tables_tu_id IN (' || pi_tu_id || CASE WHEN v_tu_corr_list IS NOT NULL
                                                                       THEN ',' || v_tu_corr_list
                                                                  END || '))) '
               END || chr(10) ||
             ' AND ROWNUM <= 1';

    EXECUTE IMMEDIATE v_sql INTO v_returned_rows;
    IF v_returned_rows = 0 THEN
       RAISE_APPLICATION_ERROR(-20922, 'There is a problem displaying the view');
    END IF ;


  -- ****************************************************************************************************
  -- V. Hierarchy validations
  -- ****************************************************************************************************
  -- If the territory definition period is not Day :  -- hierarchy table has either no effective range, or has an effective range for the same time unit as the
  --                 territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- If the territory definition is Day -- assign table is either effective dated or not effective

    v_sql := ' SELECT COUNT(1) FROM tables t '                  || chr(10) ||
             '  WHERE t.tables_id = ' || pi_hierarchy_table_id  || chr(10) ||
                CASE WHEN pi_tu_id IS NULL
                     THEN 'AND t.tables_record_dating_option IN (1, 2, 4) '
                     ELSE 'AND (t.tables_record_dating_option = 1
                            OR (t.tables_record_dating_option IN (3, 5)
                           AND t.tables_tu_id IN (' || pi_tu_id || CASE WHEN v_tu_corr_list IS NOT NULL
                                                                        THEN ',' || v_tu_corr_list
                                                                   END || '))) '
                END
                || ' AND ROWNUM <= 1';


    EXECUTE IMMEDIATE v_sql INTO v_returned_rows;
    IF v_returned_rows = 0 THEN
       RAISE_APPLICATION_ERROR(-20923, 'There is a problem displaying the view');
    END IF ;


  -- ****************************************************************************************************
  -- VI. User Assignments validations
  -- ****************************************************************************************************
  -- The selected entity is still not in the User Table
  -- The selected user entity still exists in the User Table
  -- The selected assignment table is still an assignment between the selected Entity and User Entity entities (i.e., both the entity for which the assignment table
  --                  is specified and the user entity exist in the assignment table)
  -- If the territory definition period is not Day :  -- assign tables have either no effective range, or have an effective range for the same time unit as the
  --                  territories period, or have an effective range for a corresponding period higher in time unit than the territories period
  -- If the territory definition is Day -- assign table is either effective dated or not effective

    v_sql :=  'SELECT COUNT(1)'                                        || chr(10) ||
              '  FROM TABLE(:pi_user_assignment_ids) user_assignments' || chr(10) ||
              ' WHERE (NOT EXISTS'                                     || chr(10) ||
              '        (SELECT 1'                                      || chr(10) ||
              '           FROM entity_assignments ea'                  || chr(10) ||
              '          INNER JOIN secondary_assignments sa'          || chr(10) ||
              '             ON ea.ea_id = sa.sa_ea_id'                 || chr(10) ||
              '          INNER JOIN tables t '                         || chr(10) ||
              '              ON t.tables_id = ea.ea_tables_id '        || chr(10) ||
              '          WHERE user_assignments.metric_table_id = ea.ea_tables_id' || chr(10) ||
              '            AND ea.ea_entity_id_la IN'                              || chr(10) ||
              '                (user_assignments.entity_id, user_assignments.field_id)'     || chr(10) ||
              '            AND sa.sa_entity_id IN'                                          || chr(10) ||
              '                (user_assignments.entity_id, user_assignments.field_id)'     || chr(10) ||
                CASE WHEN pi_tu_id IS NULL
                     THEN 'AND t.tables_record_dating_option IN (1, 2, 4) '
                     ELSE 'AND (t.tables_record_dating_option = 1
                            OR (t.tables_record_dating_option IN (3, 5)
                           AND t.tables_tu_id IN (' || pi_tu_id || CASE WHEN v_tu_corr_list IS NOT NULL
                                                                        THEN ',' || v_tu_corr_list
                                                                   END || '))) '
                END || ') OR' || chr(10) ||
              '        EXISTS'                                                              || chr(10) ||
              '        (SELECT 1'                                                           || chr(10) ||
              '           FROM tables t'                                                    || chr(10) ||
              '          INNER JOIN table_columns tc'                                       || chr(10) ||
              '             ON t.tables_id = tc.tc_tables_id'                               || chr(10) ||
              '          WHERE t.tables_type = ''USER_TABLE'''                              || chr(10) ||
              '            AND user_assignments.entity_id = tc.tc_entity_id) OR NOT EXISTS' || chr(10) ||
              '        (SELECT 1'                                                           || chr(10) ||
              '           FROM tables t'                                                    || chr(10) ||
              '          INNER JOIN table_columns tc'                                       || chr(10) ||
              '             ON t.tables_id = tc.tc_tables_id'                               || chr(10) ||
              '          WHERE t.tables_type = ''USER_TABLE'''                              || chr(10) ||
              '            AND user_assignments.field_id = tc.tc_entity_id))'               || chr(10) ||
              '   AND ROWNUM <= 1';

    EXECUTE IMMEDIATE v_sql INTO v_failed_records USING pi_user_assignment_ids;
    IF v_failed_records > 0 THEN
       RAISE_APPLICATION_ERROR(-20924, 'There is a problem displaying the view');
    END IF ;

  END IF;

END METRIC_VALIDATIONS;


-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END TERRITORIES;
/
