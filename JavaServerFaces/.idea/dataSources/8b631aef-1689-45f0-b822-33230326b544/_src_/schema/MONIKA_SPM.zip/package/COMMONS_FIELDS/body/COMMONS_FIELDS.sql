CREATE PACKAGE BODY COMMONS_FIELDS AS

PROCEDURE ADD_SYSTEM_FIELDS (
          pin_FLD_BUSINESS_NAME varchar2
          ,pin_FLD_COLUMN_NAME varchar2
          ,pin_FLD_LENGTH NUMBER
          ,pin_FLD_DATA_TYPE  NUMBER
          ,pin_FLD_TIMEUNIT  NUMBER
          ,pin_FLD_BASE_FIELD NUMBER
		  ,pin_FLD_UNIQUE_INTERNAL_NAME VARCHAR2 default null
          )

AS

V_FLD_UNIQUE_INTERNAL_NAME fields.FLD_UNIQUE_INTERNAL_NAME%type;

BEGIN

  V_FLD_UNIQUE_INTERNAL_NAME := nvl(pin_FLD_UNIQUE_INTERNAL_NAME,pin_FLD_BUSINESS_NAME);

  --1 - rename user field if it has the same name as new system field
  EXECUTE IMMEDIATE '
           DECLARE v_cnt NUMBER(10); v_new FIELDS.FLD_BUSINESS_NAME%TYPE;
           BEGIN
               FOR c in (select FLD_BUSINESS_NAME as text FROM FIELDS where UPPER(FLD_BUSINESS_NAME) = UPPER(''' || pin_FLD_BUSINESS_NAME || ''') AND FLD_TYPE in(2,3)) LOOP
                   FOR i in 1..99 LOOP
                     v_new := SUBSTR(c.text, 1, 30 - CASE WHEN LENGTH(c.text || i) - 30 < 1 THEN 0
                                                          ELSE LENGTH(c.text || i) - 30 END) || TO_CHAR(i);
                     SELECT COUNT(1) INTO v_cnt FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(v_new);
                     IF (v_cnt = 0) THEN
                       UPDATE FIELDS
                       SET FLD_BUSINESS_NAME = v_new
                          ,FLD_UNIQUE_INTERNAL_NAME = v_new
                       WHERE FLD_BUSINESS_NAME = c.text;
                     END IF;
                     EXIT WHEN v_cnt = 0;
                   END LOOP;
               END LOOP;
           END;
  ';

  --2 - raise error if new system fields have same name but different datatype/len that an existing one
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' || pin_FLD_BUSINESS_NAME || ''') AND FLD_TYPE = 1 AND (FLD_DATA_TYPE != ' || pin_FLD_DATA_TYPE || ' OR ' || (CASE WHEN pin_FLD_LENGTH IS NULL THEN ' FLD_LENGTH IS NOT NULL ' ELSE ' FLD_LENGTH != ' || pin_FLD_LENGTH END ) || ' OR FLD_IS_PREDEFINED != 1)) LOOP
            raise_application_error(-20001, ''Field <<' || pin_FLD_BUSINESS_NAME || '>> already exists with a different datatype or a different length or it is not a predefined one. Cannot add the new field.'');
          END LOOP;
          END;
  ';

  --3 - skip insert if new system fields have same name, datatype and len with an existing one
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' || pin_FLD_BUSINESS_NAME || ''') AND FLD_DATA_TYPE = ' || pin_FLD_DATA_TYPE || ' AND ' || (CASE WHEN pin_FLD_LENGTH IS NULL THEN ' FLD_LENGTH IS NULL ' ELSE ' FLD_LENGTH = ' || pin_FLD_LENGTH END ) || ' AND FLD_IS_PREDEFINED = 1) LOOP
            DBMS_OUTPUT.put_line(''Field <<' || pin_FLD_BUSINESS_NAME || '>> already exists. Will keep the existing one'');
          END LOOP;
          END;
  ';

  --4 - add new system field if there is no old system field with the same name

  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' || pin_FLD_BUSINESS_NAME || '''))) LOOP
            INSERT INTO FIELDS (FLD_ID, FLD_BUSINESS_NAME, FLD_COLUMN_NAME, FLD_LENGTH, FLD_DATA_TYPE, FLD_TYPE, FLD_TIMEUNIT, FLD_IS_PREDEFINED, OBJECT_VERSION, FLD_BASE_FIELD, FLD_UNIQUE_INTERNAL_NAME)
            VALUES (UID_Sequence.nextval, ''' || pin_FLD_BUSINESS_NAME || ''', ''' || pin_FLD_COLUMN_NAME || ''',' || COALESCE(to_char(pin_FLD_LENGTH), 'NULL') || ',' || pin_FLD_DATA_TYPE || ',1 ,' || COALESCE(to_char(pin_FLD_TIMEUNIT), 'NULL') || ',1 ,0 ,' || COALESCE(to_char(pin_FLD_BASE_FIELD), 'NULL') || ', ''' || V_FLD_UNIQUE_INTERNAL_NAME || ''');
          END LOOP;
          END;
	';
END ADD_SYSTEM_FIELDS;



PROCEDURE ADD_SYSTEM_FIELDS (
          pin_FLD_BUSINESS_NAME varchar2
          ,pin_FLD_COLUMN_NAME varchar2
          ,pin_FLD_LENGTH NUMBER
          ,pin_FLD_DATA_TYPE  NUMBER
          ,pin_FLD_TIMEUNIT  NUMBER
          ,pin_FLD_BASE_FIELD NUMBER
		  ,pin_FLD_UNIQUE_INTERNAL_NAME VARCHAR2
          ,pin_FLD_DISPLAY_1000_SEPARATOR NUMBER
          ,pin_FLD_DISPLAY_AS_PERCENT NUMBER
         )
AS

V_FLD_UNIQUE_INTERNAL_NAME fields.FLD_UNIQUE_INTERNAL_NAME%type;

BEGIN

  V_FLD_UNIQUE_INTERNAL_NAME := nvl(pin_FLD_UNIQUE_INTERNAL_NAME,pin_FLD_BUSINESS_NAME);

  --1 - rename user field if it has the same name as new system field
  EXECUTE IMMEDIATE '
           DECLARE v_cnt NUMBER(10); v_new FIELDS.FLD_BUSINESS_NAME%TYPE;
           BEGIN
               FOR c in (select FLD_BUSINESS_NAME as text FROM FIELDS where UPPER(FLD_BUSINESS_NAME) = UPPER(''' || pin_FLD_BUSINESS_NAME || ''') AND FLD_TYPE in(2,3)) LOOP
                   FOR i in 1..99 LOOP
                     v_new := SUBSTR(c.text, 1, 30 - CASE WHEN LENGTH(c.text || i) - 30 < 1 THEN 0
                                                          ELSE LENGTH(c.text || i) - 30 END) || TO_CHAR(i);
                     SELECT COUNT(1) INTO v_cnt FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(v_new);
                     IF (v_cnt = 0) THEN
                       UPDATE FIELDS
                       SET FLD_BUSINESS_NAME = v_new
                          ,FLD_UNIQUE_INTERNAL_NAME = v_new
                       WHERE FLD_BUSINESS_NAME = c.text;
                     END IF;
                     EXIT WHEN v_cnt = 0;
                   END LOOP;
               END LOOP;
           END;
  ';

  --2 - raise error if new system fields have same name but different datatype/len that an existing one
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' ||pin_FLD_BUSINESS_NAME ||''') AND FLD_TYPE = 1 AND (FLD_DATA_TYPE != ' ||
                    pin_FLD_DATA_TYPE || ' OR ' || (CASE
                      WHEN pin_FLD_LENGTH IS NULL THEN
                       ' FLD_LENGTH IS NOT NULL '
                      ELSE
                       ' FLD_LENGTH != ' || pin_FLD_LENGTH
                    END) ||
                    ' OR FLD_IS_PREDEFINED != 1)) LOOP
            raise_application_error(-20001, ''Field <<' ||
                    pin_FLD_BUSINESS_NAME || '>> already exists with a different datatype or a different length or it is not a predefined one. Cannot add the new field.'');
          END LOOP;
          END;
  ';

  --3 - skip insert if new system fields have same name, datatype and len with an existing one
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' ||pin_FLD_BUSINESS_NAME || ''') AND FLD_DATA_TYPE = ' ||
                    pin_FLD_DATA_TYPE || ' AND ' || (CASE
                      WHEN pin_FLD_LENGTH IS NULL THEN
                       ' FLD_LENGTH IS NULL '
                      ELSE
                       ' FLD_LENGTH = ' || pin_FLD_LENGTH
                    END) || ' AND FLD_IS_PREDEFINED = 1) LOOP
            DBMS_OUTPUT.put_line(''Field <<' ||
                    pin_FLD_BUSINESS_NAME || '>> already exists. Will keep the existing one'');
          END LOOP;
          END;
  ';

  --4 - add new system field if there is no old system field with the same name
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' ||pin_FLD_BUSINESS_NAME ||'''))) LOOP
            INSERT INTO FIELDS (FLD_ID, FLD_BUSINESS_NAME, FLD_COLUMN_NAME, FLD_LENGTH, FLD_DATA_TYPE, FLD_TYPE, FLD_TIMEUNIT, FLD_IS_PREDEFINED, OBJECT_VERSION, FLD_BASE_FIELD, FLD_DISPLAY_THOUSAND_SEPARATOR, FLD_DISPLAY_AS_PERCENT, FLD_UNIQUE_INTERNAL_NAME)
            VALUES (UID_Sequence.nextval, ''' ||
                    pin_FLD_BUSINESS_NAME || ''', ''' ||
                    pin_FLD_COLUMN_NAME || ''',' ||
                    COALESCE(to_char(pin_FLD_LENGTH), 'NULL') || ',' ||
                    pin_FLD_DATA_TYPE || ',1 ,' ||
                    COALESCE(to_char(pin_FLD_TIMEUNIT), 'NULL') ||
                    ',1 ,0 ,' ||
                    COALESCE(to_char(pin_FLD_BASE_FIELD), 'NULL') || ', ' ||
                    COALESCE(to_char(pin_FLD_DISPLAY_1000_SEPARATOR),
                             'NULL') || ', ' ||
                    COALESCE(to_char(pin_FLD_DISPLAY_AS_PERCENT), 'NULL') || ', ''' ||
                    V_FLD_UNIQUE_INTERNAL_NAME || ''');
          END LOOP;
          END;
  ';

END ADD_SYSTEM_FIELDS;





PROCEDURE RENAME_SYSTEM_FIELD (
      PI_OLD_FLD_BUSINESS_NAME IN VARCHAR2
      , PI_NEW_FLD_BUSINESS_NAME IN VARCHAR2
      ,PI_NEW_FLD_UNQ_INTERNAL_NAME VARCHAR2 default null)
AS
V_FLD_UNIQUE_INTERNAL_NAME VARCHAR2(100 char) := nvl(PI_NEW_FLD_UNQ_INTERNAL_NAME,PI_NEW_FLD_BUSINESS_NAME);
OLD_FLD_STATUS BOOLEAN:=FALSE;
BEGIN

	FOR c IN (SELECT FLD_ID FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME)=UPPER(PI_OLD_FLD_BUSINESS_NAME) AND FLD_TYPE=1 AND FLD_IS_PREDEFINED=1)
	LOOP
	OLD_FLD_STATUS := TRUE;
 --1 - rename user field if it has the same name as new system field
  EXECUTE IMMEDIATE '
           DECLARE v_cnt NUMBER(10); v_new FIELDS.FLD_BUSINESS_NAME%TYPE;
           BEGIN
               FOR c in (select FLD_BUSINESS_NAME as text FROM FIELDS where UPPER(FLD_BUSINESS_NAME) = UPPER(''' || PI_NEW_FLD_BUSINESS_NAME || ''') AND FLD_TYPE in(2,3)) LOOP
                   FOR i in 1..99 LOOP
                     v_new := SUBSTR(c.text, 1, 30 - CASE WHEN LENGTH(c.text || i) - 30 < 1 THEN 0
                                                          ELSE LENGTH(c.text || i) - 30 END) || TO_CHAR(i);
                     SELECT COUNT(1) INTO v_cnt FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(v_new);
                     IF (v_cnt = 0) THEN
                       UPDATE FIELDS
                       SET FLD_BUSINESS_NAME = v_new
                          ,FLD_UNIQUE_INTERNAL_NAME = v_new
                       WHERE FLD_BUSINESS_NAME = c.text;
                     END IF;
                     EXIT WHEN v_cnt = 0;
                   END LOOP;
               END LOOP;
           END;
  ';
  --2 - raise error if new system fields have same name and/or that an existing one
  EXECUTE IMMEDIATE '
          BEGIN
          FOR c IN (SELECT 1 FROM FIELDS WHERE UPPER(FLD_BUSINESS_NAME) = UPPER(''' || PI_NEW_FLD_BUSINESS_NAME || ''') AND FLD_TYPE = 1 ) LOOP
            raise_application_error(-20002, ''Field <<' || PI_NEW_FLD_BUSINESS_NAME || '>> already exists. Cannot update '||PI_OLD_FLD_BUSINESS_NAME||' to the same name.'');
          END LOOP;
          END;
  ';
--3 rename the field if new system field does not exist.
  EXECUTE IMMEDIATE '
          BEGIN
               	UPDATE FIELDS SET FLD_BUSINESS_NAME='''||PI_NEW_FLD_BUSINESS_NAME||''',
				FLD_UNIQUE_INTERNAL_NAME='''||V_FLD_UNIQUE_INTERNAL_NAME||'''
				WHERE FLD_ID='''||c.FLD_ID||''';
          END;
	';
	END LOOP;
-- If it will not go inside the above loop then by default value of boolean variable will be FALSE
	IF OLD_FLD_STATUS=FALSE THEN
	RAISE_APPLICATION_ERROR(-20001, 'Field <<' || PI_OLD_FLD_BUSINESS_NAME || '>> Does Not Exist As A System Field');
	END IF;
END RENAME_SYSTEM_FIELD;

PROCEDURE RENAME_SYSTEM_FIELD (
      PI_OLD_FLD_BUSINESS_NAME IN VARCHAR2
      , PI_NEW_FLD_BUSINESS_NAME IN VARCHAR2
      ,PI_NEW_FLD_UNIQUE_INTERNAL_NAM VARCHAR2 default null)
AS
begin
RENAME_SYSTEM_FIELD (
      PI_OLD_FLD_BUSINESS_NAME =>PI_OLD_FLD_BUSINESS_NAME,
      PI_NEW_FLD_BUSINESS_NAME =>PI_NEW_FLD_BUSINESS_NAME,
      PI_NEW_FLD_UNQ_INTERNAL_NAME =>PI_NEW_FLD_UNIQUE_INTERNAL_NAM);

end RENAME_SYSTEM_FIELD;

end COMMONS_FIELDS;
/
