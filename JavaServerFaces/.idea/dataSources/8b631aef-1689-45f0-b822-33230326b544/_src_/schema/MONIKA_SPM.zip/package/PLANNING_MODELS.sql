CREATE PACKAGE PLANNING_MODELS AS



PROCEDURE GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST TABLETYPE_MDL_DIM_PATH_EXP,
                                                    PO_TU_SELECT         OUT CLOB,
                                                    PO_TU_COLUMNS        OUT CLOB
                                                   );
PROCEDURE GET_REBUILT_FROM_CLAUSE( PI_TU_SELECT         IN  CLOB,
                                   PI_TU_COLUMNS        IN  CLOB,
                                   PI_ORIG_FROM_CLAUSE  IN  CLOB,
                                   PI_TABLE_NAME        IN  CLOB,
                                   PI_DIM_TYPE          IN  NUMBER,
                                   PO_FROM_CLAUSE       OUT CLOB);


/* FORMAT_CONSTANT_VALUE
-----------------------------------------------------------------------------------------------
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016.05.31
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
*/
FUNCTION FORMAT_CONSTANT_VALUE
(    pi_dim_type        VARCHAR2
    ,pi_dim_data_type   NUMBER
    ,pi_dim_value       VARCHAR2
) RETURN VARCHAR2;

/* FORMAT_COLUMN_FOR_DISPLAY
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-08-09
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get the formatted display of a value.
-----------------------------------------------------------------------------------------------
*/
FUNCTION FORMAT_COLUMN_FOR_DISPLAY
(    pi_col_name            VARCHAR2
    ,pi_col_data_type       NUMBER
    ,pi_col_length          NUMBER
    ,pi_col_th_separator    NUMBER
    ,pi_col_percent         NUMBER
    ,pi_col_period_prefix   VARCHAR2
    ,pi_session_separator   NUMBER
) RETURN VARCHAR2;


/* GET_DIMENSION_LIST
-- Author       : Dumitriu, Cosmin
-- Create date  : 2017-03-27
-- Reviewer     :
-- Review date  :
-- Description  : This is a helping function to get the hierarchy of dimensions for rows or columns of a pivot view.
-----------------------------------------------------------------------------------------------
-- Assumptions:
     pi_model_table_id  NUMBER - NOT NULL - the id of the model table from TABLES_ID
    ,pi_view_def        CLOB - NOT NULL - the xml stored in the OBJECT_DEFINITIONS.OD_DEFINITION
    ,pi_xml_path        VARCHAR2 - NOT NULL - depending whether the rows or columns are expanded:
                            * '/pivotView/rows/dimensions/dimension'
                            * '/pivotView/columns/dimensions/dimension'
    ,pi_parent_path     TABLETYPE_MDL_DIM_PATH - NULL - a list of levels already expanded

return:
    - depending on whether the record or the column pivot hierarchy must be expanded
      this parameter will contain the entire list of dimensions on that side
      ordered by DIM_ORDER
    - for parent levels that have been expanded the DIM_VALUE attribute will be populated
      with the value expanded on that particular level
            dim_id                  - field or entity id taken from xml/dimensionId
            dim_type                - 'FIELD'/'ENTITY' taken from xml/dimensionType
            dim_name                - the column physical name from the model table
            dim_data_type           - the field data type as taken from FLD_DATA_TYPE
            dim_order               - order of entity/field in the pivot hierarchy
            dim_display_fld_id      - the field id to display - taken from xml/displayFieldId
            dim_display_entity_bk   - 1/0 depending on whether we need to display bk also - taken from xml/displayAlsoDimensionId
            dim_value               - if this level has been expanded - the id of the expanded cell ex: '1001' / 'john'

            DIM_ID  DIM_TYPE    DIM_NAME    DIM_DATA_TYPE   DIM_ORDER   DIM_DISPLAY_FLD_ID  DIM_DISPLAY_ENTITY_BK    DIM_VALUE
            123     ENTITY      E200        -               1           342                 0                       '1001'
            234     ENTITY      E400        -               2           754                 1                       'john'
            564     FIELD       F890        3               3           -                   -

*/
FUNCTION GET_DIMENSION_LIST
(    pi_model_table_id  NUMBER
    ,pi_view_def        CLOB
    ,pi_xml_path        VARCHAR2
    ,pi_parent_path     TABLETYPE_MDL_DIM_PATH
) RETURN TABLETYPE_MDL_DIM_PATH_EXP;


/* GET_ENTITY_QUERY
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-16
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get the query of an entity table in the format
                  needed by the GENERATE_COMBINATIONS SP.
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the entity ID that needs to be used

return value: a string in the format
    SELECT E_INTERNAL_ID as E243 FROM T7898

*/
FUNCTION GET_ENTITY_QUERY
(    pi_definition_id   NUMBER
) RETURN CLOB;


/* GET_ASSIGNMENT_QUERY
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-16
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get the query of an assignment table in the format
                  needed by the GENERATE_COMBINATIONS SP.
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the entity assignment ID that needs to be used

return value: a string in the format
    SELECT E243, E546 FROM T7898

*/
FUNCTION GET_ASSIGNMENT_QUERY
(    pi_definition_id   NUMBER
) RETURN CLOB;


/* GET_HIERARCHY_QUERY
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-16
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get the query of an hierarchy table in the format
                  needed by the GENERATE_COMBINATIONS SP.
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the hierarchy definition ID that needs to be used

return value: a string in the format
    SELECT   T4331001.E4330996  AS E4330835 --LVL1 - Region
            ,T4331017.E4330998  AS E4330891 --LVL2 - State
            ,T4331017.E4330997  AS E4330908 --LVL3 - County
    FROM    T4331017
            INNER JOIN T4331001  ON T4331017.E4330998 = T4331001.E4330995;

*/
FUNCTION GET_HIERARCHY_QUERY
(    pi_definition_id   NUMBER
) RETURN CLOB;


/* GET_MODEL_RELATIONSHIPS
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-09
-- Reviewer     :
-- Review date  :
-- Description  : This is a temporary function that based on what a model has registered in SPM_ENTITIES
--                will look at the new p[hysical structure of the tables and return the UPPER > LOWER pairs as they would be stored in SPM_ENTITY_RELATIONSHIPS.
--                It will be used to compare actual values from SPM_ENTITY_RELATIONSHIPS and the new computed values from the physical struct
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_MODEL_RELATIONSHIPS
(    pi_definition_id           IN NUMBER
) RETURN TABLETYPE_MDL_RELATIONSHIPS;


/* GET_MODEL_DIMENSIONS
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-09
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get all entities within all relations of a model table.

            - this procedure is to be called when the data in SPM_ENTITY_RELATIONSHIPS has been populated by Java
            - prior to actually creating / regenerating the model table.

            - there is an additional GET_MODEL_CHANGED_DIMENSIONS procedure that is called whenever a hierarchy/assignment table structure is changed
            - and we want to test to see if according to the logic of joining all dimensions the key column combination f the model has changed
            - in this case we do not want to overwrite the metadata in SPM_ENTITY_RELATIONSHIPS and we recieve this via a parameter
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the model definition id in SALES_PLANNING_MODELS.SPM_ID

return value: TABLETYPE_MDL_DIMENSIONS
     DEF_ORDER          - order of the relationship (hierarchy, assignment, entity) within the model definition
    ,REL_ID             - SPME_ID of the relationship
    ,DEF_ID             - DEF_ID of the relationship
    ,DEF_TYPE_ID        - DEF_TYPE of the relationship 12=entity, 15=hierarchy, 9=assignment
    ,DIM_ORDER_IN_DEF   - order of the dimension within it's parent relationship
    ,ENTITY_ID          - if dimension is an entity - the entity ID
    ,FLD_ID             - if dimension is a field - the fld ID

example:
TABLETYPE_MDL_DIMENSIONS  --DEF_ORDER   ,REL_ID ,DEF_ID ,DEF_TYPE_ID,DIM_ORDER_IN_DEF   ,ENTITY_ID  ,FLD_ID
(    OBJTYPE_MDL_DIMENSIONS(1           ,111    ,121    ,15         ,1                  ,100        ,NULL) -- REGION
    ,OBJTYPE_MDL_DIMENSIONS(1           ,111    ,121    ,15         ,2                  ,200        ,NULL) -- STATE
    ,OBJTYPE_MDL_DIMENSIONS(1           ,111    ,121    ,15         ,3                  ,300        ,NULL) -- CITY
    ,OBJTYPE_MDL_DIMENSIONS(2           ,112    ,122    ,9          ,1                  ,200        ,NULL) -- STATE
    ,OBJTYPE_MDL_DIMENSIONS(2           ,112    ,122    ,9          ,2                  ,400        ,NULL) -- ACCOUNT
    ,OBJTYPE_MDL_DIMENSIONS(3           ,113    ,123    ,12         ,1                  ,500        ,NULL) -- PRODUCT
)
*/
FUNCTION GET_MODEL_DIMENSIONS
(    pi_definition_id           IN NUMBER
) RETURN TABLETYPE_MDL_DIMENSIONS;


/* GET_MODEL_CHANGED_DIMENSIONS
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-09
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get all entities within all relations of a model table.

            - this procedure is used for testing changes in the key field combination of a model table
            - look into the GET_MODEL_DIMENSIONS sp header to see the difference
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_MODEL_CHANGED_DIMENSIONS
(    pi_definition_id           IN NUMBER
    ,pi_entity_relationships    IN TABLETYPE_MDL_RELATIONSHIPS
) RETURN TABLETYPE_MDL_DIMENSIONS;


/* GET_MODEL_DISTINCT_DIMENSIONS
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-09
-- Reviewer     :
-- Review date  :
-- Description  : This is a function to get all distinct dimensions within the model table. This includes a record for each entity
                  plus a record for the Scenario field, plus a record for the applicable period field.
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the model definition id in SALES_PLANNING_MODELS.SPM_ID
    ,pi_entity_relationships    IN TABLETYPE_MDL_RELATIONSHIPS
                                - if this param is not populated then get data from the metadata tables
                                - if it is populated then get data from the param

return value - cursor of columns:
    DIM_ORDER   NUMBER
    ENTITY_ID   NUMBER
    FLD_ID      NUMBER
    IS_KEY      NUMBER

return example: suppose a model that has the below relationships. Notice how State is both in a hrc and an assign.

    TABLETYPE_MDL_DIMENSIONS  --DEF_ORDER   ,REL_ID ,DEF_ID ,DEF_TYPE_ID,DIM_ORDER_IN_DEF   ,ENTITY_ID  ,FLD_ID
    (    OBJTYPE_MDL_DIMENSIONS(1           ,111    ,121    ,15         ,1                  ,100        ,NULL) -- REGION
        ,OBJTYPE_MDL_DIMENSIONS(1           ,111    ,121    ,15         ,2                  ,200        ,NULL) -- STATE
        ,OBJTYPE_MDL_DIMENSIONS(1           ,111    ,121    ,15         ,3                  ,300        ,NULL) -- CITY
        ,OBJTYPE_MDL_DIMENSIONS(2           ,112    ,122    ,9          ,1                  ,200        ,NULL) -- STATE
        ,OBJTYPE_MDL_DIMENSIONS(2           ,112    ,122    ,9          ,2                  ,400        ,NULL) -- ACCOUNT
        ,OBJTYPE_MDL_DIMENSIONS(3           ,113    ,123    ,12         ,1                  ,500        ,NULL) -- PRODUCT
    )

the cursor will contain:
DIM_ORDER   ENTITY_ID   FLD_ID  IS_KEY
--------------------------------------
1           100          -      0           --for entity REGION
2           200          -      0           --for entity STATE
3           300          -      1           --for entity CITY
4           400          -      1           --for entity ACCOUNT
5           500          -      1           --for entity PRODUCT
6           -            465    1           --for field Quarter
7           -            365    1           --for field Scenario

*/
FUNCTION GET_MODEL_DISTINCT_DIMENSIONS
(    pi_definition_id           IN NUMBER
    ,pi_entity_relationships    IN TABLETYPE_MDL_RELATIONSHIPS DEFAULT NULL
) RETURN SYS_REFCURSOR;


/* GET_SQL_FOR_GENERATE_COMB_TMP
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-09
-- Description  : This should be something temporary until Java can provide the full queries needed in pi_dimension_queries parameter
                    to actually call GET_SQL_FOR_GENERATE_COMB. It's just a wrapper to compute also the aforementioned param.
                    See GET_SQL_FOR_GENERATE_COMB for a more detailed description.
*/
PROCEDURE GET_SQL_FOR_GENERATE_COMB_TMP
(    pi_definition_id           IN NUMBER
    ,po_sql                     OUT CLOB
);


/* GET_SQL_FOR_GENERATE_COMB
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-09
-- Reviewer     :
-- Review date  :
-- Description  : This procedure will build a query to be executed on the PLA schema in order to create all possible combinations
                 and store them in the model table.
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the model definition id in SALES_PLANNING_MODELS.SPM_ID

    ,pi_dimension_queries       IN TABLETYPE_ID_QUERY - a collection with a record for every distinct relationship (hrc, assign, entity)
                                ID      - SPME_ID of the relationship
                                QUERY   - a query that filters the given relationship and returns a column for each distinct dimension in the relationship
                                            * for an assignment the select will contain something similar to "SELECT E1, E2, E3 from T_ASSIGN WHERE filter"
                                            * for ahierarchy the select will contain something similar to "SELECT E1, E2, E3 from (flatten hierarchy query) WHERE filter"
                                            * for an entity the select will contain something similar to "SELECT E_INTERNAL_ID AS E5 from T_ENTITY WHERE filter"
                                        - if the relationship is not filtered than you can leave aside the where clause.
                                        - all relationships must be provided with a query.
    ,po_sql                     OUT CLOB
                                - will return the query to execute.
*/
PROCEDURE GET_SQL_FOR_GENERATE_COMB
(    pi_definition_id           IN NUMBER
    ,pi_dimension_queries       IN TABLETYPE_ID_QUERY
    ,po_sql                     OUT CLOB
);


/* GET_SQL_FOR_LOAD_DATA
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-05-04
-- Reviewer     :
-- Review date  :
-- Description  : This is the procedure that will construct the query to execute on PLA for loading records into model tables.
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the model definition id in SALES_PLANNING_MODELS.SPM_ID

    ,pi_temp_table_name         IN VARCHAR2
                                NOT NULL: - the name of the temporary table in which Data Load keeps the loaded records
                                ex: 'DL_24sde234'

    ,pi_column_mapping          IN TABLETYPE_CHARMAX
                                NOT NULL: - a collection containing the list of columns in the source temp table
                                - it will have to contain all key fields/effective dated columns, plus at least an input column
                                ex:  TABLETYPE_CHARMAX('E123','E543','F256')

    ,po_sql                     OUT CLOB
                                - will return the query to execute.

-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_LOAD_DATA
(    pi_definition_id           IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_CHARMAX
    ,po_sql                     OUT CLOB
);


/* GET_SQL_FOR_LOAD_DATA_MOD
-- Author       : Dumitriu, Cosmin
-- Create date  : 2016-09-22
-- Reviewer     :
-- Review date  :
-- Description  : This is the procedure that will serve as a post Data Load operation to get affected fields and records
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
                                NOT NULL: - the model definition id in SALES_PLANNING_MODELS.SPM_ID

    ,pi_temp_table_name         IN VARCHAR2
                                NOT NULL: - the name of the temporary table in which Data Load keeps the loaded records
                                ex: 'DL_24sde234'

    ,pi_column_mapping          IN TABLETYPE_CHARMAX
                                NOT NULL: - a collection containing the list of columns in the source temp table
                                - it will have to contain all key fields/effective dated columns, plus at least an input column
                                ex:  TABLETYPE_CHARMAX('E123','E543','F256')

    ,po_updated_fld_ids         OUT TABLETYPE_NUMBER
                                - a collection of fields that have been updated

    ,po_sql                     OUT CLOB
                                - a query to execute on PLA to get the record IDs affected by the data load

-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_LOAD_DATA_MOD
(    pi_definition_id           IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_CHARMAX
    ,po_updated_fld_ids         OUT TABLETYPE_NUMBER
    ,po_sql                     OUT CLOB
);


/* GET_SQL_FOR_PIVOT_STRUCTURE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  : The procedure will be used to construct the query for getting the records / columns that must be part of the pivot view structure
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_view_id             NUMBER      - NOT NULL
                                    - the view definition id as taken from OBJECT_DEFINITIONS.OD_CONTAINER_ID

    ,pi_axis_type           NUMBER      - NOT NULL
                                    - (1-rows, 2-columns) - if you want to expand a row or a column

    ,pi_from_clause         CLOB        - NULL
                                    - if filters have been defined in the pivot view, the model table is filtered with a query
                                    - this from clause will contain a SELECT with all columns in the table as they are named there

    ,pi_parent_id           VARCHAR2    - NULL when first displaying initial view/ NOT NULL when expanding a node
                                    - populated with the ID of the node to expand (can be row/column)
                                    - it should be in sync with pi_parent_path

    ,pi_expanded_dim_list   TABLETYPE_MDL_DIM_PATH_EXP - NULL
                                    - depending on whether the record or the column pivot hierarchy must be expanded
                                      this parameter will contain the entire list of dimensions on that side
                                      ordered by DIM_ORDER
                                    - for parent levels that have been expanded the DIM_VALUE attribute will be populated
                                      with the value expanded on that particular level
                    dim_id                  - field or entity id taken from xml/dimensionId
                    dim_type                - 'FIELD'/'ENTITY' taken from xml/dimensionType
                    dim_name                - the column physical name from the model table
                    dim_data_type           - the field data type as taken from FLD_DATA_TYPE
                    dim_order               - order of entity/field in the pivot hierarchy
                    dim_display_fld_id      - the field id to display - taken from xml/displayFieldId
                    dim_display_entity_bk   - 1/0 depending on whether we need to display bk also - taken from xml/displayAlsoDimensionId
                    dim_value               - if this level has been expanded - the id of the expanded cell ex: '1001' / 'john'

            DIM_ID  DIM_TYPE    DIM_NAME    DIM_DATA_TYPE   DIM_ORDER   DIM_DISPLAY_FLD_ID  DIM_DISPLAY_ENTITY_BK    DIM_VALUE
            123     ENTITY      E200        -               1           342                 0                       '1001'
            234     ENTITY      E400        -               2           754                 1                       'john'
            564     FIELD       F890        3               3           -                   -

output query:
          CHILD_ID          VARCHAR2 - used to identify a particular node. will contain all parent ids separated by CHR(0)
        , DISPLAY_VALUE     VARCHAR2 - the display form of an ID

    CHILD_ID   DISPLAY_VALUE
    -------------------------
    1               John
    2               Mary
    3               Wully
    -------------------------
    1/546           Q1 2010
    1/323           Q2 2014
    -------------------------
    1/546/Actuals   Actuals
    1/546/Basic     Basic
    -------------------------
    10232           10232
    10232           10232

-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SQL_FOR_PIVOT_STRUCTURE
(    pi_view_id             NUMBER
    ,pi_axis_type           NUMBER
    ,pi_from_clause         CLOB
    ,pi_parent_id           VARCHAR2
    ,pi_expanded_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_login_id            VARCHAR2 DEFAULT NULL
) RETURN CLOB;


/* GET_SQL_FOR_PIVOT_VALUES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  : The procedure will be used to construct the query for getting the pivot view values
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_view_id             NUMBER      - NOT NULL
                                    - the view definition id as taken from OBJECT_DEFINITIONS.OD_CONTAINER_ID

    ,pi_axis_type           NUMBER      - NOT NULL
                                    - 0 - the initial view is displayed and values must be provided for all row/col cells
                                    - 1 - a row has been expanded and all children must be computed
                                    - 2 - a column has been expanded and all children must be computed

    ,pi_max_opposite_level  NUMBER   - NOT NULL when pi_axis_type in (1, 2)
                                    - this will show how many levels have been expanded so far on the opposite axis

    ,pi_opp_root_exp_items  TABLETYPE_CHARMAX - NULL
                                    - the list of items that have been previously expanded on the first level of the opposite axis
                                    - items are IDs of rows/columns similar to "pi_parent_id" values
                                    - sent for performance reasons

    ,pi_from_clause         CLOB        - NULL
                                    - if filters have been defined in the pivot view, the model table is filtered with a query
                                    - this from clause will contain a SELECT with all columns in the table as they are named there

    ,pi_parent_id           VARCHAR2    - NULL when first displaying initial view/ NOT NULL when expanding a node - pi_axis_type in (1, 2)
                                    - populated with the ID of the node to expand (can be row/column)
                                    - it should be in sync with pi_parent_path

    ,pi_expanded_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
                                    - depending on whether the record or the column pivot hierarchy must be expanded
                                      this parameter will contain the entire list of dimensions on that side
                                      ordered by DIM_ORDER
                                    - for parent levels that have been expanded the DIM_VALUE attribute will be populated
                                      with the value expanded on that particular level
                    dim_id                  - field or entity id taken from xml/dimensionId
                    dim_type                - 'FIELD'/'ENTITY' taken from xml/dimensionType
                    dim_name                - the column physical name from the model table
                    dim_data_type           - the field data type as taken from FLD_DATA_TYPE
                    dim_order               - order of entity/field in the pivot hierarchy
                    dim_display_fld_id      - the field id to display - taken from xml/displayFieldId
                    dim_display_entity_bk   - 1/0 depending on whether we need to display bk also - taken from xml/displayAlsoDimensionId
                    dim_value               - if this level has been expanded - the id of the expanded cell ex: '1001' / 'john'

            DIM_ID  DIM_TYPE    DIM_NAME    DIM_DATA_TYPE   DIM_ORDER   DIM_DISPLAY_FLD_ID  DIM_DISPLAY_ENTITY_BK    DIM_VALUE
            123     ENTITY      E200        -               1           342                 0                       '1001'
            234     ENTITY      E400        -               2           754                 1                       'john'
            564     FIELD       F890        3               3           -                   -

    ,pi_opposite_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
                                    - the same as pi_expanded_dim_list, just that for the opposite axis where no DIM_VALUE will be populated

output:   ROW_ID            VARCHAR2 - used to identify a particular node. will contain all parent ids separated by CHR(0)
        , COLUMN_ID         VARCHAR2 - used to identify a particular node. will contain all parent ids separated by CHR(0)
        , ROW_VERSION_HASH  VARCHAR2 - it's a unique hash value computed based on all record versions that produced each aggregation
        , ROW_COUNT         NUMBER   - it's the number of records that produced each aggregation
        , a numerical column for each distinct Value included in the pivot view with the exact name
          as the corresponding physical column in the model table.

example: must display a pivot view that has the following 2 Output Values included:
        Cost - F435
        Revenue - F6756
the cursor will contain 6 columns : ROW_ID, COLUMN_ID, F435, F6756


    ROW_ID          COLUMN_ID       ROW_VERSION_HASH    ROW_COUNT   F435        F6756
    ----------------------------------------------------------------------------------
    North-East      Q1 2016/Basic   2534534            5            1000        2000
    North-East      Q2 2016/Basic   534534523          2            1200        2000
    South-West      Q1 2016/Basic   345454             9            1000        2040
    South-West      Q2 2016/Basic   85785              78           1400        2000
    North-East      Q1 2016/Optim   49507673467        3            1000        2000
    North-East      Q2 2016/Optim   3470563            534          1240        2000
    South-West      Q1 2016/Optim   59786673356        65           6430        2000
    South-West      Q2 2016/Optim   75723424746        544          1000        2000

-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SQL_FOR_PIVOT_VALUES
(    pi_view_id             NUMBER
    ,pi_axis_type           NUMBER
    ,pi_max_opposite_level  NUMBER
    ,pi_opp_root_exp_items  TABLETYPE_CHARMAX
    ,pi_from_clause         CLOB
    ,pi_parent_id           VARCHAR2
    ,pi_expanded_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_opposite_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
) RETURN CLOB;


/* GET_SQL_FOR_PIVOT_REFRESH
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  : The procedure will be used to construct the query for refreshing the pivot view values
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_view_id             NUMBER  - NOT NULL
                                    - the view definition id as taken from OBJECT_DEFINITIONS.OD_CONTAINER_ID

    ,pi_row_exp_max_lvl     NUMBER  - NOT NULL
                                    - this will show how many levels have been expanded at maximum so far on the row axis

    ,pi_row_exp_root_items  TABLETYPE_CHARMAX - NULL
                                    - the list of items (IDs of rows) that have been previously expanded on the first level of the row axis
                                    - sent for performance reasons

    ,pi_row_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
                                    - will contain the entire list of dimensions on the ROW side ordered by DIM_ORDER
                                    - see description of GET_SQL_FOR_PIVOT_VALUES pi_expanded_dim_list

    ,pi_col_exp_max_lvl     NUMBER  - NOT NULL
                                    - this will show how many levels have been expanded at maximum so far on the row axis

    ,pi_col_exp_root_items  TABLETYPE_CHARMAX - NULL
                                    - the list of items (IDs of columns) that have been previously expanded on the first level of the column axis
                                    - sent for performance reasons

    ,pi_col_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
                                    - will contain the entire list of dimensions on the COLUMN side ordered by DIM_ORDER
                                    - see description of GET_SQL_FOR_PIVOT_VALUES pi_expanded_dim_list

    ,pi_from_clause         CLOB    - NULL
                                    - if filters have been defined in the pivot view, the model table is filtered with a query
                                    - this from clause will contain a SELECT with all columns in the table as they are named there

output:   ROW_ID            VARCHAR2 - used to identify a particular node. will contain all parent ids separated by CHR(0)
        , COLUMN_ID         VARCHAR2 - used to identify a particular node. will contain all parent ids separated by CHR(0)
        , ROW_VERSION_HASH  VARCHAR2 - it's a unique hash value computed based on all record versions that produced each aggregation
        , ROW_COUNT         NUMBER   - it's the number of records that produced each aggregation
        , a numerical column for each distinct Value included in the pivot view with the exact name
          as the corresponding physical column in the model table.

example:
  must display a pivot view that has the following 2 Output Values included:
    Cost - F435
    Revenue - F6756
  the cursor will contain 6 columns : ROW_ID, COLUMN_ID, ROW_VERSION_HASH, ROW_COUNT, F435, F6756

    ROW_ID          COLUMN_ID       ROW_VERSION_HASH    ROW_COUNT   F435        F6756
    ----------------------------------------------------------------------------------
    North-East      Q1 2016/Basic   2534534            5            1000        2000
    North-East      Q2 2016/Basic   534534523          2            1200        2000
    South-West      Q1 2016/Basic   345454             9            1000        2040
    South-West      Q2 2016/Basic   85785              78           1400        2000
    North-East      Q1 2016/Optim   49507673467        3            1000        2000
    North-East      Q2 2016/Optim   3470563            534          1240        2000
    South-West      Q1 2016/Optim   59786673356        65           6430        2000
    South-West      Q2 2016/Optim   75723424746        544          1000        2000

-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SQL_FOR_PIVOT_REFRESH
(    pi_view_id             NUMBER
    ,pi_row_exp_max_lvl     NUMBER
    ,pi_row_exp_root_items  TABLETYPE_CHARMAX
    ,pi_row_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_col_exp_max_lvl     NUMBER
    ,pi_col_exp_root_items  TABLETYPE_CHARMAX
    ,pi_col_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_from_clause         CLOB
) RETURN CLOB;



/* PIVOT_CAN_GENERATE_EXPORT
-- Author       : Luca, Iulian
-- Create date  : 2017.07.17
-- Reviewer     : Andries, Adriana
-- Review date  : 2017.07.17
-- Description  : Procedure that checks for pivot view changes using GENERATE_EXPORT_CHECK table to decide whether we generate a fresh export or not
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_view_id             IN   NUMBER  - NOT NULL
                                         - the view definition id as taken from OBJECT_DEFINITIONS.OD_CONTAINER_ID

    ,pi_tables_id           OUT  NUMBER  - NOT NULL
                                         - table_id fetched using pi_view_id

    ,po_row_count           OUT  NUMBER  - NOT NULL
                                         - row count from the pivot table

    ,po_row_versions_sum    OUT  NUMBER  - NOT NULL
                                         - sum aggregation for row versions from the pivot table

    ,po_max_row_identifier  OUT  NUMBER  - NOT NULL
                                         - max row identifier of the pivot table

    ,po_object_version      OUT  NUMBER  - NOT NULL
                                         - object version of the table taken from SALES_PLANNING_MODELS table

    ,po_definition_version  OUT  NUMBER  - NOT NULL
                                         - definition version taken from OBJECT_DEFINITIONS table for a given view id = OD_CONTAINER_ID

    ,po_can_generate_export OUT NUMBER   - 0 = will use the old export
                                           1 = will generate a new export

--Example:
  declare
    v_tables_id           NUMBER;
    v_row_count           NUMBER;
    v_row_versions_sum    NUMBER;
    v_max_row_identifier  NUMBER;
    v_object_version      NUMBER;
    v_definition_version  NUMBER;
    v_can_generate        NUMBER;
  begin
    PLANNING_MODELS.PIVOT_CAN_GENERATE_EXPORT
    (
      pi_view_id => 4559650,
      po_tables_id => v_tables_id,
      po_row_count => v_row_count,
      po_row_versions_sum => v_row_versions_sum,
      po_max_row_identifier => v_max_row_identifier,
      po_object_version => v_object_version,
      po_definition_version => v_definition_version,
      po_can_generate => v_can_generate
    );
  end;
*/
PROCEDURE PIVOT_CAN_GENERATE_EXPORT
  (
   pi_view_id             IN      NUMBER,
   po_tables_id           OUT     NUMBER,
   po_row_count           OUT     NUMBER,
   po_row_versions_sum    OUT     NUMBER,
   po_max_row_identifier  OUT     NUMBER,
   po_object_version      OUT     NUMBER,
   po_definition_version  OUT     NUMBER,
   po_can_generate        OUT     NUMBER
  );



/* UPDATE_CAN_GENERATE_EXPORT
-- Author       : Luca, Iulian
-- Create date  : 2017.07.17
-- Reviewer     : Andries, Adriana
-- Review date  : 2017.07.17
-- Description  : Procedure that updates the GENERATE_EXPORT_CHECK after it checks if we generate a new export
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_view_id             IN   NUMBER  - NOT NULL
                                         - the view definition id as taken from OBJECT_DEFINITIONS.OD_CONTAINER_ID

    ,pi_tables_id           IN  NUMBER   - NOT NULL
                                         - table_id passed from PIVOT_CAN_GENERATE_EXPORT procedure

    ,pi_row_count           IN  NUMBER   - NOT NULL
                                         - row count from the pivot table

    ,pi_row_versions_sum    IN  NUMBER   - NOT NULL
                                         - sum aggregation for row versions from the pivot table

    ,pi_object_version      IN  NUMBER   - NOT NULL
                                         - object version of the table taken from SALES_PLANNING_MODELS table

    ,pi_definition_version  IN  NUMBER   - NOT NULL
                                         - definition version taken from OBJECT_DEFINITIONS table for a given view id = OD_CONTAINER_ID


--Example:
  begin
    PLANNING_MODELS.UPDATE_CAN_GENERATE_EXPORT
    (
      pi_view_id => 4559650,
      pi_tables_id => 4559630,
      pi_row_count => 192,
      pi_row_versions_sum => 1941,
      pi_max_row_identifier => 577,
      pi_object_version => 6,
      pi_definition_version => 15
    );
  end;
*/
PROCEDURE UPDATE_CAN_GENERATE_EXPORT
  (
   pi_view_id             IN      NUMBER,
   pi_tables_id           IN      NUMBER,
   pi_row_count           IN      NUMBER,
   pi_row_versions_sum    IN      NUMBER,
   pi_max_row_identifier  IN      NUMBER,
   pi_object_version      IN      NUMBER,
   pi_definition_version  IN      NUMBER
  );



/* GET_SQL_FOR_PIVOT_EXPORT
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  : This function returns a collection of queries that need to be executed for the pivot view export
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_view_id             NUMBER  - NOT NULL
                                    - the view definition id as taken from OBJECT_DEFINITIONS.OD_CONTAINER_ID

    ,pi_row_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
                                    - will contain the entire list of dimensions on the ROW side ordered by DIM_ORDER
                                    - see description of GET_SQL_FOR_PIVOT_VALUES pi_expanded_dim_list

    ,pi_col_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
                                    - will contain the entire list of dimensions on the COLUMN side ordered by DIM_ORDER
                                    - see description of GET_SQL_FOR_PIVOT_VALUES pi_expanded_dim_list

    ,pi_from_clause         CLOB    - NULL
                                    - if filters have been defined in the pivot view, the model table is filtered with a query
                                    - this from clause will contain a SELECT with all columns in the table as they are named there

    ,pio_column_aliases     IN OUT TABLETYPE_NAME_JOIN_MAP - NOT NULL
                                    - a collection of mapping between columns and java given aliases.
                                    - Java sends all columns and their display fields from the model tables.
                                    - we filter it to only contain the necessary exported fields.
                                name1 - FIELD ID to be exported: can be directly MT field, or entity display field
                                name2 - ENTITY ID to be exported, when this is populated then name1 is also populated
                                name3 - either "TUPR_TUP_ID"/"TUPR_YEAR" when the field to be exported is a period field
                                name4 - always NULL
                                name5 - alias given by Java
                                                                --name1 ,name2 ,name3        ,name4   ,name5
                ex: TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP(50    ,null  ,null         ,null    ,C_0_3ehss_8cio)
                                           ,OBJTYPE_NAME_JOIN_MAP(60    ,null  ,tupr_tup_id  ,null    ,P_0_0_cu)
                                           ,OBJTYPE_NAME_JOIN_MAP(60    ,null  ,tupr_year    ,null    ,Y_0_0_cu)
                                           ,OBJTYPE_NAME_JOIN_MAP(89    ,300   ,null         ,null    ,adf)
                                           ,OBJTYPE_NAME_JOIN_MAP(567   ,300   ,tupr_tup_id  ,null    ,adfadsf)
                                           ,OBJTYPE_NAME_JOIN_MAP(567   ,300   ,tupr_year    ,null    ,asdf)
                                           )

    ,po_queries             OUT TABLETYPE_NAME_QUERY
                                    - a collection representing the sheet names to be exported plus their equivalent queries
                ex: TABLETYPE_NAME_QUERY(OBJTYPE_NAME_QUERY('sheet1'    , 'SELECT ...')
                                        ,OBJTYPE_NAME_QUERY('bla bla'   , 'SELECT ...')
                                        ,OBJTYPE_NAME_QUERY('asd'       , 'SELECT ...')

*/
PROCEDURE GET_SQL_FOR_PIVOT_EXPORT
(    pi_view_id             IN NUMBER
    ,pi_row_dim_list        IN TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_col_dim_list        IN TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_from_clause         IN CLOB
    ,pio_column_aliases     IN OUT TABLETYPE_NAME_JOIN_MAP
    ,po_queries             OUT TABLETYPE_NAME_QUERY
);

/* GET_SQL_FOR_MODEL_EXPORT
-- Author       : Tudose, Alexandra
-- Create date  : 2017.07.28
-- Reviewer     : Andries, Adriana
-- Review date  : 2017.07.28
-- Description  : This function returns a query that needs to be executed for the model view export
-----------------------------------------------------------------------------------------------
-- Assumptions:

     PI_SPM_MODEL_ID        NUMBER  - NOT NULL
                                    - the model definition id as taken from SALES_PLANNING_MODELS.SPM_ID

    ,PI_EXP_MODEL_DIM_LIST  TABLETYPE_EXP_MODEL_DIMS
                                    - NOT NULL
                                    - will contain the entire list of dimensions ordered by DIM_ORDER
                                    - OBJTYPE_EXP_MODEL_DIMS:
                                           DIM_ID             - dimension id
                                           DIM_TYPE           - 'FIELD'/'ENTITY'
                                           DIM_NAME           - the column physical name from the model table
                                           IS_FIXED           - if no fixed dimension is specified, the first additional dimension will be considered fixed
                                           IS_ADDITIONAL      - marks additional dimensions
                                           ADDITIONAL_ORDER   - represents the grouping order
                                                              - 0 for fixed dimensions
                                                              - >0 for additional dimensions
                                           HAS_SUBTOTAL       - currently not used

    ,PI_EXP_MODEL_FLD_LIST  TABLETYPE_EXP_MODEL_FLDS
                                    - NOT NULL
                                    - the list of fields to be aggregated

    ,PI_FROM_CLAUSE         CLOB    - NULL
                                    - if filters have been defined, the model table is filtered with a query
                                    - this from clause will contain a SELECT with all columns in the table as they are named there

    ,PO_QUERY               OUT CLOB
*/
PROCEDURE GET_SQL_FOR_MODEL_EXPORT
(    PI_SPM_MODEL_ID        IN NUMBER
    ,PI_EXP_MODEL_DIM_LIST  IN TABLETYPE_EXP_MODEL_DIMS
    ,PI_EXP_MODEL_FLD_LIST  IN TABLETYPE_EXP_MODEL_FLDS
    ,PI_FROM_CLAUSE         IN CLOB
    ,PO_QUERY               OUT CLOB
);

/* GET_MODELS_BY_CRITERIA
-- Author       : Tudose, Alexandra
-- Create date  : 2017.08.01
-- Reviewer     :
-- Review date  :
-- Description  : This function returns a list of model table ids, filtered by specified criteria
-----------------------------------------------------------------------------------------------
-- Assumptions:

     PI_TIME_UNIT_ID        NUMBER

    ,PI_SCENARIO_NAME_LIST  TABLETYPE_CHARMAX
                                    - a list of scenario names
    ,PI_EXACT_SCENARIO_NAME NUMBER(1)
                                    - 1: search planning models based on exact criteria; 0: otherwise

    ,PI_REL_TBL_ID_LIST     TABLETYPE_NUMBER
                                    - a list of relationship table ids
    ,PI_EXACT_REL_TBL       NUMBER(1)
                                    - 1: search planning models based on exact criteria; 0: otherwise

    ,PI_INPUT_FLD_ID_LIST   TABLETYPE_NUMBER
    ,PI_EXACT_INPUT_FLD     NUMBER(1)
                                    - 1: search planning models based on exact criteria; 0: otherwise

    ,PI_OUTPUT_FLD_ID_LIST  TABLETYPE_NUMBER
    ,PI_EXACT_OUTPUT_FLD    NUMBER(1)
                                    - 1: search planning models based on exact criteria; 0: otherwise

    ,PO_MODEL_ID_LIST       OUT TABLETYPE_NUMBER
*/
PROCEDURE GET_MODELS_BY_CRITERIA
(    PI_TIME_UNIT_ID        IN NUMBER
    ,PI_SCENARIO_NAME_LIST  IN TABLETYPE_CHARMAX
    ,PI_EXACT_SCENARIO_NAME IN NUMBER
    ,PI_REL_TBL_ID_LIST     IN TABLETYPE_NUMBER
    ,PI_EXACT_REL_TBL       IN NUMBER
    ,PI_INPUT_FLD_ID_LIST   IN TABLETYPE_NUMBER
    ,PI_EXACT_INPUT_FLD     IN NUMBER
    ,PI_OUTPUT_FLD_ID_LIST  IN TABLETYPE_NUMBER
    ,PI_EXACT_OUTPUT_FLD    IN NUMBER
    ,PO_MODEL_ID_LIST       OUT TABLETYPE_NUMBER
);

END PLANNING_MODELS;
/
