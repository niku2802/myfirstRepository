CREATE PACKAGE SOCIAL_OBJECTIVES
IS
-- ###################################  ADD_OBJECTIVE  ###################################
--  Description: Insert data for an objective into objective, metric and roles tables.
--               For an initiative data is inserted only in objective table
--  ---------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table        in varchar2   - the name of the objective table
--    pi_period_column          in varchar2   - the name of the period column
--    pi_period_id              in number     - the time frequency id
--    pi_objective              in varchar2   - the name of the objective
--    pi_objective_description  in varchar2   - the description of the objective (max 1300 char)
--    pi_parent_objective       in varchar2   - the name of the parent objective
--    pi_parent_objective_id    in number     - the id of the parent objective
--    pi_objective_type         in varchar2   - the objective type (Objective, Initiative, Organizational)
--    pi_strategy_lever         in varchar2   - the strategy lever
--    pi_initiative_category    in varchar2   - the initiative category
--    pi_organization_column    in varchar2   - the organization entity
--    pi_organization_id        in number     - the id of the organization entity
--    pi_objective_privacy      in varchar2   - the privacy level of the objective(Public, Participants Only, Organizations)
--    pi_roles_table            in varchar2   - the table that stores owners and assignees
--    pi_entity_column          in varchar2   - the name of the entity column
--    pi_owner_id               in number     - the id of the owner of the objective
--    pi_assignees              in tabletype_number - the collection of assignees id
--    pi_metric_table           in varchar2   - the name of the metric table
--    pi_metric_name            in varchar2   - the name of the objective metric
--    pi_metric_description     in varchar2   - the description of the metric (max 1300 char)
--    pi_target_value           in number     - the target value for the objective metric
--    pi_child_objectives       in tabletype_number - the list of objectives to be added as child
--    po_objective_id           out number    - the id of the inserted objective
--  -----------------------------------------------------------------------------------------
 PROCEDURE ADD_OBJECTIVE
  (
    pi_objective_table        in varchar2,
    pi_period_column          in varchar2,
    pi_period_id              in number,
    pi_objective              in varchar2,
    pi_objective_description  in varchar2 := NULL,
    pi_parent_objective       in varchar2 := NULL,
    pi_parent_objective_id    in number   := NULL,
    pi_objective_type         in varchar2,
    pi_strategy_lever         in varchar2 := NULL,
    pi_initiative_category    in varchar2 := NULL,
    pi_organization_column    in varchar2 := NULL,
    pi_organization_id        in number   := NULL,
    pi_objective_privacy      in varchar2,
    pi_roles_table            in varchar2 := NULL,
    pi_entity_column          in varchar2 := NULL,
    pi_owner_id               in number   := NULL,
    pi_assignees              in tabletype_number := NULL,
    pi_metric_table           in varchar2 := NULL,
    pi_metric_name            in varchar2 := NULL,
    pi_metric_description     in varchar2 := NULL,
    pi_target_value           in number   := NULL,
    pi_child_objectives       in tabletype_number := NULL,
    po_objective_id           out number
  );



-- ##################################  UPDATE_OBJECTIVE  ######################################
--  Description: Update an objective. Objective and organizational types updates objective,
--               metric and roles tables. The period of objective and organizational types
--               are set to initiative period. Child objectives that are not in the input child
--               list are deleted. The assignees and owners of deleted child objectives are
--               inserted into activity feed entities table.
--  --------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table        in varchar2   - the name of the objective table
--    pi_objective_id           in number     - the id of the objective to be updated
--    pi_period_column          in varchar2   - the name of the period column
--    pi_period_id              in number     - the time frequency id
--    pi_objective              in varchar2   - the name of the objective
--    pi_objective_description  in varchar2   - the description of the objective (max 1300 char)
--    pi_parent_objective       in varchar2   - the name of the parent objective
--    pi_parent_objective_id    in number     - the id of the parent objective
--    pi_objective_type         in varchar2   - the objective type (Objective, Initiative, Organizational)
--    pi_strategy_lever         in varchar2   - the strategy lever
--    pi_initiative_category    in varchar2   - the initiative category
--    pi_organization_column    in varchar2   - the organization entity
--    pi_organization_id        in number     - the id of the organization entity
--    pi_row_version            in number     - the version of the row to be updated
--    pi_initiative_id          in number     - the id of the initiative
--    pi_roles_table            in varchar2   - the table that stores owners and assignees
--    pi_entity_column          in varchar2   - the name of the entity column
--    pi_owner_id               in number     - the id of the owner of the objective
--    pi_assignees              in tabletype_number - the collection of assignees id
--    pi_metric_table           in varchar2   - the name of the metric table
--    pi_metric_name            in varchar2   - the name of the objective metric
--    pi_metric_description     in varchar2   - the description of the metric (max 1300 char)
--    pi_target_value           in number     - the target value for the objective metric
--    pi_child_objectives       in tabletype_objective_list - the list of objectives to be added as child
--                                 objtype_objective_list
--                                  (
--                                     objective_id    number(10),
--                                     objective       varchar2(250 char),
--                                     target_value    number,
--                                     attainment      number,
--                                     weight          number
--                                  )
--    po_objective_id           out number    - the id of the inserted objective

--  Return: 0 - function executed successfully
--          1 - function failed due to row version
--  ----------------------------------------------------------------------------------------
--  Example:   social_objectives.update_objective (pi_objective_table       => 'T3128342',
--                                                 pi_objective_id          => 21,
--                                                 pi_period_column         => 'F462',
--                                                 pi_period_id             =>  255,
--                                                 pi_objective             => 'Increase sales',
--                                                 pi_objective_description => 'Try to increase sales',
--                                                 pi_parent_objective      => 'Increase team sales',
--                                                 pi_parent_objective_id   => 23,
--                                                 pi_objective_type        => 'Organizational',
--                                                 pi_strategy_lever        => 'Improved strategy',
--                                                 pi_initiative_category   => 'Second category',
--                                                 pi_organization_column   => 'E3492833',
--                                                 pi_organization_id       => 11,
--                                                 pi_row_version           => 1,
--                                                 pi_initiative_id         => 16,
--                                                 pi_roles_table           => 'T3128362',
--                                                 pi_entity_column         => 'E3128174',
--                                                 pi_owner_id              => 99,
--                                                 pi_assignees             => tabletype_number(31, 60),
--                                                 pi_metric_table          => 'T3128352',
--                                                 pi_metric_name           => 'Quantity',
--                                                 pi_metric_description    => 'Sales quantity',
--                                                 pi_target_value          => 90,
--                                                 pi_child_objectives      => tabletype_objective_list(objtype_objective_list(14, null, null, null, 0.70),
--                                                                                                      objtype_objective_list(15, null, null, null, 0.30)),
--                                                 pi_context_id            => 3493086
--                                               );
--  --------------------------------------------------------------------------------------------
 FUNCTION UPDATE_OBJECTIVE
  (
    pi_objective_table        in varchar2,
    pi_objective_id           in number,
    pi_period_column          in varchar2,
    pi_period_id              in number,
    pi_objective              in varchar2,
    pi_objective_description  in varchar2 := NULL,
    pi_parent_objective       in varchar2 := NULL,
    pi_parent_objective_id    in number   := NULL,
    pi_objective_type         in varchar2,
    pi_strategy_lever         in varchar2 := NULL,
    pi_initiative_category    in varchar2 := NULL,
    pi_organization_column    in varchar2 := NULL,
    pi_organization_id        in number   := NULL,
    pi_row_version            in number,
    pi_initiative_id          in number,
    pi_roles_table            in varchar2 := NULL,
    pi_entity_column          in varchar2 := NULL,
    pi_owner_id               in number   := NULL,
    pi_assignees              in tabletype_number := NULL,
    pi_metric_table           in varchar2 := NULL,
    pi_metric_name            in varchar2 := NULL,
    pi_metric_description     in varchar2 := NULL,
    pi_target_value           in number   := NULL,
    pi_child_objectives       in tabletype_objective_list := NULL
  )
  RETURN NUMBER;



-- ###############################  DELETE_OBJECTIVE  ###############################
--  Description: Delete an objective and all his children
--  ----------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table     in varchar2   - the name of the objective table
--    pi_metric_name         in varchar2   - the name of the objective metric
--    pi_roles_table         in varchar2   - the table that stores owners and assignees
--    pi_objective_id        in number     - the id of the objective to be deleted
--    pi_entity_column       in varchar2   - the name of the entity column
--    pi_context_id          in number     - the id of the social objective definition
--  ----------------------------------------------------------------------------------------

  PROCEDURE DELETE_OBJECTIVE
  (
    pi_objective_table    in varchar2,
    pi_metric_table       in varchar2,
    pi_roles_table        in varchar2,
    pi_objective_id       in number,
    pi_entity_column      in varchar2,
    pi_context_id         in number
  );



-- ##########################################  GET_OBJECTIVE  ###############################################
--  Description: Get an objective and his children. Objective data is retrieved from objective,
--               metric, roles and checkin tables through a cursor.
--  ---------------------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table     in varchar2      - the name of the objective table
--    pi_objective_id        in number        - the id of the objective to be deleted
--    pi_period_columns      in col_list_30   - the list of periods columns contained by objectives table
--    pi_metric_table        in varchar2      - the metric table name
--    pi_roles_table         in varchar2      - the roles table name
--    pi_entity_column       in varchar2      - the entity column name
--    pi_checkin_table       in varchar2      - the name of the checkin history table
--    pi_organization_column in varchar2      - the name of the organization from objectives table
--    po_objectives          out sys_refcursor - the cursor that contains objective and its children
--                                               PERIOD_RANGE_ID, OBJECTIVE, OBJECTIVE_DESCRIPTION, OBJECTIVE_TYPE,
--                                               STRATEGY_LEVER, INITIATIVE_CATEGORY, E3492833(organization id),
--                                               ROW_IDENTIFIER, ROW_VERSION, OBJECTIVE_PRIVACY, CREATED_DATE_TIME
--                                               PARENT_PERIOD_ID, PARENT_OBJECTIVE_ID, PARENT_OBJECTIVE, PARENT_OBJECTIVE_PRIVACY, PARENT_PROGRESS,
--                                               OBJECTIVE_METRIC_NAME, METRIC_DESCRIPTION, TARGET_VALUE, ATTAINMENT, WEIGHT,
--                                                (metric columns have value only for OBJECTIVE and ORGANIZATIONAL type)
--                                               LAST_CHECKIN_VALUE, LAST_CHECKIN_DATE_TIME,
--                                               INITIATIVE_PERIOD_ID, INITIATIVE_ID, INITIATIVE, INITIATIVE_ORGANIZATION, INITIATIVE_PRIVACY, INITIATIVE_PROGRESS
--                                               ORGANIZATIONAL_PERIOD_ID, ORGANIZATIONAL_ID, ORGANIZATIONAL_OBJECTIVE, ORGANIZATIONAL_PROGRESS, ORGANIZATIONAL_PRIVACY,
--                                                (organizational columns have value only for OBJECTIVE type), ORGANIZATIONAL_ORGANIZATION,
--                                               ASSIGNEES(NULL for initiative), OWNER_ID, CHILD_OBJECTIVES, PARENT_ASSIGNEES_COUNT
--                                                 - ASSIGNEES = tabletype_objective_assignees - the collection of objective assignees,
--                                                     objtype_objective_assignee
--                                                     (
--                                                       entity_id  number(10),
--                                                       weight     number
--                                                      )
--                                                 - CHILD_OBJECTIVES = tabletype_objective_list - the collection of child objectives
--                                                    objtype_objective_list
--                                                     (
--                                                        period_range_id   number(10),
--                                                        objective_id      number(10),
--                                                        objective         varchar2(250 char),
--                                                        objective_privacy varchar(30 char),
--                                                        target_value      number,
--                                                        attainment        number,
--                                                        weight            number,
--                                                        assignees_number  number
--                                                     )
--  ---------------------------------------------------------------------------------------------------------

  PROCEDURE GET_OBJECTIVE
  (
    pi_objective_table        in varchar2,
    pi_objective_id           in number,
    pi_period_columns         col_list_30,
    pi_metric_table           in varchar2,
    pi_roles_table            in varchar2,
    pi_entity_column          in varchar2,
    pi_checkin_table          in varchar2 := NULL,
    pi_organization_column    in varchar2,
    po_objectives             out sys_refcursor
  );



-- #############################  CHECKIN_OBJECTIVE  #############################
--  Description: Update the attainment of an objective and log the information
--               in checkin history table
--  ---------------------------------------------------------------------------------------
--  Parameters:
--    pi_metric_table        in varchar2      - the metric table name
--    pi_objective_id        in number        - the id of the objective to be updated
--    pi_attainment          in number        - the objective attainment to be updated
--    pi_checkin_table       in varchar2      - the checkin history table
--    pi_entity_column       in varchar2      - the entity column name
--    pi_entity_id           in number        - the id of the entity who made the checkin
--    pi_comment             in varchar2      - the checkin comment

--  Return: 0 - function executed successfully
--          1 - function failed if attainment after applying checkin gets negative
--  ----------------------------------------------------------------------------------------

  FUNCTION CHECKIN_OBJECTIVE
  (
    pi_metric_table   in varchar2,
    pi_objective_id   in number,
    pi_attainment     in number,
    pi_checkin_table  in varchar2,
    pi_entity_column  in varchar2,
    pi_entity_id      in number,
    pi_comment        in varchar2 := NULL
  )
  RETURN NUMBER;



-- ##################################  REALIGN_CHILDREN  ######################################
--  Description: Add children to an objective.
--  --------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table        in varchar2   - the name of the objective table
--    pi_parent_objective_id    in number     - the id of the parent objective
--    pi_parent_objective       in varchar2   - the name of the parent objective
--    pi_metric_table           in varchar2   - the name of the metric table
--    pi_child_objectives       in coltype_id - the list of objectives ids to be added as child
--    pi_row_version            in number     - the version of the row to be updated

--  Return: 0 - function executed successfully
--          1 - function failed due to row version
--  ----------------------------------------------------------------------------------------

  FUNCTION REALIGN_CHILDREN
  (
    pi_objective_table        in varchar2,
    pi_objective_id           in number,
    pi_objective              in varchar2,
    pi_metric_table           in varchar2,
    pi_child_objectives       in coltype_id,
    pi_row_version            in number
  )
  RETURN NUMBER;




-- ##########################################  DELETE_CHILDREN  #############################################
--  Description: Delete the objectives from the input list and all their children
--  ---------------------------------------------------------------------------------------------------------
--  Parameters:
--    pi_objective_table     in varchar2   - the name of the objective table
--    pi_metric_name         in varchar2   - the name of the objective metric
--    pi_roles_table         in varchar2   - the table that stores owners and assignees
--    pi_child_objectives    in coltype_id - the ids of the objectives to be deleted
--    pi_entity_column       in varchar2   - the name of the entity column
--    pi_context_id          in number     - the id of the social objective definition
--  ---------------------------------------------------------------------------------------------------------

  PROCEDURE DELETE_CHILDREN
  (
    pi_objective_table    in varchar2,
    pi_metric_table       in varchar2,
    pi_roles_table        in varchar2,
    pi_objective_ids      in coltype_id,
    pi_entity_column      in varchar2,
    pi_context_id         in number
  );

end SOCIAL_OBJECTIVES;
/
