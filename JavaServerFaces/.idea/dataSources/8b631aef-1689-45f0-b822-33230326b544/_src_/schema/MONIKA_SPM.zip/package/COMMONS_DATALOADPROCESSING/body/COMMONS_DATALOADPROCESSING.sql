CREATE PACKAGE BODY COMMONS_DATALOADPROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : dataloadprocessing-commons
  -- Requester      : Kalloli, Basavaraj
  -- Author         : Rohit, Maxim
  -- Reviewer       : Sharma, Pooja
  -- Modified by  : Pimpalkar, Shriniket
  -- Review date    : 16-Feb-2012
  -- Description    : Pacakge holding Data laod processing related pieces
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  /*
    -- Description:
       Private Procedure to log the variables. It will internally call the procedure L4O_LOGGING.LOG_VARIABLE.
      -----**************************************************************************************------------------------
      -- Return : NA
      -----**************************************************************************************------------------------
       -- Input Parameters:
          pi_log_level        L4O_LOGS.L4OL_LEVEL%TYPE                    : log level to use
          pi_variable        ANYDATA                                      : variable to be logged
          pi_message_format  VARCHAR2 DEFAULT NULL                        : a template for message format, "<value>" will be replaced with the actual computed value of the variable
          pi_identifier      L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL   : if multiple messages of the same type must be logged from concurrent sessions, this identifier can help developers
                                                                            identify the parent session/transaction of a particular message.

       --Out parameter :
          NA
       Example :
        DECLARE  v_e1 VARCHAR2(200);
        BEGIN  v_e1 := 'asd';
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_e1), 'v_e1 := <value>;', 'Crediting.evaluate_crediting');
        END;
  */
  --Logging changes start
  PROCEDURE L4O_LOG_VARIABLES(pi_log_level      L4O_LOGS.L4OL_LEVEL%TYPE,
                              pi_variable       ANYDATA,
                              pi_message_format VARCHAR2 DEFAULT NULL,
                              pi_identifier     L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL) IS

  BEGIN
    L4O_LOGGING.LOG_VARIABLE(pi_log_level      => pi_log_level,
                             pi_variable       => pi_variable,
                             pi_message_format => pi_message_format,
                             pi_identifier     => pi_identifier);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END L4O_LOG_VARIABLES;
  --Logging changes end.
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************
  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE          IN VARCHAR2,
                           pi_QI_TABLE            IN VARCHAR2,
                           pi_MODE                IN VARCHAR2, --1 insert, 2 update
                           pi_KEY_COLUMNS         IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_DEST_TABLE          IN VARCHAR2,
                           pi_IS_AUTO_VALUED      IN NUMBER,
                           pi_av_generated_by_sw  IN NUMBER,
                           pi_av_col_name         VARCHAR2,
                           pi_AGGREGATE           IN NUMBER,
                           pi_DATA_COLUMNS        IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER   IN VARCHAR2,
                           pi_WHERE_CONDITIONS    IN VARCHAR2,
                           PIO_DUPLICATE_TABLE    IN VARCHAR2,
                           pi_id_column_name      VARCHAR2 default null,
                           pi_version_column_name VARCHAR2 default null,

                           PI_ADD_LOG_INFO    IN COLTYPE_KEY_VALUE default null,
                           PI_SEQ_USED_FOR_ID in varchar2 default null,
                           PI_INPUT_COUNT     in number default null) IS
    V_SQL                    CLOB;
    V_SELECT_ADD_TO_EXISTING CLOB;
    V_OUTER_KEY              CLOB;
    V_SUBQUERY_SQL           CLOB;
    V_SELECT_CLAUSE          CLOB;
    V_GROUP_BY_CLAUSE        CLOB;
    V_TEMP_INDEX_DDL         CLOB;
    V_AGGREGATION_CLAUSE     CLOB;
    V_INTRANS_VALUE          NUMBER;
    L_OFFSET                 NUMBER DEFAULT 1;
    V_JOIN_CLAUSE            CLOB;
    V_DUMP_TABLE             VARCHAR2(1000);
    V_SIZE_DATA              NUMBER;
    V_WHERE_REQUIRED         BOOLEAN := TRUE;
    V_SQL_DROP_DUMP_TABLE    CLOB;
    V_DATA_COLUMNS           CLOB;
    V_DATA_COLUMNS_agg       CLOB;
    v_stamp                  VARCHAR2(250);
    V_STOP_FLAG              number := 0;
    v_seq_value              number;
  BEGIN

    SELECT MAX(PR_VALUE)
      INTO V_INTRANS_VALUE
      FROM PROPERTIES
     WHERE PR_NAME = 'INITRANS';
    if (pi_AGGREGATE in (2, 3)) then
      /*   V_DATA_COLUMNS := pi_id_column_name || ',' || pi_version_column_name;*/

      if PI_ADD_LOG_INFO is null /* or PI_AGGREGATE=3*/
       then
        V_DATA_COLUMNS_agg := PI_ID_COLUMN_NAME || ',' ||
                              PI_VERSION_COLUMN_NAME;

      end if;

      execute immediate 'select ' || PI_SEQ_USED_FOR_ID ||
                        '.nextval from dual'
        into v_seq_value;
      if /*PI_ADD_LOG_INFO is null or*/
       PI_AGGREGATE IN (3) then
        V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || ' , max(' ||
                                nvl(PI_INPUT_COUNT, 1) || '+ rownum + ' ||
                                v_seq_value || ') AS ' || PI_ID_COLUMN_NAME;
      else
        V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_ID_COLUMN_NAME ||
                                ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                PI_AGGREGATION_ORDER || ' ) AS ' ||
                                PI_ID_COLUMN_NAME;
      end if;
      /*   V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
      ,   max(' || PI_ID_COLUMN_NAME ||
                           ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                           PI_AGGREGATION_ORDER || ' ) AS ' ||
                           PI_ID_COLUMN_NAME;*/
      V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_VERSION_COLUMN_NAME ||
                              ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                              PI_AGGREGATION_ORDER || ' ) AS ' ||
                              PI_VERSION_COLUMN_NAME;
      /*ELSE
      V_DATA_COLUMNS_agg       := PI_ID_COLUMN_NAME || ',' ||
                                 PI_VERSION_COLUMN_NAME; */

    end if;
    --insert_logs(V_DATA_COLUMNS);
    ---if autonumber generated by software then that column will not be present in dump table
    IF (PI_AV_GENERATED_BY_SW = 1) THEN
      V_DUMP_TABLE := ' ( SELECT NULL AS ' || PI_AV_COL_NAME || ' , ' ||
                      PI_DUMP_TABLE || '.*  FROM ' || PI_DUMP_TABLE ||
                      ' ) '||PI_DUMP_TABLE||' ';-- deshmukha added ||PI_DUMP_TABLE||' ' for OF-56875
    ELSE
      V_DUMP_TABLE := PI_DUMP_TABLE;
    END IF;

    --debugging
    -- EXECUTE IMMEDIATE 'CREATE TABLE BKP_BFR_'||V_DUMP_TABLE||' AS SELECT * FROM '||V_DUMP_TABLE;
    -- EXECUTE IMMEDIATE 'CREATE TABLE BKP_'||PI_DEST_TABLE||' AS SELECT * FROM '||PI_DEST_TABLE;
    -- EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING PI_AGGREGATE;
    -- COMMIT;
    --id data coulmns are present
    IF (PI_DATA_COLUMNS IS NOT NULL) THEN
      FOR I IN 1 .. PI_DATA_COLUMNS.COUNT LOOP

        --if column is mapped
        IF (PI_DATA_COLUMNS(I).COL_IS_MAPPED = 1) THEN
          V_DATA_COLUMNS     := CASE
                                  WHEN V_DATA_COLUMNS IS NOT NULL THEN
                                   V_DATA_COLUMNS || ' , ' || PI_DATA_COLUMNS(I).COL_NAME
                                  ELSE
                                   PI_DATA_COLUMNS(I).COL_NAME
                                END;
          V_DATA_COLUMNS_agg := CASE
                                  WHEN V_DATA_COLUMNS_agg IS NOT NULL THEN
                                   V_DATA_COLUMNS_agg || ' , ' || PI_DATA_COLUMNS(I)
                                  .COL_NAME
                                  ELSE
                                   PI_DATA_COLUMNS(I).COL_NAME
                                END;
          --if aggregation type last
          --  dbms_output.put_line(pi_DATA_COLUMNS(I).name1);
          ---data columns in case of aggregation  and outer select
          IF (PI_DATA_COLUMNS(I).AGG_TYPE = 0) THEN

           /* V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
                                  ,MAX(' || PI_DATA_COLUMNS(I)
                                   .COL_NAME ||
                                    ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                   ---pick the last value for non number columns
                                    PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                   .COL_NAME;*/


           if PI_DATA_COLUMNS(I).col_data_type = 'XMLTYPE' THEN
              V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(t.' || PI_DATA_COLUMNS(I)
                                     .COL_NAME ||
                                      '.GETSTRINGVAL()) KEEP(DENSE_RANK LAST ORDER BY ' ||
                                      PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME;

              /*commons_utils.INSERT_LOGS('mean V_AGGREGATION_CLAUSE ' ||
              V_AGGREGATION_CLAUSE);*/

            ELSE

              V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
                              ,   max(' || PI_DATA_COLUMNS(I)
                                     .COL_NAME ||
                                      ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                      PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME;
              /* commons_utils.INSERT_LOGS('mean 1 V_AGGREGATION_CLAUSE ' ||
              V_AGGREGATION_CLAUSE);*/

            END IF;



            --pick columns for outer select
            V_SELECT_ADD_TO_EXISTING := V_SELECT_ADD_TO_EXISTING || ' , ' ||
                                        '  IP.' || PI_DATA_COLUMNS(I)
                                       .COL_NAME || ' AS ' || PI_DATA_COLUMNS(I)
                                       .COL_NAME;
          ELSE
            --for other aggregation type
            V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
                                   ,ROUND (' || CASE
                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 1 THEN
                                       'SUM'
                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 2 THEN
                                       'MIN'
                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 3 THEN
                                       'MAX'
                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 4 THEN
                                       'AVG'
                                    END || ' ( ' || PI_DATA_COLUMNS(I).COL_NAME ||
                                    '   ),' || PI_DATA_COLUMNS(I).DECIMAL_LENGTH ||
                                    ' ) AS ' || PI_DATA_COLUMNS(I).COL_NAME;

            --pick columns for outer select
            V_SELECT_ADD_TO_EXISTING := V_SELECT_ADD_TO_EXISTING || ' , ' || CASE
                                          WHEN PI_DATA_COLUMNS(I)
                                           .COL_DATA_TYPE = 'NUMBER' THEN
                                           ' cast ( '
                                          ELSE
                                           ' '
                                        END || CASE
                                          WHEN PI_DATA_COLUMNS(I).ADD_TO_EXISTING = 1 THEN
                                           ' decode(coalesce( '
                                          ELSE
                                           ' '
                                        END || '  IP.' || PI_DATA_COLUMNS(I).COL_NAME || CASE
                                          WHEN PI_DATA_COLUMNS(I).ADD_TO_EXISTING = 1 THEN
                                           ', OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                           '),null, null, nvl(IP.' || PI_DATA_COLUMNS(I)
                                          .COL_NAME || ',0) + nvl(OP.' || PI_DATA_COLUMNS(I)
                                          .COL_NAME || ',0))'
                                          ELSE
                                           ' '
                                        END || CASE
                                          WHEN PI_DATA_COLUMNS(I)
                                           .COL_DATA_TYPE = 'NUMBER' THEN
                                           ' AS NUMBER(23,10) )'
                                          ELSE
                                           ' '
                                        END || '  AS ' || PI_DATA_COLUMNS(I).COL_NAME;
          END IF;
        ELSE

          /*   commons_utils.INSERT_LOGS('1');*/
          V_SELECT_ADD_TO_EXISTING := V_SELECT_ADD_TO_EXISTING || ' , ' ||

                                      CASE
                                        WHEN PI_DATA_COLUMNS(I)
                                         .COL_DATA_TYPE = 'NUMBER(1)' THEN
                                         CASE
                                           WHEN PI_AV_GENERATED_BY_SW = 0 THEN
                                            ' cast (Decode(OP.ROW_IDENTIFIER,null,
                                         cast ( 0 ' || ' ' ||
                                            ' as ' || PI_DATA_COLUMNS(I).COL_DATA_TYPE ||
                                            ' ) , OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                            ' )as ' || PI_DATA_COLUMNS(I).COL_DATA_TYPE ||
                                            ') as ' || PI_DATA_COLUMNS(I).COL_NAME


                                          ELSE
                                            'cast ( 0 ' || ' ' || '
                                         as ' || PI_DATA_COLUMNS(I)
                                           .COL_DATA_TYPE || ') as ' || PI_DATA_COLUMNS(I)
                                           .COL_NAME
                                         END

                                        WHEN PI_DATA_COLUMNS(I)
                                         .COL_DATA_TYPE = 'XMLTYPE' THEN
                                        ' NVL( OP.'||PI_DATA_COLUMNS(I).COL_NAME||', XMLTYPE.CREATEXML('''') ) as '||PI_DATA_COLUMNS(I).COL_NAME

                                        ELSE
                                         CASE
                                           WHEN PI_AV_GENERATED_BY_SW = 0 THEN
                                            ' cast (Decode(OP.ROW_IDENTIFIER,null,
                                         cast ( null ' || ' ' ||
                                            ' as ' || PI_DATA_COLUMNS(I).COL_DATA_TYPE ||
                                            ' ) , OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                            ' )as ' || PI_DATA_COLUMNS(I).COL_DATA_TYPE ||
                                            ') as ' || PI_DATA_COLUMNS(I).COL_NAME


                                           ELSE
                                            'cast ( null ' || ' ' || '
                                         as ' || PI_DATA_COLUMNS(I)
                                           .COL_DATA_TYPE || ') as ' || PI_DATA_COLUMNS(I)
                                           .COL_NAME
                                         END
                                      END;
          /* commons_utils.INSERT_LOGS('2');*/
        END IF;
      END LOOP;
    END IF;

    IF (PI_KEY_COLUMNS IS NOT NULL) THEN
      FOR I IN 1 .. PI_KEY_COLUMNS.COUNT LOOP

        V_SELECT_CLAUSE   := CASE
                               WHEN V_SELECT_CLAUSE IS NOT NULL THEN
                                V_SELECT_CLAUSE || ' , ' || PI_KEY_COLUMNS(I).COL_NAME
                               ELSE
                                PI_KEY_COLUMNS(I).COL_NAME
                             END;
        V_GROUP_BY_CLAUSE := CASE
                               WHEN V_GROUP_BY_CLAUSE IS NOT NULL THEN
                                V_GROUP_BY_CLAUSE || ' , ' || PI_KEY_COLUMNS(I)
                               .COL_NAME
                               ELSE
                                PI_KEY_COLUMNS(I).COL_NAME
                             END;
        V_OUTER_KEY := CASE
                         WHEN V_OUTER_KEY IS NOT NULL THEN
                          V_OUTER_KEY || ' , IP. ' || PI_KEY_COLUMNS(I).COL_NAME
                         ELSE
                          'IP.' || PI_KEY_COLUMNS(I).COL_NAME
                       END;

        --join in case of autonumbered table
        IF (PI_IS_AUTO_VALUED IS NOT NULL AND PI_IS_AUTO_VALUED = 1) THEN

          V_JOIN_CLAUSE := CASE
                             WHEN V_JOIN_CLAUSE IS NOT NULL THEN
                              V_JOIN_CLAUSE || ' and ' || ' ( ' || 'OP.' || PI_KEY_COLUMNS(I)
                             .COL_NAME || '= IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                              ' ) '
                             ELSE
                              V_JOIN_CLAUSE || ' ( ' || 'OP.' || PI_KEY_COLUMNS(I)
                             .COL_NAME || '= IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                              ' ) '
                           END;
        ELSE
          ----join in case of normal table
          V_JOIN_CLAUSE := CASE
                             WHEN V_JOIN_CLAUSE IS NOT NULL THEN
                             --added by pramod on 9-Oct-2013  ...(To convert character columns to upper case so that comparison will be case insensitive)
                              CASE
                                WHEN UPPER(PI_KEY_COLUMNS(I).COL_DATA_TYPE) LIKE
                                     'VARCHAR%' THEN
                                 V_JOIN_CLAUSE || ' and ' || ' ( ' || 'UPPER( OP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ') = UPPER( IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ')' ||

                                 CASE
                                   WHEN PI_KEY_COLUMNS(I).COL_IS_REQUIRED = 0 THEN
                                    ' or (IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null and OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null ) '
                                 END || '  ) '
                                ELSE
                                --end of addition by pramod.
                                 V_JOIN_CLAUSE || ' and ' || ' ( ' || ' OP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || '=IP.' || PI_KEY_COLUMNS(I).COL_NAME ||

                                 CASE
                                   WHEN PI_KEY_COLUMNS(I).COL_IS_REQUIRED = 0 THEN
                                    ' or (IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null and OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null ) '
                                 END || ' ) '
                              END
                             ELSE
                             --added by pramod on 9-Oct-2013  ...(To convert character columns to upper case so that comparison will be case insensitive)
                              CASE
                                WHEN UPPER(PI_KEY_COLUMNS(I).COL_DATA_TYPE) LIKE
                                     'VARCHAR%' THEN
                                 V_JOIN_CLAUSE || ' ( ' || 'UPPER( OP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ') = UPPER(IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ')' ||

                                 CASE
                                   WHEN PI_KEY_COLUMNS(I).COL_IS_REQUIRED = 0 THEN
                                    ' or (IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null and OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null  ) '
                                 END || ' ) '
                                ELSE
                                --end of addition by pramod.
                                 V_JOIN_CLAUSE || ' ( ' || ' OP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || '=IP.' || PI_KEY_COLUMNS(I).COL_NAME ||

                                 CASE
                                   WHEN PI_KEY_COLUMNS(I).COL_IS_REQUIRED = 0 THEN
                                    ' or (IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null and OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                    ' is null  ) '
                                 END || ' ) '
                              END
                           END;
        END IF;
      END LOOP;
    END IF;

    IF (PI_AV_GENERATED_BY_SW = 1) THEN
      --key columns select clause
      V_SELECT_CLAUSE := ' NULL as ' || PI_AV_COL_NAME || ' ';
      V_OUTER_KEY     := ' cast (NULL as number(10)) as ROW_IDENTIFIER, cast (NULL as number(10)) as ROW_VERSION ';
    END IF;

    ------------outer query
    V_SQL := ' CREATE TABLE ' || PI_QI_TABLE ||
             ' ROWDEPENDENCIES INITRANS ' || V_INTRANS_VALUE ||
             ' NOLOGGING TABLESPACE ' || USER || '_DTS' || ' AS SELECT ';
    IF (PI_AV_GENERATED_BY_SW = 0) THEN
      V_SQL := V_SQL ||
               ' OP.ROW_IDENTIFIER as ROW_IDENTIFIER , OP.ROW_VERSION as ROW_VERSION ,';
    END IF;
    ---add key cols to outer query select
    V_SQL := CASE
               WHEN V_OUTER_KEY IS NOT NULL THEN
                V_SQL || V_OUTER_KEY
               ELSE
                V_SQL
             END;

    --add data cols to outer query select
    V_SQL := CASE
               WHEN V_SELECT_ADD_TO_EXISTING IS NOT NULL THEN
                V_SQL || V_SELECT_ADD_TO_EXISTING
               ELSE
                V_SQL
             END;

    ----

    IF (PI_AGGREGATE in (1, 2, 3) and V_SELECT_CLAUSE is not null and pi_av_generated_by_sw <> 1) THEN --deshmukha added V_SELECT_CLAUSE is not null
      --IF AGGREGATION OPTION IS SELECTED CALL STORED PROCEDURE TO SEGREGATE DUPLICATE AND DISTINCT RECORD ON THE BASIS OF KEY COLUMNS.
      COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION(PIO_DUMP_TABLE        => V_DUMP_TABLE,
                                                        PI_INTRANS_VALUE      => V_INTRANS_VALUE,
                                                        PI_KEY_COLUMNS        => V_SELECT_CLAUSE,
                                                        PI_DATA_COLUMNS       => V_DATA_COLUMNS_agg,
                                                        PI_WHERE_CONDITIONS   => PI_WHERE_CONDITIONS,
                                                        PI_AGGREGATION_CLAUSE => V_AGGREGATION_CLAUSE,
                                                        PI_GROUP_BY_CLAUSE    => V_GROUP_BY_CLAUSE,
                                                        PI_AGGREGATION_ORDER  => PI_AGGREGATION_ORDER,
                                                        PIO_DUPLICATE_TABLE   => PIO_DUPLICATE_TABLE,
                                                        PI_AGREEGATE          => PI_AGGREGATE,
                                                        PO_STOP_FLAG          => V_STOP_FLAG,
                                                        PI_ADD_LOG_INFO       => PI_ADD_LOG_INFO);
      IF (V_STOP_FLAG = 1) THEN
        --  RETURN;
        if (PI_AGGREGATE = 2) then
          -- deshmukha added the code to drop dist table created in DUMP_TABLE_SEGREGATION
          for c in (select 1
                      from user_tables
                     where table_name = V_DUMP_TABLE) loop
            V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
            COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
          END LOOP;
          raise_application_error(-20007, 'Uniqueness check failed');
        end if;
      END IF;
      V_SUBQUERY_SQL := '( SELECT * FROM ' || V_DUMP_TABLE || ')';
    ELSE
      V_SUBQUERY_SQL := '( SELECT * FROM ' || V_DUMP_TABLE;
      V_SUBQUERY_SQL := V_SUBQUERY_SQL || CASE
                          WHEN PI_WHERE_CONDITIONS IS NOT NULL THEN
                           ' WHERE ' || PI_WHERE_CONDITIONS || ' ) '
                          ELSE
                           ' ) '
                        END;
    END IF;

    IF (PI_AV_GENERATED_BY_SW = 0) THEN
      --join

      V_SQL := V_SQL || ' FROM ' || V_SUBQUERY_SQL ||
               ' IP LEFT OUTER JOIN  ' || PI_DEST_TABLE || ' OP ' ||
               ' ON  ' || V_JOIN_CLAUSE;

      --where for mode
      V_SQL := V_SQL || CASE
                 WHEN PI_MODE = 4 THEN
                  ' where OP.ROW_IDENTIFIER is null '
                 WHEN PI_MODE = 2 THEN
                  ' where OP.ROW_IDENTIFIER is not null'
                 WHEN PI_MODE = 3 THEN
                  ' '
               END;
    ELSE
      V_SQL := V_SQL || ' FROM ' || V_SUBQUERY_SQL || ' IP ';
    END IF;
    L_OFFSET := 1;
    --DEBUGGING
    -- EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING V_SQL;
    -- COMMIT;

    IF (PI_AV_GENERATED_BY_SW = 0) THEN
      -- generate stats for PI_DUMP_TABLE to be used while joining with the PI_DEST_TABLE
      COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(PI_TABLE => V_DUMP_TABLE,
                                               PI_MODE  => 2);

    end if;
    ------INSERT_LOGS(v_sql); --dbms_output.put_line(v_sql);     --to be removed
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DL_QI_CREATION';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL),
                      'V_SQL := <value>;',
                      v_stamp);

    --Logging changes end
    commons_utils.insert_logs(v_sql);
    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL, pi_to_trace => 1);
    COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(PI_TABLE => PI_QI_TABLE,
                                             PI_MODE  => 2);
    --DEBUGGING
    --EXECUTE IMMEDIATE 'CREATE TABLE BKP_AFT_'||V_DUMP_TABLE||' AS SELECT * FROM '||V_DUMP_TABLE;
    --EXECUTE IMMEDIATE 'CREATE TABLE BKP_'||PI_QI_TABLE||' AS SELECT * FROM '||PI_QI_TABLE;

    IF (PI_AGGREGATE in (1, 2, 3) and V_SELECT_CLAUSE is not null and pi_av_generated_by_sw <> 1) THEN --deshmukha added V_SELECT_CLAUSE is not null
      -- deshmukha added 2,3 to drop orphan dupl and dist tables created in dump table segregation
      for c in (select 1
                      from user_tables
                     where table_name = V_DUMP_TABLE) loop
      V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
      end loop;

    END IF;
   /* exception when others then
      commons_utils.insert_logs('Exception : '||sqlerrm || dbms_utility.format_error_backtrace());*/
  END DL_QI_CREATION;

  Procedure DL_QI_CREATION(pi_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                           pi_QI_TABLE               IN VARCHAR2, -- QI table name
                           pi_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_av_generated_by_sw     IN NUMBER, --auto-value column
                           pi_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                           pi_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER      IN VARCHAR2,
                           pi_WHERE_CONDITIONS       IN VARCHAR2, -- the where clause is needed to ignore the rejected records i.e the records failed the validations above.
                           pi_id_column_name         VARCHAR2,
                           pi_seq_used_for_id        VARCHAR2,
                           pi_version_column_name    VARCHAR2,
                           pi_ent_intern_id_col_name VARCHAR2,
                           pi_av_col_name            VARCHAR2,
                           po_row_id_max_value       out number,
                           po_COUNT                  out number,
                           po_av_count               out number,
                           PIO_DUPLICATE_TABLE       IN VARCHAR2,
                           pi_reset_sequence         in number default 0,

                           PI_ADD_LOG_INFO IN COLTYPE_KEY_VALUE default null,
                           PI_INPUT_COUNT  in number default null /*,
                                                                                                                                                                                             PI_SEQ_RESET_FLAG in number default 1*/) IS

    V_SQL                    CLOB;
    V_SELECT_ADD_TO_EXISTING CLOB;
    V_OUTER_KEY              CLOB;
    V_SUBQUERY_SQL           CLOB;
    V_SELECT_CLAUSE          CLOB;
    V_CREATE_DATA_COL_LIST   CLOB;
    V_CREATE_KEY_COL_LIST    CLOB;
    V_GROUP_BY_CLAUSE        CLOB;
    V_TEMP_INDEX_DDL         CLOB;
    V_AGGREGATION_CLAUSE     CLOB;
    V_DEFAULT_CLAUSE         CLOB;
    V_DEFAULT_SELECT         CLOB;
    V_INTRANS_VALUE          NUMBER;
    V_AV_QUERY               VARCHAR2(300);
    V_ID_SEQ_VALUE           NUMBER;
    V_WHERE_REQUIRED         BOOLEAN := TRUE;
    L_OFFSET                 NUMBER DEFAULT 1;
    V_SQL_DROP_DUMP_TABLE    CLOB;
    V_DATA_COLUMNS           CLOB;
    V_DATA_COLUMNS_agg       CLOB;
    V_DUMP_TABLE             VARCHAR2(50) := PI_DUMP_TABLE;
    v_stamp                  VARCHAR2(250);
    V_STOP_FLAG              number := 0;
    v_seq_value              number;
  BEGIN

    --debugging
    -- EXECUTE IMMEDIATE 'CREATE TABLE BKP_BFR_'||V_DUMP_TABLE||' AS SELECT * FROM '||V_DUMP_TABLE;
    -- EXECUTE IMMEDIATE 'CREATE TABLE BKP_'||PI_DEST_TABLE||' AS SELECT * FROM '||PI_DEST_TABLE;
    -- EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING PI_AGGREGATE;
    --COMMIT;
    if (pi_AGGREGATE in (2, 3)) then
      /*  V_DATA_COLUMNS := pi_id_column_name || ',' || pi_version_column_name;*/

      if PI_ADD_LOG_INFO is null /* or PI_AGGREGATE=3 */
       then
        V_DATA_COLUMNS_agg := PI_ID_COLUMN_NAME || ',' ||
                              PI_VERSION_COLUMN_NAME;

      end if;
      if pi_reset_sequence = 1 then
        v_seq_value := 1;
      else
        execute immediate 'select ' || PI_SEQ_USED_FOR_ID ||
                          '.nextval from dual'
          into v_seq_value;

      end if;
      if /*PI_ADD_LOG_INFO is null or*/
       PI_AGGREGATE IN (3) then
        V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || ' , max(' ||
                                nvl(PI_INPUT_COUNT, 1) || '+ rownum + ' ||
                                v_seq_value || ') AS ' || PI_ID_COLUMN_NAME;
      else
        V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_ID_COLUMN_NAME ||
                                ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                PI_AGGREGATION_ORDER || ' ) AS ' ||
                                PI_ID_COLUMN_NAME;
      end if;

      /*  V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
      ,   max(' || PI_ID_COLUMN_NAME ||
                           ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                           PI_AGGREGATION_ORDER || ' ) AS ' ||
                           PI_ID_COLUMN_NAME;*/
      V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_VERSION_COLUMN_NAME ||
                              ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                              PI_AGGREGATION_ORDER || ' ) AS ' ||
                              PI_VERSION_COLUMN_NAME;

      /*ELSE
      V_DATA_COLUMNS_agg       := PI_ID_COLUMN_NAME || ',' ||
                                 PI_VERSION_COLUMN_NAME;*/
    end if;
    EXECUTE IMMEDIATE ' select ' || PI_SEQ_USED_FOR_ID ||
                      '.nextval from dual'
      INTO V_ID_SEQ_VALUE;
    SELECT MAX(PR_VALUE)
      INTO V_INTRANS_VALUE
      FROM PROPERTIES
     WHERE PR_NAME = 'INITRANS';

    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DL_QI_CREATION2';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(to_clob(V_ID_SEQ_VALUE)),
                      'V_ID_SEQ_VALUE := <value>;',
                      v_stamp);

    --Logging changes end
    --row identifier
    V_DEFAULT_CLAUSE := CASE
                          WHEN PI_ID_COLUMN_NAME IS NOT NULL THEN
                           PI_ID_COLUMN_NAME || ' NOT NULL'
                          ELSE
                           ' '
                        END;

    --shri

    if (pi_reset_sequence = 0) then
      V_DEFAULT_SELECT := CASE
                            WHEN PI_ID_COLUMN_NAME IS NOT NULL THEN
                             'CAST (ROWNUM -1+' || V_ID_SEQ_VALUE ||
                             ' AS NUMBER(10)) as ' || PI_ID_COLUMN_NAME
                            ELSE
                             ' '
                          END;
    elsif (pi_reset_sequence = 1) then
      V_DEFAULT_SELECT := CASE
                            WHEN PI_ID_COLUMN_NAME IS NOT NULL THEN
                             'CAST (ROWNUM  AS NUMBER(10)) as ' ||
                             PI_ID_COLUMN_NAME
                            ELSE
                             ' '
                          END;
    end if;
    --shri

    --pi_version_column_name

    V_DEFAULT_CLAUSE := CASE
                          WHEN PI_VERSION_COLUMN_NAME IS NOT NULL THEN
                           V_DEFAULT_CLAUSE || ' , ' || PI_VERSION_COLUMN_NAME ||
                           ' NOT NULL '
                          ELSE
                           V_DEFAULT_CLAUSE
                        END;
    V_DEFAULT_SELECT := CASE
                          WHEN PI_VERSION_COLUMN_NAME IS NOT NULL THEN
                           V_DEFAULT_SELECT || ' ,CAST (0 AS NUMBER(10)) as ' ||
                           PI_VERSION_COLUMN_NAME
                          ELSE
                           V_DEFAULT_SELECT
                        END;

    --pi_ent_intern_id_col_name
    V_DEFAULT_CLAUSE := CASE
                          WHEN PI_ENT_INTERN_ID_COL_NAME IS NOT NULL THEN
                           V_DEFAULT_CLAUSE || ' , ' ||
                           PI_ENT_INTERN_ID_COL_NAME || ' NOT NULL'
                          ELSE
                           V_DEFAULT_CLAUSE
                        END;
    V_DEFAULT_SELECT := CASE
                          WHEN PI_ENT_INTERN_ID_COL_NAME IS NOT NULL THEN
                           V_DEFAULT_SELECT ||
                           ' ,CAST (ROWNUM AS NUMBER(10)) as ' ||
                           PI_ENT_INTERN_ID_COL_NAME
                          ELSE
                           V_DEFAULT_SELECT
                        END;

    --pi_av_col_name
    IF (PI_AV_GENERATED_BY_SW = 1) THEN
      V_DEFAULT_CLAUSE := CASE
                            WHEN PI_AV_COL_NAME IS NOT NULL THEN
                             V_DEFAULT_CLAUSE || ' , ' || PI_AV_COL_NAME ||
                             ' NOT NULL'
                            ELSE
                             V_DEFAULT_CLAUSE
                          END;
      V_DEFAULT_SELECT := CASE
                            WHEN PI_AV_COL_NAME IS NOT NULL THEN
                             V_DEFAULT_SELECT ||
                             ' ,CAST (ROWNUM AS NUMBER(10)) as ' ||
                             PI_AV_COL_NAME
                            ELSE
                             V_DEFAULT_SELECT
                          END;

    END IF;

    IF (PI_DATA_COLUMNS IS NOT NULL) THEN

      FOR I IN 1 .. PI_DATA_COLUMNS.COUNT LOOP

        IF (PI_DATA_COLUMNS(I).COL_IS_MAPPED = 1) THEN

          V_DATA_COLUMNS := CASE
                              WHEN V_DATA_COLUMNS IS NOT NULL THEN
                               V_DATA_COLUMNS || ' , ' || PI_DATA_COLUMNS(I).COL_NAME
                              ELSE
                               PI_DATA_COLUMNS(I).COL_NAME
                            END;

          V_DATA_COLUMNS_agg := CASE
                                  WHEN V_DATA_COLUMNS_agg IS NOT NULL THEN
                                   V_DATA_COLUMNS_agg || ' , ' || PI_DATA_COLUMNS(I)
                                  .COL_NAME
                                  ELSE
                                   PI_DATA_COLUMNS(I).COL_NAME
                                END;
          IF (PI_DATA_COLUMNS(I).AGG_TYPE = 0) THEN

         /*   V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_DATA_COLUMNS(I)
                                   .COL_NAME ||
                                    ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                    PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                   .COL_NAME;*/

             if PI_DATA_COLUMNS(I).col_data_type = 'XMLTYPE' THEN
              V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(t.' || PI_DATA_COLUMNS(I)
                                     .COL_NAME ||
                                      '.GETSTRINGVAL()) KEEP(DENSE_RANK LAST ORDER BY ' ||
                                      PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME;

              /*commons_utils.INSERT_LOGS('mean V_AGGREGATION_CLAUSE ' ||
              V_AGGREGATION_CLAUSE);*/

            ELSE

              V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
                              ,   max(' || PI_DATA_COLUMNS(I)
                                     .COL_NAME ||
                                      ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                      PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME;
              /* commons_utils.INSERT_LOGS('mean 1 V_AGGREGATION_CLAUSE ' ||
              V_AGGREGATION_CLAUSE);*/

            END IF;

            V_SELECT_ADD_TO_EXISTING := V_SELECT_ADD_TO_EXISTING || ' , ' ||

             case WHEN PI_DATA_COLUMNS(I)
                                         .COL_DATA_TYPE = 'XMLTYPE' THEN
                                        'IP.'||PI_DATA_COLUMNS(I).COL_NAME|| ' as ' ||PI_DATA_COLUMNS(I).COL_NAME
                      else
                                        ' cast ( IP.' || PI_DATA_COLUMNS(I)
                                       .COL_NAME || ' AS ' || PI_DATA_COLUMNS(I)
                                       .COL_DATA_TYPE || ' )' || '
                    AS ' || PI_DATA_COLUMNS(I)
                                       .COL_NAME end;

            V_CREATE_DATA_COL_LIST := V_CREATE_DATA_COL_LIST || ' , ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME || ' ' || CASE
                                        WHEN PI_DATA_COLUMNS(I).COL_IS_REQUIRED = 1 THEN
                                         'NOT'
                                      END || ' NULL  ';

          ELSE

            V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || ' ,cast( ROUND (' || CASE
                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 1 THEN
                                       'SUM'

                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 2 THEN
                                       'MIN'

                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 3 THEN
                                       'MAX'

                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 4 THEN
                                       'AVG'
                                    END || ' ( ' || PI_DATA_COLUMNS(I).COL_NAME ||
                                    '   ),' || PI_DATA_COLUMNS(I).DECIMAL_LENGTH ||
                                    ' )  AS  NUMBER(23,10) ) AS ' || PI_DATA_COLUMNS(I)
                                   .COL_NAME;

            V_SELECT_ADD_TO_EXISTING := V_SELECT_ADD_TO_EXISTING ||' , '||
            case WHEN PI_DATA_COLUMNS(I)
                                         .COL_DATA_TYPE = 'XMLTYPE' THEN
                                        'IP.'||PI_DATA_COLUMNS(I).COL_NAME|| ' as ' ||PI_DATA_COLUMNS(I).COL_NAME
                      else


                                        ' cast ( ' || '  IP.' || PI_DATA_COLUMNS(I)
                                       .COL_NAME || ' AS ' || PI_DATA_COLUMNS(I)
                                       .COL_DATA_TYPE || ' )' || '  AS ' || PI_DATA_COLUMNS(I)
                                       .COL_NAME end;

            V_CREATE_DATA_COL_LIST := V_CREATE_DATA_COL_LIST || ' , ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME || ' ' || CASE
                                        WHEN PI_DATA_COLUMNS(I).COL_IS_REQUIRED = 1 THEN
                                         'NOT'
                                      END || ' NULL  ';

          END IF;
        ELSE

          V_SELECT_ADD_TO_EXISTING := V_SELECT_ADD_TO_EXISTING || ' , ' ||
                                      case WHEN PI_DATA_COLUMNS(I)
                                         .COL_DATA_TYPE = 'XMLTYPE' THEN
                                        ' XMLTYPE.createXML('''') '|| ' as ' ||PI_DATA_COLUMNS(I).COL_NAME


                                      else
                                      'cast ( null  as ' || PI_DATA_COLUMNS(I)
                                     .COL_DATA_TYPE || ')' || '  AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME end;

          V_CREATE_DATA_COL_LIST := V_CREATE_DATA_COL_LIST || ' , ' || PI_DATA_COLUMNS(I)
                                   .COL_NAME || ' ' || CASE
                                      WHEN PI_DATA_COLUMNS(I).COL_IS_REQUIRED = 1 THEN
                                       ' NOT'
                                      ELSE
                                       ' NULL  '
                                    END;

        END IF;
      END LOOP;
    END IF;

    IF (PI_KEY_COLUMNS IS NOT NULL) THEN

      FOR I IN 1 .. PI_KEY_COLUMNS.COUNT LOOP

        --key columns select clause

        V_SELECT_CLAUSE   := CASE
                               WHEN V_SELECT_CLAUSE IS NOT NULL THEN
                                V_SELECT_CLAUSE || ' , ' || PI_KEY_COLUMNS(I).COL_NAME
                               ELSE
                                PI_KEY_COLUMNS(I).COL_NAME
                             END;
        V_GROUP_BY_CLAUSE := CASE
                               WHEN V_GROUP_BY_CLAUSE IS NOT NULL THEN
                                V_GROUP_BY_CLAUSE || ' , ' || PI_KEY_COLUMNS(I)
                               .COL_NAME
                               ELSE
                                PI_KEY_COLUMNS(I).COL_NAME
                             END;
        V_OUTER_KEY := CASE
                         WHEN V_OUTER_KEY IS NOT NULL THEN
                          V_OUTER_KEY || ' , ' else ' ' end||/*'cast(  IP. ' || PI_KEY_COLUMNS(I)
                         .COL_NAME || ' as ' || PI_KEY_COLUMNS(I).COL_DATA_TYPE ||
                          ' ) AS ' || PI_KEY_COLUMNS(I).COL_NAME
                         ELSE*/

                          ' cast(  IP.' || PI_KEY_COLUMNS(I).COL_NAME || ' as ' || PI_KEY_COLUMNS(I)
                         .COL_DATA_TYPE || ' ) AS ' || PI_KEY_COLUMNS(I).COL_NAME
                       ;

        V_CREATE_KEY_COL_LIST := V_CREATE_KEY_COL_LIST || ' , ' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ' ' || CASE
                                   WHEN PI_KEY_COLUMNS(I).COL_IS_REQUIRED = 1 THEN
                                    'NOT'
                                 END || ' NULL  ';

      END LOOP;
    END IF;

    ------------outer query
    V_SQL := ' CREATE TABLE ' || PI_QI_TABLE || '( ' ||
             NVL(V_DEFAULT_CLAUSE, ' ') || ' ' ||
             NVL(V_CREATE_KEY_COL_LIST, ' ') || ' ' ||
             NVL(V_CREATE_DATA_COL_LIST, ' ') || ' )
             ROWDEPENDENCIES INITRANS ' || V_INTRANS_VALUE ||
             ' NOLOGGING TABLESPACE ' || USER || '_DTS' || ' AS SELECT  ' ||
             V_DEFAULT_SELECT;

    ---add key cols to outer query select
    V_SQL := CASE
               WHEN V_OUTER_KEY IS NOT NULL THEN
                V_SQL || ' , ' || V_OUTER_KEY
               ELSE
                V_SQL
             END;
    --add data cols to outer query select
    V_SQL := CASE
               WHEN V_SELECT_ADD_TO_EXISTING IS NOT NULL THEN
                V_SQL || V_SELECT_ADD_TO_EXISTING
               ELSE
                V_SQL
             END;

    IF (PI_AGGREGATE in (1, 2, 3) and V_SELECT_CLAUSE is not null and PI_AV_GENERATED_BY_SW <> 1) THEN --deshmukha added V_SELECT_CLAUSE is not null
      --IF AGGREGATION OPTION IS SELECTED CALL STORED PROCEDURE TO SEGREGATE DUPLICATE AND DISTINCT RECORD ON THE BASIS OF KEY COLUMNS.
      COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION(PIO_DUMP_TABLE        => V_DUMP_TABLE,
                                                        PI_INTRANS_VALUE      => V_INTRANS_VALUE,
                                                        PI_KEY_COLUMNS        => V_SELECT_CLAUSE,
                                                        PI_DATA_COLUMNS       => V_DATA_COLUMNS_agg,
                                                        PI_WHERE_CONDITIONS   => PI_WHERE_CONDITIONS,
                                                        PI_AGGREGATION_CLAUSE => V_AGGREGATION_CLAUSE,
                                                        PI_GROUP_BY_CLAUSE    => V_GROUP_BY_CLAUSE,
                                                        PI_AGGREGATION_ORDER  => PI_AGGREGATION_ORDER,
                                                        PIO_DUPLICATE_TABLE   => PIO_DUPLICATE_TABLE,
                                                        PI_AGREEGATE          => PI_AGGREGATE,
                                                        PO_STOP_FLAG          => V_STOP_FLAG,
                                                        PI_ADD_LOG_INFO       => PI_ADD_LOG_INFO);
      IF (V_STOP_FLAG = 1) THEN
        --  RETURN;
        if (PI_AGGREGATE = 2) then
          -- deshmukha added the code to drop dist table created in DUMP_TABLE_SEGREGATION
          for c in (select 1
                      from user_tables
                     where table_name = V_DUMP_TABLE) loop
            V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
            COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
          END LOOP;
          raise_application_error(-20007, 'Uniqueness check failed');
        end if;
      END IF;
      V_SUBQUERY_SQL := '( SELECT * FROM ' || V_DUMP_TABLE || ')';
    ELSE
      V_SUBQUERY_SQL := '( SELECT * FROM ' || V_DUMP_TABLE;
      V_SUBQUERY_SQL := V_SUBQUERY_SQL || CASE
                          WHEN PI_WHERE_CONDITIONS IS NOT NULL THEN
                           ' WHERE ' || PI_WHERE_CONDITIONS || ' ) '
                          ELSE
                           ' ) '
                        END;
    END IF;
    --join
    V_SQL := V_SQL || ' FROM ' || V_SUBQUERY_SQL || ' IP ';

    --DEBUGGING
    --  EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING V_SQL;
    -- COMMIT;
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DL_QI_CREATION2';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL),
                      'V_SQL := <value>;',
                      v_stamp);

    --Logging changes end
commons_utils.insert_logs(v_sql);
    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL, pi_to_trace => 1);

    PO_COUNT := SQL%ROWCOUNT;
    IF (PI_AV_GENERATED_BY_SW = 1) THEN
      PO_AV_COUNT := PO_COUNT;

    ELSIF (PI_AV_GENERATED_BY_SW = 0 AND PI_AV_COL_NAME IS NOT NULL) THEN
      V_AV_QUERY := 'select max ( ' || PI_AV_COL_NAME || ') from ' ||
                    PI_QI_TABLE;

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.DL_QI_CREATION2';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(to_clob(PO_AV_COUNT)),
                        'PO_AV_COUNT := <value>;',
                        v_stamp);

      --Logging changes end

      EXECUTE IMMEDIATE V_AV_QUERY
        INTO PO_AV_COUNT;

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.DL_QI_CREATION2';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(to_clob(PO_AV_COUNT)),
                        'PO_AV_COUNT := <value>;',
                        v_stamp);

      --Logging changes end

    END IF;
    PO_ROW_ID_MAX_VALUE := PO_COUNT + V_ID_SEQ_VALUE - 1;
    COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(PI_TABLE => PI_QI_TABLE,
                                             PI_MODE  => 2);
    --DEBUGGING
    --EXECUTE IMMEDIATE 'CREATE TABLE BKP_AFT_'||V_DUMP_TABLE||' AS SELECT * FROM '||V_DUMP_TABLE;
    --EXECUTE IMMEDIATE 'CREATE TABLE BKP_'||PI_QI_TABLE||' AS SELECT * FROM '||PI_QI_TABLE;

    --DROPPING THE INTERMEDIATE DUMP TABLE HOLDING AGGREGATED RECORDS IN CASE OF AGGREGATION.
    IF (PI_AGGREGATE in (1, 2, 3) and V_SELECT_CLAUSE is not null and pi_av_generated_by_sw <> 1) THEN --deshmukha added V_SELECT_CLAUSE is not null
      -- deshmukha added 2,3 to drop orphan dupl and dist tables created in dump table segregation
       for c in (select 1
                      from user_tables
                     where table_name = V_DUMP_TABLE) loop
      V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
      end loop;
    END IF;
    --PUTTING THE QI TABLE IN LOGGING MODE.
    COMMONS_UTILS.ENABLE_LOGGING(PI_QI_TABLE);
  END DL_QI_CREATION;

  PROCEDURE DUMP_TABLE_SEGREGATION(PIO_DUMP_TABLE        IN OUT VARCHAR2,
                                   PI_INTRANS_VALUE      IN NUMBER,
                                   PI_KEY_COLUMNS        IN CLOB,
                                   PI_DATA_COLUMNS       IN CLOB,
                                   PI_WHERE_CONDITIONS   IN VARCHAR2,
                                   PI_AGGREGATION_CLAUSE IN CLOB,
                                   PI_GROUP_BY_CLAUSE    IN CLOB,
                                   PI_AGGREGATION_ORDER  IN VARCHAR2,
                                   PIO_DUPLICATE_TABLE   IN VARCHAR2,
                                   PI_AGREEGATE          IN NUMBER,
                                   PI_INPUT_COUNT        IN NUMBER default null,
                                   PO_STOP_FLAG          OUT NUMBER,
                                   PI_ADD_LOG_INFO       IN COLTYPE_KEY_VALUE default null)

   IS

    V_DATA_COLUMNS                 CLOB;
    V_SQL_DROP_INTERM_TABLE        CLOB;
    V_SQL_INSERT_DATA              CLOB;
    V_SQL_CREATE_DUPL_DUMP_TAB     CLOB;
    V_SQL_CREATE_DIST_DUMP_TAB     CLOB;
    V_SQL_DROP_DUPL_DUMP_TAB_FINAL CLOB;
    V_SQL_DROP_DIST_TABLE          CLOB;
    V_SUBQUERY_SQL                 CLOB;
    V_SUBQUERY_SQL_INS             CLOB;
    PI_DUPLICATE_DUMP_TABLE        VARCHAR2(30);
    PI_DISTINCT_DUMP_TABLE         VARCHAR2(30);
    --added by pramod on 9-oct-2013
    V_NLS_SORT VARCHAR2(30);
    V_NLS_COMP VARCHAR2(30);
    --end of addition by pramod
    v_stamp                    VARCHAR2(250);
    v_count                    number := 0;
    v_col_list                 varchar2(4000);
    v_val_list                 varchar2(4000);
    v_select_value             varchar2(4000);
    v_AV_max_value             number;
    v_AV_max_value_set         number;
    v_av_col_name              varchar2(30 char);
    v_dup_tables_id            number;
    v_where_dup                varchar2(1000 char);
    V_DUPL_COUNT               NUMBER;
    V_SQL_INSERT_DUPLICATE_TAB CLOB;
    v_env_name                 varchar2(50);

  BEGIN
    BEGIN
      SELECT nvl(max(PR_VALUE), 'SPM')
        INTO v_env_name
        FROM PROPERTIES
       WHERE PR_NAME = 'ENV_NAME';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_env_name := NULL;
    END;
    /*commons_utils.INSERT_LOGS (PIO_DUPLICATE_TABLE);  */
    PO_STOP_FLAG := 0;
    V_DUPL_COUNT := 0;
    /*dbms_output.put_line(PI_KEY_COLUMNS);*/
    /* --added by pramod on 09-oct-2013...(TO IGNORE CASE OF CHARACTER COLUMNS WHILE GROUPING THEM IN AGGREGATION)
    SELECT N.VALUE INTO V_NLS_COMP FROM NLS_SESSION_PARAMETERS N WHERE N.PARAMETER = 'NLS_COMP';
    SELECT N.VALUE INTO V_NLS_SORT FROM NLS_SESSION_PARAMETERS N WHERE N.PARAMETER = 'NLS_SORT';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP=''LINGUISTIC''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT=''BINARY_CI''';
    --end of addition by pramod.*/

    SELECT 'DIST_' || SUBSTR(PIO_DUMP_TABLE, 1, 25)
      INTO PI_DISTINCT_DUMP_TABLE
      FROM DUAL;
    SELECT 'DUPL_' || SUBSTR(PIO_DUMP_TABLE, 1, 25)
      INTO PI_DUPLICATE_DUMP_TABLE
      FROM DUAL;

    FOR C IN (SELECT TABLE_NAME
                FROM USER_TABLES
               WHERE TABLE_NAME IN (PI_DISTINCT_DUMP_TABLE)

                  or (TABLE_NAME IN (PI_DUPLICATE_DUMP_TABLE) and
                     PI_AGREEGATE = 1)) LOOP
      V_SQL_DROP_INTERM_TABLE := 'DROP TABLE ' || C.TABLE_NAME;
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_INTERM_TABLE);
    END LOOP;

    V_SQL_DROP_DUPL_DUMP_TAB_FINAL := 'DROP TABLE ' ||
                                      PI_DUPLICATE_DUMP_TABLE;
    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING PI_KEY_COLUMNS;
    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING PI_DATA_COLUMNS;
    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING PI_AGGREGATION_ORDER;
    --COMMIT;

    if (PI_AGREEGATE in (2, 3)) then
      /* commons_utils.insert_logs('inside if');*/
      FOR i IN 1 .. PI_ADD_LOG_INFO.COUNT LOOP
        /*commons_utils.insert_logs('inside for');*/
        --DBMS_OUTPUT.PUT_LINE('INSIDE LOOP');
        v_col_list := v_col_list || PI_ADD_LOG_INFO(i).v_key || ',';
        /*v_val_list:= v_val_list ||case when PI_ADD_LOG_INFO(i).v_value='autonumber' then PI_ADD_LOG_INFO(i).v_key else PI_ADD_LOG_INFO(i).v_value end|| ',';*/
        v_val_list := v_val_list || case
                        when PI_ADD_LOG_INFO(i).v_value = 'autonumber' then
                         PI_ADD_LOG_INFO(i).v_key
                        else
                        /* ''''||*/
                         PI_ADD_LOG_INFO(i).v_value /*||''''*/
                      end || ',';
        --v_val_list:= v_val_list || PI_ADD_LOG_INFO(i).v_value || ',';
        if PI_ADD_LOG_INFO(i).v_value = 'autonumber' then

          /*select tables_ID
           into v_dup_tables_id
           from tables
          where tables_physical_name = PIO_DUPLICATE_TABLE;*/

          -- for sales planning schema

          if v_env_name = 'SPM' then
            execute immediate 'select tables_ID
           from tables where tables_physical_name = ''' ||
                              PIO_DUPLICATE_TABLE || ''''
              into v_dup_tables_id;
            --v_AV_max_value := COMMONS_TABLES.GET_AUTO_VALUE(v_dup_tables_id);
             execute immediate 'select
  COMMONS_TABLES.GET_AUTO_VALUE(:1) from dual'
              into v_AV_max_value
              using v_dup_tables_id;
          end if;
          v_select_value := to_char(v_AV_max_value) || '+rownum-1 ' || PI_ADD_LOG_INFO(i)
                           .v_key || ',';
          v_av_col_name  := PI_ADD_LOG_INFO(i).v_key;
          if (v_AV_max_value <> 1) then
            v_where_dup := ' where ' || PI_ADD_LOG_INFO(i).v_key || '>=' ||
                           v_AV_max_value;

            /* v_av_col_name || ' >= ' ||
            v_AV_max_value*/

          end if;
          --v_select_value:=' 1+rownum v_num, ';
        end if;
      end loop;

    end if;
    --DBMS_OUTPUT.PUT_LINE('AFTER LOOP');
    /*  v_col_list := ltrim(v_col_list, ',');
    v_val_list := ltrim(v_val_list, ',');*/
    /* commons_utils.insert_logs(pi_clob => v_av_col_name);
       commons_utils.insert_logs(pi_clob => v_col_list);
        commons_utils.insert_logs(pi_clob => v_val_list);
         commons_utils.insert_logs(pi_clob => v_select_value);
    */
    --CREATING INTERMEDIATE DUMP TABLE TO HOLD DUPLICATE RECORDS
    V_SQL_CREATE_DUPL_DUMP_TAB := ' CREATE TABLE ' || PI_DUPLICATE_DUMP_TABLE ||
                                  ' ROWDEPENDENCIES INITRANS ' ||
                                  PI_INTRANS_VALUE ||
                                  ' NOLOGGING TABLESPACE ' || USER || '_OUT' ||
                                  ' AS SELECT ' || case
                                    when PI_INPUT_COUNT is not null then
                                     '/*+ CARDINALITY(' || PIO_DUMP_TABLE || ' ' ||
                                     PI_INPUT_COUNT || ') */ '

                                  end;
    V_SQL_CREATE_DUPL_DUMP_TAB := V_SQL_CREATE_DUPL_DUMP_TAB || case
                                    when PI_AGREEGATE in (2, 3) then
                                     ' ROW_IDENTIFIER, ROW_VERSION, '
                                  end;
    V_SQL_CREATE_DUPL_DUMP_TAB := CASE
                                    WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                                     V_SQL_CREATE_DUPL_DUMP_TAB ||
                                     PI_KEY_COLUMNS
                                    ELSE
                                     V_SQL_CREATE_DUPL_DUMP_TAB
                                  END;
    V_SQL_CREATE_DUPL_DUMP_TAB := CASE
                                    WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                                     V_SQL_CREATE_DUPL_DUMP_TAB || ' , ' ||
                                     PI_DATA_COLUMNS
                                    ELSE
                                     V_SQL_CREATE_DUPL_DUMP_TAB
                                  END;
    V_SQL_CREATE_DUPL_DUMP_TAB := CASE
                                    WHEN PI_AGGREGATION_ORDER IS NOT NULL THEN
                                     V_SQL_CREATE_DUPL_DUMP_TAB || ' , ' ||
                                     PI_AGGREGATION_ORDER
                                    ELSE
                                     V_SQL_CREATE_DUPL_DUMP_TAB
                                  END;
    V_SQL_CREATE_DUPL_DUMP_TAB := V_SQL_CREATE_DUPL_DUMP_TAB || ' FROM ' ||
                                  PIO_DUMP_TABLE || ' WHERE 1=2';
    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' using V_SQL_CREATE_DUPL_DUMP_TAB;
    -- dbms_output.put_line(V_SQL_CREATE_DUPL_DUMP_TAB);

    -- insert statement to insert data into PIO_DUPLICATE_TABLE from PI_DUPLICATE_DUMP_TABLE

    V_SQL_INSERT_DUPLICATE_TAB := 'insert all into ' || PIO_DUPLICATE_TABLE ||
                                  '(ROW_IDENTIFIER, ROW_VERSION ,' ||
                                  v_col_list;
    V_SQL_INSERT_DUPLICATE_TAB := CASE
                                    WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                                     V_SQL_INSERT_DUPLICATE_TAB ||
                                     PI_KEY_COLUMNS
                                    ELSE
                                     V_SQL_INSERT_DUPLICATE_TAB
                                  END;
    V_SQL_INSERT_DUPLICATE_TAB := CASE
                                    WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                                     V_SQL_INSERT_DUPLICATE_TAB || ' , ' ||
                                     PI_DATA_COLUMNS
                                    ELSE
                                     V_SQL_INSERT_DUPLICATE_TAB
                                  END;

    V_SQL_INSERT_DUPLICATE_TAB := CASE
                                    WHEN PI_AGGREGATION_ORDER IS NOT NULL THEN
                                     V_SQL_INSERT_DUPLICATE_TAB || ' , ' ||
                                     PI_AGGREGATION_ORDER
                                    ELSE
                                     V_SQL_INSERT_DUPLICATE_TAB
                                  END;
    V_SQL_INSERT_DUPLICATE_TAB := V_SQL_INSERT_DUPLICATE_TAB || ')';

    V_SQL_INSERT_DUPLICATE_TAB := V_SQL_INSERT_DUPLICATE_TAB ||
                                  ' VALUES(ROW_IDENTIFIER,ROW_VERSION,' ||
                                  v_val_list || CASE
                                    WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                                     PI_KEY_COLUMNS
                                  END || CASE
                                    WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                                     ' , ' || PI_DATA_COLUMNS
                                  END || CASE
                                    WHEN PI_AGGREGATION_ORDER IS NOT NULL THEN
                                     ' , ' || PI_AGGREGATION_ORDER
                                  END || ')';

    V_SQL_INSERT_DUPLICATE_TAB := V_SQL_INSERT_DUPLICATE_TAB ||
                                  'SELECT ROW_IDENTIFIER,ROW_VERSION,';

    V_SQL_INSERT_DUPLICATE_TAB := V_SQL_INSERT_DUPLICATE_TAB ||
                                  v_select_value;
    V_SQL_INSERT_DUPLICATE_TAB := CASE
                                    WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                                     V_SQL_INSERT_DUPLICATE_TAB ||
                                     PI_KEY_COLUMNS
                                    ELSE
                                     V_SQL_INSERT_DUPLICATE_TAB
                                  END;
    V_SQL_INSERT_DUPLICATE_TAB := CASE
                                    WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                                     V_SQL_INSERT_DUPLICATE_TAB || ' , ' ||
                                     PI_DATA_COLUMNS
                                    ELSE
                                     V_SQL_INSERT_DUPLICATE_TAB
                                  END;
    V_SQL_INSERT_DUPLICATE_TAB := CASE
                                    WHEN PI_AGGREGATION_ORDER IS NOT NULL THEN
                                     V_SQL_INSERT_DUPLICATE_TAB || ' , ' ||
                                     PI_AGGREGATION_ORDER
                                    ELSE
                                     V_SQL_INSERT_DUPLICATE_TAB
                                  END;
    V_SQL_INSERT_DUPLICATE_TAB := V_SQL_INSERT_DUPLICATE_TAB || ' FROM ' ||
                                  PI_DUPLICATE_DUMP_TABLE;
    -- End of insert statement to insert data into PIO_DUPLICATE_TABLE from PI_DUPLICATE_DUMP_TABLE

    --Logging changes start
    v_stamp := 'COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL_CREATE_DUPL_DUMP_TAB),
                      'V_SQL_CREATE_DUPL_DUMP_TAB := <value>;',
                      v_stamp);

    --Logging changes end

    /*if PI_AGREEGATE in (2, 3) then
      PI_DUPLICATE_DUMP_TABLE := PIO_DUPLICATE_TABLE;
    else*/
    -- insert_logs(V_SQL_CREATE_DUPL_DUMP_TAB);
    -- insert_logs(PI_DATA_COLUMNS);

    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_CREATE_DUPL_DUMP_TAB);
    --commons_utils.insert_logs(V_SQL_CREATE_DUPL_DUMP_TAB);
    --end if;

    --CREATING INTERMEDIATE DUMP TABLE TO HOLD DISTINCT RECORDS
    V_SQL_CREATE_DIST_DUMP_TAB := ' CREATE TABLE ' || PI_DISTINCT_DUMP_TABLE ||
                                  ' ROWDEPENDENCIES INITRANS ' ||
                                  PI_INTRANS_VALUE ||
                                  ' NOLOGGING TABLESPACE ' || USER || '_DTS' ||
                                  ' AS SELECT ' || case
                                    when PI_INPUT_COUNT is not null then
                                     '/*+ CARDINALITY(' || PIO_DUMP_TABLE || ' ' ||
                                     PI_INPUT_COUNT || ') */ '

                                  end;
    V_SQL_CREATE_DIST_DUMP_TAB := V_SQL_CREATE_DIST_DUMP_TAB || case
                                    when PI_AGREEGATE in (2, 3) then
                                     ' ROW_IDENTIFIER, ROW_VERSION, '
                                  end;
    V_SQL_CREATE_DIST_DUMP_TAB := CASE
                                    WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                                     V_SQL_CREATE_DIST_DUMP_TAB ||
                                     PI_KEY_COLUMNS
                                    ELSE
                                     V_SQL_CREATE_DIST_DUMP_TAB
                                  END;
    V_SQL_CREATE_DIST_DUMP_TAB := CASE
                                    WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                                     V_SQL_CREATE_DIST_DUMP_TAB || ' , ' ||
                                     PI_DATA_COLUMNS
                                    ELSE
                                     V_SQL_CREATE_DIST_DUMP_TAB
                                  END;
    V_SQL_CREATE_DIST_DUMP_TAB := V_SQL_CREATE_DIST_DUMP_TAB || ' FROM ' ||
                                  PIO_DUMP_TABLE || ' WHERE 1=2';
    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' using V_SQL_CREATE_DIST_DUMP_TAB;
    -- dbms_output.put_line(V_SQL_CREATE_DIST_DUMP_TAB);
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL_CREATE_DIST_DUMP_TAB),
                      'V_SQL_CREATE_DIST_DUMP_TAB := <value>;',
                      v_stamp);

    --Logging changes end
    --commons_utils.insert_logs(V_SQL_CREATE_DIST_DUMP_TAB);
    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_CREATE_DIST_DUMP_TAB);

    --INSERTING DUPLICATE AND DISTINCT RECORDS INTO CORRESPONDING INTERMEDIATE DUMP TABLES.
    V_SQL_INSERT_DATA := 'INSERT  /*+ APPEND */  WHEN RECORD_CNT=1
                   THEN  INTO ' ||
                         PI_DISTINCT_DUMP_TABLE || ' ( ' || case
                           when PI_AGREEGATE in (2, 3) then
                            ' ROW_IDENTIFIER, ROW_VERSION, '
                         end || CASE
                           WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                            PI_KEY_COLUMNS
                         end || CASE
                           WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                            ' , ' || PI_DATA_COLUMNS
                         end || ' ) ' || ' VALUES (';
    V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || case
                           when PI_AGREEGATE in (2, 3) then
                            ' ROW_IDENTIFIER, ROW_VERSION, '
                         end;
    V_SQL_INSERT_DATA := CASE
                           WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                            V_SQL_INSERT_DATA || PI_KEY_COLUMNS
                           ELSE
                            V_SQL_INSERT_DATA
                         END;
    V_SQL_INSERT_DATA := CASE
                           WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                            V_SQL_INSERT_DATA || ' , ' || PI_DATA_COLUMNS
                           ELSE
                            V_SQL_INSERT_DATA
                         END;
    V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || ') ELSE  INTO ' ||
                         PI_DUPLICATE_DUMP_TABLE || ' ( ' || case
                           when PI_AGREEGATE in (2, 3) then
                            ' ROW_IDENTIFIER, ROW_VERSION, '
                         end || --v_col_list ||
                         CASE
                           WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                            PI_KEY_COLUMNS
                         end || CASE
                           WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                            ' , ' || PI_DATA_COLUMNS
                         end || CASE
                           WHEN PI_AGGREGATION_ORDER IS NOT NULL and
                                PI_AGREEGATE in (1, 3) THEN
                            ' , ' || PI_AGGREGATION_ORDER
                         end || ' ) ' || ' VALUES (' || case
                           when PI_AGREEGATE in (2, 3) then
                            ' ' || PIO_DUPLICATE_TABLE ||
                            '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0, '
                         end; --|| v_val_list;

    V_SQL_INSERT_DATA := CASE
                           WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                            V_SQL_INSERT_DATA || PI_KEY_COLUMNS
                           ELSE
                            V_SQL_INSERT_DATA
                         END;
    V_SQL_INSERT_DATA := CASE
                           WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                            V_SQL_INSERT_DATA || ' , ' || PI_DATA_COLUMNS
                           ELSE
                            V_SQL_INSERT_DATA
                         END;
    V_SQL_INSERT_DATA := CASE
                           WHEN PI_AGGREGATION_ORDER IS NOT NULL and
                                PI_AGREEGATE in (1, 3) THEN
                            V_SQL_INSERT_DATA || ' , ' || PI_AGGREGATION_ORDER
                           ELSE
                            V_SQL_INSERT_DATA
                         END;

    V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || ') SELECT ' || case
                           when PI_INPUT_COUNT is not null then
                            '/*+ CARDINALITY(' || PIO_DUMP_TABLE || ' ' ||
                            PI_INPUT_COUNT || ') */ '

                         end;

    V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || case
                           when PI_AGREEGATE in (2, 3) then
                            ' ROW_IDENTIFIER, ROW_VERSION, '
                         end;
    -- V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || v_select_value;
    V_SQL_INSERT_DATA := CASE
                           WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                            V_SQL_INSERT_DATA || PI_KEY_COLUMNS
                           ELSE
                            V_SQL_INSERT_DATA
                         END;
    V_SQL_INSERT_DATA := CASE
                           WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                            V_SQL_INSERT_DATA || ' , ' || PI_DATA_COLUMNS
                           ELSE
                            V_SQL_INSERT_DATA
                         END;

    V_SQL_INSERT_DATA := CASE
                           WHEN PI_AGGREGATION_ORDER IS NOT NULL and
                                PI_AGREEGATE in (1, 3) THEN
                            V_SQL_INSERT_DATA || ' , ' || PI_AGGREGATION_ORDER
                           ELSE
                            V_SQL_INSERT_DATA
                         END;
    V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || ' ,
                COUNT(*) OVER(PARTITION BY ' ||
                         PI_KEY_COLUMNS || ') AS RECORD_CNT
                FROM ' || PIO_DUMP_TABLE;
    V_SQL_INSERT_DATA := V_SQL_INSERT_DATA || CASE
                           WHEN PI_WHERE_CONDITIONS IS NOT NULL THEN
                            ' WHERE ' || PI_WHERE_CONDITIONS
                           ELSE
                            ' '
                         END;
    --DEBUGGING
    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING V_SQL_INSERT_DATA;
    --COMMIT;
    /*COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_INSERT_DATA);*/
    -- dbms_output.put_line(V_SQL_INSERT_DATA);

    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL_INSERT_DATA),
                      'V_SQL_INSERT_DATA := <value>;',
                      v_stamp);

    --Logging changes end
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SQL_INSERT_DATA),
                      'V_SQL_INSERT_DATA := <value>;',
                      v_stamp);

    --Logging changes end
    -- commons_utils.insert_logs(V_SQL_INSERT_DATA);
    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG('begin ' || '
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_COMP=''''LINGUISTIC'''''';
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_SORT=''''BINARY_CI'''''';' ||
                                           V_SQL_INSERT_DATA || ';
     EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_COMP=''''BINARY'''''';
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_SORT=''''BINARY'''''';
     end;',
                                           pi_to_trace => 0);

    /* commons_utils.insert_logs('out');*/
    /*commons_utils.insert_logs('out');*/
    if ( /*PI_ADD_LOG_INFO is not null*/
        PI_AGREEGATE in (2, 3)) then
      /*commons_utils.insert_logs('1');*/
      EXECUTE IMMEDIATE 'select count(*) from ' || PI_DUPLICATE_DUMP_TABLE
        into V_DUPL_COUNT;

      if V_DUPL_COUNT > 0 then
        --commons_utils.insert_logs(V_SQL_INSERT_DUPLICATE_TAB);
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_INSERT_DUPLICATE_TAB);
      end if;
      /*commons_utils.insert_logs('in');*/
      execute immediate '
  select nvl(max(' || v_av_col_name || '),0)  from ' ||
                        PIO_DUPLICATE_TABLE
        into v_AV_max_value_set;
      /* commons_utils.insert_logs(v_av_col_name);
      commons_utils.insert_logs(PIO_DUPLICATE_TABLE);
      commons_utils.insert_logs(to_char(v_AV_max_value));*/
      commons_ddl_handling.execute_ddl_nolog('begin
COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => ' ||
                                             v_dup_tables_id || ',
                                    pi_value    => ' ||
                                             v_AV_max_value_set || ');

                                    end;');

    end if;

    if PI_AGREEGATE = 2 then

      /*EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || PIO_DUPLICATE_TABLE ||
      /* ' WHERE ' ||*/
      --v_where_dup
      /* v_av_col_name || ' >= ' ||
      v_AV_max_value*/
      --INTO v_count;
      --IF v_count > 0 THEN
      IF V_DUPL_COUNT > 0 THEN
        PO_STOP_FLAG := 1;
        -- deshmukha added code to drop dist table
      for c in (select 1
                    from user_tables
                   where table_name = PI_DISTINCT_DUMP_TABLE) loop
          V_SQL_DROP_DIST_TABLE := 'DROP TABLE ' || PI_DISTINCT_DUMP_TABLE;

          COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DIST_TABLE);
        END LOOP;
      END IF;
      if (PI_WHERE_CONDITIONS is not null) then
        PIO_DUMP_TABLE := PI_DISTINCT_DUMP_TABLE;
        -- deshmukha added else for Dropping dist dump table in case it is not being used further.
        else
        for c in (select 1
                    from user_tables
                   where table_name = PI_DISTINCT_DUMP_TABLE) loop
        execute immediate 'drop table ' || PI_DISTINCT_DUMP_TABLE;
        end loop;
      end if;
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(V_SQL_DROP_DUPL_DUMP_TAB_FINAL),
                        'V_SQL_DROP_DUPL_DUMP_TAB_FINAL := <value>;',
                        v_stamp);

      --Logging changes end
      -- deshmukha added Dropping dupl dump table.
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUPL_DUMP_TAB_FINAL);
      return;
    end if;

    V_SUBQUERY_SQL := ' SELECT ';
    V_SUBQUERY_SQL := CASE
                        WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                         V_SUBQUERY_SQL || PI_KEY_COLUMNS
                        ELSE
                         V_SUBQUERY_SQL
                      END;
    --AGGREGATION CLAUSE
    V_SUBQUERY_SQL := CASE
                        WHEN PI_AGGREGATION_CLAUSE IS NOT NULL THEN
                         V_SUBQUERY_SQL || PI_AGGREGATION_CLAUSE
                        ELSE
                         V_SUBQUERY_SQL
                      END;

    --shri start
    V_SUBQUERY_SQL := V_SUBQUERY_SQL || ' FROM ' || PI_DUPLICATE_DUMP_TABLE ||
                      ' T ';
    --shri end

    --V_SUBQUERY_SQL := V_SUBQUERY_SQL || v_where_dup;
    --GROUP BY CLAUSE
    V_SUBQUERY_SQL := V_SUBQUERY_SQL || ' ' || ' GROUP BY ' ||
                      PI_GROUP_BY_CLAUSE;

    --INSERTING DUPLICATE AND DISTINCT RECORDS INTO CORRESPONDING INTERMEDIATE DUMP TABLES.

    V_SUBQUERY_SQL_INS := 'INSERT /*+ APPEND */  INTO ' ||
                          PI_DISTINCT_DUMP_TABLE ||
                         /* ' ( '||CASE
                                                                                                                                                                                                                                                             WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                                                                                                                                                                                                                                                               PI_KEY_COLUMNS end ||CASE
                                                                                                                                                                                                                                                            WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                                                                                                                                                                                                                                                                 ' , ' || PI_DATA_COLUMNS
                                                                                                                                                                                                                                                                 end
                                                                                                                                                                                                                                                                 ||' ) '||*/
                          '(';
    V_SUBQUERY_SQL_INS := CASE
                            WHEN PI_KEY_COLUMNS IS NOT NULL THEN
                             V_SUBQUERY_SQL_INS || PI_KEY_COLUMNS
                            ELSE
                             V_SUBQUERY_SQL_INS
                          END;

    V_SUBQUERY_SQL_INS := V_SUBQUERY_SQL_INS || case
                            when PI_AGREEGATE in (2, 3) then
                             ' , ROW_IDENTIFIER, ROW_VERSION '
                          end;
    V_SUBQUERY_SQL_INS := CASE
                            WHEN PI_DATA_COLUMNS IS NOT NULL THEN
                             V_SUBQUERY_SQL_INS || ' , ' || PI_DATA_COLUMNS
                            ELSE
                             V_SUBQUERY_SQL_INS
                          END;
    V_SUBQUERY_SQL_INS := V_SUBQUERY_SQL_INS || ')' || V_SUBQUERY_SQL;

    --EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' USING V_SUBQUERY_SQL_INS;
    --COMMIT;

    /*COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SUBQUERY_SQL_INS);*/

    -- dbms_output.put_line(V_SUBQUERY_SQL_INS);

    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(V_SUBQUERY_SQL_INS),
                      'V_SUBQUERY_SQL_INS := <value>;',
                      v_stamp);

    -- commons_utils.INSERT_LOGS(V_SUBQUERY_SQL_INS);
    --Logging changes end
    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG('begin ' || '
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_COMP=''''LINGUISTIC'''''';
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_SORT=''''BINARY_CI'''''';' ||
                                           V_SUBQUERY_SQL_INS || ';
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_COMP=''''BINARY'''''';
    EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_SORT=''''BINARY'''''';
     end;',
                                           pi_to_trace => 0);

    --DROP DUPLICATE DUMP TABLE ONCE THE DATA IS INSERTED IN DISTINCT DUMP TABLE,WHICH WILL BE TREATED AS FINAL DUMP TABLE
    --shri
    -- deshmukha removed the if condition , now dropping dupl table evry time.
    /*if PI_AGREEGATE = 1 then
      V_SQL_DROP_DUPL_DUMP_TAB_FINAL := 'DROP TABLE ' ||
                                        PI_DUPLICATE_DUMP_TABLE;*/
      -- EXECUTE IMMEDIATE 'INSERT INTO CATCH VALUES (:1) ' using V_SQL_DROP_DUPL_DUMP_TAB_FINAL;

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(V_SQL_DROP_DUPL_DUMP_TAB_FINAL),
                        'V_SQL_DROP_DUPL_DUMP_TAB_FINAL := <value>;',
                        v_stamp);

      --Logging changes end
      COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUPL_DUMP_TAB_FINAL);

   /* end if;*/

    PIO_DUMP_TABLE := PI_DISTINCT_DUMP_TABLE;

    /*  --added by pramod on 09-oct-2013...(TO REVERT THE CHANGES MADE TO SESSION VARIABLES)
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''' || V_NLS_COMP || '''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''' || V_NLS_SORT || '''';
    --end of addition by pramod.*/

  EXCEPTION
    WHEN OTHERS THEN
      /*commons_utils.INSERT_LOGS(to_char(sqlerrm));*/
      /*--added by pramod on 09-oct-2013...(TO REVERT THE CHANGES MADE TO SESSION VARIABLES)
      EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''' || V_NLS_COMP || '''';
      EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''' || V_NLS_SORT || '''';*/
      --end of addition by pramod.
      /*commons_utils.insert_logs('Error at line '||dbms_utility.format_error_backtrace || sqlerrm);*/
      FOR C IN (SELECT TABLE_NAME
                  FROM USER_TABLES
                 WHERE TABLE_NAME IN (PI_DISTINCT_DUMP_TABLE)

                    or (TABLE_NAME IN (PI_DUPLICATE_DUMP_TABLE) and
                       PI_AGREEGATE = 1)) LOOP

        V_SQL_DROP_INTERM_TABLE := 'DROP TABLE ' || C.TABLE_NAME;

        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_INTERM_TABLE);
      END LOOP;
      raise;
  END DUMP_TABLE_SEGREGATION;


  PROCEDURE DL_ORACLE_INPUT_GET_OBJECTS(PI_DBLINK_NAME IN VARCHAR2,
                                        PO_OBJECT_LIST OUT SYS_REFCURSOR) IS
  BEGIN
    --Checking db link name,in case special string is passed ,data will be fetched from the existing schema,else via db link.
    --Fetching the name of all the applicable object types supportes in oracle table input.
    IF (PI_DBLINK_NAME = '~!@#$%^&*()_+:?') then
      OPEN PO_OBJECT_LIST FOR 'SELECT OBJECT_NAME FROM USER_OBJECTS
       WHERE OBJECT_TYPE IN( ''TABLE'',''VIEW'')
       UNION ALL
       SELECT SYNONYM_NAME FROM USER_SYNONYMS  USL, USER_DEPENDENCIES  UDL
       WHERE NLSSORT(USL.SYNONYM_NAME, ''NLS_SORT = BINARY'' )= NLSSORT(UDL.NAME,''NLS_SORT = BINARY'') AND REFERENCED_TYPE IN (''TABLE'',''VIEW'',''MATERIALIZED VIEW'')
       ORDER BY OBJECT_NAME';
    ELSE
      OPEN PO_OBJECT_LIST FOR 'SELECT OBJECT_NAME FROM USER_OBJECTS@' || PI_DBLINK_NAME || '
       WHERE OBJECT_TYPE IN( ''TABLE'',''VIEW'')
       UNION ALL
       SELECT SYNONYM_NAME FROM USER_SYNONYMS@' || PI_DBLINK_NAME || ' USL, USER_DEPENDENCIES@' || PI_DBLINK_NAME || ' UDL
       WHERE NLSSORT(USL.SYNONYM_NAME, ''NLS_SORT = BINARY'' )= NLSSORT(UDL.NAME,''NLS_SORT = BINARY'') AND REFERENCED_TYPE IN (''TABLE'',''VIEW'',''MATERIALIZED VIEW'')
       ORDER BY OBJECT_NAME';
    END IF;
  END DL_ORACLE_INPUT_GET_OBJECTS;

  PROCEDURE DL_ORACLE_INPUT_GET_COL_LIST(PI_OBJECT_NAME IN VARCHAR2,
                                         PI_DBLINK_NAME IN VARCHAR2,
                                         PO_COLUMN_LIST OUT SYS_REFCURSOR) IS
    V_OBJ_TYPE       VARCHAR2(50);
    V_OBJ_NAME       VARCHAR2(50);
    V_DBLINKNAME_STR VARCHAR2(50);
    v_stamp          VARCHAR2(250);
  BEGIN
    V_OBJ_NAME := PI_OBJECT_NAME;

    --Checking db link name,in case special string is passed ,data will be fetched from the existing schema,else via db link.
    IF (PI_DBLINK_NAME = '~!@#$%^&*()_+:?') THEN
      V_DBLINKNAME_STR := '';
    ELSE
      V_DBLINKNAME_STR := '@' || PI_DBLINK_NAME;
    END IF;

    BEGIN
      --Getting the object type of the object name.
      EXECUTE IMMEDIATE 'SELECT OBJECT_TYPE FROM USER_OBJECTS' ||
                        V_DBLINKNAME_STR ||
                        ' WHERE  NLSSORT(OBJECT_NAME,''NLS_SORT = BINARY'') = NLSSORT(''' ||
                        PI_OBJECT_NAME ||
                        ''',''NLS_SORT = BINARY'') AND OBJECT_TYPE IN (''VIEW'',''TABLE'',''SYNONYM'')'
        INTO V_OBJ_TYPE;

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.DL_ORACLE_INPUT_GET_COL_LIST';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(V_OBJ_TYPE),
                        'V_OBJ_TYPE := <value>;',
                        v_stamp);

      --Logging changes end
    EXCEPTION
      --Raising exception in case the object is not present i.e. is deleted from the database.
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20101,
                                'REQUESTED OBJECT ' || PI_OBJECT_NAME ||
                                ' NO LONGER EXISTS IN THE TARGTE DATABASE');
    END;
    --Checking the type of object if it is not among the valid type,raising an exception.
    IF (V_OBJ_TYPE NOT IN ('TABLE', 'SYNONYM', 'VIEW')) THEN
      RAISE_APPLICATION_ERROR(-20101,
                              'REQUESTED OBJECT ' || V_OBJ_NAME ||
                              ' IS OF TYPE ' || V_OBJ_TYPE ||
                              ', NOT AMONG THE VALID OBJECT TYPES
                             TABLE/SYNONYM/VIEW/MATERIALIZED VIEW');
    END IF;
    --If the object is of type Synonym,then fetching the base table name on which the synonym is created.
    IF (V_OBJ_TYPE = 'SYNONYM') THEN
      BEGIN
        EXECUTE IMMEDIATE 'SELECT TABLE_NAME FROM USER_SYNONYMS' ||
                          V_DBLINKNAME_STR || ' USL, USER_DEPENDENCIES' ||
                          V_DBLINKNAME_STR ||
                          ' UDL
                        WHERE NLSSORT(USL.SYNONYM_NAME, ''NLS_SORT = BINARY'' )= NLSSORT(UDL.NAME,''NLS_SORT = BINARY'') AND REFERENCED_TYPE IN (''TABLE'',''VIEW'',''MATERIALIZED VIEW'')
                        AND  NLSSORT(SYNONYM_NAME,''NLS_SORT=BINARY'') = NLSSORT(''' ||
                          PI_OBJECT_NAME || ''',''NLS_SORT = BINARY'')'
          INTO V_OBJ_NAME;

        --Logging changes start

        v_stamp := 'COMMONS_DATALOADPROCESSING.DL_ORACLE_INPUT_GET_COL_LIST';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(V_OBJ_NAME),
                          'V_OBJ_NAME := <value>;',
                          v_stamp);

        --Logging changes end
        --In case the object on which synonym is created is not of valid type,raising an exception.
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20101,
                                  'OBJECT NAME ' || PI_OBJECT_NAME ||
                                  ' IS NOT A VALID SYNONYM FOR A TABLE/VIEW/MATERIALIZED VIEW ');
      END;
    END IF;
    --Opening the out cursor for the list of applicable columns and properties of the object.
    OPEN PO_COLUMN_LIST FOR 'SELECT COLUMN_NAME,
  DATA_TYPE,
  DATA_PRECISION,
  DATA_SCALE
  FROM ALL_TAB_COLS' || V_DBLINKNAME_STR || ' ATC
  WHERE NLSSORT(ATC.TABLE_NAME,''NLS_SORT = BINARY'') = NLSSORT(''' || V_OBJ_NAME || ''', ''NLS_SORT = BINARY'')
  AND HIDDEN_COLUMN=''NO'' AND VIRTUAL_COLUMN=''NO''';

  END DL_ORACLE_INPUT_GET_COL_LIST;

   PROCEDURE COMMON_OVERLAP_NP(pi_Dest_Table      IN VARCHAR2,
                              pi_QI_Table        IN VARCHAR2,
                              pi_key_Fields      IN VARCHAR2,
                              PI_Effective_Start IN VARCHAR2,
                              PI_Effective_End   IN VARCHAR2,
                              PI_Is_Period       IN number,
                              PI_TU_ID           IN number,
                              PI_Is_Recreate     IN number,
                              PI_TEMP_TABLE      IN VARCHAR2,
                              PI_TEMP_COL        IN VARCHAR2,
                              PI_MODE            IN varchar2,
                              po_Overlap_Chk_Res OUT NUMBER,
                              PI_INPUT_COUNT     IN NUMBER default null,
                              PI_RUN_ID          IN NUMBER DEFAULT NULL) IS

    v_KEY_COLS       clob := PI_Key_Fields || ',';
    v_JOIN_CONDITION VARCHAR2(32767) := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';

    V_OVERLAP_RESULT Number;
    v_Intenal_query  clob;
    l_offset         number default 1;
    v_Dest_Table     clob;--varchar2(1000);
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           sys_refcursor;
    v_KEY_FIELDS     clob := '''' || replace(pi_KEY_FIELDS, ',', ''',''') || '''';

    --Checking the Columns data type
    v_data_type number;
    v_stamp     VARCHAR2(250);
    v_temp_tab_count number;

  begin

    -- dbms_output.put_line(pi_key_Fields);
    --Sagar
    ----INSERT_LOGS(PI_CLOB => 'COMMON_OVERLAP called');
    select max(num_rows) into v_temp_tab_count from user_tables where table_name = PI_TEMP_TABLE;
    if (pi_KEY_FIELDS is null) then
      v_JOIN_CONDITION := null;

    else
      --DBMS_OUTPUT.PUT_LINE('v_KEY_FIELDS:'||v_KEY_FIELDS);

      /*  DBMS_OUTPUT.PUT_LINE('
      select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
        from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_Dest_Table || ''')) t
        where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')');*/

      --Change in Key fields in list
      open cv_sql for '
select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_Dest_Table || ''')) t
  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';

      loop
        fetch cv_sql
          into v_COL_NAME, v_IS_NULLABLE, v_data_type;
        EXIT WHEN cv_sql%NOTFOUND;

        v_JOIN_CONDITION := v_JOIN_CONDITION || CASE
                              WHEN v_IS_NULLABLE = 0 THEN --required column

                               CASE
                                 WHEN v_data_type in (1, 4) THEN --note or chracter

                                  ' UPPER(a.' || v_COL_NAME || ') = UPPER(b.' ||
                                  v_COL_NAME || ')'

                               --end of addition by pramod
                                 ELSE
                                  '  a.' || v_COL_NAME || ' = b.' || v_COL_NAME
                               end
                              ELSE
                               COMMONS_TABLES.nvl_check(v_col_name, v_data_type)

                            END || ' and ';

        /*      -- if fields are Character or Note
        if v_data_type in (1, 4) then
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( UPPER(a.' ||
                              v_COL_NAME || ') = UPPER(b.' || v_COL_NAME || '))' || case
                                when v_IS_NULLABLE = 1 then
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' || v_COL_NAME ||
                                 ' IS NULL )'
                              end || ') and';
        else
          v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( a.' || v_COL_NAME || ' = b.' ||
                              v_COL_NAME || ')' || case
                                when v_IS_NULLABLE = 1 then
                                 ' or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                                 v_COL_NAME || ' IS NULL )'
                              end || ') and';
        end if;*/

      END LOOP;

      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;

      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION,
                                 1,
                                 LENGTH(v_JOIN_CONDITION) - 4);

    end if;

    /*  DBMS_OUTPUT.PUT_LINE('v_JOIN_CONDITION:'||v_JOIN_CONDITION);*/

    if (PI_Is_Recreate = 0) then
      v_Dest_Table:='( Select 1 to_calculate,' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end||
              ' from ' || pi_Dest_Table || ' Dest ' || case
                when pi_mode in (3, 2) then
                 ' where not exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE || ' Qi where NVL(Qi.' ||
                 PI_TEMP_COL || ',-1)=Dest.row_identifier )'
              end || ')';
      /*select '( Select 1 to_calculate,' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || pi_Dest_Table || ' Dest ' || case
                when pi_mode in (3, 2) then
                 ' where not exists
( select 1 from ' || PI_TEMP_TABLE || ' Qi where Qi.' ||
                 PI_TEMP_COL || '=Dest.row_identifier )'
              end || ')'

        into v_Dest_Table
        from dual;*/
    elsif (PI_Is_Recreate = 1) then
      /*  select pi_Dest_Table into v_Dest_Table from dual;*/
      v_Dest_Table := pi_Dest_Table;
    end if;

    /*
    '||decode(PI_Is_Recreate,1,' where 1=2 ',null)||'*/
    if (PI_is_Period = 0) then
      v_Intenal_query:= '
with Table_Check as
 (

  select /*+ materialize */ rownum as row_number,
          T.*, ' || PI_Effective_Start ||
              ' start_given,
          decode(to_calculate,1,decode(' || PI_Effective_End || ',
                 null,
                  LEAD(' || PI_Effective_Start ||
              ') OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by ' || PI_Effective_Start ||
              ' nulls first ) - 1,' || PI_Effective_End || '),0,' ||
              PI_Effective_End || ') AS end_calulated

    from (select to_calculate, ' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ';
              v_Intenal_query:=v_Intenal_query ||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end|| '
              from ' ;
             v_Intenal_query := v_Intenal_query || /*decode(PI_Is_Recreate,
                                            0,
                                            v_Dest_Table || ' IP
           union all',
                                            ' ( ')*/ case when PI_Is_Recreate=0 then v_Dest_Table || ' IP
           union all' else ' ( ' end || '
           select 0 to_calculate,' || PI_Effective_Start ||
              ' , ' || PI_Effective_End || ' ' ;
              v_Intenal_query:=v_Intenal_query||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP ) ' ||

              /*decode(PI_Is_Recreate, 0, ' ', ' ) ')*/ case when PI_Is_Recreate = 0 then ' ' else ' ) ' end || ' T)

--select * from Table_Check
,';
      /*select '
with Table_Check as
 (

  select \*+ materialize *\ rownum as row_number,
          T.*, ' || PI_Effective_Start ||
              ' start_given,
          decode(to_calculate,1,decode(' || PI_Effective_End || ',
                 null,
                  LEAD(' || PI_Effective_Start ||
              ') OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by ' || PI_Effective_Start ||
              ' nulls first ) - 1,' || PI_Effective_End || '),0,' ||
              PI_Effective_End || ') AS end_calulated

    from (select to_calculate, ' || PI_Effective_Start || ' , ' ||
              PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) || '
              from ' || decode(PI_Is_Recreate,
                                            0,
                                            v_Dest_Table || ' IP
           union all',
                                            ' ( ') || '
           select 0 to_calculate,' || PI_Effective_Start ||
              ' , ' || PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP ) ' ||

              decode(PI_Is_Recreate, 0, ' ', ' ) ') || ' T)

--select * from Table_Check
,'
        into v_Intenal_query
        from dual;*/

    elsif (PI_is_Period = 1) then

      v_Intenal_query:='

with Table_Check_partial as
 (select '||
                          COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_OVERLAP_CHECK',
                                                                    pi_hint_id   => 'OVPC1',
                                                                    pi_proc_id   => NULL) ||' rownum as row_number,
         T_Temp.*,
         T_Temp.tupr_start_date start_given,
          decode(to_calculate,1,
         LEAD(T_Temp.tupr_start_date) OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by T_Temp.tupr_start_date nulls first) ,0,T_Temp.tupr_start_date) end_calulated_partial

    from (

          select '||
                          COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_OVERLAP_CHECK',
                                                                    pi_hint_id   => 'OVPC2',
                                                                    pi_proc_id   => NULL) ||
                  ' Temp.*,
                  tupr_start.TUPR_start_date TUPR_start_date,
                  tupr_end.tupr_end_date     tupr_end_date,
                  tupr_start.TUPR_id         TUPR_start_id,
                  tupr_end.tupr_id           tupr_end_id

            from (select to_calculate,' || PI_Effective_Start ||
              ' , ' || PI_Effective_End || ' ' ;
              v_Intenal_query:=v_Intenal_query||
             /* decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end||
              ' from ' ;
              v_Intenal_query:=v_Intenal_query|| /*decode(PI_Is_Recreate,
                                 0,
                                 v_Dest_Table || ' IP
           union all',
                                 ' ( ')*/ case when PI_Is_Recreate = 0 then v_Dest_Table || ' IP
           union all' else ' ( ' end || '
                   select  0 to_calculate,' ||
              PI_Effective_Start || ' , ' || PI_Effective_End || ' ' ;
              v_Intenal_query:=v_Intenal_query ||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP )' || /*decode(PI_Is_Recreate, 0, ' ', ' ) ')*/case when PI_Is_Recreate = 0 then ' ' else ' ) ' end ||
              ' Temp
            left outer join tu_periods_range tupr_start
              on tupr_start.TUPR_ID = NVL(Temp.' ||
              PI_Effective_Start || ',-1)
            left outer join tu_periods_range tupr_end
              on tupr_end.TUPR_ID = NVL(Temp.' || PI_Effective_End ||
              ',-1)) T_Temp)
--select * from Table_Check_partial
,
Table_Check as

 (

  select T.*,
          (select tupr_end_date
             from tu_periods_range
            where tupr_id in (
             decode(to_calculate,1,
            decode(tupr_end_id,
                                     null,
                                     commons_timeunits.Get_nth_prior_period(' ||
              PI_TU_ID || ',
                                                                            (select tupr_id
                                                                               from tu_periods_range
                                                                              where tupr_start_date =
                                                                                    end_calulated_partial
                                                                                and tupr_tu_id =' ||
              PI_TU_ID || '

                                                                             ),
                                                                            1,
                                                                            2010,
                                                                            2025),
                                     tupr_end_id),tupr_end_id)

                                     )) end_calulated
    from Table_Check_partial T

  ),

 ';
      /*select '

with Table_Check_partial as
 (select rownum as row_number,
         T_Temp.*,
         T_Temp.tupr_start_date start_given,
          decode(to_calculate,1,
         LEAD(T_Temp.tupr_start_date) OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by T_Temp.tupr_start_date nulls first) ,0,T_Temp.tupr_start_date) end_calulated_partial

    from (

          select Temp.*,
                  tupr_start.TUPR_start_date TUPR_start_date,
                  tupr_end.tupr_end_date     tupr_end_date,
                  tupr_start.TUPR_id         TUPR_start_id,
                  tupr_end.tupr_id           tupr_end_id

            from (select to_calculate,' || PI_Effective_Start ||
              ' , ' || PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || decode(PI_Is_Recreate,
                                 0,
                                 v_Dest_Table || ' IP
           union all',
                                 ' ( ') || '
                   select  0 to_calculate,' ||
              PI_Effective_Start || ' , ' || PI_Effective_End || ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP )' || decode(PI_Is_Recreate, 0, ' ', ' ) ') ||
              ' Temp
            left outer join tu_periods_range tupr_start
              on tupr_start.TUPR_ID = Temp.' ||
              PI_Effective_Start || '
            left outer join tu_periods_range tupr_end
              on tupr_end.TUPR_ID = Temp.' || PI_Effective_End ||
              ') T_Temp)
--select * from Table_Check_partial
,
Table_Check as

 (

  select T.*,
          (select tupr_end_date
             from tu_periods_range
            where tupr_id in (
             decode(to_calculate,1,
            decode(tupr_end_id,
                                     null,
                                     commons_timeunits.Get_nth_prior_period(' ||
              PI_TU_ID || ',
                                                                            (select tupr_id
                                                                               from tu_periods_range
                                                                              where tupr_start_date =
                                                                                    end_calulated_partial
                                                                                and tupr_tu_id =' ||
              PI_TU_ID || '

                                                                             ),
                                                                            1,
                                                                            2010,
                                                                            2025),
                                     tupr_end_id),tupr_end_id)

                                     )) end_calulated
    from Table_Check_partial T

  ),

 '
        into v_Intenal_query
        from dual;*/

    end if;

    select v_Intenal_query || '

Overlap_check as
 (SELECT COUNT(*) FROM DUAL WHERE EXISTS
   (select /*+ USE_HASH(a,b) */ 1
            from Table_Check a, Table_Check b
           where ' ||
            decode(v_JOIN_CONDITION, null, null, v_JOIN_CONDITION || ' and ') || '
              (a.row_number <> b.row_number and
                 (
                 nvl(a.start_given,
                      to_date(''1 / 1 / 1900 '', ''mm / dd / yyyy '')) <=
                 nvl(b.end_calulated,
                      to_date('' 12 / 31 / 9999 '', '' mm / dd / yyyy ''))
                      and
                 nvl(a.end_calulated,
                      to_date('' 12 / 31 / 9999 '', '' mm / dd / yyyy '')) >=
                 nvl(b.start_given,
                      to_date('' 1 / 1 / 1900 '', '' mm / dd / yyyy ''))
                      )

                      )
                      )

  )

  select * from Overlap_check'
      into v_Intenal_query
      from dual;

    /* loop
        exit when l_offset > dbms_lob.getlength(v_Intenal_query);
        dbms_output.put_line(dbms_lob.substr(v_Intenal_query, 999, l_offset));
        l_offset := l_offset + 999;
      end loop;
      l_offset := 1;
    */
    --    DBMS_OUTPUT.PUT_LINE(v_OVERLAP_STR);

    --Sagar
    --  --INSERT_LOGS(PI_CLOB => 'v_Intenal_query '||v_Intenal_query);

    /* loop
        exit when l_offset > dbms_lob.getlength(v_Intenal_query);
      -- dbms_output.put_line( dbms_lob.substr( v_Intenal_query, 999, l_offset ) );
      l_offset := l_offset + 999;
    end loop;*/
    ----INSERT_LOGS(v_Intenal_query);
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.COMMON_OVERLAP_NP';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(v_Intenal_query),
                      'v_Intenal_query := <value>;',
                      v_stamp);

    --Logging changes end
    /*commons_utils.insert_logs('v_Intenal_query : '||v_Intenal_query);*/
    EXECUTE IMMEDIATE v_Intenal_query
      INTO V_OVERLAP_RESULT;
    COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => PI_RUN_ID,
                                      pi_query_identifier => NULL,
                                      pi_bind_variables   => NULL);
    -- Overlap check
    IF V_OVERLAP_RESULT = 1 THEN
      po_OVERLAP_CHK_RES := 0;
    ELSE
      po_OVERLAP_CHK_RES := 1;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;
      raise;
      /*        raise_application_error(-20101,
      'COMMON_OVERLAP_CHECK encountered an error');*/
  end COMMON_OVERLAP_NP;

  PROCEDURE COMMON_OVERLAP_NP_POST(pi_Dest_Table      IN VARCHAR2,
                                   pi_QI_Table        IN VARCHAR2,
                                   pi_key_Fields      IN VARCHAR2,
                                   pi_data_Fields     IN VARCHAR2 default null,
                                   PI_Effective_Start IN VARCHAR2,
                                   PI_Effective_End   IN VARCHAR2,
                                   PI_Is_Period       IN number,
                                   PI_TU_ID           IN number,
                                   PI_Is_Recreate     IN number,
                                   PI_TEMP_TABLE      IN VARCHAR2,
                                   PI_TEMP_COL        IN VARCHAR2,
                                   PI_MODE            IN varchar2,
                                   po_Overlap_Chk_Res OUT NUMBER,
                                   PI_INPUT_COUNT     IN NUMBER default null,
                                   PI_RUN_ID          IN NUMBER DEFAULT NULL,
                                   PI_OVERLAP_TABLE   IN Varchar2,
                                   PI_ADD_LOG_INFO    IN COLTYPE_KEY_VALUE default null) IS

    v_KEY_COLS       clob := PI_Key_Fields || ',';
    v_JOIN_CONDITION VARCHAR2(32767) := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';
    V_OVERLAP_RESULT Number;
    v_Intenal_query  clob;
    l_offset         number default 1;
    v_Dest_Table     clob;--varchar2(1000);
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           sys_refcursor;
    v_KEY_FIELDS     clob := '''' || replace(pi_KEY_FIELDS, ',', ''',''') || '''';
    v_insert_part    clob;
    v_post_select    clob;
    --Checking the Columns data type
    v_data_type     number;
    v_stamp         VARCHAR2(250);
    v_sql_temp      clob;
    v_count         number;
    v_col_list      varchar2(4000);
    v_val_list      varchar2(4000);
    v_select_value  varchar2(4000);
    v_AV_max_value  number;
    v_av_col_name   varchar2(30 char);
    v_ovr_tables_id number;
    v_data_fields   CLOB := '';
    v_temp_tab_count number;
  begin

    /*  execute immediate 'create table '||pi_QI_Table||'_bkp as select * from '||pi_QI_Table;
    execute immediate 'create table '||PI_TEMP_TABLE||'_bkp as select * from '||PI_TEMP_TABLE;*/

    -- dbms_output.put_line(pi_key_Fields);
    select max(num_rows) into v_temp_tab_count from user_tables where table_name = PI_TEMP_TABLE;
    if (PI_OVERLAP_TABLE is not null) then

      FOR i IN 1 .. PI_ADD_LOG_INFO.COUNT LOOP
        --DBMS_OUTPUT.PUT_LINE('INSIDE LOOP');
        v_col_list := v_col_list || PI_ADD_LOG_INFO(i).v_key || ',';
        /*v_val_list:= v_val_list ||case when PI_ADD_LOG_INFO(i).v_value='autonumber' then PI_ADD_LOG_INFO(i).v_key else PI_ADD_LOG_INFO(i).v_value end|| ',';*/
        /* v_val_list := v_val_list || case
          when PI_ADD_LOG_INFO(i).v_value = 'autonumber' then
           PI_ADD_LOG_INFO(i).v_key
          else
           PI_ADD_LOG_INFO(i).v_value
        end || ',';*/
        --v_val_list:= v_val_list || PI_ADD_LOG_INFO(i).v_value || ',';
        if PI_ADD_LOG_INFO(i).v_value = 'autonumber' then
          select tables_ID
            into v_ovr_tables_id
            from tables
           where tables_physical_name = PI_OVERLAP_TABLE;
          v_AV_max_value := COMMONS_TABLES.GET_AUTO_VALUE(v_ovr_tables_id);
          v_select_value := v_select_value || to_char(v_AV_max_value) ||
                            '+rownum-1 ' || PI_ADD_LOG_INFO(i).v_key || ',';

          v_av_col_name := PI_ADD_LOG_INFO(i).v_key;

          --v_select_value:=' 1+rownum v_num, ';
        else
          v_select_value := v_select_value || /*''''||*/
                            PI_ADD_LOG_INFO(i).v_value || /*''''||*/
                            ',';

        end if;
      end loop;

    end if;

    FOR CUR IN (SELECT PIF.column_value COLUMN_NAME, F.FLD_DATA_TYPE
                  FROM TABLE(COMMONS_TABLES.COMMA_TO_TABLE(PI_DATA_FIELDS)) PIF
                  LEFT OUTER JOIN FIELDS F
                    ON F.FLD_COLUMN_NAME = PIF.column_value) LOOP
      IF cur.FLD_DATA_TYPE = 9 THEN
        V_DATA_FIELDS := V_DATA_FIELDS || 'a.' || CUR.COLUMN_NAME ||
                         '.getstringval() ' || CUR.COLUMN_NAME || ',';
      ELSE
        V_DATA_FIELDS := V_DATA_FIELDS || 'a.' || CUR.COLUMN_NAME || ',';
      END IF;
    END LOOP;
    V_DATA_FIELDS := rtrim(V_DATA_FIELDS, ',');

    ----INSERT_LOGS(PI_CLOB => 'COMMON_OVERLAP called');
    if (pi_KEY_FIELDS is null) then
      v_JOIN_CONDITION := null;

      v_insert_part := ' insert into ' || PI_OVERLAP_TABLE || ' (' ||
                       v_col_list || 'row_identifier,row_version,' ||
                       pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD) ';
      v_sql_temp    := pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD/*,row_identifier,row_version*/ ';
      --v_post_select :=  /*case when pi_data_Fields is null then*/
      -- 'a.' /*end*/
      --                 || replace(pi_data_Fields, ',', ',a.') || /*'a.'||*/
      --                 PI_Effective_Start || /*',a.'||PI_Effective_END||*/
      --                 ',a.to_calculate DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';
      v_post_select := v_data_fields || PI_Effective_Start ||
                       ',a.to_calculate DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';

    else

      v_insert_part := ' insert into ' || PI_OVERLAP_TABLE || ' (' ||
                       v_col_list || 'row_identifier,row_version,' ||
                       pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                       ',DLP_EXISTING_RECORD' || ',' || pi_KEY_FIELDS || ') ';

      v_sql_temp := pi_data_Fields || PI_Effective_Start || /*','||PI_Effective_END||*/
                    ',DLP_EXISTING_RECORD/*,row_identifier,row_version*/' || ',' ||
                    pi_KEY_FIELDS;
      --v_post_select :=  /*case when pi_data_Fields is null then*/
      -- 'a.' /*end*/
      --                 || replace(pi_data_Fields, ',', ',a.') || /*'a.'||*/
      --                 PI_Effective_Start || /*',a.'||PI_Effective_END||*/
      --                 ',a.to_calculate DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';
      v_post_select := v_data_fields || PI_Effective_Start ||
                       ',a.to_calculate DLP_EXISTING_RECORD,rownum row_identifier,0 row_version';
      --DBMS_OUTPUT.PUT_LINE('v_KEY_FIELDS:'||v_KEY_FIELDS);
      -- INSERT_LOGS(PI_CLOB => 'pi_data_Fields ' || pi_data_Fields);
      -- INSERT_LOGS(PI_CLOB => 'v_post_select ' || v_post_select);
      /*  DBMS_OUTPUT.PUT_LINE('
      select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
        from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_Dest_Table || ''')) t
        where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')');*/

      --Change in Key fields in list
      open cv_sql for '
select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
  from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || pi_Dest_Table || ''')) t
  where t.COLUMN_NAME in (' || v_KEY_FIELDS || ')';

      loop
        fetch cv_sql
          into v_COL_NAME, v_IS_NULLABLE, v_data_type;
        EXIT WHEN cv_sql%NOTFOUND;
        v_post_select := v_post_select || ',a.' || v_COL_NAME;

        v_JOIN_CONDITION := v_JOIN_CONDITION || CASE
                              WHEN v_IS_NULLABLE = 0 THEN --required column

                               CASE
                                 WHEN v_data_type in (1, 4) THEN --note or chracter

                                  ' UPPER(a.' || v_COL_NAME || ') = UPPER(b.' ||
                                  v_COL_NAME || ')'

                               --end of addition by pramod
                                 ELSE
                                  '  a.' || v_COL_NAME || ' = b.' || v_COL_NAME
                               end
                              ELSE
                               COMMONS_TABLES.nvl_check(v_col_name, v_data_type)

                            END || ' and ';

        /* -- if fields are Character or Note
          if v_data_type in (1, 4) then
            v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( UPPER(a.' ||
                                v_COL_NAME || ') = UPPER(b.' || v_COL_NAME || '))' || case
                                  when v_IS_NULLABLE = 1 then
                                   ' or (a.' || v_COL_NAME || ' IS NULL AND b.' || v_COL_NAME ||
                                   ' IS NULL )'
                                end || ') and';
          else
            v_JOIN_CONDITION := v_JOIN_CONDITION || ' (( a.' || v_COL_NAME || ' = b.' ||
                                v_COL_NAME || ')' || case
                                  when v_IS_NULLABLE = 1 then
                                   ' or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                                   v_COL_NAME || ' IS NULL )'
                                end || ') and';
          end if;
        */
      END LOOP;

      IF cv_sql%ISOPEN THEN
        CLOSE cv_sql;
      END IF;

      v_JOIN_CONDITION := SUBSTR(v_JOIN_CONDITION,
                                 1,
                                 LENGTH(v_JOIN_CONDITION) - 4);

    end if;

    /*  DBMS_OUTPUT.PUT_LINE('v_JOIN_CONDITION:'||v_JOIN_CONDITION);*/

    if (PI_Is_Recreate = 0) then
      select '( Select ' || pi_data_Fields || ' 1 to_calculate,' ||
              PI_Effective_Start || /*' , ' ||
                                                                                                                                                                                                                                           PI_Effective_End || */
              ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || pi_Dest_Table || ' Dest ' || case
                when pi_mode in (3, 2) then
                 ' where not exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE || ' Qi where NVL(Qi.' ||
                 PI_TEMP_COL || ',-1)=Dest.row_identifier )'
              end || ')'

        into v_Dest_Table
        from dual;
    elsif (PI_Is_Recreate = 1) then
      /*  select pi_Dest_Table into v_Dest_Table from dual;*/
      v_Dest_Table := pi_Dest_Table;
    end if;

    /*
    '||decode(PI_Is_Recreate,1,' where 1=2 ',null)||'*/
    if (PI_is_Period = 0) then
    v_Intenal_query:= '
with Table_Check as
 (

  select /*+ materialize */ rownum as row_number,
          T.*, ' || PI_Effective_Start ||
              ' start_given,
          decode(to_calculate,1,decode(' || PI_Effective_End || ',
                 null,
                  LEAD(' || PI_Effective_Start ||
              ') OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by ' || PI_Effective_Start ||
              ' nulls first ) - 1,' || PI_Effective_End || '),0,' ||
              PI_Effective_End || ') AS end_calulated

    from (select ' ;
    v_Intenal_query:=v_Intenal_query|| pi_data_Fields || 'to_calculate, ' ||
              PI_Effective_Start || /*' , ' ||
                                                                                                                                                                                                                                           PI_Effective_End ||*/
              ' ' ;
              v_Intenal_query:=v_Intenal_query||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end|| '
              from ' || /*decode(PI_Is_Recreate,
                                            0,
                                            v_Dest_Table || ' IP
           union all',
                                            ' ( ') */case when PI_Is_Recreate = 0 then v_Dest_Table || ' IP
           union all' else ' ( ' end|| '
           select ' ;
           v_Intenal_query:=v_Intenal_query|| pi_data_Fields || '0 to_calculate,' ||
              PI_Effective_Start ||
             /*' , ' || PI_Effective_End || */
              ' ' ;
              v_Intenal_query:=v_Intenal_query||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP ) ' ||

              /*decode(PI_Is_Recreate, 0, ' ', ' ) ')*/ case when PI_Is_Recreate = 0 then ' ' else ' ) ' end|| ' T)

--select * from Table_Check
,';
     /*select '
with Table_Check as
 (

  select \*+ materialize *\ rownum as row_number,
          T.*, ' || PI_Effective_Start ||
              ' start_given,
          decode(to_calculate,1,decode(' || PI_Effective_End || ',
                 null,
                  LEAD(' || PI_Effective_Start ||
              ') OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by ' || PI_Effective_Start ||
              ' nulls first ) - 1,' || PI_Effective_End || '),0,' ||
              PI_Effective_End || ') AS end_calulated

    from (select ' || pi_data_Fields || 'to_calculate, ' ||
              PI_Effective_Start || \*' , ' ||
                                                                                                                                                                                                                                           PI_Effective_End ||*\
              ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) || '
              from ' || decode(PI_Is_Recreate,
                                            0,
                                            v_Dest_Table || ' IP
           union all',
                                            ' ( ') || '
           select ' || pi_data_Fields || '0 to_calculate,' ||
              PI_Effective_Start ||
             \*' , ' || PI_Effective_End || *\
              ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP ) ' ||

              decode(PI_Is_Recreate, 0, ' ', ' ) ') || ' T)

--select * from Table_Check
,'
        into v_Intenal_query
        from dual;*/

    elsif (PI_is_Period = 1) then

      v_Intenal_query:='

with Table_Check_partial as
 (select '||
                          COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_OVERLAP_CHECK',
                                                                    pi_hint_id   => 'OVPC1',
                                                                    pi_proc_id   => NULL) ||' rownum as row_number,
         T_Temp.*,
         T_Temp.tupr_start_date start_given,
          decode(to_calculate,1,
         LEAD(T_Temp.tupr_start_date) OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by T_Temp.tupr_start_date nulls first) ,0,T_Temp.tupr_start_date) end_calulated_partial

    from (

          select '||
                          COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_OVERLAP_CHECK',
                                                                    pi_hint_id   => 'OVPC2',
                                                                    pi_proc_id   => NULL) ||' Temp.*,
                  tupr_start.TUPR_start_date TUPR_start_date,
                  tupr_end.tupr_end_date     tupr_end_date,
                  tupr_start.TUPR_id         TUPR_start_id,
                  tupr_end.tupr_id           tupr_end_id

            from (select ' || pi_data_Fields || 'to_calculate,' ||
              PI_Effective_Start ||
             /*' , ' || PI_Effective_End ||*/
              ' ' ||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/
              case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end ||
              ' from ' ;
              v_Intenal_query:=v_Intenal_query|| /*decode(PI_Is_Recreate,
                                 0,
                                 v_Dest_Table || ' IP
           union all',
                                 ' ( ')*/ case when PI_Is_Recreate = 0 then v_Dest_Table || ' IP
           union all' else ' ( ' end || '
                   select  ' || pi_data_Fields ||
              '0 to_calculate,' || PI_Effective_Start || /*' , ' || PI_Effective_End || */
              ' ' ;
              v_Intenal_query:=v_Intenal_query||
              /*decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields)*/ case
                        when pi_key_fields is null then
                         ''
                        else
                         ' , ' || pi_key_Fields
                      end||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '/*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') */ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select /*+ cardinality('||v_temp_tab_count||')*/ 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP )' || /*decode(PI_Is_Recreate, 0, ' ', ' ) ')*/ case when PI_Is_Recreate = 0 then ' ' else ' ) ' end ||
              ' Temp
            left outer join tu_periods_range tupr_start
              on tupr_start.TUPR_ID = NVL(Temp.' ||
              PI_Effective_Start || ',-1)
            left outer join tu_periods_range tupr_end
              on tupr_end.TUPR_ID = NVL(Temp.' || PI_Effective_End ||
              ',-1)) T_Temp)
--select * from Table_Check_partial
,';

      /*select '

with Table_Check_partial as
 (select rownum as row_number,
         T_Temp.*,
         T_Temp.tupr_start_date start_given,
          decode(to_calculate,1,
         LEAD(T_Temp.tupr_start_date) OVER(partition by ' ||
              nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                         PI_COL_LIST   => pi_key_Fields),
                  ' NULL ') || ' order by T_Temp.tupr_start_date nulls first) ,0,T_Temp.tupr_start_date) end_calulated_partial

    from (

          select Temp.*,
                  tupr_start.TUPR_start_date TUPR_start_date,
                  tupr_end.tupr_end_date     tupr_end_date,
                  tupr_start.TUPR_id         TUPR_start_id,
                  tupr_end.tupr_id           tupr_end_id

            from (select ' || pi_data_Fields || 'to_calculate,' ||
              PI_Effective_Start ||
             \*' , ' || PI_Effective_End ||*\
              ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' || decode(PI_Is_Recreate,
                                 0,
                                 v_Dest_Table || ' IP
           union all',
                                 ' ( ') || '
                   select  ' || pi_data_Fields ||
              '0 to_calculate,' || PI_Effective_Start || \*' , ' || PI_Effective_End || *\
              ' ' ||
              decode(pi_key_Fields, null, null, ' , ' || pi_key_Fields) ||
              ' from ' ||

              case
                when pi_mode in (3) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE || ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
               ))'

                when pi_mode in (4) then
                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is null ))'

                when pi_mode in (2) then

                 '(select ' || case
                   when PI_INPUT_COUNT is not null then
                    '\*+  CARDINALITY(QI ' || PI_INPUT_COUNT || ') *\ '

                 end || '  * from ' || pi_QI_Table || ' QI where  exists
( select 1 from ' || PI_TEMP_TABLE ||
                 ' TEMP where TEMP.IP_ROW_IDENTIFIER=QI.row_identifier
              and TEMP.OP_ROW_IDENTIFIER is not null ))'
              end

              || ' OP )' || decode(PI_Is_Recreate, 0, ' ', ' ) ') ||
              ' Temp
            left outer join tu_periods_range tupr_start
              on tupr_start.TUPR_ID = Temp.' ||
              PI_Effective_Start || '
            left outer join tu_periods_range tupr_end
              on tupr_end.TUPR_ID = Temp.' || PI_Effective_End ||
              ') T_Temp)
--select * from Table_Check_partial
,'

        into v_Intenal_query
        from dual;*/

      v_Intenal_query := v_Intenal_query || '
Table_Check as
 (

  select T.*,
          (select tupr_end_date
             from tu_periods_range
            where tupr_id in (
             decode(to_calculate,1,
            decode(tupr_end_id,
                                     null,
                                     commons_timeunits.Get_nth_prior_period(' ||
                         PI_TU_ID || ',
                                                                            (select tupr_id
                                                                               from tu_periods_range
                                                                              where tupr_start_date =
                                                                                    end_calulated_partial
                                                                                and tupr_tu_id =' ||
                         PI_TU_ID || '

                                                                             ),
                                                                            1,
                                                                            2010,
                                                                            2025),
                                     tupr_end_id),tupr_end_id)

                                     )) end_calulated
    from Table_Check_partial T

  ),';

    end if;

    select v_Intenal_query || '

Overlap_check as
 ( select /*+ USE_HASH(a,b) */ ' || v_post_select || '
            from Table_Check a, Table_Check b
           where ' ||
            decode(v_JOIN_CONDITION, null, null, v_JOIN_CONDITION || ' and ') || '
              (a.row_number <> b.row_number and

                 (
                 nvl(a.start_given,
                      to_date(''1 / 1 / 1900 '', ''mm / dd / yyyy '')) <=
                 nvl(b.end_calulated,
                      to_date('' 12 / 31 / 9999 '', '' mm / dd / yyyy ''))
                      and
                 nvl(a.end_calulated,
                      to_date('' 12 / 31 / 9999 '', '' mm / dd / yyyy '')) >=
                 nvl(b.start_given,
                      to_date('' 1 / 1 / 1900 '', '' mm / dd / yyyy ''))
                      )


                      )

  )
select  ' || v_select_value || PI_OVERLAP_TABLE ||
            '_row_identifier_seq.nextval' || ' row_identifier,
                0 row_version,' || v_sql_temp ||
            ' from (
  select distinct ' || v_sql_temp || ' from Overlap_check) T '
      into v_Intenal_query
      from dual;

    v_Intenal_query := v_insert_part || v_Intenal_query;

    /* loop
        exit when l_offset > dbms_lob.getlength(v_Intenal_query);
        dbms_output.put_line(dbms_lob.substr(v_Intenal_query, 999, l_offset));
        l_offset := l_offset + 999;
      end loop;
      l_offset := 1;
    */
    --    DBMS_OUTPUT.PUT_LINE(v_OVERLAP_STR);

    --Sagar
    --INSERT_LOGS(PI_CLOB => 'v_Intenal_query '||v_Intenal_query);

    /* loop
        exit when l_offset > dbms_lob.getlength(v_Intenal_query);
      -- dbms_output.put_line( dbms_lob.substr( v_Intenal_query, 999, l_offset ) );
      l_offset := l_offset + 999;
    end loop;*/
    ----INSERT_LOGS(v_Intenal_query);
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.COMMON_OVERLAP_NP';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(v_Intenal_query),
                      'v_Intenal_query := <value>;',
                      v_stamp);
     /*commons_utils.INSERT_LOGS(PI_CLOB => 'v_Intenal_query ' || v_Intenal_query);*/
    --Logging changes end
    commons_ddl_handling.execute_ddl_nolog_rowcount(pi_ddl      => v_Intenal_query,
                                                    pi_to_trace => 1,
                                                    po_rowcount => v_count);
    -- EXECUTE IMMEDIATE v_Intenal_query
    /*INTO V_OVERLAP_RESULT;*/
    /* COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => PI_RUN_ID,
    pi_query_identifier => NULL,
    pi_bind_variables   => NULL);*/

    /*   v_Intenal_query := 'select count(*) from dual where exists (select 1 from ' ||
                       PI_OVERLAP_TABLE || ' where rownum=1 )';
    --INSERT_LOGS(PI_CLOB => 'v_Intenal_query ' || v_Intenal_query);
    EXECUTE IMMEDIATE v_Intenal_query
      INTO V_OVERLAP_RESULT;*/
    -- Overlap check
    if (PI_OVERLAP_TABLE is not null) then

      execute immediate '
  select nvl(max(' || v_av_col_name || '),0)  from ' ||
                        PI_OVERLAP_TABLE
        into v_AV_max_value;
      /* COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => v_ovr_tables_id,
      pi_value    => v_AV_max_value);  */

      commons_ddl_handling.execute_ddl_nolog('begin
 COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => ' ||
                                             v_ovr_tables_id || ',
                                    pi_value    => ' ||
                                             v_AV_max_value || ');

                                    end;');
    end if;

    IF v_count = 0 THEN
      po_OVERLAP_CHK_RES := 1;
      /*  commit;*/
    ELSE
      po_OVERLAP_CHK_RES := 0;

    END IF;

    /*    EXCEPTION
        WHEN OTHERS THEN
      IF cv_sql%ISOPEN THEN
         CLOSE cv_sql;
      END IF;
    raise;*/
    /*        raise_application_error(-20101,
    'COMMON_OVERLAP_CHECK encountered an error');*/
    /*EXCEPTION
        WHEN OTHERS THEN
          commons_utils.insert_logs(sqlerrm||dbms_utility.format_error_backtrace());*/
  end COMMON_OVERLAP_NP_POST;

  procedure Upsert_posting(pi_table                  VARCHAR2,
                           pi_dump                   VARCHAR2,
                           pi_join_clause            VARCHAR2,
                           PI_mode                   NUMBER,
                           pi_list_of_columns        IN TABLETYPE_CHARMAX,
                           pi_list_of_keys           IN TABLETYPE_CHARMAX,
                           pi_add_to_exist_columns   IN TABLETYPE_CHARMAX,
                           pi_id_column_name         VARCHAR2,
                           pi_version_column_name    VARCHAR2,
                           pi_seq_used_for_id        VARCHAR2,
                           pi_ent_intern_id_col_name VARCHAR2,
                           pi_ent_seq_name           VARCHAR2,
                           pi_av_col_name            VARCHAR2,
                           pi_av_generated_sw        number,
                           pi_process_id             varchar2,

                           /* pi_av_count               number,*/
                           pi_dump_buisness_index  varchar2,
                           pi_dump_primary_index   varchar2,
                           PI_TABLE_BUSINESSKEY_UI varchar2, --OF-21137
                           --moving close date parameters start
                           pi_is_close_end       number,
                           pi_key_Fields         IN VARCHAR2,
                           pi_Effective_Start    IN VARCHAR2,
                           pi_Effective_End      IN VARCHAR2,
                           pi_Is_Period          IN number,
                           pi_tu_id              IN number,
                           PI_DL_DEF_ID          IN NUMBER,
                           PI_RUN_ID             IN NUMBER DEFAULT NULL,
                           PO_closed_dates_Count out NUMBER,
                           --moving close date parameters end
                           /*   po_av_count     out number,*/

                           po_update_count out number,
                           po_insert_count out number,
                           po_status       out number,
                           PI_TABLES_ID    in number,

                           PI_TABLES_RECORD_DATING_OPTION IN NUMBER,
                           PI_UNMAPPED_BOOL               IN TABLETYPE_CHARMAX,
                           PI_SYNC_CLAUSE                 clob,
                           PI_ALL_KEYS                    boolean,
                           PI_ALL_UPDATE                  BOOLEAN,
                           PI_INPUT_COUNT                 IN NUMBER default null,
                           PI_OVERLAP_TABLE               in varchar2 default null,
                           PI_ADD_LOG_INFO                IN COLTYPE_KEY_VALUE default null) IS

    v_merge_count              number;
    v_before                   number := 0;
    v_post                     number := 0;
    v_insert_count             number;
    v_IP_col_list              clob;
    v_OP_col_list              CLOB;
    v_update_col_list          CLOB;
    v_col_list                 CLOB;
    v_id_column_value          CLOB;
    v_ent_intern_id_string     CLOB;
    v_ent_seq_string           CLOB;
    v_av_col_string            CLOB;
    v_av_value_string          CLOB;
    v_version_col_string       CLOB;
    v_av_update_sql            CLOB;
    v_version_value_ins_string CLOB;
    v_count_query              varchar2(1000);
    join_condition_for_merge   varchar2(1000);
    v_av_col_field_id          number;
    v_AV_max_value             number;
    v_Overlap_Chk_ResR         number;
    e_Data_table_missing exception;
    e_Dump_table_missing exception;
    V_SIZE_DATA               NUMBER;
    V_SIZE_DUMP               NUMBER;
    V_SIZE_DIFF               NUMBER;
    V_REBUILD                 number(1);
    V_BREAKPOINT_SIZE         NUMBER := 100;
    V_BREAKPOINT_SIMILAR_SIZE NUMBER := 45;
    V_BREAKPOINT_SIMILAR_DIFF NUMBER := 5;
    V_BREAKPOINT_DIFF_SMALL   NUMBER := 50;
    v_index                   number := 0;
    v_Primary_Key_enabled     number(1) := 0;
    l_offset                  number default 1;
    v_count                   number;
    v_index_created           number(1) := 0;
    v_index_status            number := 1;
    v_tables_id               number;
    v_merge_status            boolean := false;
    v_in_log_msg              clob;
    v_out_log_msg             clob;
    v_gtemp_table             varchar(30) := 'TTN_' || PI_DL_DEF_ID;
    v_gtemp_index             varchar(30) := 'TIN_' || PI_DL_DEF_ID;
    v_av_value                number;
    v_sql                     clob;
    v_out_tablespace          varchar2(30 char) := user || '_OUT';
    v_DTS_tablespace          varchar2(30 char) := user || '_DTS';   --- OF-72584
    v_IND_tablespace          varchar2(30 char) := user || '_IND';   --- OF-72584
    v_KEY_FIELDS              clob := '''' ||
                                      replace(pi_KEY_FIELDS, ',', ''',''') || '''';
     V_SQL_DROP_DUMP_TABLE     clob;
    /*   v_is_close_end    NUMBER;
    v_is_period       NUMBER;*/
    v_Overlap_Chk_Res         NUMBER;
    v_gtemp_count             NUMBER := 0;
    V_UPDATE_CANDIDATE_EXISTS NUMBER := 1; --OF-21137

    v_stamp         VARCHAR2(250);
    v_col_data_list clob;
    v_sql_hints     clob;
  begin
    --put our table spce to use
    FOR C IN (SELECT count(*) gtt_column_count
                FROM USER_TAB_COLUMNS
               WHERE TABLE_NAME = v_gtemp_table
                 AND COLUMN_NAME IN ('IP_ROW_IDENTIFIER',
                                     'OP_ROW_IDENTIFIER',
                                     'RECORD_UPDATED')) LOOP

      IF C.gtt_column_count = 0 THEN

        v_sql := '
          CREATE   TABLE ' || v_gtemp_table || '
          (
            IP_ROW_IDENTIFIER         NUMBER,
            OP_ROW_IDENTIFIER         NUMBER,
            RECORD_UPDATED            NUMBER(1)
          ) TABLESPACE ' || v_DTS_tablespace;   --- OF-72584

        ------INSERT_LOGS(v_sql); --dbms_output.put_line(v_sql);
        --Logging changes start

        v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(v_sql),
                          'v_sql := <value>;',
                          v_stamp);

        --Logging changes end

        commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);

      ELSIF C.gtt_column_count = 2 THEN
        v_sql := 'ALTER TABLE ' || v_gtemp_table ||
                 ' ADD RECORD_UPDATED NUMBER(1)';

        --Logging changes start

        v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(v_sql),
                          'v_sql := <value>;',
                          v_stamp);

        --Logging changes end
        commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);
      END IF;
    END LOOP;

    /* FOR C IN (
     select 1 from dual where  exists(
     SELECT * FROM USER_indexes
      WHERE TABLE_NAME = v_gtemp_table
      and index_name=v_gtemp_index)) LOOP
    execute immediate 'drop index '||v_gtemp_index;*/

    /*  execute immediate'
    CREATE UNIQUE INDEX  '||v_gtemp_index||'
    ON '||v_gtemp_table||' (IP_ROW_IDENTIFIER,
     OP_ROW_IDENTIFIER, 1)
     TABLESPACE '||USER||'_OUT'; */
    /* ---------------------------------------------------------------------------------------------- */
    /* determine what records will be updated                                                         */
    /* ---------------------------------------------------------------------------------------------- */

    /*   commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'truncate TABLE ' ||
                                                       v_gtemp_table);   --shifting it down after drop index.
    */

    --18-nov-2014 start OF-23315
    FOR I IN (SELECT *
                FROM USER_INDEXES U
               WHERE UPPER(U.INDEX_NAME) = UPPER(v_gtemp_index)) LOOP
      v_sql := 'DROP INDEX ' || v_gtemp_index;
      commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);
    END LOOP;

    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'truncate TABLE ' ||
                                                     v_gtemp_table);
    --18-nov-2014 end

    if (PI_TABLES_RECORD_DATING_OPTION not in (4, 5)) then

      IF (pi_av_generated_sw = 0) THEN
        --OF-21137
        v_sql_hints:=REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                          pi_hint_id   => 'PI_DUMP_BUSINESS_IND',
                                                          pi_proc_id   => PI_DL_DEF_ID),
                             'pi_dump_buisness_index', pi_dump_buisness_index);

        IF PI_INPUT_COUNT IS NOT NULL THEN
           v_sql_hints:= REPLACE(REPLACE(v_sql_hints, '/*+', ''), '*/', '');
           v_sql_hints:= REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id   => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                              pi_hint_id     => 'CARDINALITY_ON_DMP_UPDT_CHK',
                                                              pi_proc_id     => PI_DL_DEF_ID,
                                                              pi_other_hints => v_sql_hints),
                                 'PI_INPUT_COUNT', PI_INPUT_COUNT);
        END IF;

        execute immediate 'SELECT COUNT(1) FROM DUAL WHERE EXISTS (select ' ||
                          CHR(10) ||
                          COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                    pi_hint_id   => 'PI_TABLE_BUSINESS_IND',
                                                                    pi_proc_id   => PI_DL_DEF_ID) ||
                          CHR(10) ||

                          REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                               pi_hint_id   => 'PI_TABLE_BUSINESS_IND',
                                                               pi_proc_id   => PI_DL_DEF_ID),
                                  'PI_TABLE_BUSINESSKEY_UI',
                                  PI_TABLE_BUSINESSKEY_UI) || CHR(10) ||
                          ' 1 from ' || pi_table || ' op where exists (select ' ||
                          CHR(10) ||
                          COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                    pi_hint_id   => 'PI_DUMP_BUSINESS_IND',
                                                                    pi_proc_id   => PI_DL_DEF_ID) ||
                          CHR(10) ||
                          CASE WHEN PI_INPUT_COUNT IS NOT NULL
                               THEN COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                              pi_hint_id   => 'CARDINALITY_ON_DMP_UPDT_CHK',
                                                                              pi_proc_id   => PI_DL_DEF_ID)
                               ELSE ''
                          END ||
                          CHR(10) ||
                          v_sql_hints ||
                          CHR(10) ||
                          ' 1 from ' || pi_dump || ' ip where ' ||
                          pi_join_clause || '))'
          into V_UPDATE_CANDIDATE_EXISTS;
        ---addition for save execution plan
        COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => PI_RUN_ID,
                                          pi_query_identifier => NULL,
                                          pi_bind_variables   => NULL);
      END IF;
    end if; --OF-21137

    if (pi_av_generated_sw = 0 AND V_UPDATE_CANDIDATE_EXISTS = 1) then
      --OF-21137
      --change for hint framework start
      /*v_sql := 'INSERT \*+ APPEND *\ INTO ' || v_gtemp_table || */

      v_sql_hints:= REPLACE(REPLACE(REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                         pi_hint_id   => 'SEL_DMP1',
                                                                         pi_proc_id   => PI_DL_DEF_ID),
                                            'pi_dump_buisness_index', pi_dump_buisness_index),
                                            'pi_dump_primary_index',  pi_dump_primary_index),
                                            'pi_table', pi_table);

      IF PI_INPUT_COUNT IS NOT NULL THEN
         v_sql_hints:= REPLACE(REPLACE(v_sql_hints, '/*+', ''), '*/', '');
         v_sql_hints:= REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id   => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                            pi_hint_id     => 'CARDINALITY_ON_DUMP_INSRT_GTT',
                                                            pi_proc_id     => PI_DL_DEF_ID,
                                                            pi_other_hints => v_sql_hints),
                               'PI_INPUT_COUNT', PI_INPUT_COUNT);
      END IF;

      v_sql := 'INSERT ' || CHR(10) ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id   => 'INS_GTT1',
                                                         pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||

               COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                            pi_hint_id   => 'INS_GTT1',
                                            pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||

               ' INTO ' || v_gtemp_table ||
              --change for hint framework end
               '(IP_ROW_IDENTIFIER, OP_ROW_IDENTIFIER' || CASE
                 WHEN (PI_ALL_KEYS = FALSE AND PI_ALL_UPDATE = FALSE and
                      PI_mode <> 4) THEN
                  ',RECORD_UPDATED'
               END || '

               )
SELECT IP_ROW_IDENTIFIER, OP_ROW_IDENTIFIER
' ||

               CASE
                 WHEN (PI_ALL_KEYS = FALSE AND PI_ALL_UPDATE = FALSE and
                      PI_mode <> 4) THEN
                  ',RECORD_UPDATED '
               END || '
FROM (

SELECT ' ||
              --change for hint framework start
              /*+ QB_NAME("DL#pi_table#pop#gtt")
                  CARDINALITY(IP PI_INPUT_COUNT)
                  INDEX_JOIN (IP pi_dump_business_index  pi_dump_primary_index)
                  INDEX_JOIN (OP pi_table_BUSINESSKEY_UI PK_pi_table)
               */
               CHR(10) ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id   => 'SEL_DMP1',
                                                         pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||
               CASE WHEN PI_INPUT_COUNT IS NOT NULL
                    THEN COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                   pi_hint_id   => 'CARDINALITY_ON_DUMP_INSRT_GTT',
                                                                   pi_proc_id   => PI_DL_DEF_ID)
                    ELSE ''
               END ||
               CHR(10) ||
               v_sql_hints ||
               CHR(10) ||
               --change for hint framework end
               ' IP.ROW_IDENTIFIER IP_ROW_IDENTIFIER, OP.ROW_IDENTIFIER OP_ROW_IDENTIFIER ' ||

               CASE
                 WHEN (PI_ALL_KEYS = FALSE AND PI_ALL_UPDATE = FALSE and
                      PI_mode <> 4) THEN
                  ',CASE WHEN (OP.ROW_IDENTIFIER is not null and ' ||
                  PI_SYNC_CLAUSE || ')  THEN 0
                  ELSE 1
             END AS RECORD_UPDATED '

               END || '
FROM ' || pi_dump || ' IP
LEFT OUTER JOIN ' || pi_table || ' OP ON (' || pi_join_clause || ')
 )INOUT
' ||

               CASE
                 WHEN (PI_ALL_KEYS = FALSE AND PI_ALL_UPDATE = FALSE and
                      PI_mode <> 4) THEN
                  ' where RECORD_UPDATED=1 '
               END;

      v_sql := v_sql;
      -- dbms_output.put_line(v_sql);
      --dbms_stats.gather_index_stats(user, v_gtemp_index);
      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_sql),
                        'v_sql := <value>;',
                        v_stamp);

      --Logging changes end

      --INSERT_LOGS(v_sql); --dbms_output.put_line(v_sql);
      /*commons_utils.INSERT_LOGS(v_sql);*/
      --commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);
      commons_ddl_handling.execute_ddl_nolog_rowcount(pi_ddl      => v_sql,
                                                      pi_to_trace => 1,
                                                      po_rowcount => v_gtemp_count);

    end if;

    --18-nov-2014 start OF-23315
    v_sql := '
    CREATE UNIQUE INDEX  ' || v_gtemp_index || '
    ON ' || v_gtemp_table ||
             ' (IP_ROW_IDENTIFIER, OP_ROW_IDENTIFIER,RECORD_UPDATED) TABLESPACE ' ||
             v_IND_tablespace;      --- OF-72584
    ------INSERT_LOGS(v_sql); --dbms_output.put_line(v_sql);
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(v_sql),
                      'v_sql := <value>;',
                      v_stamp);

    --Logging changes end
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);
    --18-nov-2014 end
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME       => user,
                                  TABNAME       => v_gtemp_table);
    --add hints in the queries
    /*if (PI_TABLES_RECORD_DATING_OPTION in (4, 5)) then
    \*      v_is_period    := case
                              when PI_TABLES_RECORD_DATING_OPTION = 4 then
                               0
                              else
                               1
                            end;
          v_is_close_end := 1;*\
          --OVERLAP

          ------INSERT_LOGS(pi_table);
          ------INSERT_LOGS(pi_key_Fields);

          COMMON_OVERLAP_NP(pi_Dest_Table      => pi_table,
                            pi_QI_Table        => pi_dump,
                            pi_key_Fields      => pi_key_Fields,
                            PI_Effective_Start => PI_Effective_Start,
                            PI_Effective_End   => PI_Effective_End,
                            PI_Is_Period       => PI_is_period,
                            PI_TU_ID           => PI_TU_ID,
                            PI_Is_Recreate     => 0,
                            PI_TEMP_TABLE      => v_gtemp_table,
                            PI_TEMP_COL        => 'OP_ROW_IDENTIFIER',
                            PI_MODE            => pi_mode,
                            po_Overlap_Chk_Res => v_Overlap_Chk_Res,
                PI_INPUT_COUNT        =>PI_INPUT_COUNT,
                PI_RUN_ID        => PI_RUN_ID
               );

          if v_Overlap_Chk_Res = 0 then

            raise_application_error(-20006, 'Overlap check failed');
          end if;
        end if;*/

    ----remove table check

    for c in (select column_value column_name from table(pi_list_of_columns)) loop
      v_IP_col_list := v_IP_col_list || 'IP.' || c.column_name || ',';
      v_col_list    := v_col_list || c.column_name || ',';

    end loop;

    for c in (select column_value column_name
                from table(pi_list_of_columns)
              minus
              select column_value column_name
                from table(pi_list_of_keys)) loop

      v_update_col_list := v_update_col_list || 'OP.' || c.column_name ||
                           '=IP.' || c.column_name || ',';
      v_col_data_list   := v_col_data_list || c.column_name || ',';
    end loop;
    --boolean column , unmapped
    for c in (select column_value column_name from table(PI_UNMAPPED_BOOL)) loop
      /* v_IP_col_list := v_IP_col_list || '0' || ',';*/
      v_IP_col_list := v_IP_col_list || '0 ' || c.column_name || ',';
      v_col_list    := v_col_list || c.column_name || ',';
      /* v_update_col_list := v_update_col_list || 'OP.' || c.column_name || '=0'|| ',';*/
    end loop;

    for c in (select column_value column_name
                from table(pi_add_to_exist_columns)) loop
      -- dbms_output.put_line(c.column_name);
      v_IP_col_list     := v_IP_col_list || 'IP.' || c.column_name || ',';
      v_col_list        := v_col_list || c.column_name || ',';
      v_update_col_list := v_update_col_list || 'OP.' || c.column_name || '=' ||
                           'cast(' || ' decode(coalesce(IP.' ||
                           c.column_name || ', OP.' || c.column_name ||
                           ' ),null, null,' || '(nvl(OP.' || c.column_name ||
                           ',0) + nvl(IP.' || c.column_name || ',0))' || ')' ||

                           ' as NUMBER(23,10)),';
      v_col_data_list   := v_col_data_list || c.column_name || ',';
    end loop;
    --#######################
    --autonumber handling
    --#######################
    --add autonumber column if its is not generated by software
    if (pi_av_col_name is not null) then

      v_col_list := v_col_list || pi_av_col_name || ',';

      --  nvl2(pi_av_col_name, ',OP.' || pi_av_col_name, ''),-- v_av_col_string,
      if (pi_av_generated_sw = 0) then
        v_update_col_list := v_update_col_list || 'OP.' || pi_av_col_name ||
                             '=IP.' || pi_av_col_name || ',';

        v_IP_col_list := v_IP_col_list || 'IP.' || pi_av_col_name || ',';

      elsif (pi_av_generated_sw = 1) then
        v_AV_max_value := COMMONS_TABLES.GET_AUTO_VALUE(PI_TABLES_ID);
        v_IP_col_list  := v_IP_col_list || '(' || to_char(v_AV_max_value) ||
                          '+rownum-1)' || ',';

      end if;
    end if;

    --#######################
    --E_internal Id col_namehandling
    --#######################
    if (pi_ent_intern_id_col_name is not null) then
      /* v_update_col_list := v_update_col_list || 'OP.' ||
      pi_ent_intern_id_col_name || '=OP.' ||
      pi_ent_intern_id_col_name || '+1'|| ',';*/
      v_col_list    := v_col_list || pi_ent_intern_id_col_name || ',';
      v_OP_col_list := v_OP_col_list || pi_ent_seq_name || '.NEXTVAL' || ',';
    end if;
    --#######################
    --row identifier handling
    --#######################
    v_col_list    := v_col_list || pi_id_column_name || ',';
    v_OP_col_list := v_OP_col_list || pi_seq_used_for_id || '.NEXTVAL ' ||
                     pi_id_column_name || ',';
    --#######################
    --row version handling
    --#######################
    v_update_col_list := v_update_col_list || 'OP.' ||
                         pi_version_column_name || '=OP.' ||
                         pi_version_column_name || '+1';
    v_col_list        := v_col_list || pi_version_column_name;
    v_OP_col_list     := v_OP_col_list || '0 ' || pi_version_column_name;

    if (PI_TABLES_RECORD_DATING_OPTION in (4, 5)) then
      /*      v_is_period    := case
                          when PI_TABLES_RECORD_DATING_OPTION = 4 then
                           0
                          else
                           1
                        end;
      v_is_close_end := 1;*/
      --OVERLAP

      ------INSERT_LOGS(pi_table);
      ------INSERT_LOGS(pi_key_Fields);

      if (PI_OVERLAP_TABLE is null) then
        /*   commons_utils.INSERT_LOGS('non call');*/
        COMMON_OVERLAP_NP(pi_Dest_Table      => pi_table,
                          pi_QI_Table        => pi_dump,
                          pi_key_Fields      => pi_key_Fields,
                          PI_Effective_Start => PI_Effective_Start,
                          PI_Effective_End   => PI_Effective_End,
                          PI_Is_Period       => PI_is_period,
                          PI_TU_ID           => PI_TU_ID,
                          PI_Is_Recreate     => 0,
                          PI_TEMP_TABLE      => v_gtemp_table,
                          PI_TEMP_COL        => 'OP_ROW_IDENTIFIER',
                          PI_MODE            => pi_mode,
                          po_Overlap_Chk_Res => v_Overlap_Chk_Res,
                          PI_INPUT_COUNT     => PI_INPUT_COUNT,
                          PI_RUN_ID          => PI_RUN_ID);

      elsif (PI_OVERLAP_TABLE is not null) then
        /* commons_utils.INSERT_LOGS('actual call');*/
        COMMON_OVERLAP_NP_POST(pi_Dest_Table      => pi_table,
                               pi_QI_Table        => pi_dump,
                               pi_key_Fields      => pi_key_Fields,
                               pi_data_Fields     => v_col_data_list,
                               PI_Effective_Start => PI_Effective_Start,
                               PI_Effective_End   => PI_Effective_End,
                               PI_Is_Period       => PI_is_period,
                               PI_TU_ID           => PI_TU_ID,
                               PI_Is_Recreate     => 0,
                               PI_TEMP_TABLE      => v_gtemp_table,
                               PI_TEMP_COL        => 'OP_ROW_IDENTIFIER',
                               PI_MODE            => pi_mode,
                               po_Overlap_Chk_Res => v_Overlap_Chk_Res,
                               PI_INPUT_COUNT     => PI_INPUT_COUNT,
                               PI_RUN_ID          => PI_RUN_ID,
                               PI_OVERLAP_TABLE   => PI_OVERLAP_TABLE,
                               PI_ADD_LOG_INFO    => PI_ADD_LOG_INFO);

      end if;

      if v_Overlap_Chk_Res = 0 then
        -- deshmukha added the code to drop dist table created in DUMP_TABLE_SEGREGATION
        if upper(substr(pi_dump, 1, 5)) = 'DIST_' then
          for c in (select 1 from user_tables where table_name = pi_dump) loop
            V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || pi_dump;
            COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
          END LOOP;
        end if;
        raise_application_error(-20006, 'Overlap check failed');
      end if;
    end if;

    /* ---------------------------------------------------------------------------------------------- */
    /* update matched records                                                                         */
    /* ---------------------------------------------------------------------------------------------- */
    ---kept here for now need to push this to java
    /*execute immediate '
    select '||
     --change for hint framework start
    \*+ INDEX(OP PK_' || pi_table || ')  *\
      CHR(10)||
      COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING'
                                               ,pi_hint_id   => 'SEL_INPUT_TABLE1'
                                               ,pi_proc_id   => PI_DL_DEF_ID) ||CHR(10)||

      REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id    => 'DATAMANAGEMENT_UPSERT_POSTING'
                                   ,pi_hint_id     => 'SEL_INPUT_TABLE1'
                                   ,pi_proc_id     => PI_DL_DEF_ID),'pi_table',pi_table)||CHR(10)||

     --change for hint framework end
     ' count(' || pi_id_column_name || ') from ' ||
                        pi_table || ' OP'
        into v_before;

      --Logging changes start

        v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,ANYDATA.CONVERTCLOB(TO_CLOB(v_before)),'v_before := <value>;', v_stamp);

      --Logging changes end

      v_before := case
                    when v_before = 0 then
                     1
                    else
                     v_before
                  end;*/

    if (PI_mode in (2, 3) and PI_ALL_KEYS = FALSE AND
       V_UPDATE_CANDIDATE_EXISTS = 1) then
      --OF-21137
      ------update the columns
      --APPEND

      v_sql_hints:= REPLACE(REPLACE(REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                         pi_hint_id   => 'SEL_GTT_DUMP1',
                                                                         pi_proc_id   => PI_DL_DEF_ID),
                                            'v_gtemp_index', v_gtemp_index),
                                            'pi_dump_primary_index', pi_dump_primary_index),
                                            'pi_table', pi_table);

      v_sql_hints:= REPLACE(REPLACE(v_sql_hints, '/*+', ''), '*/', '');
      v_sql_hints:= REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id   => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id     => 'CARDINALITY_ON_GTT_MRGE_DEST',
                                                         pi_proc_id     => PI_DL_DEF_ID,
                                                         pi_other_hints => v_sql_hints),
                            'v_gtemp_count', v_gtemp_count);

      IF PI_INPUT_COUNT IS NOT NULL THEN
         v_sql_hints:= REPLACE(REPLACE(v_sql_hints, '/*+', ''), '*/', '');
         v_sql_hints:= REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                            pi_hint_id   => 'CARDINALITY_ON_DMP_MRGE_DEST',
                                                            pi_proc_id   => PI_DL_DEF_ID,
                                                            pi_other_hints => v_sql_hints ),
                               'PI_INPUT_COUNT', PI_INPUT_COUNT);
 	    END IF;

      v_sql := 'MERGE ' ||
              --change for hint framework start
              /*+ QB_NAME("DL#pi_table#Upd#Table") INDEX(OP PK_pi_table) NO_USE_HASH(IP OP) */
               CHR(10) ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id   => 'MER_INPUT_TABLE1',
                                                         pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||

               REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                    pi_hint_id   => 'MER_INPUT_TABLE1',
                                                    pi_proc_id   => PI_DL_DEF_ID),
                       'pi_table',
                       pi_table) || CHR(10) ||
              --change for hint framework END
               ' INTO ' || pi_table || ' OP
USING (
          SELECT ' ||
              --change for hint framework start
              /*+
                 QB_NAME("DL#pi_table#Upd#inside")
                 CARDINALITY(IP PI_INPUT_COUNT)
                 INDEX (IP2 v_gtemp_index)
                 INDEX (IP pi_dump_primary_index)
                 NO_USE_HASH(IP IP2)
               */
              --cardinality hint to be added.
               CHR(10) ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id   => 'SEL_GTT_DUMP1',
                                                         pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id   => 'CARDINALITY_ON_GTT_MRGE_DEST',
                                                         pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||
               CASE WHEN PI_INPUT_COUNT IS NOT NULL
                    THEN COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                   pi_hint_id   => 'CARDINALITY_ON_DMP_MRGE_DEST',
                                                                   pi_proc_id   => PI_DL_DEF_ID)
                    ELSE ''
               END ||
               CHR(10) ||
               v_sql_hints ||
               CHR(10) ||
              --change for hint framework end
               ' ' || v_IP_col_list || 'IP2.OP_ROW_IDENTIFIER
          FROM ' || v_gtemp_table || ' IP2
          INNER JOIN ' || pi_dump || ' IP ON  IP2.IP_ROW_IDENTIFIER = IP.ROW_IDENTIFIER
          WHERE IP2.OP_ROW_IDENTIFIER IS NOT NULL
          ' ||

               CASE
                 WHEN (PI_ALL_UPDATE = FALSE) THEN
                  'AND RECORD_UPDATED = 1 '
               END || '


          )   IP
      ON (IP.OP_ROW_IDENTIFIER = OP.ROW_IDENTIFIER)
WHEN MATCHED THEN
  UPDATE
     SET ' || v_update_col_list;
      --APPEND

      -- INSERT_LOGS(v_sql);
      -- dbms_output.put_line(v_sql);

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_sql),
                        'v_sql := <value>;',
                        v_stamp);

      --Logging changes end

      --INSERT_LOGS(v_sql);
      /*commons_utils.INSERT_LOGS(v_sql);*/
      execute immediate v_sql;
      po_update_count := sql%rowcount;
      ---addition for save execution plan
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => PI_RUN_ID,
                                        pi_query_identifier => NULL,
                                        pi_bind_variables   => NULL);
      v_post := v_post + nvl(po_update_count, 0);
    end if;
    --in case exception hence forth we might have commited partial data to the table
    /*COMMIT;*/
    /* ---------------------------------------------------------------------------------------------- */
    /* insert new records                                                                             */
    /* ---------------------------------------------------------------------------------------------- */
    if (PI_mode in (4, 3)) then
      v_sql_hints:= REPLACE(REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                 pi_hint_id   => 'SEL_DUMP2',
                                                                 pi_proc_id   => PI_DL_DEF_ID),
                                   'v_gtemp_index', v_gtemp_index),
                                   'pi_table', pi_table);
      IF pi_av_generated_sw = 0 and V_UPDATE_CANDIDATE_EXISTS = 1 THEN
         v_sql_hints:= REPLACE(REPLACE(v_sql_hints, '/*+', ''), '*/', '');
         v_sql_hints:= REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id   => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                            pi_hint_id     => 'CARDINALITY_HNT_GTT_INST_DEST',
                                                            pi_proc_id     => PI_DL_DEF_ID,
                                                            pi_other_hints => v_sql_hints),
                               'v_gtemp_count', v_gtemp_count);
      END IF;

      IF PI_INPUT_COUNT IS NOT NULL THEN
         v_sql_hints:= REPLACE(REPLACE(v_sql_hints, '/*+', ''), '*/', '');
         v_sql_hints:= REPLACE(COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                            pi_hint_id   => 'CARDINALITY_ON_DMP_INST_DEST',
                                                            pi_proc_id   => PI_DL_DEF_ID,
                                                            pi_other_hints => v_sql_hints),
                               'PI_INPUT_COUNT', PI_INPUT_COUNT);
      END IF;

      v_sql := 'INSERT ' || CASE
                 WHEN PI_is_close_end = 1 THEN
                  ' '
                 ELSE
                 --change for hint framework start
                 /* '\*+ APPEND *\'*/

                  CHR(10) ||
                  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                            pi_hint_id   => 'INS_INPUT_TABLE1',
                                                            pi_proc_id   => PI_DL_DEF_ID) ||
                  CHR(10) ||

                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                               pi_hint_id   => 'INS_INPUT_TABLE1',
                                               pi_proc_id   => PI_DL_DEF_ID) ||
                  CHR(10)

               --change for hint framework end
               END || '
       INTO ' || pi_table || '(' || v_col_list || ')
SELECT ' ||
              --change for hint framework start
              /*+ QB_NAME("DL#pi_table#Append#Table#") CARDINALITY(IP PI_INPUT_COUNT) INDEX (OP v_gtemp_index) */
              --cardinality hint to be added
               CHR(10) ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                         pi_hint_id   => 'SEL_DUMP2',
                                                         pi_proc_id   => PI_DL_DEF_ID) ||
               CHR(10) ||
               CASE WHEN pi_av_generated_sw = 0 and V_UPDATE_CANDIDATE_EXISTS = 1
                    THEN COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                   pi_hint_id   => 'CARDINALITY_HNT_GTT_INST_DEST',
                                                                   pi_proc_id   => PI_DL_DEF_ID)
                    ELSE ''
               END ||
               CHR(10) ||
               CASE WHEN PI_INPUT_COUNT IS NOT NULL
                    THEN COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'DATAMANAGEMENT_UPSERT_POSTING',
                                                                   pi_hint_id   => 'CARDINALITY_ON_DMP_INST_DEST',
                                                                   pi_proc_id   => PI_DL_DEF_ID)
                    ELSE ''
               END ||
               CHR(10) ||
               v_sql_hints ||
               CHR(10) ||
              --change for hint framework end
               ' ' || v_IP_col_list || v_OP_col_list || '
FROM ' || pi_dump || ' IP ' || case
                 when (pi_av_generated_sw = 0 AND V_UPDATE_CANDIDATE_EXISTS = 1) then --OF-21137
                  'INNER JOIN ' || v_gtemp_table ||
                  ' OP ON OP.IP_ROW_IDENTIFIER = IP.ROW_IDENTIFIER
 WHERE OP.OP_ROW_IDENTIFIER IS NULL'
               end;
      -- INSERT_LOGS(v_sql);
      -- dbms_output.put_line(v_sql);

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_sql),
                        'v_sql := <value>;',
                        v_stamp);

      --Logging changes end

      --INSERT_LOGS(v_sql);
      /*commons_utils.INSERT_LOGS(v_sql);*/
      execute immediate v_sql;
      po_insert_count := sql%rowcount;
      ---addition for save execution plan
      COMMONS_PROCESSING.SAVE_EXEC_PLAN(pi_run_id           => PI_RUN_ID,
                                        pi_query_identifier => NULL,
                                        pi_bind_variables   => NULL);
      v_post := v_post + nvl(po_insert_count, 0);
    end if;
    ---check
    if (pi_av_col_name is not null) then

      if (pi_av_generated_sw = 1) then

        v_av_value := v_AV_max_value + po_insert_count - 1;

      else
        commit;
        execute immediate '
  select max(' || pi_av_col_name || ')  from ' ||
                          pi_table
          into v_av_value;

        --Logging changes start

        v_stamp := 'COMMONS_DATALOADPROCESSING.Upsert_posting';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(TO_CLOB(v_av_value)),
                          'v_av_value := <value>;',
                          v_stamp);

        --Logging changes end

      end if;

      COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => PI_TABLES_ID,
                                    pi_value    => v_av_value);

    end if;

    IF (pi_is_close_end = 1) THEN
      commons_tables.COMMON_CLOSING_END(pi_Table           => pi_table,
                                        pi_key_Fields      => pi_key_Fields,
                                        PI_Effective_Start => PI_Effective_Start,
                                        PI_Effective_End   => PI_Effective_End,
                                        PI_Is_Period       => pi_is_period,
                                        PI_TU_ID           => PI_TU_ID,
                                        /*   PI_Commit          =>PI_Commit,*/
                                        PO_Count => PO_closed_dates_Count);
    END IF;

    --clean up
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'truncate TABLE ' ||
                                                     v_gtemp_table);
    /* execute immediate 'truncate TABLE ' || v_gtemp_table;*/
    /*COMMIT;*/
    --dbms_output.put_line(v_post);
    -- dbms_output.put_line(v_before);
    --dbms_output.put_line(v_post / v_before);

    /*  IF (v_post / v_before > 0.1) THEN
      commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => pi_table,
                                               PI_MODE  => 2);
      \*commons_utils.GET_TABLE_SIZE(v_data_table, V_SIZE_DATA);*\
    END IF;*/
    ----

    po_update_count := nvl(po_update_count, 0);
    po_insert_count := nvl(po_insert_count, 0);

  exception

    when others then
      --clean up
      commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'truncate TABLE ' ||
                                                       v_gtemp_table);
      raise;
  end Upsert_posting;

  PROCEDURE ValidationAndPosting(PI_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                                 PI_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                                 PI_AV_GENERATED_BY_SW     IN NUMBER, --auto-value
                                 PI_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                                 PI_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                                 PI_AGGREGATION_ORDER      IN VARCHAR2,
                                 PI_FLT_JOIN_CONDITIONS    IN VARCHAR2,
                                 PI_FLT_WHERE_CONDITIONS   IN VARCHAR2,
                                 PI_ID_COLUMN_NAME         IN VARCHAR2,
                                 PI_SEQ_USED_FOR_ID        IN VARCHAR2,
                                 PI_VERSION_COLUMN_NAME    IN VARCHAR2,
                                 PI_ENT_INTERN_ID_COL_NAME IN VARCHAR2,
                                 pi_ent_seq_name           IN VARCHAR2,
                                 PI_AV_COL_NAME            IN VARCHAR2,
                                 /*   PO_ROW_ID_MAX_VALUE       OUT NUMBER,*/ ---in crete to be handled in teh dump table removing now
                                 /*    PO_AV_COUNT               OUT NUMBER,*/ ---to be set by sp hence removing

                                 pi_process_id     IN varchar2,
                                 PI_MODE           IN VARCHAR2, --1 insert, 2 update
                                 PI_DEST_TABLE     IN VARCHAR2,
                                 PI_DEST_TABLES_ID IN NUMBER,
                                 /* PI_INPUT_SIZE IN VARCHAR2,*/ --requireed in future , commented for now
                                 PI_Effective_Start IN VARCHAR2, --DON'T PASS IN KEY
                                 PI_Effective_End   IN VARCHAR2,
                                 /*   PI_Is_Period       IN number, --CAN BE CACULATED AS WELL*/
                                 PI_TU_ID                       IN NUMBER,
                                 PI_TABLES_RECORD_DATING_OPTION IN NUMBER,
                                 PI_DL_DEF_ID                   IN NUMBER,
                                 PI_INPUT_COUNT                 IN NUMBER DEFAULT NULL,
                                 PI_SOURCE_FILE_COUNT           IN NUMBER DEFAULT 1,
                                 PI_RUN_ID                      IN NUMBER DEFAULT NULL,
                                 po_update_count                OUT NUMBER,
                                 po_insert_count                OUT NUMBER,
                                 PO_closed_dates_Count          OUT NUMBER,
                                 PO_FILTER_COUNT                OUT NUMBER, --WILL RETURN COUNT OF FILTERED ROWS.
                                 po_status                      OUT NUMBER,
                                 po_QI_TABLE                    OUT VARCHAR2,
                                 po_SHRINK_flag                 OUT NUMBER,
                                 PIO_DUPLICATE_TABLE            IN VARCHAR2,
                                 PI_OVERLAP_TABLE               in varchar2 default null,
                                 PI_ADD_LOG_INFO                IN COLTYPE_KEY_VALUE default null,
                                 PI_SEQ_RESET_FLAG              in number default 1) IS

    V_SQL                    CLOB;
    V_SELECT_ADD_TO_EXISTING CLOB;
    V_OUTER_KEY              CLOB;
    V_SUBQUERY_SQL           CLOB;
    V_SELECT_CLAUSE          CLOB;
    V_CREATE_DATA_COL_LIST   CLOB;
    V_CREATE_KEY_COL_LIST    CLOB;
    V_GROUP_BY_CLAUSE        CLOB;
    V_AGGREGATION_CLAUSE     CLOB;
    V_DEFAULT_CLAUSE         CLOB;
    V_DEFAULT_SELECT         CLOB;
    V_INTRANS_VALUE          NUMBER;
    V_AV_QUERY               VARCHAR2(300);
    V_ID_SEQ_VALUE           NUMBER;
    L_OFFSET                 NUMBER DEFAULT 1;
    V_SQL_DROP_DUMP_TABLE    CLOB;
    V_DATA_COLUMNS           CLOB;
    V_DUMP_TABLE             VARCHAR2(50);
    V_COL_LIST               TABLETYPE_CHARMAX := TABLETYPE_CHARMAX();
    V_KEY_LIST               TABLETYPE_CHARMAX := TABLETYPE_CHARMAX();
    V_ADD_TO_EXISTING        TABLETYPE_CHARMAX := TABLETYPE_CHARMAX();
    V_UNMAPPED_BOOL          TABLETYPE_CHARMAX := TABLETYPE_CHARMAX();
    V_JOIN_CLAUSE            CLOB;
    V_OVERLAP_CLAUSE         CLOB;
    V_UNIQUE_CLAUSE          CLOB;
    v_business_key_ddl       CLOB;
    v_is_period              number;
    v_business_index_name    varchar2(30 char) := PI_DEST_TABLE ||
                                                  '_BUSINESSKEY_UI';
    v_primary_index_name     varchar2(30 char) := 'PK_' || PI_DEST_TABLE;
    v_dp_business_index_name varchar2(30 char) := Upper(SUBSTR(PI_DUMP_TABLE,
                                                               0,
                                                               25)) ||
                                                  '_DPBK';
    v_dp_primary_index_name  varchar2(30 char) := Upper(SUBSTR(PI_DUMP_TABLE,
                                                               0,
                                                               25)) ||
                                                  '_DPPK';

    V_SYNC_CLAUSE CLOB;

    E_DUPL_KEY EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_DUPL_KEY, -01452);
    v_is_close_end    number := 0;
    v_add_count       number := 0;
    v_col_count       number := 0;
    v_bool_count      number := 0;
    v_key_col_count   number := 0;
    v_Overlap_Chk_Res number(1);
    v_av_count        number;
    v_index_failed    boolean := false;
    v_unique_Chk_Res  number;
    v_out_tablespace  varchar2(30 char) := user || '_OUT';
    v_dts_tablespace  varchar2(30 char) := user || '_DTS';
    v_ind_tablespace  varchar2(30 char) := user || '_IND';
    v_tablespace      varchar2(30 char);
    v_tablespace_ind  varchar2(30 char);
    V_ALL_KEYS        BOOLEAN := TRUE;
    V_ALL_UPDATE      BOOLEAN := FALSE;
    v_filter_table    varchar2(30 char) := upper('DMPFLT_' ||
                                                 substr(PI_DUMP_TABLE,
                                                        -least(length(PI_DUMP_TABLE),
                                                               23)));
    --cardinality
    V_INPUT_COUNT number := PI_INPUT_COUNT;

    -----------
    v_stamp            VARCHAR2(250);
    V_KEY_LIST_UPPER   CLOB;
    v_unqness_check    NUMBER;
    V_STOP_FLAG        number := 0;
    v_DATA_FIELDS      clob;
    V_DATA_COLUMNS_agg clob;
    v_seq_value        number;

  BEGIN
    /*execute immediate 'create table test_dump'||uid_sequence.nextval||' as select * from '||PI_DUMP_TABLE;*/
    --INSERT_LOGS (PIO_DUPLICATE_TABLE);
    /*
      if (PI_ADD_LOG_INFO is not null) then
    commons_utils.insert_logs('check '||to_char(PI_ADD_LOG_INFO.count));
    commons_utils.insert_logs('check '||to_char(PI_ADD_LOG_INFO(1).v_key));
     commons_utils.insert_logs('check '||to_char(PI_ADD_LOG_INFO(1).v_value));
     commons_utils.insert_logs('check '||to_char(PI_ADD_LOG_INFO(2).v_key));
     commons_utils.insert_logs('check '||to_char(PI_ADD_LOG_INFO(2).v_value));
    else
        commons_utils.insert_logs('check null');
    end if;*/
    if PI_MODE in (2, 3, 4) then
      po_shrink_flag := commons_utils.TABLE_SHRINK_CHECK(pi_table_name => PI_DEST_TABLE);
      if po_shrink_flag = 1 then
        commons_utils.TABLE_SHRINK(pi_table_name => PI_DEST_TABLE);
      end if;
    end if;

    v_tablespace := case
                      when pi_mode = 1 and (PI_AGGREGATE = 0 /*and PI_DATA_COLUMNS.count <> 0*/
                           ) then
                       v_dts_tablespace
                      else
                       v_out_tablespace
                    end;

    v_tablespace_ind := case
                          when pi_mode = 1 and (PI_AGGREGATE = 0 /*and PI_DATA_COLUMNS.count <> 0*/
                               ) then
                           v_ind_tablespace
                          else
                           v_out_tablespace
                        end;

    /*if (PI_FLT_WHERE_CONDITIONS is not null) then
         V_DUMP_TABLE := v_filter_table;
         --CHECK THIS
         v_sql := '
    CREATE TABLE  ' || V_DUMP_TABLE || ' TABLESPACE ' || v_tablespace ||

                  ' AS SELECT '||PI_DUMP_TABLE||'.* FROM ' || PI_DUMP_TABLE || ' ' ||
                  PI_FLT_JOIN_CONDITIONS || ' WHERE  ' || PI_FLT_WHERE_CONDITIONS;


            --Logging changes start

         v_stamp := 'COMMONS_DATALOADPROCESSING.ValidationAndPosting';
         L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>;', v_stamp);

       --Logging changes end

         commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);
       V_INPUT_COUNT:=sql%rowcount;
       else
         V_DUMP_TABLE := upper(PI_DUMP_TABLE);
       end if;*/

    /*execute immediate 'select '||PI_SEQ_USED_FOR_ID||'.nextval from dual' into v_seq_value;*/

    if PI_SEQ_RESET_FLAG = 1 then
      v_seq_value := 1;
    else
      execute immediate 'select ' || PI_SEQ_USED_FOR_ID ||
                        '.nextval from dual'
        into v_seq_value;

    end if;
    if /*PI_ADD_LOG_INFO is null or*/
     PI_AGGREGATE IN (3) then
      V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || ' , max(' ||
                              nvl(PI_INPUT_COUNT, 1) || '+ rownum + ' ||
                              v_seq_value || ') AS ' || PI_ID_COLUMN_NAME;
    else
      V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_ID_COLUMN_NAME ||
                              ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                              PI_AGGREGATION_ORDER || ' ) AS ' ||
                              PI_ID_COLUMN_NAME;
    end if;
    V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(' || PI_VERSION_COLUMN_NAME ||
                            ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                            PI_AGGREGATION_ORDER || ' ) AS ' ||
                            PI_VERSION_COLUMN_NAME;
    V_DATA_COLUMNS       := PI_ID_COLUMN_NAME || ',' ||
                            PI_VERSION_COLUMN_NAME;

    /*if PI_ADD_LOG_INFO is null then

    commons_utils.INSERT_LOGS('PI_ADD_LOG_INFO is null ');
    end if;*/

    --commons_utils.INSERT_LOGS('count'||PI_ADD_LOG_INFO.count);
    if /*PI_ADD_LOG_INFO is null or*/
     PI_AGGREGATE NOT IN (2, 3) then
      --commons_utils.INSERT_LOGS('V_DATA_COLUMNS_agg '||V_DATA_COLUMNS_agg);
      V_DATA_COLUMNS_agg := PI_ID_COLUMN_NAME || ',' ||
                            PI_VERSION_COLUMN_NAME;

    end if;
    --commons_utils.INSERT_LOGS('V_DATA_COLUMNS_agg '||V_DATA_COLUMNS_agg);

    IF (PI_DATA_COLUMNS IS NOT NULL) THEN

      FOR I IN 1 .. PI_DATA_COLUMNS.COUNT LOOP
        ------code starts here
        --complete col lsit to be sent to posting proc
        IF (PI_DATA_COLUMNS(I).COL_IS_MAPPED = 1) THEN
          V_ALL_KEYS := FALSE;
          --for overlap data fields
          v_DATA_FIELDS := v_DATA_FIELDS /*|| CASE
                                                                                                           WHEN v_DATA_FIELDS IS NOT NULL THEN
                                                                                                            ',' end*/
                           || PI_DATA_COLUMNS(I).COL_NAME || ',';
          -- insert_logs(PI_CLOB => 'v_DATA_FIELDS '|| v_DATA_FIELDS);
          dbms_output.put_line(v_DATA_FIELDS);
          V_SYNC_CLAUSE := V_SYNC_CLAUSE || CASE
                             WHEN V_SYNC_CLAUSE IS NOT NULL THEN
                              ' and '
                             else
                              ' '
                           end || ' ( ' ||

                           CASE
                             WHEN PI_DATA_COLUMNS(I).COL_IS_REQUIRED = 1 THEN

                              CASE
                                WHEN PI_DATA_COLUMNS(I).COL_DATA_TYPE LIKE 'VARCHAR%' THEN
                                 ' UPPER( OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ')= UPPER(IP.' || PI_DATA_COLUMNS(I).COL_NAME || ' ) '

                              --end of addition by pramod
                                ELSE
                                 'OP.' || PI_DATA_COLUMNS(I).COL_NAME || '= IP.' || PI_DATA_COLUMNS(I)
                                .COL_NAME
                              END

                             ELSE
                              CASE
                                WHEN PI_DATA_COLUMNS(I).COL_DATA_TYPE LIKE 'VARCHAR%' THEN
                                 ' NVL(UPPER(OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 '), CHR(0))= NVL(UPPER(IP.' || PI_DATA_COLUMNS(I)
                                .COL_NAME || '), CHR(0)) '

                              --end of addition by pramod
                                WHEN PI_DATA_COLUMNS(I).COL_DATA_TYPE like 'NUMBER%' THEN
                                 ' NVL(OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ', 1E38)= NVL(IP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ', 1E38) '

                                WHEN PI_DATA_COLUMNS(I).COL_DATA_TYPE = 'DATE' THEN
                                 ' NVL(OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD''))= NVL(IP.' || PI_DATA_COLUMNS(I)
                                .COL_NAME ||
                                 ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD'')) '

                                WHEN PI_DATA_COLUMNS(I).COL_DATA_TYPE LIKE 'TIMESTAMP%' THEN
                                 ' NVL(OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD''))= NVL(IP.' || PI_DATA_COLUMNS(I)
                                .COL_NAME ||
                                 ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD'')) '

                                ELSE
                                 'OP.' || PI_DATA_COLUMNS(I).COL_NAME || '= IP.' || PI_DATA_COLUMNS(I)
                                .COL_NAME
                              END ||

                              CASE
                                WHEN PI_DATA_COLUMNS(I)
                                 .COL_DATA_TYPE NOT LIKE 'VARCHAR%' AND PI_DATA_COLUMNS(I)
                                     .COL_DATA_TYPE NOT LIKE 'TIMESTAMP%' AND PI_DATA_COLUMNS(I)
                                     .COL_DATA_TYPE NOT LIKE 'NUMBER%' AND PI_DATA_COLUMNS(I)
                                     .COL_DATA_TYPE NOT IN ('DATE') THEN
                                 ' or (IP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ' is null and OP.' || PI_DATA_COLUMNS(I).COL_NAME ||
                                 ' is null ) '
                              END
                           END || ' ) ';

          ---1.28
          if PI_DATA_COLUMNS(I).ADD_TO_EXISTING = 0 then
            v_col_count := v_col_count + 1;
            V_COL_LIST.extend;
            V_COL_LIST(v_col_count) := PI_DATA_COLUMNS(I).COL_NAME;
            /*V_COL_LIST := V_COL_LIST || CASE
                              WHEN V_COL_LIST IS NOT NULL THEN
                               ' , '
                            END || PI_DATA_COLUMNS(I).COL_NAME;
            */
          elsif PI_DATA_COLUMNS(I).ADD_TO_EXISTING = 1 then
            --add to existing to be set to posting proc
            V_ALL_UPDATE := TRUE;
            v_add_count  := v_add_count + 1;
            V_ADD_TO_EXISTING.extend;
            V_ADD_TO_EXISTING(v_add_count) := PI_DATA_COLUMNS(I).COL_NAME;

            /*  V_ADD_TO_EXISTING := V_ADD_TO_EXISTING || CASE
              WHEN V_ADD_TO_EXISTING IS NOT NULL THEN
               ' , '
            END || '''' || PI_DATA_COLUMNS(I).COL_NAME || '''';*/

          end if;

          V_DATA_COLUMNS := V_DATA_COLUMNS || CASE
                              WHEN V_DATA_COLUMNS IS NOT NULL THEN
                               ' , '
                            END || PI_DATA_COLUMNS(I).COL_NAME;

          V_DATA_COLUMNS_agg := V_DATA_COLUMNS_agg || CASE
                                  WHEN V_DATA_COLUMNS_agg IS NOT NULL THEN
                                   ' , '
                                END || PI_DATA_COLUMNS(I).COL_NAME;
          -----agreegartion clause
          IF (PI_DATA_COLUMNS(I).AGG_TYPE = 0) THEN
            --shri start
            if PI_DATA_COLUMNS(I).col_data_type = 'XMLTYPE' THEN
              V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
         ,   max(t.' || PI_DATA_COLUMNS(I)
                                     .COL_NAME ||
                                      '.GETSTRINGVAL()) KEEP(DENSE_RANK LAST ORDER BY ' ||
                                      PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME;

              /*commons_utils.INSERT_LOGS('mean V_AGGREGATION_CLAUSE ' ||
              V_AGGREGATION_CLAUSE);*/

            ELSE

              V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || '
                              ,   max(' || PI_DATA_COLUMNS(I)
                                     .COL_NAME ||
                                      ') KEEP(DENSE_RANK LAST ORDER BY ' ||
                                      PI_AGGREGATION_ORDER || ' ) AS ' || PI_DATA_COLUMNS(I)
                                     .COL_NAME;
              /* commons_utils.INSERT_LOGS('mean 1 V_AGGREGATION_CLAUSE ' ||
              V_AGGREGATION_CLAUSE);*/

            END IF;

            --shri end
          ELSE

            V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || ' ,cast( ROUND (' || CASE
                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 1 THEN
                                       'SUM'

                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 2 THEN
                                       'MIN'

                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 3 THEN
                                       'MAX'

                                      WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 4 THEN
                                       'AVG'
                                    END || ' ( ' || PI_DATA_COLUMNS(I).COL_NAME ||
                                    '   ),' || PI_DATA_COLUMNS(I).DECIMAL_LENGTH ||
                                    ' )  AS  NUMBER(23,10) ) AS ' || PI_DATA_COLUMNS(I)
                                   .COL_NAME;

            /*        V_AGGREGATION_CLAUSE := V_AGGREGATION_CLAUSE || ' ,cast( ROUND (' || CASE
              WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 1 THEN
               ' ,cast( ROUND (' || 'SUM'

              WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 2 THEN
               'MIN'

              WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 3 THEN
               'MAX'

              WHEN PI_DATA_COLUMNS(I).AGG_TYPE = 4 THEN
               ' ,cast( ROUND (' || 'AVG'

            END || ' ( ' || PI_DATA_COLUMNS(I).COL_NAME ||
            '   )' || CASE
              WHEN PI_DATA_COLUMNS(I).AGG_TYPE in (1, 4) THEN
               ',' || PI_DATA_COLUMNS(I).DECIMAL_LENGTH ||

               ' )  AS  NUMBER(23,10) ) '
            end || ' AS ' || PI_DATA_COLUMNS(I).COL_NAME;*/

          END IF;

        ELSE

          if (PI_DATA_COLUMNS(I).COL_DATA_TYPE = 'NUMBER(1)') THEN
            v_bool_count := v_bool_count + 1;
            V_UNMAPPED_BOOL.extend;
            V_UNMAPPED_BOOL(v_bool_count) := PI_DATA_COLUMNS(I).COL_NAME;
          end if;
        END IF;
      END LOOP;
    END IF;

    ---code starts here
    IF (PI_AV_COL_NAME IS NOT NULL) THEN

      V_JOIN_CLAUSE := ' ( ' || 'OP.' || PI_AV_COL_NAME || '= IP.' ||
                       PI_AV_COL_NAME || ' ) ';

      V_OVERLAP_CLAUSE  := PI_AV_COL_NAME;
      V_UNIQUE_CLAUSE   := PI_AV_COL_NAME;
      V_KEY_LIST_UPPER  := '''' || UPPER(PI_AV_COL_NAME) || '''';
      V_GROUP_BY_CLAUSE := PI_AV_COL_NAME;
      V_SELECT_CLAUSE   := PI_AV_COL_NAME;
      /*  v_col_count             := v_col_count + 1;*/
      --av not passed in col list
      /*V_COL_LIST.extend;
      V_COL_LIST(v_col_count) := PI_AV_COL_NAME;*/
    ELSE

      IF (PI_KEY_COLUMNS IS NOT NULL) THEN

        FOR I IN 1 .. PI_KEY_COLUMNS.COUNT LOOP
          ----join in case of normal table
          V_JOIN_CLAUSE := V_JOIN_CLAUSE || CASE
                             WHEN V_JOIN_CLAUSE IS NOT NULL THEN
                              ' and '
                             else
                              ' '
                           end || ' ( ' ||

                           CASE
                             WHEN PI_KEY_COLUMNS(I).COL_IS_REQUIRED = 1 THEN

                              CASE
                                WHEN PI_KEY_COLUMNS(I).COL_DATA_TYPE LIKE 'VARCHAR%' THEN
                                 ' UPPER( OP.' || PI_KEY_COLUMNS(I).COL_NAME || ')= UPPER(IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ' ) '

                              --end of addition by pramod
                                ELSE
                                 'OP.' || PI_KEY_COLUMNS(I).COL_NAME || '= IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME
                              END

                             ELSE
                              CASE
                                WHEN PI_KEY_COLUMNS(I).COL_DATA_TYPE LIKE 'VARCHAR%' THEN
                                 ' NVL(UPPER(OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                 '), CHR(0))= NVL(UPPER(IP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                 '), CHR(0)) '

                              --end of addition by pramod
                                WHEN PI_KEY_COLUMNS(I).COL_DATA_TYPE like 'NUMBER%' THEN
                                 ' NVL(OP.' || PI_KEY_COLUMNS(I).COL_NAME || ', 1E38)= NVL(IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ', 1E38) '

                                WHEN PI_KEY_COLUMNS(I).COL_DATA_TYPE = 'DATE' THEN
                                 ' NVL(OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                 ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD''))= NVL(IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD'')) '

                                WHEN PI_KEY_COLUMNS(I).COL_DATA_TYPE LIKE 'TIMESTAMP%' THEN
                                 ' NVL(OP.' || PI_KEY_COLUMNS(I).COL_NAME ||
                                 ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD''))= NVL(IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD'')) '

                                ELSE
                                 'OP.' || PI_KEY_COLUMNS(I).COL_NAME || '= IP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME
                              END || /*|| ')' ||*/

                              CASE
                                WHEN PI_KEY_COLUMNS(I).COL_DATA_TYPE NOT LIKE 'VARCHAR%' AND PI_KEY_COLUMNS(I)
                                     .COL_DATA_TYPE NOT LIKE 'TIMESTAMP%' AND PI_KEY_COLUMNS(I)
                                     .COL_DATA_TYPE NOT LIKE 'NUMBER%' AND PI_KEY_COLUMNS(I)
                                     .COL_DATA_TYPE NOT IN ('DATE') THEN
                                 ' or (IP.' || PI_KEY_COLUMNS(I).COL_NAME || ' is null and OP.' || PI_KEY_COLUMNS(I)
                                .COL_NAME || ' is null ) '
                              END
                           END || ' ) ';

          v_col_count := v_col_count + 1;
          V_COL_LIST.extend;
          V_COL_LIST(v_col_count) := PI_KEY_COLUMNS(I).COL_NAME;

          v_key_col_count := v_key_col_count + 1;
          V_KEY_LIST.extend;
          V_KEY_LIST(v_key_col_count) := PI_KEY_COLUMNS(I).COL_NAME;

          /*V_COL_LIST := V_COL_LIST || CASE
            WHEN V_COL_LIST IS NOT NULL THEN
             ' , '
          END || PI_KEY_COLUMNS(I).COL_NAME;*/
          V_GROUP_BY_CLAUSE := V_GROUP_BY_CLAUSE || CASE
                                 WHEN V_GROUP_BY_CLAUSE IS NOT NULL THEN
                                  ' , '
                               END || PI_KEY_COLUMNS(I).COL_NAME;
          V_UNIQUE_CLAUSE := V_UNIQUE_CLAUSE || CASE
                               WHEN V_UNIQUE_CLAUSE IS NOT NULL THEN
                                ' , '
                             END || PI_KEY_COLUMNS(I).COL_NAME;

          V_KEY_LIST_UPPER := V_KEY_LIST_UPPER || CASE
                                WHEN V_KEY_LIST_UPPER IS NOT NULL THEN
                                 ' , '
                              END || '''' || UPPER(PI_KEY_COLUMNS(I).COL_NAME) || '''';
          V_OVERLAP_CLAUSE := V_OVERLAP_CLAUSE || CASE
                                WHEN PI_KEY_COLUMNS(I).COL_NAME = PI_Effective_Start THEN
                                 ''
                                ELSE
                                 '' || CASE
                                   WHEN V_OVERLAP_CLAUSE IS NOT NULL THEN
                                    ','
                                 END ||

                                 PI_KEY_COLUMNS(I).COL_NAME
                              END;

          --OLD key columns select clause
          V_SELECT_CLAUSE := V_SELECT_CLAUSE || CASE
                               WHEN V_SELECT_CLAUSE IS NOT NULL THEN
                                ' , ' || PI_KEY_COLUMNS(I).COL_NAME
                               ELSE
                                PI_KEY_COLUMNS(I).COL_NAME
                             END;

        END LOOP;
      END IF;
    END IF;

    --create index here
    /* v_business_index_name varchar2(30 char):=PI_DEST_TABLE ||'_BUSINESSKEY_UI';
    v_primary_index_name varchar2(30 char):='PK_' || PI_DEST_TABLE;

     v_dp_business_index_name varchar2(30 char):='DPBK_' || PI_DEST_TABLE;
    v_dp_primary_index_name varchar2(30 char):='DPPK_' || PI_DEST_TABLE;*/
    -----------

    ---to be used once aggregation is integrated

    /*select aids_index_ddl into v_business_key_ddl from AIM_INDEX_DDL_STORAGE
    where aids_table_name=PI_DEST_TABLE and aids_index_name=v_business_index_name;

    v_business_key_ddl:=replace(v_business_key_ddl,v_business_index_name,v_dp_business_index_name);
    v_business_key_ddl:=replace(v_business_key_ddl,PI_DEST_TABLE,V_DUMP_TABLE);
      IF (PI_AGGREGATE = 1) THEN
    v_business_key_ddl:=replace(v_business_key_ddl,'UNIQUE','');
    execute immediate v_business_key_ddl;
    else

    begin
     execute immediate v_business_key_ddl;
     when others then
       ---creatinga unique index will perform teh uniquness checl
       null;
       --rasie exception
     end ;
    end if;

      if ( IF (1 = 1) ) then
        commons_tables.COMMON_UNIQUE_CHECK(pi_TABLE          => V_DUMP_TABLE,
                            pi_KEY_FIELDS     => V_OVERLAP_CLAUSE,
                            po_UNIQUE_CHK_RES => po_UNIQUE_CHK_RES);

        if po_UNIQUE_CHK_RES = 0 then
         --rasie exception
         return;
        end if;
    */

    ---PI_AV_COL_NAME
    --$$$
    if (PI_MODE = 1 and PI_AV_GENERATED_BY_SW = 1 AND
       PI_SOURCE_FILE_COUNT > 1) then
      V_DUMP_TABLE := v_filter_table;
      v_sql := '
                    CREATE TABLE  ' || V_DUMP_TABLE ||
               ' TABLESPACE ' || v_tablespace || ' AS SELECT rownum ' ||
               PI_AV_COL_NAME || CASE
                 WHEN V_DATA_COLUMNS IS NOT NULL THEN
                  ' , ' || V_DATA_COLUMNS
               END || ' FROM ' || PI_DUMP_TABLE || CASE
                 WHEN PI_FLT_WHERE_CONDITIONS is not null THEN
                  ' ' || PI_FLT_JOIN_CONDITIONS || ' WHERE  ' ||
                  PI_FLT_WHERE_CONDITIONS
               END;

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.ValidationAndPosting';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_sql),
                        'v_sql := <value>;',
                        v_stamp);

      --Logging changes end

      /*commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);*/ --OF-19672
      commons_ddl_handling.execute_ddl_nolog_rowcount(pi_ddl      => v_sql,
                                                      pi_to_trace => 1,
                                                      po_rowcount => V_INPUT_COUNT); --OF-19672
      /*V_INPUT_COUNT:=sql%rowcount;*/ --OF-19672
      IF PI_FLT_WHERE_CONDITIONS is not null THEN
        PO_FILTER_COUNT := V_INPUT_COUNT;
      END IF;

    elsif (PI_FLT_WHERE_CONDITIONS is not null) THEN
      V_DUMP_TABLE := v_filter_table;
      v_sql        := '
                   CREATE TABLE  ' || V_DUMP_TABLE ||
                      ' TABLESPACE ' || v_tablespace || ' AS SELECT ' ||
                      PI_DUMP_TABLE || '.* FROM ' || PI_DUMP_TABLE || ' ' ||
                      PI_FLT_JOIN_CONDITIONS || ' WHERE  ' ||
                      PI_FLT_WHERE_CONDITIONS;

      --Logging changes start

      v_stamp := 'COMMONS_DATALOADPROCESSING.ValidationAndPosting';
      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(v_sql),
                        'v_sql := <value>;',
                        v_stamp);

      --Logging changes end

      /*commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);*/ --OF-19672
      commons_ddl_handling.execute_ddl_nolog_rowcount(pi_ddl      => v_sql,
                                                      pi_to_trace => 1,
                                                      po_rowcount => V_INPUT_COUNT); --OF-19672
      /*V_INPUT_COUNT:=sql%rowcount;*/ --OF-19672
      PO_FILTER_COUNT := V_INPUT_COUNT;
    else
      V_DUMP_TABLE := upper(PI_DUMP_TABLE);
    end if;
    --$$$

    if (PI_AV_GENERATED_BY_SW = 0) then

      IF (PI_AGGREGATE IN (1, 2, 3) and V_SELECT_CLAUSE is not null /*AND PI_DATA_COLUMNS IS NOT NULL*/--deshmukha added V_SELECT_CLAUSE is not null
         ) THEN

        /*   COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(PI_TABLE   => V_DUMP_TABLE,PI_MODE =>2);*/
        --IF AGGREGATION OPTION IS SELECTED CALL STORED PROCEDURE TO SEGREGATE DUPLICATE AND DISTINCT RECORD ON THE BASIS OF KEY COLUMNS.
        COMMONS_DATALOADPROCESSING.DUMP_TABLE_SEGREGATION(PIO_DUMP_TABLE        => V_DUMP_TABLE,
                                                          PI_INTRANS_VALUE      => 2,
                                                          PI_KEY_COLUMNS        => V_SELECT_CLAUSE,
                                                          PI_DATA_COLUMNS       => V_DATA_COLUMNS_agg,
                                                          PI_WHERE_CONDITIONS   => null,
                                                          PI_AGGREGATION_CLAUSE => V_AGGREGATION_CLAUSE,
                                                          PI_GROUP_BY_CLAUSE    => V_GROUP_BY_CLAUSE,
                                                          PI_AGGREGATION_ORDER  => PI_AGGREGATION_ORDER,
                                                          PIO_DUPLICATE_TABLE   => PIO_DUPLICATE_TABLE,
                                                          PI_AGREEGATE          => PI_AGGREGATE,
                                                          PI_INPUT_COUNT        => V_INPUT_COUNT,
                                                          PO_STOP_FLAG          => V_STOP_FLAG,
                                                          PI_ADD_LOG_INFO       => PI_ADD_LOG_INFO);
        --disabling cardinality hint in case of aggregation
        /* V_INPUT_COUNT:=null;*/
        IF (V_STOP_FLAG = 1) THEN
          --  RETURN;
          if (PI_AGGREGATE = 2) then
            for c in (select 1
                        from user_tables
                       where table_name = V_DUMP_TABLE) loop
              V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
              COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
            END LOOP;
            raise_application_error(-20007, 'Uniqueness check failed');
          end if;
        END IF;
        /*Shri*/
      END IF;

      /*if(pi_mode=1) then
        commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => V_DUMP_TABLE,
                                               PI_MODE  => 2);

           \*select num_rows into PO_COUNT from user_tables where table_name=V_DUMP_TABLE;                                       *\
      end if;*/ --removed since it will handeled centrally at the end.

      v_dp_business_index_name := Upper(SUBSTR(V_DUMP_TABLE, 0, 25)) ||
                                  '_DPBK';
      v_dp_primary_index_name  := Upper(SUBSTR(V_DUMP_TABLE, 0, 25)) ||
                                  '_DPPK';

      /*execute immediate 'select NVL(MAX(1),0) from dual where exists(SELECT 1 FROM TABLE_COLUMNS T WHERE UPPER(T.TC_PHYSICAL_NAME) IN (' ||
                        V_KEY_LIST_UPPER || ') AND T.TC_IS_NULLABLE = 0)'
        INTO v_unqness_check;*/
      -- deshmukha added tc_tables_id condition for OF-69616
      execute immediate 'select NVL(MAX(1),0) from dual where exists(SELECT 1 FROM TABLE_COLUMNS T WHERE t.tc_tables_id = ' ||
                        PI_DEST_TABLES_ID ||
                        ' and UPPER(T.TC_PHYSICAL_NAME) IN (' ||
                        V_KEY_LIST_UPPER || ') AND T.TC_IS_NULLABLE = 0)'
        INTO v_unqness_check;
      v_stamp := 'COMMONS_DATALOADPROCESSING.ValidationAndPosting';

      L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                        ANYDATA.CONVERTCLOB(TO_CLOB(v_unqness_check)),
                        'v_unqness_check := <value>;',
                        v_stamp);

      IF v_unqness_check = 0 THEN

        commons_tables.COMMON_UNIQUE_CHECK(pi_TABLE          => V_DUMP_TABLE,
                                           pi_KEY_FIELDS     => V_UNIQUE_CLAUSE,
                                           po_UNIQUE_CHK_RES => v_unique_Chk_Res,
                                           PI_INPUT_COUNT    => V_INPUT_COUNT);

        if v_unique_Chk_Res = 0 then

          raise_application_error(-20007, 'Uniqueness check failed');
        end if;
      END IF;

      begin

        select REGEXP_REPLACE(AIDS_INDEX_DDL,
                              '(TABLESPACE (.){1,})',
                              '',
                              1,
                              0,
                              'i')
        --    aids_index_ddl
          into v_business_key_ddl
          from AIM_INDEX_DDL_STORAGE
         where upper(aids_table_name) = upper(PI_DEST_TABLE)
           and aids_index_name = v_business_index_name;

        v_business_key_ddl := replace(v_business_key_ddl,
                                      v_business_index_name,
                                      v_dp_business_index_name);
        v_business_key_ddl := replace(v_business_key_ddl,
                                      upper(PI_DEST_TABLE),
                                      V_DUMP_TABLE) || ' TABLESPACE ' ||
                              v_tablespace_ind;

        begin
          -- dbms_output.put_line(v_business_key_ddl);
          /*      execute immediate v_business_key_ddl;*/
          --Logging changes start

          v_stamp := 'COMMONS_DATALOADPROCESSING.ValidationAndPosting';
          L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                            ANYDATA.CONVERTCLOB(v_business_key_ddl),
                            'v_business_key_ddl := <value>;',
                            v_stamp);
          /*commons_utils.insert_logs(v_business_key_ddl);*/
          --Logging changes end
          commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_business_key_ddl);
        exception
          when E_DUPL_KEY then
            if (PI_AGGREGATE = 0) then
              raise_application_error(-20007, 'Uniqueness check failed');
            else
              raise;
            end if;
            --added to mark that the flow is checkdd
          when others then
            raise;

        end;
      exception
        when no_data_found then
          v_index_failed := true;

      end;

      IF v_unqness_check = 1 THEN

        if (v_index_failed = true) then

          commons_tables.COMMON_UNIQUE_CHECK(pi_TABLE          => V_DUMP_TABLE,
                                             pi_KEY_FIELDS     => V_UNIQUE_CLAUSE,
                                             po_UNIQUE_CHK_RES => v_unique_Chk_Res,
                                             PI_INPUT_COUNT    => V_INPUT_COUNT);

          if v_unique_Chk_Res = 0 then

            raise_application_error(-20007, 'Uniqueness check failed');
          end if;
        end if;
      END IF;

      /*    end if;*/

      if (pi_mode in (2, 3, 4)) then
        v_sql := 'CREATE UNIQUE INDEX ' || v_dp_primary_index_name ||
                 ' ON ' || V_DUMP_TABLE || ' (' || PI_ID_COLUMN_NAME || ')' ||
                 'TABLESPACE ' || v_out_tablespace;
        ------INSERT_LOGS(v_sql); --dbms_output.put_line(v_sql);
        --Logging changes start

        v_stamp := 'COMMONS_DATALOADPROCESSING.ValidationAndPosting';
        L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                          ANYDATA.CONVERTCLOB(v_sql),
                          'v_sql := <value>;',
                          v_stamp);

        --Logging changes end

        commons_ddl_handling.execute_ddl_nolog(pi_ddl => v_sql);
      end if;

    end if;

    --add hints in the queries
    if (PI_TABLES_RECORD_DATING_OPTION in (4, 5)) then

      v_is_period := case
                       when PI_TABLES_RECORD_DATING_OPTION = 4 then
                        0
                       else
                        1
                     end;
      v_is_close_end := 1;

      --OVERLAP

      ------INSERT_LOGS(PI_DEST_TABLE);
      ------INSERT_LOGS(V_UNIQUE_OVERLAP_CLAUSE);

      if (PI_MODE = 1) then

        if (PI_OVERLAP_TABLE is null) then
          commons_tables.COMMON_OVERLAP_CHECK(pi_TABLE           => PI_DEST_TABLE,
                                              pi_TABLE_CLOB      => V_DUMP_TABLE,
                                              pi_KEY_FIELDS      => V_OVERLAP_CLAUSE,
                                              pi_Effective_Start => PI_Effective_Start,
                                              pi_Effective_End   => pi_Effective_End,
                                              PI_is_Period       => v_is_period,
                                              PI_ID_COLUMN       => 'ROW_IDENTIFIER',
                                              po_OVERLAP_CHK_RES => v_Overlap_Chk_Res,
                                              PI_INPUT_COUNT     => V_INPUT_COUNT);

        elsif (PI_OVERLAP_TABLE is not null) then

          commons_tables.COMMON_OVERLAP_POST(pi_TABLE           => PI_DEST_TABLE,
                                             pi_TABLE_CLOB      => V_DUMP_TABLE,
                                             pi_KEY_FIELDS      => V_OVERLAP_CLAUSE,
                                             pi_DATA_FIELDS     => v_DATA_FIELDS,
                                             pi_Effective_Start => PI_Effective_Start,
                                             pi_Effective_End   => pi_Effective_End,
                                             PI_is_Period       => v_is_period,
                                             PI_ID_COLUMN       => 'ROW_IDENTIFIER',
                                             po_OVERLAP_CHK_RES => v_Overlap_Chk_Res,
                                             PI_INPUT_COUNT     => V_INPUT_COUNT,
                                             PI_OVERLAP_TABLE   => PI_OVERLAP_TABLE,
                                             PI_ADD_LOG_INFO    => PI_ADD_LOG_INFO);
        end if;

        if v_Overlap_Chk_Res = 0 then
          if PI_AGGREGATE in (1, 2, 3) then
            for c in (select 1
                        from user_tables
                       where table_name = V_DUMP_TABLE) loop
              V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
              COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
            END LOOP;
          end if;
          raise_application_error(-20006, 'Overlap check failed');
        end if;
      end if;
    end if;
    if (pi_mode in (2, 3, 4)) then
      Upsert_posting(pi_table                  => PI_DEST_TABLE,
                     pi_dump                   => V_DUMP_TABLE,
                     pi_join_clause            => V_JOIN_CLAUSE,
                     PI_mode                   => PI_MODE,
                     pi_list_of_columns        => V_COL_LIST,
                     pi_list_of_keys           => V_KEY_LIST,
                     pi_add_to_exist_columns   => V_ADD_TO_EXISTING,
                     pi_id_column_name         => PI_ID_COLUMN_NAME,
                     pi_version_column_name    => PI_VERSION_COLUMN_NAME,
                     pi_seq_used_for_id        => PI_SEQ_USED_FOR_ID,
                     pi_ent_intern_id_col_name => PI_ENT_INTERN_ID_COL_NAME,
                     pi_ent_seq_name           => pi_ent_seq_name,
                     pi_av_col_name            => PI_AV_COL_NAME,
                     pi_av_generated_sw        => pi_av_generated_by_sw,
                     pi_process_id             => pi_process_id,

                     /* pi_av_count            => 0, --set an call*/
                     pi_dump_buisness_index  => v_dp_business_index_name,
                     pi_dump_primary_index   => v_dp_primary_index_name,
                     PI_TABLE_BUSINESSKEY_UI => v_business_index_name,
                     --moving close date parameters start
                     pi_is_close_end       => v_is_close_end,
                     pi_key_Fields         => V_OVERLAP_CLAUSE,
                     pi_Effective_Start    => PI_Effective_Start,
                     pi_Effective_End      => pi_Effective_End,
                     pi_Is_Period          => v_is_period,
                     pi_tu_id              => PI_TU_ID,
                     PI_DL_DEF_ID          => PI_DL_DEF_ID,
                     PI_RUN_ID             => PI_RUN_ID,
                     PO_closed_dates_Count => PO_closed_dates_Count,
                     --moving close date parameters end
                     /* po_av_count     => v_av_count,*/
                     po_update_count                => po_update_count,
                     po_insert_count                => po_insert_count,
                     po_status                      => po_status,
                     PI_TABLES_ID                   => PI_DEST_TABLES_ID,
                     PI_TABLES_RECORD_DATING_OPTION => PI_TABLES_RECORD_DATING_OPTION,
                     PI_UNMAPPED_BOOL               => V_UNMAPPED_BOOL,
                     PI_SYNC_CLAUSE                 => V_SYNC_CLAUSE,
                     PI_ALL_KEYS                    => V_ALL_KEYS,
                     PI_ALL_UPDATE                  => V_ALL_UPDATE,
                     PI_INPUT_COUNT                 => V_INPUT_COUNT,
                     PI_OVERLAP_TABLE               => PI_OVERLAP_TABLE,
                     PI_ADD_LOG_INFO                => PI_ADD_LOG_INFO);
    end if;
    --DROPPING THE INTERMEDIATE DUMP TABLE HOLDING AGGREGATED RECORDS THE FILTERING RECORDS FOR UPSERT MODES.
    IF (PI_mode in (2, 3, 4) and PI_AGGREGATE in (1, 2, 3) and V_SELECT_CLAUSE is not null) THEN --deshmukha added V_SELECT_CLAUSE is not null
      --PI_AGGREGATE = 1) deshmukha added 2 and 3 to the condition PI_AGGREGATE = 1
      for c in (select 1 from user_tables where table_name = V_DUMP_TABLE) loop
        V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || V_DUMP_TABLE;
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
      END LOOP;
    END IF;

    ------DROPPING THE INTERMEDIATE DUMP TABLE HOLDING THE FILTERING RECORDS FOR UPSERT MODES
    IF (PI_mode in (2, 3, 4) and PI_FLT_WHERE_CONDITIONS is not null) THEN
      for c in (select 1 from user_tables where table_name = v_filter_table) loop
        V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || v_filter_table;
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
      end loop;
    end if;
    ---if we are in recerte mdoe with aggregation and filtering applied in the defination then
    IF (PI_mode in (1) and PI_AGGREGATE = 1 /*and  PI_DATA_COLUMNS IS NOT NULL */
       AND PI_FLT_WHERE_CONDITIONS is not null) THEN
      for c in (select 1 from user_tables where table_name = v_filter_table) loop
        V_SQL_DROP_DUMP_TABLE := 'DROP TABLE ' || v_filter_table;
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(V_SQL_DROP_DUMP_TABLE);
      END LOOP;
    END IF;

    Po_QI_TABLE := V_DUMP_TABLE;
  END ValidationAndPosting;

  PROCEDURE HIRARCHY_VIEW(pi_Dest_Table      IN VARCHAR2,
                          pi_QI_Table        IN VARCHAR2,
                          pi_view_name       IN VARCHAR2,
                          pi_key_Fields      IN VARCHAR2,
                          pi_DATA_Fields     IN VARCHAR2,
                          PI_Effective_Start IN VARCHAR2,
                          PI_Effective_End   IN VARCHAR2,
                          PI_Is_Recreate     IN number,
                          PI_Is_Period       IN number,
                          PI_TU_ID           IN number) IS

    v_KEY_COLS       clob := PI_Key_Fields || ',';
    v_JOIN_CONDITION VARCHAR2(32767) := '';
    v_FIELDS         VARCHAR2(30) := '';
    v_OVERLAP_STR    CLOB := '';
    V_OVERLAP_RESULT Number;
    v_Intenal_query  clob;
    l_offset         number default 1;
    v_Dest_Table     varchar2(1000);
    v_COL_NAME       VARCHAR2(30 CHAR);
    v_IS_NULLABLE    NUMBER(1);
    cv_sql           sys_refcursor;
    v_KEY_FIELDS     clob := '''' || replace(pi_KEY_FIELDS, ',', ''',''') || '''';
    v_stamp          VARCHAR2(250);

    --Checking the Columns data type
    v_data_type             number;
    v_col_list clob := 'row_identifier,row_version,' || PI_Effective_Start ||
                       ' , ' || PI_Effective_End || ' ' || case
                         when pi_key_Fields is null then
                          null
                         else
                          ' , ' || pi_key_Fields
                       end || case
                         when pi_DATA_Fields is null then
                          null
                         else
                          ' , ' || pi_DATA_Fields
                       end;
    v_col_list_wo_start_end clob := 'row_identifier,row_version' || case
                                      when pi_key_Fields is null then
                                       null
                                      else
                                       ' , ' || pi_key_Fields
                                    end || case
                                      when pi_DATA_Fields is null then
                                       null
                                      else
                                       ' , ' || pi_DATA_Fields
                                    end;

  begin

    --DBMS_OUTPUT.PUT_LINE(v_col_list);

    if (PI_Is_Recreate = 0) then
      v_Dest_Table := '( Select 1 to_calculate,' || v_col_list || '  ' ||
                      ' from ' || pi_Dest_Table || ' Dest where not exists
( select 1 from ' || pi_QI_Table ||
                      ' Qi where Qi.row_identifier=Dest.row_identifier )) ';

      /*
      '||decode(PI_Is_Recreate,1,' where 1=2 ',null)||'*/

      v_Intenal_query := '
with Table_Check as
 (

  select ' || v_col_list || ', ' || PI_Effective_Start ||
                         ' start_given,
          decode(to_calculate,1,decode(' ||
                         PI_Effective_End || ',
                 null,' || case
                           when PI_Is_Period = 0 then
                            ' LEAD(' || PI_Effective_Start ||
                            ') OVER(partition by ' ||
                            nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                                       PI_COL_LIST   => pi_key_Fields),
                                ' NULL ') || ' order by ' || PI_Effective_Start ||
                            ' nulls first ) - 1 '
                           when PI_Is_Period = 1 then
                            ' commons_timeunits.Get_nth_prior_period(' ||
                            PI_TU_ID || ',(LEAD(' || PI_Effective_Start ||
                            ') OVER(partition by ' ||
                            nvl(commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => UPPER(pi_Dest_Table),
                                                                       PI_COL_LIST   => pi_key_Fields),
                                ' NULL ') || ' order by ' || PI_Effective_Start ||
                            ' nulls first))
                                                                           ,1,
                                                                                   2010,
                                                                                   2025)'
                         end || ',' || PI_Effective_End || '),0,' ||
                         PI_Effective_End || ') AS end_calulated

    from (select to_calculate, ' || v_col_list || '
              from ' || v_Dest_Table || ' IP
           union all ' || 'select 0 to_calculate,' ||
                         v_col_list || ' from ' || pi_QI_Table ||
                         ' OP )  T)

select start_given ' || PI_Effective_Start ||
                         ' ,end_calulated ' || PI_Effective_End || ',  ' ||
                         v_col_list_wo_start_end || ' from Table_Check
';

      --    DBMS_OUTPUT.PUT_LINE(v_OVERLAP_STR);

      v_Intenal_query := 'create view ' || pi_view_name || ' as ' ||
                         v_Intenal_query;

    elsif (PI_Is_Recreate = 1) then
      v_Intenal_query := 'create view ' || pi_view_name || ' as ' ||
                         ' select * from ' || pi_QI_Table;
    end if;

    /* loop
      exit when l_offset > dbms_lob.getlength(v_Intenal_query);
      dbms_output.put_line(dbms_lob.substr(v_Intenal_query, 999, l_offset));
      l_offset := l_offset + 999;
    end loop;
    l_offset := 1;*/
    /*
    EXECUTE IMMEDIATE v_Intenal_query;*/
    --Logging changes start

    v_stamp := 'COMMONS_DATALOADPROCESSING.HIRARCHY_VIEW';
    L4O_LOG_VARIABLES(L4O_LOGGING.LVL_DEBUG,
                      ANYDATA.CONVERTCLOB(v_Intenal_query),
                      'v_Intenal_query := <value>;',
                      v_stamp);

    --Logging changes end

    commons_ddl_handling.execute_ddl_nolog(v_Intenal_query);
  end HIRARCHY_VIEW;

  PROCEDURE DL_SET_RUN_TIME_OFFSETS(PI_RUN_DATA_ID        IN NUMBER,
                                    PI_RANGE              IN NUMBER,
                                    PO_MAX_ROW_IDENTIFIER OUT NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    UPDATE DL_RUN_TIME_OFFSETS D
       SET D.DRTO_NEXT_ROW_IDENTIFIER = D.DRTO_NEXT_ROW_IDENTIFIER +
                                        PI_RANGE
     WHERE D.DRTO_RD_ID = PI_RUN_DATA_ID
    RETURNING D.DRTO_NEXT_ROW_IDENTIFIER INTO PO_MAX_ROW_IDENTIFIER;

    IF SQL%ROWCOUNT = 0 THEN
      ROLLBACK;
      RAISE_APPLICATION_ERROR(-20102,
                              'Offset record for RUN_DATA_ID = ' ||
                              PI_RUN_DATA_ID || ' does not exist.');
    END IF;
    COMMIT;
  END;

  PROCEDURE ValidationAndPosting(PI_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                                 PI_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                                 PI_AV_GENERATED_BY_SW     IN NUMBER, --auto-value
                                 PI_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                                 PI_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                                 PI_AGGREGATION_ORDER      IN VARCHAR2,
                                 PI_FLT_JOIN_CONDITIONS    IN VARCHAR2,
                                 PI_FLT_WHERE_CONDITIONS   IN VARCHAR2,
                                 PI_ID_COLUMN_NAME         IN VARCHAR2,
                                 PI_SEQ_USED_FOR_ID        IN VARCHAR2,
                                 PI_VERSION_COLUMN_NAME    IN VARCHAR2,
                                 PI_ENT_INTERN_ID_COL_NAME IN VARCHAR2,
                                 pi_ent_seq_name           IN VARCHAR2,
                                 PI_AV_COL_NAME            IN VARCHAR2,
                                 /*   PO_ROW_ID_MAX_VALUE       OUT NUMBER,*/ ---in crete to be handled in teh dump table removing now
                                 /*    PO_AV_COUNT               OUT NUMBER,*/ ---to be set by sp hence removing
                                 pi_process_id     IN varchar2,
                                 PI_MODE           IN VARCHAR2, --1 insert, 2 update
                                 PI_DEST_TABLE     IN VARCHAR2,
                                 PI_DEST_TABLES_ID IN NUMBER,
                                 /* PI_INPUT_SIZE IN VARCHAR2,*/ --requireed in future , commented for now
                                 PI_Effective_Start IN VARCHAR2, --DON'T PASS IN KEY
                                 PI_Effective_End   IN VARCHAR2,
                                 /*   PI_Is_Period       IN number, --CAN BE CACULATED AS WELL*/
                                 PI_TU_ID                       IN NUMBER,
                                 PI_TABLES_RECORD_DATING_OPTION IN NUMBER,
                                 PI_DL_DEF_ID                   IN NUMBER,
                                 PI_INPUT_COUNT                 IN NUMBER DEFAULT NULL,
                                 PI_SOURCE_FILE_COUNT           IN NUMBER DEFAULT 1,
                                 PI_RUN_ID                      IN NUMBER DEFAULT NULL,
                                 po_update_count                OUT NUMBER,
                                 po_insert_count                OUT NUMBER,
                                 PO_closed_dates_Count          OUT NUMBER,
                                 PO_FILTER_COUNT                OUT NUMBER, --will be used in recrete mode
                                 po_status                      OUT NUMBER,
                                 po_QI_TABLE                    OUT VARCHAR2,
                                 po_SHRINK_FLAG                 OUT NUMBER,
                                 PI_ADD_LOG_INFO                IN COLTYPE_KEY_VALUE default null,
                                 PI_SEQ_RESET_FLAG              in number default 1) is
    v_char varchar2(30) := null;
  begin
    ValidationAndPosting(PI_DUMP_TABLE                  => PI_DUMP_TABLE,
                         PI_KEY_COLUMNS                 => PI_KEY_COLUMNS,
                         PI_AV_GENERATED_BY_SW          => PI_AV_GENERATED_BY_SW,
                         PI_AGGREGATE                   => PI_AGGREGATE,
                         PI_DATA_COLUMNS                => PI_DATA_COLUMNS,
                         PI_AGGREGATION_ORDER           => PI_AGGREGATION_ORDER,
                         PI_FLT_JOIN_CONDITIONS         => PI_FLT_JOIN_CONDITIONS,
                         PI_FLT_WHERE_CONDITIONS        => PI_FLT_WHERE_CONDITIONS,
                         PI_ID_COLUMN_NAME              => PI_ID_COLUMN_NAME,
                         PI_SEQ_USED_FOR_ID             => PI_SEQ_USED_FOR_ID,
                         PI_VERSION_COLUMN_NAME         => PI_VERSION_COLUMN_NAME,
                         PI_ENT_INTERN_ID_COL_NAME      => PI_ENT_INTERN_ID_COL_NAME,
                         pi_ent_seq_name                => pi_ent_seq_name,
                         PI_AV_COL_NAME                 => PI_AV_COL_NAME,
                         pi_process_id                  => pi_process_id,
                         PI_MODE                        => PI_MODE,
                         PI_DEST_TABLE                  => PI_DEST_TABLE,
                         PI_DEST_TABLES_ID              => PI_DEST_TABLES_ID,
                         PI_Effective_Start             => PI_Effective_Start,
                         PI_Effective_End               => PI_Effective_End,
                         PI_TU_ID                       => PI_TU_ID,
                         PI_TABLES_RECORD_DATING_OPTION => PI_TABLES_RECORD_DATING_OPTION,
                         PI_DL_DEF_ID                   => PI_DL_DEF_ID,
                         PI_INPUT_COUNT                 => PI_INPUT_COUNT,
                         PI_SOURCE_FILE_COUNT           => PI_SOURCE_FILE_COUNT,
                         PI_RUN_ID                      => PI_RUN_ID,
                         po_update_count                => po_update_count,
                         po_insert_count                => po_insert_count,
                         PO_closed_dates_Count          => PO_closed_dates_Count,
                         PO_FILTER_COUNT                => PO_FILTER_COUNT,
                         po_status                      => po_status,
                         po_QI_TABLE                    => po_QI_TABLE,
                         po_SHRINK_FLAG                 => po_SHRINK_FLAG,
                         PIO_DUPLICATE_TABLE            => v_char,
                         PI_ADD_LOG_INFO                => PI_ADD_LOG_INFO,
                         PI_SEQ_RESET_FLAG              => PI_SEQ_RESET_FLAG);

  end;

  PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE          IN VARCHAR2,
                           pi_QI_TABLE            IN VARCHAR2,
                           pi_MODE                IN VARCHAR2,
                           pi_KEY_COLUMNS         IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_DEST_TABLE          IN VARCHAR2,
                           pi_IS_AUTO_VALUED      IN NUMBER,
                           pi_av_generated_by_sw  IN NUMBER,
                           pi_av_col_name         VARCHAR2,
                           pi_AGGREGATE           IN NUMBER,
                           pi_DATA_COLUMNS        IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER   IN VARCHAR2,
                           pi_WHERE_CONDITIONS    IN VARCHAR2,
                           pi_id_column_name      VARCHAR2 default null,
                           pi_version_column_name VARCHAR2 default null,
                           PI_ADD_LOG_INFO        IN COLTYPE_KEY_VALUE default null,
                           PI_SEQ_USED_FOR_ID     in varchar2 default null,
                           PI_INPUT_COUNT         in number default null) is
    v_char varchar2(30) := null;
  begin
    DL_QI_CREATION(pi_DUMP_TABLE          => pi_DUMP_TABLE,
                   pi_QI_TABLE            => pi_QI_TABLE,
                   pi_MODE                => pi_MODE,
                   pi_KEY_COLUMNS         => pi_KEY_COLUMNS,
                   pi_DEST_TABLE          => pi_DEST_TABLE,
                   pi_IS_AUTO_VALUED      => pi_IS_AUTO_VALUED,
                   pi_av_generated_by_sw  => pi_av_generated_by_sw,
                   pi_av_col_name         => pi_av_col_name,
                   pi_AGGREGATE           => pi_AGGREGATE,
                   pi_DATA_COLUMNS        => pi_DATA_COLUMNS,
                   pi_AGGREGATION_ORDER   => pi_AGGREGATION_ORDER,
                   pi_WHERE_CONDITIONS    => pi_WHERE_CONDITIONS,
                   PIO_DUPLICATE_TABLE    => v_char,
                   pi_id_column_name      => pi_id_column_name,
                   pi_version_column_name => pi_version_column_name,
                   PI_ADD_LOG_INFO        => PI_ADD_LOG_INFO,
                   PI_SEQ_USED_FOR_ID     => PI_SEQ_USED_FOR_ID,
                   PI_INPUT_COUNT         => PI_INPUT_COUNT);
  end;

  PROCEDURE DL_QI_CREATION(pi_DUMP_TABLE             IN VARCHAR2, -- Dump table name
                           pi_QI_TABLE               IN VARCHAR2, -- QI table name
                           pi_KEY_COLUMNS            IN TABLETYPE_DL_KEY_COL_MAP,
                           pi_av_generated_by_sw     IN NUMBER, --auto-value column
                           pi_AGGREGATE              IN NUMBER, --specifies whether we need to perform aggregation or not
                           pi_DATA_COLUMNS           IN TABLETYPE_DL_DATA_COL_MAP,
                           pi_AGGREGATION_ORDER      IN VARCHAR2,
                           pi_WHERE_CONDITIONS       IN VARCHAR2, -- the where clause is needed to ignore the rejected records i.e the records failed the validations above.
                           pi_id_column_name         VARCHAR2,
                           pi_seq_used_for_id        VARCHAR2,
                           pi_version_column_name    VARCHAR2,
                           pi_ent_intern_id_col_name VARCHAR2,
                           pi_av_col_name            VARCHAR2,
                           po_row_id_max_value       out number,
                           po_COUNT                  out number,
                           po_av_count               out number,
                           pi_reset_sequence         in number default 0,
                           PI_ADD_LOG_INFO           IN COLTYPE_KEY_VALUE default null,
                           PI_INPUT_COUNT            in number default null /*,
                                                      PI_SEQ_RESET_FLAG         in number default 1*/) is
    v_char varchar2(30) := null;
  begin
    DL_QI_CREATION(pi_DUMP_TABLE             => pi_DUMP_TABLE,
                   pi_QI_TABLE               => pi_QI_TABLE,
                   pi_KEY_COLUMNS            => pi_KEY_COLUMNS,
                   pi_av_generated_by_sw     => pi_av_generated_by_sw,
                   pi_AGGREGATE              => pi_AGGREGATE,
                   pi_DATA_COLUMNS           => pi_DATA_COLUMNS,
                   pi_AGGREGATION_ORDER      => pi_AGGREGATION_ORDER,
                   pi_WHERE_CONDITIONS       => pi_WHERE_CONDITIONS,
                   pi_id_column_name         => pi_id_column_name,
                   pi_seq_used_for_id        => pi_seq_used_for_id,
                   pi_version_column_name    => pi_version_column_name,
                   pi_ent_intern_id_col_name => pi_ent_intern_id_col_name,
                   pi_av_col_name            => pi_av_col_name,
                   po_row_id_max_value       => po_row_id_max_value,
                   po_COUNT                  => po_COUNT,
                   po_av_count               => po_av_count,
                   PIO_DUPLICATE_TABLE       => v_char,
                   pi_reset_sequence         => pi_reset_sequence,
                   PI_ADD_LOG_INFO           => PI_ADD_LOG_INFO,
                   PI_INPUT_COUNT            => PI_INPUT_COUNT /*,
                                      PI_SEQ_RESET_FLAG         => PI_SEQ_RESET_FLAG*/);
  end;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************



END COMMONS_DATALOADPROCESSING;
/
