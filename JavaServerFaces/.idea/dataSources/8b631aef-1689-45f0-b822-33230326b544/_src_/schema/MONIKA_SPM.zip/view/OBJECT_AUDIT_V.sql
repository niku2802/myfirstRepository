CREATE VIEW OBJECT_AUDIT_V AS SELECT OA_RECORD_ADJUSTMENT_TIME,
                                 ADJUSTED_BY,
                                 ADJUSTED_BY_FULL_NAME,
                                 OA_DEFINITION_ID,
                                 case when OA_DEFINITION_TYPE = 64 then 4 else case when  OA_DEFINITION_TYPE = 77 then 36 else OA_DEFINITION_TYPE end end OA_DEFINITION_TYPE,
                                 NVL(OREG.OBJECT_NAME,T.OBJECT_NAME) OBJECT_NAME,
                                 NVL(OREG.definition_type_name,OBJECT_TYPE)  OBJECT_TYPE,
                                 OA_RECORD_ADJUSTMENT_LOCATION,
                                 OA_RECORD_ADJUSTMENT_TYPE,
                                 NVL(OREG.FOL_NAME,OA_FOL_NAME) OA_FOL_NAME,
                                 OA_FOL_ID,
                                 OA_HEADER_INFORMATION,
                                 OA_BEFORE,
                                 OA_AFTER,
                                 ROW_IDENTIFIER,
                                 ROW_VERSION,
                                 case when OR_LAST_UPDATED is not null AND OR_LAST_UPDATED = ROW_IDENTIFIER then 1 else 0 end OA_IS_LAST_UPDATE
                                 FROM OBJECT_AUDIT T
                                 left join (select nvl(OA_INNER.object_name, OREG_INNER.object_name) object_name,
                                                   OREG_INNER.fol_name fol_name,
                                                   OREG_INNER.definition_type_name definition_type_name,
                                                   OREG_INNER.or_id or_id,
                                                   OREG_INNER.OR_LAST_UPDATED OR_LAST_UPDATED
                                            from
                                           (select or1.or_name object_name ,or1.or_id or_id, or1.OR_LAST_UPDATED OR_LAST_UPDATED, null fol_name, def_type_name_singular definition_type_name
                                            from object_registration or1
                                            join definition_types on def_type_id = or1.or_type
                                            where or_container_id is null and or1.or_type not in (3,50,64,77)
                                            union all
                                            select or1.or_name object_name ,or1.or_id or_id, or1.OR_LAST_UPDATED OR_LAST_UPDATED, fol_name ||'('|| case when  fol_contained_obj_type_id = 53 then pa_name else ft_feature_name end||')' fol_name , def_type_name_singular definition_type_name
                                            from object_registration or1
                                            inner join object_registration or2 on or2.or_id = or1.or_container_id and or2.or_type = 3
                                            join definition_types on def_type_id = or1.or_type
                                            join folders on or2.or_id = fol_id
                                            left join features on fol_contained_obj_type_id  = ft_contained_object_type and fol_contained_obj_type_id <> 53 and ft_Feature_id not in (112,143)
                                            left join portal_applications on or2.or_container_id = pa_id
                                            where or1.or_type not in (3,50,64,77,115)
                                            union all
                                            select or1.or_name object_name ,or1.or_id or_id, or1.OR_LAST_UPDATED OR_LAST_UPDATED, null fol_name , def_type_name_singular || '('|| case when  fol_contained_obj_type_id = 53 then pa_name else ft_feature_name end||')' definition_type_name
                                            from object_registration or1
                                            join definition_types on def_type_id = or1.or_type
                                            join folders on or1.or_id = fol_id
                                            left join features on fol_contained_obj_type_id  = ft_contained_object_type and fol_contained_obj_type_id <> 53 and ft_Feature_id not in (112,143)
                                            left join portal_applications on or1.or_container_id = pa_id
                                            where or1.or_type =3
                                            union all
                                            select or1.or_name object_name,or1.or_id or_id, or1.OR_LAST_UPDATED OR_LAST_UPDATED,  null fol_name , def_type_name_singular || '('|| pa_name ||')' definition_type_name
                                            from object_registration or1
                                            join definition_types on def_type_id = or1.or_type
                                            join portal_folders on or1.or_id = pf_id
                                            join portal_applications on pf_pa_id = pa_id
                                            where or1.or_type = 50
                                            union all
                                            SELECT or1.or_name object_name,or1.or_id or_id, or1.OR_LAST_UPDATED OR_LAST_UPDATED, fol_name ||'('|| CASE WHEN  fol_contained_obj_type_id = 53 THEN pa_name ELSE ft_feature_name END||')' fol_name ,  def_type_name_singular definition_type_name
                                            FROM object_registration or1
                                            join versions on ver_object_id = or1.or_id
                                            INNER JOIN object_registration or2 ON or2.or_id = ver_base_object_id
                                            JOIN definition_types ON def_type_id = or2.or_type
                                            JOIN folders ON or2.or_container_id = fol_id
                                            LEFT JOIN features ON fol_contained_obj_type_id  = ft_contained_object_type AND fol_contained_obj_type_id <> 53 AND ft_Feature_id NOT IN (112,143)
                                            LEFT JOIN portal_applications ON or2.or_container_id = pa_id
                                            WHERE or1.or_type IN (64, 77)
                                            union all
                                            SELECT or1.or_name object_name,or1.or_id or_id, or1.OR_LAST_UPDATED OR_LAST_UPDATED,   fol_name ||'('||ft_feature_name ||')' fol_name ,def_type_name_singular  definition_type_name
                                            FROM object_registration or1
                                            JOIN definition_types ON def_type_id = or1.or_type
                                            JOIN folders ON or1.or_container_id = fol_id
                                            LEFT JOIN features ON fol_contained_obj_type_id  = ft_contained_object_type  AND ft_Feature_id NOT IN (112,143)
                                            WHERE or1.or_type = 115
                                            ) OREG_INNER
                                            left join OBJECT_AUDIT OA_INNER on ROW_IDENTIFIER = OR_LAST_UPDATED  and OA_DEFINITION_TYPE in (4,64, 96,36, 77)
                                            ) OREG ON OREG.or_id = OA_DEFINITION_ID
/
