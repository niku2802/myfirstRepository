CREATE VIEW INDEXING_METADATA_V AS SELECT index_metadata."INDEXED_COLUMNS",index_metadata."INDEX_NAME",index_metadata."CREATION_DATE",index_metadata."LAST_UPDATE_DATE",index_metadata."REQUESTOR", user_details."SES_OBJECT_NAME",user_details."USER_DEFINITION",user_details."LAST_USED_ON", unused_details."RUI_INDEX_NAME",unused_details."RUI_DEF_ID",unused_details."RUI_LAST_UPDATED_DATE"
  FROM (SELECT MAX(indexed_columns) indexed_columns,
               MAX(index_name) index_name,
               MIN(creation_date) creation_date,
               MIN(last_update_date) last_update_date,
               listagg(def_name, ',') within GROUP(ORDER BY NULL) requestor
          FROM (SELECT obr.or_name def_name, a.*
                  FROM (SELECT asim.asim_def_id definition_id,
                               index_usage.get_ind_col_list1(asim.asim_indexed_columns) indexed_columns,
                               asim.asim_index_name index_name,
                               asim.asim_creation_date creation_date,
                               asim.asim_last_update_date last_update_date
                          FROM app_specific_indexes_metadata asim
                        UNION ALL
                        SELECT aim.aim_def_id,
                               index_usage.get_ind_col_list(aim.aim_indexed_columns),
                               aim.aim_index_name,
                               aim.aim_creation_date,
                               aim.aim_last_update_date
                          FROM application_indexes_metadata aim) a
                  LEFT OUTER JOIN object_registration obr
                    ON obr.or_id = a.definition_id)
         GROUP BY index_name) index_metadata
  LEFT OUTER JOIN
 (SELECT ses_object_name,
          listagg(user_definition, ',') within GROUP(ORDER BY NULL) user_definition,
          MAX(last_used_on) last_used_on
    FROM (SELECT obr.or_name user_definition,
                  obr.or_id,
                  ses.ses_object_name,
                  last_used_on
             FROM sql_execution_stats ses
             LEFT OUTER JOIN (SELECT tqp_sql_id          sql_id,
                                    NULL                run_id,
                                    tqp_object_id       definition_id,
                                    tqp_last_usage_time last_used_on
                               FROM table_query_plans
                             UNION ALL
                             SELECT NULL                      sql_id,
                                    rd_id,
                                    rd_definition_id          definition_id,
                                    rsd.rs_execution_end_time last_used_on
                               FROM run_data rd
                              INNER JOIN run_status_data rsd
                                 ON rsd.rs_id = rd.rd_id
                             ) b
               ON (b.sql_id = ses.ses_sql_id OR b.run_id = ses.ses_run_id)
             LEFT OUTER JOIN object_registration obr
               ON obr.or_id = b.definition_id) user_internal
   GROUP BY ses_object_name) user_details
    ON ses_object_name = index_metadata.index_name
  LEFT OUTER JOIN (SELECT rui_index_name,
                          listagg(rui_def_id, ',') within GROUP(ORDER BY NULL) rui_def_id,
                          MAX(rui_last_updated_date) rui_last_updated_date
                     FROM report_unused_indexes
                     group by rui_index_name) unused_details
    ON unused_details.rui_index_name = index_metadata.index_name
/
