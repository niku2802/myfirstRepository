CREATE VIEW LOG_DETAILS_V AS select LMD_TEXT as DETAIL_TEXT
                                                                       ,LMD_ORDER as DETAIL_ORDER
                                                                       ,LMD_LM_ID as ROW_IDENTIFIER
                                                                       ,cast(null as number(10)) as ROW_VERSION
                                                                   from LOGS_MESSAGE_DETAILS
/
