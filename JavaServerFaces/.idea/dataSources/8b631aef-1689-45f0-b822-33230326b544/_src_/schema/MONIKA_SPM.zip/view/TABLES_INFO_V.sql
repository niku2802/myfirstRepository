CREATE VIEW TABLES_INFO_V AS SELECT T.TABLES_ID              AS TABLE_ID,
       T.TABLES_PHYSICAL_NAME   AS TABLE_PHYSICAL_NAME,
       A.TABLE_DESC,
       CASE WHEN A.DEF_TYPE IS NOT NULL THEN A.DEF_TYPE
            WHEN T.TABLES_TYPE IN ('SYSTEM_TABLE', 'ALERT_MESSAGES_V', 'LOGIN_HISTORY','USER_TABLE','PORTAL_USAGE') THEN T.TABLES_TYPE
            ELSE 'NEW_OR_INVALID: '||T.TABLES_TYPE
       END AS DEF_TYPE,
       A.DEF_ID,
       A.DEF_NAME,
       F.FOL_NAME AS DEF_FOLDER_NAME
FROM         TABLES                   T
LEFT  JOIN
    (   -- ENTITY - ENTITY_TABLES
        SELECT 'ENTITY'                    AS DEF_TYPE,
            E.ENTITY_FOL_ID                  AS DEF_FOL_ID,
            E.ENTITY_ID                      AS DEF_ID,
            E.ENTITY_NAME                    AS DEF_NAME,
            E.ENTITY_TABLES_ID               AS TABLE_ID,
            'ENTITY_TABLE'                 AS TABLE_DESC
        FROM ENTITIES E
        WHERE ENTITY_BASE_ENTITY IS NULL
        -- ENTITY_ASSIGNMENT - ENTITY_ASSIGNMENT_TABLE
        UNION ALL
        SELECT   'ENTITY_ASSIGNMENT'        DEF_TYPE
                ,EA_FOL_ID                  DEF_FOL_ID
                ,EA_ID                      DEF_ID
                ,EA_NAME                    DEF_NAME
                ,EA_TABLES_ID               TABLE_ID
                ,'<LE: '||COMMONS_APPFRAMEWORK.GET_NAME(LE.ENTITY_NAME)||' ('||TO_CHAR(LE.ENTITY_ID)||')> '
                 ||'<SE: '||SE.ENTITY_NAMES||'>' TABLE_DESC
        FROM ENTITY_ASSIGNMENTS
            INNER JOIN ENTITIES LE ON EA_ENTITY_ID_LA = LE.ENTITY_ID
            INNER JOIN
            (   SELECT   SA_EA_ID
                        ,LISTAGG(COMMONS_APPFRAMEWORK.GET_NAME(RE.ENTITY_NAME)||' ('||TO_CHAR(RE.ENTITY_ID)||')', ', ') WITHIN GROUP (ORDER BY SA.SA_ORDER) ENTITY_NAMES
                FROM    SECONDARY_ASSIGNMENTS SA
                        INNER JOIN ENTITIES RE ON SA.SA_ENTITY_ID = RE.ENTITY_ID
                GROUP BY SA_EA_ID
            ) SE ON EA_ID = SA_EA_ID
        WHERE EA_TABLES_ID IS NOT NULL
        UNION ALL
        -- ENTITY - ENTITY_TO_PLAN_ROSTERS
        SELECT   'ENTITY'                 DEF_TYPE
                ,ENTITY_FOL_ID              DEF_FOL_ID
                ,ENTITY_ID                  DEF_ID
                ,ENTITY_NAME                DEF_NAME
                ,TABLES_ID                  TABLE_ID
                ,'ENTITY_TO_PLAN_ROSTER'  TABLE_DESC
        FROM    CATEGORY_RELATIONSHIPS
                INNER JOIN TABLES ON CR_DEFINITION_ID = TABLES_ID
                INNER JOIN TABLE_COLUMNS ON TABLES_ID = TC_TABLES_ID AND TC_LOGIC_TYPE = 1 AND TC_COLUMN_TYPE = 1
                INNER JOIN ENTITIES ON TC_ENTITY_ID = ENTITY_ID
        WHERE CR_CD_ID = 12
        UNION ALL
        -- DATA_TABLE - TABLES
        SELECT 'DATA_TABLE'                AS DEF_TYPE,
            DT.DT_FOL_ID                     AS DEF_FOL_ID,
            DT.DT_ID                         AS DEF_ID,
            DT.DT_NAME                       AS DEF_NAME,
            DT.DT_TABLES_ID                  AS TABLE_ID,
            NULL                             AS TABLE_DESC
        FROM DATA_TABLES DT
        UNION ALL
    -- HIERARCHY - TABLES
        SELECT 'HIERARCHY'                 AS DEF_TYPE,
            HT.HT_FOL_ID                     AS DEF_FOL_ID,
            HT.HT_ID                         AS DEF_ID,
            HT.HT_NAME                       AS DEF_NAME,
            HR.HR_TABLE_ID                   AS TABLE_ID,
            'LOWER ENTITY NAME: '|| COMMONS_APPFRAMEWORK.GET_NAME(LE.ENTITY_NAME) || '; LOWER ENTITY ID: ' ||TO_CHAR(LE.ENTITY_ID)||';'||
            'UPPER ENTITY NAME: '|| COMMONS_APPFRAMEWORK.GET_NAME(HE.ENTITY_NAME) || '; UPPER ENTITY ID: ' ||TO_CHAR(HE.ENTITY_ID)||';' AS TABLE_DESC
        FROM       HIERARCHY_RELATIONSHIP   HR
        INNER JOIN HIERARCHY_STRUCTURE      HS  ON HR.HR_HS_ID = HS.HS_ID
        INNER JOIN HIERARCHY_TABLES         HT  ON HS.HS_HT_ID = HT.HT_ID
        INNER JOIN ENTITIES                         LE  ON HR_LOWER_ENTITY_ID = LE.ENTITY_ID
        INNER JOIN ENTITIES                         HE  ON HR_HIGHER_ENTITY_ID = HE.ENTITY_ID
        UNION ALL
        -- WORKFLOW_APPLICATION - REQUESTS_TABLES
        SELECT 'WORKFLOW_APPLICATION'      AS DEF_TYPE,
            NULL                             AS DEF_FOL_ID,
            WA.WA_ID                         AS DEF_ID,
            WA.WA_NAME                       AS DEF_NAME,
            WA.WA_REQUESTS_TABLES_ID         AS TABLE_ID,
            'REQUESTS_TABLE'               AS TABLE_DESC
        FROM WORKFLOW_APPLICATIONS WA
        UNION ALL
        -- WORKFLOW_APPLICATION - REQUESTS_VIEWS
        SELECT 'WORKFLOW_APPLICATION'      AS DEF_TYPE,
            NULL                             AS DEF_FOL_ID,
            WA.WA_ID                         AS DEF_ID,
            WA.WA_NAME                       AS DEF_NAME,
            WA.WA_REQUESTS_VIEW_ID           AS TABLE_ID,
            'REQUESTS_VIEW'                AS TABLE_DESC
        FROM WORKFLOW_APPLICATIONS WA
        UNION ALL
        -- WORKFLOW_APPLICATION - TASKS_TABLES
        SELECT 'WORKFLOW_APPLICATION'      AS DEF_TYPE,
            NULL                             AS DEF_FOL_ID,
            WA.WA_ID                         AS DEF_ID,
            WA.WA_NAME                       AS DEF_NAME,
            WA.WA_TASKS_TABLES_ID            AS TABLE_ID,
            'TASKS_TABLE'                  AS TABLE_DESC
        FROM WORKFLOW_APPLICATIONS WA
        UNION ALL
        -- WORKFLOW_APPLICATION - TASKS_VIEWS
        SELECT 'WORKFLOW_APPLICATION'      AS DEF_TYPE,
            NULL                             AS DEF_FOL_ID,
            WA.WA_ID                         AS DEF_ID,
            WA.WA_NAME                       AS DEF_NAME,
            WA.WA_TASKS_VIEW_ID              AS TABLE_ID,
            'TASKS_VIEW'                   AS TABLE_DESC
        FROM WORKFLOW_APPLICATIONS WA
        /*UNION ALL
        -- WORKFLOW_APPLICATION - ATTACHMENTS_TABLES
        SELECT 'WORKFLOW_APPLICATION'      AS DEF_TYPE,
            NULL                             AS DEF_FOL_ID,
            WA.WA_ID                         AS DEF_ID,
            WA.WA_NAME                       AS DEF_NAME,
            WA.WA_ATTACHMENTS_TABLES_ID      AS TABLE_ID,
            'ATTACHMENTS_TABLE'            AS TABLE_DESC
        FROM WORKFLOW_APPLICATIONS WA */
        UNION ALL
        -- AUDIT - TABLES
        SELECT 'AUDIT'                     AS DEF_TYPE,
            OJ.OR_CONTAINER_ID               AS DEF_FOL_ID,
            A.AT_AUDITED_TABLES_ID           AS DEF_ID,
            COMMONS_APPFRAMEWORK.GET_NAME(OJ.OR_NAME) AS DEF_NAME,
            A.AT_AUDIT_TABLES_ID             AS TABLE_ID,
            NULL                             AS TABLE_DESC
        FROM      AUDIT_TABLES        A
        LEFT JOIN OBJECT_REGISTRATION OJ ON A.AT_AUDIT_TABLES_ID = OJ.OR_ID
        UNION ALL
        -- ACCEPTANCE_AGREEMENT - TABLES
        SELECT 'ACCEPTANCE_AGREEMENT'      AS DEF_TYPE,
            AA.AA_FOLDER_ID                  AS DEF_FOL_ID,
            AA.AA_ID                         AS DEF_ID,
            AA.AA_NAME                       AS DEF_NAME,
            AA.AA_VIEW_ID                    AS TABLE_ID,
            NULL                             AS TABLE_DESC
        FROM ACCEPTANCE_AGREEMENTS AA
        UNION ALL
        -- REPORT_LIST - TABLES
        SELECT 'REPORT_LIST'               AS DEF_TYPE,
            RL.REP_LISTS_FOL_ID              AS DEF_FOL_ID,
            RL.REP_LISTS_ID                  AS DEF_ID,
            RL.REP_LISTS_NAME                AS DEF_NAME,
            RL.REP_LISTS_TABLES_ID           AS TABLE_ID,
            NULL                             AS TABLE_DESC
        FROM REPORT_LISTS RL
        UNION ALL
        -- DATA_TRANSFORMATION_PROCESS - OUTPUTS
        SELECT 'DATA_TRANSFORMATION_PROCESS' AS DEF_TYPE,
            DP.DTP_FOLDER_ID                   AS DEF_FOL_ID,
            DP.DTP_ID                          AS DEF_ID,
            DP.DTP_NAME                        AS DEF_NAME,
            DTRT.DTRT_TABLES_ID                AS TABLE_ID,
            'OUTPUT_TABLE <OP_ORDER:'||DOP.DTO_ORDER||'> <OP_NAME:'||DOP.DTO_NAME||'><OP_TYPE:'||DTOPT.DTOPT_NAME||'><OUTPUT_TYPE:'||OT.DTOUTT_NAME||'>'   AS TABLE_DESC
        FROM        DT_RESULT_TABLES DTRT
        INNER JOIN DT_OUTPUTS       DO   ON DTRT.DTRT_DTOUT_ID = DO.DTOUT_ID
        LEFT JOIN DT_OUTPUT_TYPES OT ON DO.DTOUT_DTOUTT_ID = OT.DTOUTT_ID
        INNER JOIN DT_OPERATIONS    DOP  ON DO.DTOUT_DTO_ID = DOP.DTO_ID
        LEFT JOIN DT_OPERATION_TYPES DTOPT ON DOP.DTO_DTOPT_ID = DTOPT.DTOPT_ID
        INNER JOIN DT_PROCESSES     DP   ON DOP.DTO_DTP_ID = DP.DTP_ID
        UNION ALL
        -- OBJECTIVE_DEFINITION - PERIODS_TABLES
        SELECT  'OBJECTIVE_DEFINITION'       AS DEF_TYPE
                ,OBD_FOL_ID                    AS DEF_FOL_ID
                ,OBD_ID                        AS DEF_ID
                ,OBD_NAME                      AS DEF_NAME
                ,OBD_PERIODS_TABLES_ID         AS TABLE_ID
                ,'PERIODS_TABLE'             AS TABLE_DESC
        FROM OBJ_DEFINITIONS
        WHERE OBD_PERIODS_TABLES_ID IS NOT NULL
        UNION ALL
        -- OBJECTIVE_DEFINITION - ENTITIES_TABLES
        SELECT  'OBJECTIVE_DEFINITION'       AS DEF_TYPE
                ,OBD_FOL_ID                    AS DEF_FOL_ID
                ,OBD_ID                        AS DEF_ID
                ,OBD_NAME                      AS DEF_NAME
                ,OBD_ENTITIES_TABLES_ID        AS TABLE_ID
                ,'ENTITIES_TABLE <'||ENTITY_NAME||'>' AS TABLE_DESC
        FROM OBJ_DEFINITIONS
            LEFT JOIN ENTITIES ON OBD_ENTITY_ID = ENTITY_ID
        WHERE OBD_ENTITIES_TABLES_ID IS NOT NULL
        UNION ALL
        -- OBJECTIVE_DEFINITION - OBJECTIVES_TABLES
        SELECT  'OBJECTIVE_DEFINITION'       AS DEF_TYPE
                ,OBD_FOL_ID                    AS DEF_FOL_ID
                ,OBD_ID                        AS DEF_ID
                ,OBD_NAME                      AS DEF_NAME
                ,OBD_OBJECTIVES_TABLES_ID      AS TABLE_ID
                ,'OBJECTIVES_TABLE'          AS TABLE_DESC
        FROM OBJ_DEFINITIONS
        WHERE OBD_OBJECTIVES_TABLES_ID IS NOT NULL
        UNION ALL
        -- ALIGNMENT_LOGIC - RESULT_TABLES
        SELECT   'ALIGNMENT_LOGIC' AS DEF_TYPE
                ,ALIGNMENT_FOL_ID    AS DEF_FOL_ID
                ,AD.ALIGNMENT_ID     AS DEF_ID
                ,ALIGNMENT_NAME      AS DEF_NAME
                ,TABLE_ID
                ,TABLE_DESC
        FROM    ALIGNMENT_DEFINITIONS AD
                INNER JOIN
                (   SELECT   AR_ALIGNMENT_ID ALIGNMENT_ID
                            ,AR_ALIGNMENT_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Aligned Records>' TABLE_DESC
                    FROM    ALIGNMENT_RESULTS
                    WHERE   AR_ALIGNMENT_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   AR_ALIGNMENT_ID ALIGNMENT_ID
                            ,AR_OVERLAPPING_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Overlapping Records>' TABLE_DESC
                    FROM    ALIGNMENT_RESULTS
                    WHERE   AR_OVERLAPPING_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   AR_ALIGNMENT_ID ALIGNMENT_ID
                            ,AR_CONTRADICTORY_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Conflicting Records>' TABLE_DESC
                    FROM    ALIGNMENT_RESULTS
                    WHERE   AR_CONTRADICTORY_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   AR_ALIGNMENT_ID ALIGNMENT_ID
                            ,AR_DUAL_ALIGNMENT_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Multiple Aligned Records>' TABLE_DESC
                    FROM    ALIGNMENT_RESULTS
                    WHERE   AR_DUAL_ALIGNMENT_TABLES_ID IS NOT NULL
                ) RT ON AD.ALIGNMENT_ID = RT.ALIGNMENT_ID
        UNION ALL
        -- CREDITING_RULE - RESULT_TABLES
        SELECT   'CREDITING_RULE'  AS DEF_TYPE
                ,CREDITING_FOL_ID    AS DEF_FOL_ID
                ,CD.CREDITING_ID     AS DEF_ID
                ,CREDITING_NAME      AS DEF_NAME
                ,TABLE_ID
                ,TABLE_DESC
        FROM    CREDITING_DEFINITIONS CD
                INNER JOIN
                (   SELECT   CAR_CREDITING_ID CREDITING_ID
                            ,CAR_ALIGNMENT_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Aligned Records>' TABLE_DESC
                    FROM    CREDITING_ALIGNMENT_RESULTS
                    WHERE   CAR_ALIGNMENT_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   CAR_CREDITING_ID CREDITING_ID
                            ,CAR_OVERLAPPING_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Overlapping Records>' TABLE_DESC
                    FROM    CREDITING_ALIGNMENT_RESULTS
                    WHERE   CAR_OVERLAPPING_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   CAR_CREDITING_ID CREDITING_ID
                            ,CAR_CONTRADICTORY_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Conflicting Records>' TABLE_DESC
                    FROM    CREDITING_ALIGNMENT_RESULTS
                    WHERE   CAR_CONTRADICTORY_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   CAR_CREDITING_ID CREDITING_ID
                            ,CAR_DUAL_ALIGNMENT_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Multiple Aligned Records>' TABLE_DESC
                    FROM    CREDITING_ALIGNMENT_RESULTS
                    WHERE   CAR_DUAL_ALIGNMENT_TABLES_ID IS NOT NULL
                    UNION ALL
                    SELECT   CRESULTS_CREDITING_ID CREDITING_ID
                            ,CRESULTS_TABLES_ID TABLE_ID
                            ,'RESULT_TABLE <Credited Data>' TABLE_DESC
                    FROM    CREDITING_RESULTS
                    WHERE   CRESULTS_TABLES_ID IS NOT NULL
                ) RT ON CD.CREDITING_ID = RT.CREDITING_ID
        UNION ALL
        -- PLAN - OUTPUT_TABLES
        SELECT  'PLAN'                       AS DEF_TYPE,
                PD_FOL_ID                      AS DEF_FOL_ID,
                PD_ID                          AS DEF_ID,
                PD_NAME                        AS DEF_NAME,
                TABLE_ID                       AS TABLE_ID,
                'OUTPUT_TABLE <'||COMMONS_APPFRAMEWORK.GET_NAME(VER_NAME)||'> <'||PARENT_TYPE||'>'
                 ||CASE WHEN PARENT_TYPE <> 'PLAN_VERSION' THEN ' <'||PARENT_NAME||'> <'||TO_CHAR(PARENT_ID)||'>' ELSE NULL END
                 ||' <'||RESULT_TYPE||'>' TABLE_DESC
        FROM
            PLAN_DEFINITIONS
            INNER JOIN VERSIONS ON PD_ID = VER_BASE_OBJECT_ID
            INNER JOIN
            (    SELECT VER_OBJECT_ID PLAN_VERSION_ID, 'PLAN_VERSION' PARENT_TYPE, VER_OBJECT_ID PARENT_ID, COMMONS_APPFRAMEWORK.GET_NAME(VER_NAME) PARENT_NAME
                FROM VERSIONS
                WHERE VER_DEF_TYPE_ID = 64

                UNION ALL
                SELECT PCD_VER_OBJECT_ID, 'COMPONENT', PCD_ID, PCD_NAME
                FROM PLAN_COMPONENT_DEFINITIONS

                UNION ALL
                SELECT PM_VER_OBJECT_ID, 'METRIC', PM_ID, PM_NAME
                FROM PLAN_METRICS
            ) RESULT_PARENTS ON VER_OBJECT_ID = PLAN_VERSION_ID
            INNER JOIN
            (    SELECT PRRT_DEFINITION_ID RESULT_PARENT_ID
                    ,CASE    WHEN PRRT_PROCESS_TYPE IN (1, 2) THEN 'PLAN_VERSION'
                            WHEN PRRT_PROCESS_TYPE IN (3) THEN 'COMPONENT'
                            WHEN PRRT_PROCESS_TYPE IN (4, 5) THEN 'METRIC'
                            ELSE NULL END RESULT_PARENT_TYPE
                    ,CASE    WHEN PRRT_PROCESS_TYPE = 1 AND PRRT_NUMBER = 1 THEN 'Earnings Roster'
                            WHEN PRRT_PROCESS_TYPE = 1 AND PRRT_NUMBER = 2 THEN 'Earnings to Payments Roster'
                            WHEN PRRT_PROCESS_TYPE = 2 THEN 'Payments'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 1 THEN 'Detailed Earnings'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 2 THEN 'Aggregated Earnings'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 3 THEN 'Modified Earnings'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 4 THEN 'Component Earnings'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 5 THEN 'Payments By Component'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 6 THEN 'Detailed Tier Earnings'
                            WHEN PRRT_PROCESS_TYPE = 3 AND PRRT_NUMBER = 7 THEN 'Detailed Modified Earnings'
                            WHEN PRRT_PROCESS_TYPE = 4 THEN 'Metric'
                            WHEN PRRT_PROCESS_TYPE = 5 THEN 'Metric Modifier'
                            END RESULT_TYPE
                    ,PRRT_TABLES_ID TABLE_ID
                FROM PROCESS_RESULT_TABLES
                WHERE PRRT_TABLES_ID IS NOT NULL
            ) RESULT_TABLES ON PARENT_TYPE = RESULT_PARENT_TYPE AND PARENT_ID = RESULT_PARENT_ID
        -- PLAN - RESULT_VIEWS
        UNION ALL
        SELECT  'PLAN'                     AS DEF_TYPE,
                PD_FOL_ID                    AS DEF_FOL_ID,
                PD_ID                        AS DEF_ID,
                PD_NAME                      AS DEF_NAME,
                TABLES_ID                    AS TABLE_ID,
                'RESULT_VIEW <'||TABLES_NAME||'>' AS TABLE_DESC
        FROM
            PLAN_DEFINITIONS
            INNER JOIN CATEGORY_RELATIONSHIPS ON CR_CD_ID = 6 AND PD_ID = CR_PARENT_DEFINITION_ID
            INNER JOIN TABLES ON CR_DEFINITION_ID = TABLES_ID
        -- PLAN - PROCESSING_ROSTERS
        UNION ALL
        SELECT   'PLAN'                   AS DEF_TYPE
                ,PD_FOL_ID                  AS DEF_FOL_ID
                ,PD_ID                      AS DEF_ID
                ,PD_NAME                    AS DEF_NAME
                ,PPO_ROSTER_TABLE_ID        AS TABLE_ID
                ,'PROCESSING_ROSTER'      AS TABLE_DESC
        FROM    PLAN_DEFINITIONS
                INNER JOIN PLAN_PROCESSING_OPTIONS ON PD_ID = PPO_PD_ID
        WHERE   PPO_ROSTER_TABLE_ID IS NOT NULL
        -- PLAN - PARAMETER_TABLES
        UNION ALL
        SELECT  'PLAN'                     AS DEF_TYPE,
                PD_FOL_ID                    AS DEF_FOL_ID,
                PD_ID                        AS DEF_ID,
                PD_NAME                      AS DEF_NAME,
                TABLE_ID                     AS TABLE_ID,
                'PARAMETER_TABLE <'||COMMONS_APPFRAMEWORK.GET_NAME(VER_NAME)||'> <'||PARENT_TYPE||'>'
                 ||CASE WHEN PARENT_TYPE <> 'PLAN_VERSION' THEN ' <'||PARENT_NAME||'> <'||TO_CHAR(PARENT_ID)||'>' ELSE NULL END
                 ||' <'||PARAM_TYPE||'>' TABLE_DESC
        FROM
            PLAN_DEFINITIONS
            INNER JOIN VERSIONS ON PD_ID = VER_BASE_OBJECT_ID
            INNER JOIN
            (    SELECT VER_OBJECT_ID PLAN_VERSION_ID, 'PLAN_VERSION' PARENT_TYPE, VER_OBJECT_ID PARENT_ID, COMMONS_APPFRAMEWORK.GET_NAME(VER_NAME) PARENT_NAME
                FROM VERSIONS
                WHERE VER_DEF_TYPE_ID = 64

                UNION ALL
                SELECT PCD_VER_OBJECT_ID, 'COMPONENT', PCD_ID, PCD_NAME
                FROM PLAN_COMPONENT_DEFINITIONS

                UNION ALL
                SELECT PM_VER_OBJECT_ID, 'METRIC', PM_ID, PM_NAME
                FROM PLAN_METRICS
            ) RESULT_PARENTS ON VER_OBJECT_ID = PLAN_VERSION_ID
            INNER JOIN
            (    SELECT PTET_VER_OBJECT_ID PARAM_PARENT_ID, 'PLAN_VERSION' PARAM_PARENT_TYPE, 'Plan Target Earnings' PARAM_TYPE, PTET_VALUES_TABLE_ID TABLE_ID
                FROM PLAN_TARGET_EARNINGS_TAB
                WHERE PTET_VALUES_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PTET_VER_OBJECT_ID, 'PLAN_VERSION', 'Component Weights', PTET_WEIGHTS_TABLE_ID
                FROM PLAN_TARGET_EARNINGS_TAB
                WHERE PTET_WEIGHTS_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PPMT_VER_OBJECT_ID,'PLAN_VERSION','Payment Adjustments', PPMT_ADJUSTMENT_TABLE_ID
                FROM PLAN_PAYMENTS_TAB
                WHERE PPMT_ADJUSTMENT_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PPMT_VER_OBJECT_ID, 'PLAN_VERSION', 'Payment Overrides', PPMT_OVERRIDE_TABLE_ID
                FROM PLAN_PAYMENTS_TAB
                WHERE PPMT_OVERRIDE_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PPMT_VER_OBJECT_ID, 'PLAN_VERSION'
                        ,CASE    WHEN PPMT_DRAW_OPTION = 0 THEN 'Guarantees'
                                WHEN PPMT_DRAW_OPTION = 1 THEN 'Recoverable Draws'
                                ELSE 'Other' END
                        ,PPMD_TABLE_ID
                FROM PLAN_PAYMENT_DRAWS
                    LEFT JOIN PLAN_PAYMENTS_TAB ON PPMD_PPMT_ID = PPMT_ID
                WHERE PPMD_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PCECT_PCD_ID, 'COMPONENT'
                        ,CASE    WHEN PCECT_OPTION = 1 THEN 'Step Lookup'
                                WHEN PCECT_OPTION = 2 THEN 'Continuous Lookup'
                                WHEN PCECT_OPTION = 3 THEN 'Discrete Lookup'
                                WHEN PCECT_OPTION = 5 THEN 'Commission Rates'
                                ELSE 'Other' END
                        ,PCECT_TABLE_ID
                FROM PLAN_COMP_EARNING_CALC_TAB
                WHERE PCECT_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PCECT_PCD_ID, 'COMPONENT'
                        ,CASE    WHEN PCECCR_COMMISSION_LOOKUP_TYPE = 1 THEN 'Commission Rate Step Lookup'
                                WHEN PCECCR_COMMISSION_LOOKUP_TYPE = 2 THEN 'Commission Rate Continuous Lookup'
                                WHEN PCECCR_COMMISSION_LOOKUP_TYPE = 3 THEN 'Commission Rate Discrete Lookup'
                                ELSE 'Other' END
                        ,PCECCR_LOOKUP_TABLE_ID
                FROM PLAN_COMP_EARNING_CALC_CM_RATE
                    LEFT JOIN PLAN_COMP_EARNING_CALC_TAB ON PCECT_ID = PCECCR_PCECT_ID
                WHERE PCECCR_LOOKUP_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PCTET_PCD_ID, 'COMPONENT', 'Target Earnings', PCTET_TABLE_ID
                FROM PLAN_COMP_TARGET_EARNINGS_TAB
                WHERE PCTET_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PCD_ID, 'COMPONENT', 'Eligibility Exceptions', PCD_ELIGIBLE_EARNING_TABLE_ID
                FROM PLAN_COMPONENT_DEFINITIONS
                WHERE PCD_ELIGIBLE_EARNING_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT PMC_PM_ID, 'METRIC'
                        ,CASE    WHEN PMC_METRIC_TYPE = 22 THEN 'Step Lookup'
                                WHEN PMC_METRIC_TYPE = 23 THEN 'Continuous Lookup'
                                WHEN PMC_METRIC_TYPE = 24 THEN 'Discrete Lookup'
                                ELSE 'Other Metric' END
                        ,PMCLC_TABLES_ID
                FROM PLAN_METRIC_CALCULATIONS
                    LEFT JOIN PLAN_MC_LOOKUP_CURVES ON PMCLC_PMC_ID = PMC_ID
                WHERE PMCLC_TABLES_ID IS NOT NULL

                UNION ALL
                SELECT PMC_PM_ID, 'METRIC', 'Baseline Prior Period Values', PMC_BASELINE_TABLE_ID
                FROM PLAN_METRIC_CALCULATIONS
                WHERE PMC_BASELINE_TABLE_ID IS NOT NULL

                UNION ALL
                SELECT     MOD_PARENT_ID, MOD_PARENT_TYPE
                        ,'Modifier '||TO_CHAR(MOD_ORDER)||' ('
                         ||CASE MOD_TYPE
                                  WHEN 0 THEN 'FLOOR(0)'
                                  WHEN 1 THEN 'CAP(1)'
                                  WHEN 2 THEN 'METRIC_HURDLE(2)'
                                  WHEN 3 THEN 'COMPONENT_EARNING_HURDLE(3)'
                                  WHEN 4 THEN 'METRIC_QUALIFIER(4)'
                                  WHEN 5 THEN 'COMPONENT_EARNING_QUALIFIER(5)'
                                  WHEN 6 THEN 'METRIC_ACCELERATOR(6)'
                                  WHEN 7 THEN 'COMPONENT_EARNING_ACCELERATOR(7)'
                                  WHEN 8 THEN 'METRIC_DECELERATOR(8)'
                                  WHEN 9 THEN 'COMPONENT_EARNING_DECELERATOR(9)'
                                  WHEN 10 THEN 'ADD(10)'
                                  WHEN 11 THEN 'SUBTRACT(11)'
                                  WHEN 12 THEN 'MULTIPLY(12)'
                                  WHEN 13 THEN 'DIVIDE(13)'
                                  WHEN 14 THEN 'SPLIT(14)'
                                  WHEN 15 THEN 'FACTOR(15)'
                                  WHEN 16 THEN 'ROUND(16)'
                                  WHEN 17 THEN 'ROUND_UP(17)'
                                  WHEN 18 THEN 'ROUND_DOWN(18)'
                                  ELSE 'Other'
                         END
                         ||') '||MOD_PARAM_TYPE
                        ,TABLE_ID
                FROM
                    (    SELECT PCECT_PCD_ID MOD_PARENT_ID, 'COMPONENT' MOD_PARENT_TYPE, PCECT_PMD_ID MOD_ID
                        FROM PLAN_COMP_EARNING_CALC_TAB

                        UNION ALL
                        SELECT PMC_PM_ID, 'METRIC', PMC_PMD_ID
                        FROM PLAN_METRIC_CALCULATIONS
                    ) M
                    INNER JOIN
                    (    SELECT     PMI_PMD_ID                        MOD_ID
                                ,PMI_ORDER                        MOD_ORDER
                                ,PMI_TYPE                        MOD_TYPE
                                ,'left side param table'        MOD_PARAM_TYPE
                                ,PMI_TABLE_ID                    TABLE_ID
                        FROM PLAN_MODIFIER_ITEMS
                        WHERE PMI_TABLE_ID IS NOT NULL

                        UNION ALL
                        SELECT     PMI_PMD_ID                        MOD_ID
                                ,PMI_ORDER                        MOD_ORDER
                                ,PMI_TYPE                        MOD_TYPE
                                ,'right side param table'        MOD_PARAM_TYPE
                                ,PMI_OUTPUT_TABLE_ID            TABLE_ID
                        FROM PLAN_MODIFIER_ITEMS
                        WHERE PMI_OUTPUT_TABLE_ID IS NOT NULL

                        UNION ALL
                        SELECT     PMI_PMD_ID                        MOD_ID
                                ,PMI_ORDER                        MOD_ORDER
                                ,PMI_TYPE                        MOD_TYPE
                                ,'left side lookup'                MOD_PARAM_TYPE
                                ,PL_TABLE_ID                    TABLE_ID
                        FROM PLAN_MODIFIER_ITEMS
                            LEFT JOIN PLAN_LOOKUPS ON PMI_INPUT_LOOKUP_ID = PL_ID
                        WHERE PL_TABLE_ID IS NOT NULL

                        UNION ALL
                        SELECT     PMI_PMD_ID                        MOD_ID
                                ,PMI_ORDER                        MOD_ORDER
                                ,PMI_TYPE                        MOD_TYPE
                                ,'right side lookup'            MOD_PARAM_TYPE
                                ,PL_TABLE_ID                    TABLE_ID
                        FROM PLAN_MODIFIER_ITEMS
                            LEFT JOIN PLAN_LOOKUPS ON PMI_OUTPUT_LOOKUP_ID = PL_ID
                        WHERE PL_TABLE_ID IS NOT NULL
                    ) MI ON M.MOD_ID = MI.MOD_ID
            ) PARAM_TABLES ON PARENT_TYPE = PARAM_PARENT_TYPE AND PARENT_ID = PARAM_PARENT_ID

    ) A  ON A.TABLE_ID = T.TABLES_ID
  -- FOLDER INFO
  LEFT  JOIN FOLDERS                  F   ON F.FOL_ID = A.DEF_FOL_ID
/
