CREATE VIEW ICM_INFO_V AS SELECT    
       F.FOL_NAME           AS PLAN_FOLDER_NAME,  
       PD.PD_ID             AS PLAN_ID,  
       PD.PD_NAME           AS PLAN_NAME, 
       -- PLAN ENTITIES: 
       P_ENT.EARNING_ENTITY AS PLAN_EARNING_ENTITY, 
       P_ENT.PAYMENT_ENTITY AS PLAN_PAYMENT_ENTITY, 
       PL_COMP.PROCESS_TYPE, 
       PL_COMP.DEF_ID, 
       PL_COMP.DEF_NAME, 
       PL_COMP.DEF_INPUT, 
       PL_COMP.DEF_OUTPUT || CHR(10) || 'RESULT VIEWS: '||CRT.RESULT_VIEWS  AS DEF_OUTPUT 
FROM       PLAN_DEFINITIONS              PD 
INNER JOIN FOLDERS                       F       ON F.FOL_ID=PD.PD_FOL_ID 
INNER JOIN PLAN_VERSIONS                 PDV     ON PDV.PDV_PD_ID = PD.PD_ID 
INNER JOIN (SELECT CR.CR_PARENT_DEFINITION_ID, 
                 LISTAGG(CR_T.TABLES_NAME || ' ( TABLES_ID: '|| CR_T.TABLES_ID || '; TABLES_PHYSICAL_NAME: '||CR_T.TABLES_PHYSICAL_NAME || ')'||CHR(10),'              ') 
                    WITHIN GROUP (ORDER BY 1)  AS RESULT_VIEWS 
            FROM      CATEGORY_RELATIONSHIPS      CR                            
            INNER JOIN TABLES              CR_T   ON CR.CR_DEFINITION_ID = CR_T.TABLES_ID 
            WHERE CR.CR_CD_ID = 6 
            GROUP BY CR.CR_PARENT_DEFINITION_ID 
            ) CRT ON CRT.CR_PARENT_DEFINITION_ID = PD.PD_ID 
-- PLAN INPUT: 
-->>  PLAN ENTITIES: 
INNER JOIN (SELECT PET.PET_PD_ID, 
                   EAR.ENTITY_NAME || ' (ENTITY_ID: '|| EAR.ENTITY_ID || ')' AS EARNING_ENTITY, 
                   EPAY.ENTITY_NAME || ' (ENTITY_ID: '|| EPAY.ENTITY_ID || ')' AS PAYMENT_ENTITY 
            FROM       PLAN_ENTITIES_TAB PET   
            -- EARNING ENTITY 
            INNER JOIN ENTITIES          EAR ON EAR.ENTITY_ID = PET.PET_EARNING_ENTITY_ID 
            -- PAYMENT ENTITY 
            LEFT  JOIN ENTITIES          EPAY ON EPAY.ENTITY_ID = PET.PET_PAYMENT_ENTITY_ID 
            ) P_ENT ON P_ENT.PET_PD_ID = PD.PD_ID 
-->> PLAN TYPES: 
INNER JOIN (-- ***** PLAN ROSTERS: ***** 
            SELECT PRT.PRT_VER_OBJECT_ID AS OBJ_ID, 
                   'ROSTER'              AS PROCESS_TYPE, 
                   PRT.PRT_ID            AS DEF_ID, 
                   NULL AS DEF_NAME, 
                   'Generate the '|| EAR.ENTITY_NAME ||' roster from: ' || 
                       CASE PRT.PRT_EARNING_GENERATE_OPTION  
                         WHEN 0 THEN EAR.ENTITY_NAME|| ' entity table'  
                         WHEN 1 THEN 'assignment between '||EAR.ENTITY_NAME||' and other entity' 
                       END || CHR(10) ||  
                       '  Entity: ' || NVL2(PRT_E.ENTITY_NAME,PRT_E.ENTITY_NAME || ' (ENTITY_ID: ' || PRT_E.ENTITY_ID || ')','') || CHR(10) || 
                       '  Assignment table: ' || NVL2(PRT_EA.EA_NAME,PRT_EA.EA_NAME || ' (EA_ID: ' || PRT_EA.EA_ID || ')','') || CHR(10) || 
                       'Attributes: ' ||  CHR(10) || ROS_ATTR.ROSTER_ATTRIBUTES AS DEF_INPUT, 
                       NVL2(ROS_ATTR.OUTPUT_TABLES,'Output tables: ' || ROS_ATTR.OUTPUT_TABLES,NULL)  AS DEF_OUTPUT 
            FROM         PLAN_VERSIONS            PDV1 
              INNER JOIN PLAN_ENTITIES_TAB        PET1 ON PET1.PET_PD_ID = PDV1.PDV_PD_ID 
              INNER JOIN ENTITIES                 EAR ON EAR.ENTITY_ID = PET1.PET_EARNING_ENTITY_ID 
              INNER JOIN PLAN_ROSTERS_TAB         PRT ON PDV1.PDV_VER_OBJECT_ID = PRT.PRT_VER_OBJECT_ID  
            -->> ROSTERS -> EARNINGS TAB   
              -- EARNING ENTITY ID 
              LEFT  JOIN ENTITIES                 PRT_E ON PRT_E.ENTITY_ID = PRT.PRT_EARNING_ENTITY_ID 
              -- EARNINGS TO PAYMENTS ASSIGNMENT TABLE 
              LEFT  JOIN ENTITIES                 PRT_EP ON PRT_EP.ENTITY_ID = PRT.PRT_EARN_TO_PMT_ASGN_TABLE_ID 
              -- EARNING ASSIGN TABLE ID 
              LEFT  JOIN ENTITY_ASSIGNMENTS       PRT_EA ON PRT_EA.EA_ID = PRT.PRT_EARNING_ASSIGN_TABLE_ID       
              LEFT JOIN (SELECT  PRAF_PRT_ID, 
                                LISTAGG(CASE PRAF_TYPE  
                                            WHEN 1 THEN '  Earnings attributes from the earnings entity: ' 
                                            WHEN 2 THEN '  Earnings attributes from the payment entity: ' 
                                            WHEN 3 THEN '  Payment attributes: ' 
                                        END || FIELDS || CHR(10),'') WITHIN GROUP (ORDER BY 1) AS ROSTER_ATTRIBUTES, 
                            LISTAGG( OUTPUT_TABLES||CHR(10),'') WITHIN GROUP (ORDER BY 1) AS OUTPUT_TABLES 
                        FROM 
                            (SELECT PRT_E.ENTITY_ID,PRT_E.ENTITY_NAME, 
                                   PRT_EA.EA_ID, PRT_EA.EA_NAME, 
                                   PRAF.PRAF_PRT_ID, 
                                  PRAF.PRAF_TYPE, 
                                  LISTAGG(PRAF_F.FLD_BUSINESS_NAME || ' (FLD_ID: '||PRAF_F.FLD_ID||')',', ') WITHIN GROUP (ORDER BY PRAF.PRAF_ORDER) AS FIELDS, 
                                  LISTAGG(PRRT_T.TABLES_NAME || ' ( TABLES_ID: '|| PRRT_T.TABLES_ID || '; TABLES_PHYSICAL_NAME: '||PRRT_T.TABLES_PHYSICAL_NAME || ')',', ') 
                                   WITHIN GROUP (ORDER BY PRRT.PRRT_NUMBER)  AS OUTPUT_TABLES 
                            FROM PLAN_ROSTERS_TAB                 PRT 
                             -->> ROSTERS -> EARNINGS TAB   
                                          -- EARNING ENTITY ID 
                                          LEFT  JOIN ENTITIES                 PRT_E ON PRT_E.ENTITY_ID = PRT.PRT_EARNING_ENTITY_ID 
                                          -- EARNINGS TO PAYMENTS ASSIGNMENT TABLE 
                                          LEFT  JOIN ENTITIES                 PRT_EP ON PRT_EP.ENTITY_ID = PRT.PRT_EARN_TO_PMT_ASGN_TABLE_ID 
                                          -- EARNING ASSIGN TABLE ID 
                                          LEFT  JOIN ENTITY_ASSIGNMENTS       PRT_EA ON PRT_EA.EA_ID = PRT.PRT_EARNING_ASSIGN_TABLE_ID   
                              -->> ROSTERS -> EARNINGS ATTRIBUTES + PAYMENT ATTRIBUTES 
                              INNER JOIN PLAN_ROSTER_ADDITIONAL_FIELDS  PRAF ON PRAF.PRAF_PRT_ID = PRT.PRT_ID 
                              INNER JOIN FIELDS                         PRAF_F ON PRAF_F.FLD_ID = PRAF.PRAF_FLD_ID 
                              INNER JOIN PROCESS_RESULT_TABLES          PRRT   ON PRRT.PRRT_DEFINITION_ID = PRT.PRT_VER_OBJECT_ID 
                                                                                       -- EARNING 
                                                                               AND (  (PRAF.PRAF_TYPE = 1 AND PRRT.PRRT_PROCESS_TYPE = 1 AND PRRT.PRRT_NUMBER=1) 
                                                                                       OR 
                                                                                       -- EARNING TO PAYMENTS ROSTER 
                                                                                       (PRAF.PRAF_TYPE = 2 AND PRRT.PRRT_PROCESS_TYPE = 1 AND PRRT.PRRT_NUMBER=2) 
                                                                                       OR 
                                                                                       -- PAYMENT 
                                                                                       (PRAF.PRAF_TYPE = 3 AND PRRT.PRRT_PROCESS_TYPE = 2 AND PRRT.PRRT_NUMBER=1) 
                                                                                   ) 
                              INNER JOIN TABLES                        PRRT_T ON PRRT_T.TABLES_ID = PRRT.PRRT_TABLES_ID                                                      
                            GROUP BY PRT_E.ENTITY_ID,PRT_E.ENTITY_NAME, 
                                   PRT_EA.EA_ID, PRT_EA.EA_NAME, 
                                   PRAF.PRAF_PRT_ID, 
                                                                  PRAF.PRAF_TYPE 
 
                            ) 
                        GROUP BY PRAF_PRT_ID  
                         ) ROS_ATTR ON ROS_ATTR.PRAF_PRT_ID = PRT.PRT_ID 
           UNION ALL 
           -- ***** TARGET EARNINGS: ***** 
           SELECT PTET.PTET_VER_OBJECT_ID AS OBJ_ID, 
                  'TARGET EARNINGS'       AS PROCESS_TYPE, 
                  PTET.PTET_ID            AS DEF_ID, 
                  NULL AS DEF_NAME, 
                  'Target earnings option: ' ||CASE PTET.PTET_TARGET_EARNINGS_OPTION  
                                                    WHEN 0 THEN 'Do not use target earnings' 
                                                    WHEN 1 THEN 'Specify target earnings for the plan and set weights for each plan component' 
                                                    WHEN 2 THEN 'Specify target earnings for one or more plan components' 
                                               END || CHR(10)|| 
                      'Target earnings values are for the time span of: ' || TU.TU_NAME || CHR(10)|| 
                      'Set target earnings to a value: ' || NVL2(PTET.PTET_VALUE, ' of '||PTET.PTET_VALUE,NULL)||' from a table with values that vary by: ' || TEV.TARGET_EARNINGS_VALUES || CHR(10)|| 
                      'Set plan component weights to values: ' || ' from a table with values that vary by: '||TEW.TARGET_EARNINGS_WEIGHTS 
                   AS DEF_INPUT, 
                   'Target Earnings - Values table: ' || PTET_TV.TABLES_NAME || '(TABLES_ID: '|| PTET_TV.TABLES_ID || ', TABLES_PHYSICAL_NAME: '|| PTET_TV.TABLES_PHYSICAL_NAME || ')' || CHR(10) || 
                   '                - Weigths table: ' || PTET_TW.TABLES_NAME || '(TABLES_ID: '|| PTET_TW.TABLES_ID || ', TABLES_PHYSICAL_NAME: '|| PTET_TW.TABLES_PHYSICAL_NAME || ')' AS DEF_OUTPUT      
            FROM PLAN_TARGET_EARNINGS_TAB PTET 
              INNER JOIN TIME_UNITS TU ON TU.TU_ID = PTET.PTET_TU_ID 
              -- TARGET EARNINGS -> VALUES TABLE TAB 
              LEFT  JOIN TABLES PTET_TV ON PTET_TV.TABLES_ID = PTET.PTET_VALUES_TABLE_ID 
              -- TARGET EARNINGS -> WEIGHTS TABLE TAB 
              LEFT  JOIN TABLES PTET_TW ON PTET_TW.TABLES_ID = PTET.PTET_WEIGHTS_TABLE_ID 
              -- TARGET EARNINGS -> WEIGHTS TAB 
              INNER JOIN(SELECT PTEWC.PTEWC_PTET_ID, 
                              LISTAGG(COALESCE(NVL2(PTEWC_E.ENTITY_NAME,PTEWC_E.ENTITY_NAME || '(ENTITY_ID: ' || PTEWC_E.ENTITY_ID || ')',NULL), 
                                                                       NVL2(PTEWC_F.FLD_BUSINESS_NAME,PTEWC_F.FLD_BUSINESS_NAME || '(FIELD_ID: ' || PTEWC_F.FLD_ID || ')',NULL)), 
                                                         ', ') WITHIN GROUP (ORDER BY PTEWC.PTEWC_ORDER) AS TARGET_EARNINGS_WEIGHTS 
                        FROM PLAN_TE_WEIGHT_COLS PTEWC   
                          -- PTEWC_TYPE: 0 = field id from FIELDS; 1 = entity id 
                          LEFT  JOIN ENTITIES          PTEWC_E ON PTEWC_E.ENTITY_ID = PTEWC.PTEWC_COL_ID AND PTEWC.PTEWC_TYPE=1 -- ENTITY 
                          LEFT  JOIN FIELDS            PTEWC_F ON PTEWC_F.FLD_ID = PTEWC.PTEWC_COL_ID AND PTEWC.PTEWC_TYPE=0    -- FIELD 
                        GROUP BY PTEWC.PTEWC_PTET_ID 
                        ) TEW ON TEW.PTEWC_PTET_ID = PTET.PTET_ID  
              -- TARGET EARNINGS -> VALUES TAB 
              INNER JOIN (SELECT PTEVC.PTEVC_PTET_ID,        
                                 LISTAGG(COALESCE(NVL2(PTEVC_E.ENTITY_NAME,PTEVC_E.ENTITY_NAME || '(ENTITY_ID: ' || PTEVC_E.ENTITY_ID || ')',NULL), 
                                                       NVL2(PTEVC_F.FLD_BUSINESS_NAME,PTEVC_F.FLD_BUSINESS_NAME || '(FIELD_ID: ' || PTEVC_F.FLD_ID || ')',NULL)), 
                                         ', ') WITHIN GROUP (ORDER BY PTEVC.PTEVC_ORDER) AS TARGET_EARNINGS_VALUES 
                          FROM  PLAN_TE_VALUE_COLS  PTEVC  
                            -- PTEVC_TYPE: 0 = field id from FIELDS; 1 = entity id 
                            LEFT  JOIN ENTITIES          PTEVC_E ON PTEVC_E.ENTITY_ID = PTEVC.PTEVC_COL_ID  AND PTEVC.PTEVC_TYPE = 1 -- ENTITY 
                            LEFT  JOIN FIELDS            PTEVC_F ON PTEVC_F.FLD_ID = PTEVC.PTEVC_COL_ID AND PTEVC.PTEVC_TYPE = 0 -- FIELD 
                          GROUP BY PTEVC.PTEVC_PTET_ID 
                         ) TEV ON TEV.PTEVC_PTET_ID = PTET.PTET_ID 
           UNION ALL 
           -- ***** PLAN PAYMENTS: *****  
           SELECT PPMT.PPMT_VER_OBJECT_ID AS OBJ_ID, 
                   'PLAN PAYMENTS'        AS PROCESS_TYPE, 
                   PPMT.PPMT_ID           AS DEF_ID, 
                   NULL                   AS DEF_NAME, 
                   'Calculation: ' || CHR(10) ||  CASE WHEN PPMT.PPMT_MULTIPLY_FACTOR=1 THEN '    - Multiply plan component earnings by an eligibility factor'|| CHR(10) END || 
                                      CASE WHEN PPMT.PPMT_SUBTRACT_PAYMENT_TU_ID IS NOT NULL THEN '    - Subtract prior period payments for the '|| TU.TU_NAME || ' for the calculation'|| CHR(10) END ||  
                                      CASE PPMT.PPMT_DRAW_OPTION 
                                        WHEN 0 THEN '    - Apply draws - by providing a guarantee (non-recoverable draw)' 
                                        WHEN 1 THEN '    - Apply draws - by providing a recoverable draw' 
                                      END || CHR(10) ||  
                    'Payment equals the maximum of either: The guarantee amount: ' || CHR(10) ||  ' from a table with values that vary by: ' || PAY_INFO.PAYMENTS || CHR(10) ||  
                    ' OR the payment' AS DEF_INPUT , 
                   CASE PPMD.PPMD_TYPE 
                     WHEN 0 THEN 'Guarantee table: ' 
                     WHEN 0 THEN 'Recoverable Draws table: ' 
                   END || PPMD_T.TABLES_NAME || ' (TABLES_ID: ' || PPMD_T.TABLES_ID || ', TABLES_PHYSICAL_NAME: '|| PPMD_T.TABLES_PHYSICAL_NAME || ')' || CHR(10)|| 
                   'Payment Adjustments table: ' || PPMT_AD.TABLES_NAME || ' (TABLES_ID: ' || PPMT_AD.TABLES_ID || ', TABLES_PHYSICAL_NAME: '|| PPMT_AD.TABLES_PHYSICAL_NAME || ')' || CHR(10)|| 
                   'Payment Overrides table: '|| PPMT_OV.TABLES_NAME || ' (TABLES_ID: ' || PPMT_OV.TABLES_ID || ', TABLES_PHYSICAL_NAME: '|| PPMT_OV.TABLES_PHYSICAL_NAME || ')' AS DEF_OUTPUT 
            FROM PLAN_PAYMENTS_TAB PPMT 
              LEFT JOIN TIME_UNITS TU ON TU.TU_ID = PPMT.PPMT_SUBTRACT_PAYMENT_TU_ID 
              -- ADJUSTMENT_TABLE_ID 
              INNER JOIN TABLES PPMT_AD ON PPMT_AD.TABLES_ID = PPMT.PPMT_ADJUSTMENT_TABLE_ID 
              -- OVERRIDE_TABLE_ID 
              INNER JOIN TABLES PPMT_OV ON PPMT_OV.TABLES_ID = PPMT.PPMT_OVERRIDE_TABLE_ID 
            -- PAYMENTS -> RECOVERABLE DRAW TAB  
            -- PAYMENTS -> GUARANTEE TAB 
            LEFT JOIN PLAN_PAYMENT_DRAWS  PPMD ON PPMD.PPMD_PPMT_ID = PPMT.PPMT_ID  
             LEFT  JOIN TABLES            PPMD_T ON PPMD_T.TABLES_ID = PPMD.PPMD_TABLE_ID -- Recoverable Draws TABLE / GUARANTEE TABLE 
             LEFT  JOIN (SELECT PPDC.PPDC_PPMD_ID, 
                               LISTAGG(COALESCE(NVL2(PPDC_E.ENTITY_NAME,PPDC_E.ENTITY_NAME || '(ENTITY_ID: ' || PPDC_E.ENTITY_ID || ')',NULL), 
                                                NVL2(PPDC_F.FLD_BUSINESS_NAME,PPDC_F.FLD_BUSINESS_NAME || '(FIELD_ID: ' || PPDC_F.FLD_ID || ')',NULL)), 
                                                                                 ', ') WITHIN GROUP (ORDER BY PPDC.PPDC_ORDER) AS PAYMENTS 
                        FROM PLAN_PAYMENT_DRAW_COLS PPDC 
                           LEFT JOIN ENTITIES              PPDC_E ON PPDC_E.ENTITY_ID = PPDC.PPDC_COL_ID AND PPDC.PPDC_TYPE=1 
                           LEFT JOIN FIELDS                PPDC_F ON PPDC_F.FLD_ID = PPDC.PPDC_COL_ID AND PPDC.PPDC_TYPE=0 
                        GROUP BY PPDC.PPDC_PPMD_ID 
                        ) PAY_INFO ON PAY_INFO.PPDC_PPMD_ID = PPMD.PPMD_ID            
           UNION ALL 
           -- ***** PLAN METRICS: ***** 
           SELECT PM.PM_VER_OBJECT_ID AS OBJ_ID, 
                     'PLAN METRICS'      AS PROCESS_TYPE, 
                     PM.PM_ID            AS DEF_ID, 
                     PM.PM_NAME          AS DEF_NAME, 
                     'Plan metrics entities: ' || PM_ENT.METRIC_ENTITIES || CHR(10)|| 
                     -->> PLAN METRICS -> METRIC CALCULATIONS -> INPUT TAB 
                     'Metric Calculation Input: ' || METRIC_CALC_INPUT.METRIC_CALC_INPUT_TABLES AS DEF_INPUT, 
                     'Calculation type: ' || 
                                          -->> PLAN METRICS -> METRIC CALCULATIONS -> TYPE TAB 
                                           CASE PMC.PMC_METRIC_TYPE 
                                                            WHEN 1 THEN 'VALUES -> VALUE [' 
                                                            WHEN 2 THEN 'VALUES -> SUM [' 
                                                            WHEN 3 THEN 'VALUES -> AVG [' 
                                                            WHEN 4 THEN 'VALUES -> MIN [' 
                                                            WHEN 5 THEN 'VALUES -> MAX [' 
                                                            WHEN 6 THEN 'AGGREGATIONS -> SUM [' 
                                                            WHEN 7 THEN 'AGGREGATIONS -> AVG [' 
                                                            WHEN 8 THEN 'AGGREGATIONS -> MIN [' 
                                                            WHEN 9 THEN 'AGGREGATIONS -> MAX [' 
                                                            WHEN 10 THEN 'RATIOS -> GOAL ATTAINMENT [' 
                                                            WHEN 11 THEN 'RATIOS -> RATIO [' 
                                                            WHEN 14 THEN 'STATISTICS -> COUNT OF RECORDS [' 
                                                            WHEN 15 THEN 'STATISTICS -> COUNT OF DISTINCT VALUES IN RECORDS [' 
                                                            WHEN 18 THEN 'RANKS -> RANK [' 
                                                            WHEN 22 THEN 'LOOKUPS -> STEP LOOKUP [' 
                                                            WHEN 23 THEN 'LOOKUPS -> CONTINUOUS LOOKUP [' 
                                                            WHEN 24 THEN 'LOOKUPS -> DISCRETE VALUE LOOKUP [' 
                                                            ELSE 'UNKNOWN VALUE [ ' 
                                             END || METRIC_CALC_INFO.FLD_INFO || ']' 
                     AS DEF_OUTPUT 
              FROM         PLAN_METRICS                   PM 
                -->> PLAN METRICS -> ENTITIES TAB 
                INNER JOIN (SELECT PME.PME_PM_ID, 
                                   LISTAGG(COALESCE(NVL2(PMED_E.ENTITY_NAME,PMED_E.ENTITY_NAME || '(ENTITY_ID: ' || PMED_E.ENTITY_ID || ')',NULL), 
                                                                          NVL2(PMED_F.FLD_BUSINESS_NAME,PMED_F.FLD_BUSINESS_NAME || '(FIELD_ID: ' || PMED_F.FLD_ID || ')',NULL)), 
                                                                                                           ', ') WITHIN GROUP (ORDER BY PMED.PMED_ORDER) AS METRIC_ENTITIES 
                          FROM PLAN_METRIC_ENTITIES           PME      
                              INNER JOIN PLAN_METRIC_ENTITY_DETAILS   PMED ON PMED.PMED_PME_ID = PME.PME_ID 
                              LEFT  JOIN ENTITIES                     PMED_E ON PMED_E.ENTITY_ID = PMED.PMED_FLD_ENTITY_ID 
                                                                             AND PMED.PMED_FIELD_OR_ENTITY = 0 -- ENTITY 
                              LEFT  JOIN FIELDS                       PMED_F ON PMED_F.FLD_ID = PMED.PMED_FLD_ENTITY_ID 
                                                                             AND PMED.PMED_FIELD_OR_ENTITY = 1 -- FIELD   
                          GROUP BY PME.PME_PM_ID 
                          ) PM_ENT ON PM_ENT.PME_PM_ID = PM.PM_ID   
                -->> PLAN METRICS -> METRIC CALCULATIONS -> TYPE TAB 
                INNER JOIN PLAN_METRIC_CALCULATIONS       PMC  ON PMC.PMC_PM_ID = PM.PM_ID 
                -->> PLAN METRICS -> METRIC CALCULATIONS -> INPUT TAB 
                INNER JOIN (SELECT PMCI.PMCI_PMC_ID, 
                                   LISTAGG(PMCI_DT.DT_NAME || ' (DT_ID:  '|| PMCI_DT.DT_ID || ')',', ') WITHIN GROUP (ORDER BY PMCI.PMCI_ORDER) AS METRIC_CALC_INPUT_TABLES 
                            FROM PLAN_MC_INPUTS                PMCI  
                                INNER JOIN TABLE_REFERENCES TR ON TR.TREF_ID=PMCI.PMCI_TREF_ID 
                                INNER JOIN DATA_TABLES         PMCI_DT ON PMCI_DT.DT_ID = TR.TREF_DEFINITION_ID     
                            GROUP BY PMCI.PMCI_PMC_ID     
                            ) METRIC_CALC_INPUT ON METRIC_CALC_INPUT.PMCI_PMC_ID = PMC.PMC_ID          
                -->> PLAN METRICS -> METRIC CALCULATIONS -> CALCULATIONS TAB 
                 LEFT JOIN ( 
                     --   CALCULATION TYPE = VALUES 
                     SELECT PMC_CV.PMCCV_PMC_ID AS METRIC_ID, 
                        LISTAGG(F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| F.FLD_ID ||')', ', ') WITHIN GROUP (ORDER BY PMC_CVF.PMCCVF_FLD_ORDER) AS FLD_INFO 
                     FROM PLAN_MCC_VALUES              PMC_CV 
                     INNER JOIN PLAN_MCC_VALUE_FIELDS  PMC_CVF ON PMC_CVF.PMCCVF_PMCCV_ID = PMC_CV.PMCCV_ID 
                     INNER JOIN FIELDS                 F       ON F.FLD_ID = PMC_CVF.PMCCVF_FLD_ID 
                     GROUP BY PMC_CV.PMCCV_PMC_ID        
                     UNION ALL 
                     --   CALCULATION TYPE = AGGREGATIONS 
                     SELECT PMC_CA.PMCCA_PMC_ID, 
                          F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| F.FLD_ID ||')' 
                     FROM PLAN_MCC_AGGREGATIONS PMC_CA 
                     INNER JOIN FIELDS F ON F.FLD_ID = PMC_CA.PMCCA_FLD_ID         
                     UNION ALL 
                     --   CALCULATION TYPE = RATIOS 
                     SELECT PMC_CR.PMCCR_PMC_ID AS METRIC_ID, 
                        CASE PMC_CR.PMCCR_NUMERATOR_AGG_TYPE 
                                WHEN 1 THEN 'SUM_OF [' 
                                WHEN 2 THEN 'AVERAGE_OF [' 
                                WHEN 3 THEN 'MINIMUM_OF [' 
                                WHEN 4 THEN 'MAXIMUM_OF [' 
                              END || GOAL.FLD_INFO || ']'  || CHR(10) || 
                        '  Divide by: '|| 
                        CASE PMC_CR.PMCCR_DENOMINATOR_AGG_TYPE 
                                WHEN 1 THEN 'SUM_OF [' 
                                WHEN 2 THEN 'AVERAGE_OF [' 
                                WHEN 3 THEN 'MINIMUM_OF [' 
                                WHEN 4 THEN 'MAXIMUM_OF [' 
                              END ||ACTUAL.FLD_INFO || ']' AS CALCULATION_DESC 
                     FROM        PLAN_MCC_RATIOS            PMC_CR 
                      LEFT JOIN ( 
                           SELECT PMC_CR_DF.PMCCRDF_PMCCR_ID AS FLD_ID, 
                              LISTAGG(PMC_CR_DF_F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| PMC_CR_DF_F.FLD_ID ||')', ', ') WITHIN GROUP (ORDER BY PMC_CR_DF.PMCCRDF_FLD_ORDER) AS FLD_INFO 
                           FROM PLAN_MCC_RATIO_DEN_FIELDS  PMC_CR_DF  
                             INNER JOIN FIELDS             PMC_CR_DF_F ON PMC_CR_DF_F.FLD_ID = PMC_CR_DF.PMCCRDF_FLD_ID 
                           GROUP BY PMC_CR_DF.PMCCRDF_PMCCR_ID) ACTUAL ON ACTUAL.FLD_ID=PMC_CR.PMCCR_ID  
                      LEFT JOIN (      
                           -- DIVIDE INFO 
                           SELECT PMC_CR_NF.PMCCRNF_PMCCR_ID AS FLD_ID, 
                            LISTAGG(PMC_CR_DF_F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| PMC_CR_DF_F.FLD_ID ||')', ', ') WITHIN GROUP (ORDER BY PMC_CR_NF.PMCCRNF_FLD_ORDER) AS FLD_INFO 
                           FROM   PLAN_MCC_RATIO_NUM_FIELDS  PMC_CR_NF   
                            INNER JOIN FIELDS                PMC_CR_DF_F ON PMC_CR_DF_F.FLD_ID = PMC_CR_NF.PMCCRNF_FLD_ID 
                           GROUP BY PMC_CR_NF.PMCCRNF_PMCCR_ID 
                           ) GOAL ON GOAL.FLD_ID  = PMC_CR.PMCCR_ID 
                     UNION ALL        
                     --   CALCULATION TYPE = STATISTICS 
                     SELECT PMC_CS.PMCCS_PMC_ID AS METRIC_ID, 
                        F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| F.FLD_ID ||')' AS CALCULATION_DESC        
                     FROM PLAN_MCC_STATISTICS          PMC_CS  
                     INNER JOIN FIELDS F ON F.FLD_ID = PMC_CS.PMCCS_FLD_ID 
                     UNION ALL 
                     --   CALCULATION TYPE = RANKS 
                     SELECT PMC_CRA.PMCCRA_PMC_ID, 
                         'Rank of: ' || PMC_F1.FLD_BUSINESS_NAME || ' (FLD_ID: '|| PMC_F1.FLD_ID ||')'  || CHR(10) ||  
                         '   Ordered by '|| CASE PMC_CRA.PMCCRA_ORDERBY  
                                   WHEN 1 THEN 'HIGHEST VALUE RANKED FIRST' 
                                   WHEN 2 THEN 'LOWEST VALUE RANKED FIRST' 
                                END || CHR(10)||  
                         'Within each group of: [' || GR.FLD_INFO  || ']'  || CHR(10)||  
                         'Break ties with: ' || PMC_F2.FLD_BUSINESS_NAME || ' (FLD_ID: '|| PMC_F2.FLD_ID ||')' || CHR(10)||  
                         '   Ordered by '|| CASE PMC_CRA.PMCCRA_BREAK_TIE_ORDERBY 
                                   WHEN 1 THEN 'HIGHEST VALUE RANKED FIRST' 
                                   WHEN 2 THEN 'LOWEST VALUE RANKED FIRST' 
                                END 
                    FROM          PLAN_MCC_RANKS              PMC_CRA 
                       INNER JOIN (SELECT PMC_CRAF.PMCCRAF_PMCCRA_ID, 
                                LISTAGG(NVL2(PMC_CRAF_F.FLD_BUSINESS_NAME,  
                                       PMC_CRAF_F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| PMC_CRAF_F.FLD_ID ||')', 
                                       NVL2(PMC_CRAF_E.ENTITY_NAME, PMC_CRAF_E.ENTITY_NAME || ' (ENTITY_ID: '|| PMC_CRAF_E.ENTITY_ID ||')','') 
                                       ),', ')  
                                   WITHIN GROUP (ORDER BY PMC_CRAF.PMCCRAF_FLD_ORDER) AS FLD_INFO 
                             FROM PLAN_MCC_RANK_FIELDS PMC_CRAF 
                             LEFT JOIN FIELDS          PMC_CRAF_F ON PMC_CRAF_F.FLD_ID = PMC_CRAF.PMCCRAF_FLD_ID  
                                              AND PMCCRAF_FLD_TYPE=1 
                             LEFT JOIN ENTITIES        PMC_CRAF_E ON PMC_CRAF_E.ENTITY_ID = PMC_CRAF.PMCCRAF_FLD_ID  
                                              AND PMCCRAF_FLD_TYPE=2 
                             GROUP BY PMC_CRAF.PMCCRAF_PMCCRA_ID 
                            ) GR ON GR.PMCCRAF_PMCCRA_ID = PMC_CRA.PMCCRA_ID 
                     INNER JOIN FIELDS                        PMC_F1 ON PMC_F1.FLD_ID = PMC_CRA.PMCCRA_FLD_ID 
                     LEFT JOIN FIELDS                         PMC_F2 ON PMC_F2.FLD_ID = PMC_CRA.PMCCRA_BREAK_TIE_FLD_ID 
                     UNION ALL 
                     --   CALCULATION TYPE = LOOKUPS 
                     SELECT PMC_LC.PMCLC_PMC_ID, 
                           'Number of decimals in lookup values: ' || PMC_LC.PMCLC_LOOKUP_DECIMAL_LENGTH  || CHR(10) || 
                           'Number of decimals in result values: ' || PMC_LC.PMCLC_RESULT_DECIMAL_LENGTH || CHR(10) || 
                           'Lookup field: [' || F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| F.FLD_ID ||')]' || CHR(10) || 
                           'Result table: ' || T.TABLES_PHYSICAL_NAME || '(TABLES_ID: ' || T.TABLES_ID || ')'|| 
                           CASE PMC_LC.PMCLC_RESULT_VALUE_LESS 
                             WHEN 1 THEN CHR(10)||'If the lookup field value is less than the smallest lookup value, the result is: the result value for the smallest lookup value'|| CHR(10) 
                             WHEN 2 THEN CHR(10)||'If the lookup field value is less than the smallest lookup value, the result is: based on the slope between the two smallest lookup values'|| CHR(10) 
                             WHEN 5 THEN CHR(10)||'If the lookup field value is less than the smallest lookup value, the result is: zero'|| CHR(10) 
                             WHEN 6 THEN CHR(10)||'If the lookup field value is less than the smallest lookup value, the result is: an error' || CHR(10) 
                           END ||  
                           CASE PMC_LC.PMCLC_RESULT_VALUE_GREATER  
                             WHEN 3 THEN CHR(10)||'If the lookup field value is greater than the largest lookup value, the result is: the result value for the largest lookup value'|| CHR(10) 
                             WHEN 4 THEN CHR(10)||'If the lookup field value is greater than the largest lookup value, the result is: based on the slope between the two largest lookup values'|| CHR(10) 
                             WHEN 6 THEN CHR(10)||'If the lookup field value is greater than the largest lookup value, the result is: an error' || CHR(10) 
                           END 
                    FROM PLAN_MC_LOOKUP_CURVES PMC_LC 
                    INNER JOIN FIELDS F ON F.FLD_ID = PMC_LC.PMCLC_FLD_ID 
                    INNER JOIN TABLES T ON T.TABLES_ID = PMC_LC.PMCLC_TABLES_ID 
                      ) METRIC_CALC_INFO ON METRIC_CALC_INFO.METRIC_ID = PMC.PMC_ID   
           UNION ALL 
           -- ***** PLAN COMPONENTS: ***** 
           SELECT PCD.PCD_VER_OBJECT_ID AS OBJ_ID, 
                    'PLAN COMPONENTS'     AS PROCESS_TYPE, 
                    PCD.PCD_ID            AS DEF_ID, 
                    PCD.PCD_NAME          AS DEF_NAME, 
                    'Earnings calculation entity: ' || COMP_ENT.COMP_ENTITIIES || CHR(10)|| 
                    -->> ENTITIES TAB -> Aggregate earnings to .. using: 
                    'Aggregate earnings using: '||  AGGREGATION_TYPE  || CHR(10) || 
                    CASE WHEN PMT.PM_ID IS NOT NULL 
                         THEN 'Lookup metric for the plan: ' || PMT.PM_NAME || ' (PM_ID: '||PMT.PM_ID 
                         ELSE 'Lookup component for the plan: ' || PCD_LOOK.PCD_NAME || ' (PCD_ID: '||PCD_LOOK.PCD_ID 
                    END || ')' AS DEF_INPUT, 
                   -->> EARNINGS CALCULATION -> TYPE TAB 
                   'Earnings calculation type: ' || CASE PCECL.PCECL_LOOKUP_TYPE 
                                                     WHEN 1 THEN 'STEP LOOKUP' 
                                                     WHEN 2 THEN 'CONTINUOUS LOOKUP' 
                                                     WHEN 3 THEN 'DISCRETE LOOKUP' 
                                                   END || CHR(10) || 
                    -->> EARNINGS CALCULATION -> CALCULATION TAB 
                   'Number of decimals in lookup values: '|| PCECL.PCECL_LOOKUP_DECIMAL_NUMBER || CHR(10) ||   
                   'Number of decimals in result values: '|| PCECL.PCECL_RESULT_DECIMAL_NUMBER || CHR(10) || 
                   'Lookup table: ' || PCECT_T.TABLES_NAME || ' (TABLES_ID: '||PCECT_T.TABLES_ID || ', TABLES_PHYSICAL_NAME: ' || PCECT_T.TABLES_PHYSICAL_NAME || ')' || CHR(10) || 
                   'Plan modifiers: ' || CHR(10) ||  
                   '   Modifier tables: '|| P_MOD.MODIFIER_TABLES|| CHR(10) ||  
                   '   Input tables: '|| COALESCE(P_MOD.MODIFIER_INPUT_TABLES,'-')|| CHR(10) || 
                   '   Output tables: '|| P_MOD.MODIFIER_OUPUT_TABLES AS DEF_OUTPUT   
            FROM           PLAN_COMPONENT_DEFINITIONS     PCD 
            INNER JOIN (SELECT PCET.PCET_PCD_ID, 
                               CASE PCET.PCET_AGGREGATION_TYPE 
                                 WHEN 1 THEN 'SUM' 
                                 WHEN 2 THEN 'AVERAGE' 
                                 WHEN 3 THEN 'MIN' 
                                 WHEN 4 THEN 'MAX' 
                               END AS AGGREGATION_TYPE, 
                               LISTAGG(NVL2(PCECC_F.FLD_BUSINESS_NAME, PCECC_F.FLD_BUSINESS_NAME || ' (FLD_ID: '|| PCECC_F.FLD_ID ||')', 
                                      NVL2(PCECC_E.ENTITY_NAME, PCECC_E.ENTITY_NAME || ' (ENTITY_ID: '|| PCECC_E.ENTITY_ID ||')','')),', ')  
                                     WITHIN GROUP (ORDER BY PCECC.PCECC_ORDER) AS COMP_ENTITIIES 
                        FROM           PLAN_COMP_ENTITIES_TAB         PCET  
                          INNER JOIN   PLAN_COMP_ENTITY_CALC_COLS     PCECC   ON PCECC.PCECC_PCET_ID = PCET.PCET_ID 
                          LEFT JOIN    ENTITIES                       PCECC_E ON PCECC_E.ENTITY_ID = PCECC.PCECC_COL_ID 
                                                                              AND PCECC.PCECC_TYPE=1 
                          LEFT JOIN    FIELDS                         PCECC_F ON PCECC_F.FLD_ID = PCECC.PCECC_COL_ID 
                                                                              AND PCECC.PCECC_TYPE=0 
                        GROUP BY PCET.PCET_PCD_ID,CASE PCET.PCET_AGGREGATION_TYPE 
                                                       WHEN 1 THEN 'SUM' 
                                                       WHEN 2 THEN 'AVERAGE' 
                                                       WHEN 3 THEN 'MIN' 
                                                       WHEN 4 THEN 'MAX' 
                                                     END 
                        ) COMP_ENT ON COMP_ENT.PCET_PCD_ID  = PCD.PCD_ID 
            INNER JOIN     PLAN_COMP_EARNING_CALC_TAB     PCECT ON PCECT.PCECT_PCD_ID = PCD.PCD_ID                          
            -->> EARNINGS CALCULATION -> LOOKUP -> LOOKUP TABLE 
              INNER JOIN   TABLES                         PCECT_T ON PCECT_T.TABLES_ID = PCECT.PCECT_TABLE_ID 
            -->> EARNINGS CALCULATION -> CALCULATION TAB   
              INNER JOIN   PLAN_COMP_EARNING_CALC_LOOKUP  PCECL ON PCECL.PCECL_PARENT_ID = PCECT.PCECT_ID   
              LEFT JOIN   PLAN_METRICS                   PMT      ON PMT.PM_ID       =  PCECL.PCECL_LOOKUP_INPUT_ID 
              LEFT JOIN   PLAN_COMPONENT_DEFINITIONS     PCD_LOOK ON PCD_LOOK.PCD_ID =  PCECL.PCECL_LOOKUP_INPUT_ID 
            -->> EARNINGS CALCULATION -> MODIFIERS TAB   
              LEFT JOIN    (SELECT PM.PMD_ID, 
                                   LISTAGG(NVL2(PMI_T.TABLES_NAME,'TABLES BUSINESS NAME: '||PMI_T.TABLES_NAME || ' (TABLES_ID: '|| PMI_T.TABLES_ID||', TABLES_PHYSICAL_NAME: '|| PMI_T.TABLES_PHYSICAL_NAME || ')',NULL),', ')  
                                          WITHIN GROUP (ORDER BY PMI.PMI_ORDER) AS MODIFIER_TABLES, 
                                   LISTAGG(NVL2(PMI_TI.TABLES_NAME,'TABLES BUSINESS NAME: '||PMI_TI.TABLES_NAME || ' (TABLES_ID: '|| PMI_TI.TABLES_ID||', TABLES_PHYSICAL_NAME: '|| PMI_TI.TABLES_PHYSICAL_NAME || ')',NULL),', ')  
                                          WITHIN GROUP (ORDER BY PMI.PMI_ORDER) AS MODIFIER_INPUT_TABLES, 
                                   LISTAGG(NVL2(PMI_TO.TABLES_NAME,'TABLES BUSINESS NAME: '||PMI_TO.TABLES_NAME || ' (TABLES_ID: '|| PMI_TO.TABLES_ID||', TABLES_PHYSICAL_NAME: '|| PMI_TO.TABLES_PHYSICAL_NAME || ')',NULL),', ')  
                                          WITHIN GROUP (ORDER BY PMI.PMI_ORDER) AS MODIFIER_OUPUT_TABLES 
                            FROM PLAN_MODIFIERS                 PM  
                              INNER JOIN    PLAN_MODIFIER_ITEMS            PMI ON PMI.PMI_PMD_ID = PM.PMD_ID 
                              -- MODIFIER TABLE 
                              LEFT JOIN    TABLES                         PMI_T ON PMI_T.TABLES_ID  = PMI.PMI_TABLE_ID 
                              LEFT JOIN TABLE_REFERENCES                  PMI_TR ON PMI_TR.TREF_DEFINITION_ID=PMI.PMI_INPUT_TREF_ID 
                              -- MODIFIER INPUT TABLE  
                              LEFT JOIN    TABLES                         PMI_TI ON PMI_TI.TABLES_DEFINITION_ID  = PMI_TR.TREF_DEFINITION_ID 
                              -- MODIFIER OUTPUT TABLE 
                              LEFT JOIN    TABLES                         PMI_TO ON PMI_TO.TABLES_ID  = PMI.PMI_OUTPUT_TABLE_ID 
                            GROUP BY PM.PMD_ID   
                            ) P_MOD ON P_MOD.PMD_ID = PCECT.PCECT_PMD_ID  
           ) PL_COMP ON PL_COMP.OBJ_ID = PDV.PDV_VER_OBJECT_ID
/
