CREATE VIEW CONFIG_OBJECT_DETAILS_V AS with LAST_PERF_ANALYZER_DATES as
(
SELECT DEFINITION_ID, LAST_PERF_ANALYZER_DATE
  FROM (SELECT rd.rd_definition_id DEFINITION_ID,
               rs_execution_start_time LAST_PERF_ANALYZER_DATE,
               rank() over(PARTITION BY rd.rd_definition_id ORDER BY rsd.rs_execution_start_time DESC, rownum) rnk
          FROM run_data rd
         INNER JOIN run_status_data rsd
            ON rd.rd_id = rsd.rs_id
         WHERE rd_type = 41)
WHERE rnk = 1
),
last_config_adjustment_dates as
       (select oa_definition_id, oa_record_adjustment_time
        from (select a.oa_definition_id,
           a.oa_record_adjustment_time,
           rank() over(partition by a.oa_definition_id order by a.oa_record_adjustment_time desc, rownum) rnk
          from OBJECT_AUDIT a)
         where rnk = 1)
      select obj_view."OBJ_ID",obj_view."OBJ_NAME",obj_view."OBJ_TYPE_ID",obj_view."OBJ_TYPE_NAME",obj_view."OBJ_CONTAINER_ID",obj_view."OBJ_CONTAINER_NAME",obj_view."LATEST_ADJUSTMENT_TIME",obj_view."LAST_PERF_ANALYZER_DATE", obj_view.OBJ_ID ROW_IDENTIFIER, 0 ROW_VERSION from (select or_id OBJ_ID,
         COMMONS_APPFRAMEWORK.GET_NAME(or_name) OBJ_NAME,
         or_type OBJ_TYPE_ID,
         d.def_type_name_singular OBJ_TYPE_NAME,
         or_container_id OBJ_CONTAINER_ID,
         f.fol_name OBJ_CONTAINER_NAME,   --container name will be displayed only if it is folder
         oa_record_adjustment_time LATEST_ADJUSTMENT_TIME,
         LAST_PERF_ANALYZER_DATE  LAST_PERF_ANALYZER_DATE
        from (select or_id,
           or_name,
           or_type,
           or_container_id,
           cd.oa_record_adjustment_time,
               pd.LAST_PERF_ANALYZER_DATE
          from (select o1.or_id, o1.or_name, o1.or_type, o1.or_container_id
            from object_registration o1
            left outer join entities e
            on (o1.or_id = e.entity_id)
            left outer join fields f
            on (o1.or_id = f.fld_id)
           where o1.or_type not in (53)
             and ((o1.or_type in (1, 12) and f.fld_base_field is null and
             e.entity_base_entity is null) or
             o1.or_type not in (1, 12))) o
          left outer join last_config_adjustment_dates cd
          on (o.or_id = cd.oa_definition_id)
          left outer join LAST_PERF_ANALYZER_DATES pd
          on (o.or_id = pd.definition_id )
        union all
        select or_id,
           or_name,
           or_type,
           or_container_id,
           cd1.oa_record_adjustment_time,
           pd1.LAST_PERF_ANALYZER_DATE
          from (select l1.or_id,
             l3.or_id studio_app_id,
             l1.or_name || '(' || l3.or_name || ')' or_name,
             l1.or_type,
             l3.or_container_id             --for app components container is of app studio.
            from (select * from object_registration where or_type = 53) l1
            left outer join object_registration l2
            on (l1.or_container_id = l2.or_id)
            left outer join object_registration l3
            on (l2.or_container_id = l3.or_id)) comp
          left outer join last_config_adjustment_dates cd1
          on (comp.studio_app_id = cd1.oa_definition_id)
          left outer join LAST_PERF_ANALYZER_DATES pd1
         on (comp.studio_app_id = pd1.definition_id )) all_obj            --for app component config date is of app studio
    left outer join folders f
        on (all_obj.or_container_id = f.fol_id)
        left outer join definition_types d
        on (all_obj.or_type = d.def_type_id)) obj_view

/
