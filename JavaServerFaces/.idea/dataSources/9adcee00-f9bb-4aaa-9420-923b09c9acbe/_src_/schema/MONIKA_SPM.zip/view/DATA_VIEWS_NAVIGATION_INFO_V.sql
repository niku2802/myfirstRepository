CREATE VIEW DATA_VIEWS_NAVIGATION_INFO_V AS select  distinct first_value(login_id) over(partition by pvv_id) user_name, rol_name, fol_name, pa_name,pvpv_name, pvv_label,pvv_id, filtrableFields from pv_portal_views
                        join   ( SELECT listagg( extractValue(value(x),'/fieldOptions/fieldHeaderLabel') , ',') within group(order by extractValue(value(x),'/fieldOptions/fieldHeaderLabel') ) over (partition by pvv_id) filtrableFields ,
                                        pvv_id,
                                        pvv_label,
                                        pvv_pvpv_id
                                  FROM pv_views,
                                       object_definitions od,
                                       TABLE(XMLSequence(extract(XMLTYPE(od.od_Definition),'/*/fieldOptions'))) x
                                  where pvv_definition_type_id = 19
                                  and od_container_id = pvv_id
                                  and extractValue(value(x),'/fieldOptions/filterableAndSortable')  = 'true') on pvpv_id = pvv_pvpv_id
                        join portal_folders on pvpv_pf_id = pf_id
                        join portal_applications on pf_pa_id = pa_id
                        join folders on fol_id = pa_fol_id
                        join role_objects on ro_or_id = pvpv_id and  ro_permission = 2
                        join roles on rol_id = ro_rol_id
                        join users u on instr(trim(','||u.role||','), ','||rol_name||',') > 0  and rol_name is not null
/
