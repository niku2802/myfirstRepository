CREATE VIEW COLUMN_SELECTIVITY AS select utcs.table_name,
       column_name,
       case when histogram = 'NONE' then density else 1 / (utcs.num_distinct + case when num_nulls = 0 then 0 else 1 end) end col_density ,
       case when histogram = 'NONE' and (utcs.num_nulls / ut.num_rows) <= .2 then ut.num_rows /(utcs.num_distinct + case when num_nulls = 0 then 0 else 1 end)
            when histogram = 'NONE' and (utcs.num_nulls / ut.num_rows) > .2 then null else density * ut.num_rows end col_selectivity,
       case when ut.num_rows >= 5 then 'Yes Based on Selectivity and density' else 'No' end Column_indexable,
       case when histogram = 'NONE' then density  else 1 / (utcs.num_distinct + case when num_nulls = 0 then 0 else 1 end) end/ ut.num_rows  Think_DensitybyNumRowS,
       ut.num_rows,
       utcs.num_distinct,
       num_nulls ,
       histogram,
       density,
       case when histogram = 'NONE' and (utcs.num_nulls / ut.num_rows) <= .2 then ((utcs.num_distinct + case when num_nulls = 0 then 0 else 1 end) * 100 / ut.num_rows)
         when histogram = 'NONE' and (utcs.num_nulls / ut.num_rows) > .2 then null else (density * ut.num_rows) end Column_selectivity,
       (1 / (utcs.num_distinct + case when num_nulls = 0 then 0 else 1 end))/ut.num_rows calculate_density,
--       (1 / (utcs.num_distinct + case when num_nulls = 0 then 0 else 1 end)) calculate_den1
       (num_rows / num_distinct) * 100 / num_rows density_percent
  from user_tables ut
 INNER JOIN user_tab_col_statistics utcs
    ON ut.table_name = utcs.table_name
 where ut.num_rows <> 0
   and utcs.num_distinct <> 0
/
