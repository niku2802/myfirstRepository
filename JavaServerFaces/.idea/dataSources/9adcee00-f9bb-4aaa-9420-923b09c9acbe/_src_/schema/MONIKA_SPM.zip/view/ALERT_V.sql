CREATE VIEW ALERT_V AS SELECT     AM.AM_ID AS ROW_IDENTIFIER,
                                       AM.OBJECT_VERSION AS ROW_VERSION,
                                       AM.AM_USER_ID,
                                       AMT.AMT_TYPE AS MESSAGE_TYPE,
                                       AM.AM_MESSAGE_TEXT,
                                       AM.PRIORITY,
                                       PV.PVPV_NAME AS PORTAL_VIEW_NAME,
                                       PA.PA_NAME AS PORTAL_APPLICATION_NAME,
                                       AM.DATE_TIME,
                                       U.LOGIN_ID,
                                       U.FULL_NAME,
                                       AM.SENT_DATE,
                                       AM.PUSH_NOTIFICATION_DATE
                                  FROM ALERT_MESSAGES AM
                                 INNER JOIN USERS U
                                    ON (AM.AM_USER_ID = U.USER_ID)
                                 INNER JOIN ALERT_MESSAGE_TYPES AMT
                                    ON (AM.AM_MESSAGE_TYPE_ID = AMT.AMT_ID)
                                 LEFT OUTER JOIN PV_PORTAL_VIEWS PV
                                    ON (AM.AM_PV_ID = PV.PVPV_ID)
                                 LEFT OUTER JOIN PORTAL_APPLICATIONS PA
                                    ON (PA.PA_ID = AM.AM_PA_ID)
/
