CREATE VIEW DROP_INDEXES AS SELECT rui.rui_table_name,
       rui.rui_index_name,
       rui.rui_def_id,
       rui.rui_create_date,
       rui.rui_last_updated_date,
       rui.rui_usage_factor
  FROM report_unused_indexes rui
 INNER JOIN user_indexes ui
    ON ui.index_name = rui.rui_index_name
 WHERE rui.rui_usage_factor < (SELECT pr_value FROM properties WHERE pr_name = 'INDEX_USAGE_FACTOR')
    OR NOT EXISTS (SELECT 1
          FROM index_usage_stats
         WHERE ius_index_name = rui_index_name
           AND SYSDATE - ius_last_used_on > (SELECT pr_value FROM properties WHERE pr_name = 'INDEX_LAST_USED'))
UNION
SELECT rui.rui_table_name,
       rui.rui_index_name,
       rui.rui_def_id,
       rui.rui_create_date,
       rui.rui_last_updated_date,
       rui.rui_usage_factor
  FROM (SELECT cir_index_name index_name
          FROM create_index_requests
        UNION
        SELECT dir_index_name index_name
          FROM delete_index_requests) result_index
 INNER JOIN report_unused_indexes rui
    ON rui_index_name = index_name
 WHERE rui_usage_factor <
       (SELECT pr_value FROM properties WHERE pr_name = 'INDEX_USAGE_FACTOR')
    OR NOT EXISTS (SELECT 1
          FROM index_usage_stats
         WHERE ius_index_name = rui_index_name
           AND SYSDATE - ius_last_used_on > (SELECT pr_value FROM properties WHERE pr_name = 'INDEX_LAST_USED'))
/
