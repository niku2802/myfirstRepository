CREATE TYPE              "OBJTYPE_TERRIT_PROPOSALS" 
                          FORCE AS OBJECT
                          (
                             TERRITORY_ENTITY_ID        NUMBER(10),
                             TERRITORY_OLD_ENTITY_ID    NUMBER(10),
                             ACCOUNT_ENTITY_ID          NUMBER(10),
                             REP_ENTITY_ID              NUMBER(10),
                             ADJUSTMENT_TYPE            VARCHAR2(250 CHAR),
                             ADJUSTMENT_DATE            TIMESTAMP(6),
                             ADJUSTMENT_START_DATE      DATE,
                             ADJUSTMENT_END_DATE        DATE,
                             ADJUSTMENT_COMMENT         VARCHAR2(1300 CHAR),
                             ADJUSTMENT_REASON          VARCHAR2(250 CHAR),
                             ADJUSTMENT_STATUS          VARCHAR2(250 CHAR),
                             ADJUSTMENT_ROLE            VARCHAR2(1300 CHAR)
                          )
/
