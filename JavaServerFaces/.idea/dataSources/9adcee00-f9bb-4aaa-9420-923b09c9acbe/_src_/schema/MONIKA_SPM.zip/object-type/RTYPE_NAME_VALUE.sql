CREATE TYPE              "RTYPE_NAME_VALUE" IS OBJECT (NAME varchar2(30), VALUE varchar2(4000))
/
