CREATE TYPE              "OBJTYPE_TBL_COLS_SDM" AS OBJECT
                                                                                (
                                                                                  OTCS_TC_ID                    NUMBER(10),
                                                                                  OTCS_TC_COLUMN_TYPE           NUMBER(1),
                                                                                  OTCS_TC_IS_REQUIRED           NUMBER(1),
                                                                                  OTCS_TC_FLD_ID                NUMBER(10),
                                                                                  OTCS_TC_LOGIC_TYPE            NUMBER(1),
                                                                                  OTCS_TC_ORDER                 NUMBER(5),
                                                                                  OTCS_TC_PHYSICAL_NAME         VARCHAR2(30 CHAR),
                                                                                  OTCS_TC_IS_PREDEFINED         NUMBER(1),
                                                                                  OTCS_TC_ENTITY_ID             NUMBER(10),
                                                                                  OTCS_DISPLAY_ORDER            NUMBER(5),
                                                                                  OTCS_IS_LOWER                 NUMBER(1),
                                                                                  OTCS_IS_UPPER                 NUMBER(1)
                                                                                )
/
