CREATE TYPE              "OBJ_TABLE_COL_DTLS" as object (TC_FLD_ID number(10),
                         TC_ENTITY_ID number(10),
                         TC_TABLES_ID number(10),
                         TC_PHYSICAL_NAME varchar2(30),
						 ENT_TABLE  varchar2(30 char),
                         ENT_KEY_COL varchar2(30 char))
/
