CREATE TYPE              "OBJTYPE_PROCESS_DB_ACTIVITY" AS OBJECT (  PROCESS_ID        NUMBER(10)
                                                                                        ,PROCESS_NAME      VARCHAR2(255 CHAR)
                                                                                        ,PROCESS_LOG_ID    VARCHAR2(1300 CHAR)
                                                                                        ,process_type_id    NUMBER(10)
                                                                                        ,process_type_name    VARCHAR2(255 CHAR)
                                                                                        ,PROCESS_STATUS    NUMBER(10)
                                                                                        ,PROCESS_DB_STATUS NUMBER(10)
                                                                                      )
/
