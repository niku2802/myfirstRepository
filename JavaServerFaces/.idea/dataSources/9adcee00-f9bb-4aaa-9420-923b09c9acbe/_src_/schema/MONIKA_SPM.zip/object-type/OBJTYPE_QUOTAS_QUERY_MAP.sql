CREATE TYPE              "OBJTYPE_QUOTAS_QUERY_MAP" 
                            FORCE AS OBJECT
                            (
                               OBJECT_ID         NUMBER(10),
                               QUERY             VARCHAR2(2000 CHAR)
                         )
/
