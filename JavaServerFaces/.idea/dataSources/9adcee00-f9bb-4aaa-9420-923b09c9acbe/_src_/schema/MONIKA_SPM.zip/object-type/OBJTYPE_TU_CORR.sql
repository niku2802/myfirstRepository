CREATE TYPE              "OBJTYPE_TU_CORR" AS OBJECT (

			OTC_ID              NUMBER(10) 		,--	VTC_ID 				:Ordering column
			OTC_NAME        	varchar2(30) 	,-- VTC_NAME 			:Name of the primary TU
			OTC_NAME_CORR      varchar2(30) 	 -- VTC_NAME_CORR 		:Name of the secondary TU

		);
/
