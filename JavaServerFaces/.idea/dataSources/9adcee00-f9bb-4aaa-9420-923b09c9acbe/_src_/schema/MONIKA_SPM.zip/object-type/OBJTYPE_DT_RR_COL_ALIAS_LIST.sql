CREATE TYPE              "OBJTYPE_DT_RR_COL_ALIAS_LIST" AS OBJECT
                      (
                      COLUMN_NAME  VARCHAR2(30 CHAR),
                      COLUMN_ALIAS VARCHAR2(50 CHAR),
                      DISPLAY_FINAL_OUTPUT  NUMBER(1),
                      RANK_OR_COUNT_FLD NUMBER(1)
                      )
/
