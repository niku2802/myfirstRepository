CREATE TYPE              "OBJTYPE_ALIGNMENTS_CONDITIONS" 
      FORCE AS OBJECT
      (
         LOGIC_CONDITION_ID NUMBER (10),                            -- NOT NULL
         LOGIC_CONDITION_TEXT VARCHAR2(4000 CHAR),          -- NOT NULL
         EFFECTIVE_START_DATE DATE,                                   -- NULL
         EFFECTIVE_END_DATE DATE,                                      -- NULL
         ALLOCATION  NUMBER(5,2)                                        -- NULL
      )
/
