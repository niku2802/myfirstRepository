CREATE TYPE              "OBJTYPE_CRED_CONDITIONS_DETAIL" 
        FORCE AS OBJECT
      (
         CCD_ID                                  NUMBER (10),                -- NOT NULL
         CCD_TEXT                                CLOB,          	 -- NOT NULL
         CCD_EFFECTIVE_START_DATE                DATE,                       -- NULL
         CCD_EFFECTIVE_END_DATE                  DATE,                       -- NULL
         CCD_FILTER_EVAL_AT_PER_ENTITY           COLTYPE_CRED_AT_FILTERS,    -- NULL            -- NULL WHEN FILTER_CRITERIA = 0
         CCD_FILTER_EVAL_AT_COMBINED             CLOB,             -- NULL            -- NULL WHEN FILTER_CRITERIA = 0
         CCD_FILTER_EVAL_DT_COMBINED             CLOB              -- NULL            -- NULL WHEN FILTER_CRITERIA = 0
      )
/
