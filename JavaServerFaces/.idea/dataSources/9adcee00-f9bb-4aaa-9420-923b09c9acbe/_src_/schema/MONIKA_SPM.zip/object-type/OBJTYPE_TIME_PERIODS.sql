CREATE TYPE              "OBJTYPE_TIME_PERIODS" AS OBJECT
		(
			OTP_ID          	NUMBER(10)       ,--  VTP_ID 			:Ordering column
			OTP_VTU_ID          NUMBER(10)       ,--  VTP_VTU_ID 		:Ordering column of VOBJ_TIME_UNIT
			OTP_NAME        	varchar2(30)     ,--  VTP_NAME 			:TU Period name
			OTP_MONTH_OFFSET  	NUMBER(10)       ,--  VTP_MONTH_OFFSET 	:Starting month of this period
			OTP_ORDER          	NUMBER(10)       ,--  VTP_ORDER         :Internal order of the TU periods
			OTP_START_MONTH     NUMBER(10)       ,--  VTP_START_MONTH 	:Starting month of this TU
			OTP_YEAR_OFFSET     NUMBER(10)        --  VTP_YEAR_OFFSET 	:current year 0, next year 1

		)
/
