CREATE TYPE              "OBJTYPE_CRD_INFO" FORCE AS OBJECT (
                  ROLLUP_FROM_ENTITY_BASE_ID NUMBER(10), -- Rollup FROM BASE Entity ID -- ideally the Crediting Entity ID -- CREDITING_DEFINITIONS.CREDITING_ENTITY_ID IS Crediting Entity ID; -- CHANGED from ROLLUP_FROM_ID
                  ROLLUP_FROM_ENTITY_EQ_ID NUMBER(10), -- Rollup FROM EQUIVALENT Entity ID -- ideally the Crediting Entity ID -- CREDITING_DEFINITIONS.CREDITING_ENTITY_ID IS Crediting Entity ID; -- ADDED NEW
                  LEVELS_TO_RUP_FROM NUMBER(10), -- If Crediting entity is at multiple levels then this signifies the level to pick -- NULL for US1 where Crediting Entity is only once in the Hierarchy -- CREDITING_DEFINITIONS.CREDITING_RUP_LVL_TO_RUP_FROM IS Hierarchy level from which the rollup will start LOWEST(1),ALL LOWER(2);;
                  INCLUDE_UMATCH_RESULT NUMBER(10), -- 0 = no, 1 = yes -- CREDITING_DEFINITIONS.CREDITING_RUP_INC_UMATCHED_REC IS Include Unmatched records  [USED TO IDENTIFY TAB IS DEFINED OR NOT TOO] 0-no 1-yes;
                  RECORD_BASED_ON_OPTION NUMBER(10), -- CREDITING_DEFINITIONS.CREDITING_RUP_BASED_ON_OPT IS PROCESSING_PERIOD(1) DATE_OR_PERIOD_VALUES(2);;
                  RECORDS_TO_USE_OPTION NUMBER(10), -- Hierarchy relationships to use: 1 = All records, 2 = Records determined based on date or period -- CREDITING_DEFINITIONS.CREDITING_RUP_REC_TO_USE_OPT IS All(1),DATE_OR_PERIOD_BASED(2)
                  RECORDS_BETWEEN_OPTION NUMBER(10), -- CREDITING_DEFINITIONS.CREDITING_RUP_PROC_PERIOD_OPT IS FIRST(1),LAST(2),Any(3),EVERY(4);
                  Field_To_Match Varchar2 (30 Char)   -- CREDITING_DEFINITIONS.CREDITING_RUP_FLD_ID_TO_MATCH IS Field id to match effective dated
				  )
/
