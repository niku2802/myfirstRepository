CREATE TYPE              "OBJTYPE_TERRITORIES_MAP" FORCE AS OBJECT
      (
      METRIC_TABLE_ID       NUMBER(10),
      ENTITY_ID             NUMBER(10),
      FIELD_ID              NUMBER(10),
      SEARCH_OPTION         NUMBER(1)
      )
/
