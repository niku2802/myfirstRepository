CREATE TYPE              "OBJTYPE_URT_INFO" -- Unmatched Records Result Table  -- not reqd for US1
FORCE AS OBJECT ( Result_Table_Name Varchar2 (30 Char),
                                    nonTechnical_Column_Names CLOB)
/
