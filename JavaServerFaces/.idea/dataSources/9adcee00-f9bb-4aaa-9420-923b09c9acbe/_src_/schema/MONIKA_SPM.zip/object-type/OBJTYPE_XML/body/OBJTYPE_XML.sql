CREATE TYPE BODY              "OBJTYPE_XML" 
		  IS
			 ORDER MEMBER FUNCTION equals(pin_compared_xml objtype_xml)
			 RETURN NUMBER
			 IS
			 BEGIN
			  -- convert the xmls in clobs and compare them
			  RETURN dbms_lob.compare(SELF.v_xml.getClobVal(), pin_compared_xml.v_xml.getClobVal());
			 EXCEPTION
			  WHEN OTHERS THEN RETURN 0;
			 END;
		  END;
/
