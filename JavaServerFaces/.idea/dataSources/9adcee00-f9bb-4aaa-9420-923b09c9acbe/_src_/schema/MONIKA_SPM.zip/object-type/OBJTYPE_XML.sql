CREATE TYPE              "OBJTYPE_XML" IS OBJECT(

          v_xml XMLTYPE,

          ORDER MEMBER FUNCTION equals(pin_compared_xml objtype_xml)
            RETURN NUMBER
         )
/
