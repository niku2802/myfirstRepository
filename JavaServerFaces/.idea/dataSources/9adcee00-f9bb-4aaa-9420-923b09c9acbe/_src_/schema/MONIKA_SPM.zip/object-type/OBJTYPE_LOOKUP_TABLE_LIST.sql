CREATE TYPE              "OBJTYPE_LOOKUP_TABLE_LIST" FORCE AS OBJECT
			(
			  LOOKUP_COLUMN       varchar2(30),
			  TABLE_NAME          varchar2(30),
			  LOWER_VALUE_OPTION  numeric(2),
			  HIGHER_VALUE_OPTION numeric(2),
			  USED_FOR            numeric(1),
			  VARY_BY_FIELDS      varchar2(2000),
			  FROM_CLAUSE         varchar2(32767),
			  WHERE_CLAUSE        varchar2(32767),
			  EFFECTIVE_DATE_PROPS OBJTYPE_DATE_RANGE_INTERNAL
			)
/
