CREATE TYPE              "OBJTYPE_RTE_INFO" -- single row
FORCE AS OBJECT ( ROLLUP_TO_ENTITY_BASE_ID NUMBER(10), -- CREDIT_RUP_TO_ENTITY_OPTIONS.CRTEO_ENTITY_ID IS Entity id roll up to; --PI_RTE_INFO(1).ROLLUP_TO_ID; -- CHANGED from ROLLUP_TO_ID
                  ROLLUP_TO_ENTITY_EQ_ID NUMBER(10), -- Rollup FROM EQUIVALENT Entity ID -- ideally the Crediting Entity ID -- CREDITING_DEFINITIONS.CREDITING_ENTITY_ID IS Crediting Entity ID; -- ADDED NEW
                  Levels_To_Rup_To Number(1), -- CREDIT_RUP_TO_ENTITY_OPTIONS.CRTEO_ENTITY_LEVEL IS ANY(0),ONE(1),TWO(2),THREE(3),FOUR(4),FIVE(5),SIX(6),SEVEN(7),Eight(8),NINE(9); -- null for US1 when Rollup_To_Entity is only once in the Hierarchy --PI_RTE_INFO(1).Levels_To_Rup_To;
                  Aggregate_Values Number(1), -- CREDIT_RUP_TO_ENTITY_OPTIONS.CRTEO_ENTITY_AGGREGATE IS Aggregate value option 0-NO 1-YES; -- 0 for US1 --PI_RTE_INFO(1).Aggregate_Values;
                  INCLUDE_NO_RUP_RESULT NUMBER(1) -- CREDIT_RUP_TO_ENTITY_OPTIONS.CRTEO_INCLUDE_NON_ROLLEDUP_REC IS Display result table for not rolled up data 0-NO 1-YES; -- 0 for US1 --PI_RTE_INFO(1).INCLUDE_NO_RUP_RESULT; --unused
				  )
/
