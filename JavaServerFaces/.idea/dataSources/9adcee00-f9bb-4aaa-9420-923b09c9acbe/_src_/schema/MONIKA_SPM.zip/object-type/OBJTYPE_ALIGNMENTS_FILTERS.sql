CREATE TYPE              "OBJTYPE_ALIGNMENTS_FILTERS" 
      FORCE AS OBJECT
      (
         LOGIC_CONDITION_ID NUMBER (10),                                -- NOT NULL
         ENTITY_COLUMN_NAME VARCHAR2 (30 CHAR),                 -- NOT NULL
         ENTITY_TYPE NUMBER(1),                                             -- NOT NULL                                                                                    -- 1 - ALIGNMENT, 2 - ALIGNED
         FILTER_CRITERIA NUMBER(1),                                        -- NOT NULL                                                                                    -- 1 - INCLUDE, 2 - EXCLUDE, 3 - ALL
         -- FILTER_EVALUATION VARCHAR2(4000 CHAR),                   -- NULL            -- NULL WHEN FILTER_ENTITY_VALUES_CRITERIA = 3                           /*OF-4022 and OF-10094*/
         FILTER_EVALUATION_INCLUDE VARCHAR2(4000 CHAR),                   -- NULL            -- NULL WHEN FILTER_ENTITY_VALUES_CRITERIA = 3          /*OF-4022 and OF-10094*/
         FILTER_EVALUATION_EXCLUDE VARCHAR2(4000 CHAR),                   -- NULL            -- NULL WHEN FILTER_ENTITY_VALUES_CRITERIA <> 2        /*OF-4022 and OF-10094*/
         ALIGNMENT_FILTER_CRITERIA NUMBER(1),                       -- NULL            -- NULL WHEN ALIGNMENT_METHOD_OPTION <> 2          -- 1 - INCLUDE, 2 - EXCLUDE
         ALIGNMENT_FILTER_EVALUATION VARCHAR2(4000 CHAR),  -- NULL            -- NULL WHEN ALIGNMENT_METHOD_OPTION <> 2
         ALIGNMENT_FLT_VIA_HIERARCHY  NUMBER(1)                  -- NULL            -- NULL WHEN ALIGNMENT_METHOD_OPTION <> 4          -- If Alignment Entity is part of a Hierarchy, then whether Alignment Filter is based on Hierarchy or not: 0 = NO (Based on SPECIFIED VALUES), 1 = YES (Based on any Valid Filterable Entity, i.e. Upper Entity or the Alignment Entity itself, via the Hierarchy)   -- OF-7722
      )
/
