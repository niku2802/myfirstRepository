CREATE TYPE BODY              "OBJTYPE_LISTAGG_JAVA" 
	AS
		STATIC FUNCTION odciaggregateinitialize
		(
			pinout_aggobj	IN OUT OBJTYPE_LISTAGG_JAVA
		) RETURN NUMBER IS
		BEGIN
			pinout_aggobj := OBJTYPE_LISTAGG_JAVA(NULL, 0, ',', NULL);
			RETURN odciconst.success;
		END;

		MEMBER FUNCTION odciaggregateiterate
		(
			 SELF			IN OUT OBJTYPE_LISTAGG_JAVA
			,pin_word_dlm	IN OBJTYPE_WORD_DLM
		) RETURN NUMBER IS
		BEGIN
			SELF.delimiter	:= pin_word_dlm.delimiter;
			SELF.maxcount	:= pin_word_dlm.maxcount;

			IF (SELF.maxcount IS NULL OR SELF.wordcount < SELF.maxcount) AND  PIN_WORD_DLM.WORD IS NOT NULL THEN
				--dbms_output.put_line(SELF.wordcount || ' - ' || pin_word_dlm.word);
				SELF.wordlist := SELF.wordlist || pin_word_dlm.word || SELF.delimiter;
				SELF.wordcount := SELF.wordcount + 1;
			END IF;
			RETURN odciconst.success;
		END;

		MEMBER FUNCTION odciaggregateterminate
		(
			 SELF			IN OBJTYPE_LISTAGG_JAVA
			,pout_retval	OUT CLOB
			,pin_flags		IN NUMBER
		) RETURN NUMBER IS
		BEGIN
			pout_retval := SUBSTR(SELF.wordlist, 1, LENGTH(SELF.wordlist) - LENGTH(SELF.delimiter));
			RETURN odciconst.success;
		END;

		MEMBER FUNCTION odciaggregatemerge
		(
			 SELF			IN OUT OBJTYPE_LISTAGG_JAVA
			,pin_aggobj1	IN OBJTYPE_LISTAGG_JAVA
		) RETURN NUMBER IS
		BEGIN
			IF SELF.wordcount = SELF.maxcount THEN
				NULL;
			ELSIF SELF.maxcount IS NULL
				OR (SELF.wordcount + pin_aggobj1.wordcount) < SELF.maxcount THEN
				SELF.wordlist := SELF.wordlist || pin_aggobj1.wordlist;
				SELF.wordcount := SELF.wordcount + pin_aggobj1.wordcount;
			ELSE
				SELF.wordlist := SELF.wordlist || pin_aggobj1.wordlist;
				SELF.wordlist := SUBSTR(SELF.wordlist, 1, INSTR(SELF.wordlist, SELF.delimiter, 1, SELF.maxcount));
				SELF.wordcount := SELF.maxcount;
			END IF;

			RETURN odciconst.success;
		END;
	END;

/
