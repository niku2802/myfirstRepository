CREATE TYPE              "OBJTYPE_DATA_ENTITY_INFO" /*Data Entities*/
   FORCE AS OBJECT
   (
      DE_TABLE_NAME VARCHAR2 (30 CHAR),
      DE_NAME VARCHAR2 (30 CHAR),
      DE_COLUMN_NAME VARCHAR2 (30 CHAR),                   -- column name of entity
      DE_BUSINESS_NAME VARCHAR2 (30 CHAR),                 -- Business name of entity field
      DE_PHYSICAL_COLUMN_NAME VARCHAR2 (30 CHAR)           -- Actual physical name of business field
   )
/
