CREATE TYPE              "OBJTYPE_TBL_CALC_REL" FORCE AS OBJECT(INPUT_KEY NUMBER(10),
                                                                                        OUTPUT_KEY NUMBER(10),
                                                                                        FIXED_VALUE CLOB)
/
