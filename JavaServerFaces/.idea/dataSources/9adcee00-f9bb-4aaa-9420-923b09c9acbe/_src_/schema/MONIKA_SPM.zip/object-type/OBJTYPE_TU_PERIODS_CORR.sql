CREATE TYPE              "OBJTYPE_TU_PERIODS_CORR" AS OBJECT
		(
			OTPC_ID                	NUMBER(10)       ,--  VTPC_ID 				:Ordering column
			OTPC_NAME            	VARCHAR2(30)     ,--  VTPC_NAME 			:Name of the primary TU period
			OTPC_CORR_NAME        	VARCHAR2(30)     ,--  VTPC_CORR_NAME 		:Name of the secondary TU period
			OTPC_START            	NUMBER(10)       ,--  VTPC_START            :Starting month of primary TU
			OTPC_CORR_START       	NUMBER(10)       ,--  VTPC_CORR_START 		:Starting month of secondary TU
			OTPC_PERIOD_NUMBER      NUMBER(2)        ,--  VTPC_PERIOD_NUMBER    :Internal order of the primary TU periods
			OTPC_PERIOD_NUMBER_CORR NUMBER(2)        ,--  VTPC_PERIOD_NUMBER_CORR :Internal order of the secondary TU periods
			OTPC_YEAR_OFFSET      	NUMBER(1)  	      --  VTPC_YEAR_OFFSET 	 	:prev year 1,current year 2, next year 3
		)
/
