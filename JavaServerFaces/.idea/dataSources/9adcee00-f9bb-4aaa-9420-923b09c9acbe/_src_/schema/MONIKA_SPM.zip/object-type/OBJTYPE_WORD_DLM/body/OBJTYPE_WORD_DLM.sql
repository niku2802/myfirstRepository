CREATE TYPE BODY              "OBJTYPE_WORD_DLM" 
				AS
					MAP MEMBER FUNCTION sort_key RETURN VARCHAR2 IS
					BEGIN
						RETURN word;
					END;
				END;

/
