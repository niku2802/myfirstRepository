CREATE TYPE              "OBJTYPE_UDT_INFO" /* Object for UDT = Uncredited_Data_Table Info */
	 FORCE AS OBJECT
	 (
	   UDT_NAME                                VARCHAR2 (30 CHAR),            -- NOT NULL -- Uncredited_Data_Table_Name
	   -- UDT_NON_TECH_COL_LIST           COLTYPE_UDT_NON_TECH_COL_LIST          -- NOT NULL
	   UDT_NON_TECH_COL_LIST           CLOB          -- NOT NULL
	 )
/
