CREATE TYPE              "OBJTYPE_WORD_DLM" AS OBJECT
							(
								 word			VARCHAR2(4000)
								,delimiter	VARCHAR2(4000)
								,maxcount	NUMBER(10)
								,MAP MEMBER FUNCTION SORT_KEY RETURN VARCHAR2
							)
/
