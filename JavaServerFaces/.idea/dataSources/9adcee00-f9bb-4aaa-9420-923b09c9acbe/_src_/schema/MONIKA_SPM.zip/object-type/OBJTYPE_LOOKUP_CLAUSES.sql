CREATE TYPE              "OBJTYPE_LOOKUP_CLAUSES" FORCE as object
		(
		  LOOKUP_SQL      clob,
		  CASE_SQL        clob,
		  TIERS_TABLE_SQL clob
		)
/
