CREATE TYPE              "OBJTYPE_FTR_INFO" -- Field to Rollup To for the Rollup_To_Entity -- all those fields who have value 1 set for CREDITING_FIELDS.CF_INCLUDE_IN_ROLLUP IS Include field in rollup results 0-no 1-yes;
FORCE AS OBJECT ( Field_Business_Name Varchar2 (30 Char),  -- Field Business Name -- might be needed for logging from SP later -- not needed for US1
                                      Column_Names_In_Crt Varchar2 (30 Char), -- Field physical column name
                                                          decimal_length Number(10) )
/
