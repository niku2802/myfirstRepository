CREATE TYPE              "OBJTYPE_DELETE_INDEX" 
   FORCE AS OBJECT
(
   BUSINESS_NAME VARCHAR2 (60 CHAR),                               -- NOT NULL
   DEF_ID NUMBER (10)                                              -- NOT NULL
)
/
