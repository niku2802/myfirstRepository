CREATE TYPE              "OBJTYPE_DE_COL_TYPE_LIST" FORCE AS OBJECT
                          (
                          COLUMN_NAME  VARCHAR2(30 CHAR),
                          COLUMN_HEADER VARCHAR2(250 CHAR),
                          COLUMN_TYPE  NUMBER(1),
                          DECIMAL_PRECISION NUMBER(10),
                          FIXED_LENGTH  NUMBER(10)
                          )
/
