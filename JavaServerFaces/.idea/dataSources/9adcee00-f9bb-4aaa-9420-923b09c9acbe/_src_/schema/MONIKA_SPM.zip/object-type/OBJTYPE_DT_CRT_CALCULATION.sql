CREATE TYPE              "OBJTYPE_DT_CRT_CALCULATION" FORCE AS OBJECT
                  (
                   FIELD_TO_TOTAL VARCHAR2(30)
                  ,RESULT_FIELD TABLETYPE_DT_CHAR
                  ,GROUPING_COLUMNS VARCHAR2(1000)
                  ,LARGER_TIME_SPAN OBJTYPE_DT_MF_ID_NAME_ALIAS
                  ,ORDERING_COLUMNS VARCHAR2(4000)
                  )
/
