CREATE TYPE              "OBJ_XML_DET" is object (  XML_ID NUMBER,
																					FILE_NAME VARCHAR2(3000 CHAR),
																					FILE_INTERNALNAME VARCHAR2(3000 CHAR),
																					FILE_SIZE VARCHAR2(3000 CHAR),
																					FILE_UPLOADEDON VARCHAR2(3000 CHAR)
																			      )
/
