CREATE TYPE              "OBJTYPE_CDT_INFO" /*CreditingDataTable */
   FORCE AS OBJECT
   (
      CDT_NAME VARCHAR2 (30 CHAR),                               -- dataTableName
      CDT_BUSINESS_NAME VARCHAR2 (30 CHAR),                      -- dataTableDefinitionName
      CDT_ALIAS VARCHAR2 (30 CHAR),                              -- dataTableAlias
      CDT_FILTER_JOIN_CLAUSE CLOB,                    -- filterJoinClause -- This will contain combined JOIN clauses for PERIOD_Fields and All Entities other than Data Entities used in Data Table Filter. /*OF-5370*/
      CDT_FILTER_WHERE_CLAUSE CLOB,                   -- filterWhereClause -- This will contain the Filter Evaluation for Data Table.
      CDT_INPUT_COMPARISON_COL_NAME VARCHAR2 (30 CHAR),          -- dateOrPeriodColumnNameInDTToCompare
      CDT_INPUT_COMPARISON_COL_TYPE NUMBER (1),                  -- NOT_EFFECTIVE_DATE(1), EFFECTIVE_START_DATE(2), EFFECTIVE_END_DATE(3), NOT_EFFECTIVE_PERIOD(4), EFFECTIVE_START_PERIOD(5), EFFECTIVE_END_PERIOD(6)  ComparisonFieldEffectiveDatingType
      CDT_DATE_OR_PERIOD_OPTION NUMBER (1),                      -- 1 - None, 2 - Date, 3 - Period, 4 - Date Range, 5- Period Range     -- OF-a
      CDT_START_COLUMN_NAME VARCHAR2 (30 CHAR),                  -- null when CDT_DATE_OR_PERIOD_OPTION = 1                         -- OF-a
      CDT_END_COLUMN_NAME VARCHAR2 (30 CHAR)                     -- null when CDT_DATE_OR_PERIOD_OPTION in 1,2,3                     -- OF-a
   )
/
