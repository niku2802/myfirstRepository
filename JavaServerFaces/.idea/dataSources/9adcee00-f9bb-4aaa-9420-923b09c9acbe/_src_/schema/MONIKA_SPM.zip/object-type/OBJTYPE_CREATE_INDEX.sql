CREATE TYPE              "OBJTYPE_CREATE_INDEX" 
   FORCE AS OBJECT
(
   BUSINESS_NAME VARCHAR2 (60 CHAR),                               -- NOT NULL
   DEF_ID NUMBER (10),                                             -- NOT NULL
   COLUMN_LIST TABLETYPE_CHARMAX,                                  -- NOT NULL
   IS_UNIQUE NUMBER (1),                                           -- NOT NULL
   RECREATE_INDEX_ON_COL_DROP NUMBER (1)                           -- NOT NULL
)
/
