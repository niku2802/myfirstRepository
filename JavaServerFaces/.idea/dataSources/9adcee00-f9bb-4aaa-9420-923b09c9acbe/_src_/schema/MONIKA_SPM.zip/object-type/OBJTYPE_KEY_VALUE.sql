CREATE TYPE              "OBJTYPE_KEY_VALUE" is object (v_key varchar2(250 char),v_value varchar2(250 char))
/
