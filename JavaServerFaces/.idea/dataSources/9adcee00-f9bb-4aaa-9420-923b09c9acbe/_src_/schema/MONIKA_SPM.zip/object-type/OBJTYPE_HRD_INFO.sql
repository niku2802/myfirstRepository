CREATE TYPE              "OBJTYPE_HRD_INFO" 
FORCE AS OBJECT ( Relationship_Table_Name Varchar2 (30 Char),
                                          Upper_Entity_Id Number(10),
                                          Lower_Entity_Id Number(10),
                                          Upper_Column_Name Varchar2 (30 Char),
                                          lower_column_name varchar2 (30 Char),
                      RecordDatingOption number(1),
                      timeunit_id number(10)
                      )
/
