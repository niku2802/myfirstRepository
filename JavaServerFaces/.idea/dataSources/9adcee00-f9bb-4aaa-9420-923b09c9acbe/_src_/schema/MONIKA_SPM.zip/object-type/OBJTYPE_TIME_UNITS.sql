CREATE TYPE              "OBJTYPE_TIME_UNITS" AS OBJECT
       (
            OTU_ID          		NUMBER(10)      ,--	VTU_ID 			     :Ordering column
            OTU_NAME        		Varchar2(30)    ,--  VTU_NAME 		     :TU name
            OTU_IS_FISCAL   		NUMBER(1)       ,--  VTU_IS_FISCAL 	     :TU is fiscal or not
            OTU_DIVISON_FACTOR 		NUMBER(10)      ,--  VTU_DIVISON_FACTOR  :no of months in the TU period
			OTU_OFFSET          	NUMBER(10)       --  VTU_OFFSET          :total no of periods.For eg for semester 2
        )
/
