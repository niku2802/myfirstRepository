CREATE TYPE              "OBJTYPE_RRT_INFO" -- single row
FORCE AS OBJECT ( Result_Table_Name Varchar2 (30 Char), -- Rollup Result Table name -- unique for every Rollup_To_Entity
                                    nonTechnical_Column_Names CLOB -- mostly not usable ever -- definitely not for US1
                                    )
/
