CREATE TYPE              "OBJTYPE_DT_MR_OP_INPUTS" FORCE AS OBJECT
    (    INPUT_ID               NUMBER(10)
        ,INPUT_ORDER            NUMBER(10)
        ,INPUT_TYPE             NUMBER(2)
        ,INPUT_OUTPUT_ID        NUMBER(10)
        ,INPUT_TABLE_ID         NUMBER(10)
        ,INPUT_FILTER_ID        NUMBER(10)
    )
/
