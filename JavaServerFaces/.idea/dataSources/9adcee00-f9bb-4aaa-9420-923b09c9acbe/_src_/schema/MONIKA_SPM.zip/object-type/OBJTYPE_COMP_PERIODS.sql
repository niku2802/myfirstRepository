CREATE TYPE              "OBJTYPE_COMP_PERIODS" FORCE AS OBJECT (TABLE_NAME     VARCHAR2(30)
                                                                                  ,PRIOR_PERIOD_IDS  VARCHAR2(500)
                                                                                  ,INPUT_NUMBER  NUMERIC(10))
/
