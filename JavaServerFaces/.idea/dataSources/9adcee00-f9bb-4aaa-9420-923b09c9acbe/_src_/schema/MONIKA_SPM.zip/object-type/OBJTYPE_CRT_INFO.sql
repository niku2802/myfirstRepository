CREATE TYPE              "OBJTYPE_CRT_INFO" /*CreditingResultTable */
   FORCE AS OBJECT
   (
      CRT_NAME VARCHAR2 (30 CHAR),                               -- CreditingResultTableName -- To be used as the Input table name for Rollup
      -- Following not reqd for US1
      CRT_DATE_OR_PERIOD_OPTION NUMBER (1),                      -- 1 - None, 2 - Date, 3 - Period, 4 - Date Range, 5- Period Range
      CRT_START_COLUMN_NAME VARCHAR2 (30 CHAR),                  -- null when CRT_DATE_OR_PERIOD_OPTION = 1
      CRT_END_COLUMN_NAME VARCHAR2 (30 CHAR),                     -- null when CRT_DATE_OR_PERIOD_OPTION in 1,2,3
	  CRT_IS_EFFECTIVE NUMBER (1)                    -- 0 - No, 1 - Yes    -- OF-a
   )
/
