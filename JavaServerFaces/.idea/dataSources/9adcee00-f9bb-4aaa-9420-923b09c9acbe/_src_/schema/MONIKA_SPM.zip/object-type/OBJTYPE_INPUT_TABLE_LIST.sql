CREATE TYPE              "OBJTYPE_INPUT_TABLE_LIST" FORCE AS OBJECT (TABLE_NAME     VARCHAR2(30)
                                                                                  ,FROM_CLAUSE   CLOB
                                                                                  ,WHERE_CLAUSE  CLOB
                                                                                  ,TABLE_TYPE    NUMERIC(2)
                                                                                  ,INPUT_NUMBER  NUMERIC(10))
/
