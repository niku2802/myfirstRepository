CREATE PROCEDURE filtersMigrationTool
  AS LANGUAGE JAVA NAME 'FilterMigrationTool.migrate()';
/
