CREATE PROCEDURE PortalViewsFiltersUpgrade
 AS LANGUAGE JAVA NAME  'PortalViewsFiltersUpgrade.upgrade()';
/
