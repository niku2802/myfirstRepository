CREATE procedure PVFiltersDuplicationTool(cursor_value in sys_refcursor) as
  LANGUAGE JAVA NAME 'PVFiltersDuplicationTool.updateFilters(java.sql.ResultSet)';
/
