CREATE procedure PVBackupFiltersDuplicationTool(cursor_value in sys_refcursor) as
  LANGUAGE JAVA NAME 'PVBackupFiltersDuplicationTool.updateFilters(java.sql.ResultSet)';
/
