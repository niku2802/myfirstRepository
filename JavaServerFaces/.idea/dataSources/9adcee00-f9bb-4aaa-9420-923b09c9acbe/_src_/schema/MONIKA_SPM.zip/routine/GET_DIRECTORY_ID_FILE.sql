CREATE procedure GET_DIRECTORY_ID_FILE(pathWithFileName IN VARCHAR2, root IN VARCHAR2,fileName OUT VARCHAR2,dirId OUT number) AS
  LANGUAGE JAVA NAME 'DirectoryCreator.getDirectoryAndFileName(java.lang.String , java.lang.String , java.lang.String[] , java.lang.Long[] )';
/
