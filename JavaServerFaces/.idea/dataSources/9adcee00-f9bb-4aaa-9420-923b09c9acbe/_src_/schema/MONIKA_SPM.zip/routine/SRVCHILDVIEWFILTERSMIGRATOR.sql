CREATE PROCEDURE SRVChildViewFiltersMigrator
 AS LANGUAGE JAVA NAME  'SRVChildViewFiltersMigrator.migrate()';
/
