CREATE PACKAGE BODY performance_analyzer IS

PROCEDURE logging(pi_run_id      IN NUMBER,
                  pi_lm_message  IN CLOB,
                  pi_log_details IN coltype_log_details,
                  pi_level IN NUMBER default NULL) IS
  v_lm_id number;
  v_log_start_time TIMESTAMP;
  v_level number := 1; -- warning
BEGIN
  IF  pi_level IS NOT NULL THEN
    v_level:= pi_level;
  END IF;
  SELECT from_tz(CAST(to_timestamp(to_char(systimestamp,
                                           'rrrr-mm-dd hh24:mi:ss.ff'),
                                   'YYYY-MM-DD HH24:MI:SS.ff') AS TIMESTAMP),
                 tz_offset(sessiontimezone)) at TIME ZONE 'UTC'
    INTO v_log_start_time
    FROM dual;

  logs.logs_upsert_data(pin_lm_rd_id           => pi_run_id,
                        pin_lm_level           => v_level,
                        pin_lm_message         => pi_lm_message,
                        pin_lm_message_details => pi_log_details,
                        pin_lm_start_date      => v_log_start_time,
                        pin_lm_update_date     => NULL,
                        pinout_lm_id           => v_lm_id);
END;

PROCEDURE get_key_count(pi_def_id         IN NUMBER,
                        pi_table_type     IN VARCHAR2,
                        pi_msg_flag       IN NUMBER,
                        pi_property_value IN NUMBER,
                        pi_run_id         IN NUMBER,
                        po_flag           OUT NUMBER) IS
  v_count          NUMBER;
  v_table_name     VARCHAR2(30 CHAR);
  v_log_details    coltype_log_details := coltype_log_details();
  v_lm_message     clob;
BEGIN

  IF pi_table_type = 'DATA_TABLE' THEN
    SELECT dt_name, COUNT(*)
      INTO v_table_name, v_count
      FROM data_tables tab
     INNER JOIN tables t
        ON tab.dt_tables_id = t.tables_id
     INNER JOIN table_columns tc
        ON tc.tc_tables_id = t.tables_id
     WHERE tc_logic_type in (1, 5)
       AND dt_id = pi_def_id
     GROUP BY dt_name;
  END IF;

  IF v_count > pi_property_value AND pi_msg_flag = 1 THEN
    po_flag          := 1;
    v_lm_message     := 'This table has ' || v_count ||
                        ' key fields. Please review if you need so many.';
    v_log_details.extend(2);
    v_log_details(1) := rtype_log_details('Table ' || v_table_name || ' has ' || v_count ||
                                          ' key fields. It is generally recommended that number of key fields in a table should be minimum required (ideally one).',
                                          1);
    v_log_details(2) := rtype_log_details('You can consider creating a special key field only meant to serve as the business key.', 2);
    logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
  END IF;
exception when no_data_found
    then po_flag := 0;
END get_key_count;


PROCEDURE get_fields_count(pi_def_id         IN NUMBER,
                           pi_table_type     IN VARCHAR2,
                           pi_property_value IN VARCHAR2,
                           pi_msg_flag       in number,
                           pi_run_id         IN NUMBER,
                           po_flag           OUT NUMBER)

IS
  v_count   NUMBER;
  v_dt_name VARCHAR2(30 CHAR);
  v_flag           NUMBER := 0;
  v_log_details    coltype_log_details := coltype_log_details();
  v_lm_message     clob;
BEGIN
  IF pi_table_type = 'DATA_TABLE' THEN
    SELECT dt_name, COUNT(*)
      INTO v_dt_name, v_count
      FROM data_tables tab
     INNER JOIN tables t
        ON tab.dt_tables_id = t.tables_id
     INNER JOIN table_columns tc
        ON tc.tc_tables_id = t.tables_id
     WHERE tc_column_type IN (1, 2)
       AND dt_id = pi_def_id
     GROUP BY dt_name;
  END IF;

  IF v_count > pi_property_value and pi_msg_flag = 1  THEN
    v_lm_message     := 'This table has ' || v_count || ' fields and entities. Please review if you need so many.';
    v_log_details.extend(1);
    v_log_details(1) := rtype_log_details('Tables tend to perform very slowly after a certain number of columns. Consider splitting this table into two or more tables.',
                                          1);
    logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
    v_flag := 1;
  END IF;
  po_flag := v_flag ;
END get_fields_count;


PROCEDURE get_record_count(pi_def_id         IN NUMBER,
                           pi_run_id         IN NUMBER,
                           pi_property_value IN NUMBER,
                           pi_table_type     IN varchar2,
                           pi_msg_flag       IN NUMBER,
                           po_record_count   OUT NUMBER,
                           po_flag           OUT NUMBER) IS
  v_flag           NUMBER := 0;
  v_log_details    coltype_log_details := coltype_log_details();
  v_lm_message     clob;
  v_table_name     VARCHAR2(30 CHAR);
BEGIN



  IF pi_table_type = 'DATA_TABLE' THEN
  SELECT t.tables_physical_name
      INTO v_table_name
      FROM data_tables tab
     INNER JOIN tables t
        ON tab.dt_tables_id = t.tables_id
     WHERE dt_id = pi_def_id;


  ELSIF pi_table_type = 'ENTITY_TABLE' THEN
    SELECT t.tables_physical_name
      INTO v_table_name
      FROM entities tab
     INNER JOIN tables t
        ON tab.entity_tables_id = t.tables_id
     WHERE entity_id = pi_def_id;

  ELSIF pi_table_type = 'ASSIGNMENT_TABLE' THEN
    SELECT  t.tables_physical_name
      INTO v_table_name
      FROM entity_assignments tab
     INNER JOIN tables t
        ON tab.ea_tables_id = t.tables_id
     WHERE ea_id = pi_def_id;
  END IF;

  SELECT nvl(num_rows,0)
    INTO po_record_count
    FROM user_tables
   WHERE table_name = v_table_name;

  IF po_record_count > pi_property_value AND pi_msg_flag = 1 THEN
    v_lm_message     := 'This entity table has ' || po_record_count || ' records. Please review if it should be an entity table.';
    v_log_details.extend(2);
    v_log_details(1) := rtype_log_details('Entity tables should generally only have non-transactional, factual data (e.g. Cities, Employees, Products). Entity tables are not optimized for large number of records.',
                                          1);

    v_log_details(2) := rtype_log_details('Please review if this table should be entity table, or a data table.', 1);

    logging(pi_run_id      => pi_run_id,
           pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
    v_flag := 1;
  END IF;
  po_flag := v_flag;
END get_record_count;

PROCEDURE get_table_size(pi_def_id         IN NUMBER,
                         pi_run_id         IN NUMBER,
                         pi_property_value IN NUMBER,
                         pi_table_type     IN VARCHAR2,
                         pi_msg_flag       IN NUMBER,
                         po_record_count   OUT NUMBER,
                         po_table_size     OUT NUMBER,
                         po_flag           OUT NUMBER)

IS
  v_flag           NUMBER := 0;
  v_log_details    coltype_log_details := coltype_log_details();
  v_lm_message     clob;

  v_block_size user_tablespaces.block_size%TYPE;
  v_table      VARCHAR2(30);
  CURSOR c_size(pi_block_size user_tablespaces.block_size%TYPE) IS
    SELECT (blocks) * (pi_block_size - avg_space) / (1024 * 1024), num_rows
      FROM user_tables
     WHERE table_name = v_table;

  CURSOR c_block_size IS
    SELECT block_size
      FROM user_tablespaces
     WHERE tablespace_name IN
           (SELECT tablespace_name
              FROM user_tables
             WHERE table_name = v_table);
BEGIN


IF pi_table_type = 'DATA_TABLE' THEN

  SELECT t.tables_physical_name
    INTO v_table
    FROM data_tables dt
   INNER JOIN tables t
      ON dt.dt_tables_id = t.tables_id
   WHERE dt.dt_id = pi_def_id;

  ELSIF pi_table_type = 'ENTITY_TABLE' THEN

    SELECT t.tables_physical_name
    INTO v_table
    FROM entities dt
   INNER JOIN tables t
      ON dt.entity_tables_id = t.tables_id
   WHERE dt.entity_id = pi_def_id;
  END IF;
   --  commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => V_TABLE, PI_MODE  => 2);
  OPEN c_block_size;
  FETCH c_block_size
    INTO v_block_size;
  CLOSE c_block_size;

  OPEN c_size(v_block_size);
  FETCH c_size
    INTO po_table_size, po_record_count;
  CLOSE c_size;

  IF po_table_size > pi_property_value AND pi_msg_flag = 1 THEN

    v_lm_message     := 'This table has ' || po_record_count ||
                        ' records and approximately ' || po_table_size ||
                        ' MB of data. Consider moving out data that you don''t need often.';

    v_log_details.extend(1);
    v_log_details(1) := rtype_log_details('Tables tend to perform very slowly after a certain amount of data. Consider splitting this table into two or more tables, by moving old or rarely used data to an archive table.',
                                          1);

    logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
    v_flag := 1;
  END IF;

  po_flag := v_flag;
END get_table_size;

FUNCTION  get_mf_fields_in_adv_exp(pi_operation_id in number) RETURN TABLETYPE_ID_ID PIPELINED
AS
  type string_array is table of varchar2(1000) index by varchar2(1000);
  v_left_field      varchar2(30);
  v_right_field     varchar2(30);
  v_left_input      varchar2(30);
  v_right_input     varchar2(30);
  v_operator        varchar2(30);
  v_left_field_id   number(10);
  v_right_field_id  number(10);
  v_left_input_id   number(10);
  v_right_input_id  number(10);
  v_left_text       varchar2(100);
  v_right_text      varchar2(100);
  v_has_prior       number(1);
  v_input_order     number;
BEGIN

for op in (select '=' as v_operator from dual union all
           select '<>' from dual union all
           select '>' from dual union all
           select '>=' from dual union all
           select '<' from dual union all
           select '<=' from dual union all
           select 'LIKE' from dual union all
           select 'NOT LIKE' from dual union all
           select 'BETWEEN' from dual union all
           select 'NOT BETWEEN' from dual)
loop

  for c in (select regexp_substr(ex, '^\[(.*?)\]', 1) as left_input,
                   regexp_substr(ex, '\[([^]]+)\]$', 1) as right_input,
                   operation
            from (
                    select  distinct to_char(regexp_substr(od_definition, '\[([^]]+)\] ' || op.v_operator || ' \[([^]]+)\]', 1, level)) as ex,
                     o.dto_name as operation
                    from dt_processes p inner join dt_operations o on p.dtp_id = o.dto_dtp_id
                    inner join dt_merge_fields m on o.dto_id = m.dtmf_id
                    inner join dt_mf_options mo on m.dtmf_id = mo.dtmfo_dtmf_id
                    inner join object_definitions o on mo.dtmfo_adv_cond_id = o.od_id
                    where o.dto_id = pi_operation_id and od_definition like '%] ' || op.v_operator || ' [%'
                    connect by level <= regexp_count(od_definition, '\[([^]]+)\] ' || op.v_operator || ' \[([^]]+)\]')
                  )
            order by operation
            )
  loop
    if regexp_substr(c.left_input, '^\[[a-zA-Z]+[\.[0-9]+]*\]') is not null
    then
      v_left_input_id := to_number(regexp_substr(c.left_input, '\.([0-9]*)\.([0-9]*)\]$', 1, 1, null, 1));
      v_left_field_id := to_number(regexp_substr(c.left_input, '([0-9]*)\]$', 1, 1, null, 1));

      select count(dtin_dtout_id) into v_has_prior
      from dt_inputs
      where dtin_id = v_left_input_id;

      select dtin_order into v_input_order
      from dt_inputs
      where dtin_id = v_left_input_id;

      if v_has_prior = 0
      then
        select o.or_name into v_left_input
        from dt_inputs i inner join table_references tr on i.dtin_tref_id = tr.tref_id
             inner join object_registration o on o.or_id = tr.tref_definition_id
             where i.dtin_id = v_left_input_id;
      else
        case
          when v_input_order is null then
            v_left_input := 'Priorinput.' || 'Deletedinput';
          when v_input_order = 0 then
            v_left_input := 'Priorinput.' || 'Initialinput';
          else
            v_left_input := 'Priorinput.' || 'Mergedinput' || to_char(v_input_order);
        end case;

      end if;
      select fld_business_name into v_left_field from fields where fld_id = v_left_field_id;
      v_left_text := v_left_field  || '[' || v_left_input || ']';
    else
      v_left_text := c.left_input;
    end if;

    if regexp_substr(c.right_input, '^\[[a-zA-Z]+[\.[0-9]+]*\]') is not null
    then
      v_right_input_id := to_number(regexp_substr(c.right_input, '\.([0-9]*)\.([0-9]*)\]$', 1, 1, null, 1));
      v_right_field_id := to_number(regexp_substr(c.right_input, '([0-9]*)\]$', 1, 1, null, 1));

      select count(dtin_dtout_id)into v_has_prior
      from dt_inputs
      where dtin_id = v_right_input_id;

      select dtin_order into v_input_order
      from dt_inputs
      where dtin_id = v_right_input_id;

      if v_has_prior = 0
      then
        select o.or_name into v_right_input
        from dt_inputs i inner join table_references tr on i.dtin_tref_id = tr.tref_id
             inner join object_registration o on o.or_id = tr.tref_definition_id
             where i.dtin_id = v_right_input_id;
      else
        case
          when v_input_order is null then
            v_right_input := 'Priorinput.' || 'Deletedinput';
          when v_input_order = 0 then
            v_right_input := 'Priorinput.' || 'Initialinput';
          else
            v_right_input := 'Priorinput.' || 'Mergedinput' || to_char(v_input_order);
        end case;

      end if;
      select fld_business_name into v_right_field from fields where fld_id = v_right_field_id;
      v_right_text := v_right_field  || '[' || v_right_input || ']';
    else
      v_right_text := c.right_input;
    end if;

    if v_left_input_id is not null and v_left_field_id is not null then
      pipe row(OBJTYPE_ID_ID(v_left_input_id, v_left_field_id));
    end if;
    if v_right_input_id is not null and v_right_field_id is not null then
      pipe row(OBJTYPE_ID_ID(v_right_input_id, v_right_field_id));
    end if;

  end loop;

end loop;

END get_mf_fields_in_adv_exp;

procedure get_fields_in_use(pi_table_id number,
                          pi_process_id TABLETYPE_NUMBER,
                          po_fields_in_use out TABLETYPE_CHARMAX) as

begin
  for c in (select distinct DTO_ID
              from DT_PROCESSES
              join DT_OPERATIONS on DTP_ID = DTO_DTP_ID
             where DTP_ID in (select column_value from table(PI_PROCESS_ID))
            ) loop
    insert into FIELDS_IN_DT_FILTERS_JOINS(TC_PHYSICAL_NAME)
    select TC_PHYSICAL_NAME
      from (select INPUT_ID INPUT_ID,
                   coalesce(nvl(TC_FLD_ID, DTORF_FLD_ID), nvl(TC_ENTITY_ID, DTORF_ENTITY_ID)) FLD_ID,
                   tc.TC_PHYSICAL_NAME
              from (select DTO_RESULT_FIELDS_TYPE_IN,
                           TREF_ID_IN,
                           rownum TABLE_ORDER,
                           INPUT_ID,
                           OPERATION_ID_IN,
                           OPERATION_TYPE_IN
                      from (select DTO_RESULT_FIELDS_TYPE_IN,
                                   OPERATION_ID,
                                   TREF_ID_IN,
                                   OPERATION_TYPE_IN,
                                   connect_by_root DTIN_ID INPUT_ID,
                                   OPERATION_ID_IN
                              from (select case when DTO.DTO_DTOPT_ID = 30 and DTOUTT.DTOUTT_PRIMARY = 0 then 0 end OP_RES_TYPE_DYN_NO_OUT,
                                           DTIN.DTIN_ORDER INPUT_ORDER,
                                           DTO.DTO_ID OPERATION_ID,
                                           DTO_IN.DTO_ID OPERATION_ID_IN,
                                           DTIN.DTIN_DTOUT_ID OP_RESULT_ID_IN,
                                           DTOUT.DTOUT_ID OP_RESULT_ID_OUT,
                                           DTIN.DTIN_TREF_ID TREF_ID_IN,
                                           case when DTIN.DTIN_TREF_ID is not null then 1 when DTOUTT_IN.DTOUTT_ORDER !=1 and DTO_IN.DTO_DTOPT_ID != 90 then 1 else DTO_IN.DTO_RESULT_FIELDS_TYPE end DTO_RESULT_FIELDS_TYPE_IN,
                                           case when DTOUTT.DTOUTT_ORDER != 1 then 1 else DTO.DTO_RESULT_FIELDS_TYPE end DTO_RESULT_FIELDS_TYPE_OUT,
                                           DTIN.DTIN_ID DTIN_ID,
                                           DTOUTT.DTOUTT_PRIMARY DTOUTT_PRIMARY,
                                           DTO_IN.DTO_DTOPT_ID OPERATION_TYPE_IN
                                      from DT_OPERATIONS DTO
                                      left join DT_OUTPUTS DTOUT on DTOUT.DTOUT_DTO_ID = DTO.DTO_ID
                                      left join DT_OUTPUT_TYPES DTOUTT on DTOUTT.DTOUTT_DTOPT_ID = DTO.DTO_DTOPT_ID and DTOUTT.DTOUTT_ID = DTOUT.DTOUT_DTOUTT_ID
                                      left join (select DTIN_ID,
                                                        DTIN_DTO_ID,
                                                        DTIN_TREF_ID,
                                                        DTIN_ORDER,
                                                        DTIN_DTOUT_ID
                                                   from DT_INPUTS
                                                   join DT_OPERATIONS on DTIN_DTO_ID = DTO_ID and DTO_DTOPT_ID != 90
                                                  union all
                                                 select DTDR_ID DTIN_ID,
                                                        DTDR_ID DTIN_DTO_ID,
                                                        DTDR_TABLE_TREF_ID DTIN_TREF_ID,
                                                        0 DTIN_ORDER,
                                                        null DTIN_DTOUT_ID
                                                   from DT_DELETE_RECORDS
                                                 ) DTIN on DTIN.DTIN_DTO_ID = DTO.DTO_ID
                                       left join DT_OUTPUTS DTOUT_IN on DTIN.DTIN_DTOUT_ID = DTOUT_IN.DTOUT_ID
                                       left join DT_OPERATIONS DTO_IN on DTO_IN.DTO_ID = DTOUT_IN.DTOUT_DTO_ID
                                       left join DT_OUTPUT_TYPES DTOUTT_IN on DTOUTT_IN.DTOUTT_DTOPT_ID = DTO_IN.DTO_DTOPT_ID and DTOUTT_IN.DTOUTT_ID = DTOUT_IN.DTOUT_DTOUTT_ID
                                    ) OP_INP
                             start with OPERATION_ID = c.DTO_ID and nvl(DTOUTT_PRIMARY, 1) = 1
                           connect by prior OP_RESULT_ID_IN = OP_RESULT_ID_OUT and coalesce(OP_RES_TYPE_DYN_NO_OUT, INPUT_ORDER, 0) = nvl(INPUT_ORDER, 0) and DTO_RESULT_FIELDS_TYPE_OUT != 2
                             order siblings by INPUT_ORDER
                           )
                    ) INP
              left join TABLE_REFERENCES TR on TR.TREF_ID = INP.TREF_ID_IN
              left join (select OBR.OR_ID,
                                OBR.OR_NAME,
                                CR.CR_PARENT_DEFINITION_ID
                           from OBJECT_REGISTRATION OBR
                           join CATEGORY_RELATIONSHIPS CR on CR.CR_DEFINITION_ID = OBR.OR_ID
                         ) OBRC on OBRC.OR_NAME = TR.TREF_DEFINITION_NAME and OBRC.CR_PARENT_DEFINITION_ID = TR.TREF_PARENT_DEFINITION_ID
              left join TABLES T on nvl(T.TABLES_DEFINITION_ID, T.TABLES_ID) = nvl(TR.TREF_DEFINITION_ID, OBRC.OR_ID)
              left join TABLE_COLUMNS TC on TC.TC_TABLES_ID = T.TABLES_ID and TC_COLUMN_TYPE != 3
              left join DT_OP_RESULT_FIELDS DTORF on DTORF.DTORF_DTO_ID = INP.OPERATION_ID_IN and (INP.DTO_RESULT_FIELDS_TYPE_IN = 2 or INP.OPERATION_TYPE_IN in (10,20,70,60))
              left join FIELDS on nvl(TC_FLD_ID, DTORF_FLD_ID) = FLD_ID
             where (FLD_DATA_TYPE is null or FLD_DATA_TYPE not in (9,10))
               and (coalesce(TC_FLD_ID, DTORF_FLD_ID, TC_ENTITY_ID, DTORF_ENTITY_ID) is not null or DTO_RESULT_FIELDS_TYPE_IN is null)
               and t.TABLES_ID = pi_table_id
            ) INPUTS
      join (select DTIN_ID, DM_REFFERED_OBJECT_ID FLD_ID
              from DT_OPERATIONS
              join DT_INPUTS on DTO_ID = DTIN_DTO_ID
              join OBJECT_DEFINITIONS on DTIN_FILTER_ID = OD_ID
              join DEPENDENCY_METADATA on 'FILTER_IN_USE_DATA_' || OD_ID = DM_SUBGROUP_KEY and DTO_ID = DM_REFFERING_OBJECT_ID
             where DTO_ID = c.DTO_ID
             union
            select DTDR_ID, DM_REFFERED_OBJECT_ID FLD_ID
              from DT_OPERATIONS
              join DT_DELETE_RECORDS on DTO_ID = DTDR_ID
              join OBJECT_DEFINITIONS on DTDR_TABLE_FILTER_ID = OD_ID
              join DEPENDENCY_METADATA on 'FILTER_IN_USE_DATA_' || OD_ID = DM_SUBGROUP_KEY and DTO_ID = DM_REFFERING_OBJECT_ID
             where DTO_ID = c.DTO_ID
             union
            select DTIN_ID, coalesce(DTMFC_FLD_ID, DTMFC_ENTITY_ID) FLD_ID
              from DT_OPERATIONS
              join DT_INPUTS on DTO_ID = DTIN_DTO_ID
              join DT_MERGE_FIELDS on DTO_ID = DTMF_ID
              join DT_MF_OPTIONS on DTMFO_DTMF_ID = DTMF_ID
              join DT_MF_CONDITIONS on DTMFC_DTMFO_ID = DTMFO_ID and DTIN_ID = DTMFC_PRIOR_DTIN_ID
             where DTO_ID = c.DTO_ID
            union
            select DTIN_ID, coalesce(DTMFCI_FLD_ID, DTMFCI_ENTITY_ID) FLD_ID
              from DT_OPERATIONS
              join DT_INPUTS on DTO_ID = DTIN_DTO_ID
              join DT_MERGE_FIELDS on DTO_ID = DTMF_ID
              join DT_MF_OPTIONS on DTMFO_DTMF_ID = DTMF_ID and DTIN_ID = DTMFO_DTIN_ID
              join DT_MF_CONDITIONS on DTMFC_DTMFO_ID = DTMFO_ID
              join DT_MF_CONDITION_INPUTS on DTMFCI_DTMFC_ID = DTMFC_ID
             where DTO_ID = c.DTO_ID
             union
            select ID1 DTIN_ID, ID2 FLD_ID from table(get_mf_fields_in_adv_exp(c.DTO_ID))
             union
            select DTDR_ID, coalesce(DTDRC_TABLE_FLD_ID, DTDRC_TABLE_ENTITY_ID) FLD_ID
              from DT_OPERATIONS
              join DT_DELETE_RECORDS on DTO_ID = DTDR_ID
              join DT_DR_CONDITIONS on DTDRC_DTDR_ID = DTDR_ID
             where DTO_ID = c.DTO_ID
             union
            select DTDR_ID, coalesce(DTDRCI_INPUT_FLD_ID, DTDRCI_INPUT_ENTITY_ID) FLD_ID
              from DT_OPERATIONS
              join DT_DELETE_RECORDS on DTO_ID = DTDR_ID
              join DT_DR_CONDITIONS on DTDRC_DTDR_ID = DTDR_ID
              join DT_DR_CONDITION_INPUTS on DTDRCI_DTDRC_ID = DTDRC_ID
             where DTO_ID = c.DTO_ID
            ) FILTERS_JOINS
        on INPUTS.INPUT_ID = FILTERS_JOINS.DTIN_ID
       and INPUTS.FLD_ID = FILTERS_JOINS.FLD_ID;
  end loop;
  select distinct TC_PHYSICAL_NAME
    bulk collect into po_fields_in_use
    from FIELDS_IN_DT_FILTERS_JOINS;
end get_fields_in_use;

PROCEDURE get_required_fields(pi_def_id         IN NUMBER,
                              pi_table_type     IN VARCHAR2,
                              pi_run_id         IN NUMBER,
                              pi_property_value IN VARCHAR2,
                              pi_msg_flag       IN NUMBER,
                              pi_process_id  IN tabletype_number DEFAULT NULL,
                              po_flag           OUT NUMBER) IS
  v_sql               CLOB;
  v_sql_unpivot       CLOB;
  v_coltype_key_value coltype_key_value := coltype_key_value();
  v_table_name        VARCHAR2(30 CHAR);
  v_tables_id         NUMBER;
  v_tab_business_name VARCHAR2(100 CHAR);
  v_flag              NUMBER := 0;
  v_log_details       coltype_log_details := coltype_log_details();
  v_lm_message        clob;
  v_record_count      NUMBER;
  v_tab_count number;
  v_pr_value varchar2(1300 char);
  v_fields_in_use TABLETYPE_CHARMAX;
  v_column_name  TABLETYPE_CHARMAX;
  v_flds_clob clob;
BEGIN
  IF pi_table_type = 'DATA_TABLE' THEN
    SELECT tab.dt_name, t.tables_id, t.tables_physical_name
      INTO v_tab_business_name, v_tables_id, v_table_name
      FROM data_tables tab
     INNER JOIN tables t
        ON tab.dt_tables_id = t.tables_id
     WHERE dt_id = pi_def_id;

  ELSIF pi_table_type = 'ENTITY_TABLE' THEN
    SELECT tab.entity_name, t.tables_id, t.tables_physical_name
      INTO v_tab_business_name, v_tables_id, v_table_name
      FROM entities tab
     INNER JOIN tables t
        ON tab.entity_tables_id = t.tables_id
     WHERE entity_id = pi_def_id;

  ELSIF pi_table_type = 'ASSIGNMENT_TABLE' THEN
    SELECT tab.ea_name, t.tables_id, t.tables_physical_name
      INTO v_tab_business_name, v_tables_id, v_table_name
      FROM entity_assignments tab
     INNER JOIN tables t
        ON tab.ea_tables_id = t.tables_id
     WHERE ea_id = pi_def_id;
  END IF;

  v_sql         := ' select OBJTYPE_KEY_VALUE (column_name,number_of_nulls) from (select ';
  v_sql_unpivot := ' unpivot (number_of_nulls FOR column_name IN ( ';

  select max(pr_value) into v_pr_value from properties where pr_name = 'Required_Fields_Table_Count_Limit';

  execute immediate 'select count(*) from '||v_table_name || ' where rownum <= ' || v_pr_value || ' + 1' into v_tab_count;

  if v_tab_count <= v_pr_value
    then
      po_flag := 0;
      return;
  else
    if (pi_process_id.count > 0) then
     get_fields_in_use(pi_table_id      => v_tables_id,
                       pi_process_id    => pi_process_id,
                       po_fields_in_use => v_fields_in_use);
      if v_fields_in_use.count = 0
        then
          po_flag := 0;
          return;
       else
         for i in 1..v_fields_in_use.count loop
             v_flds_clob  := v_flds_clob || '''' || v_fields_in_use(i) ||''',';

         end loop;
		 v_flds_clob := rtrim(v_flds_clob,',');
      end if;
    end if;
  end if;

execute immediate 'SELECT column_name
              FROM user_tab_columns
             WHERE table_name = '''|| v_table_name || ''' '||
              case when pi_process_id.count > 0 then
             ' and column_name in (' ||v_flds_clob||')'
             else ' ' end
               bulk collect into v_column_name;

  FOR i IN 1 .. v_column_name.count LOOP
    v_sql         := v_sql || ' count(case when ' || v_column_name(i) || ' is null then 1 end) as ' || v_column_name(i) || ',';
    v_sql_unpivot := v_sql_unpivot || v_column_name(i) || ' AS  ''' || v_column_name(i) || ''',';
  END LOOP;

  SELECT rtrim(v_sql, ',') || ' from '||v_table_name||') ' || rtrim(v_sql_unpivot, ',') || '))pivot_handle where pivot_handle.number_of_nulls = 0'
    INTO v_sql FROM dual;

  --dbms_output.put_line(v_sql);

  EXECUTE IMMEDIATE v_sql BULK COLLECT INTO v_coltype_key_value;

  IF pi_msg_flag = 1 THEN
    IF (v_coltype_key_value.count) > 0 THEN
        get_record_count(pi_def_id         => pi_def_id,
                       pi_run_id           => NULL,
                       pi_property_value   => NULL,
                       pi_table_type       => pi_table_type,
                       pi_msg_flag         => 0,
                       po_record_count     => v_record_count,
                       po_flag             => v_flag);

      v_log_details.extend(2);

      if v_record_count > 0 then

        FOR j IN (SELECT nvl(fld_business_name, entity_name) business_name, tc_column_type
                    FROM table_columns tc
                   INNER JOIN TABLE(v_coltype_key_value) key_value
                      ON tc.tc_physical_name = key_value.v_key
                    LEFT OUTER JOIN fields f
                      ON tc.tc_physical_name = f.fld_column_name
                    LEFT OUTER JOIN entities e
                      ON tc.tc_entity_id = e.entity_id
                   WHERE tc_tables_id = v_tables_id
                     AND tc_column_type IN (1, 2, 5)
                    and tc_is_required = 0
                    and tc_logic_type in (1,2,5)) -- selecting entity and field columns only;
         LOOP

        v_lm_message := case j.tc_column_type when  2 then 'Field '
                                              when  1 then 'Entity ' end || '"' || j.business_name ||
              '" has non-empty values in all ' ||  v_record_count ||  ' records. Please review if it can be marked as required.';

          v_log_details(1) := rtype_log_details('Table "' || v_tab_business_name || '" has ' || v_record_count || ' records and '
                        || case j.tc_column_type when  2 then 'field "'
                                              when  1 then 'entity "' end  || j.business_name ||
                                                '" has non-empty values in all the records.', 1);

          v_log_details(2) := rtype_log_details('Please review if it can be marked as required in the table definition. Marking a field / entity as required has substantial advantages in all the data processing that uses that table.',
          2);

            logging(pi_run_id      => pi_run_id,
                    pi_lm_message  => v_lm_message,
                    pi_log_details => v_log_details);

           v_flag := 1;
          END LOOP;
      end if;
    END IF;
  END IF;
  po_flag := v_flag;
END get_required_fields;
procedure get_cardinality(pi_def_type_id IN NUMBER,
                         pi_def_id      IN NUMBER,
                         pi_run_id      IN NUMBER,
                         pi_table_type  IN VARCHAR2,
                         po_flag        OUT NUMBER) is

  v_log_details    coltype_log_details := coltype_log_details();
  v_lm_message     CLOB;
  --v_key_fields_msg CLOB;
  --v_dt_name        VARCHAR2(30 CHAR) ;
  v_count          NUMBER := 1;

BEGIN

  FOR i IN (SELECT *
              FROM (SELECT listagg(tc_order, ',') within GROUP(ORDER BY cardinality DESC) tc_order,
                           listagg(expected_order, ',') within GROUP(ORDER BY cardinality DESC) expected_order
                      FROM (SELECT x.*,
                                   rank() over(ORDER BY cardinality DESC, rownum) expected_order
                              FROM (SELECT nvl(fld_business_name, entity_name) business_name,
                                           utc.num_distinct / decode(ut.num_rows, null, 1, 0, 1, ut.num_rows) cardinality,
                                           tc.tc_order
                                      FROM user_tables ut INNER JOIN tables t ON t.tables_physical_name = ut.table_name
                                     INNER JOIN data_tables dt ON dt.dt_tables_id = t.tables_id
                                     INNER JOIN table_columns tc ON t.tables_id = tc.tc_tables_id
                                     INNER JOIN user_tab_columns utc ON (tc.tc_physical_name = utc.column_name AND t.tables_physical_name = utc.table_name)
                                      LEFT OUTER JOIN fields f ON tc.tc_physical_name = f.fld_column_name
                                      LEFT OUTER JOIN entities e ON tc.tc_entity_id = e.entity_id
                                     WHERE dt.dt_id = pi_def_id AND tc.tc_logic_type in (1, 5)) x
                             ORDER BY expected_order) x) y
             WHERE tc_order <> expected_order) LOOP

    FOR j IN (SELECT x.*,
                     rank() over(ORDER BY cardinality DESC, rownum) expected_order
                FROM (SELECT nvl(fld_business_name, entity_name) business_name,
                             utc.num_distinct / decode(ut.num_rows, null, 1, 0, 1, ut.num_rows) cardinality,
                             tc.tc_order
                        FROM user_tables ut
                       INNER JOIN tables t ON t.tables_physical_name = ut.table_name
                       INNER JOIN data_tables dt ON dt.dt_tables_id = t.tables_id
                       INNER JOIN table_columns tc ON t.tables_id = tc.tc_tables_id
                       INNER JOIN user_tab_columns utc ON (tc.tc_physical_name = utc.column_name AND t.tables_physical_name = utc.table_name)
                        LEFT OUTER JOIN fields f ON tc.tc_physical_name = f.fld_column_name
                        LEFT OUTER JOIN entities e ON tc.tc_entity_id = e.entity_id
                       WHERE  dt.dt_id = pi_def_id AND tc.tc_logic_type in (1, 5)) x
              ORDER BY expected_order) LOOP
      if v_count = 1 then
        v_log_details.extend(3);
      else
       v_log_details.extend(1);
      end if;

      v_log_details(v_count+2) := rtype_log_details(v_count||'. '||j.business_name,v_count+2);
     -- v_key_fields_msg := v_key_fields_msg || v_count || '. ' || j.business_name;
      v_count          := v_count + 1;
    END LOOP;
    po_flag      := 1;
    v_lm_message := 'Order of key fields should be from highest to lowest cardinality (extent of uniqueness).';

    v_log_details(1) := rtype_log_details('This data table has ' || (v_count -1) ||
                                          ' key fields. Ideally, fields having more unique values should be before fields having less unique values in the set of key fields.',
                                          1);
    v_log_details(2) := rtype_log_details('So, based on current data, the recommended order of key fields is: ',2);

        logging(pi_run_id      => pi_run_id,
                pi_lm_message  => v_lm_message,
                pi_log_details => v_log_details);
  END LOOP;
END get_cardinality;


PROCEDURE check_mf_like_operations(pi_def_id           IN  NUMBER,
                                   pi_run_id           IN  NUMBER,
                                   pi_msg_flag         IN  NUMBER,
                                   pi_operator_id      IN  NUMBER,
                                   po_flag             OUT NUMBER)
IS
  type string_array is table of varchar2(1000) index by varchar2(1000);
  v_log_details     coltype_log_details := coltype_log_details();
  v_flag            number := 0;
  v_lm_message      clob;
  v_left_field      varchar2(30);
  v_right_field     varchar2(30);
  v_left_input      varchar2(30);
  v_right_input     varchar2(30);
  v_expression      varchar2(4000);
  v_msg_details     clob;
  v_operation       varchar2(30);
  v_order           number := 1;
  v_operator        varchar2(30);
  v_left_field_id   number(10);
  v_right_field_id  number(10);
  v_left_input_id   number(10);
  v_right_input_id  number(10);
  v_left_text       varchar2(100);
  v_right_text      varchar2(100);
  v_i               number := 1;
  v_has_prior       number(1);
  v_input_order     number;
  v_operations      string_array;
  v_messages        string_array;
  v_message         varchar2(1000);
BEGIN
  if pi_operator_id = 7
  then
    v_operator := 'LIKE';
  else
    v_operator := 'NOT LIKE';
  end if;

  v_lm_message  := v_operator || ' operator in match conditions tends to perform slowly. Please review if it can be replaced with equality.';

  for c in (select  c.dtmfc_fld_id    as left_field_id,
                    ci.dtmfci_fld_id  as right_field_id,
                    il.dtin_id        as left_input,
                    ir.dtin_id        as right_input,
                    o.dto_name        as operation
                    ,il.dtin_dtout_id as left_prior
                    ,il.dtin_order    as left_order
                    ,ir.dtin_dtout_id as right_prior
                    ,ir.dtin_order    as right_order
            from dt_processes p inner join dt_operations o on p.dtp_id = o.dto_dtp_id
            inner join dt_merge_fields m on o.dto_id = m.dtmf_id
            inner join dt_mf_options mo on m.dtmf_id = mo.dtmfo_dtmf_id
            inner join dt_mf_conditions c on mo.dtmfo_id = c.dtmfc_dtmfo_id
            inner join dt_mf_condition_inputs ci on c.dtmfc_id = ci.dtmfci_dtmfc_id
            inner join dt_inputs il on c.dtmfc_prior_dtin_id = il.dtin_id
            inner join dt_inputs ir on o.dto_id = ir.dtin_dto_id
            where p.dtp_id = pi_def_id and ir.dtin_order = 1 and c.dtmfc_operator = pi_operator_id
            order by operation
         )
    loop
      select count(dtin_dtout_id) into v_has_prior
      from dt_inputs
      where dtin_id = c.left_input;

      if c.left_prior is null
      then
        select o.or_name into v_left_input
        from dt_inputs i inner join table_references tr on i.dtin_tref_id = tr.tref_id
             inner join object_registration o on o.or_id = tr.tref_definition_id
             where i.dtin_id = c.left_input;
      else
          case
          when c.left_order is null then
            v_left_input := 'Priorinput.' || 'Deletedinput';
          when c.left_order = 0 then
            v_left_input := 'Priorinput.' || 'Initialinput';
          else
            v_left_input := 'Priorinput.' || 'Mergedinput' || to_char(c.left_order);
        end case;
      end if;

      select count(dtin_dtout_id) into v_has_prior
      from dt_inputs
      where dtin_id = c.right_input;

      if c.right_prior is null
      then
        select o.or_name into v_right_input
        from dt_inputs i inner join table_references tr on i.dtin_tref_id = tr.tref_id
             inner join object_registration o on o.or_id = tr.tref_definition_id
             where i.dtin_id = c.right_input;
      else
        case
        when c.right_order is null then
          v_right_input := 'Priorinput.' || 'Deletedinput';
        when c.right_order = 0 then
          v_right_input := 'Priorinput.' || 'Initialinput';
        else
          v_right_input := 'Priorinput.' || 'Mergedinput' || to_char(c.right_order);
        end case;
      end if;

      select fld_business_name into v_left_field from fields where fld_id = c.left_field_id;
      select fld_business_name into v_right_field from fields where fld_id = c.right_field_id;

      v_expression := c.operation || '#' || '''' || v_left_field  || '[' || v_left_input || ']'' IS ' || v_operator || ' ''' || v_right_field || '[' || v_right_input || ']''';

      v_operations(c.operation) := '';
      v_messages(v_expression) := c.operation;
  end loop;

    ---- Check MF expressions ----
  for c in (select regexp_substr(ex, '^\[(.*?)\]', 1) as left_input,
                   regexp_substr(ex, '\[([^]]+)\]$', 1) as right_input,
                   operation
            from (
                    select  distinct to_char(regexp_substr(od_definition, '\[([^]]+)\] ' || v_operator || ' \[([^]]+)\]', 1, level)) as ex,
                     o.dto_name as operation
                    from dt_processes p inner join dt_operations o on p.dtp_id = o.dto_dtp_id
                    inner join dt_merge_fields m on o.dto_id = m.dtmf_id
                    inner join dt_mf_options mo on m.dtmf_id = mo.dtmfo_dtmf_id
                    inner join object_definitions o on mo.dtmfo_adv_cond_id = o.od_id
                    where p.dtp_id = pi_def_id and od_definition like '%] ' || v_operator || ' [%'
                    connect by level <= regexp_count(od_definition, '\[([^]]+)\] ' || v_operator || ' \[([^]]+)\]')
                  )
            order by operation
            )
  loop
    if regexp_substr(c.left_input, '^\[[a-zA-Z]+[\.[0-9]+]*\]') is not null
    then
      v_left_input_id := to_number(regexp_substr(c.left_input, '\.([0-9]*)\.([0-9]*)\]$', 1, 1, null, 1));
      v_left_field_id := to_number(regexp_substr(c.left_input, '([0-9]*)\]$', 1, 1, null, 1));

      select count(dtin_dtout_id) into v_has_prior
      from dt_inputs
      where dtin_id = v_left_input_id;

      select dtin_order into v_input_order
      from dt_inputs
      where dtin_id = v_left_input_id;

      if v_has_prior = 0
      then
        select o.or_name into v_left_input
        from dt_inputs i inner join table_references tr on i.dtin_tref_id = tr.tref_id
             inner join object_registration o on o.or_id = tr.tref_definition_id
             where i.dtin_id = v_left_input_id;
      else
        case
          when v_input_order is null then
            v_left_input := 'Priorinput.' || 'Deletedinput';
          when v_input_order = 0 then
            v_left_input := 'Priorinput.' || 'Initialinput';
          else
            v_left_input := 'Priorinput.' || 'Mergedinput' || to_char(v_input_order);
        end case;

      end if; -- end has_prior;
      select fld_business_name into v_left_field from fields where fld_id = v_left_field_id;
      v_left_text := v_left_field  || '[' || v_left_input || ']';
    else
      v_left_text := c.left_input;
    end if; --- end regex;

    if regexp_substr(c.right_input, '^\[[a-zA-Z]+[\.[0-9]+]*\]') is not null
    then
      v_right_input_id := to_number(regexp_substr(c.right_input, '\.([0-9]*)\.([0-9]*)\]$', 1, 1, null, 1));
      v_right_field_id := to_number(regexp_substr(c.right_input, '([0-9]*)\]$', 1, 1, null, 1));

      select count(dtin_dtout_id)into v_has_prior
      from dt_inputs
      where dtin_id = v_right_input_id;

      select dtin_order into v_input_order
      from dt_inputs
      where dtin_id = v_right_input_id;

      if v_has_prior = 0
      then
        select o.or_name into v_right_input
        from dt_inputs i inner join table_references tr on i.dtin_tref_id = tr.tref_id
             inner join object_registration o on o.or_id = tr.tref_definition_id
             where i.dtin_id = v_right_input_id;
      else
        case
          when v_input_order is null then
            v_right_input := 'Priorinput.' || 'Deletedinput';
          when v_input_order = 0 then
            v_right_input := 'Priorinput.' || 'Initialinput';
          else
            v_right_input := 'Priorinput.' || 'Mergedinput' || to_char(v_input_order);
        end case;

      end if; -- end has_prior;
      select fld_business_name into v_right_field from fields where fld_id = v_right_field_id;
      v_right_text := v_right_field  || '[' || v_right_input || ']';
    else
      v_right_text := c.right_input;
    end if;

    v_expression := c.operation || '#' || '''' || v_left_text || ''' IS ' || v_operator || ' ''' || v_right_text || '''';
    v_operations(c.operation) := '';
    v_messages(v_expression) := c.operation;
    v_flag := 1;
  end loop;

  v_operation := v_operations.first;

  while v_operation is not null
  loop
    v_msg_details := 'Following match conditions in this ''' || v_operation || ''' merge fields operation use  ' || lower(v_operator) || ' operator. ' ||
                      v_operator || ' operator in match conditions tends to perform slowly. Please review if it can be replaced with equality.';

    v_log_details.extend(1);
    v_log_details(v_order) := rtype_log_details(v_msg_details, v_order);
    v_order := v_order + 1;
    v_message := v_messages.first;
    v_i := 1;

    while v_message is not null
    loop
      if v_messages(v_message) = v_operation
      then
        v_msg_details := v_i || '. ' || v_operator || ' operator match condition ' || to_char(v_i) || ': ' || replace(v_message, v_operation || '#', '');
        v_log_details.extend(1);
        v_log_details(v_order) := rtype_log_details(v_msg_details, v_order);
        v_order := v_order + 1;
        v_i := v_i + 1;
      end if;

      v_message := v_messages.next(v_message);
    end loop;

    v_operation := v_operations.next(v_operation);
  end loop;

  if v_flag = 1 and pi_msg_flag = 1
  then
    logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
  end if;
  po_flag := v_flag;

END check_mf_like_operations;


PROCEDURE get_like_operator(pi_def_id           IN  NUMBER,
                            pi_run_id           IN  NUMBER,
                            pi_msg_flag         IN  NUMBER,
                            po_flag             OUT NUMBER)
IS
BEGIN
  check_mf_like_operations(pi_def_id, pi_run_id, pi_msg_flag, 7, po_flag);
END get_like_operator;


PROCEDURE get_not_like_operator(pi_def_id           IN  NUMBER,
                                pi_run_id           IN  NUMBER,
                                pi_msg_flag         IN  NUMBER,
                                po_flag             OUT NUMBER)
IS
BEGIN
  check_mf_like_operations(pi_def_id, pi_run_id, pi_msg_flag, 8, po_flag);
END get_not_like_operator;

PROCEDURE get_dto_logs(pi_def_id           IN  NUMBER,
                            pi_process_type     IN  VARCHAR2,
                            pi_run_id           IN  NUMBER,
                            pi_property_value   IN  VARCHAR2,
                            pi_msg_flag         IN  NUMBER,
                            po_flag             OUT NUMBER)
IS
    v_flag            number := 0;
    v_log_details     coltype_log_details := coltype_log_details();
    v_lm_message      clob;
    v_msg_details     clob;
    v_order           number := 0;
    v_stamp varchar2(250 char):= 'performance_analyzer.get_dto_logs - output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    v_flag_adto          NUMBER(1) := 0;
    no_res      NUMBER(10) := 0;
    no_proceses NUMBER(10) := 0;
    no_ui       NUMBER(10) := 0;
    inner_string     CLOB;
    lock_message     CLOB;
    dto_name         VARCHAR(127 CHAR);
    resource_message CLOB;
    i                NUMBER(10) := 0;
    no_locks         number(10) := 0;
    rd_log_id        VARCHAR2(1300 CHAR);
    log_start_date   timestamp(6);
    time_waited      CLOB;
    timeout_exp      NUMBER(1) := 0; --0 for no, 1 for yes -- for just a resource
    time_spent       NUMBER(10) := 0; --time spent by the operation
    reference_time   NUMBER(5)  := 10; --10 seconds as the reference time fow waiting
    ref_count        NUMBER(2)  :=0; --how many times the lock was under the reference time
    no_hours         NUMBER(10);
    no_minutes       NUMBER(10);
    no_seconds       NUMBER(10);
    str_time         CLOB;
BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_def_id) ,     ',pi_def_id => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_process_type) ,     ',pi_process_type => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id) ,     ',pi_run_id => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_property_value) ,     ',pi_property_value => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_msg_flag) ,     ',pi_msg_flag => <value>' , v_stamp);

    --getting all the DTOs from the current DT;
    FOR dto IN (
      Select * from dt_operations where dto_dtp_id = pi_def_id
      )
    LOOP
        v_flag := 0;
        ref_count := 0;
        v_log_details.Delete;
        v_order := 0;
        v_lm_message  := 'Operation '|| dto.dto_name ||' had to wait for shared resource(s) during some of its recent runs.';
        v_order := v_order + 1;
        v_log_details.extend(1);
        v_log_details(v_order) := rtype_log_details(dbms_lob.substr('This happened in some of the recent runs for this process (given below). Please review the schedules of this process to make sure it''s not conflicting with some other process.',4000,1), v_order);
        v_order := v_order + 1;
        v_log_details.extend(1);
        v_log_details(v_order) := rtype_log_details(CHR(13),v_order);

        --getting all the messages for the current DTO
        FOR res IN (Select *
            from (Select RD_ID, count(LM_ID) as COUNTRES
                    from logs_messages
                   INNER JOIN run_data
                      ON lm_rd_id = rd_id
                   where rd_definition_id =dto.dto_id
                   group by RD_ID
                   order by RD_ID desc)
            Where ROWNUM < 6)
        LOOP
            i:= i + 1;
            timeout_exp := 0;
            --v_flag := 0;
            lock_message := ''; --'Run' || i || ': ';
            resource_message := '';
            inner_string     := '';

            --check if there are any locks in the logs of the current run
            select count(LM_ID) into no_locks FROM logs_messages WHERE LM_RD_ID = res.RD_ID AND LM_MESSAGE like 'Process is waiting to lock%';

            --if there are lock with waiting we will write the header
            IF no_locks > 0 THEN
                SELECT RD_LOG_ID INTO rd_log_id FROM RUN_DATA where RD_ID = res.RD_ID;
                SELECT LM_START_DATE INTO log_start_date FROM
                       (Select * FROM (SELECT LM_START_DATE FROM logs_messages WHERE LM_RD_ID = res.RD_ID order by LM_ID)
                       WHERE ROWNUM < 2);
               -- lock_message := lock_message || ' Start ' || TO_CHAR(log_start_date, 'YYYY-MM-DD HH24:MI:SS') || ' (Log ID: ' || rd_log_id || ') - The process waited to lock ';
               lock_message := lock_message || ' Log ID: ' || rd_log_id || ' - The process waited to lock ';

                --different message depending on the number of resources
                IF no_locks = 1 THEN
                   lock_message := lock_message || 'resource ';
                ELSE
                   lock_message := lock_message || 'the following resources: ' || CHR(10);
                END IF;
                --if there aren't any locks
            ELSE
                 lock_message := lock_message || 'No lock!';
            END IF;
            no_res := no_locks;

            --here I go through all the logs for resources locked by the same process
            --getting every log_message for the specific run_data and parse it
            --if the query doesn't return any row then this loop doesn't execute
            FOR r IN (select LM_update_date, LM_ID, LM_message, LM_START_DATE
                  from logs_messages WHERE LM_RD_ID = res.RD_ID
                  AND LM_MESSAGE like 'Process is waiting to lock%')
            LOOP
                no_hours := 0;
                no_minutes := 0;
                no_seconds := 0;

                --OBTAINING THE TIME INTERVAL
                --here we check if there was a timeout or how long it took to complete de operation
                IF (INSTR(r.LM_MESSAGE,'lock was acquired successfully') > 0 ) THEN
                    time_waited  := SUBSTR (r.LM_MESSAGE, INSTR(r.LM_MESSAGE,
                                    'successfully after waiting for') + 31,
                                    INSTR(r.LM_MESSAGE, 'The timeout is of') - INSTR(r.LM_MESSAGE, 'successfully after waiting for') - 33 );
                    str_time := TRIM(SUBSTR(r.LM_MESSAGE,   --string
                                     INSTR(r.LM_MESSAGE,'successfully after waiting' ) +31,  --start
                                     INSTR(r.LM_MESSAGE,'.', INSTR(r.LM_MESSAGE,'successfully after waiting' ) )-  INSTR(r.LM_MESSAGE,'successfully after waiting' ) -31));
                	  --hours
                    IF ( INSTR(str_time,'hour') > 0  )THEN
                        no_hours := to_number(trim(substr(str_time,0,INSTR(str_time,'hour')-1)));
                    ELSE
                        no_hours :=0;
                    END IF;
                    --minutes
                    IF ( INSTR(str_time,'minute') > 0  )THEN
                        no_minutes := to_number(trim( SUBSTR(str_time, instr(str_time,' ', (-1)*(LENGTH(str_time) - INSTR(str_time,'minute')), 2),  instr(str_time,' ', (-1)*(LENGTH(str_time) - INSTR(str_time,'minute')), 1)-  instr(str_time,' ', (-1)*(LENGTH(str_time) - INSTR(str_time,'minute')), 2) )));
                    ELSE
                        no_minutes :=0;
                    END IF;
                    --seconds
                    IF ( INSTR(str_time,'second') > 0  )THEN
                        no_seconds := to_number(trim( SUBSTR(str_time, instr(str_time,' ', (-1)*(LENGTH(str_time) - INSTR(str_time,'second')), 2),  instr(str_time,' ', (-1)*(LENGTH(str_time) - INSTR(str_time,'second')), 1)-  instr(str_time,' ', (-1)*(LENGTH(str_time) - INSTR(str_time,'second')), 2) )));
                    ELSE
                        no_seconds :=0;
                    END IF;

                    time_spent := 3600 *  no_hours + 60*  no_minutes +  no_seconds;

                    IF (time_spent <= reference_time) and (time_spent > 0) THEN
                      ref_count := ref_count + 1;
                    END IF;


                    IF (time_spent > reference_time) THEN
                        timeout_exp  := 1;
                    END IF;
                    IF (ref_count > 1 ) THEN
                        timeout_exp  := 1;
                    END IF;

                ELSE
                    time_waited  := SUBSTR (r.LM_MESSAGE, INSTR(r.LM_MESSAGE,
                                 'Failed to acquire the lock because the timeout of') + 50,
                                 INSTR(r.LM_MESSAGE, 'has expired') - INSTR(r.LM_MESSAGE, 'Failed to acquire the lock because the timeout of') - 52 );
                    timeout_exp  := 1;
                    time_spent := 3600;
                END IF;

                --BUILDING THE MESSAGE LOG
                --if more than one resouce is locked and this means that we have more than one log_message entry, every resource has it's own log_message for lock
                IF no_res > 1 THEN
                    resource_message := resource_message || CHR(13) || CHR(9) ||
                    'Resource ''' ||
                    substr(r.LM_MESSAGE,
                       INSTR(r.LM_MESSAGE, 'resource (', 1) + 11,
                       INSTR(r.LM_MESSAGE,
                             '''',
                             INSTR(r.LM_MESSAGE, 'resource (', 1),
                             2) -
                       INSTR(r.LM_MESSAGE,
                             '''',
                             INSTR(r.LM_MESSAGE, 'resource (', 1),
                             1) - 1) || ''', - locked by';
                    --just one row of log for every lock
                ELSE
                    resource_message := resource_message || '''' ||
                    substr(r.LM_MESSAGE,
                       INSTR(r.LM_MESSAGE, 'resource (', 1) + 11,
                       INSTR(r.LM_MESSAGE,
                             '''',
                             INSTR(r.LM_MESSAGE, 'resource (', 1),
                             2) -
                       INSTR(r.LM_MESSAGE,
                             '''',
                             INSTR(r.LM_MESSAGE, 'resource (', 1),
                             1) - 1) || ''', locked by';
                END IF;

                --getting the number of locks, on a single resurce
                Select REGEXP_COUNT(r.LM_MESSAGE, '\(log ID: ') INTO no_proceses FROM DUAL;

                --checking the number of locks
                resource_message := resource_message ||  substr(r.LM_MESSAGE , INSTR( r.LM_MESSAGE, 'locked by') + 9, INSTR( r.LM_MESSAGE, '...',1) - INSTR( r.LM_MESSAGE, 'locked by')-8);

                --getting the number of ui operations
                Select REGEXP_COUNT(r.LM_MESSAGE, 'UI operation') INTO no_ui FROM DUAL;
                IF no_ui <> 0 THEN
                    Select REGEXP_COUNT(r.LM_MESSAGE, 'multiple UI operations') + 1
                    INTO no_ui
                    FROM DUAL;
                END IF;
            END LOOP;

            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(timeout_exp) ,     ',timeout_exp => <value>' , v_stamp);
            IF (timeout_exp = 1) THEN
                v_flag := 1;
                v_order := v_order + 1;
                v_log_details.extend(1);
                v_log_details(v_order) := rtype_log_details(dbms_lob.substr( lock_message || resource_message,4000,1), v_order);
                v_order := v_order + 1;
                v_log_details.extend(1);
                v_log_details(v_order) := rtype_log_details(CHR(13),v_order);
            END IF;
        END LOOP;

        if v_flag = 1 and pi_msg_flag = 1
        then
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_lm_message) ,     ',v_lm_message          => <value>' , v_stamp);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(v_log_details) ,     ',v_log_details          => <value>' , v_stamp);
            logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
            v_flag_adto := v_flag;
        end if;

    END LOOP;
po_flag := v_flag_adto;
END get_dto_logs;

PROCEDURE get_delete_records_input(pi_def_id           IN  NUMBER,
                                   pi_run_id           IN  NUMBER,
                                   pi_property_value   IN  NUMBER,
                                   pi_msg_flag         IN  NUMBER,
                                   po_flag             OUT NUMBER)
IS
  v_flag           number := 0;
  v_log_details    coltype_log_details := coltype_log_details();
  v_lm_message     clob;
  v_order          number := 0;
BEGIN
  v_lm_message := 'The Delete Records operation is slow when the operation is matched against a input table with many rows.
                   Please review if can be used an aggregate step before the delete operation to reduce the input size.';
  for c in (
            select o.dto_name as operation_name, ob.or_name as table_name, ut.num_rows
            from dt_delete_records d
                   inner join dt_operations o on d.dtdr_id = o.dto_id
                   inner join dt_processes p on o.dto_dtp_id = p.dtp_id
                   inner join dt_inputs i on o.dto_id = i.dtin_dto_id
                   inner join table_references r on i.dtin_tref_id = r.tref_id
                   inner join tables t on r.tref_definition_id = t.tables_definition_id
                   inner join object_registration ob on r.tref_definition_id = ob.or_id
                   inner join user_tables ut on t.tables_physical_name = ut.table_name
             where num_rows > pi_property_value and p.dtp_id = pi_def_id
             group by o.dto_name, ob.or_name, ut.num_rows
            )
  loop
    v_flag := 1;
    v_order := v_order + 1;
    v_log_details.extend(1);
    v_log_details(v_order) := rtype_log_details('The input table ' || '''' || c.table_name || '''' || ' from the ' || '''' || c.operation_name || '''' || ' delete operation has ' || c.num_rows || ' rows. Please review if can be used an aggregate step before the delete operation to reduce the input size.', v_order);
 end loop;

 if pi_msg_flag = 1 and v_flag = 1
 then
   logging(pi_run_id      => pi_run_id,
           pi_lm_message  => v_lm_message,
           pi_log_details => v_log_details);
 end if;
  po_flag := v_flag;
END get_delete_records_input;


PROCEDURE get_dt_unused_results(pi_def_id           IN  NUMBER,
                            pi_process_type     IN  VARCHAR2,
                            pi_run_id           IN  NUMBER,
                            pi_property_value   IN  VARCHAR2,
                            pi_msg_flag         IN  NUMBER,
                            po_flag             OUT NUMBER)
IS
  v_flag            number := 0;
  v_log_details     coltype_log_details := coltype_log_details();
  v_lm_message      clob;
  v_left_field      varchar2(30);
  v_right_field     varchar2(30);
  v_msg_details     clob;
  v_order           number := 1;
  v_i               number := 1;
BEGIN
  v_lm_message  := 'Some operation results are not being used.';
  v_msg_details := 'Following operation results are not being used. Please review whether you need them.';
  v_log_details.extend(1);
  v_log_details(v_order) := rtype_log_details(v_msg_details, v_order);

  for c in (select o1.dto_name,
                   case ot.dtoutt_name
                   when 'AR_PRIMARY_OUTPUT' then 'Aggregate Records - Primary Output'
                   when 'CF_PRIMARY_OUTPUT' then 'Calculate Fields - Primary Output'
                   when 'MF_PRIMARY_OUTPUT' then 'Merge Fields - Primary Output'
                   when 'MR_PRIMARY_OUTPUT' then 'Merge Records - Primary Output'
                   when 'MF_INITIAL_INPUT_UNMATCHED_RECORDS' then 'Merge Fields - Unmatched Records'
                   when 'MF_INITIAL_INPUT_MULTIPLE_MATCHES' then 'Merge Fields - Records with Multiple Matches'
                   when 'RR_PRIMARY_OUTPUT' then 'Rank Records - Primary Output'
                   when 'CRT_PRIMARY_OUTPUT' then 'Calculate Running Totals - Primary Output'
                   when 'RU_PRIMARY_OUTPUT' then 'Roll Up Using Hierarchy - Primary Output'
                   when 'RU_UNMATCHED_RECORDS' then 'Roll Up Using Hierarchy - Unmatched Records'
                   when 'RU_NO_ROLL_UP' then 'Roll Up Using Hierarchy - Records that do not Roll Up'
                   when 'DR_DELETED_RECORDS' then 'Delete Records - Primary Output'
                   end dtoutt_name
              from dt_operations o1
              join dt_processes p1 on o1.dto_dtp_id = p1.dtp_id
              join dt_outputs otp on o1.dto_id = otp.dtout_dto_id
              join dt_output_types ot on otp.dtout_dtoutt_id = ot.dtoutt_id
              left join dt_inputs inp on otp.dtout_id = inp.dtin_dtout_id
              left join dt_operations o2 on inp.dtin_dto_id = o2.dto_id
              left join dt_processes p2 on o2.dto_dtp_id = p2.dtp_id
             where p1.dtp_id = pi_def_id
                     and o1.dto_dtopt_id != 50
               and inp.dtin_id is null
             order by o1.dto_id)
  loop
    v_msg_details := v_i || '. ' || c.dto_name || ': ' || c.dtoutt_name;
    v_log_details.extend(1);
    v_order := v_order + 1;
    v_log_details(v_order) := rtype_log_details(v_msg_details, v_order);
    v_i := v_i + 1;
    v_flag := 1;
  end loop;

  if v_flag = 1 and pi_msg_flag = 1
  then
    logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
  end if;

  po_flag := v_flag;
END get_dt_unused_results;


PROCEDURE perf_analyser_data_table(pi_def_type_id IN NUMBER,
                                   pi_def_id      IN NUMBER,
                                   pi_run_id      IN NUMBER,
                                   pi_table_type  IN VARCHAR2,
                                   pi_process_id  IN tabletype_number DEFAULT NULL,
                                   po_flag        OUT NUMBER) IS
  v_flag_fields_count NUMBER := 0;
  v_flag_key_count    NUMBER := 0;
  v_flag_table_size   NUMBER := 0;
  v_flag_required     NUMBER := 0;
  v_cardinality       NUMBER := 0;
  v_table_size        NUMBER;
  v_record_count      NUMBER;
BEGIN

  FOR i IN (SELECT cvt_property_name, cvt_property_value
              FROM checks_table
              LEFT OUTER JOIN checks_values_table
                ON cvt_ct_id = ct_id
             WHERE ct_definition_type_id = pi_def_type_id
               AND cvt_enable_check = 1) LOOP
    -- check 1 key fields/entities count check
    IF upper(i.cvt_property_name) = upper('KEY_COUNT') THEN
      get_key_count(pi_def_id         => pi_def_id,
                    pi_table_type     => pi_table_type,
                    pi_msg_flag       => 1,
                    pi_property_value => i.cvt_property_value,
                    pi_run_id         => pi_run_id,
                    po_flag           => v_flag_key_count);
      -- check 2 total number of fields count check
    ELSIF upper(i.cvt_property_name) = upper('FIELDS_COUNT') THEN
      get_fields_count(pi_def_id         => pi_def_id,
                       pi_table_type     => pi_table_type,
                       pi_property_value => i.cvt_property_value,
                       pi_run_id         => pi_run_id,
                       pi_msg_flag       => 1,
                       po_flag           => v_flag_fields_count);
      -- check 3 table size check
    ELSIF upper(i.cvt_property_name) = upper('TABLE_SIZE') THEN
      get_table_size(pi_def_id         => pi_def_id,
                     pi_table_type     => pi_table_type,
                     pi_run_id         => pi_run_id,
                     pi_property_value => i.cvt_property_value,
                     pi_msg_flag       => 1,
                     po_record_count   => v_record_count,
                     po_table_size     => v_table_size,
                     po_flag           => v_flag_table_size);

      -- check 4 Required check, check for null values in each column of data table
      -- if there are columns which contains not null values, display the warning
      -- that these columns can be marked as required by table creater

    ELSIF upper(i.cvt_property_name) = upper('FIELD_REQUIRED') THEN
      get_required_fields(pi_def_id         => pi_def_id,
                          pi_table_type     => pi_table_type,
                          pi_run_id         => pi_run_id,
                          pi_property_value => i.cvt_property_value,
                          pi_msg_flag       => 1,
                          pi_process_id     => pi_process_id,
                          po_flag           => v_flag_required);

    ELSIF upper(i.cvt_property_name) = upper('TABLE_CARDINALITY') THEN
      get_cardinality(pi_def_type_id => pi_def_type_id,
                      pi_def_id      => pi_def_id,
                      pi_table_type  => pi_table_type,
                      pi_run_id      => pi_run_id,
                      po_flag        => v_cardinality);
    END IF;
  END LOOP;
  IF (v_flag_fields_count = 1 OR v_flag_key_count = 1 OR
     v_flag_table_size = 1 OR v_flag_required = 1 OR v_cardinality = 1) THEN
    po_flag := 1;
  ELSE
    po_flag := 0;
  END IF;
END;

PROCEDURE perf_analyser_entity_table(pi_def_type_id IN NUMBER,
                                     pi_def_id      IN NUMBER,
                                     pi_run_id      IN NUMBER,
                                     pi_table_type  IN VARCHAR2,
                                     pi_process_id  IN tabletype_number DEFAULT NULL,
                                     po_flag        OUT NUMBER) IS

  v_flag_required     NUMBER := 0;
  v_flag_record_count NUMBER := 0;
  v_record_count      NUMBER;

BEGIN

  -- check 1 Table Size Check
  FOR i IN (SELECT cvt_property_name, cvt_property_value
              FROM checks_table
              LEFT OUTER JOIN checks_values_table
                ON cvt_ct_id = ct_id
             WHERE ct_definition_type_id = pi_def_type_id
               AND cvt_enable_check = 1) LOOP

    IF upper(i.cvt_property_name) = 'RECORD_COUNT' THEN
      get_record_count(pi_def_id         => pi_def_id,
                       pi_run_id         => pi_run_id,
                       pi_property_value => i.cvt_property_value,
                       pi_table_type     => pi_table_type,
                       pi_msg_flag       => 1,
                       po_record_count   => v_record_count,
                       po_flag           => v_flag_record_count);

    ELSIF upper(i.cvt_property_name) = 'FIELD_REQUIRED' THEN
      get_required_fields(pi_def_id         => pi_def_id,
                          pi_table_type     => pi_table_type,
                          pi_run_id         => pi_run_id,
                          pi_property_value => i.cvt_property_value,
                          pi_msg_flag       => 1,
                          pi_process_id     => pi_process_id,
                          po_flag           => v_flag_required);

    END IF;
  END LOOP;
  IF (v_flag_record_count = 1 OR v_flag_required = 1) THEN
    po_flag := 1;
  ELSE
    po_flag := 0;
  END IF;
END;

PROCEDURE perf_analyser_assignment_table(pi_def_type_id IN NUMBER,
                                         pi_def_id      IN NUMBER,
                                         pi_run_id      IN NUMBER,
                                         pi_table_type  IN VARCHAR2,
                                         pi_process_id  IN tabletype_number DEFAULT NULL,
                                         po_flag        OUT NUMBER) IS
  v_flag           NUMBER := 0;
BEGIN

FOR i IN (SELECT cvt_property_name, cvt_property_value
              FROM checks_table
              LEFT OUTER JOIN checks_values_table
                ON cvt_ct_id = ct_id
             WHERE ct_definition_type_id = pi_def_type_id
               AND cvt_enable_check = 1) LOOP

    IF upper(i.cvt_property_name) = 'FIELD_REQUIRED' THEN
      get_required_fields(pi_def_id         => pi_def_id,
                          pi_table_type     => pi_table_type,
                          pi_run_id         => pi_run_id,
                          pi_property_value => i.cvt_property_value,
                          pi_msg_flag       => 1,
                          pi_process_id     => pi_process_id,
                          po_flag           => v_flag);
    END IF;
  END LOOP;
  po_flag := v_flag;
END;


PROCEDURE perf_analyser_data_transform(pi_def_type_id     IN  NUMBER,
                                       pi_def_id          IN  NUMBER,
                                       pi_run_id          IN  NUMBER,
                                       pi_process_type    IN  VARCHAR2,
                                       po_flag            OUT NUMBER
                                      )
IS
  v_flag          NUMBER := 0;
  v_flag_like     NUMBER := 0;
  v_flag_not_like NUMBER := 0;
  v_flag_unused   NUMBER := 0;
  v_flag_delete   NUMBER := 0;
  v_flag_log      NUMBER := 0;

BEGIN
  for i in (select cvt_property_name, cvt_property_value
            from checks_table left outer join checks_values_table on cvt_ct_id = ct_id
            where ct_definition_type_id = pi_def_type_id and cvt_enable_check = 1)
  loop
   if upper(i.cvt_property_name) = 'MERGE_FIELDS_LIKE_OPERATOR'
   then
    get_like_operator(pi_def_id           => pi_def_id,
                      pi_run_id           => pi_run_id,
                      pi_msg_flag         => 1,
                      po_flag             => v_flag_like);
   end if;

   if upper(i.cvt_property_name) = 'MERGE_FIELDS_NOT_LIKE_OPERATOR'
   then
    get_not_like_operator(pi_def_id       => pi_def_id,
                      pi_run_id           => pi_run_id,
                      pi_msg_flag         => 1,
                      po_flag             => v_flag_not_like);
   end if;

   if upper(i.cvt_property_name) = 'DATA_TRANSFORMATION_UNUSED_RESULTS'
   then
    get_dt_unused_results(pi_def_id           => pi_def_id,
                      pi_process_type     => pi_process_type,
                      pi_run_id           => pi_run_id,
                      pi_property_value   => i.cvt_property_value,
                      pi_msg_flag         => 1,
                      po_flag             => v_flag_unused);
   end if;

   if upper(i.cvt_property_name) = 'DELETE_RECORDS_MATCH_INPUT_COUNT'
   then
    get_delete_records_input(pi_def_id           => pi_def_id,
                             pi_run_id           => pi_run_id,
                             pi_property_value   => i.cvt_property_value,
                             pi_msg_flag         => 1,
                             po_flag             => v_flag_delete);
   end if;

  if upper(i.cvt_property_name) = 'DATA_TRANSFORMATION_OPERATION_LOGS'
   then
    get_dto_logs(pi_def_id           => pi_def_id,
                      pi_process_type     => pi_process_type,
                      pi_run_id           => pi_run_id,
                      pi_property_value   => i.cvt_property_value,
                      pi_msg_flag         => 1,
                      po_flag             => v_flag_log);
   end if;

  end loop;

  if v_flag_like = 1 or v_flag_not_like = 1 or v_flag_unused = 1 or v_flag_delete = 1 or v_flag_log = 1
  then
     po_flag := 1;
  else
    po_flag := 0;
  end if;
END perf_analyser_data_transform;


PROCEDURE perf_analyser_dummy(pi_def_type_id IN NUMBER,
                             pi_def_id      IN NUMBER,
                             pi_run_id      IN NUMBER,
                             pi_table_type  IN VARCHAR2,
                            po_flag        OUT NUMBER) IS
    v_count NUMBER := 0;
    v_log_details    coltype_log_details := coltype_log_details();
    v_lm_message     clob;
    v_type_name VARCHAR2(250 CHAR);
BEGIN
  -- if you get to this select you either don't have an entry for module identifier
  -- or (less likely) have one in checks_table and particular checks in checks_values_table that you don't have specific code written for them.
  SELECT count(1) INTO v_count from checks_table c inner join checks_values_table t ON c.ct_id= t.cvt_ct_id
  WHERE t.cvt_enable_check = 1 AND c.ct_definition_type_id = pi_def_type_id;
  SELECT def_type_name_singular INTO v_type_name FROM definition_types WHERE def_type_id = pi_def_type_id;

  --if executes if the object has entries but no matching procedure
  IF v_count > 0 THEN
     v_lm_message     := 'The object type '''|| v_type_name || ''' is currently under development in the performance analysis framework!';
     v_log_details.extend(1);
     v_log_details(1) := rtype_log_details('Consider adding a procedure for the type '''|| v_type_name ||''' to use the checks you added.',1);
     logging(pi_run_id      => pi_run_id,
            pi_lm_message  => v_lm_message,
            pi_log_details => v_log_details);
     po_flag := 1;
  --else executes it there are no entries
  ELSE
      v_lm_message     := 'The object type '''|| v_type_name ||''' is currently not supported by the performance analysis framework!';
      v_log_details.extend(1);
      v_log_details(1) := rtype_log_details('Consider adding support for the object type '''|| v_type_name ||'''  to the performance analysis framework.',1);
      logging(pi_run_id      => pi_run_id,
      pi_lm_message  => v_lm_message,
      pi_log_details => v_log_details,
      pi_level => 2);
      po_flag := 0;
  END IF;

END;




PROCEDURE perf_analyser_checks(pi_def_type_id IN NUMBER,
                               pi_def_id      IN NUMBER,
                               pi_run_id      IN NUMBER,
                               pi_process_id  IN tabletype_number DEFAULT NULL,
                               po_flag        OUT NUMBER) IS

  v_module_identifier VARCHAR2(30);
  v_module_count NUMBER := 0;
  v_dt_or_ids   tabletype_number := tabletype_number();
BEGIN

  declare
  v_stamp varchar2(250 char):= 'performance_analyzer.perf_analyser_checks - output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  begin
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_def_type_id) ,     ',pi_def_type_id => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_def_id) ,     ',pi_def_id => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_run_id) ,     ',pi_run_id => <value>' , v_stamp);
	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertCollection(pi_process_id) ,     ',pi_process_id => <value>' , v_stamp);

    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_def_type_id) ,     ',pi_def_type_id => <value>' , v_stamp);
  end;

  SELECT COUNT(1) INTO v_module_count FROM checks_table WHERE ct_definition_type_id = pi_def_type_id;

  IF v_module_count > 0 THEN

      SELECT ct_module_identifier
        INTO v_module_identifier
        FROM checks_table
       WHERE ct_definition_type_id = pi_def_type_id;

      -- commons_utils.INSERT_LOGS(to_char(pi_def_type_id));
      -- commons_utils.INSERT_LOGS(to_char(pi_def_id));
      -- commons_utils.INSERT_LOGS(to_char(pi_run_id));

/*  FOR i IN 1.. pi_process_id.count LOOP
     commons_utils.INSERT_LOGS(to_char(pi_process_id(i)));
  END LOOP;*/

  --commons_utils.INSERT_LOGS('life is hard');

/*  FOR i IN 1.. v_dt_or_ids.count  LOOP
    commons_utils.INSERT_LOGS(to_char(v_dt_or_ids(i)));
  END LOOP;*/

      SELECT or_id
        BULK COLLECT
        INTO v_dt_or_ids
        FROM object_registration
      WHERE or_type = 40
         AND or_id IN (SELECT column_value FROM TABLE(pi_process_id) t);

        IF v_module_identifier = 'DATA_TABLE' THEN
          -- integrity checks for data table
          perf_analyser_data_table(pi_def_type_id => pi_def_type_id,
                                   pi_def_id      => pi_def_id,
                                   pi_run_id      => pi_run_id,
                                   pi_table_type  => v_module_identifier,
                                   pi_process_id  => v_dt_or_ids,
                                   po_flag        => po_flag);

        ELSIF v_module_identifier = 'ENTITY_TABLE' THEN
          -- integrity checks for entity table
          perf_analyser_entity_table(pi_def_type_id => pi_def_type_id,
                                     pi_def_id      => pi_def_id,
                                     pi_run_id      => pi_run_id,
                                     pi_table_type  => v_module_identifier,
                                     pi_process_id  => v_dt_or_ids,
                                     po_flag        => po_flag);

        ELSIF v_module_identifier = 'ASSIGNMENT_TABLE' THEN
          -- integrity checks for assignment table
          perf_analyser_assignment_table(pi_def_type_id => pi_def_type_id,
                                         pi_def_id      => pi_def_id,
                                         pi_run_id      => pi_run_id,
                                         pi_table_type  => v_module_identifier,
                                         pi_process_id  => v_dt_or_ids,
                                         po_flag        => po_flag);

        ELSIF v_module_identifier = 'DATA_TRANSFORMATION' THEN
          -- integrity checks for data transformation process
          perf_analyser_data_transform(pi_def_type_id   => pi_def_type_id,
                                       pi_def_id        => pi_def_id,
                                       pi_run_id        => pi_run_id,
                                       pi_process_type  => v_module_identifier,
                                       po_flag          => po_flag);
        ELSE
          -- needs to be implemented as the module identifier name is found in checks_table
          perf_analyser_dummy(pi_def_type_id => pi_def_type_id,
                                   pi_def_id      => pi_def_id,
                                   pi_run_id      => pi_run_id,
                                   pi_table_type  => v_module_identifier,
                                   po_flag        => po_flag);

        END IF;

  ELSE

     -- the module is not found so I output a warning telling the user to add it to the  checks_table
     perf_analyser_dummy(pi_def_type_id => pi_def_type_id,
                         pi_def_id      => pi_def_id,
                         pi_run_id      => pi_run_id,
                         pi_table_type  => v_module_identifier,
                         po_flag        => po_flag);
  END IF;

END perf_analyser_checks;

END performance_analyzer;
/
