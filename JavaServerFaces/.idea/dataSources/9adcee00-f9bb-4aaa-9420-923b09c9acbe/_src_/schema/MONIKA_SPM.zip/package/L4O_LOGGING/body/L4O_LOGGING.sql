CREATE PACKAGE BODY L4O_LOGGING
IS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
/* ========================== FORWARD DECLARE START ========================== */

FUNCTION GET_OBJECT_VALUE
(	 pi_main_var		ANYDATA
	,pi_main_type_owner	VARCHAR2
	,pi_main_type_name	VARCHAR2
	,pi_main_type_code	VARCHAR2
	,pi_member			VARCHAR2
	,pi_type_owner		VARCHAR2
	,pi_type_name		VARCHAR2
	,pi_level			NUMBER
	,pi_first_char		VARCHAR2
) RETURN CLOB;


FUNCTION GET_COLLECTION_VALUE
(	 pi_main_var		ANYDATA
	,pi_main_type_owner	VARCHAR2
	,pi_main_type_name	VARCHAR2
	,pi_main_type_code	VARCHAR2
	,pi_member			VARCHAR2
	,pi_type_owner		VARCHAR2
	,pi_type_name		VARCHAR2
	,pi_level			NUMBER
	,pi_first_char		VARCHAR2
) RETURN CLOB;

/* ========================== FORWARD DECLARE END ========================== */

/* ========================== PRIVATE METHODS START ========================== */

FUNCTION GET_ELEMENT_VALUE
(	 pi_member			VARCHAR2
	,pi_type_name		VARCHAR2
	,pi_level			NUMBER
	,pi_first_char		VARCHAR2
) RETURN CLOB
IS
	v_elem				CLOB;
BEGIN
	v_elem := 'v_str := v_str||RPAD(CHR(9), '||TO_CHAR(pi_level)||')||'||pi_first_char||'||'
		||CASE	WHEN pi_type_name IN ('NUMBER','PLS_INTEGER','BINARY_INTEGER','DECIMAL','BINARY_DOUBLE','BINARY_FLOAT'
						,'DEC','DOUBLE PRECISION','FLOAT','INT','INTEGER','NATURAL','NATURALN'
						,'NUMERIC','POSITIVE','POSITIVEN','REAL','SIGNTYPE','SMALLINT')

				THEN 'CASE WHEN TO_CHAR('||pi_member||') IS NULL THEN ''NULL'' ELSE TO_CHAR('||pi_member||') END'

				WHEN pi_type_name IN ('DATE', 'TIMESTAMP', 'TIMESTAMP WITH TIME ZONE', 'TIMESTAMP WITH LOCAL TIME ZONE')

				THEN 'CASE WHEN TO_CHAR('||pi_member||') IS NULL THEN ''NULL'' ELSE TO_CHAR('||pi_member||') END'

				WHEN pi_type_name IN ('CHAR','VARCHAR2','CLOB','NCHAR','NVARCHAR2','NCLOB'
						,'CHAR VARYING','CHARACTER','CHARACTER VARYING','NATIONAL CHAR','NATIONAL CHAR VARYING'
						,'NATIONAL CHARACTER','NATIONAL CHARACTER VARYING','NCHAR VARYING','STRING','VARCHAR')

				THEN 'CASE WHEN '||pi_member||' IS NULL THEN ''NULL'' ELSE ''''''''||'||pi_member||'||'''''''' END'

				ELSE '''ERROR''' END
		||'||CHR(10);'||CHR(10)||CHR(9);
	RETURN v_elem;
END GET_ELEMENT_VALUE;


FUNCTION GET_OBJECT_VALUE
(	 pi_main_var		ANYDATA
	,pi_main_type_owner	VARCHAR2
	,pi_main_type_name	VARCHAR2
	,pi_main_type_code	VARCHAR2
	,pi_member			VARCHAR2
	,pi_type_owner		VARCHAR2
	,pi_type_name		VARCHAR2
	,pi_level			NUMBER
	,pi_first_char		VARCHAR2
) RETURN CLOB
IS
	v_obj				CLOB;
BEGIN
	v_obj := 'v_str := v_str||RPAD(CHR(9), '||TO_CHAR(pi_level)||')||'||pi_first_char||';'||CHR(10)||CHR(9)
		||'IF ('||pi_member||' IS NULL) THEN'||CHR(10)||CHR(9)
		||'v_str := v_str||''NULL''||CHR(10);'||CHR(10)||CHR(9)
		||'ELSE'||CHR(10)||CHR(9)
		||'v_str := v_str||'''||pi_type_name||'(''||CHR(10);'||CHR(10)||CHR(9);

	FOR c IN (	SELECT TA.ATTR_NO, TA.ATTR_NAME, TA.ATTR_TYPE_OWNER, TA.ATTR_TYPE_NAME, T.TYPECODE
				FROM SYS.ALL_TYPE_ATTRS TA
					LEFT JOIN SYS.ALL_TYPES T ON TA.ATTR_TYPE_OWNER = T.OWNER AND TA.ATTR_TYPE_NAME = T.TYPE_NAME
				WHERE TA.OWNER = pi_type_owner AND TA.TYPE_NAME = pi_type_name
				ORDER BY TA.ATTR_NO)
	LOOP
		v_obj := v_obj||CASE	WHEN c.TYPECODE = 'OBJECT' THEN L4O_LOGGING.GET_OBJECT_VALUE
													(	 pi_main_var		=> pi_main_var
														,pi_main_type_owner	=> pi_main_type_owner
														,pi_main_type_name	=> pi_main_type_name
														,pi_main_type_code	=> pi_main_type_code
														,pi_member			=> pi_member||'.'||c.ATTR_NAME
														,pi_type_owner		=> c.ATTR_TYPE_OWNER
														,pi_type_name		=> c.ATTR_TYPE_NAME
														,pi_level			=> pi_level + 1
														,pi_first_char		=> CASE	WHEN c.ATTR_NO = 1 THEN ''' '''
																					ELSE ''',''' END
													)
								WHEN c.TYPECODE = 'COLLECTION' THEN L4O_LOGGING.GET_COLLECTION_VALUE
																	(	 pi_main_var		=> pi_main_var
																		,pi_main_type_owner	=> pi_main_type_owner
																		,pi_main_type_name	=> pi_main_type_name
																		,pi_main_type_code	=> pi_main_type_code
																		,pi_member			=> pi_member||'.'||c.ATTR_NAME
																		,pi_type_owner		=> c.ATTR_TYPE_OWNER
																		,pi_type_name		=> c.ATTR_TYPE_NAME
																		,pi_level			=> pi_level + 1
																		,pi_first_char		=> CASE	WHEN c.ATTR_NO = 1 THEN ''' '''
																									ELSE ''',''' END
																	)
								ELSE L4O_LOGGING.GET_ELEMENT_VALUE
										(	 pi_member		=> pi_member||'.'||c.ATTR_NAME
											,pi_type_name	=> c.ATTR_TYPE_NAME
											,pi_level		=> pi_level + 1
											,pi_first_char	=> CASE	WHEN c.ATTR_NO = 1 THEN ''' '''
																	ELSE ''',''' END
										) END;
	END LOOP;

	v_obj := v_obj||'v_str := v_str||RPAD(CHR(9), '||TO_CHAR(pi_level)||')||'')''||CHR(10);'||CHR(10)||CHR(9)
		||'END IF;'||CHR(10)||CHR(9);

	RETURN v_obj;
END GET_OBJECT_VALUE;


FUNCTION GET_COLLECTION_VALUE
(	 pi_main_var		ANYDATA
	,pi_main_type_owner	VARCHAR2
	,pi_main_type_name	VARCHAR2
	,pi_main_type_code	VARCHAR2
	,pi_member			VARCHAR2
	,pi_type_owner		VARCHAR2
	,pi_type_name		VARCHAR2
	,pi_level			NUMBER
	,pi_first_char		VARCHAR2
) RETURN CLOB
IS
	v_coll				CLOB;
	v_elem_type_owner	VARCHAR2(200);
	v_elem_type_name	VARCHAR2(200);
	v_elem_type_code	VARCHAR2(200);
	v_index				    VARCHAR2(200);
BEGIN
    v_index := CASE WHEN NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('L4O_COLL_INCLUDE_INDEX'), 'FALSE')  = 'TRUE'
					THEN '''/*''||TO_CHAR(v_idx'||TO_CHAR(pi_level)||')||''*/''||'
					ELSE NULL END;

	SELECT CT.ELEM_TYPE_OWNER, CT.ELEM_TYPE_NAME, T.TYPECODE
	INTO v_elem_type_owner, v_elem_type_name, v_elem_type_code
	FROM ALL_COLL_TYPES CT
		LEFT JOIN SYS.ALL_TYPES T ON CT.ELEM_TYPE_OWNER = T.OWNER AND CT.ELEM_TYPE_NAME = T.TYPE_NAME
	WHERE CT.OWNER = pi_type_owner AND CT.TYPE_NAME = pi_type_name;

	v_coll := 'v_str := v_str||RPAD(CHR(9), '||TO_CHAR(pi_level)||')||'||pi_first_char||';'||CHR(10)||CHR(9)
		||'IF ('||pi_member||' IS NULL) THEN'||CHR(10)||CHR(9)
		||'v_str := v_str||''NULL''||CHR(10);'||CHR(10)||CHR(9)
		||'ELSE'||CHR(10)||CHR(9)
		||'v_str := v_str||'''||pi_type_name||'(''||CHR(10);'||CHR(10)||CHR(9)
		||'v_idx'||TO_CHAR(pi_level)||' := '||pi_member||'.FIRST;'||CHR(10)||CHR(9)
		||'WHILE (v_idx'||TO_CHAR(pi_level)||' IS NOT NULL)'||CHR(10)||CHR(9)
		||'LOOP'||CHR(10)||CHR(9)

		||CASE	WHEN v_elem_type_code = 'OBJECT' THEN L4O_LOGGING.GET_OBJECT_VALUE
													(	 pi_main_var		=> pi_main_var
														,pi_main_type_owner	=> pi_main_type_owner
														,pi_main_type_name	=> pi_main_type_name
														,pi_main_type_code	=> pi_main_type_code
														,pi_member			=> pi_member||'(v_idx'||TO_CHAR(pi_level)||')'
														,pi_type_owner		=> v_elem_type_owner
														,pi_type_name		=> v_elem_type_name
														,pi_level			=> pi_level + 1
														,pi_first_char		=> v_index||'CASE WHEN v_idx'||TO_CHAR(pi_level)||' = '||pi_member||'.FIRST THEN '' '' ELSE '','' END'
													)
				WHEN v_elem_type_code = 'COLLECTION' THEN L4O_LOGGING.GET_COLLECTION_VALUE
													(	 pi_main_var		=> pi_main_var
														,pi_main_type_owner	=> pi_main_type_owner
														,pi_main_type_name	=> pi_main_type_name
														,pi_main_type_code	=> pi_main_type_code
														,pi_member			=> pi_member||'(v_idx'||TO_CHAR(pi_level)||')'
														,pi_type_owner		=> v_elem_type_owner
														,pi_type_name		=> v_elem_type_name
														,pi_level			=> pi_level + 1
														,pi_first_char		=> v_index||'CASE WHEN v_idx'||TO_CHAR(pi_level)||' = '||pi_member||'.FIRST THEN '' '' ELSE '','' END'
													)
				ELSE L4O_LOGGING.GET_ELEMENT_VALUE
						(	 pi_member		=> pi_member||'(v_idx'||TO_CHAR(pi_level)||')'
							,pi_type_name	=> v_elem_type_name
							,pi_level		=> pi_level + 1
							,pi_first_char	=> v_index||'CASE WHEN v_idx'||TO_CHAR(pi_level)||' = '||pi_member||'.FIRST THEN '' '' ELSE '','' END'
						) END

		||'v_idx'||TO_CHAR(pi_level)||' := '||pi_member||'.NEXT(v_idx'||TO_CHAR(pi_level)||');'||CHR(10)||CHR(9)
		||'END LOOP;'||CHR(10)||CHR(9)

		||'v_str := v_str||RPAD(CHR(9), '||TO_CHAR(pi_level)||')||'')''||CHR(10);'||CHR(10)||CHR(9)
		||'END IF;'||CHR(10)||CHR(9);

	RETURN v_coll;
END GET_COLLECTION_VALUE;


FUNCTION GET_VARIABLE_VALUE
(	pi_var				ANYDATA
) RETURN CLOB
IS
	v_type_owner		VARCHAR2(200);
	v_type_name			VARCHAR2(200);
	v_type_code			VARCHAR2(200);
	v_var_dyn_str		CLOB;
	v_cmd				CLOB;
	v_str				CLOB;
BEGIN
	v_type_owner := SUBSTR(pi_var.GETTYPENAME(), 1, INSTR(pi_var.GETTYPENAME(), '.')-1);
	v_type_name := SUBSTR(pi_var.GETTYPENAME(), INSTR(pi_var.GETTYPENAME(), '.')+1);

	BEGIN
		SELECT TYPECODE
		INTO v_type_code
		FROM SYS.ALL_TYPES
		WHERE OWNER = v_type_owner
			AND TYPE_NAME = v_type_name;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
		NULL;
	END;

	v_var_dyn_str := CASE	WHEN v_type_code = 'OBJECT' THEN L4O_LOGGING.GET_OBJECT_VALUE
														(	 pi_main_var		=> pi_var
															,pi_main_type_owner	=> v_type_owner
															,pi_main_type_name	=> v_type_name
															,pi_main_type_code	=> v_type_code
															,pi_member			=> 'v_var_val'
															,pi_type_owner		=> v_type_owner
															,pi_type_name		=> v_type_name
															,pi_level			=> 0
															,pi_first_char		=> ''' '''
														)
							WHEN v_type_code = 'COLLECTION' THEN L4O_LOGGING.GET_COLLECTION_VALUE
																(	 pi_main_var		=> pi_var
																	,pi_main_type_owner	=> v_type_owner
																	,pi_main_type_name	=> v_type_name
																	,pi_main_type_code	=> v_type_code
																	,pi_member			=> 'v_var_val'
																	,pi_type_owner		=> v_type_owner
																	,pi_type_name		=> v_type_name
																	,pi_level			=> 0
																	,pi_first_char		=> ''' '''
																)
							ELSE L4O_LOGGING.GET_ELEMENT_VALUE
									(	 pi_member		=> 'v_var_val'
										,pi_type_name	=> v_type_name
										,pi_level		=> 0
										,pi_first_char	=> ''' '''
									) END;
	v_var_dyn_str := LTRIM(RTRIM(v_var_dyn_str, CHR(10)), '|');

	v_cmd := '
	DECLARE
	v_var			ANYDATA;
	v_retcode		PLS_INTEGER;
	v_var_val		'|| CASE	WHEN v_type_owner <> 'SYS' THEN v_type_owner||'.'
								ELSE NULL END
					|| CASE	WHEN v_type_name = 'VARCHAR2' THEN v_type_name||'(32767)'
								ELSE v_type_name END ||';
	v_str			CLOB;
	v_idx0			PLS_INTEGER;	v_idx1			PLS_INTEGER;
	v_idx2			PLS_INTEGER;	v_idx3			PLS_INTEGER;
	v_idx4			PLS_INTEGER;	v_idx5			PLS_INTEGER;
	v_idx6			PLS_INTEGER;	v_idx7			PLS_INTEGER;
	v_idx8			PLS_INTEGER;	v_idx9			PLS_INTEGER;
	v_idx10			PLS_INTEGER;	v_idx11			PLS_INTEGER;
	v_idx12			PLS_INTEGER;	v_idx13			PLS_INTEGER;
	v_idx14			PLS_INTEGER;	v_idx15			PLS_INTEGER;
	v_idx16			PLS_INTEGER;	v_idx17			PLS_INTEGER;
	v_idx18			PLS_INTEGER;	v_idx19			PLS_INTEGER;
	BEGIN
	v_var := :pi_var;
	v_retcode := v_var.'||CASE	WHEN v_type_code = 'COLLECTION' THEN 'GETCOLLECTION'
								WHEN v_type_code = 'OBJECT' THEN 'GETOBJECT'
								ELSE 'GET'||v_type_name END
						||'(v_var_val);

	'||v_var_dyn_str||'
	:po_str := v_str;
	END;';

	EXECUTE IMMEDIATE v_cmd
	USING pi_var, OUT v_str;

	v_str := LTRIM(RTRIM(v_str, CHR(10)), ' ');

	RETURN v_str;
EXCEPTION
	WHEN OTHERS THEN
		v_str := SQLERRM;
		RETURN v_str;
END GET_VARIABLE_VALUE;


PROCEDURE SAVE_MESSAGE_IN_DB
(	 pi_log_level		L4O_LOGS.L4OL_LEVEL%TYPE
	,pi_message			L4O_LOGS.L4OL_MESSAGE%TYPE
	,pi_error_code		L4O_LOGS.L4OL_ERROR_CODE%TYPE
	,pi_error_message	L4O_LOGS.L4OL_ERROR_MESSAGE%TYPE
	,pi_identifier		L4O_LOGS.L4OL_IDENTIFIER%TYPE
)
IS
	PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
	INSERT INTO L4O_LOGS
	(	 L4OL_ID
		,L4OL_DATE
		,L4OL_IDENTIFIER
		,L4OL_MESSAGE
		,L4OL_ERROR_CODE
		,L4OL_ERROR_MESSAGE
		,L4OL_LEVEL
	) VALUES
	(	 L4O_LOGS_L4OL_ID_SEQ.NEXTVAL
		,CURRENT_TIMESTAMP
		,pi_identifier
		,pi_message
		,pi_error_code
		,pi_error_message
		,pi_log_level
	);
	COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RAISE;
END SAVE_MESSAGE_IN_DB;


PROCEDURE SAVE_MESSAGE
(	 pi_log_level		L4O_LOGS.L4OL_LEVEL%TYPE
	,pi_message			L4O_LOGS.L4OL_MESSAGE%TYPE
	,pi_error_code		L4O_LOGS.L4OL_ERROR_CODE%TYPE
	,pi_error_message	L4O_LOGS.L4OL_ERROR_MESSAGE%TYPE
	,pi_identifier		L4O_LOGS.L4OL_IDENTIFIER%TYPE
)
IS
	v_message			  CLOB;
BEGIN
    IF (NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('L4O_OUTPUT_DEVICE'), L4O_LOGGING.OUT_DATABASE) = L4O_LOGGING.OUT_DATABASE)
	THEN
		L4O_LOGGING.SAVE_MESSAGE_IN_DB
		(	 pi_log_level		=> pi_log_level
			,pi_message			=> pi_message
			,pi_error_code		=> pi_error_code
			,pi_error_message	=> pi_error_message
			,pi_identifier		=> pi_identifier
		);
	ELSIF (NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('L4O_OUTPUT_DEVICE'), L4O_LOGGING.OUT_DATABASE) = L4O_LOGGING.OUT_BUFFER)
	THEN
		v_message :=
					  CASE	WHEN NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('L4O_INCLUDE_TIMESTAMP'), 'FALSE') = 'TRUE'
							THEN TO_CHAR(CURRENT_TIMESTAMP, 'YYYY.MM.DD HH24:MI:SS:FF3')||' - '||pi_log_level||' - '
							ELSE NULL END
					||pi_message
					||CASE	WHEN pi_error_code IS NOT NULL
								OR pi_error_message IS NOT NULL THEN ' ('
							ELSE NULL END
					||CASE	WHEN pi_error_code IS NOT NULL THEN pi_error_code||', '
							ELSE NULL END
					||pi_error_message
					||CASE	WHEN pi_error_code IS NOT NULL
								OR pi_error_message IS NOT NULL THEN ')'
							ELSE NULL END;

		FOR i IN 0..LENGTH(v_message)/1000
		LOOP
			DBMS_OUTPUT.PUT_LINE(SUBSTR(v_message, (i*1000) + 1, 1000));
		END LOOP;
	END IF;
END SAVE_MESSAGE;

/* ========================== PRIVATE METHODS END ========================== */

/* ========================== PUBLIC METHODS START ========================== */

PROCEDURE LOG_MESSAGE
(	 pi_log_level		L4O_LOGS.L4OL_LEVEL%TYPE
	,pi_message			L4O_LOGS.L4OL_MESSAGE%TYPE
	,pi_error_code		L4O_LOGS.L4OL_ERROR_CODE%TYPE DEFAULT NULL
	,pi_error_message	L4O_LOGS.L4OL_ERROR_MESSAGE%TYPE DEFAULT NULL
	,pi_identifier		L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL
)
IS
BEGIN
	IF (CASE NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('L4O_LOGGING_LEVEL'), L4O_LOGGING.LVL_INFO)
			WHEN L4O_LOGGING.LVL_FATAL THEN 0
			WHEN L4O_LOGGING.LVL_ERROR THEN 1
			WHEN L4O_LOGGING.LVL_WARN THEN 2
			WHEN L4O_LOGGING.LVL_INFO THEN 3
			WHEN L4O_LOGGING.LVL_DEBUG THEN 4
			ELSE NULL END
		>= CASE pi_log_level
			WHEN L4O_LOGGING.LVL_FATAL THEN 0
			WHEN L4O_LOGGING.LVL_ERROR THEN 1
			WHEN L4O_LOGGING.LVL_WARN THEN 2
			WHEN L4O_LOGGING.LVL_INFO THEN 3
			WHEN L4O_LOGGING.LVL_DEBUG THEN 4
			ELSE NULL END)
	THEN
		L4O_LOGGING.SAVE_MESSAGE
		(	 pi_log_level		=> pi_log_level
			,pi_message			=> pi_message
			,pi_error_code		=> pi_error_code
			,pi_error_message	=> pi_error_message
			,pi_identifier		=> pi_identifier
		);
	END IF;
EXCEPTION
	WHEN OTHERS THEN
		NULL;
END LOG_MESSAGE;


PROCEDURE LOG_VARIABLE
(	 pi_log_level		L4O_LOGS.L4OL_LEVEL%TYPE
	,pi_variable		ANYDATA
	,pi_message_format	VARCHAR2 DEFAULT NULL
	,pi_identifier		L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL
)
IS
	v_var_value			CLOB;
	v_message			CLOB;
BEGIN
	IF (CASE NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('L4O_LOGGING_LEVEL'), L4O_LOGGING.LVL_INFO)
			WHEN L4O_LOGGING.LVL_FATAL THEN 0
			WHEN L4O_LOGGING.LVL_ERROR THEN 1
			WHEN L4O_LOGGING.LVL_WARN THEN 2
			WHEN L4O_LOGGING.LVL_INFO THEN 3
			WHEN L4O_LOGGING.LVL_DEBUG THEN 4
			ELSE NULL END
		>= CASE pi_log_level
			WHEN L4O_LOGGING.LVL_FATAL THEN 0
			WHEN L4O_LOGGING.LVL_ERROR THEN 1
			WHEN L4O_LOGGING.LVL_WARN THEN 2
			WHEN L4O_LOGGING.LVL_INFO THEN 3
			WHEN L4O_LOGGING.LVL_DEBUG THEN 4
			ELSE NULL END)
	THEN
		v_var_value := L4O_LOGGING.GET_VARIABLE_VALUE(pi_variable);

		IF (NVL(INSTR(pi_message_format, '<value>'), 0) = 0)
		THEN
			v_message := pi_message_format||v_var_value;
		ELSE
			v_message := REPLACE(pi_message_format, '<value>', v_var_value);
		END IF;

		L4O_LOGGING.SAVE_MESSAGE
		(	 pi_log_level		=> pi_log_level
			,pi_message			=> v_message
			,pi_error_code		=> NULL
			,pi_error_message	=> NULL
			,pi_identifier		=> pi_identifier
		);
	END IF;
EXCEPTION
	WHEN OTHERS THEN
		NULL;
END LOG_VARIABLE;


FUNCTION CREATE_LOG(
    pin_package_name   varchar2,
    pin_procedure_name varchar2
  )
    RETURN CLOB
    AS
      TYPE ARGUMENT_REC IS RECORD (
      ARGUMENT_NAME VARCHAR2(30),
      ARGUMENT_TYPE VARCHAR2(30),
      ARGUMENT_ID NUMBER,
      ARGUMENT_IN_OUT VARCHAR2(6));

      TYPE ARGUMENT_MOD IS TABLE OF ARGUMENT_REC;

      V_ARGUMENTS ARGUMENT_MOD := ARGUMENT_MOD();

      V_SUBPROGRAM_ID NUMBER := 1;

    V_INPUT_LOG CLOB := '-- FUNCTION/PROCEDURE NR 1
    v_stamp            VARCHAR2(250);

BEGIN

  v_stamp := ''' || pin_package_name || '.' || pin_procedure_name || ' - input - ''||TO_CHAR(CURRENT_TIMESTAMP,''YYYY-MM-DD HH24:MI:SSxFF'');

  -- log the input parameters
  BEGIN';

    V_OUTPUT_LOG CLOB := '
-- FUNCTION/PROCEDURE NR 1
  v_stamp := replace(v_stamp, ''input'', ''output'');
  -- log the output parameters
  BEGIN';

    V_LOG_OUTPUT_START CONSTANT VARCHAR2(32767) := '
  v_stamp := replace(v_stamp, ''input'', ''output'');
  -- log the output parameters
  BEGIN';

    V_LOG_INPUT_START CONSTANT VARCHAR2(32767) := '
  v_stamp            VARCHAR2(250);

BEGIN

  v_stamp := ''' || pin_package_name || '.' || pin_procedure_name || ' - input - ''||TO_CHAR(CURRENT_TIMESTAMP,''YYYY-MM-DD HH24:MI:SSxFF'');

  -- log the input parameters
  BEGIN';


  BEGIN


    select ARGUMENT_NAME, DATA_TYPE, SUBPROGRAM_ID, IN_OUT
    BULK COLLECT INTO V_ARGUMENTS
    from user_arguments a
    where object_name = pin_procedure_name
    and PACKAGE_NAME = pin_package_name
    AND NOT(POSITION <> 0 AND ARGUMENT_NAME IS NULL)
    ORDER BY SUBPROGRAM_ID, POSITION;

    FOR i IN V_ARGUMENTS.FIRST .. V_ARGUMENTS.LAST
      LOOP
        CASE (V_ARGUMENTS(I).ARGUMENT_IN_OUT)
        WHEN 'IN' THEN

          IF (V_SUBPROGRAM_ID <> V_ARGUMENTS(I).ARGUMENT_ID) THEN
             V_SUBPROGRAM_ID := V_ARGUMENTS(I).ARGUMENT_ID;
             V_INPUT_LOG := V_INPUT_LOG || '
  END;

-- FUNCTION/PROCEDURE NR ' || V_SUBPROGRAM_ID || '
             ' || V_LOG_INPUT_START;

          END IF;
          --
            V_INPUT_LOG := V_INPUT_LOG || '
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERT'
    ||
            CASE V_ARGUMENTS(I).ARGUMENT_TYPE
                WHEN 'TABLE' THEN 'COLLECTION'
                WHEN 'BINARY_INTEGER' THEN 'NUMBER'
                ELSE V_ARGUMENTS(I).ARGUMENT_TYPE
            END
    ||
    '('
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    '),    '','
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    ' => <value>'', v_stamp);';
          --
        WHEN 'OUT' THEN

          IF (V_SUBPROGRAM_ID <> V_ARGUMENTS(I).ARGUMENT_ID) THEN
             V_SUBPROGRAM_ID := V_ARGUMENTS(I).ARGUMENT_ID;
             V_OUTPUT_LOG := V_OUTPUT_LOG || '
  END;

-- FUNCTION/PROCEDURE NR ' || V_SUBPROGRAM_ID || '
             ' || V_LOG_OUTPUT_START;

          END IF;
          --
             V_OUTPUT_LOG := V_OUTPUT_LOG || '
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERT'
    ||
            CASE V_ARGUMENTS(I).ARGUMENT_TYPE
                WHEN 'TABLE' THEN 'COLLECTION'
                WHEN 'BINARY_INTEGER' THEN 'NUMBER'
                ELSE V_ARGUMENTS(I).ARGUMENT_TYPE
            END
    ||
    '('
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    '),    '','
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    ' => <value>'', v_stamp);';
    --
        WHEN 'IN/OUT' THEN
          --
          IF (V_SUBPROGRAM_ID <> V_ARGUMENTS(I).ARGUMENT_ID) THEN
             V_SUBPROGRAM_ID := V_ARGUMENTS(I).ARGUMENT_ID;
             V_OUTPUT_LOG := V_OUTPUT_LOG || '
  END;

-- FUNCTION/PROCEDURE NR ' || V_SUBPROGRAM_ID || '
             ' || V_LOG_OUTPUT_START;
             V_INPUT_LOG := V_INPUT_LOG || '
  END;

-- FUNCTION/PROCEDURE NR ' || V_SUBPROGRAM_ID || '
             ' || V_LOG_INPUT_START;

          END IF;
          --
             V_INPUT_LOG := V_INPUT_LOG || '
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERT'
    ||
            CASE V_ARGUMENTS(I).ARGUMENT_TYPE
                WHEN 'TABLE' THEN 'COLLECTION'
                WHEN 'BINARY_INTEGER' THEN 'NUMBER'
                ELSE V_ARGUMENTS(I).ARGUMENT_TYPE
            END
    ||
    '('
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    '),    '','
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    ' => <value>'', v_stamp);';
    --
    V_OUTPUT_LOG := V_OUTPUT_LOG || '
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERT'
    ||
            CASE V_ARGUMENTS(I).ARGUMENT_TYPE
                WHEN 'TABLE' THEN 'COLLECTION'
                WHEN 'BINARY_INTEGER' THEN 'NUMBER'
                ELSE V_ARGUMENTS(I).ARGUMENT_TYPE
            END
    ||
    '('
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    '),    '','
    || V_ARGUMENTS(I).ARGUMENT_NAME ||
    ' => <value>'', v_stamp);';



        END CASE;

      END LOOP;

     RETURN V_INPUT_LOG ||
           '
  END;
  ---------
  ---------
  ---------
           '
           || V_OUTPUT_LOG || '
  END;';
END CREATE_LOG;

/* ========================== PUBLIC METHODS END ========================== */
END L4O_LOGGING;
/
