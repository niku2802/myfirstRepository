CREATE PACKAGE commons AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: commons
-- Module			: commons
-- Requester		: Cozac, Tudor
-- Author			: Cozac, Tudor
-- Reviewer			:
-- Review date		:
-- Description		:
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       ******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         ******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START	*******************************

	-- ################################ CREATE_PK_TRIGGER START	################################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Cozac, Tudor
	Create date	:
	Description	:
	----------------------------------------------------------------------------------------
	Input Parameters:

	----------------------------------------------------------------------------------------
	Result set:

	----------------------------------------------------------------------------------------
	Example:

	----------------------------------------------------------------------------------------
	*/
	PROCEDURE CREATE_PK_TRIGGER (
		pi_table_name	IN VARCHAR2,
		pi_column_name	IN VARCHAR2
	);
	-- ################################ CREATE_PK_TRIGGER END	################################

	-- ################################ LISTAGG_COLLECT START	################################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Dumitriu, Cosmin
	Create date	: 20110713
	Description	: LISTAGG_COLLECT is part of a workaround of the aggregate system function LISTAGG
					which cannot return values with more than 4000 chars. It is designed to be used in conjunction
					with the COLLECT system function.
					It basically takes an array of VARCHAR2(32000) values (gathered by the COLLECT function) and
					returns a CLOB that contains all the above elements concatenated.

	----------------------------------------------------------------------------------------
	Prerequisites:
		The nested table type TABLETYPE_CHARMAX (TABLE OF VARCHAR2(32000)) must already be created within the schema.

	----------------------------------------------------------------------------------------
	Input Parameters:
		pin_wordlist	IN TABLETYPE_CHARMAX		- NOT NULL - this is the array of values to be concatenated
		pin_delimiter	IN VARCHAR2 DEFAULT ','		- NULL - this is the delimiter to be used.
													If nothing is supplied then by default ',' is used.
													The delimiter can be made out of more than 1 character.
		pin_maxcount	IN NUMBER DEFAULT NULL		- NULL - the maximum number of values to concatenate.
													Only the first <pin_maxcount> number of values will be returned within the CLOB.
													If nothing or NULL is supplied then all values are concatenated

	----------------------------------------------------------------------------------------
	Example:
		-- all values are concatenated
		select		 department_id
					,LISTAGG_COLLECT(CAST(COLLECT(emp_name) AS TABLETYPE_CHARMAX), ',', NULL) emp_names
		from		employees
		group by	department_id

		-- first 30 values are concatented, elements are taken in order by hire date.
		select		 department_id
					,LISTAGG_COLLECT(CAST(COLLECT(emp_name ORDER BY emp_hire_date) AS TABLETYPE_CHARMAX), ',', 30) emp_names
		from		employees
		group by	department_id

	----------------------------------------------------------------------------------------
	*/
	FUNCTION LISTAGG_COLLECT (
		 pin_wordlist	IN TABLETYPE_CHARMAX
		,pin_delimiter	IN VARCHAR2 DEFAULT ','
		,pin_maxcount	IN NUMBER DEFAULT NULL
	) RETURN CLOB;
	-- ################################ LISTAGG_COLLECT END		################################

	-- ############################# FIELD_PRECISION_AND_SCALE START   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Cozac, Tudor
	Create date	: 20110720
	Description	: Return the precision and scale for a given field defined in fields.
	----------------------------------------------------------------------------------------
	Input Parameters:
		pin_field_name NOT NULL VARCHAR2  : The physical column name for a field.(FIELDS.FLD_COLUMN_NAME)
	----------------------------------------------------------------------------------------
	Return (precision, scale)
		precision	: the scale + integer_part_lenght
					integer_part_lenght: a constant for the project stored in PARAMETER table for parameter name FIELD_INTEGER_PART_LENGTH.
		scale		: the scale defined for the field; from FIELDS.FLD_LENGTH scale
	----------------------------------------------------------------------------------------
	Example: SELECT COMMONS.FIELD_PRECISION_AND_SCALE('METRIC') FROM DUAL;
	Return: (17,4)
	----------------------------------------------------------------------------------------

	*/
	FUNCTION FIELD_PRECISION_AND_SCALE(
		pin_field_name	IN VARCHAR2
	) RETURN VARCHAR2;
	-- ############################# FIELD_PRECISION_AND_SCALE START   #############################

	-- ############################# FIELD_SCALE START   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Cozac, Tudor
	Create date	: 20160802
	Description	: Return the precision and scale for a given field defined in fields with precision defined by the user
	----------------------------------------------------------------------------------------
	Input Parameters:
		pin_field_name NOT NULL VARCHAR2  : The physical column name for a field.(FIELDS.FLD_COLUMN_NAME)
    pin_precision NOT NULL NUMBER  : The precision of the field defined by the user
	----------------------------------------------------------------------------------------
	Return (precision, scale)
		precision	: the scale + integer_part_lenght
					integer_part_lenght: a constant for the project stored in PARAMETER table for parameter name FIELD_INTEGER_PART_LENGTH.
		scale		: the scale defined for the field; from FIELDS.FLD_LENGTH scale
	----------------------------------------------------------------------------------------
	Example: SELECT COMMONS.FIELD_SCALE('METRIC',2) FROM DUAL;
	Return: (17,4)
	----------------------------------------------------------------------------------------

	*/
	FUNCTION FIELD_SCALE(
		pin_field_name	IN VARCHAR2
   ,pin_precision IN NUMBER
	) RETURN VARCHAR2;
	-- ############################# FIELD_SCALE START   #############################

	-- ############################# check_record_existence start   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Lazar, Lucian
	Create date	: 20110831
	Description	: Returns 0 or 1 depending if a given query returns at least a record
	----------------------------------------------------------------------------------------
	Input Parameters:
		pi_sql not null clob: The query that will be checked if returns at least a record
	----------------------------------------------------------------------------------------
	Return: 0 for no records, 1 for at least one record
	----------------------------------------------------------------------------------------
	Example: select commons.check_record_existence('select * from count_one where c2 = 0') from dual;
	Return: 1
	----------------------------------------------------------------------------------------
	*/
	function check_record_existence(pi_sql in clob)	return integer;
	-- ############################# check_record_existence end   #############################
	-- ############################# FIND_ENITY_BUSINESS_KEY START   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Hrubaru, Ionut
	Create date	: 20111011
	Description	: Return the business id for a given entity table
	----------------------------------------------------------------------------------------
	Input Parameters:
		pin_table_name NOT NULL VARCHAR2  : The physical table name for a entity.(tables.tables_physical_name)
	----------------------------------------------------------------------------------------
	Return (tc_physical_name)
		tc_physical_name = physical name of the business key column
	----------------------------------------------------------------------------------------
	Example: SELECT COMMONS.FIND_ENITY_BUSINESS_KEY('T123') FROM DUAL;
	Return: (17,4)
	----------------------------------------------------------------------------------------

	*/
	FUNCTION FIND_ENITY_BUSINESS_KEY(
		pin_table_name	IN VARCHAR2
	) RETURN VARCHAR2;
	-- ############################# FIND_ENITY_BUSINESS_KEY START   #############################

	FUNCTION FIND_ENT_BUSINESS_KEY_BY_NAME(
		pin_entity_name	IN VARCHAR2
	) RETURN VARCHAR2;

  	FUNCTION FIND_ENT_TABLE_NAME(
		pin_entity_name	IN VARCHAR2
	) RETURN VARCHAR2;

	-- ############################# terminate_insane_query start   #############################
	/*
	----------------------------------------------------------------------------------------
	Author     	: Lazar, Lucian
	Create date	: 20140429
	Description	: Raises an error if a given query has an estimated execution time longer than a threshold
                Logs the query
                Sends an alert if the query has an estimated temp space consumption larger than a threshold
	----------------------------------------------------------------------------------------
	Input Parameters:
		pi_sql not  null      clob    The query that will be checked if its estimated execution time longer then a treshold
    pi_run_id   not null  number  The run id of the process that generated the query
	----------------------------------------------------------------------------------------
	Result:
		Raises custom ORA-20011 exception if the query has an execution time longer then a treshold
	----------------------------------------------------------------------------------------
	Example: commons.terminate_insane_query('select 1 from dual',1234);
	----------------------------------------------------------------------------------------
	*/
	procedure terminate_insane_query(pi_sql in clob, pi_run_id in number);
	-- ############################# terminate_insane_query end   #############################

-- *******************************    PUBLIC PROCEDURES END		*******************************
END commons;
/
