CREATE PACKAGE BODY app_locking
AS

    FUNCTION GetListOfLocksByServer (Server IN VARCHAR2)
      RETURN RESOURCELOCKS_MAP
      PIPELINED
    AS
        v_RL_MapRec   RESOURCELOCKS_MAPREC;
    BEGIN
        FOR v_RL_MapRec IN (SELECT  rl_id, rl_resource, rl_server, rl_lock_mode, rl_run_id, rl_transaction_id
                            FROM    resource_locks
                            WHERE   rl_server = Server)
        LOOP
         PIPE ROW (v_RL_MapRec);
        END LOOP;
    END GetListOfLocksByServer;


    PROCEDURE Acquire_Lock (ResourceName    IN  VARCHAR2
                           ,Server          IN  VARCHAR2
                           ,Lock_Mode       IN  INT         -- 1 for SHARED, 2 for WX and 3 for FX
                           ,Run_ID          IN  NUMBER
                           ,Transaction_ID  IN  VARCHAR2
                           ,Lock_ID         OUT INT)
    AS
        i pls_integer;
        v_rl_id resource_locks.rl_id%type;
        v_rl_lock_mode resource_locks.rl_lock_mode%type;
        resource_busy_timeout EXCEPTION;
        PRAGMA EXCEPTION_INIT (resource_busy_timeout, -30006);
    BEGIN

        FOR i IN 1..20 LOOP  -- looping for max 5 secs for in order to get exclusive access on all locks of the current resource
            BEGIN
                SAVEPOINT acq_lock_trans;  -- mark the savepoint

                INSERT INTO resource_locks (rl_id, rl_resource, rl_server, rl_lock_mode, rl_system_resource)  -- add a "system" lock to serialize access on the resource
                       values (s_resource_locks.NEXTVAL, ResourceName, Server, -1, ResourceName)
                       returning rl_id into v_rl_id;

                select nvl((SELECT max(rl_lock_mode) FROM resource_locks WHERE  rl_resource = ResourceName),0) into v_rl_lock_mode from dual for update WAIT 5;

                IF Lock_Mode = 1 and v_rl_lock_mode not in (3)
                THEN                                                           -- SHARED
                    INSERT INTO resource_locks (rl_id, rl_resource, rl_server, rl_lock_mode, rl_run_id, rl_transaction_id)
                        values (s_resource_locks.NEXTVAL, ResourceName, Server, Lock_Mode, Run_ID, Transaction_ID)
                        returning rl_id into Lock_ID;

                ELSIF Lock_Mode = 2 and v_rl_lock_mode not in (2,3)
                THEN                                                           -- WX
                    INSERT INTO resource_locks (rl_id, rl_resource, rl_server, rl_lock_mode, rl_run_id, rl_transaction_id)
                        values(s_resource_locks.NEXTVAL, ResourceName, Server, Lock_Mode, Run_ID, Transaction_ID)
                        returning rl_id into Lock_ID;

                ELSIF Lock_Mode = 3 and v_rl_lock_mode not in (1,2,3)
                THEN                                                           -- FX
                    INSERT INTO resource_locks (rl_id, rl_resource, rl_server, rl_lock_mode, rl_run_id, rl_transaction_id)
                        values(s_resource_locks.NEXTVAL, ResourceName, Server, Lock_Mode, Run_ID, Transaction_ID)
                        returning rl_id into Lock_ID;

                ELSIF Lock_Mode not in (1,2,3)
                THEN
                    raise_application_error (-20001,'Incorrect LockMode value supplied! Please use 1 for SHARED, 2 for WX and 3 for FX.');

                ELSE
                    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, NVL (TO_CHAR (Lock_ID), 'Lock not acquired!'));
                END IF;

                --dbms_lock.sleep(10);
                DELETE resource_locks WHERE rl_id=v_rl_id;  --remove "system" lock
                COMMIT;
                EXIT;

                EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, '"System lock '||v_rl_id||' detected. Retrying :'||to_char(i));
                        --dbms_lock.sleep(0.25); -- TODO: to use a sleep routine after granting the proper rights

                        ROLLBACK TO acq_lock_trans;
                     WHEN OTHERS THEN
                        ROLLBACK WORK;
                        RAISE;
                END;

             END LOOP;
        EXCEPTION
           WHEN DUP_VAL_ON_INDEX THEN
                L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Lock not acquired due to timeout.');
                ROLLBACK WORK;
           WHEN resource_busy_timeout then
                L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Lock not acquired due to timeout.');
                ROLLBACK WORK;
           WHEN OTHERS THEN
                ROLLBACK WORK;
                RAISE;
    END Acquire_Lock;


    PROCEDURE ReleaseLockByLockID (Lock_ID IN NUMBER)
    AS
    BEGIN
       DELETE resource_locks
       WHERE rl_id=Lock_ID;

       --COMMIT;
    END ReleaseLockByLockID;

    PROCEDURE ReleaseLockByServer (Server IN VARCHAR2)
    as
    BEGIN
       DELETE resource_locks
       WHERE rl_server=Server;

      -- COMMIT;
    END ReleaseLockByServer;

    PROCEDURE ReleaseLockByRunID (Run_ID IN NUMBER)
    as
    BEGIN
       DELETE resource_locks
       WHERE rl_run_id=Run_ID;

       --COMMIT;
    END ReleaseLockByRunID;

    PROCEDURE Change_Lock (Lock_ID         IN OUT INT
                          ,Lock_Mode       IN  INT         -- 1 for SHARED, 2 for WX and 3 for FX
                          ,ResourceName    IN  VARCHAR2
                          )
    AS
        i pls_integer;
        v_rl_id_system resource_locks.rl_id%type;
        v_rl_id resource_locks.rl_id%type;
        v_rl_lock_mode resource_locks.rl_lock_mode%type;
        resource_busy_timeout EXCEPTION;
        PRAGMA EXCEPTION_INIT (resource_busy_timeout, -30006);
    BEGIN

        FOR i IN 1..20 LOOP -- looping for max 5 secs for in order to get exclusive access on all locks of the current resource
            BEGIN
                SAVEPOINT acq_lock_trans;  -- mark the savepoint
                INSERT INTO resource_locks (rl_id, rl_resource, rl_server, rl_lock_mode, rl_system_resource)  -- add a "system" lock to serialize access on the resource
                       values (s_resource_locks.NEXTVAL, ResourceName, null, -1, ResourceName)
                       returning rl_id into v_rl_id_system;

                select nvl((SELECT max(rl_lock_mode) FROM resource_locks WHERE  rl_resource = ResourceName and rl_id<>Lock_ID),0) into v_rl_lock_mode from dual for update WAIT 5;


                IF Lock_Mode = 1 and v_rl_lock_mode not in (3)
                THEN                                                           -- SHARED
                    update resource_locks
                        set rl_lock_mode=Lock_Mode where rl_id=Lock_ID
                        returning rl_id into v_rl_id;

                ELSIF Lock_Mode = 2 and v_rl_lock_mode not in (2,3)
                THEN                                                           -- WX
                    update resource_locks
                        set rl_lock_mode=Lock_Mode where rl_id=Lock_ID
                        returning rl_id into v_rl_id;

                ELSIF Lock_Mode = 3 and v_rl_lock_mode not in (1,2,3)
                THEN                                                           -- FX
                    update resource_locks
                        set rl_lock_mode=Lock_Mode where rl_id=Lock_ID
                        returning rl_id into v_rl_id;

                ELSIF Lock_Mode not in (1,2,3)
                THEN
                    raise_application_error (-20001,'Incorrect LockMode value supplied! Please use 1 for SHARED, 2 for WX and 3 for FX.');

                ELSE
                    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Lock not acquired!');
                END IF;

                --dbms_lock.sleep(10);
                DELETE resource_locks WHERE rl_id=v_rl_id_system;  --remove "system" lock
                Lock_ID:=v_rl_id;
                COMMIT;
                EXIT;

            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, '"System lock '||v_rl_id||' detected. Retrying :'||to_char(i));
                    --dbms_lock.sleep(0.25); -- TODO: to use a sleep routine after granting the proper rights
                    ROLLBACK TO acq_lock_trans;
                 WHEN OTHERS THEN
                    ROLLBACK WORK;
                    RAISE;
            END;

         END LOOP;
    EXCEPTION
       WHEN DUP_VAL_ON_INDEX THEN
            L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Lock not acquired due to timeout.');
            ROLLBACK WORK;
       WHEN resource_busy_timeout then
            L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Lock not acquired due to timeout.');
            ROLLBACK WORK;
       WHEN OTHERS THEN
            ROLLBACK WORK;
            RAISE;
    END Change_Lock;

  PROCEDURE ReleaseOrphanLocks(ReleaseResult OUT INT
                              ,ResourceIds   OUT TABLETYPE_NUMBER) AS
    tid              varchar2(50);
    v_handle         varchar2(128);
    v_status         number;
    v_released_locks integer;
    v_undo_ddl_rec   TABLETYPE_NUMBER;
    v_undo_ddl_count integer;
  BEGIN

    -- get the lock
    dbms_lock.allocate_unique('release_orphan_locks', v_handle);

    LOOP
      v_status := dbms_lock.request(v_handle, release_on_commit => TRUE);
      EXIT WHEN v_status = 0;
    END LOOP;

    tid := dbms_transaction.local_transaction_id(true);

    -- insert the transaction into a GTT
    insert into app_lock
      (appl_transaction_id)
      select transaction_id from optmz$user_transactions;

    -- step 1 -- release orphan locks

    delete resource_locks
     where
    -- remove orphan locks left by completed process runs
     (exists (select 1
                from run_status_data
               where rl_run_id = rs_id
                 and rs_status = 5) or
     -- remove orphan locks left by transactions
      not exists
      (select 1
         from app_lock
        where appl_transaction_id =
              nvl(rl_transaction_id, appl_transaction_id)))
     -- remove orphan locks only if there are no records in UNDO_DDL
     and not exists (select 1
        from undo_ddl
       where case
               when rl_transaction_id is not null then
                rl_transaction_id
               else
                to_char(rl_run_id)
             end = case
               when rl_transaction_id is not null then
                ud_transaction_id
               else
                to_char(ud_run_id)
             end)
      and (RL_SERVER not LIKE 'BKP_PROC_LOCK%' AND nvl(RL_TRANSACTION_ID,'backup') not LIKE 'BKP_PROC_LOCK%');

    v_released_locks := sql%rowcount;

    delete from app_lock;

    -- step 2 -- check if there are resources locked by inactive transactions

    select rl_id bulk collect
      into v_undo_ddl_rec
      from resource_locks
      join undo_ddl
        on case
             when rl_transaction_id is not null then
              rl_transaction_id
             else
              to_char(rl_run_id)
           end = case
             when rl_transaction_id is not null then
              ud_transaction_id
             else
              to_char(ud_run_id)
           end
     where not exists
     (select 1
              from optmz$user_transactions
             where transaction_id = ud_transaction_id)
       and (exists (select 1
                      from run_status_data
                     where rl_run_id = rs_id
                       and rs_status = 5) or not exists
            (select 1
               from app_lock
              where appl_transaction_id =
                    nvl(rl_transaction_id, appl_transaction_id)));

    v_undo_ddl_count := v_undo_ddl_rec.count;

    -- step 3 -- report errors

    if v_undo_ddl_count > 0 then
      -- 3 - resources locked by inactive transactions in UNDO_DDL
      ReleaseResult := 3;
      ResourceIds := v_undo_ddl_rec;

    elsif v_released_locks > 0 then
      -- 2 - orphan locks released successfully
      ReleaseResult := 2;
    else
      -- 1 - no orphan lock
      ReleaseResult := 1;
    end if;

  END ReleaseOrphanLocks;

  PROCEDURE ReleaseOrphanLockByResName(ResourceName in varchar2, ReleaseResult out number) AS
    v_count integer;
  BEGIN

    -- insert the transaction into a GTT
    insert into app_lock
      (appl_transaction_id)
      select transaction_id from optmz$user_transactions;

    -- release the lock if it does not affect DDLs from active transactions
    delete resource_locks
     where RL_RESOURCE = ResourceName
       and
    -- remove orphan locks left by completed process runs
     (exists (select 1
                from run_status_data
               where rl_run_id = rs_id
                 and rs_status = 5) or
     -- remove orphan locks left by transactions
      not exists
      (select 1
         from app_lock
        where appl_transaction_id =
              nvl(rl_transaction_id, appl_transaction_id)))
     -- remove orphan locks only if there are no records in UNDO_DDL
     and not exists (select 1
        from undo_ddl
       where case
               when rl_transaction_id is not null then
                rl_transaction_id
               else
                to_char(rl_run_id)
             end = case
               when rl_transaction_id is not null then
                ud_transaction_id
               else
                to_char(ud_run_id)
             end);
    v_count := sql%rowcount;

    delete from app_lock;

    if v_count = 0 then
      ReleaseResult := 0;
    else
      ReleaseResult := 1;
    end if;
  END ReleaseOrphanLockByResName;

  PROCEDURE ReleaseOrphanLockByRunId(RunId in number, ReleaseResult out number) AS
    v_locks_count integer;
    v_delete_count integer;
  BEGIN
    -- count the locks held by the process
    select count(*)
      into v_locks_count
      from RESOURCE_LOCKS
     where RL_RUN_ID = RunId;

    -- insert the transaction into a GTT
    insert into app_lock
      (appl_transaction_id)
      select transaction_id from optmz$user_transactions;

    -- release the locks held by the process that do not affect DDLs from active transactions
    delete resource_locks
     where RL_RUN_ID = RunId
       and
    -- remove orphan locks left by post execution process runs
     (exists (select 1
                from run_status_data
               where rl_run_id = rs_id
                 and rs_status = 4) or
     -- remove orphan locks left by transactions
      not exists
      (select 1
         from app_lock
        where appl_transaction_id =
              nvl(rl_transaction_id, appl_transaction_id)))
     -- remove orphan locks only if there are no records in UNDO_DDL
     and not exists (select 1
        from undo_ddl
       where case
               when rl_transaction_id is not null then
                rl_transaction_id
               else
                to_char(rl_run_id)
             end = case
               when rl_transaction_id is not null then
                ud_transaction_id
               else
                to_char(ud_run_id)
             end
         and ud_status != 1);
    v_delete_count := sql%rowcount;

    delete from app_lock;

    -- check if all the locks held by the process were released
    if v_delete_count = v_locks_count then
      ReleaseResult := 1;
    else
      ReleaseResult := 0;
    end if;

  END ReleaseOrphanLockByRunId;

END app_locking;
/
