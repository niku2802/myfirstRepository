CREATE PACKAGE BODY CALCULATE_RUNNING_TOTALS AS


/* CRT_CALCULATION
-- Author    : Hrubaru, Ionut
-- Create date  :
-- Reviewer    :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
  1. 2013.01.07 - Hrubaru, Ionut - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE RUN_CRT
(  pin_input_view           IN CLOB
  ,pin_input_table          IN VARCHAR2
  ,pin_input_table_alias    IN VARCHAR2
  ,pin_output_table         IN VARCHAR2
  ,pin_input_columns        IN VARCHAR2
  ,pin_output_columns       IN VARCHAR2
  ,pin_calculations         IN TABLETYPE_DT_CRT_CALCULATION
  ,pin_output_filters       IN CLOB
  ,pin_flashback            IN NUMBER
  ,pin_period_join          IN CLOB
  ,pout_vld_results         OUT SYS_REFCURSOR
  ,pout_insert_rowcount     OUT NUMBER
)
IS
  v_ret_insert CLOB;
  v_calculations CLOB;
  v_calculated_fields VARCHAR2(500);
  v_calculated_aliases VARCHAR2(500);
  /*v_input_filter CLOB;
  v_input_filter_entity_join CLOB;
  v_input_filter_period_join CLOB;
  v_output_filter CLOB;
  v_output_filter_entity_join CLOB;
  v_output_filter_period_join CLOB;
  v_entity_table VARCHAR2(30);*/

  v_larger_timespan_tu_id NUMBER;
  v_larger_timespan_name VARCHAR2(30);
  v_larger_timespan_alias VARCHAR2(30);
  v_larger_timespan_tu_id_period NUMBER;

  v_date_inline_views CLOB;
  v_date_inline_view_case CLOB;
  v_date_inline_view_join CLOB;
  v_date_validation_query CLOB;

  /*v_period_inline_views CLOB;
  v_period_inline_view_case CLOB;
  v_period_inline_view_join CLOB;
  v_period_validation_query CLOB;

  v_scale_input VARCHAR2(30);*/
  v_scale_output VARCHAR2(30);
  v_stamp            VARCHAR2(250);
  v_input_columns CLOB;
  v_output_columns CLOB;

  v_inputs                tabletype_dt_op_inputs;
  v_inputs_cardinality    tabletype_dt_op_inputs_card;
  v_cardinal_hint         VARCHAR2(250 CHAR);
  v_input_view            CLOB;

BEGIN

  v_stamp := 'CALCULATE_RUNNING_TOTALS.RUN_CRT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_input_view),    ',pin_input_view => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_input_table),    ',pin_input_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_output_table),  ',pin_output_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_input_columns),      ',pin_input_columns => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pin_output_columns),      ',pin_output_columns => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_output_filters),    ',pin_output_filters => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_calculations),  ',pin_calculations => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_flashback),    ',v => <value>', v_stamp);
  END;


SELECT objtype_dt_op_inputs(dti.dtin_id,
                            drt.dtrt_dtout_id,
                            t.tables_physical_name,
                            pin_input_table_alias) BULK COLLECT
  INTO v_inputs
  FROM dt_inputs dti
 INNER JOIN dt_result_tables drt
    ON dti.dtin_dtout_id = drt.dtrt_dtout_id
 INNER JOIN tables t
    ON t.tables_id = drt.dtrt_tables_id
 WHERE dti.DTIN_DTOUT_ID IS NOT NULL
   AND t.tables_physical_name = pin_input_table;

data_transformation_processing.get_inputs_cardinality(v_inputs, v_inputs_cardinality);

SELECT MAX(cardinal_hint)
  INTO v_cardinal_hint
  FROM TABLE(v_inputs_cardinality);


v_input_view := REGEXP_REPLACE(pin_input_view,'SELECT','SELECT '|| CASE WHEN v_cardinal_hint IS NOT NULL THEN '/*+ ' || v_cardinal_hint || ' */' END,1,2,'i');

L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_input_view),    ',v_input_view => <value>', v_stamp);


if  pin_input_columns is not null then
    v_input_columns := pin_input_columns || ',';
end if;
if  pin_output_columns is not null then
    v_output_columns := pin_output_columns || ',';
end if ;

IF pin_calculations IS NOT NULL THEN
    -- BUILDING ALL THE CALCULATIONS
    FOR i IN pin_calculations.FIRST .. pin_calculations.LAST
    LOOP

      --is rounding necessary
      --v_scale_input := GET_FIELD_SCALE(pin_calculations(i).FIELD_TO_TOTAL);
      v_scale_output := GET_FIELD_SCALE(pin_calculations(i).RESULT_FIELD(1));

      --IF v_scale_input > v_scale_output THEN
        v_calculations := v_calculations || ' ROUND(SUM('|| pin_calculations(i).FIELD_TO_TOTAL ||') OVER (';
      --ELSE
      --  v_calculations := v_calculations || ' SUM('|| pin_calculations(i).FIELD_TO_TOTAL ||') OVER (';
      --END IF;

      IF pin_calculations(i).GROUPING_COLUMNS IS NOT NULL THEN
        v_calculations := v_calculations ||
        ' PARTITION BY '
        || pin_calculations(i).GROUPING_COLUMNS ||
        ' ';
      END IF;

       --build inline views in case we have larger timespan option selected
      IF pin_calculations(i).LARGER_TIME_SPAN IS NOT NULL THEN
          v_larger_timespan_tu_id := pin_calculations(i).LARGER_TIME_SPAN.ID;
          v_larger_timespan_name := pin_calculations(i).LARGER_TIME_SPAN.NAME;
          v_larger_timespan_alias := pin_calculations(i).LARGER_TIME_SPAN.ALIAS;
          --larger time span is Day
          IF v_larger_timespan_tu_id = 0 THEN
             v_calculations := v_calculations || ',TRUNC(' || v_larger_timespan_alias||')';
          ELSE
            --larger time span is TimeUnit and the Field from the input is a DATE (or DATETIME) field
            IF GET_FIELD_TYPE(v_larger_timespan_name) = 3 OR GET_FIELD_TYPE(v_larger_timespan_name) = 5 THEN

              v_date_inline_views := v_date_inline_views || '
                      --get min/max start date for time unit id selected
                      TU_MINMAX'||(i)||' as ( '||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL1', pi_proc_id => null)||
                                             ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL1', pi_proc_id => null)||
                                                ' MIN(TUPR_START_DATE) sd_min, MAX(TUPR_END_DATE) ed_max FROM TU_PERIODS_RANGE WHERE TUPR_TU_ID='||v_larger_timespan_tu_id||'),
                      --get valid dates from input(min and max)
                      DT_MINMAX'||(i)||' as ( '||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL2', pi_proc_id => null)||
                                            ' select '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL2', pi_proc_id => null)||
                                                     ' TRUNC(MIN('||v_larger_timespan_alias||')) min
                                                    ,TRUNC(max('||v_larger_timespan_alias||')) max
                                                    from ('||v_input_view||') TAB,TU_MINMAX'||(i)||' where TRUNC('||v_larger_timespan_alias||') between sd_min and ed_max),
                      --get valid dates from tu_periods_range  based on valid dates from input
                      A'||(i)||' AS ( '||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL3', pi_proc_id => null)||
                                    ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL3', pi_proc_id => null)||
                                         '  TUPR_ID,TUPR_START_DATE ,TUPR_END_DATE  FROM TU_PERIODS_RANGE,dt_minmax'||(i)||' mm
                      WHERE TUPR_TU_ID = '||v_larger_timespan_tu_id||'  and TUPR_END_DATE>=mm.min and  TUPR_START_DATE<=mm.max), ' ; --
              -- v_date_join_inline_view := ' A'||(i)||';

              --build the string for failing the process when validation does not pass
              v_date_inline_view_case := v_date_inline_view_case ||
                                         ',CASE WHEN A'||(i)||'.tupr_id IS NULL AND DTIN.'||v_larger_timespan_alias||' IS NOT NULL THEN 1/0
                                         ELSE A'||(i)||'.TUPR_ID END AS RESULT_PERIOD_FIELD'||(i);
              --add tupr_id in partition by clause
              v_calculations := v_calculations || ',CASE WHEN A'||(i)||'.tupr_id IS NULL AND DTIN.'||v_larger_timespan_alias||' IS NOT NULL THEN 1/0
                                         ELSE A'||(i)||'.TUPR_ID END ';
              --join between the input and the inline view
              v_date_inline_view_join := v_date_inline_view_join ||
                              ' LEFT JOIN A'||(i)||' ON  DTIN.'||v_larger_timespan_alias||' BETWEEN A'||(i)||'.TUPR_START_DATE AND A'||(i)||'.TUPR_END_DATE';
              --query fired in case validation that we don't have a corresponding period for each date from the input date field
              v_date_validation_query := v_date_validation_query || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL4', pi_proc_id => null)||
                                      ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL4', pi_proc_id => null)||' DISTINCT '
                                      || v_larger_timespan_alias || ' AS DATE_NOT_FOUND, NULL AS PERIOD_NOT_FOUND, '''
                                      || GET_FIELD_NAME(v_larger_timespan_name) || ''' AS INPUT_FIELD_NAME
                                   ,''' || GET_FIELD_NAME(pin_calculations(i).RESULT_FIELD(1)) || ''' AS RESULT_FIELD
                                   , ' || pin_calculations(i).LARGER_TIME_SPAN.ID ||' AS LARGER_TU_ID
                                      FROM ( '|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL5', pi_proc_id => null)||
                                           ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL5', pi_proc_id => null)||
                                               ' * FROM (' || v_input_view || ') TAB) DTIN
                                      WHERE NOT EXISTS ( '|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL6', pi_proc_id => null)||
                                                ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL6', pi_proc_id => null)||
                                                '       1 FROM ('|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL7', pi_proc_id => null)||
                                                                ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL7', pi_proc_id => null)||
                                                                      ' * FROM TU_PERIODS_RANGE ) TUPR --AS OF SCN ' ||pin_flashback|| '
                                                WHERE TUPR.TUPR_TU_ID = '||v_larger_timespan_tu_id ||'
                                                AND TRUNC(DTIN.'||v_larger_timespan_alias||') BETWEEN TUPR.TUPR_START_DATE AND TUPR.TUPR_END_DATE)
                                                AND DTIN.'||v_larger_timespan_alias||' IS NOT NULL and rownum<=1000
                                      UNION ALL ' ;
            END IF;

            --larger time span is TimeUnit and the Field from the input is a PERIOD field
            IF GET_FIELD_TYPE(v_larger_timespan_name) = 8 THEN
              v_larger_timespan_tu_id_period := GET_FIELD_TU_ID(v_larger_timespan_name);
              v_date_inline_views := v_date_inline_views || '
                                tu_corr'||(i)||' as ('|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL8', pi_proc_id => null)||
                                                   ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL8', pi_proc_id => null)||
                                                        ' TUPC_CORRESPONDENCE_TYPE
                                ,TUPC_TUP_ID
                                ,TUPC_TUP_ID_CORR
                                ,TUPC_PERIOD_NUMBER
                                ,TUPC_PERIOD_NUMBER_CORR
                                ,TUPC_YEAR_OFFSET
                                ,tuc_tu_id_corr
                              FROM  TU_CORRESPONDENCE
                                INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
                              WHERE  TUC_TU_ID = '||v_larger_timespan_tu_id_period||'--month
                                AND TUC_TU_ID_CORR = '||v_larger_timespan_tu_id||' --quarter
                                ), ' ;

              --add tupr_id in partition by clause
              v_calculations := v_calculations
              || ',CASE WHEN tupr_tpc'||(i)||'.tupr_id IS NULL AND '||v_larger_timespan_alias||' IS NOT NULL THEN 1/0 ELSE tupr_tpc'||(i)||'.tupr_id END ';
              --join between the input and the inline view
              v_date_inline_view_join := v_date_inline_view_join ||
                              ' LEFT JOIN TU_PERIODS_RANGE TUPR_TP'||(i)||' ON DTIN.'||v_larger_timespan_alias||' = TUPR_TP'||(i)||'.TUPR_ID
                     LEFT JOIN tu_corr'||(i)||' ON (tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE = 1 AND TUPR_TP'||(i)||'.TUPR_TUP_ID = tu_corr'||(i)||'.TUPC_TUP_ID)
                          OR (tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_TP'||(i)||'.TUPR_PERIOD_NUMBER = tu_corr'||(i)||'.TUPC_PERIOD_NUMBER)
                     LEFT JOIN TU_PERIODS_RANGE TUPR_TPC'||(i)||' ON ((tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE = 1 AND tu_corr'||(i)||'.TUPC_TUP_ID_CORR = TUPR_TPC'||(i)||'.TUPR_TUP_ID)
                          OR (tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_TPC'||(i)||'.TUPR_TU_ID = '||v_larger_timespan_tu_id||'--quarter
                          AND tu_corr'||(i)||'.TUPC_PERIOD_NUMBER_CORR = TUPR_TPC'||(i)||'.TUPR_PERIOD_NUMBER))
                          AND CASE WHEN tu_corr'||(i)||'.TUPC_YEAR_OFFSET = 1 THEN TUPR_TP'||(i)||'.TUPR_YEAR - 1
                          WHEN tu_corr'||(i)||'.TUPC_YEAR_OFFSET = 2 THEN TUPR_TP'||(i)||'.TUPR_YEAR
                          WHEN tu_corr'||(i)||'.TUPC_YEAR_OFFSET = 3 THEN TUPR_TP'||(i)||'.TUPR_YEAR + 1
                          ELSE NULL END = TUPR_TPC'||(i)||'.TUPR_YEAR ';
               --query fired in case validation that we don't have a corresponding period for each date from the input date field
              v_date_validation_query := v_date_validation_query || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL9', pi_proc_id => null)||
                                ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL9', pi_proc_id => null)||
                                   ' DISTINCT
                                      NULL AS DATE_NOT_FOUND, TUPR_TP'||(i)||'.Tupr_Period_Range_Name AS PERIOD_NOT_FOUND,'''
                                      || GET_FIELD_NAME(v_larger_timespan_name) || ''' AS INPUT_FIELD_NAME
                                   ,''' || GET_FIELD_NAME(pin_calculations(i).RESULT_FIELD(1)) || ''' AS RESULT_FIELD
                                   , ' || pin_calculations(i).LARGER_TIME_SPAN.ID ||' AS LARGER_TU_ID
                                      FROM (' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL10', pi_proc_id => null)||
                                           ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL10', pi_proc_id => null)||
                                             ' * FROM (' || v_input_view || ') TAB) DTIN
                                       LEFT JOIN TU_PERIODS_RANGE TUPR_TP'||(i)||' ON DTIN.'||v_larger_timespan_alias||' = TUPR_TP'||(i)||'.TUPR_ID
                                LEFT JOIN (' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL11', pi_proc_id => null)||
                                          ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL11', pi_proc_id => null)||
                                          '  TUPC_CORRESPONDENCE_TYPE
                                                          ,TUPC_TUP_ID
                                                          ,TUPC_TUP_ID_CORR
                                                          ,TUPC_PERIOD_NUMBER
                                                          ,TUPC_PERIOD_NUMBER_CORR
                                                          ,TUPC_YEAR_OFFSET
                                                          ,tuc_tu_id_corr
                                                        FROM  TU_CORRESPONDENCE
                                                          INNER JOIN TU_PERIODS_CORRESPONDENCE ON TUC_ID = TUPC_TUC_ID
                                                        WHERE  TUC_TU_ID = '||v_larger_timespan_tu_id_period||'--month
                                                        AND TUC_TU_ID_CORR = '||v_larger_timespan_tu_id||' --quarter
                                                          ) tu_corr'||(i)||'
                                                   ON (tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE = 1 AND TUPR_TP'||(i)||'.TUPR_TUP_ID = tu_corr'||(i)||'.TUPC_TUP_ID)
                                                        OR (tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_TP'||(i)||'.TUPR_PERIOD_NUMBER = tu_corr'||(i)||'.TUPC_PERIOD_NUMBER)
                                                   LEFT JOIN TU_PERIODS_RANGE TUPR_TPC'||(i)||' ON ((tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE = 1 AND tu_corr'||(i)||'.TUPC_TUP_ID_CORR = TUPR_TPC'||(i)||'.TUPR_TUP_ID)
                                                   OR (tu_corr'||(i)||'.TUPC_CORRESPONDENCE_TYPE <> 1 AND TUPR_TPC'||(i)||'.TUPR_TU_ID = '||v_larger_timespan_tu_id||'--quarter
                                                        AND tu_corr'||(i)||'.TUPC_PERIOD_NUMBER_CORR = TUPR_TPC'||(i)||'.TUPR_PERIOD_NUMBER))
                                                        AND CASE WHEN tu_corr'||(i)||'.TUPC_YEAR_OFFSET = 1 THEN TUPR_TP'||(i)||'.TUPR_YEAR - 1
                                                        WHEN tu_corr'||(i)||'.TUPC_YEAR_OFFSET = 2 THEN TUPR_TP'||(i)||'.TUPR_YEAR
                                                        WHEN tu_corr'||(i)||'.TUPC_YEAR_OFFSET = 3 THEN TUPR_TP'||(i)||'.TUPR_YEAR + 1
                                                        ELSE NULL END = TUPR_TPC'||(i)||'.TUPR_YEAR
                                                        WHERE tupr_tpc'||(i)||'.tupr_id IS NULL
                                                        AND DTIN.'||v_larger_timespan_alias||' IS NOT NULL AND rownum<=1000
                                                                    UNION ALL ' ;

             END IF;

          END IF;
       END IF;

      --columns to order by
      IF pin_calculations(i).ORDERING_COLUMNS IS NOT NULL THEN
            v_calculations := v_calculations ||
            ' ORDER BY '
            || pin_calculations(i).ORDERING_COLUMNS;
      END IF;

      --IF v_scale_input > v_scale_output THEN
        v_calculations := v_calculations ||'),'||v_scale_output||' ) AS '|| pin_calculations(i).RESULT_FIELD(2) ||', ';
        --v_calculations := v_calculations ||') AS '|| pin_calculations(i).RESULT_FIELD(2) ||', ';
      --ELSE
      --  v_calculations := v_calculations ||') AS '|| pin_calculations(i).RESULT_FIELD(2) ||', ';
      --END IF;


      --v_calculations := v_calculations ||') AS '|| pin_calculations(i).RESULT_FIELD(2) ||', ';

      --GET ALSO THE RESULT FIELD NAME SINCE IT NEEDS TO BE PUT IN THE VALUES CLAUSE OF THE INSERT STATEMENT
      v_calculated_fields := v_calculated_fields || pin_calculations(i).RESULT_FIELD(1) ||', ';
      --GET ALSO THE RESULT FIELD ALIAS NAME SINCE IT NEEDS TO BE SELECTED IN THE OUTER SELECT
      v_calculated_aliases := v_calculated_aliases || pin_calculations(i).RESULT_FIELD(2) ||', ';
    END LOOP;

      --get rid of last comma
      v_calculations := RTRIM(TRIM(v_calculations), ',');
      v_calculated_fields := RTRIM(TRIM(v_calculated_fields), ',');
      v_calculated_aliases := RTRIM(TRIM(v_calculated_aliases), ',');
      IF v_date_validation_query IS NOT NULL THEN
        v_date_validation_query := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL12', pi_proc_id => null)||
                                 ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL12', pi_proc_id => null)||
                                    ' DISTINCT * FROM ('|| RTRIM(TRIM(v_date_validation_query), 'UNION ALL') ||') VLD';
      END IF;

      IF  v_date_inline_views IS NOT NULL THEN
        v_date_inline_views   := ' WITH ' || RTRIM(TRIM(v_date_inline_views), ',');
      END IF;
   /*
      --handle the filter parameters
    IF pin_filters(1) IS NOT NULL THEN
      v_input_filter := ' WHERE ' || pin_filters(1).WHERE_CLAUSE;
      IF pin_filters(1).FILTER_ENTITIES IS NOT NULL THEN
        FOR i IN pin_filters(1).FILTER_ENTITIES.FIRST .. pin_filters(1).FILTER_ENTITIES.LAST LOOP
            v_entity_table := GET_TABLE_NAME_BY_ENTITY_ID(pin_filters(1).FILTER_ENTITIES(i));
            v_input_filter_entity_join := v_input_filter_entity_join || ' INNER JOIN ' || v_entity_table || ' E'||pin_filters(1).FILTER_ENTITIES(i)
                                       || ' ON DTIN.E'|| pin_filters(1).FILTER_ENTITIES(i) || '=E'||pin_filters(1).FILTER_ENTITIES(i)||'.E_INTERNAL_ID';
        END LOOP;
      END IF;
      IF pin_filters(1).FILTER_PERIODS IS NOT NULL THEN
        FOR i IN pin_filters(1).FILTER_PERIODS.FIRST .. pin_filters(1).FILTER_PERIODS.LAST LOOP
            v_input_filter_period_join := v_input_filter_period_join || ' LEFT JOIN TU_PERIODS_RANGE F' ||pin_filters(1).FILTER_PERIODS(i)
                                          || ' ON DTIN.F'||pin_filters(1).FILTER_PERIODS(i)||'=F'||pin_filters(1).FILTER_PERIODS(i)||'.TUPR_ID' ;
        END LOOP;
      END IF;
    END IF;

    IF pin_filters(2) IS NOT NULL THEN
      v_output_filter := ' WHERE ' || pin_filters(2).WHERE_CLAUSE;
      IF pin_filters(2).FILTER_ENTITIES IS NOT NULL THEN
        FOR i IN pin_filters(2).FILTER_ENTITIES.FIRST .. pin_filters(2).FILTER_ENTITIES.LAST LOOP
            v_entity_table := GET_TABLE_NAME_BY_ENTITY_ID(pin_filters(2).FILTER_ENTITIES(i));
            v_output_filter_entity_join := v_output_filter_entity_join || ' INNER JOIN ' || v_entity_table || ' E'||pin_filters(2).FILTER_ENTITIES(i)
                                       || ' ON DTOUT.E'|| pin_filters(2).FILTER_ENTITIES(i) || '=E'||pin_filters(2).FILTER_ENTITIES(i)||'.E_INTERNAL_ID';
        END LOOP;
      END IF;
      IF pin_filters(2).FILTER_PERIODS IS NOT NULL THEN
        FOR i IN pin_filters(2).FILTER_PERIODS.FIRST .. pin_filters(2).FILTER_PERIODS.LAST LOOP
            v_output_filter_period_join := v_output_filter_period_join || ' LEFT JOIN TU_PERIODS_RANGE F' ||pin_filters(2).FILTER_PERIODS(i)
                                          || ' ON DTIN.F'||pin_filters(2).FILTER_PERIODS(i)||'=F'||pin_filters(2).FILTER_PERIODS(2)||'.TUPR_ID' ;
        END LOOP;
      END IF;
    END IF;
    */
    /*
    v_input_filter_entity_join := RTRIM(TRIM(v_input_filter_entity_join), 'INNER JOIN');
    v_input_filter_period_join := RTRIM(TRIM(v_input_filter_period_join), 'LEFT JOIN');
    v_output_filter_entity_join := RTRIM(TRIM(v_output_filter_entity_join), 'INNER JOIN');
    v_output_filter_period_join := RTRIM(TRIM(v_output_filter_period_join), 'LEFT JOIN');
    */
    -- FINAL INSERT TO BE PERFORMED ON OUTPUT TABLE
    v_ret_insert := '
    BEGIN '|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_INS1', pi_proc_id => null)||
        ' INSERT INTO '|| COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_INS1', pi_proc_id => null)
        || ' '|| pin_output_table ||
        ' ('
        || v_output_columns || v_calculated_fields || ', ROW_IDENTIFIER, ROW_VERSION' ||
        ') '
        ||v_date_inline_views||' ' ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL13', pi_proc_id => null)||
        ' SELECT '|| COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL13', pi_proc_id => null)||' '||
        v_input_columns|| v_calculated_aliases ||',' ||pin_output_table||'_ROW_IDENTIFIER_SEQ.nextval,0
        FROM
        ( '|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL14', pi_proc_id => null)||
        ' SELECT ' || COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL14', pi_proc_id => null)
        || ' DTIN.*' || ',' || v_calculations || v_date_inline_view_case
        || ' FROM (' || v_input_view
        || ') DTIN '
        || v_date_inline_view_join
    --    || v_input_filter_entity_join  || ' '
    --    || v_input_filter_period_join  || ' '
    --    || v_input_filter
        || ' ) DTOUT ' || pin_period_join
        || pin_output_filters || ';'
    --   || v_output_filter_entity_join || ' '
    --    || v_output_filter_period_join || ' '
    --    || v_output_filter;
        || ' :SQLROWCNT := SQL%ROWCOUNT;
        END; ';

ELSE
    v_ret_insert := '
    BEGIN '|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_INS1', pi_proc_id => null)||
        ' INSERT INTO '|| COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_INS1', pi_proc_id => null)
        || ' '|| pin_output_table ||
        ' ('
        || pin_output_columns || CASE WHEN pin_output_columns IS NOT NULL THEN ',' END || ' ROW_IDENTIFIER, ROW_VERSION' ||
        ')'|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL15', pi_proc_id => null)||
        ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL15', pi_proc_id => null)||' '||
           pin_input_columns  || CASE WHEN pin_input_columns IS NOT NULL THEN ',' END ||pin_output_table||'_ROW_IDENTIFIER_SEQ.nextval,0
        FROM
        ( '|| COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL16', pi_proc_id => null)||
        ' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'CALCULATE_RUNNING_TOTALS', pi_hint_id=> 'CRT_SEL16', pi_proc_id => null)
        || ' DTIN.*'
        || ' FROM (' || v_input_view
        || ') DTIN '
    --    || v_input_filter_entity_join  || ' '
    --    || v_input_filter_period_join  || ' '
    --    || v_input_filter
        || ' ) DTOUT ' || pin_period_join
        || pin_output_filters || ';'
    --   || v_output_filter_entity_join || ' '
    --    || v_output_filter_period_join || ' '
    --    || v_output_filter;
        || ' :SQLROWCNT := SQL%ROWCOUNT;
        END; ';

END IF;

  -- EXECUTE THE QUERY
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_ret_insert), 'v_ret_insert := <value>;', v_stamp);
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_date_validation_query), 'v_date_validation_query := <value>;', v_stamp);


  -- log session stats
  COMMONS_PROCESSING.EXEC_START_PROC_TRANSACTION();

  EXECUTE IMMEDIATE v_ret_insert USING OUT pout_insert_rowcount;

  -- log session stats
  COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION();

  OPEN pout_vld_results FOR
  SELECT CAST(NULL AS VARCHAR2(50)) DATE_PERIOD_NOT_FOUND
  ,CAST(NULL AS VARCHAR2(50)) FIELD_NAME
  FROM dual
        WHERE 1 = 0;


EXCEPTION

  WHEN ZERO_DIVIDE THEN

      -- log session stats
     COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION();

     --   ROLLBACK;
     OPEN pout_vld_results FOR v_date_validation_query;

--    raise_application_error(-20001, SUBSTR(SQLERRM, 1, 1000));
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR,'',SQLCODE,SQLERRM);


  WHEN OTHERS THEN

     -- log session stats
     COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION();
     RAISE;

END RUN_CRT;

FUNCTION GET_TABLE_NAME_BY_ENTITY_ID
(  pin_entity_id IN NUMBER
) RETURN VARCHAR2
IS
  v_tab VARCHAR2(200);
BEGIN
  SELECT TABLES_PHYSICAL_NAME
  INTO v_tab
  FROM TABLES T INNER JOIN ENTITIES E ON T.TABLES_ID = E.ENTITY_TABLES_ID
  WHERE E.ENTITY_ID = pin_entity_id;

  RETURN v_tab;
END GET_TABLE_NAME_BY_ENTITY_ID;

FUNCTION GET_FIELD_TYPE
(  pin_field_name IN VARCHAR2
) RETURN NUMBER
IS
  v_type NUMBER;
BEGIN
  SELECT FLD_DATA_TYPE
  INTO v_type
  FROM FIELDS F
  WHERE F.FLD_COLUMN_NAME = pin_field_name;

  RETURN v_type;
END GET_FIELD_TYPE;

FUNCTION GET_FIELD_NAME
(  pin_field_name IN VARCHAR2
) RETURN VARCHAR2
IS
  v_name VARCHAR2(50);
BEGIN
  SELECT FLD_BUSINESS_NAME
  INTO v_name
  FROM FIELDS F
  WHERE F.FLD_COLUMN_NAME = pin_field_name;

  RETURN v_name;
END GET_FIELD_NAME;

FUNCTION GET_FIELD_TU_ID
(  pin_field_name IN VARCHAR2
) RETURN NUMBER
IS
  v_tu_id NUMBER;
BEGIN
  SELECT FLD_TIMEUNIT
  INTO v_tu_id
  FROM FIELDS F
  WHERE F.FLD_COLUMN_NAME = pin_field_name;

  RETURN v_tu_id;
END GET_FIELD_TU_ID;

FUNCTION GET_FIELD_SCALE
(    pin_field_name IN VARCHAR2
) RETURN NUMBER
IS
    v_scale NUMBER;
BEGIN
    SELECT FLD_LENGTH
    INTO v_scale
    FROM FIELDS F
    WHERE F.FLD_COLUMN_NAME = pin_field_name;

    RETURN v_scale;
END GET_FIELD_SCALE;

END CALCULATE_RUNNING_TOTALS;
/
