CREATE PACKAGE app_locking AS
/******************************************************************************
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.

 Product:       commons
 Module:        appframework
 Requester:     Petru Obreja
 Author:        Victor Homeuca
 Create Date:   September 22nd, 2010
 Modified:        May 23rd, 2011 - Fixed concurrency issue (changes in Acquire_Lock), added Change_Lock. In parallel, upgrade script commons_appframework_20110523_1000 was also committed.
 Reviewer:
 Review date:
 Description: Implements Application Locking
    Types of locks used:
        1. Shared (S)           - used for reading: can be aquired when other S or WX locks already exist on same ResourceID
                                                    cannot be acquired when FX lock already exists on same ResourceID
        2. WriteExclusive (WX)  - used for writing: can be aquired when other S locks already exist on same ResourceID
                                                    cannot be acquired when another WX or FX lock already exists on same ResourceID
        3. FullExclusive (FX)   - strictly exclusive: can be aquired only when no other locks exist on same ResourceID

******************************************************************************/

    TYPE ResourceLocks_MapRec IS RECORD( rl_id              resource_locks.rl_id%type
                                        ,rl_resource        resource_locks.rl_resource%type
                                        ,rl_server          resource_locks.rl_server%type
                                        ,rl_lock_mode       resource_locks.rl_lock_mode%type
                                        ,rl_run_id          resource_locks.rl_run_id%type
                                        ,rl_transaction_id  resource_locks.rl_transaction_id%type);
    TYPE ResourceLocks_Map IS TABLE OF RESOURCELOCKS_MAPREC;

    FUNCTION  GetListOfLocksByServer(Server VARCHAR2) RETURN RESOURCELOCKS_MAP PIPELINED;
        -- Returns a map of locks owned by a Tomcat server.
    PROCEDURE Acquire_Lock ( ResourceName       VARCHAR2
                            ,Server             VARCHAR2
                            ,Lock_Mode          INT           -- 1 for SHARED, 2 for WX and 3 for FX
                            ,Run_ID             NUMBER
                            ,Transaction_ID     VARCHAR2
                            ,Lock_ID        OUT INT);
        -- Tries to acquire a lock. If succesfull it will return the internal ID of the lock in Lock_ID output parameter. If lock
        --      cannot be acquired, Lock_ID will be NULL.
    PROCEDURE ReleaseLockByLockID (Lock_ID IN NUMBER);
        -- Deletes the lock identified by Lock_ID
    PROCEDURE ReleaseLockByServer (Server IN VARCHAR2);
        -- Deletes all locks acquired through a Supervisor or Tomcat server (identified by Server). Will be used during server recovery.
    PROCEDURE ReleaseLockByRunID (Run_ID IN NUMBER);
        -- Deletes the lock acquired by a process or a UI request (identified using Owner). Will be used inside process "cleanup" area
        --      for processes or by Tomcat in case of a UI request whose session terminated in a non-gracefully manner.

    PROCEDURE Change_Lock (Lock_ID         IN OUT INT
                          ,Lock_Mode       IN     INT
                          ,ResourceName    IN     VARCHAR2
                          );
       -- Tries to upgrade/downgrade a lock. If succesfull it will return the internal ID of the lock in Lock_ID output parameter. If lock
       --      cannot be acquired, Lock_ID will be NULL.

	  PROCEDURE ReleaseOrphanLocks(ReleaseResult OUT INT
                                ,ResourceIds   OUT TABLETYPE_NUMBER);
  	   -- Releases all orphan locks acquired by processes/UI actions. Will be used as part of "cleanup" process executed by a recurrent database job.
       -- ReleaseResult: 1 - no orphan lock, 2 - orphan locks released successfully, 3 - resources locked by inactive transactions in UNDO_DDL
       -- ResourceIds: RL_ID for the resources locked by inactive transactions in UNDO_DDL; has records if ReleaseResult = 3

	  PROCEDURE ReleaseOrphanLockByResName(ResourceName in varchar2, ReleaseResult out number);
  	   -- Releases a certain lock checking against active transactions
       -- ResourceName: RL_RESOURCE from RESOURCE_LOCKS
       -- ReleaseResult: 0 - fail, 1 - success

	  PROCEDURE ReleaseOrphanLockByRunId(RunId in number, ReleaseResult out number);
  	   -- Releases all locks held by a process checking against active transactions
       -- RunId: RD_ID from RUN_DATA
       -- ReleaseResult: 0 - some locks not removed, 1 - all locks removed successsfully

END app_locking;
/
