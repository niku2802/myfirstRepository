CREATE PACKAGE COMMONS_FIELDS AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type  : (SPM or CENTRAL)
-- Product        :
-- Module         : commons_fields
-- Requester      :
-- Author         : Shriniket Pimparkar
-- Reviewer       :
-- Review date    :
-- Description    : provide add functionality for FIELDS

-- Modified on    :
-- Modified By    :
-- Reviewer       :
-- Description    : Created a procedure to accept input parameters to insert values for attributes in FIELDS table .
--					Created a overloaded procedure to accept input parameters to insert values for attributes
--                  FLD_DISPLAY_THOUSAND_SEPARATOR and FLD_DISPLAY_AS_PERCENT in FIELDS table.
-- Modified on    :  28/04/2015
-- Modified By    :  Sachida Nand Tripathi
-- Reviewer       :  Maxim Rohit, Cosmin Dumitriu
-- Description    : Created a procedure RENAME_SYSTEM_FIELD to rename the system field (OF-29564)

-- ---------------------------------------------------------------------------
    -- *******************************    PUBLIC TYPES START       *******************************
    -- *******************************    PUBLIC TYPES END         *******************************

    -- *******************************    PUBLIC CURSORS START       *******************************
    -- *******************************    PUBLIC CURSORS END         *******************************

    -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
    -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

    -- *******************************    PUBLIC FUNCTIONS START       *******************************
    -- *******************************    PUBLIC FUNCTIONS END         *******************************

    -- *******************************    PUBLIC PROCEDURES START       *******************************

PROCEDURE ADD_SYSTEM_FIELDS (
          pin_FLD_BUSINESS_NAME varchar2
          ,pin_FLD_COLUMN_NAME varchar2
          ,pin_FLD_LENGTH NUMBER
          ,pin_FLD_DATA_TYPE  NUMBER
          ,pin_FLD_TIMEUNIT  NUMBER
          ,pin_FLD_BASE_FIELD NUMBER
		  ,pin_FLD_UNIQUE_INTERNAL_NAME VARCHAR2 default null
          );

PROCEDURE ADD_SYSTEM_FIELDS (
          pin_FLD_BUSINESS_NAME varchar2
          ,pin_FLD_COLUMN_NAME varchar2
          ,pin_FLD_LENGTH NUMBER
          ,pin_FLD_DATA_TYPE  NUMBER
          ,pin_FLD_TIMEUNIT  NUMBER
          ,pin_FLD_BASE_FIELD NUMBER
		  ,pin_FLD_UNIQUE_INTERNAL_NAME VARCHAR2 default null
          ,pin_FLD_DISPLAY_1000_SEPARATOR NUMBER
          ,pin_FLD_DISPLAY_AS_PERCENT NUMBER
         );

PROCEDURE RENAME_SYSTEM_FIELD (
  PI_OLD_FLD_BUSINESS_NAME IN VARCHAR2
  ,PI_NEW_FLD_BUSINESS_NAME IN VARCHAR2
  ,PI_NEW_FLD_UNQ_INTERNAL_NAME VARCHAR2 default null
  );

  PROCEDURE RENAME_SYSTEM_FIELD (
      PI_OLD_FLD_BUSINESS_NAME IN VARCHAR2
      , PI_NEW_FLD_BUSINESS_NAME IN VARCHAR2
      ,PI_NEW_FLD_UNIQUE_INTERNAL_NAM VARCHAR2 default null);

end COMMONS_FIELDS;
/
