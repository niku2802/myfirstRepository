CREATE PACKAGE BODY PAYMENT_PROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright ? 2010-2011, SPM Software LP. All rights reserved.
  -- This program belongs to SPM Software LP.  It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from SPM Software LP.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   COMPENSATION
  -- Module    :  COMPENSATION-PROCESSING
  -- Requester    :  Creoleanu, Irina
  -- Author    :  Lazarescu, Bogdan
  -- Reviewer    :  Lazar, Lucian
  -- Review date    :  20110624
  -- Description    :  package used to handle all operations for payment processing
  -- updated date: 20110706
  -- update details: throw error <<ORA-01438: value larger than specified precision allowed for this column>> for <<The integer part of the numeric values is restricted to 13>> validation
  -- updated date: 20110822
  -- update details: added support for draws, adjustments, Overrides, selected roster
  -- updated date: 20170424
  -- update details: added support for guarantee and recoverable draws on the same plan
  -- updated date: 20170606
  -- update details: replaced payment_after_draw processing with cases in adjustments select query OF-72697
  -- updated date: 20170922
  -- update details: added pin_calculate_component parameter to know when to inner join or right outer join(0-payment for total payments) the roster table
  -- updated date: 20170922
  -- update details: added pin_roster_by_component parameter to know when Roster by Component option is checked
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
  /*
  parameter list:
    pin_input_list              tabletype_input_table_list  NOT NULL :list of tables used in calculations(except lookups)
                                                   table_name   - physical table name;
                                                   from_clause  - NOT NULL for table_type in (3,4,5,6)
                                                                     a from clause will be send:
                                                                          MT_COM,MT_WEIGTH,MT_P_TARGET,MT_C_TARGET is the alias for the match_table
                                                                                      (3 comision rate,4 component weight, 5 plan target,6 component target)
                                                                          I is the alias for the input table
                                                                          R  is the alias for the roster table
                                                                          for table_type=3,6 search fields in input calculation entity fields then in roster fields
                                                                              table_type=4,5 search fields in roster fields
                                                                          Templates:
                                                                           all match fields found in input
                                                                            <alias for the match_table> ON <alias for the match_table>.<field1> = R.<field1> AND <alias for the match_table>.<field2> = R.<field2> ...
                                                                           not all match fields found in input; some are in roster
                                                                            <alias for the match_table> ON <alias for the match_table>.<field1> = I.<field1> AND <alias for the match_table>.<field2> = R.<field2> ...
                                                   where_clause - where clause that contain period filter
                                                                           NULL for 8 Detailed earnings ,9 Aggregated Earnings,10 Modified Earnings,11 Component Earnings, 13, 14 , 15
                                                   table_type   - 0 roster,1 roster with earning entity and payment entity when earning entity <> payment entity
                                                                          ,2 input, 3 comision rate match table
                                                                          ,4 component weight match table,5 plan target earning match table
                                                                          ,6 component target earning match table
                                                                          ,7 eligibility table,8 Detailed earnings
                                                                          ,9 Aggregated Earnings,10 Modified Earnings,11 Component Earnings
                                                                          ,12 commission rate input table (metric result table used in commission rate lookup)
                                                                          ,14 roster ? selected items
                                                                          ,15 roster ? selected items with earning entity and payment entity when earning entity <> payment entity
                                                                          ,16 entity table for earning entity;
                                                                          ,20 Guarantee, 21 Recoverable Draw, 22 Adjustments, 23 Overrides, 24 payment output table
                                                                          ,28 Prior Period Table
                                                                          ,29 Prior Period Table for Recoverable Draw
                                                                          ,30 entity table
                                                                          ,31 output table
                                                                          ,32 input table
                                                                          ,33 total payments table
                                                   input_number - when table_type is 2 input give a number to the input

  PIN_COMP_PRIOR_PERIOD_LIST  TABLETYPE_COMP_PERIOD_LIST     TABLE_NAME        component physical table name
                                                               PRIOR_PERIOD_IDS  list of prior periods ids
                                                               INPUT_NUMBER      component input number

  pin_current_period          number            time period id of the plan; not null
    pin_current_period_column   varchar2          physical name of the plan period column

    pin_projected_period        number            time period id of the projected run if the plan has projected period; not null if plan has projected periods
    pin_projected_period_column varchar2          physical name of the projected period column
    pin_projected               number            null - no projected, 0 - payment, 1 - projected

    pin_prior_period_ids        varchar2          list of the time period id for prior periods to subtract. If null, no subtraction is done

    pin_earn_entity_column      varchar2          physical name of the earning entity if earning entity is different than payment entity
    pin_pay_entity_column       varchar2          physical name of the payment entity
    pin_pay_attribute_columns   VARCHAR2      comma separated list with the physical name of the columns that are attribute fields in the payment roster
    pin_add_attribute_columns   VARCHAR2      comma separated list with the physical name of the columns that are additional attribute fields

    pin_apply_draws             number            null if not draws; 0 -  Guarantee; 1 - recoverable draw; 2 - both guarantee and recoverable draw
    pin_constant_draw           number            constant value of the draw if pin_apply_draws is not null; null if pin_apply_draws is 2
    pin_recoverable_prior_period number           time period id of the recoverable draw prior period - not null if recoverable draw has the option to limit the substraction;
                                                  -1 if first period and substract is to limit the substraction
    pin_entity_key               varchar2         business key of the payment entity
    pin_ver_object_id            IN NUMBER        the plan version id
    pin_0_payment                IN NUMBER        if the 0 payment option is selected
	pin_roster_by_component		 IN NUMBER			   : 0 - roster by component is NOT checked; 1 - roster by component is checked
    pin_vld_when                 IN CLOB          NULL : the output string which holds the "insert when" clauses related to validations.
    pin_vld_select               IN CLOB          NULL : the output string which holds the "select" clauses related to validations.
    pin_vld_from                 IN CLOB          NULL : the output string which holds the "from join" clauses related to validations.
    pin_vld_get_values           IN CLOB          NULL : the output string which holds the query that selects the triggered validations.
    pout_vld_results             OUT reftype_resultset : Result set :
                                                    VALIDATION_ID      NUMBER  : the id of the validation posible values 1,2,3,4,5
                                                    VALIDATION_TYPE    VARCHAR2: type of validation trigger ERROR/WARNING
                            VALIDATION_ENT_CNT NUMBER  : count of all entities that triggered the validation
                                                    VALIDATION_DETAILS TABLETYPE_CHARMAX : the business ids of all entities which have triggered this validation
                                                                                   TABLETYPE_CHARMAX("<business_id1>",...,"<business_id2>")
    pin_calculate_component		 IN NUMBER			   : 1 - calculate payment for a component; 0 - others
  */

  V_TEMP_PROC_VALIDATION_COUNT NUMBER(10);
  V_TEMP_UI_VALIDATION_CNT     NUMBER(10);
  V_TEMP_PAY_VALIDATIONS_CNT   NUMBER(10);

  V_STAMP                      VARCHAR2(200 CHAR);

  PROCEDURE CALCULATE_COMPLETE_PAYMENT(PIN_INPUT_LIST               TABLETYPE_INPUT_TABLE_LIST,
                                        PIN_CURRENT_PERIOD           NUMERIC,
                                        PIN_CURRENT_PERIOD_COLUMN    VARCHAR2,
                                        PIN_PROJECTED_PERIOD         NUMERIC,
                                        PIN_PROJECTED_PERIOD_COLUMN  VARCHAR2,
                                        PIN_PROJECTED                NUMBER,
                                        PIN_PRIOR_PERIOD_IDS         VARCHAR2,
                                        PIN_EARN_ENTITY_COLUMN       VARCHAR2,
                                        PIN_PAY_ENTITY_COLUMN        VARCHAR2,
                                        PIN_OLD_EARN_ENTITY_COLUMN   VARCHAR2,
                                        PIN_PAY_ATTRIBUTE_COLUMNS    VARCHAR2,
                                        PIN_ADD_ATTRIBUTE_COLUMNS    VARCHAR2,
                                        PIN_APPLY_DRAWS              NUMBER,
                                        PIN_CONSTANT_DRAW            NUMBER,
                                        PIN_RECOVERABLE_PRIOR_PERIOD NUMBER,
                                        PIN_ENTITY_KEY               VARCHAR2,
                                        PIN_VER_OBJECT_ID            NUMBER,
                                        PIN_COMPONENT_ID             NUMBER,
                                        PIN_0_PAYMENT                NUMBER,
										PIN_ROSTER_BY_COMPONENT		 NUMBER,
                                        PIN_TOTAL_PAYMENT            NUMBER,
                                        PIN_VLD_WHEN                 CLOB,
                                        PIN_VLD_SELECT               CLOB,
                                        PIN_VLD_FROM                 CLOB,
                                        PIN_VLD_GET_VALUES           CLOB,

                                        POUT_VLD_RESULT              OUT SYS_REFCURSOR,
                                        POUT_ROWS_IN_OUTPUT          OUT NUMBER,
                                        PIN_CALCULATE_COMPONENT      NUMBER DEFAULT 0) AS
    TYPE RTYPE_TABLE_REC IS RECORD(
      TABLE_NAME   VARCHAR2(30),
      FROM_CLAUSE  CLOB,
      WHERE_CLAUSE CLOB,
      TABLE_TYPE   NUMERIC(2),
      INPUT_NUMBER NUMERIC(10));

    C_INPUT_TABLE_LIST SYS_REFCURSOR;

    V_INPUT_TABLE_REC RTYPE_TABLE_REC;
    V_INPUT_TABLE_REC_G RTYPE_TABLE_REC;
    V_INPUT_TABLE_REC_RD RTYPE_TABLE_REC;

    V_AGG_SELECT CLOB;

    V_PRIORPP_SELECT VARCHAR2(2000);
    V_PRIORPP_FROM   CLOB;
    V_PRIORPP_TABLES VARCHAR2(2000);

    V_DRAWS_SELECT  VARCHAR2(3000);
    V_DRAWS_FROM    CLOB;
    V_DRAWSPP_TABLE VARCHAR2(2000);

    V_CONSTANT_DRAW_SQL CLOB;
    V_CONSTANT_DRAW     NUMBER;
    V_CONSTANT_DRAW_G   NUMBER;
    V_CONSTANT_DRAW_RD  NUMBER;

    V_ADJUSTMENTS_SELECT VARCHAR2(2000);
    V_ADJUSTMENTS_FROM   CLOB;

    V_OVERRIDE_SELECT VARCHAR2(2000);
    V_OVERRIDE_FROM   CLOB;

    V_SQL            CLOB;
    V_SQL_SELECT     VARCHAR2(2000);
    V_SQL_INSERT     VARCHAR2(2000);
    V_SQL_VALUES     VARCHAR2(2000);
    V_SQL_INSERT_ALL VARCHAR2(2000);

    V_ENTITY_COLUMN VARCHAR2(30);
    V_ENTITY_TABLE  VARCHAR2(30);

    V_OUTPUT_TABLE     VARCHAR2(30);
    V_INPUT_TABLE      VARCHAR2(30);
    V_PROJECTED        VARCHAR2(100);
    V_PROJECTED_ALIAS  VARCHAR2(100);
    V_PROJECTED_SELECT VARCHAR2(100);

    V_TOTAL_ROWCOUNT               NUMBER(10);
    V_TEMP_PAY_VALIDATIONS_COUNT   NUMBER(10);
    V_TEMP_UI_VALIDATION_COUNT     NUMBER(10);

    V_CHECK_IN                   VARCHAR2(250);
    V_VALIDATION_COLUMNS         VARCHAR2(2000);
    V_VALIDATION_JOINS           VARCHAR2(2000);
    V_PROC_VALIDATION_COLS       VARCHAR2(2000);
    V_PAY_VALID_COLS             VARCHAR2(2000);
    V_PAY_VALID_COLS2            VARCHAR2(2000);
    VCOL_COL_ENT_NAME_COLS TABLETYPE_NAME_MAP := TABLETYPE_NAME_MAP();
    V_ADD_ATTRIBUTE_COLUMNS    VARCHAR2(2000);
    V_ADD_ATT_VALID_COLS       VARCHAR2(2000);
    V_ADD_ATT_VALID_JOINS      VARCHAR2(2000);
    V_ADD_ATT_JOIN_COLS        VARCHAR2(2000);
    V_IS_DRAW                BOOLEAN :=FALSE;

    V_ROSTER_COLS       VARCHAR2(2000);
    V_ROSTER_TABLE      VARCHAR2(2000);
    V_ROSTER_TABLE_FROM VARCHAR2(2000);
    V_ROSTER_FOR_ATT    VARCHAR2(2000);
    V_ROSTER_TYPE       NUMBER(1); --0 = full roster (0,1), 1 = selected rows (14, 15);used for validations - if selected roster (14, 15) then the validation will run on the output

    V_CNT                NUMBER(10);
    V_VAL_NO_FALL_JOIN   VARCHAR2(2000);
    V_VAL_NO_FALL_INSERT VARCHAR2(2000);
    V_VAL_NO_FALL_SELECT VARCHAR2(50);
    V_VAL_NO_FALL_ENTITY VARCHAR2(30);
    V_COMPONENT_NUMBER   NUMBER(10);
    V_TOTAL_EARNINGS_COMP_TOTAL VARCHAR2(30);

    V_SELECT_HINT    VARCHAR2(2000);
    V_SELECT_HINT2   VARCHAR2(2000);
    V_DELETE_HINT    VARCHAR2(2000);
    V_INSERT_HINT    VARCHAR2(2000);
  BEGIN

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCOLLECTION(PIN_INPUT_LIST),
                               ',pin_input_list => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_CURRENT_PERIOD),
                               ',pin_current_period => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_CURRENT_PERIOD_COLUMN),
                               ',pin_current_period_column => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_PROJECTED_PERIOD),
                               ',pin_projected_period => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_PROJECTED_PERIOD_COLUMN),
                               ',pin_projected_period_column => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_PROJECTED),
                               ',pin_projected => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_PRIOR_PERIOD_IDS),
                               ',pin_prior_period_ids => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_EARN_ENTITY_COLUMN),
                               ',pin_earn_entity_column => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_PAY_ENTITY_COLUMN),
                               ',pin_pay_entity_column => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_OLD_EARN_ENTITY_COLUMN),
                               ',pin_old_earn_entity_column => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_PAY_ATTRIBUTE_COLUMNS),
                               ',pin_pay_attribute_columns => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ADD_ATTRIBUTE_COLUMNS),
                               ',pin_add_attribute_columns => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_APPLY_DRAWS),
                               ',pin_apply_draws => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_CONSTANT_DRAW),
                               ',pin_constant_draw => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_RECOVERABLE_PRIOR_PERIOD),
                               ',pin_recoverable_prior_period => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_ENTITY_KEY),
                               ',pin_entity_key => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTVARCHAR2(PIN_VER_OBJECT_ID),
                               ',pin_ver_object_id => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_0_PAYMENT),
                               ',pin_0_payment => <value>',
                               V_STAMP);
	  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_ROSTER_BY_COMPONENT),
                               ',pin_roster_by_component => <value>',
                               V_STAMP);
	  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_CALCULATE_COMPONENT),
                               ',pin_calculate_component => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTNUMBER(PIN_TOTAL_PAYMENT),
                               ',pin_total_payment => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PIN_VLD_WHEN),
                               ',pin_vld_when => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PIN_VLD_SELECT),
                               ',pin_vld_select => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PIN_VLD_FROM),
                               ',pin_vld_from => <value>',
                               V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(PIN_VLD_GET_VALUES),
                               ',pin_vld_get_values => <value>',
                               V_STAMP);
    END;

    --set which entity (earn or pay) to use
    IF PIN_EARN_ENTITY_COLUMN IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'Earning entity column can not be null!');
    ELSIF PIN_PAY_ENTITY_COLUMN IS NULL THEN
      V_ENTITY_COLUMN := PIN_EARN_ENTITY_COLUMN;
    ELSIF PIN_EARN_ENTITY_COLUMN = PIN_PAY_ENTITY_COLUMN THEN
      V_ENTITY_COLUMN := PIN_EARN_ENTITY_COLUMN;
    ELSE
      V_ENTITY_COLUMN := PIN_PAY_ENTITY_COLUMN;
    END IF;

    -- get the additional attributes entities and fields
    SELECT LISTAGG(CASE
                     WHEN TAB.FLD_DATA_TYPE = 1 THEN
                      '-COALESCE(UPPER(' || TAB.AA || '), CHR(0))'
                     WHEN TAB.FLD_DATA_TYPE IN (2, 6, 8) THEN
                      '-COALESCE(' || TAB.AA || ', 1E38)'
                     WHEN TAB.FLD_DATA_TYPE IN (3, 5) THEN
                      '-COALESCE(' || TAB.AA || ', TO_DATE(''01/01/1800'',''MM/DD/sYYYY''))'
           ELSE
                      '-COALESCE(' || TAB.AA || ', 1E38)'
                   END,
                   '') WITHIN GROUP(ORDER BY TAB.LVL) AS LIST,
           LISTAGG(CASE
                     WHEN TAB.FLD_DATA_TYPE = 1 THEN
                      ',UPPER(' || TAB.AA || ')'
                     ELSE
                      ',' || TAB.AA
                   END,
                   '') WITHIN GROUP(ORDER BY TAB.LVL) AS LIST1,
           LISTAGG(CASE
                     WHEN TAB.TC_COLUMN_TYPE = 1 THEN
                      ',ENT' || (TAB.LVL+1) || '.' || COMMONS.FIND_ENT_BUSINESS_KEY_BY_NAME(TAB.AA) || ' AS C' || (TAB.LVL+1)
                     ELSE
                      ',MAIN_S.' || TAB.AA || ' AS C' || (TAB.LVL+1)
                   END,
                   '') WITHIN GROUP(ORDER BY TAB.LVL) AS LIST2,
          LISTAGG(CASE
                     WHEN TAB.TC_COLUMN_TYPE = 1 THEN
                          ' LEFT OUTER JOIN ' || COMMONS.FIND_ENT_TABLE_NAME(TAB.AA) || ' ENT' || (TAB.LVL+1) || ' ON MAIN_S.' || TAB.AA || ' = ENT' || (TAB.LVL+1) || '.E_INTERNAL_ID'
                     ELSE
                      NULL
                   END,
                   '') WITHIN GROUP(ORDER BY TAB.LVL) AS LIST3
      INTO V_ADD_ATT_JOIN_COLS, V_ADD_ATTRIBUTE_COLUMNS, V_ADD_ATT_VALID_COLS, V_ADD_ATT_VALID_JOINS
      FROM (SELECT AA, MIN(FLD.FLD_DATA_TYPE) FLD_DATA_TYPE, MIN(TC.TC_COLUMN_TYPE) TC_COLUMN_TYPE, BB.LVL
              FROM (SELECT REGEXP_SUBSTR(PIN_ADD_ATTRIBUTE_COLUMNS,
                                         '[^ ,]+',
                                         1,
                                         LEVEL) AA,
                           LEVEL AS LVL
                      FROM DUAL
                    CONNECT BY REGEXP_SUBSTR(PIN_ADD_ATTRIBUTE_COLUMNS,
                                             '[^ ,]+',
                                             1,
                                             LEVEL) IS NOT NULL) BB
             INNER JOIN TABLE_COLUMNS TC
                ON BB.AA = TC.TC_PHYSICAL_NAME
              LEFT JOIN fields fld
                ON fld.fld_id = tc.tc_fld_id
             GROUP BY BB.AA, BB.LVL) TAB;

    --build string for projected column and projected time unit
    V_PROJECTED := (CASE
                     WHEN PIN_PROJECTED_PERIOD IS NOT NULL THEN
                      ', ' || PIN_PROJECTED_PERIOD_COLUMN || ', PROJECTED'
                     ELSE
                      ''
                   END);
    V_PROJECTED_ALIAS := (CASE
                           WHEN PIN_PROJECTED_PERIOD IS NOT NULL THEN
                            ', S.' || PIN_PROJECTED_PERIOD_COLUMN ||
                            ', S.PROJECTED'
                           ELSE
                            ''
                         END);
    V_PROJECTED_SELECT := (CASE
                            WHEN PIN_PROJECTED_PERIOD IS NOT NULL THEN
                             ', MAIN_S.' || PIN_PROJECTED_PERIOD_COLUMN ||
                             ', MAIN_S.PROJECTED'
                            ELSE
                             ''
                          END);

    -- build roster table; load roster table information
    IF PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN THEN
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE IN (1, 15);
    ELSE
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE IN (0, 14);
    END IF;

    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'SELECT_ROSTER' || PIN_COMPONENT_ID, pin_ver_object_id);
    --
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'SELECT_ROSTER' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'SELECT_ROSTER', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

    IF PIN_TOTAL_PAYMENT = 1 THEN
      V_ROSTER_COLS := PIN_EARN_ENTITY_COLUMN;
    ELSE
      SELECT LISTAGG(COLUMN_NAME, ',') WITHIN GROUP(ORDER BY NULL)
        INTO V_ROSTER_COLS
        FROM USER_TAB_COLS UTC
       WHERE UTC.TABLE_NAME = V_INPUT_TABLE_REC.TABLE_NAME
         AND COLUMN_NAME NOT IN (NVL(PIN_OLD_EARN_ENTITY_COLUMN, CASE WHEN PIN_PAY_ENTITY_COLUMN IS NULL THEN CHR(0) ELSE PIN_EARN_ENTITY_COLUMN END), 'PROCESSED_DATE_TIME', 'ROW_VERSION', 'ROW_IDENTIFIER')
         AND COLUMN_NAME NOT LIKE 'SYS%';
    END IF;

    V_ROSTER_TABLE := ' (' || v_select_hint ||
                        CASE WHEN (INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_EARN_ENTITY_COLUMN || ',') > 0
                          OR (PIN_OLD_EARN_ENTITY_COLUMN IS NULL AND PIN_0_PAYMENT = 0)
                          OR PIN_EARN_ENTITY_COLUMN = PIN_OLD_EARN_ENTITY_COLUMN)
                          OR
                          (PIN_0_PAYMENT = 1 AND
                              ((PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN OR PIN_OLD_EARN_ENTITY_COLUMN != PIN_EARN_ENTITY_COLUMN)
                                AND
                                INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_EARN_ENTITY_COLUMN || ',') > 0
                                )
                          OR
                               (PIN_0_PAYMENT = 1
                               AND PIN_OLD_EARN_ENTITY_COLUMN IS NULL
                               AND INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_EARN_ENTITY_COLUMN || ',') > 0))
                           OR INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_OLD_EARN_ENTITY_COLUMN || ',') > 0
                          THEN ' * '
                        ELSE ' DISTINCT ' || V_ROSTER_COLS END ||
                        ' FROM ' || V_INPUT_TABLE_REC.TABLE_NAME || CASE
                        WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NOT NULL THEN
                         ' R WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                        ELSE
                         NULL
                      END || ')
    ';
    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'EARN_PAY_ENTITY' || PIN_COMPONENT_ID, pin_ver_object_id);
    --
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'EARN_PAY_ENTITY' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'EARN_PAY_ENTITY', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

    IF (PIN_PAY_ENTITY_COLUMN IS NOT NULL AND
       PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN) THEN
      V_ROSTER_FOR_ATT := ' (' || v_select_hint || ' ' || V_ENTITY_COLUMN || CASE
                            WHEN PIN_PAY_ATTRIBUTE_COLUMNS IS NOT NULL THEN
                             ',' || PIN_PAY_ATTRIBUTE_COLUMNS
                            ELSE
                             NULL
                          END || '
          FROM ' || V_INPUT_TABLE_REC.TABLE_NAME || CASE
                            WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NOT NULL THEN
                             ' R WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                            ELSE
                             NULL
                          END || '
          GROUP BY ' || V_ENTITY_COLUMN || CASE
                            WHEN PIN_PAY_ATTRIBUTE_COLUMNS IS NOT NULL THEN
                             ',' || RTRIM(regexp_replace(PIN_PAY_ATTRIBUTE_COLUMNS || ',' , '\)[^,]+,' , '),'),',')
                            ELSE
                             NULL
                          END || ')
    ';
    END IF;

    V_ROSTER_TABLE_FROM := (CASE
                             WHEN V_INPUT_TABLE_REC.FROM_CLAUSE IS NOT NULL THEN
                              V_INPUT_TABLE_REC.FROM_CLAUSE
                             ELSE
                              ''
                           END);
    V_ROSTER_TYPE := (CASE
                       WHEN V_INPUT_TABLE_REC.TABLE_TYPE IN (0, 1) THEN
                        0
                       ELSE
                        1
                     END);

    -- get the output table
    BEGIN
      --get components table
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 31;
       -- get the component number
       v_component_number := v_input_Table_rec.INPUT_NUMBER;
       -- get the column for the earnings
       V_TOTAL_EARNINGS_COMP_TOTAL := 'TOTAL_EARNINGS';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- get the payments table
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 24;
       -- get the column for the earnings
       V_TOTAL_EARNINGS_COMP_TOTAL := 'COMPONENT_TOTAL';
    END;

    V_INPUT_TABLE := v_input_table_rec.TABLE_NAME;


    -- get the output table
    BEGIN
      --get components table
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 31;
       -- get the component number
       v_component_number := v_input_Table_rec.INPUT_NUMBER;
       -- get the column for the earnings
       V_TOTAL_EARNINGS_COMP_TOTAL := 'TOTAL_EARNINGS';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- get the payments table

      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 24;
       -- get the column for the earnings
       V_TOTAL_EARNINGS_COMP_TOTAL := 'COMPONENT_TOTAL';
    END;

    v_output_table := v_input_table_rec.TABLE_NAME;

    --get the entity table
    SELECT *
      INTO V_INPUT_TABLE_REC
      FROM TABLE(PIN_INPUT_LIST)
     WHERE TABLE_TYPE = 16;
    V_ENTITY_TABLE := V_INPUT_TABLE_REC.TABLE_NAME;

    /***<<<aggregate component earning***/
    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'COMP_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id);
    --
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'COMP_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'COMP_SELECT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

    --build insert and select for insert
    V_SQL_SELECT := ' ' || v_select_hint || ' 0 AS ROW_VERSION
                         , MAIN_S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',MAIN_S.') || '
                         , MAIN_S.' ||
                    PIN_CURRENT_PERIOD_COLUMN || '
                           ' || V_PROJECTED_SELECT ||
                    CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                         ELSE ' , CAST(MAIN_S.' || V_TOTAL_EARNINGS_COMP_TOTAL || ' AS NUMBER' ||
                                COMMONS.FIELD_PRECISION_AND_SCALE(V_TOTAL_EARNINGS_COMP_TOTAL) ||
                                ') AS MAIN_S_' || V_TOTAL_EARNINGS_COMP_TOTAL
                    END || '
                         , COALESCE(CAST(MAIN_S.PAYMENT_DUE AS NUMBER' ||
                    COMMONS.FIELD_PRECISION_AND_SCALE('PAYMENT_DUE') ||
                    '),0) AS MAIN_S_PAYMENT_DUE ';

    V_SQL_INSERT := ' ROW_IDENTIFIER, ROW_VERSION, ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS || ', ' ||
                    PIN_CURRENT_PERIOD_COLUMN || V_PROJECTED ||
                    CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                         ELSE ', ' || V_TOTAL_EARNINGS_COMP_TOTAL
                    END
                    || ', ' || case WHEN v_component_number IS null THEN 'PAYMENT_DUE' ELSE 'PRIOR_PERIOD_PAYMENTS' END;

    V_SQL_VALUES := ' ROW_IDENTIFIER, ROW_VERSION, ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS || ', ' ||
                    PIN_CURRENT_PERIOD_COLUMN || V_PROJECTED ||
                    CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                         ELSE ', MAIN_S_' || V_TOTAL_EARNINGS_COMP_TOTAL
                    END
                    || ', ' || case WHEN v_component_number IS null THEN 'MAIN_S_PAYMENT_DUE' ELSE 'MAIN_S_PRIOR_PERIOD_PAYMENTS' END;
    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'AGG_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id);
    --
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'AGG_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'AGG_SELECT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));


    IF (pin_0_payment = 0) THEN

       V_AGG_SELECT := v_select_hint || ' R.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.');

    ELSE

       V_AGG_SELECT := v_select_hint || ' R.' || V_ENTITY_COLUMN ||
                   CASE
                      WHEN PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN OR PIN_OLD_EARN_ENTITY_COLUMN != PIN_EARN_ENTITY_COLUMN THEN
                       REPLACE(REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.'), 'S.' || NVL(PIN_OLD_EARN_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN), 'R.' || NVL(PIN_OLD_EARN_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN))
                      ELSE
                       REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.')
                    END;

    END IF;


    v_agg_select := v_agg_select || '
                , ' || PIN_CURRENT_PERIOD || ' AS ' ||
                    PIN_CURRENT_PERIOD_COLUMN || '
                  ' || (CASE
                      WHEN PIN_PROJECTED_PERIOD IS NOT NULL THEN
                       ', ' || PIN_PROJECTED_PERIOD || ' AS ' ||
                       PIN_PROJECTED_PERIOD_COLUMN
                      ELSE
                       ''
                    END) || '
                  ' || (CASE
                      WHEN PIN_PROJECTED_PERIOD IS NOT NULL THEN
                       ', ' || PIN_PROJECTED || ' AS PROJECTED'
                      ELSE
                       ''
                    END) ||
                    CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                         ELSE ', ' || CASE WHEN pin_0_payment = 0 THEN '  NVL(SUM(COMPONENT_EARNINGS),0) ' ELSE ' COALESCE(SUM(COMPONENT_EARNINGS), 0) ' END || ' AS ' || V_TOTAL_EARNINGS_COMP_TOTAL
                    END  || '
                , ' || CASE WHEN pin_0_payment = 0 THEN '  NVL(SUM(COMPONENT_EARNINGS),0) ' ELSE ' COALESCE(SUM(COMPONENT_EARNINGS), 0) ' END || ' AS PAYMENT_DUE
                FROM (
                ';
    -- loop through input tables
    OPEN C_INPUT_TABLE_LIST FOR
      SELECT * FROM TABLE(PIN_INPUT_LIST) WHERE TABLE_TYPE = 2;
    LOOP
      FETCH C_INPUT_TABLE_LIST
        INTO V_INPUT_TABLE_REC;
      EXIT WHEN C_INPUT_TABLE_LIST%NOTFOUND;
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'AGG' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'AGG' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'AGG' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_AGG_SELECT := V_AGG_SELECT || ' ' || v_select_hint || ' ' ||
                      CASE WHEN INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_EARN_ENTITY_COLUMN || ',') > 0 THEN substr(PIN_ADD_ATTRIBUTE_COLUMNS, 2)
                        ELSE PIN_EARN_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS
                      END ||
                      (CASE
                        WHEN PIN_PAY_ENTITY_COLUMN IS NOT NULL AND
                             PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN THEN
                             ',' || PIN_PAY_ENTITY_COLUMN
                        ELSE
                         ''
                      END) || ',' || CASE WHEN (PIN_TOTAL_PAYMENT = 1) THEN 'PAYMENT_DUE AS '
                                          WHEN (V_COMPONENT_NUMBER IS NULL AND V_INPUT_TABLE_REC.FROM_CLAUSE IS NOT NULL) THEN 'CURRENT_PERIOD_PAYMENT AS '
                                          ELSE ''
                                     END || 'COMPONENT_EARNINGS
                                    FROM ' ||



                      V_INPUT_TABLE_REC.TABLE_NAME
                      || CASE WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE  IS NOT NULL THEN
                               ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                         ELSE ''
                         END
                      || '
                      UNION ALL';
    END LOOP;
    CLOSE C_INPUT_TABLE_LIST;

    --get rid of last union all
    V_AGG_SELECT := SUBSTR(V_AGG_SELECT, 0, LENGTH(V_AGG_SELECT) - 9);

    --filter input by roster
    V_AGG_SELECT := V_AGG_SELECT || ') S
                     ' || CASE WHEN pin_0_payment = 0 OR PIN_COMPONENT_ID IS NOT NULL
                     THEN
                       CASE
                         WHEN PIN_TOTAL_PAYMENT = 1 OR (PIN_CALCULATE_COMPONENT = 1 AND PIN_ROSTER_BY_COMPONENT = 1) THEN ' INNER JOIN '
                         ELSE ' RIGHT OUTER JOIN '
                       END  || V_ROSTER_TABLE || ' R ON S.' || NVL(PIN_PAY_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN) || ' = R.' || NVL(PIN_PAY_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN) ||
                    (CASE
                      WHEN (PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN AND pin_0_payment = 0) OR
                            ((PIN_OLD_EARN_ENTITY_COLUMN != PIN_EARN_ENTITY_COLUMN OR PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN)
                                  AND (INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_EARN_ENTITY_COLUMN || ',') > 0
                                       OR INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_OLD_EARN_ENTITY_COLUMN || ',') > 0
                                      )) THEN
                       ' AND S.' || CASE WHEN PIN_PAY_ENTITY_COLUMN IS NULL
                                         THEN PIN_OLD_EARN_ENTITY_COLUMN
                                           ELSE PIN_EARN_ENTITY_COLUMN
                                    END
                      || ' = R.' || CASE WHEN PIN_PAY_ENTITY_COLUMN IS NULL
                                         THEN PIN_OLD_EARN_ENTITY_COLUMN
                                           ELSE PIN_EARN_ENTITY_COLUMN
                                    END
                    END)
                     ELSE
                       CASE
                         WHEN PIN_TOTAL_PAYMENT = 1 OR (PIN_CALCULATE_COMPONENT = 1 AND PIN_ROSTER_BY_COMPONENT = 1) THEN ' INNER JOIN '
                         ELSE ' RIGHT OUTER JOIN '
                       END || V_ROSTER_TABLE || ' R ON S.' || NVL(PIN_PAY_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN) || ' = R.' || NVL(PIN_PAY_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN) ||
                    (CASE
                      WHEN (PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN AND pin_0_payment = 0) OR
                            ((PIN_OLD_EARN_ENTITY_COLUMN != PIN_EARN_ENTITY_COLUMN OR PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN)
                                  AND (INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_EARN_ENTITY_COLUMN || ',') > 0
                                       OR INSTR(PIN_ADD_ATTRIBUTE_COLUMNS || ',', ',' || PIN_OLD_EARN_ENTITY_COLUMN || ',') > 0
                                      )) THEN
                       ' AND S.' || CASE WHEN PIN_PAY_ENTITY_COLUMN IS NULL
                                         THEN PIN_OLD_EARN_ENTITY_COLUMN
                                           ELSE PIN_EARN_ENTITY_COLUMN
                                    END
                      || ' = R.' || CASE WHEN PIN_PAY_ENTITY_COLUMN IS NULL
                                         THEN PIN_OLD_EARN_ENTITY_COLUMN
                                           ELSE PIN_EARN_ENTITY_COLUMN
                                    END
                    END)
                       END ;

    --add group by
    IF (pin_0_payment = 0) THEN

       V_AGG_SELECT := V_AGG_SELECT || '
              GROUP BY R.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.');

    ELSE

       V_AGG_SELECT := V_AGG_SELECT || '
              GROUP BY R.' || V_ENTITY_COLUMN ||
                   CASE
                      WHEN PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN OR PIN_OLD_EARN_ENTITY_COLUMN != PIN_EARN_ENTITY_COLUMN THEN
                       REPLACE(REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.'), 'S.' || NVL(PIN_OLD_EARN_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN), 'R.' || NVL(PIN_OLD_EARN_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN))
                      ELSE
                       REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.')
                    END;

    END IF;

    /***aggregate component earning>>>***/

    V_VAL_NO_FALL_ENTITY := 'PAYMENT_ENTITY_ID';

    V_TEMP_PROC_VALIDATION_COUNT := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES');

    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PAYMENT_TEMP_PROC' || PIN_COMPONENT_ID, pin_ver_object_id, 'CARDINALITY(TEMP_PROC_VALIDATION_VALUES ' || V_TEMP_PROC_VALIDATION_COUNT || ')');
    --
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'PAYMENT_TEMP_PROC' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PAYMENT_TEMP_PROC', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));


    SELECT LISTAGG(CASE
                     WHEN TAB.TC_ENTITY_ID IS NULL THEN
                      ', CALC_ENTITY_' || LVL || '_VALUE AS ' || TAB.AA
                     ELSE
                      ', CALC_ENTITY_' || LVL || '_ID AS ' || TAB.AA
                   END,
                   '') WITHIN GROUP(ORDER BY TAB.LVL) AS LIST
      INTO V_PAY_VALID_COLS
      FROM (SELECT AA, MIN(TC.TC_ENTITY_ID) TC_ENTITY_ID, BB.LVL
              FROM (SELECT REGEXP_SUBSTR(REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, PIN_EARN_ENTITY_COLUMN),
                                         '[^ ,]+',
                                         1,
                                         LEVEL) AA,
                           LEVEL AS LVL
                      FROM DUAL
                    CONNECT BY REGEXP_SUBSTR(REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, PIN_EARN_ENTITY_COLUMN),
                                             '[^ ,]+',
                                             1,
                                             LEVEL) IS NOT NULL) BB
             INNER JOIN TABLE_COLUMNS TC
                ON BB.AA = TC.TC_PHYSICAL_NAME
             GROUP BY BB.AA, BB.LVL) TAB;
    CASE
      WHEN PIN_0_PAYMENT = 0 THEN
        V_VAL_NO_FALL_JOIN   := '
                    LEFT JOIN (' || v_select_hint || ' DISTINCT ' ||
                                V_VAL_NO_FALL_ENTITY || V_PAY_VALID_COLS || CASE WHEN INSTR(PIN_ADD_ATTRIBUTE_COLUMNS, PIN_EARN_ENTITY_COLUMN)>0 THEN ', EARNING_ENTITY_ID AS ' || PIN_EARN_ENTITY_COLUMN END ||'
                                FROM TEMP_PROC_VALIDATION_VALUES) TPVV ON MAIN_S.' ||
                                V_ENTITY_COLUMN || ' = TPVV.' ||
                                V_VAL_NO_FALL_ENTITY || REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATTRIBUTE_COLUMNS, '([^,]+)', ' AND MAIN_S.\1 = TPVV.\1'), ',', ''), 'MAIN_S.UPPER(', 'UPPER(MAIN_S.'), 'TPVV.UPPER(', 'UPPER(TPVV.');
      ELSE
        V_VAL_NO_FALL_JOIN   := '
                    LEFT JOIN (' || v_select_hint || ' DISTINCT ' ||
                                V_VAL_NO_FALL_ENTITY || V_PAY_VALID_COLS || CASE WHEN INSTR(PIN_ADD_ATTRIBUTE_COLUMNS, PIN_EARN_ENTITY_COLUMN)>0 THEN ', EARNING_ENTITY_ID AS ' || PIN_EARN_ENTITY_COLUMN END ||'
                                FROM TEMP_PROC_VALIDATION_VALUES) TPVV ON MAIN_S.' ||
                                V_ENTITY_COLUMN || ' = TPVV.' ||
                                V_VAL_NO_FALL_ENTITY || REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATTRIBUTE_COLUMNS, '([^,]+)', ' AND (MAIN_S.\1 = TPVV.\1 OR TPVV.\1 IS NULL)'), ',', ''), 'MAIN_S.UPPER(', 'UPPER(MAIN_S.'), 'TPVV.UPPER(', 'UPPER(TPVV.');
    END CASE;

    V_VAL_NO_FALL_INSERT := V_VAL_NO_FALL_ENTITY || ' IS NULL ' || CASE
                              WHEN PIN_APPLY_DRAWS = 0 AND PIN_CONSTANT_DRAW IS NULL THEN
                               ' AND COALESCE(MAIN_S_GUARANTEE_AMOUNT, 0) >= 0 '
                              WHEN PIN_APPLY_DRAWS = 1 AND PIN_CONSTANT_DRAW IS NULL THEN
                               ' AND COALESCE(MAIN_S_RECOVERABLE_DRAW_AMOUNT, 0) >= 0 '
                              WHEN PIN_APPLY_DRAWS = 2 AND PIN_CONSTANT_DRAW IS NULL THEN
                               ' AND COALESCE(MAIN_S_GUARANTEE_AMOUNT, 0) >= 0
                                 AND COALESCE(MAIN_S_RECOVERABLE_DRAW_AMOUNT, 0) >= 0
                                 AND NOT(MAIN_S_GUARANTEE_AMOUNT IS NOT NULL AND MAIN_S_RECOVERABLE_DRAW_AMOUNT IS NOT NULL)
                                 '
                              ELSE
                               ''
                            END;
    V_VAL_NO_FALL_SELECT := ' , ' || V_VAL_NO_FALL_ENTITY;
    /***validation_no_fall>>>***/

    /***<<<extract prior period payments***/
    IF PIN_PRIOR_PERIOD_IDS IS NOT NULL THEN

      V_SQL_SELECT := V_SQL_SELECT || '
                , CAST(MAIN_S.PRIOR_PERIOD_PAYMENTS AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_PAYMENTS') ||
                      ') AS MAIN_S_PRIOR_PERIOD_PAYMENTS
                , CAST(MAIN_S.CURRENT_PERIOD_PAYMENT AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('CURRENT_PERIOD_PAYMENT') ||
                      ') AS MAIN_S_CURRENT_PERIOD_PAYMENT';

      V_SQL_INSERT := V_SQL_INSERT ||
                      ', PRIOR_PERIOD_PAYMENTS, CURRENT_PERIOD_PAYMENT';

      V_SQL_VALUES := V_SQL_VALUES ||
                      ', MAIN_S_PRIOR_PERIOD_PAYMENTS, MAIN_S_CURRENT_PERIOD_PAYMENT';

      V_PRIORPP_SELECT := ' SELECT S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.') || '
                              , S.' ||
                          PIN_CURRENT_PERIOD_COLUMN || '
                                ' ||
                          V_PROJECTED_ALIAS || '
                              , ' || case WHEN (V_COMPONENT_NUMBER IS NULL) THEN 'COMPONENT_TOTAL'
                              ELSE 'S.PAYMENT_DUE AS TOTAL_EARNINGS' END|| '
                              , COALESCE(PP.PRIOR_PAYMENT_DUE, 0) AS PRIOR_PERIOD_PAYMENTS
                              , ' || case WHEN (V_COMPONENT_NUMBER IS NULL) THEN  '(CASE WHEN S.PAYMENT_DUE - COALESCE(PP.PRIOR_PAYMENT_DUE, 0) < 0 THEN 0 ELSE S.PAYMENT_DUE - COALESCE(PP.PRIOR_PAYMENT_DUE, 0) END) AS CURRENT_PERIOD_PAYMENT'
                              ELSE '(CASE WHEN PAYMENT_DUE - COALESCE(PP.PRIOR_PAYMENT_DUE, 0) < 0 THEN 0 ELSE PAYMENT_DUE - COALESCE(PP.PRIOR_PAYMENT_DUE, 0) END) AS CURRENT_PERIOD_PAYMENT' END|| '
                              , (CASE WHEN S.PAYMENT_DUE - COALESCE(PP.PRIOR_PAYMENT_DUE, 0) < 0 THEN 0 ELSE S.PAYMENT_DUE - COALESCE(PP.PRIOR_PAYMENT_DUE, 0) END) AS PAYMENT_DUE
                      FROM (';

      -- if prior with plan
      -- loop through prior period tables
      OPEN C_INPUT_TABLE_LIST FOR
        SELECT * FROM TABLE(PIN_INPUT_LIST) WHERE TABLE_TYPE = 28;
      LOOP
        FETCH C_INPUT_TABLE_LIST
          INTO V_INPUT_TABLE_REC;
        EXIT WHEN C_INPUT_TABLE_LIST%NOTFOUND;
        -- generic hint
        v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIOR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
        --
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'PRIOR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIOR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

        V_PRIORPP_TABLES := V_PRIORPP_TABLES || v_select_hint || ' ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                            ', PAYMENT_DUE FROM ' ||
                            V_INPUT_TABLE_REC.TABLE_NAME || CASE
                              WHEN PIN_PROJECTED_PERIOD IS NULL THEN
                               ''
                              ELSE
                               ' WHERE PROJECTED = 0'
                            END || ' UNION ALL' || CHR(10);
      END LOOP;
      CLOSE C_INPUT_TABLE_LIST;

      -- if prior with components
      IF (V_PRIORPP_TABLES IS NULL) THEN
        -- loop through prior period tables
        OPEN C_INPUT_TABLE_LIST FOR
          SELECT * FROM TABLE(PIN_INPUT_LIST) WHERE TABLE_TYPE = 32;
        LOOP
          FETCH C_INPUT_TABLE_LIST
            INTO V_INPUT_TABLE_REC;
          EXIT WHEN C_INPUT_TABLE_LIST%NOTFOUND;
          -- generic hint
          v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIORCOMP' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
          --
          v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'PRIORCOMP' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIORCOMP' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

          V_PRIORPP_TABLES := V_PRIORPP_TABLES || v_select_hint || ' ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                              ', CURRENT_PERIOD_PAYMENT FROM ' ||
                              V_INPUT_TABLE_REC.TABLE_NAME ||
                              CASE
                                WHEN PIN_PROJECTED_PERIOD IS NULL THEN
                                 ''
                                ELSE
                                 ' WHERE PROJECTED = 0'
                              END || ' UNION ALL' || CHR(10);
        END LOOP;
        CLOSE C_INPUT_TABLE_LIST;
      END IF;

      -- get rid of the last UNION ALL
      V_PRIORPP_TABLES := SUBSTR(V_PRIORPP_TABLES,
                                 1,
                                 LENGTH(V_PRIORPP_TABLES) - 10);
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIOR_TABLES' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'PRIOR_TABLES' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIOR_TABLES', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      IF (V_PRIORPP_TABLES IS NULL) THEN
        V_PRIORPP_TABLES := v_select_hint || ' ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS || ', ' || case WHEN v_component_number IS null THEN 'PAYMENT_DUE' ELSE 'CURRENT_PERIOD_PAYMENT' END ||
                            ' FROM ' || V_INPUT_TABLE ||
                             CASE
                              WHEN PIN_PROJECTED_PERIOD IS NULL THEN
                               ''
                              ELSE
                               ' WHERE PROJECTED = 0'
                            END;
      END IF;
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIOR_FROM' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'PRIOR_FROM' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'PRIOR_FROM', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_PRIORPP_FROM := ') S LEFT JOIN (' || v_select_hint || ' ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                        ', SUM(' || case WHEN v_component_number IS null THEN 'PAYMENT_DUE' ELSE 'CURRENT_PERIOD_PAYMENT' END || ') AS PRIOR_PAYMENT_DUE
          FROM (' || V_PRIORPP_TABLES || ') PP
          GROUP BY ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS || ' ) PP ON S.' ||
                        V_ENTITY_COLUMN || ' = PP.' || V_ENTITY_COLUMN || REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATT_JOIN_COLS, '([^-]+)', ' AND S.\1 = PP.\1'), '-', ''), 'S.COALESCE(UPPER(', 'COALESCE(UPPER(S.'), 'PP.COALESCE(UPPER(', 'COALESCE(UPPER(PP.'), 'S.COALESCE(', 'COALESCE(S.'), 'PP.COALESCE(', 'COALESCE(PP.');
    END IF;
    /***extract prior period>>>***/

    -- reset the variable
    V_PAY_VALID_COLS := '';

    -- prepare the columns for the PAYMENT validations
    FOR i IN 1 .. NVL(REGEXP_COUNT(PIN_ADD_ATTRIBUTE_COLUMNS, ','),0)
    LOOP
      V_PAY_VALID_COLS := V_PAY_VALID_COLS || ', C' || i;
      V_PAY_VALID_COLS2 := V_PAY_VALID_COLS2 || ', C' || TO_CHAR(i+1);
    END LOOP;

    /***<<<guarantee***/
    IF PIN_APPLY_DRAWS = 0 THEN

      V_IS_DRAW := TRUE;

      V_SQL_SELECT := V_SQL_SELECT || '
                , CAST(MAIN_S.GUARANTEE_AMOUNT AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('GUARANTEE_AMOUNT') ||
                      ') AS MAIN_S_GUARANTEE_AMOUNT
                , CAST(MAIN_S.PAYMENT_AFTER_DRAW AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('PAYMENT_AFTER_DRAW') ||
                      ') AS MAIN_S_PAYMENT_AFTER_DRAW';

      V_SQL_INSERT := V_SQL_INSERT ||
                      ', GUARANTEE_AMOUNT, PAYMENT_AFTER_DRAW';

      V_SQL_VALUES := V_SQL_VALUES ||
                      ', MAIN_S_GUARANTEE_AMOUNT, MAIN_S_PAYMENT_AFTER_DRAW';

      --guarantee is a table
      IF PIN_CONSTANT_DRAW IS NULL THEN
        -- add the negative value validation
        V_SQL_INSERT_ALL := ' WHEN MAIN_S_GUARANTEE_AMOUNT < 0 THEN INTO TEMP_PAYMENT_VALIDATIONS(PAYMENT_ENTITY ' || V_PAY_VALID_COLS || ', VALIDATION_TYPE) values (' ||
                            V_ENTITY_COLUMN || V_PAY_VALID_COLS2 || ', 3815) ';
        -- load data about guarantee table
        SELECT *
          INTO V_INPUT_TABLE_REC
          FROM TABLE(PIN_INPUT_LIST)
         WHERE TABLE_TYPE = 20;
        -- generic hint
        v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONSTANT_DRAW' || PIN_COMPONENT_ID, pin_ver_object_id);
        --
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'CONSTANT_DRAW' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONSTANT_DRAW', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

        IF LENGTH(V_INPUT_TABLE_REC.FROM_CLAUSE) != 0 OR
           LENGTH(V_ROSTER_TABLE_FROM) != 0 THEN
          V_DRAWS_FROM := ') S
                         INNER JOIN ' || CASE
                            WHEN PIN_PAY_ENTITY_COLUMN IS NOT NULL AND
                                 PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN THEN
                             V_ROSTER_FOR_ATT
                            ELSE
                             V_ROSTER_TABLE
                          END || ' R ON S.' || V_ENTITY_COLUMN || ' = R.' || V_ENTITY_COLUMN || '
                         LEFT JOIN (' || v_select_hint || ' * FROM ' ||
                          V_INPUT_TABLE_REC.TABLE_NAME || (CASE
                            WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NULL THEN
                             ''
                            ELSE
                             ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                          END) || ') G ' || V_INPUT_TABLE_REC.FROM_CLAUSE;

          --no fields to vary - one record -> will use the approach with constant_draw
        ELSE
          V_DRAWS_FROM := '';
          BEGIN
            -- generic hint
            v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'GUARANTEE_AMOUNT' || PIN_COMPONENT_ID, pin_ver_object_id);
            --
            v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'GUARANTEE_AMOUNT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'GUARANTEE_AMOUNT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

            V_CONSTANT_DRAW_SQL := 'SELECT GUARANTEE_AMOUNT INTO :a FROM ' ||
                                   V_INPUT_TABLE_REC.TABLE_NAME || (CASE
                                     WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NULL THEN
                                      ''
                                     ELSE
                                      ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                                   END);
            EXECUTE IMMEDIATE V_CONSTANT_DRAW_SQL
              INTO V_CONSTANT_DRAW;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_CONSTANT_DRAW := 1E39;
            WHEN TOO_MANY_ROWS THEN
              RAISE_APPLICATION_ERROR(-20422,
                                      'Guarantee table has more than one record');
          END;
        END IF;

      END IF;

      V_CONSTANT_DRAW := COALESCE(PIN_CONSTANT_DRAW, V_CONSTANT_DRAW);
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAWS_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DRAWS_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAWS_SELECT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      --guarantee is a constant value
      V_DRAWS_SELECT := ' ' || v_select_hint || ' S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.') || '
                              , S.' ||
                        PIN_CURRENT_PERIOD_COLUMN || '
                                ' || V_PROJECTED_ALIAS ||
                          CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                               ELSE ', ' || V_TOTAL_EARNINGS_COMP_TOTAL
                          END || ' ' || (CASE
                          WHEN PIN_PRIOR_PERIOD_IDS IS NOT NULL THEN
                           ', PRIOR_PERIOD_PAYMENTS, CURRENT_PERIOD_PAYMENT'
                          ELSE
                           ''
                        END) || (CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                           ', NULL'
                          WHEN V_CONSTANT_DRAW IS NOT NULL THEN
                           ', ' || TO_CHAR(V_CONSTANT_DRAW)
                          ELSE
                           ', G.GUARANTEE_AMOUNT'
                        END) || ' AS GUARANTEE_AMOUNT' ||
						--replaced payment_after_draw processing with cases in adjustments select query OF-72697
						/*' ,GREATEST(' || (CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                           'NULL'
                          WHEN V_CONSTANT_DRAW IS NOT NULL THEN
                           TO_CHAR(V_CONSTANT_DRAW)
                          ELSE
                           'G.GUARANTEE_AMOUNT'
                        END) || ', S.PAYMENT_DUE) AS PAYMENT_AFTER_DRAW ' ||*/
                            ', GREATEST(' || (CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                           '0'
                          WHEN V_CONSTANT_DRAW IS NOT NULL THEN
                           TO_CHAR(V_CONSTANT_DRAW)
                          ELSE
                           'COALESCE(G.GUARANTEE_AMOUNT, S.PAYMENT_DUE)'
                        END) || ', S.PAYMENT_DUE) AS PAYMENT_DUE
                      FROM (';
      V_DRAWS_FROM   := COALESCE(V_DRAWS_FROM, ') S');

    END IF;
    /***guarantee>>>***/

    /***<<<recoverable draws***/
    IF PIN_APPLY_DRAWS = 1 THEN

      V_IS_DRAW := TRUE;

      V_SQL_SELECT := V_SQL_SELECT || '
                , CAST(MAIN_S.RECOVERABLE_DRAW_AMOUNT AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('RECOVERABLE_DRAW_AMOUNT') ||
                      ') AS MAIN_S_RECOVERABLE_DRAW_AMOUNT
                , CAST(MAIN_S.PRIOR_PERIOD_DRAW_BALANCE AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_DRAW_BALANCE') ||
                      ') AS MAIN_S_PP_DRAW_BALANCE
                , CAST(MAIN_S.PAYMENT_AFTER_DRAW AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('PAYMENT_AFTER_DRAW') ||
                      ') AS MAIN_S_PAYMENT_AFTER_DRAW
                , CAST(MAIN_S.DRAW_BALANCE AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('DRAW_BALANCE') ||
                      ') AS MAIN_S_DRAW_BALANCE';

      V_SQL_INSERT := V_SQL_INSERT ||
                      ', RECOVERABLE_DRAW_AMOUNT, PRIOR_PERIOD_DRAW_BALANCE, PAYMENT_AFTER_DRAW, DRAW_BALANCE';

      V_SQL_VALUES := V_SQL_VALUES ||
                      ', MAIN_S_RECOVERABLE_DRAW_AMOUNT, MAIN_S_PP_DRAW_BALANCE, MAIN_S_PAYMENT_AFTER_DRAW, MAIN_S_DRAW_BALANCE';

      -- compute prior period draws table
      BEGIN
        BEGIN
          SELECT TABLE_NAME
            INTO V_DRAWSPP_TABLE
            FROM TABLE(PIN_INPUT_LIST)
           WHERE TABLE_TYPE = 29;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        IF (V_DRAWSPP_TABLE IS NOT NULL) THEN
          -- generic hint
          v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAW_BALANCE' || PIN_COMPONENT_ID, pin_ver_object_id);
          --
          v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DRAW_BALANCE' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAW_BALANCE', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

          V_DRAWSPP_TABLE := 'SELECT ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                             ', DRAW_BALANCE FROM ' || V_DRAWSPP_TABLE ||
                             CASE
                               WHEN PIN_PROJECTED_PERIOD IS NULL THEN
                                ''
                               ELSE
                                ' WHERE PROJECTED = 0'
                             END;
        ELSE
          V_DRAWSPP_TABLE := 'SELECT NULL ' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',NULL AS ') ||
                             ', NULL DRAW_BALANCE FROM DUAL WHERE 1 = 0';
        END IF;
      END;

      --recoverable draws is a table
      IF PIN_CONSTANT_DRAW IS NULL THEN
        -- add the negative values validations
        V_SQL_INSERT_ALL := '
        --negative values from draw table
        WHEN MAIN_S_RECOVERABLE_DRAW_AMOUNT < 0 THEN INTO TEMP_PAYMENT_VALIDATIONS(PAYMENT_ENTITY' || V_PAY_VALID_COLS || ', VALIDATION_TYPE) values (' ||
                                  V_ENTITY_COLUMN || V_PAY_VALID_COLS2 || ', 3835) ';
        -- load data about recoverable draw table
        SELECT *
          INTO V_INPUT_TABLE_REC
          FROM TABLE(PIN_INPUT_LIST)
         WHERE TABLE_TYPE = 21;

        IF LENGTH(V_INPUT_TABLE_REC.FROM_CLAUSE) != 0 OR
           LENGTH(V_ROSTER_TABLE_FROM) != 0 THEN
            -- generic hint
            v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONST' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);

            --
            v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'CONST' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONST' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

            V_DRAWS_FROM := ') S
               INNER JOIN ' || CASE
                              WHEN PIN_PAY_ENTITY_COLUMN IS NOT NULL AND
                                   PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN THEN
                               V_ROSTER_FOR_ATT
                              ELSE
                               V_ROSTER_TABLE
                            END || ' R ON S.' || V_ENTITY_COLUMN || ' = R.' ||
                            V_ENTITY_COLUMN || '
               LEFT JOIN (' || v_select_hint || ' * FROM ' ||
                            V_INPUT_TABLE_REC.TABLE_NAME || (CASE
                              WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NULL THEN
                               ''
                              ELSE
                               ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                            END) || ') RD ' || V_INPUT_TABLE_REC.FROM_CLAUSE || CASE
                              WHEN PIN_RECOVERABLE_PRIOR_PERIOD IS NOT NULL THEN
                               ' LEFT JOIN (' || V_DRAWSPP_TABLE || ') PPRD ON S.' || V_ENTITY_COLUMN ||
                               ' = PPRD.' || V_ENTITY_COLUMN || REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATT_JOIN_COLS, '([^-]+)', ' AND S.\1 = PPRD.\1'), '-', ''), 'S.COALESCE(UPPER(', 'COALESCE(UPPER(S.'), 'PPRD.COALESCE(UPPER(', 'COALESCE(UPPER(PPRD.'), 'S.COALESCE(', 'COALESCE(S.'), 'PPRD.COALESCE(', 'COALESCE(PPRD.')
                              ELSE
                               NULL
                            END;

          --no fields to vary - one record -> will use the approach with constant_draw
        ELSE
          V_DRAWS_FROM := '';
          BEGIN
            -- generic hint
            v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'RECDR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
            --
            v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'RECDR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'RECDR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

            V_CONSTANT_DRAW_SQL := v_select_hint || ' RECOVERABLE_DRAW_AMOUNT INTO :a FROM ' ||
                                   V_INPUT_TABLE_REC.TABLE_NAME || (CASE
                                     WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NULL THEN
                                      ''
                                     ELSE
                                      ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                                   END);
            EXECUTE IMMEDIATE V_CONSTANT_DRAW_SQL
              INTO V_CONSTANT_DRAW;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_CONSTANT_DRAW := 1E39;
            WHEN TOO_MANY_ROWS THEN
              RAISE_APPLICATION_ERROR(-20422,
                                      'Recoverable draw table has more than one record');
          END;
        END IF;

      END IF;

      V_CONSTANT_DRAW := COALESCE(PIN_CONSTANT_DRAW, V_CONSTANT_DRAW);
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAWS_MAIN_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DRAWS_MAIN_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAWS_MAIN_SELECT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      --recoverable draw is a constant value
      V_DRAWS_SELECT := ' ' || v_select_hint || ' S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.') || '
                              , S.' ||
                        PIN_CURRENT_PERIOD_COLUMN || '
                                ' || V_PROJECTED_ALIAS || '
                              , ' || V_TOTAL_EARNINGS_COMP_TOTAL || ' ' || (CASE
                          WHEN PIN_PRIOR_PERIOD_IDS IS NOT NULL THEN
                           ', PRIOR_PERIOD_PAYMENTS, CURRENT_PERIOD_PAYMENT'
                          ELSE
                           ''
                        END) || (CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                           ', NULL'
                          WHEN V_CONSTANT_DRAW IS NOT NULL THEN
                           ', ' || TO_CHAR(V_CONSTANT_DRAW)
                          ELSE
                           ', RD.RECOVERABLE_DRAW_AMOUNT'
                        END) || ' AS RECOVERABLE_DRAW_AMOUNT '

                        -- PRIOR_PERIOD_DRAW_BALANCE
                          || ' , ' || (CASE
                          WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 AND V_CONSTANT_DRAW <> 1E39 THEN
               ' 0'
              WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                CASE
                  WHEN V_CONSTANT_DRAW IS NULL THEN
                                     'CASE
                          WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NULL THEN NULL
                          ELSE 0
                        END '
                  ELSE 'NULL'
                END
              ELSE
               CASE
              WHEN V_CONSTANT_DRAW IS NULL THEN
                 'CASE
                  WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NOT NULL THEN
                   COALESCE(PPRD.DRAW_BALANCE, 0)
                  WHEN PPRD.DRAW_BALANCE = 0 THEN
                   NULL
                  ELSE
                   PPRD.DRAW_BALANCE
                 END'
              WHEN V_CONSTANT_DRAW = 1E39 THEN
                   'CASE
                   WHEN PPRD.DRAW_BALANCE = 0 THEN
                   NULL
                  ELSE
                   PPRD.DRAW_BALANCE
                 END'
               ELSE
                   'COALESCE(PPRD.DRAW_BALANCE, 0)'
               END
                        END) || ' AS PRIOR_PERIOD_DRAW_BALANCE '

                        -- DRAW_BALANCE
                          || ' , GREATEST(' || (CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                           '0'
                          WHEN V_CONSTANT_DRAW IS NOT NULL THEN
                           TO_CHAR(V_CONSTANT_DRAW)
                          ELSE
                           'COALESCE(RD.RECOVERABLE_DRAW_AMOUNT, 0)'
                        END) || ' - S.PAYMENT_DUE + ' || (
           CASE
                          WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 AND V_CONSTANT_DRAW <> 1E39 THEN
                           ' 0'
                          WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                            CASE
                              WHEN V_CONSTANT_DRAW IS NULL THEN
                                                 'CASE
                                      WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NULL THEN NULL
                                      ELSE 0
                                    END '
                              ELSE 'NULL'
                            END
                          ELSE
               CASE
                WHEN V_CONSTANT_DRAW IS NULL THEN
                   'CASE
                    WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NOT NULL THEN
                     COALESCE(PPRD.DRAW_BALANCE, 0)
                    WHEN PPRD.DRAW_BALANCE = 0 THEN
                     NULL
                    ELSE
                     PPRD.DRAW_BALANCE
                   END'
                WHEN V_CONSTANT_DRAW = 1E39 THEN
                     'CASE
                     WHEN PPRD.DRAW_BALANCE = 0 THEN
                     NULL
                    ELSE
                     PPRD.DRAW_BALANCE
                   END'
                 ELSE
                     'COALESCE(PPRD.DRAW_BALANCE, 0)'
                 END
              END) || ', 0) AS DRAW_BALANCE '

                        -- PAYMENT_AFTER_DRAW --replaced payment_after_draw processing with cases in adjustments select query OF-72697
                          /*|| ' , GREATEST(' || (CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                           'CASE
                              WHEN COALESCE(PPRD.DRAW_BALANCE, 0) = 0 THEN
                               NULL
                              ELSE
                               -1E39
                             END'
                          WHEN V_CONSTANT_DRAW IS NOT NULL THEN
                           TO_CHAR(V_CONSTANT_DRAW)
                          ELSE
                           'COALESCE(RD.RECOVERABLE_DRAW_AMOUNT,
                             CASE
                              WHEN COALESCE(PPRD.DRAW_BALANCE, 0) = 0 THEN
                               NULL
                              ELSE
                               -1E39
                             END)'
                        END) || ', S.PAYMENT_DUE - ' || (CASE
                          WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                           '0 '
                          ELSE
                           'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                        END) || ') AS PAYMENT_AFTER_DRAW '*/

                        -- PAYMENT_DUE
                             ||
                          CASE
                          WHEN V_CONSTANT_DRAW = 1E39 THEN
                                     ', S.PAYMENT_DUE - ' || (CASE
                                    WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                                     '0 '
                                    ELSE
                                     'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                                  END)
                          ELSE
                               ' , GREATEST(' ||
                               CASE WHEN V_CONSTANT_DRAW <> 1E39 THEN
                                     TO_CHAR(V_CONSTANT_DRAW)
                                ELSE
                                 'COALESCE(RD.RECOVERABLE_DRAW_AMOUNT, S.PAYMENT_DUE - ' || (CASE
                                      WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                                       '0 '
                                      ELSE
                                       'COALESCE(PPRD.DRAW_BALANCE, 0)'
                                    END) || ')'
                                END || ', S.PAYMENT_DUE - ' || (CASE
                              WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                               '0 '
                              ELSE
                               'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                              END)
                           || ')'
                          END || ' AS PAYMENT_DUE
                      FROM (';

      V_DRAWS_FROM := COALESCE(V_DRAWS_FROM,
                               ') S' || CASE
                                 WHEN PIN_RECOVERABLE_PRIOR_PERIOD IS NOT NULL THEN
                                  ' LEFT JOIN (' || V_DRAWSPP_TABLE || ') PPRD ON S.' ||
                                  V_ENTITY_COLUMN || ' = PPRD.' || V_ENTITY_COLUMN || REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATTRIBUTE_COLUMNS, '([^,]+)', ' AND S.\1 = PPRD.\1'), ',', ''), 'S.UPPER(', 'UPPER(S.'), 'PPRD.UPPER(', 'UPPER(PPRD.')
                                 ELSE
                                  NULL
                               END);

    END IF;
    /***recoverable draws>>>***/

    /***<<<both guarantee and recoverable draws***/
    IF PIN_APPLY_DRAWS = 2 THEN

      V_IS_DRAW := TRUE;

      V_SQL_SELECT := V_SQL_SELECT || '
                , CAST(MAIN_S.GUARANTEE_AMOUNT AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('GUARANTEE_AMOUNT') ||
                      ') AS MAIN_S_GUARANTEE_AMOUNT
                , CAST(MAIN_S.RECOVERABLE_DRAW_AMOUNT AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('RECOVERABLE_DRAW_AMOUNT') ||
                      ') AS MAIN_S_RECOVERABLE_DRAW_AMOUNT
                , CAST(MAIN_S.PRIOR_PERIOD_DRAW_BALANCE AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_DRAW_BALANCE') ||
                      ') AS MAIN_S_PP_DRAW_BALANCE
                , CAST(MAIN_S.PAYMENT_AFTER_DRAW AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('PAYMENT_AFTER_DRAW') ||
                      ') AS MAIN_S_PAYMENT_AFTER_DRAW
                , CAST(MAIN_S.DRAW_BALANCE AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('DRAW_BALANCE') ||
                      ') AS MAIN_S_DRAW_BALANCE';

      V_SQL_INSERT := V_SQL_INSERT ||
                      ', GUARANTEE_AMOUNT, RECOVERABLE_DRAW_AMOUNT, PRIOR_PERIOD_DRAW_BALANCE, PAYMENT_AFTER_DRAW, DRAW_BALANCE';

      V_SQL_VALUES := V_SQL_VALUES ||
                      ', MAIN_S_GUARANTEE_AMOUNT, MAIN_S_RECOVERABLE_DRAW_AMOUNT, MAIN_S_PP_DRAW_BALANCE, MAIN_S_PAYMENT_AFTER_DRAW, MAIN_S_DRAW_BALANCE';




      -- compute prior period draws table
      BEGIN
        BEGIN
          SELECT TABLE_NAME
            INTO V_DRAWSPP_TABLE
            FROM TABLE(PIN_INPUT_LIST)
           WHERE TABLE_TYPE = 29;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;

        IF (V_DRAWSPP_TABLE IS NOT NULL) THEN
          -- generic hint
          v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAW_BALANCE' || PIN_COMPONENT_ID, pin_ver_object_id);
          --
          v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DRAW_BALANCE' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAW_BALANCE', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

          V_DRAWSPP_TABLE := 'SELECT ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                             ', DRAW_BALANCE FROM ' || V_DRAWSPP_TABLE ||
                             CASE
                               WHEN PIN_PROJECTED_PERIOD IS NULL THEN
                                ''
                               ELSE
                                ' WHERE PROJECTED = 0'
                             END;
        ELSE
          V_DRAWSPP_TABLE := 'SELECT NULL ' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',NULL AS ') ||
                             ', NULL DRAW_BALANCE FROM DUAL WHERE 1 = 0';
        END IF;
      END;

      --guarantee and recoverable draw must be tables
      IF PIN_CONSTANT_DRAW IS NULL THEN
        -- add the negative value validation
        V_SQL_INSERT_ALL := ' WHEN MAIN_S_GUARANTEE_AMOUNT < 0 THEN INTO TEMP_PAYMENT_VALIDATIONS(PAYMENT_ENTITY ' || V_PAY_VALID_COLS || ', VALIDATION_TYPE) values (' ||
                            V_ENTITY_COLUMN || V_PAY_VALID_COLS2 || ', 3815) ';
        V_SQL_INSERT_ALL := V_SQL_INSERT_ALL || '
        WHEN MAIN_S_RECOVERABLE_DRAW_AMOUNT < 0 THEN INTO TEMP_PAYMENT_VALIDATIONS(PAYMENT_ENTITY' || V_PAY_VALID_COLS || ', VALIDATION_TYPE) values (' ||
                      V_ENTITY_COLUMN || V_PAY_VALID_COLS2 || ', 3835) ';
        -- add the guarantee and recoverable draws on same record validation
        V_SQL_INSERT_ALL := V_SQL_INSERT_ALL || '
        WHEN MAIN_S_GUARANTEE_AMOUNT IS NOT NULL AND MAIN_S_RECOVERABLE_DRAW_AMOUNT IS NOT NULL THEN INTO TEMP_PAYMENT_VALIDATIONS(PAYMENT_ENTITY' || V_PAY_VALID_COLS || ', VALIDATION_TYPE) values (' ||
             V_ENTITY_COLUMN || V_PAY_VALID_COLS2 || ', 3845) ';
        -- add the guarantee and prior period draw validation
        V_SQL_INSERT_ALL := V_SQL_INSERT_ALL || '
        WHEN MAIN_S_GUARANTEE_AMOUNT IS NOT NULL AND MAIN_S_PP_DRAW_BALANCE IS NOT NULL AND MAIN_S_RECOVERABLE_DRAW_AMOUNT IS NULL THEN
          INTO TEMP_PAYMENT_VALIDATIONS(PAYMENT_ENTITY, VALIDATION_TYPE) VALUES('|| V_ENTITY_COLUMN ||', 3875)';
        -- load data about guarantee table
        SELECT *
          INTO V_INPUT_TABLE_REC_G
          FROM TABLE(PIN_INPUT_LIST)
         WHERE TABLE_TYPE = 20;
        -- load data about recoverable draw table
        SELECT *
          INTO V_INPUT_TABLE_REC_RD
          FROM TABLE(PIN_INPUT_LIST)
         WHERE TABLE_TYPE = 21;

        -- generic hint guarantee
        v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONSTANT_DRAW' || PIN_COMPONENT_ID, pin_ver_object_id);
        --
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'CONSTANT_DRAW' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONSTANT_DRAW', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

        -- generic hint recoverable draw
        v_select_hint2 :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONST' || V_INPUT_TABLE_REC_RD.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
        --
        v_select_hint2 :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'CONST' || V_INPUT_TABLE_REC_RD.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'CONST' || V_INPUT_TABLE_REC_RD.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint2, '/*+'), '*/'));


          V_DRAWS_FROM := ') S
                         ' ||
             CASE WHEN LENGTH(V_ROSTER_TABLE_FROM) != 0 OR LENGTH(V_INPUT_TABLE_REC_G.FROM_CLAUSE) != 0 OR LENGTH(V_INPUT_TABLE_REC_RD.FROM_CLAUSE) != 0 THEN
                  'INNER JOIN ' ||
                CASE
                  WHEN PIN_PAY_ENTITY_COLUMN IS NOT NULL AND
                     PIN_EARN_ENTITY_COLUMN != PIN_PAY_ENTITY_COLUMN THEN
                   V_ROSTER_FOR_ATT
                  ELSE
                   V_ROSTER_TABLE
                END || ' R ON S.' || V_ENTITY_COLUMN || ' = R.' || V_ENTITY_COLUMN
                 ||
                 CASE --check guarantee existence
                  WHEN LENGTH(V_INPUT_TABLE_REC_G.FROM_CLAUSE) != 0 THEN
                    '
                    LEFT JOIN (' || v_select_hint || ' * FROM ' ||
                    V_INPUT_TABLE_REC_G.TABLE_NAME || (
                    CASE
                      WHEN V_INPUT_TABLE_REC_G.WHERE_CLAUSE IS NULL THEN
                       ''
                      ELSE
                       ' WHERE ' || V_INPUT_TABLE_REC_G.WHERE_CLAUSE
                    END) || ') G ' || V_INPUT_TABLE_REC_G.FROM_CLAUSE
                  ELSE NULL
                 END ||
                 CASE --check recovarable existence
                  WHEN LENGTH(V_INPUT_TABLE_REC_RD.FROM_CLAUSE) != 0 THEN
                    '
                    LEFT JOIN (' || v_select_hint2 || ' * FROM ' ||
                    V_INPUT_TABLE_REC_RD.TABLE_NAME || (
                    CASE
                      WHEN V_INPUT_TABLE_REC_RD.WHERE_CLAUSE IS NULL THEN
                       ''
                      ELSE
                       ' WHERE ' || V_INPUT_TABLE_REC_RD.WHERE_CLAUSE
                    END) || ') RD ' || V_INPUT_TABLE_REC_RD.FROM_CLAUSE
                  ELSE NULL
                 END
             ELSE
               NULL
             END
             ||
             CASE --check prior period existence
                WHEN PIN_RECOVERABLE_PRIOR_PERIOD IS NOT NULL THEN
                   ' LEFT JOIN (' || V_DRAWSPP_TABLE || ') PPRD ON S.' || V_ENTITY_COLUMN ||
                   ' = PPRD.' || V_ENTITY_COLUMN || REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATT_JOIN_COLS, '([^-]+)', ' AND S.\1 = PPRD.\1'), '-', ''), 'S.COALESCE(UPPER(', 'COALESCE(UPPER(S.'), 'PPRD.COALESCE(UPPER(', 'COALESCE(UPPER(PPRD.'), 'S.COALESCE(', 'COALESCE(S.'), 'PPRD.COALESCE(', 'COALESCE(PPRD.')
                ELSE NULL
             END;
      --check if we have to use constant aproach for guarantee or recoverable
      IF COALESCE(LENGTH(V_INPUT_TABLE_REC_G.FROM_CLAUSE),0) = 0 THEN
        BEGIN
        -- generic hint guarantee
        v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'GUARANTEE_AMOUNT' || PIN_COMPONENT_ID, pin_ver_object_id);
        --
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'GUARANTEE_AMOUNT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'GUARANTEE_AMOUNT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

        V_CONSTANT_DRAW_SQL := 'SELECT GUARANTEE_AMOUNT INTO :a FROM ' ||
                     V_INPUT_TABLE_REC_G.TABLE_NAME || (CASE
                     WHEN V_INPUT_TABLE_REC_G.WHERE_CLAUSE IS NULL THEN
                      ''
                     ELSE
                      ' WHERE ' || V_INPUT_TABLE_REC_G.WHERE_CLAUSE
                     END);
        EXECUTE IMMEDIATE V_CONSTANT_DRAW_SQL
          INTO V_CONSTANT_DRAW_G;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_CONSTANT_DRAW_G := 1E39;
        WHEN TOO_MANY_ROWS THEN
          RAISE_APPLICATION_ERROR(-20422,
                      'Guarantee table has more than one record');
        END;
      END IF;
      IF COALESCE(LENGTH(V_INPUT_TABLE_REC_RD.FROM_CLAUSE),0) = 0 THEN
        BEGIN
        -- generic hint recoverable
        v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'RECDR' || V_INPUT_TABLE_REC_RD.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
        --
        v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'RECDR' || V_INPUT_TABLE_REC_RD.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'RECDR' || V_INPUT_TABLE_REC_RD.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

        V_CONSTANT_DRAW_SQL := v_select_hint || ' RECOVERABLE_DRAW_AMOUNT INTO :a FROM ' ||
                     V_INPUT_TABLE_REC_RD.TABLE_NAME || (CASE
                     WHEN V_INPUT_TABLE_REC_RD.WHERE_CLAUSE IS NULL THEN
                      ''
                     ELSE
                      ' WHERE ' || V_INPUT_TABLE_REC_RD.WHERE_CLAUSE
                     END);
        EXECUTE IMMEDIATE V_CONSTANT_DRAW_SQL
          INTO V_CONSTANT_DRAW_RD;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_CONSTANT_DRAW_RD := 1E39;
        WHEN TOO_MANY_ROWS THEN
          RAISE_APPLICATION_ERROR(-20422,
                      'Recoverable draw table has more than one record');
        END;
        END IF;

      ELSE --we have a constant value not null given for pin_apply_draws = 2
        RAISE_APPLICATION_ERROR(-20423,
                                      'Constant option cannot be used when both guarantee and recoverable draws are selected.');
      END IF;

      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAWS_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DRAWS_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DRAWS_SELECT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      --guarantee and recov draws are tables or use constant aproach
      V_DRAWS_SELECT := ' ' || v_select_hint || ' S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.') || '
                                    , S.' || PIN_CURRENT_PERIOD_COLUMN || '
                                      ' || V_PROJECTED_ALIAS || CASE
          WHEN PIN_TOTAL_PAYMENT = 1
            THEN ''
          ELSE ', ' || V_TOTAL_EARNINGS_COMP_TOTAL
          END || ' ' || (
          CASE
            WHEN PIN_PRIOR_PERIOD_IDS IS NOT NULL
              THEN ', PRIOR_PERIOD_PAYMENTS, CURRENT_PERIOD_PAYMENT'
            ELSE ''
            END
          ) ||
          (CASE
             WHEN V_CONSTANT_DRAW_G = 1E39 THEN
              ', NULL'
             WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
              ', ' || TO_CHAR(V_CONSTANT_DRAW_G)
             ELSE
              ', G.GUARANTEE_AMOUNT'
           END) || ' AS GUARANTEE_AMOUNT ' ||
          (CASE
             WHEN V_CONSTANT_DRAW_RD = 1E39 THEN
              ', NULL'
             WHEN V_CONSTANT_DRAW_RD IS NOT NULL THEN
              ', ' || TO_CHAR(V_CONSTANT_DRAW_RD)
             ELSE
              ', RD.RECOVERABLE_DRAW_AMOUNT'
           END) || ' AS RECOVERABLE_DRAW_AMOUNT, ' ||
          -- PRIOR_PERIOD_DRAW_BALANCE
          (CASE
             WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 AND V_CONSTANT_DRAW_RD <> 1E39 THEN
               ' 0'
             WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                CASE
                  WHEN V_CONSTANT_DRAW_RD IS NULL THEN
                                     'CASE
                          WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NULL THEN NULL
                          ELSE 0
                        END '
                  ELSE 'NULL'
                END
             ELSE
                CASE
                  WHEN V_CONSTANT_DRAW_RD IS NULL THEN
                   'CASE
                    WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NOT NULL THEN
                     COALESCE(PPRD.DRAW_BALANCE, 0)
                    WHEN PPRD.DRAW_BALANCE = 0 THEN
                     NULL
                    ELSE
                     PPRD.DRAW_BALANCE
                   END'
                  WHEN V_CONSTANT_DRAW_RD = 1E39 THEN
                     'CASE
                     WHEN PPRD.DRAW_BALANCE = 0 THEN
                     NULL
                    ELSE
                     PPRD.DRAW_BALANCE
                   END'
                  ELSE
                   'COALESCE(PPRD.DRAW_BALANCE, 0)'
               END
            END) || ' AS PRIOR_PERIOD_DRAW_BALANCE '
        -- DRAW_BALANCE
        || ' , GREATEST(' ||
        (CASE
            WHEN V_CONSTANT_DRAW_RD = 1E39 THEN
             '0'
            WHEN V_CONSTANT_DRAW_RD IS NOT NULL THEN
             TO_CHAR(V_CONSTANT_DRAW_RD)
            ELSE
             'COALESCE(RD.RECOVERABLE_DRAW_AMOUNT, 0)'
          END) || ' - S.PAYMENT_DUE + ' ||
         (CASE
            WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 AND V_CONSTANT_DRAW_RD <> 1E39 THEN
                 ' 0'
            WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                 CASE
                    WHEN V_CONSTANT_DRAW_RD IS NULL THEN
                       'CASE
                          WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NULL THEN NULL
                          ELSE 0
                        END '
                    ELSE 'NULL'
                 END
            ELSE
                CASE
                  WHEN V_CONSTANT_DRAW_RD IS NULL THEN
                     'CASE
                      WHEN RD.RECOVERABLE_DRAW_AMOUNT IS NOT NULL THEN
                       COALESCE(PPRD.DRAW_BALANCE, 0)
                      WHEN PPRD.DRAW_BALANCE = 0 THEN
                       NULL
                      ELSE
                         CASE
                           WHEN
                             '
                             || (CASE
                                 WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
                                  TO_CHAR(V_CONSTANT_DRAW_G) || ' = 1E39 OR ' || TO_CHAR(V_CONSTANT_DRAW_G)
                                 ELSE
                                  'G.GUARANTEE_AMOUNT = 1E39 OR G.GUARANTEE_AMOUNT'
                                 END) || ' IS NULL THEN
                              PPRD.DRAW_BALANCE
                           ELSE

                              CASE
                                WHEN PPRD.DRAW_BALANCE IS NULL THEN
                                     NULL
                                ELSE
                                     0
                              END
                         END
                     END'
                  WHEN V_CONSTANT_DRAW_RD = 1E39 THEN
                       'CASE
                         WHEN PPRD.DRAW_BALANCE = 0 THEN
                           NULL
                         ELSE
                           CASE
                               WHEN
                                 '
                                 || (CASE
                                     WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
                                      TO_CHAR(V_CONSTANT_DRAW_G) || ' = 1E39 OR ' || TO_CHAR(V_CONSTANT_DRAW_G)
                                     ELSE
                                      'G.GUARANTEE_AMOUNT = 1E39 OR G.GUARANTEE_AMOUNT'
                                     END) || ' IS NULL THEN
                                  PPRD.DRAW_BALANCE
                               ELSE

                                  CASE
                                    WHEN PPRD.DRAW_BALANCE IS NULL THEN
                                         NULL
                                    ELSE
                                         0
                                  END
                             END
                     END'
                   ELSE
                       'COALESCE(PPRD.DRAW_BALANCE, 0)'
                END
          END) || ', 0) AS DRAW_BALANCE, '
          --payment after draw --replaced payment_after_draw processing with cases in adjustments select query OF-72697
          /*||
          CASE WHEN V_CONSTANT_DRAW_G = 1E39 AND V_CONSTANT_DRAW_RD = 1E39 --if no draw will be applied then the pay after draw will be null
            THEN ',NULL'
            ELSE
              ',
              CASE ' || --here at least one of the table aproach for guarantee or recoverable will be used
               CASE WHEN V_CONSTANT_DRAW_G = 1E39 THEN ''
               ELSE
               'WHEN '
               ||(CASE
                     WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
                      TO_CHAR(V_CONSTANT_DRAW_G)
                     ELSE
                      'GUARANTEE_AMOUNT'
                  END) ||
                ' IS NOT NULL
                THEN
                  CASE
                    WHEN PPRD.DRAW_BALANCE <> 0 THEN
                      NULL
                    ELSE
                      GREATEST(
                      ' || (CASE
                            WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
                             TO_CHAR(V_CONSTANT_DRAW_G)
                            ELSE
                             'G.GUARANTEE_AMOUNT'
                          END) || ', S.PAYMENT_DUE)
                  END'
               END ||
               CASE WHEN V_CONSTANT_DRAW_RD = 1E39 THEN ''
               ELSE
              ' WHEN '
                || (CASE
                     WHEN V_CONSTANT_DRAW_RD IS NOT NULL THEN
                      TO_CHAR(V_CONSTANT_DRAW_RD)
                     ELSE
                      'RECOVERABLE_DRAW_AMOUNT'
                   END) || ' IS NOT NULL OR PPRD.DRAW_BALANCE IS NOT NULL
              THEN GREATEST(' || (CASE
                            WHEN V_CONSTANT_DRAW_RD IS NOT NULL THEN
                             TO_CHAR(V_CONSTANT_DRAW_RD)
                            ELSE
                             'COALESCE(RD.RECOVERABLE_DRAW_AMOUNT,
                               CASE
                                WHEN COALESCE(PPRD.DRAW_BALANCE, 0) = 0 THEN
                                 NULL
                                ELSE
                                 -1E39
                               END)'
                          END) || ', S.PAYMENT_DUE - ' || (CASE
                            WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                             '0 '
                            ELSE
                             'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                          END) || ')'
                END || ' ELSE NULL END '
          END || ' AS PAYMENT_AFTER_DRAW,'*/
          --payment due
          ||
          CASE WHEN V_CONSTANT_DRAW_G = 1E39 AND V_CONSTANT_DRAW_RD = 1E39
                    THEN 'S.PAYMENT_DUE - ' || (CASE
                                                  WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                                                   '0 '
                                                  ELSE
                                                   'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                                                END)
              ELSE
                           '
                          CASE '
              || CASE WHEN V_CONSTANT_DRAW_G = 1E39 THEN ''
                  ELSE
                    'WHEN '
                         ||(CASE
                             WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
                              TO_CHAR(V_CONSTANT_DRAW_G)
                             ELSE
                              'GUARANTEE_AMOUNT'
                            END) || ' IS NOT NULL
                      THEN GREATEST(' || (CASE
                                  WHEN V_CONSTANT_DRAW_G IS NOT NULL THEN
                                   TO_CHAR(V_CONSTANT_DRAW_G)
                                  ELSE
                                   'COALESCE(G.GUARANTEE_AMOUNT, S.PAYMENT_DUE)'
                                END) || ', S.PAYMENT_DUE)'
                END ||
                CASE WHEN V_CONSTANT_DRAW_RD = 1E39 THEN ''
                 ELSE
                  'WHEN '
                    || (CASE
                         WHEN V_CONSTANT_DRAW_RD IS NOT NULL THEN
                          TO_CHAR(V_CONSTANT_DRAW_RD)
                         ELSE
                          'RD.RECOVERABLE_DRAW_AMOUNT'
                        END) || ' IS NOT NULL OR PPRD.DRAW_BALANCE IS NOT NULL
                    THEN GREATEST(' ||
                                     CASE WHEN V_CONSTANT_DRAW_RD <> 1E39 THEN
                                           TO_CHAR(V_CONSTANT_DRAW_RD)
                                      ELSE
                                       'COALESCE(RD.RECOVERABLE_DRAW_AMOUNT, S.PAYMENT_DUE - ' || (CASE
                                            WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                                             '0 '
                                            ELSE
                                             'COALESCE(PPRD.DRAW_BALANCE, 0)'
                                          END) || ')'
                                      END || ', S.PAYMENT_DUE - ' ||
                                      (CASE
                                        WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                                         '0 '
                                        ELSE
                                         'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                                      END)
                                 || ')'

                END ||
                 ' ELSE S.PAYMENT_DUE - ' || (CASE
                                                  WHEN PIN_RECOVERABLE_PRIOR_PERIOD = -1 THEN
                                                   '0 '
                                                  ELSE
                                                   'COALESCE(LEAST(S.PAYMENT_DUE, PPRD.DRAW_BALANCE), 0)'
                                                END) || ' END '
          END || ' AS PAYMENT_DUE
                            FROM (';

    END IF;
    /***both guarantee and recoverable draws>>>***/

    /***<<<adjustments***/
    V_CNT := 0;
    SELECT COUNT(1)
      INTO V_CNT
      FROM (select rownum from TABLE(PIN_INPUT_LIST)
             WHERE TABLE_TYPE = 22)
      where rownum <= 1;
    IF V_CNT > 0 THEN
      -- load data about adjustments table
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 22;
      V_SQL_SELECT := V_SQL_SELECT || '
                , CAST(MAIN_S.ADJUSTMENT AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('ADJUSTMENT') ||
                      ') AS MAIN_S_ADJUSTMENT';

      V_SQL_INSERT := V_SQL_INSERT || ', ADJUSTMENT';

      V_SQL_VALUES := V_SQL_VALUES || ', MAIN_S_ADJUSTMENT';
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'ADJUSTMENTS_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'ADJUSTMENTS_SELECT' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'ADJUSTMENTS_SELECT', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_ADJUSTMENTS_SELECT := v_select_hint || ' S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.') || '
                              , S.' ||
                              PIN_CURRENT_PERIOD_COLUMN || '
                                ' ||
                              V_PROJECTED_ALIAS ||
                              CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                                   ELSE ', ' || V_TOTAL_EARNINGS_COMP_TOTAL
                              END || ' ' ||
                              (CASE
                                WHEN PIN_PRIOR_PERIOD_IDS IS NOT NULL THEN
                                 ', PRIOR_PERIOD_PAYMENTS, CURRENT_PERIOD_PAYMENT'
                                ELSE
                                 ''
                              END) || (CASE --replaced payment_after_draw processing with cases in adjustments select query OF-72697
                                WHEN PIN_APPLY_DRAWS = 0 THEN
                                 ', GUARANTEE_AMOUNT,
                                    CASE
                                      WHEN GUARANTEE_AMOUNT IS NOT NULL
                                        THEN S.PAYMENT_DUE
                                      ELSE
                                        NULL
                                    END AS PAYMENT_AFTER_DRAW'
                                WHEN PIN_APPLY_DRAWS = 1 THEN
                                 ', RECOVERABLE_DRAW_AMOUNT, PRIOR_PERIOD_DRAW_BALANCE, DRAW_BALANCE,
                                    CASE
                                      WHEN RECOVERABLE_DRAW_AMOUNT IS NOT NULL
                                        OR COALESCE(TO_NUMBER(PRIOR_PERIOD_DRAW_BALANCE), 0) <> 0
                                        THEN S.PAYMENT_DUE
                                      ELSE
                                        NULL
                                    END AS PAYMENT_AFTER_DRAW'
                                WHEN PIN_APPLY_DRAWS = 2 THEN
                                 ', GUARANTEE_AMOUNT, RECOVERABLE_DRAW_AMOUNT, PRIOR_PERIOD_DRAW_BALANCE, DRAW_BALANCE,
                                    CASE
                                      WHEN GUARANTEE_AMOUNT IS NOT NULL
                                        OR RECOVERABLE_DRAW_AMOUNT IS NOT NULL
                                        OR COALESCE(TO_NUMBER(PRIOR_PERIOD_DRAW_BALANCE), 0) <> 0
                                        THEN S.PAYMENT_DUE
                                      ELSE
                                        NULL
                                    END AS PAYMENT_AFTER_DRAW'
                                ELSE
                                 ''
                              END) || '
                              , ADJUSTMENT AS ADJUSTMENT
                              , S.PAYMENT_DUE + COALESCE(ADJUSTMENT, 0) AS PAYMENT_DUE
                              FROM (';
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'ADJUSTMENTS_FROM' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'ADJUSTMENTS_FROM' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'ADJUSTMENTS_FROM', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_ADJUSTMENTS_FROM := ') S LEFT JOIN (' || v_select_hint || ' ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                            ', SUM(ADJUSTMENT) AS ADJUSTMENT FROM ' ||
                            V_INPUT_TABLE_REC.TABLE_NAME || (CASE
                              WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NULL THEN
                               ''
                              ELSE
                               ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                            END) || ' GROUP BY ' || V_ENTITY_COLUMN || PIN_ADD_ATTRIBUTE_COLUMNS ||
                            ') ADJ ON S.' || V_ENTITY_COLUMN || ' = ADJ.' ||
                            V_ENTITY_COLUMN || REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATT_JOIN_COLS, '([^-]+)', ' AND S.\1 = ADJ.\1'), '-', ''), 'S.COALESCE(UPPER(', 'COALESCE(UPPER(S.'), 'ADJ.COALESCE(UPPER(', 'COALESCE(UPPER(ADJ.'), 'S.COALESCE(', 'COALESCE(S.'), 'ADJ.COALESCE(', 'COALESCE(ADJ.');
    END IF;
    /***adjustments>>>***/

    /***<<<overrides***/
    V_CNT := 0;
    SELECT COUNT(1)
      INTO V_CNT
      FROM (select rownum from TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 23)
      where rownum <= 1;
    IF V_CNT > 0 THEN
      -- load data about adjustments table
      SELECT *
        INTO V_INPUT_TABLE_REC
        FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE = 23;

      V_CNT := 0;
      SELECT COUNT(1)
        INTO V_CNT
        FROM (select rownum from TABLE(PIN_INPUT_LIST)
         WHERE TABLE_TYPE = 22)
        where rownum <= 1;

      V_SQL_SELECT := V_SQL_SELECT || '
                , CAST(MAIN_S.OVERRIDE AS NUMBER' ||
                      COMMONS.FIELD_PRECISION_AND_SCALE('OVERRIDE') ||
                      ') AS MAIN_S_OVERRIDE';

      V_SQL_INSERT := V_SQL_INSERT || ', OVERRIDE';

      V_SQL_VALUES := V_SQL_VALUES || ', MAIN_S_OVERRIDE';
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'OVRSL' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'OVRSL' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'OVRSL' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_OVERRIDE_SELECT := v_select_hint || ' S.' || V_ENTITY_COLUMN || REPLACE(PIN_ADD_ATTRIBUTE_COLUMNS, ',', ',S.') || '
                              , S.' ||
                           PIN_CURRENT_PERIOD_COLUMN || '
                                ' ||
                           V_PROJECTED_ALIAS ||
                            CASE WHEN PIN_TOTAL_PAYMENT = 1 THEN ''
                                 ELSE ', ' || V_TOTAL_EARNINGS_COMP_TOTAL
                            END || ' ' ||
                           (CASE
                             WHEN PIN_PRIOR_PERIOD_IDS IS NOT NULL THEN
                              ', PRIOR_PERIOD_PAYMENTS, CURRENT_PERIOD_PAYMENT'
                             ELSE
                              ''
                           END) || (CASE
                             WHEN PIN_APPLY_DRAWS = 0 THEN
                              ', GUARANTEE_AMOUNT, PAYMENT_AFTER_DRAW'
                             WHEN PIN_APPLY_DRAWS = 1 THEN
                              ', RECOVERABLE_DRAW_AMOUNT, PRIOR_PERIOD_DRAW_BALANCE, DRAW_BALANCE, PAYMENT_AFTER_DRAW'
                             WHEN PIN_APPLY_DRAWS = 2 THEN
                              ', GUARANTEE_AMOUNT, RECOVERABLE_DRAW_AMOUNT, PRIOR_PERIOD_DRAW_BALANCE, DRAW_BALANCE, PAYMENT_AFTER_DRAW'
                             ELSE
                              ''
                           END) || (CASE
                             WHEN V_CNT > 0 THEN
                              ', ADJUSTMENT'
                             ELSE
                              ''
                           END) || '
                              , OVR.OVERRIDE, COALESCE(OVR.OVERRIDE, S.PAYMENT_DUE) AS PAYMENT_DUE
                              FROM (';
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'OVRFR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'OVRFR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'OVRFR' || V_INPUT_TABLE_REC.INPUT_NUMBER || '_COMP', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_OVERRIDE_FROM := ') S LEFT JOIN (' || v_select_hint || ' * FROM ' ||
                         V_INPUT_TABLE_REC.TABLE_NAME || (CASE
                           WHEN V_INPUT_TABLE_REC.WHERE_CLAUSE IS NULL THEN
                            ''
                           ELSE
                            ' WHERE ' || V_INPUT_TABLE_REC.WHERE_CLAUSE
                         END) || ') OVR ON S.' || V_ENTITY_COLUMN || ' = OVR.' ||
                         V_ENTITY_COLUMN || REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REGEXP_REPLACE(V_ADD_ATT_JOIN_COLS, '([^-]+)', ' AND S.\1 = OVR.\1'), '-', ''), 'S.COALESCE(UPPER(', 'COALESCE(UPPER(S.'), 'OVR.COALESCE(UPPER(', 'COALESCE(UPPER(OVR.'), 'S.COALESCE(', 'COALESCE(S.'), 'OVR.COALESCE(', 'COALESCE(OVR.');
    END IF;
    /***overrides>>>***/
    -- generic hint
    v_insert_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'INSERT_ALL_OVER' || PIN_COMPONENT_ID, pin_ver_object_id);
    --
    v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'INSERT_ALL_OVER' || PIN_COMPONENT_ID, pin_ver_object_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'INSERT_ALL_OVER', pin_ver_object_id, replace(replace(v_insert_hint, '/*+'), '*/'));

    V_SQL := ' ' || v_insert_hint || ' ALL ' || V_SQL_INSERT_ALL || ' WHEN ' ||
             V_VAL_NO_FALL_INSERT || ' THEN INTO ' || V_OUTPUT_TABLE || '(' ||
             CASE
               WHEN (PIN_PRIOR_PERIOD_IDS IS NULL AND v_component_number IS NOT NULL) THEN 'CURRENT_PERIOD_PAYMENT, '
               ELSE ''
             END || 'PROCESSED_DATE_TIME, ' ||
             V_SQL_INSERT || ') VALUES (' ||
             CASE
               WHEN (PIN_PRIOR_PERIOD_IDS IS NULL AND v_component_number IS NOT NULL) THEN 'MAIN_S_TOTAL_EARNINGS, '
               ELSE ''
             END || 'cast(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' as date), ' ||
             REPLACE(
             CASE
               WHEN (PIN_PRIOR_PERIOD_IDS IS NULL AND v_component_number IS NOT NULL) THEN REPLACE(V_SQL_VALUES,'MAIN_S_PRIOR_PERIOD_PAYMENTS','0')
               ELSE V_SQL_VALUES
             END
             ,
                     'ROW_IDENTIFIER',
                     commons_appframework.get_row_identifier_sequence (V_OUTPUT_TABLE, NULL) || '.NEXTVAL') || ')' ||
             (CASE
               WHEN V_ROSTER_TYPE = 0 AND PIN_VLD_WHEN IS NOT NULL THEN
                PIN_VLD_WHEN
               ELSE
                ''
             END) || V_SQL_SELECT || (CASE
               WHEN V_ROSTER_TYPE = 0 AND PIN_VLD_SELECT IS NOT NULL THEN
                PIN_VLD_SELECT
               ELSE
                ''
             END) || ', ENT.' || PIN_ENTITY_KEY || V_VAL_NO_FALL_SELECT ||
            CASE
               WHEN (V_IS_DRAW) OR (V_ROSTER_TYPE = 0 AND (PIN_VLD_FROM IS NOT NULL OR PIN_VLD_WHEN IS NOT NULL OR PIN_VLD_SELECT IS NOT NULL)) THEN
                  V_ADD_ATT_VALID_COLS
               ELSE
                ''
             END ||
             ' FROM (' || V_OVERRIDE_SELECT || V_ADJUSTMENTS_SELECT ||
             V_DRAWS_SELECT || V_PRIORPP_SELECT || V_AGG_SELECT ||
             V_PRIORPP_FROM || V_DRAWS_FROM || V_ADJUSTMENTS_FROM ||
             V_OVERRIDE_FROM || ' ) MAIN_S  INNER JOIN ' ||
             V_ENTITY_TABLE || ' ENT ON MAIN_S.' || V_ENTITY_COLUMN ||
             ' = ENT.E_INTERNAL_ID ' || V_VAL_NO_FALL_JOIN || (CASE
               WHEN V_ROSTER_TYPE = 0 AND PIN_VLD_FROM IS NOT NULL THEN
                  PIN_VLD_FROM
               ELSE
                ''
             END) ||
             (CASE
               WHEN (V_IS_DRAW) OR (V_ROSTER_TYPE = 0 AND (PIN_VLD_FROM IS NOT NULL OR PIN_VLD_WHEN IS NOT NULL OR PIN_VLD_SELECT IS NOT NULL)) THEN
                  ' ' || V_ADD_ATT_VALID_JOINS || ' '
               ELSE
                ''
             END);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCLOB(V_SQL),
                             'v_sql := <value>',
                             V_STAMP);

    EXECUTE IMMEDIATE V_SQL;


  -- count the total number of inserts
  V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;


  SELECT COUNT(*)
  INTO V_TEMP_PAY_VALIDATIONS_COUNT
  FROM TEMP_PAYMENT_VALIDATIONS;

  V_TEMP_PAY_VALIDATIONS_CNT := V_TEMP_PAY_VALIDATIONS_COUNT - COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PAYMENT_VALIDATIONS');

  COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PAYMENT_VALIDATIONS', V_TEMP_PAY_VALIDATIONS_COUNT);

  SELECT COUNT(*)
  INTO V_TEMP_UI_VALIDATION_COUNT
  FROM TEMP_UI_VALIDATION_VALUES;

    V_TEMP_UI_VALIDATION_CNT := V_TEMP_UI_VALIDATION_COUNT - COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PAYMENT_VALIDATIONS');

  COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_UI_VALIDATION_VALUES', V_TEMP_UI_VALIDATION_CNT);

  -- set the number of inserts in the output table
  V_TOTAL_ROWCOUNT := V_TOTAL_ROWCOUNT - V_TEMP_UI_VALIDATION_COUNT - V_TEMP_PAY_VALIDATIONS_CNT;

  -- prepare the columns for existence check in TEMP_PAYMENT_VALIDATIONS
  FOR i IN 2 .. NVL(REGEXP_COUNT(PIN_ADD_ATTRIBUTE_COLUMNS, ',')+1, 0) LOOP
      V_CHECK_IN := V_CHECK_IN || ', UI.C' || i;
  END LOOP;

    --validation on all output table for selected roster scenario
    IF V_ROSTER_TYPE = 1 AND PIN_VLD_GET_VALUES IS NOT NULL THEN
      -- generic hint
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'INSERT_ALL_ROSTER' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_insert_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'INSERT_ALL_ROSTER' || PIN_COMPONENT_ID, pin_ver_object_id) || 'INSERT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'INSERT_ALL_ROSTER', pin_ver_object_id, replace(replace(v_insert_hint, '/*+'), '*/'));
      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'INSERT_ROSTER_SEL' || PIN_COMPONENT_ID, pin_ver_object_id);
      --
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'INSERT_ROSTER_SEL' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'INSERT_ROSTER_SEL', pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

      V_SQL := v_insert_hint || ' ALL ' || (CASE
                 WHEN PIN_VLD_WHEN IS NOT NULL THEN
                  PIN_VLD_WHEN
                 ELSE
                  ''
               END) || V_SQL_SELECT || (CASE
                 WHEN PIN_VLD_SELECT IS NOT NULL THEN
                  PIN_VLD_SELECT
                 ELSE
                  ''
               END) || ', ENT.' || PIN_ENTITY_KEY ||
               CASE
                 WHEN (PIN_VLD_FROM IS NOT NULL OR PIN_VLD_WHEN IS NOT NULL OR PIN_VLD_SELECT IS NOT NULL OR V_IS_DRAW) IS NOT NULL THEN
                    V_ADD_ATT_VALID_COLS
                 ELSE
                  ''
               END || ' FROM (' ||
               ' ' || v_select_hint || ' * FROM ' || V_OUTPUT_TABLE || ' WHERE ' ||
               PIN_CURRENT_PERIOD || ' = ' || PIN_CURRENT_PERIOD_COLUMN ||
               ' ) MAIN_S INNER JOIN ' || V_ENTITY_TABLE ||
               ' ENT ON MAIN_S.' || V_ENTITY_COLUMN ||
               ' = ENT.E_INTERNAL_ID ' || (CASE
               WHEN PIN_VLD_FROM IS NOT NULL THEN
                  PIN_VLD_FROM
               ELSE
                ''
             END) ||
             (CASE
               WHEN (PIN_VLD_FROM IS NOT NULL OR PIN_VLD_WHEN IS NOT NULL OR PIN_VLD_SELECT IS NOT NULL OR V_IS_DRAW) IS NOT NULL THEN
                  ' ' || V_ADD_ATT_VALID_JOINS || ' '
               ELSE
                ''
             END);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_SQL),
                               'v_sql := <value>',
                               V_STAMP);
      EXECUTE IMMEDIATE V_SQL;
    ELSIF (PIN_VLD_GET_VALUES IS NOT NULL) THEN

        -- get the additional attributes entities and fields
        SELECT OBJTYPE_NAME_MAP(max('E' || e.entity_id), BB.AA)
          BULK COLLECT INTO VCOL_COL_ENT_NAME_COLS
          FROM
                (select regexp_substr(PIN_ADD_ATTRIBUTE_COLUMNS,'[^ ,]+', 1, level) AA, level as LVL from dual
                connect by regexp_substr(PIN_ADD_ATTRIBUTE_COLUMNS, '[^ ,]+', 1, level) is not null) BB
          INNER JOIN table_columns tc ON bb.AA = tc.tc_physical_name
          LEFT JOIN  entities e       ON tc.tc_entity_id = e.entity_id
          GROUP BY BB.AA, BB.LVL
          ORDER BY BB.LVL;

          FOR i IN 1 .. VCOL_COL_ENT_NAME_COLS.COUNT
          LOOP
            -- check if the additional attribute is field of entity
            IF (VCOL_COL_ENT_NAME_COLS(I).NAME1 = 'E') THEN
              -- create the column list
              V_VALIDATION_COLUMNS := V_VALIDATION_COLUMNS || ', COALESCE(TO_CHAR(PR.C' || i ||  '), CHR(0))';
            ELSE
              -- create the column list
              V_VALIDATION_COLUMNS := V_VALIDATION_COLUMNS || ', COALESCE(TO_CHAR(ET' || i || '.' || commons.FIND_ENT_BUSINESS_KEY_BY_NAME(VCOL_COL_ENT_NAME_COLS(I).NAME1) || '), CHR(0))';
              -- create the join
              V_VALIDATION_JOINS   := V_VALIDATION_JOINS   || ' INNER JOIN ' || commons.FIND_ENT_TABLE_NAME(VCOL_COL_ENT_NAME_COLS(I).NAME1) || ' ET' || i ||
                                                              ' ON PR.C' || i ||  ' = ET' || i || '.E_INTERNAL_ID';
            END IF;
            -- create the cols for TEMP_PROC_VALIDATION_VALUES
            V_PROC_VALIDATION_COLS := V_PROC_VALIDATION_COLS || ', COALESCE(TO_CHAR(PR.CALC_ENTITY_' || i || '_ID), CHR(0))';
          END LOOP;

      -- generic hint
      v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'TEMP_PROC', pin_ver_object_id, 'CARDINALITY(TEMP_PROC_VALIDATION_VALUES ' || V_TEMP_PROC_VALIDATION_COUNT || ')');
      v_delete_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_UI_PROC', pin_ver_object_id, 'CARDINALITY(TEMP_UI_VALIDATION_VALUES ' || V_TEMP_PROC_VALIDATION_COUNT || ')');

      -- prepare the hint and cardinality framework
      v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DELETE_TEMP_PROC' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_TEMP_PROC' || PIN_COMPONENT_ID, pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));
      v_delete_hint := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DELETE_UI_PROC' || PIN_COMPONENT_ID, pin_ver_object_id) || 'DELETE ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_UI_PROC' || PIN_COMPONENT_ID, pin_ver_object_id, replace(replace(v_delete_hint, '/*+'), '*/'));

      -- create the query
      V_SQL := v_delete_hint || ' FROM TEMP_UI_VALIDATION_VALUES UI
                                        WHERE (UI.C1' || V_CHECK_IN || ') IN
                                         (' || v_select_hint || ' TO_CHAR(ET.' || PIN_ENTITY_KEY || ')' || V_PROC_VALIDATION_COLS || '
                                          FROM TEMP_PROC_VALIDATION_VALUES PR
                                          INNER JOIN ' || V_ENTITY_TABLE || ' ET ON PR.PAYMENT_ENTITY_ID = ET.E_INTERNAL_ID)';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_SQL),
                               'v_delete_UI_vld1_sql := <value>',
                               V_STAMP);
      EXECUTE IMMEDIATE V_SQL;

    -- update the cardinality of the gtt
    V_TEMP_UI_VALIDATION_COUNT := V_TEMP_UI_VALIDATION_COUNT - SQL%ROWCOUNT;
    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_UI_VALIDATION_VALUES', V_TEMP_UI_VALIDATION_COUNT);

    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_TEMP_PAY', pin_ver_object_id, 'CARDINALITY(TEMP_PAYMENT_VALIDATIONS ' || V_TEMP_PROC_VALIDATION_COUNT || ')');
    v_delete_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_UI_PROC2', pin_ver_object_id, 'CARDINALITY(TEMP_UI_VALIDATION_VALUES ' || V_TEMP_PROC_VALIDATION_COUNT || ')');

    -- set hints
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DELETE_TEMP_PAY' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_TEMP_PAY' || PIN_COMPONENT_ID, pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));
    v_delete_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DELETE_UI_PROC2' || PIN_COMPONENT_ID, pin_ver_object_id) || 'DELETE ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_UI_PROC2' || PIN_COMPONENT_ID, pin_ver_object_id, replace(replace(v_delete_hint, '/*+'), '*/'));

    -- prepare the query
      V_SQL := v_delete_hint || ' FROM TEMP_UI_VALIDATION_VALUES UI
                                  WHERE (UI.C1' || V_CHECK_IN || ') IN
                                         (' || v_select_hint || ' TO_CHAR(ET.' || PIN_ENTITY_KEY || ')' || V_VALIDATION_COLUMNS || '
                                          FROM TEMP_PAYMENT_VALIDATIONS PR
                                          INNER JOIN ' || V_ENTITY_TABLE || ' ET ON PR.PAYMENT_ENTITY = ET.E_INTERNAL_ID' || V_VALIDATION_JOINS || ')';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                               ANYDATA.CONVERTCLOB(V_SQL),
                               'v_delete_UI_vld2_sql := <value>',
                               V_STAMP);
      EXECUTE IMMEDIATE V_SQL;

   COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_UI_VALIDATION_VALUES', V_TEMP_UI_VALIDATION_COUNT - SQL%ROWCOUNT);
    END IF;

    --when a detailed erorr is needed, a result set will be outputed

    IF PIN_VLD_GET_VALUES IS NOT NULL THEN
      OPEN POUT_VLD_RESULT FOR PIN_VLD_GET_VALUES
        USING V_TOTAL_ROWCOUNT;
    ELSE
      OPEN POUT_VLD_RESULT FOR
        SELECT NULL AS VALIDATION_ID,
               NULL AS VALIDATION_TYPE,
               NULL AS VALIDATION_ENT_CNT,
               NULL AS VALIDATION_DETAILS
          FROM DUAL
         WHERE 1 = 0;
    END IF;

    POUT_ROWS_IN_OUTPUT := V_TOTAL_ROWCOUNT;

    -- generic hint
    v_select_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_PAY_NOT_VALID', pin_ver_object_id, 'CARDINALITY(TEMP_PAYMENT_VALIDATIONS ' || V_TEMP_PROC_VALIDATION_COUNT || ')');
    v_delete_hint :=  COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_PAY_VALID', pin_ver_object_id, 'CARDINALITY(TEMP_PAYMENT_VALIDATIONS ' || V_TEMP_PROC_VALIDATION_COUNT || ')');

    -- prepare the cardinality hint
    v_delete_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DELETE_PAY_NOT_VALID' || PIN_COMPONENT_ID, pin_ver_object_id) || 'DELETE ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_PAY_NOT_VALID' || PIN_COMPONENT_ID, pin_ver_object_id, replace(replace(v_delete_hint, '/*+'), '*/'));
    v_select_hint :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('PAYMENT_PROCESSING', 'DELETE_PAY_VALID' || PIN_COMPONENT_ID, pin_ver_object_id) || 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('PAYMENT_PROCESSING', 'DELETE_PAY_VALID' || PIN_COMPONENT_ID, pin_ver_object_id, replace(replace(v_select_hint, '/*+'), '*/'));

    --delete duplicates from temp table validation - defect OF-580
    EXECUTE IMMEDIATE v_delete_hint || ' FROM TEMP_PAYMENT_VALIDATIONS
             WHERE ROWID NOT IN
                 (' || v_select_hint || ' MIN(ROWID)
                  FROM TEMP_PAYMENT_VALIDATIONS
                 GROUP BY PAYMENT_ENTITY' || V_PAY_VALID_COLS || ', VALIDATION_TYPE)';

  -- set new gtt cardinality
   COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PAYMENT_VALIDATIONS', V_TEMP_PAY_VALIDATIONS_COUNT - SQL%ROWCOUNT);


  END CALCULATE_COMPLETE_PAYMENT;


  /*
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  ----------------------------
  */


  PROCEDURE CALCULATE_PAYMENT(PIN_INPUT_LIST               IN  TABLETYPE_INPUT_TABLE_LIST,
                              PIN_COMP_PRIOR_PERIOD_LIST   IN  TABLETYPE_COMP_PERIOD_LIST,
                              PIN_CURRENT_PERIOD           IN  NUMERIC,
                              PIN_CURRENT_PERIOD_COLUMN    IN  VARCHAR2,
                              PIN_PROJECTED_PERIOD         IN  NUMERIC,
                              PIN_PROJECTED_PERIOD_COLUMN  IN  VARCHAR2,
                              PIN_PROJECTED                IN  NUMBER,
                              PIN_PRIOR_PERIOD_IDS         IN  VARCHAR2,
                              PIN_EARN_ENTITY_COLUMN       IN  VARCHAR2,
                              PIN_PAY_ENTITY_COLUMN        IN  VARCHAR2,
                              PIN_PAY_ATTRIBUTE_COLUMNS    IN  VARCHAR2,
                              PIN_ADD_ATTRIBUTE_COLUMNS    IN  VARCHAR2,
                              PIN_APPLY_DRAWS              IN  NUMBER,
                              PIN_CONSTANT_DRAW            IN  NUMBER,
                              PIN_RECOVERABLE_PRIOR_PERIOD IN  NUMBER,
                              PIN_ENTITY_KEY               IN  VARCHAR2,
                              PIN_VER_OBJECT_ID            IN  NUMBER,
                              PIN_0_PAYMENT                IN  NUMBER,
							  PIN_ROSTER_BY_COMPONENT	   IN  NUMBER,
                              PIN_VLD_WHEN                 IN  CLOB,
                              PIN_VLD_SELECT               IN  CLOB,
                              PIN_VLD_FROM                 IN  CLOB,
                              PIN_VLD_GET_VALUES           IN  CLOB,
                              POUT_VLD_RESULT              OUT SYS_REFCURSOR,
                              POUT_ROWS_IN_OUTPUT          OUT NUMBER) AS

        v_input_comp_list  TABLETYPE_INPUT_TABLE_LIST;
        v_input_full_list  TABLETYPE_INPUT_TABLE_LIST;
        V_WHERE_CLAUSE     VARCHAR2(32767);
        v_output_list      TABLETYPE_COMP_PERIOD_LIST;
        v_prior_exists     NUMBER(1);
        v_dummy_record1    SYS_REFCURSOR;
        v_dummy_record2    NUMBER;

   BEGIN
          V_STAMP := 'PAYMENT_PROCESSING.CALCULATE_PAYMENT - ' ||
                     TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

          BEGIN
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTCOLLECTION(PIN_INPUT_LIST),
                                     ',pin_input_list => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTCOLLECTION(PIN_COMP_PRIOR_PERIOD_LIST),
                                     ',PIN_COMP_PRIOR_PERIOD_LIST => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_CURRENT_PERIOD),
                                     ',pin_current_period => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_CURRENT_PERIOD_COLUMN),
                                     ',pin_current_period_column => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_PROJECTED_PERIOD),
                                     ',pin_projected_period => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_PROJECTED_PERIOD_COLUMN),
                                     ',pin_projected_period_column => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_PROJECTED),
                                     ',pin_projected => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_PRIOR_PERIOD_IDS),
                                     ',pin_prior_period_ids => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_EARN_ENTITY_COLUMN),
                                     ',pin_earn_entity_column => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_PAY_ENTITY_COLUMN),
                                     ',pin_pay_entity_column => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_PAY_ATTRIBUTE_COLUMNS),
                                     ',pin_pay_attribute_columns => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_ADD_ATTRIBUTE_COLUMNS),
                                     ',pin_add_attribute_columns => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_APPLY_DRAWS),
                                     ',pin_apply_draws => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_CONSTANT_DRAW),
                                     ',pin_constant_draw => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_RECOVERABLE_PRIOR_PERIOD),
                                     ',pin_recoverable_prior_period => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_ENTITY_KEY),
                                     ',pin_entity_key => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTVARCHAR2(PIN_VER_OBJECT_ID),
                                     ',pin_ver_object_id => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTNUMBER(PIN_0_PAYMENT),
                                     ',pin_0_payment => <value>',
                                     V_STAMP);
			L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
									 ANYDATA.CONVERTNUMBER(PIN_ROSTER_BY_COMPONENT),
									 ',pin_roster_by_component => <value>',
									 V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTCLOB(PIN_VLD_WHEN),
                                     ',pin_vld_when => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTCLOB(PIN_VLD_SELECT),
                                     ',pin_vld_select => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTCLOB(PIN_VLD_FROM),
                                     ',pin_vld_from => <value>',
                                     V_STAMP);
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                                     ANYDATA.CONVERTCLOB(PIN_VLD_GET_VALUES),
                                     ',pin_vld_get_values => <value>',
                                     V_STAMP);
          END;

    SELECT COUNT(*)
    INTO V_TEMP_PAY_VALIDATIONS_CNT
    FROM TEMP_PAYMENT_VALIDATIONS;

    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PAYMENT_VALIDATIONS', V_TEMP_PAY_VALIDATIONS_CNT);

    SELECT COUNT(*)
    INTO V_TEMP_PROC_VALIDATION_COUNT
    FROM TEMP_PROC_VALIDATION_VALUES;

    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES', V_TEMP_PROC_VALIDATION_COUNT);

  SELECT COUNT(*)
  INTO V_TEMP_UI_VALIDATION_CNT
  FROM TEMP_UI_VALIDATION_VALUES;

  COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_UI_VALIDATION_VALUES', V_TEMP_UI_VALIDATION_CNT);

     IF (PIN_COMP_PRIOR_PERIOD_LIST IS NULL) THEN
       CALCULATE_COMPLETE_PAYMENT(PIN_INPUT_LIST               => PIN_INPUT_LIST,
                                  PIN_CURRENT_PERIOD           => pin_current_period,
                                  PIN_CURRENT_PERIOD_COLUMN    => pin_current_period_column,
                                  PIN_PROJECTED_PERIOD         => pin_projected_period,
                                  PIN_PROJECTED_PERIOD_COLUMN  => PIN_PROJECTED_PERIOD_COLUMN,
                                  PIN_PROJECTED                => pin_projected,
                                  PIN_PRIOR_PERIOD_IDS         => PIN_PRIOR_PERIOD_IDS,
                                  PIN_EARN_ENTITY_COLUMN       => PIN_EARN_ENTITY_COLUMN,
                                  PIN_PAY_ENTITY_COLUMN        => PIN_PAY_ENTITY_COLUMN,
                                  PIN_OLD_EARN_ENTITY_COLUMN   => NULL,
                                  PIN_PAY_ATTRIBUTE_COLUMNS    => pin_pay_attribute_columns,
                                  PIN_ADD_ATTRIBUTE_COLUMNS    => pin_add_attribute_columns,
                                  PIN_APPLY_DRAWS              => PIN_APPLY_DRAWS,
                                  PIN_CONSTANT_DRAW            => PIN_CONSTANT_DRAW,
                                  PIN_RECOVERABLE_PRIOR_PERIOD => PIN_RECOVERABLE_PRIOR_PERIOD,
                                  PIN_ENTITY_KEY               => pin_entity_key,
                                  PIN_VER_OBJECT_ID            => pin_ver_object_id,
                                  PIN_COMPONENT_ID             => NULL,
                                  PIN_0_PAYMENT                => PIN_0_PAYMENT,
								  PIN_ROSTER_BY_COMPONENT	   => NULL,
                                  PIN_TOTAL_PAYMENT            => NULL,
                                  PIN_VLD_WHEN                 => pin_vld_when,
                                  PIN_VLD_SELECT               => pin_vld_select,
                                  PIN_VLD_FROM                 => pin_vld_from,
                                  PIN_VLD_GET_VALUES           => pin_vld_get_values,

                                  POUT_VLD_RESULT              => POUT_VLD_RESULT,
                                  POUT_ROWS_IN_OUTPUT          => POUT_ROWS_IN_OUTPUT);

     ELSE

   -- remove the components, input, adjustment and override tables from the list
   SELECT OBJTYPE_INPUT_TABLE_LIST(TABLE_NAME,
                                   FROM_CLAUSE,
                                   WHERE_CLAUSE,
                                   TABLE_TYPE,
                                   INPUT_NUMBER) BULK COLLECT
     INTO V_INPUT_COMP_LIST
     FROM TABLE(PIN_INPUT_LIST)
    WHERE TABLE_TYPE <> 22
      AND TABLE_TYPE <> 23;

      -- select the component output tables
    SELECT OBJTYPE_COMP_PERIODS(TABLE_NAME, PRIOR_PERIOD_IDS, INPUT_NUMBER)
      BULK COLLECT INTO v_output_list
      FROM TABLE(PIN_COMP_PRIOR_PERIOD_LIST)
     WHERE INPUT_NUMBER > 0
     ORDER BY INPUT_NUMBER;

   -- iterate the components list which have a time unit run for
   FOR i IN v_output_list.FIRST .. v_output_list.LAST
     LOOP
       -- without the adjustment and override tables from the list and only one component
       SELECT OBJTYPE_INPUT_TABLE_LIST(TABLE_NAME,
                                       FROM_CLAUSE,
                                       WHERE_CLAUSE,
                                       TABLE_TYPE,
                                       INPUT_NUMBER) BULK COLLECT
         INTO v_input_full_list
         FROM TABLE(v_input_comp_list)
        WHERE TABLE_TYPE <> 2 OR (TABLE_TYPE = 2 AND INPUT_NUMBER = v_output_list(i).INPUT_NUMBER)
        UNION ALL
       SELECT OBJTYPE_INPUT_TABLE_LIST(v_output_list(i).TABLE_NAME,
                                       NULL,
                                       NULL,
                                       31,
                                       v_output_list(i).INPUT_NUMBER)
         FROM dual
        UNION ALL
       SELECT OBJTYPE_INPUT_TABLE_LIST(PRIOR_LIST.TABLE_NAME,
                                       NULL,
                                       PRIOR_LIST.PRIOR_PERIOD_IDS,
                                       32,
                                       PRIOR_LIST.INPUT_NUMBER)
         FROM TABLE(PIN_COMP_PRIOR_PERIOD_LIST) PRIOR_LIST
       WHERE PRIOR_LIST.INPUT_NUMBER = -v_output_list(i).INPUT_NUMBER;

     -- check to see if there is at least a prior period table
       BEGIN
         SELECT 1
           INTO v_prior_exists
           FROM dual WHERE EXISTS (SELECT 1
                                     FROM TABLE(PIN_COMP_PRIOR_PERIOD_LIST) PRIOR_LIST
                                    WHERE PRIOR_LIST.INPUT_NUMBER = -v_output_list(i).INPUT_NUMBER);
       EXCEPTION
         WHEN NO_DATA_FOUND
           THEN NULL;
       END;

         SELECT WHERE_CLAUSE
         INTO   V_WHERE_CLAUSE
         FROM TABLE(PIN_INPUT_LIST)
         WHERE INPUT_NUMBER = v_output_list(i).INPUT_NUMBER AND table_type = 2;

         -- calculate the payment per component
         CALCULATE_COMPLETE_PAYMENT(PIN_INPUT_LIST               => v_input_full_list,
                                    PIN_CURRENT_PERIOD           => substr(V_WHERE_CLAUSE, instr(V_WHERE_CLAUSE,'=')+2),
                                    PIN_CURRENT_PERIOD_COLUMN    => substr(V_WHERE_CLAUSE, 1, instr(V_WHERE_CLAUSE,'=')-2),
                                    PIN_PROJECTED_PERIOD         => CASE WHEN (substr(V_WHERE_CLAUSE, 1, instr(V_WHERE_CLAUSE,'=')-2) = PIN_PROJECTED_PERIOD_COLUMN) THEN PIN_CURRENT_PERIOD
                                                                         ELSE NULL END,
                                    PIN_PROJECTED_PERIOD_COLUMN  => CASE WHEN (substr(V_WHERE_CLAUSE, 1, instr(V_WHERE_CLAUSE,'=')-2) = PIN_PROJECTED_PERIOD_COLUMN) THEN PIN_CURRENT_PERIOD_COLUMN
                                                                         ELSE NULL END,
                                    PIN_PROJECTED                =>  CASE WHEN (substr(V_WHERE_CLAUSE, 1, instr(V_WHERE_CLAUSE,'=')-2) = PIN_PROJECTED_PERIOD_COLUMN) THEN PIN_PROJECTED
                                                                          ELSE NULL END,
                                    PIN_PRIOR_PERIOD_IDS         => v_prior_exists, -- from
                                    PIN_EARN_ENTITY_COLUMN       => PIN_EARN_ENTITY_COLUMN,
                                    PIN_PAY_ENTITY_COLUMN        => PIN_PAY_ENTITY_COLUMN,
                                    PIN_OLD_EARN_ENTITY_COLUMN   => NULL,
                                    PIN_PAY_ATTRIBUTE_COLUMNS    => pin_pay_attribute_columns,
                                    PIN_ADD_ATTRIBUTE_COLUMNS    => pin_add_attribute_columns,
                                    PIN_APPLY_DRAWS              => NULL,
                                    PIN_CONSTANT_DRAW            => NULL,
                                    PIN_RECOVERABLE_PRIOR_PERIOD => NULL,
                                    PIN_ENTITY_KEY               => pin_entity_key,
                                    PIN_VER_OBJECT_ID            => pin_ver_object_id,
                                    PIN_COMPONENT_ID             => v_output_list(i).INPUT_NUMBER,
                                    PIN_0_PAYMENT                => PIN_0_PAYMENT,
									PIN_ROSTER_BY_COMPONENT	 	 => PIN_ROSTER_BY_COMPONENT,
                                    PIN_TOTAL_PAYMENT            => NULL,
                                    PIN_VLD_WHEN                 => NULL,
                                    PIN_VLD_SELECT               => NULL,
                                    PIN_VLD_FROM                 => NULL,
                                    PIN_VLD_GET_VALUES           => NULL,

                                    POUT_VLD_RESULT              => POUT_VLD_RESULT,
                                    POUT_ROWS_IN_OUTPUT          => POUT_ROWS_IN_OUTPUT,
                                    PIN_CALCULATE_COMPONENT      => 1);
   END LOOP;

   -- get the tablelist by changing the component earnings table with a prior component table
    SELECT OBJTYPE_INPUT_TABLE_LIST(TABLE_NAME,
                                   FROM_CLAUSE,
                                   WHERE_CLAUSE,
                                   CASE WHEN TABLE_TYPE = 1 THEN 0
                                        WHEN TABLE_TYPE = 15 THEN 14
                                        ELSE TABLE_TYPE
                                   END,
                                   INPUT_NUMBER) BULK COLLECT
     INTO v_input_full_list
     FROM TABLE(PIN_INPUT_LIST)
     WHERE TABLE_TYPE <> 2
     UNION ALL
     SELECT OBJTYPE_INPUT_TABLE_LIST(a.TABLE_NAME,
                                   1,
                                   b.WHERE_CLAUSE,
                                   2,
                                   a.INPUT_NUMBER)
     FROM TABLE(v_output_list) a
     INNER JOIN TABLE(PIN_INPUT_LIST) b
     ON a.INPUT_NUMBER = b.INPUT_NUMBER;

   -- do the aggregation of the components
   CALCULATE_COMPLETE_PAYMENT(PIN_INPUT_LIST               => v_input_full_list,
                              PIN_CURRENT_PERIOD           => pin_current_period,
                              PIN_CURRENT_PERIOD_COLUMN    => pin_current_period_column,
                              PIN_PROJECTED_PERIOD         => pin_projected_period,
                              PIN_PROJECTED_PERIOD_COLUMN  => PIN_PROJECTED_PERIOD_COLUMN,
                              PIN_PROJECTED                => pin_projected,
                              PIN_PRIOR_PERIOD_IDS         => NULL,
                              PIN_EARN_ENTITY_COLUMN       => NVL(PIN_PAY_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN),
                              PIN_PAY_ENTITY_COLUMN        => NULL,
                              PIN_OLD_EARN_ENTITY_COLUMN   => PIN_EARN_ENTITY_COLUMN,
                              PIN_PAY_ATTRIBUTE_COLUMNS    => NULL,
                              PIN_ADD_ATTRIBUTE_COLUMNS    => pin_add_attribute_columns,
                              PIN_APPLY_DRAWS              => PIN_APPLY_DRAWS,
                              PIN_CONSTANT_DRAW            => PIN_CONSTANT_DRAW,
                              PIN_RECOVERABLE_PRIOR_PERIOD => PIN_RECOVERABLE_PRIOR_PERIOD,
                              PIN_ENTITY_KEY               => pin_entity_key,
                              PIN_VER_OBJECT_ID            => pin_ver_object_id,
                              PIN_COMPONENT_ID             => NULL,
                              PIN_0_PAYMENT                => PIN_0_PAYMENT,
							  PIN_ROSTER_BY_COMPONENT	   => NULL,
                              PIN_TOTAL_PAYMENT            => NULL,
                              PIN_VLD_WHEN                 => pin_vld_when,
                              PIN_VLD_SELECT               => pin_vld_select,
                              PIN_VLD_FROM                 => pin_vld_from,
                              PIN_VLD_GET_VALUES           => pin_vld_get_values,

                              POUT_VLD_RESULT              => POUT_VLD_RESULT,
                              POUT_ROWS_IN_OUTPUT          => POUT_ROWS_IN_OUTPUT);


       END IF;

     IF (pin_add_attribute_columns IS NOT NULL) THEN

       -- change the table input list
       SELECT OBJTYPE_INPUT_TABLE_LIST(TABLE_NAME,
                                     FROM_CLAUSE,
                                     WHERE_CLAUSE,
                                     case WHEN TABLE_TYPE = 33 THEN 24
                                          WHEN TABLE_TYPE = 24 THEN 2
                                          WHEN TABLE_TYPE = 1  THEN 0
                                          WHEN TABLE_TYPE = 15 THEN 14
                                          ELSE TABLE_TYPE
                                     END,
                                     INPUT_NUMBER) BULK COLLECT
       INTO v_input_full_list
       FROM TABLE(PIN_INPUT_LIST)
       WHERE TABLE_TYPE IN (0, 1, 11, 14, 15, 16, 24, 30, 33);

      -- do the total payment
       CALCULATE_COMPLETE_PAYMENT(PIN_INPUT_LIST               => v_input_full_list,
                                  PIN_CURRENT_PERIOD           => pin_current_period,
                                  PIN_CURRENT_PERIOD_COLUMN    => pin_current_period_column,
                                  PIN_PROJECTED_PERIOD         => pin_projected_period,
                                  PIN_PROJECTED_PERIOD_COLUMN  => PIN_PROJECTED_PERIOD_COLUMN,
                                  PIN_PROJECTED                => pin_projected,
                                  PIN_PRIOR_PERIOD_IDS         => NULL,
                                  PIN_EARN_ENTITY_COLUMN       => NVL(PIN_PAY_ENTITY_COLUMN, PIN_EARN_ENTITY_COLUMN),
                                  PIN_PAY_ENTITY_COLUMN        => NULL,
                                  PIN_OLD_EARN_ENTITY_COLUMN   => NULL,
                                  PIN_PAY_ATTRIBUTE_COLUMNS    => NULL,
                                  PIN_ADD_ATTRIBUTE_COLUMNS    => NULL,
                                  PIN_APPLY_DRAWS              => NULL,
                                  PIN_CONSTANT_DRAW            => NULL,
                                  PIN_RECOVERABLE_PRIOR_PERIOD => NULL,
                                  PIN_ENTITY_KEY               => pin_entity_key,
                                  PIN_VER_OBJECT_ID            => pin_ver_object_id,
                                  PIN_COMPONENT_ID             => NULL,
                                  PIN_0_PAYMENT                => NULL,
								  PIN_ROSTER_BY_COMPONENT	   => NULL,
                                  PIN_TOTAL_PAYMENT            => 1,
                                  PIN_VLD_WHEN                 => NULL,
                                  PIN_VLD_SELECT               => NULL,
                                  PIN_VLD_FROM                 => NULL,
                                  PIN_VLD_GET_VALUES           => NULL,
                                  POUT_VLD_RESULT              => v_dummy_record1,
                                  POUT_ROWS_IN_OUTPUT          => v_dummy_record2);
    END IF;

   END CALCULATE_PAYMENT;


-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END PAYMENT_PROCESSING;
/
