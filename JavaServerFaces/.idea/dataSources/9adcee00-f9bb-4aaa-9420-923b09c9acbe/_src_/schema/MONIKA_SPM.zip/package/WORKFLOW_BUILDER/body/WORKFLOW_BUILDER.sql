CREATE PACKAGE BODY WORKFLOW_BUILDER AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type  : SPM
-- Product      : workflowmanagement
-- Module      : workflowbuilder
-- Requester    : Pantilimon, Narcisa
-- Author      : Dumitriu, Cosmin
-- Reviewer      :
-- Review date    :
-- Description    : Package that contains different utilities for workflowbuilder
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
-- *******************************    PUBLIC FUNCTIONS END         *******************************

-- *******************************    PUBLIC PROCEDURES START       *******************************

/*  PROCEDURE GET_WF_PROCESS_DIAGRAM
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:

  2012.03.27 - Dumitriu, Cosmin - created
  2012.05.30 - Dumitriu, Cosmin - added CHILD_OBJ_AVAILABILITY column
  ========================================================*/
PROCEDURE GET_WF_PROCESS_DIAGRAM
(   pi_wp_id    IN NUMBER
  ,po_diagram    OUT SYS_REFCURSOR
) AS
BEGIN
  OPEN po_diagram FOR
  SELECT
     PARENT_OBJ_TYPE
    ,PARENT_OBJ_ID
    ,PARENT_OBJ_NAME
    ,CHILD_OBJ_TYPE
    ,CHILD_OBJ_ID
    ,CHILD_OBJ_NAME
    ,CHILD_OBJ_AVAILABILITY
    ,ACTION_ID
    ,CHILD_ORDER
    ,MIN(RN) WF_ORDER
  FROM
    (SELECT
       ROWNUM RN
      ,PARENT_OBJ_TYPE
      ,PARENT_OBJ_ID
      ,PARENT_OBJ_NAME
      ,CHILD_OBJ_TYPE
      ,CHILD_OBJ_ID
      ,CHILD_OBJ_NAME
      ,CHILD_OBJ_AVAILABILITY
      ,ACTION_ID
      ,CHILD_ORDER
    FROM
      (SELECT
         'TA'        PARENT_OBJ_TYPE
        ,WTA_ID         PARENT_OBJ_ID
        ,WTA_NAME      PARENT_OBJ_NAME
        ,'A'        CHILD_OBJ_TYPE
        ,WFCA_ID        CHILD_OBJ_ID
        ,WFA_NAME      CHILD_OBJ_NAME
        ,WFA_AVAILABILITY  CHILD_OBJ_AVAILABILITY
        ,WFA_ID          ACTION_ID
        ,WFCA_ORDER      CHILD_ORDER
      FROM WF_ACTIONS
        INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID
        INNER JOIN WF_TASK_ASSIGNMENTS ON WFCA_WTA_ID = WTA_ID
      WHERE WTA_WP_ID = pi_wp_id

      UNION ALL
      SELECT
         CASE WHEN WFA_ID IS NULL THEN 'R' ELSE 'A' END PARENT_OBJ_TYPE
        ,WFCA_ID        PARENT_OBJ_ID
        ,WFA_NAME      PARENT_OBJ_NAME
        ,'TA'        CHILD_OBJ_TYPE
        ,WTA_ID         CHILD_OBJ_ID
        ,WTA_NAME      CHILD_OBJ_NAME
        ,NULL        CHILD_OBJ_AVAILABILITY
        ,WFA_ID          ACTION_ID
        ,WTAC_ORDER      CHILD_ORDER
      FROM WF_TA_ACTIVATIONS
        INNER JOIN WF_TASK_ASSIGNMENTS ON WTAC_WTA_ID = WTA_ID
        LEFT JOIN (select * from WF_ACTIONS INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID) ON WTAC_WFCA_ID = WFCA_ID

      WHERE WTA_WP_ID = pi_wp_id
      ) T
    START WITH PARENT_OBJ_ID IS NULL
    CONNECT BY PRIOR CHILD_OBJ_TYPE = PARENT_OBJ_TYPE AND PRIOR CHILD_OBJ_ID = PARENT_OBJ_ID
    ORDER SIBLINGS BY CHILD_ORDER
    )
  GROUP BY
     PARENT_OBJ_TYPE
    ,PARENT_OBJ_ID
    ,PARENT_OBJ_NAME
    ,CHILD_OBJ_TYPE
    ,CHILD_OBJ_ID
    ,CHILD_OBJ_NAME
    ,CHILD_OBJ_AVAILABILITY
    ,ACTION_ID
    ,CHILD_ORDER
  ORDER BY MIN(RN);
END GET_WF_PROCESS_DIAGRAM;


/*  PROCEDURE GET_NODE_TA_PARENT_LIST
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:

  2012.04.09 - Dumitriu, Cosmin - created
  2012.04.10 - Dumitriu, Cosmin
    * changed the output cursor. Now it returns the id and name of the task assignments, in alphabetical order
  ========================================================*/
PROCEDURE GET_NODE_TA_PARENT_LIST
(   pi_wp_id    IN NUMBER
  ,pi_node_id    IN NUMBER
  ,pi_node_type  IN VARCHAR2
  ,po_ta_list    OUT SYS_REFCURSOR
) AS
BEGIN
  OPEN po_ta_list FOR
  WITH WF AS
  (SELECT RN, LEVEL LVL, REGEXP_SUBSTR(PTH, '[^/]+', 1, LEVEL) NODE FROM
    (SELECT RN,PTH FROM
      (SELECT
         CHILD_OBJ_TYPE
        ,CHILD_OBJ_ID
        ,ROWNUM RN
        ,SYS_CONNECT_BY_PATH(CASE  WHEN CHILD_OBJ_TYPE = 'TA' THEN 'T'
                      ELSE CHILD_OBJ_TYPE END ||'_'||TO_CHAR(CHILD_OBJ_ID),'/') PTH
      FROM
        (SELECT
           'TA'      PARENT_OBJ_TYPE
          ,WTA_ID       PARENT_OBJ_ID
          ,WTA_NAME    PARENT_OBJ_NAME
          ,'A'      CHILD_OBJ_TYPE
          ,WFCA_ID      CHILD_OBJ_ID
          ,WFA_NAME    CHILD_OBJ_NAME
          ,WFCA_ORDER    CHILD_ORDER
        FROM WF_ACTIONS
          INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID
          INNER JOIN WF_TASK_ASSIGNMENTS ON WFCA_WTA_ID = WTA_ID
        WHERE WTA_WP_ID = pi_wp_id

        UNION ALL
        SELECT
           CASE WHEN WFA_ID IS NULL THEN 'R' ELSE 'A' END PARENT_OBJ_TYPE
          ,WFCA_ID      PARENT_OBJ_ID
          ,WFA_NAME    PARENT_OBJ_NAME
          ,'TA'      CHILD_OBJ_TYPE
          ,WTA_ID       CHILD_OBJ_ID
          ,WTA_NAME    CHILD_OBJ_NAME
          ,WTAC_ORDER    CHILD_ORDER
        FROM WF_TA_ACTIVATIONS
          INNER JOIN WF_TASK_ASSIGNMENTS ON WTAC_WTA_ID = WTA_ID
          LEFT JOIN (select * from WF_ACTIONS INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID) ON WTAC_WFCA_ID = WFCA_ID
        WHERE WTA_WP_ID = pi_wp_id
        ) T
      START WITH PARENT_OBJ_ID IS NULL
      CONNECT BY PRIOR CHILD_OBJ_TYPE = PARENT_OBJ_TYPE AND PRIOR CHILD_OBJ_ID = PARENT_OBJ_ID
      ORDER SIBLINGS BY CHILD_ORDER
      )
    WHERE CHILD_OBJ_TYPE = pi_node_type AND CHILD_OBJ_ID = pi_node_id
    )
    CONNECT BY INSTR(PTH, '/', 1, LEVEL - 1) > 0
      AND RN = PRIOR RN
      AND PRIOR DBMS_RANDOM.VALUE IS NOT NULL
  )
  select t.*, ca.wfca_wfa_id WFA_ID from (
  SELECT WTA_ID, WTA_NAME, A_ID WFCA_ID
  FROM
    (SELECT DISTINCT
       SUBSTR(WF1.NODE, 3, LENGTH(WF1.NODE)) TA_ID
      ,SUBSTR(WF2.NODE, 3, LENGTH(WF2.NODE)) A_ID
    FROM WF WF1 LEFT JOIN WF WF2 ON WF1.RN = WF2.RN AND WF1.LVL + 1 = WF2.LVL
    WHERE SUBSTR(WF1.NODE, 1, 1) = 'T'
    ) T
    LEFT JOIN WF_TASK_ASSIGNMENTS ON TA_ID = WTA_ID
  WHERE A_ID IS NOT NULL) t left outer join WF_COMMON_ACTIONS ca on t.WFCA_ID = ca.wfca_id
  ORDER BY WTA_NAME;
END GET_NODE_TA_PARENT_LIST;



procedure WF_RE_ROUTING_CREATION(pi_request_id          in number,
                                                   pi_request_table       in varchar2,
                                                   pi_task_id             in number,
                                                   pi_task_table          in varchar2,
                                                   pi_task_version        in number,
                                                   pi_re_reouting_table   in varchar2,
                                                   pi_sender_comments     in varchar2,
                                                   pi_sender_user_id      in varchar2,
                                                   pi_request_status_id   in number,
                                                   pi_task_entity_cols    in varchar2,
                                                   pi_request_entity_cols in varchar2,
                                                    po_status      out number,
                                                   po_returned_id out number) is
  v_requets_lock number;
  e_requets_lock EXCEPTION;
  v_task_lock number;
  e_task_lock EXCEPTION;
  v_multi_re_routing_val number;
  e_multi_re_routing_val EXCEPTION;
  v_sql                   clob;
  v_sql_values            clob;
  v_task_entity_values    varchar2(250 char);
  v_request_entity_values varchar2(250 char);
  v_re_reouting_table_id  number;
  v_autonumber            number;
  --OF-16999 start
  v_autonumber_refcursor  sys_refcursor;
  v_min_autonumber        number;
  v_autonumber_timestamp  timestamp;
  v_OFFSET_VAL            number := 1;
  --OF-16999 end

e_req_lock_not_occupied EXCEPTION;
   PRAGMA
   EXCEPTION_INIT (e_req_lock_not_occupied, -30006);
 e_task_lock_not_occupied EXCEPTION;
   PRAGMA
   EXCEPTION_INIT (e_task_lock_not_occupied, -00054);


begin
  --Note : values required should be given by prepared statement.

  --To lock the request row and wait for maximum 3 seconds to get the lock.

  begin
    execute immediate 'select /*+ INDEX (' || pi_request_table || ' ' || pi_request_table || '_BUSINESSKEY_UI)*/ 1
  from ' || pi_request_table || '
 where REQUEST_ID = ' || pi_request_id ||
                      ' for update wait 3'
      into v_requets_lock;
  exception
    when no_data_found then
      po_status := 1;
      raise e_requets_lock;
     when e_req_lock_not_occupied then
      po_status := 1;
      raise e_requets_lock;
    when others then
      raise;
  end;

  /* if (sql%rowcount = 0) then

    po_status := 1;
    raise e_requets_lock;

  end if;*/

  --Proceed if above query returns 1 i.e. if lock is aquired

  --To lock the task record from task_table and that task should not be in completed state. If following block returns 0 i.e. if no row will be selected,
  --then exit from here saying task is already completed and hence can not be rerouted. We are locking the task so that nobody can take action on this task untill rerouting is completed.
  begin
    execute immediate '
  select /*+ INDEX (' || pi_task_table || ' ' || pi_task_table || '_BUSINESSKEY_UI)*/ 1
    from ' || pi_task_table || ' where TASK_ID  = ' ||
                      pi_task_id || '
     and ACTION_PERFORMED is NULL
     and Row_Version = ' || pi_task_version ||
                      ' for update nowait'
      into v_task_lock;
  exception
    when no_data_found then
      po_status := 2;
      raise e_task_lock;
     when e_task_lock_not_occupied then
      po_status := 2;
      raise e_task_lock;
    when others then
      raise;
  end;



  --To check if there is any rerouted request corresponding to this request id.
  begin
    execute immediate '
select 1
  from ' || pi_re_reouting_table || '
 where REQUEST_ID = ' || pi_request_id || '
   and IS_OPEN = 1'
      into v_multi_re_routing_val;
  exception
    when no_data_found then
      null;

    when others then
      raise;
  end;

  if (sql%rowcount <> 0) then

    po_status := 3;
    raise e_multi_re_routing_val;

  end if;

  --Proceed if above query returns 1 else exit saying  only one
  --                    rerouted request can exit in open state for one request id '.

  --To insert record into re-routing table

  v_sql := 'RETURNED_ID,
     REQUEST_ID,
      TASK_ID,
      SENDER_COMMENTS,
      SENDER_USER_ID,
      CREATED_DATE_TIME,
      /*ATTACHMENTS,*/
      is_open,
      ROW_IDENTIFIER,
      ROW_VERSION';

  select Tables_id
    into v_re_reouting_table_id
    from tables
   where tables_physical_name = pi_re_reouting_table;
 -- v_autonumber := COMMONS_TABLES.GET_AUTO_VALUE(v_re_reouting_table_id);  --commented for OF-16999

  --OF-16999 start
  COMMONS_TABLES.GET_SET_AUTO_VALUE(PI_TABLE_ID => v_re_reouting_table_id, PI_OFFSET_VAL => v_OFFSET_VAL, PO_AV_RANGE_WITH_TS => v_autonumber_refcursor);

  fetch v_autonumber_refcursor into v_autonumber,v_min_autonumber,v_autonumber_timestamp;

  -- OF-16999 end;

  v_sql_values := v_autonumber || ',' || pi_request_id || ',' || pi_task_id || ',' || '''' ||
                  pi_sender_comments || ''',' || '''' || pi_sender_user_id ||
                  ''',' || 'to_date(to_char(SYS_EXTRACT_UTC(systimestamp),''dd-Mon-yyyy HH24:MI:SS''),''dd-Mon-yyyy HH24:MI:SS'')' || ','/* || '0' || ',' */|| '1' || ',' ||
                  pi_re_reouting_table || '_row_identifier_seq.nextval' || ',' || '0';

  if (pi_task_entity_cols is not null) then
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'select ' ||
                      'nvl(to_char('||replace(pi_task_entity_cols,
                              ',',
                              '),''null'')||'',''||nvl(to_char(') || '),''null'') from ' ||
                      pi_task_table || ' where TASK_ID=' || pi_task_id);

    execute immediate 'select ' ||
                      'nvl(to_char('||replace(pi_task_entity_cols,
                              ',',
                              '),''null'')||'',''||nvl(to_char(') || '),''null'') from ' ||
                      pi_task_table || ' where TASK_ID=' || pi_task_id
      into v_task_entity_values;
    v_sql        := v_sql || ',' || pi_task_entity_cols;
    v_sql_values := v_sql_values || ',' || v_task_entity_values;

  end if;

  if (pi_request_entity_cols is not null) then
  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'select ' ||
                      'nvl(to_char('||replace(pi_request_entity_cols,
                              ',',
                              '),''null'')||'',''||nvl(to_char(') || '),''null'') from ' ||
                      pi_request_table || ' where REQUEST_ID=' ||
                      pi_request_id);
   execute immediate 'select ' ||
                      'nvl(to_char('||replace(pi_request_entity_cols,
                              ',',
                              '),''null'')||'',''||nvl(to_char(') || '),''null'') from ' ||
                      pi_request_table || ' where REQUEST_ID=' ||
                      pi_request_id
      into v_request_entity_values;
    v_sql        := v_sql || ',' || pi_request_entity_cols;
    v_sql_values := v_sql_values || ',' || v_request_entity_values;

  end if;



  v_sql := ' INSERT INTO ' || pi_re_reouting_table || ' (' || v_sql ||
           ') select ' || v_sql_values || ' from dual   ';
  /* RETURNING RETURNED_ID INTO :1*/

 /* dbms_output.put_line(v_sql);*/
  execute immediate v_sql;

  /*COMMONS_TABLES.SET_AUTO_VALUE(pi_TABLE_ID => v_re_reouting_table_id,
                                pi_value    => v_autonumber);
                                po_returned_id:=v_autonumber;*/    --commented for OF-16999
  /* RETURNING into po_returned_id;*/
  --RETURNING OBJTYPE_TASK_ID_REQUEST_ID(<TASK_ID>,<REQUEST_ID>) BULK COLLECT INTO v_taskid_reqid_recs
  --To update the request status and row version.   --Optional
  if (pi_request_status_id is not null) then

    execute immediate 'update /*+ INDEX (' || pi_request_table || ' ' || pi_request_table || '_BUSINESSKEY_UI)*/' || pi_request_table || ' set ROW_VERSION = ROW_VERSION +1,
REQUEST_STATUS = ' || pi_request_status_id ||
                      ' where  REQUEST_ID  = ' || pi_request_id;

  end if;


  po_returned_id:=v_autonumber;   --OF-16999
  po_status := 4;

exception
  when e_requets_lock then
    return;
  when e_task_lock then
    return;
  when e_multi_re_routing_val then
    return;
/*  when others then
    raise;*/
end WF_RE_ROUTING_CREATION;


procedure UPDATE_REQUEST_TABLE( PI_REQ_UPDATE_PROCESS_ID  IN NUMBER,
                                PI_REQ_TO_INPUT_COL_MAP IN TABLETYPE_WF_COL_MAP,
                                PI_INPUT_TABLE_QUERY IN CLOB,
                                PI_REQ_ID_FLD_COLUMN_NAME IN VARCHAR2,
                                PO_REQ_IDS_MATCHED OUT COLTYPE_WF_ID,
                                PO_REQ_IDS_NOT_MATCHED OUT COLTYPE_WF_ID,
                                PO_MATCHED_RECORD_COUNT OUT NUMBER,
                                PO_MISMATCHED_RECORD_COUNT OUT NUMBER,
                                PO_STATUS OUT NUMBER) IS

  V_REQ_ID_MATCHED coltype_id;
  V_REQ_ID_NOT_MATCHED coltype_id;
  V_WA_ID NUMBER(10);
  V_MATCHED_COUNT NUMBER :=0;
  V_NOT_MATCHED_COUNT NUMBER :=0;
  V_REQ_TYPE_ID NUMBER(10);
  V_REQ_STATUS_ID NUMBER(10);
  V_REQUESTS_TABLES_ID NUMBER(10);
  V_REQUESTS_TABLES_NAME varchar2(30 char);
  V_UPDATE_COUNT NUMBER := 0;
  V_DUPLICATE_ENTITY_FLG NUMBER;
  V_REQ_ID_FLD_COLUMN_NAME VARCHAR2(30) := PI_REQ_ID_FLD_COLUMN_NAME;
  V_SET_CLAUSE CLOB;
  V_MERGE_SQL CLOB;
  V_REPORT_SQL CLOB;
  V_ENTITY_VALIDATION_CLAUSE CLOB;
  TYPE OBJ_REQ_ID_MAP IS RECORD (IP_TBL_REQ_ID NUMBER, REQUEST_TBL_REQ_ID NUMBER);
  TYPE T_REQ_ID_MAP IS TABLE OF OBJ_REQ_ID_MAP;
  V_REQ_ID_MAP T_REQ_ID_MAP;
  nonunique_source exception;
  CONCURRENT_UPDATE_ON_SOURCE EXCEPTION;
  ENTITY_NOT_EXISTS EXCEPTION;
  pragma exception_init(nonunique_source,-30926);
  numeric_overflow EXCEPTION;
  pragma exception_init(numeric_overflow,-01438);

begin
  PO_STATUS := 1;
  SELECT WAP.WAP_WA_ID,
         WAP.WAP_WRT_ID,
         WAP.WAP_WRS_ID
    INTO V_WA_ID, V_REQ_TYPE_ID, V_REQ_STATUS_ID
    FROM WORKFLOW_AUTOMATION_PROCESS WAP
   WHERE WAP.WAP_ID = PI_REQ_UPDATE_PROCESS_ID;

  SELECT WA.WA_REQUESTS_TABLES_ID
    INTO V_REQUESTS_TABLES_ID
    FROM WORKFLOW_APPLICATIONS WA
   WHERE WA.WA_ID = V_WA_ID;

   /* SELECT WA.WA_REQUESTS_TABLES_ID
    INTO V_REQUESTS_TABLES_ID
    FROM WORKFLOW_APPLICATIONS WA
   WHERE WA.WA_ID = V_WA_ID;*/


   select tables_physical_name into V_REQUESTS_TABLES_NAME  from tables
   where tables_id=V_REQUESTS_TABLES_ID;




   FOR I IN 1..PI_REQ_TO_INPUT_COL_MAP.COUNT LOOP
     IF I = 1 THEN
       V_SET_CLAUSE := PI_REQ_TO_INPUT_COL_MAP(I).NAME1 ||' = '|| PI_REQ_TO_INPUT_COL_MAP(I).NAME2;
     ELSE
       V_SET_CLAUSE := V_SET_CLAUSE||' , '||PI_REQ_TO_INPUT_COL_MAP(I).NAME1 ||' = '|| PI_REQ_TO_INPUT_COL_MAP(I).NAME2;
     END IF;

     IF (PI_REQ_TO_INPUT_COL_MAP(I).IS_ENTITY_MAPPING = 1)  THEN
       FOR J IN (
         SELECT U.DATA_TYPE
           FROM USER_TAB_COLUMNS U
        /*  inner join table_columns tc
             on (U.COLUMN_NAME = tc.TC_PHYSICAL_NAME)*/
          WHERE U.TABLE_NAME = V_REQUESTS_TABLES_NAME
            /*and tc.tc_tables_id = V_REQUESTS_TABLES_ID*/
            AND upper(U.COLUMN_NAME) =
                upper(PI_REQ_TO_INPUT_COL_MAP(I).NAME1)
          /*  AND TC.TC_COLUMN_TYPE <> 1*/
                    ) LOOP

                 IF V_ENTITY_VALIDATION_CLAUSE IS NULL THEN
                   IF J.DATA_TYPE = 'NUMBER' THEN
                      V_ENTITY_VALIDATION_CLAUSE := PI_REQ_TO_INPUT_COL_MAP(I).NAME1 || ' = -1e20 ';
                   ELSIF J.DATA_TYPE = 'VARCHAR2' THEN
                      V_ENTITY_VALIDATION_CLAUSE := PI_REQ_TO_INPUT_COL_MAP(I).NAME1 || ' = ''-100000000000000000000''';
                   ELSE
                     raise_application_error(-20001, 'INVALID DATATYPE FOR ENTITY.');
                   END IF;
                 ELSE
                   IF J.DATA_TYPE = 'NUMBER' THEN
                      V_ENTITY_VALIDATION_CLAUSE := V_ENTITY_VALIDATION_CLAUSE || ' OR '||PI_REQ_TO_INPUT_COL_MAP(I).NAME1 || ' = -1e20 ';
                   ELSIF J.DATA_TYPE = 'VARCHAR2' THEN
                      V_ENTITY_VALIDATION_CLAUSE := V_ENTITY_VALIDATION_CLAUSE || ' OR '||PI_REQ_TO_INPUT_COL_MAP(I).NAME1 || ' = ''-100000000000000000000''';
                   ELSE
                     raise_application_error(-20001, 'INVALID DATATYPE FOR ENTITY.');
                   END IF;
                 END IF;

   END LOOP;
     END IF;
   END LOOP;

   V_SET_CLAUSE := V_SET_CLAUSE||' , ROW_VERSION = ROW_VERSION + 1';

   V_MERGE_SQL := 'MERGE INTO '||V_REQUESTS_TABLES_NAME||' RQ
                   USING ('||PI_INPUT_TABLE_QUERY||') IP
                      ON ( RQ.REQUEST_ID = IP.'||V_REQ_ID_FLD_COLUMN_NAME||' AND RQ.REQUEST_TYPE = '||V_REQ_TYPE_ID||')
              WHEN MATCHED THEN
                  UPDATE SET '||V_SET_CLAUSE;



   V_REPORT_SQL := 'SELECT DT.'||V_REQ_ID_FLD_COLUMN_NAME||' DT_ID, RQ.REQUEST_ID REQ_ID FROM ('||PI_INPUT_TABLE_QUERY||') DT LEFT OUTER JOIN '||V_REQUESTS_TABLES_NAME||' RQ ON (RQ.REQUEST_ID = DT.'||V_REQ_ID_FLD_COLUMN_NAME||' AND RQ.REQUEST_TYPE = '||V_REQ_TYPE_ID||')';


   PO_REQ_IDS_MATCHED := COLTYPE_WF_ID()  ;
   PO_REQ_IDS_NOT_MATCHED := COLTYPE_WF_ID();

   EXECUTE IMMEDIATE V_MERGE_SQL;


   V_UPDATE_COUNT := SQL%ROWCOUNT;

   EXECUTE IMMEDIATE V_REPORT_SQL BULK COLLECT INTO V_REQ_ID_MAP;

   FOR I IN 1 .. V_REQ_ID_MAP.COUNT LOOP
     IF V_REQ_ID_MAP(I).REQUEST_TBL_REQ_ID IS NOT NULL THEN
       V_MATCHED_COUNT := V_MATCHED_COUNT + 1;
       --OF-57891: Removed the 1000 records condition
       --IF V_MATCHED_COUNT <= 1000 THEN               --TO REPORT MAXIMUM 1000 RECORDS
         PO_REQ_IDS_MATCHED.EXTEND(1);
         PO_REQ_IDS_MATCHED(V_MATCHED_COUNT) := V_REQ_ID_MAP(I).IP_TBL_REQ_ID;
       --END IF;
     ELSE
       V_NOT_MATCHED_COUNT := V_NOT_MATCHED_COUNT + 1;
       --OF-57891: Removed the 1000 records condition
       --IF V_NOT_MATCHED_COUNT <= 1000 THEN          --TO REPORT MAXIMUM 1000 RECORDS
         PO_REQ_IDS_NOT_MATCHED.EXTEND(1);
         PO_REQ_IDS_NOT_MATCHED(V_NOT_MATCHED_COUNT) := V_REQ_ID_MAP(I).IP_TBL_REQ_ID;
       --END IF;
     END IF;
   END LOOP;

   PO_MATCHED_RECORD_COUNT := V_UPDATE_COUNT;
   PO_MISMATCHED_RECORD_COUNT := V_NOT_MATCHED_COUNT;

   IF V_UPDATE_COUNT <> V_MATCHED_COUNT THEN
     RAISE CONCURRENT_UPDATE_ON_SOURCE;
   END IF;

   IF V_ENTITY_VALIDATION_CLAUSE IS NULL THEN
     V_ENTITY_VALIDATION_CLAUSE := '1=2';
   END IF;

   EXECUTE IMMEDIATE 'SELECT NVL(MAX(1),0)
                        FROM DUAL
                       WHERE EXISTS (SELECT 1
                                       FROM '||V_REQUESTS_TABLES_NAME||'
                                      WHERE '||V_ENTITY_VALIDATION_CLAUSE ||')'
                     INTO V_DUPLICATE_ENTITY_FLG;

   IF V_DUPLICATE_ENTITY_FLG =1 THEN
     RAISE ENTITY_NOT_EXISTS;
   END IF;

EXCEPTION
  WHEN nonunique_source THEN
    PO_STATUS := 2;       /*FAILED DUE TO DUPLICATE SOURCE RECORDS*/
  WHEN ENTITY_NOT_EXISTS or numeric_overflow THEN
    PO_STATUS := 3;       /*FAILED DUE TO NON EXISTANCE OF ENTITY*/
  WHEN CONCURRENT_UPDATE_ON_SOURCE THEN
    PO_STATUS := 4;       /*FAILED DUE TO CONCURRENT UPDATE ON SOURCE*/
end UPDATE_REQUEST_TABLE;





PROCEDURE UPDATE_WORKFLOW_FIRST_LAST(PIN_WP_ID  IN NUMBER)
AS
BEGIN

  -- delete the old records
  DELETE FROM WORKFLOW_PROCESS_LVL_FIRST WPLF
  WHERE WPLF.WPLF_WP_ID = PIN_WP_ID;

  -- populate the first table
  INSERT INTO WORKFLOW_PROCESS_LVL_FIRST
                 WITH T AS (SELECT  WTA_WP_ID      WTA_WP_ID,
                                    WTA_ID         PARENT_OBJ_ID,
                                    0              CHILD_OBJ_TYPE,
                                    WFCA_ID         CHILD_OBJ_ID,
                                    WFCA_ORDER      CHILD_ORDER
                                   FROM WF_ACTIONS
                                  INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID
                                  INNER JOIN WF_TASK_ASSIGNMENTS
                                   ON WFCA_WTA_ID = WTA_ID
                                  WHERE WTA_WP_ID  = PIN_WP_ID

                                 UNION ALL

                                 SELECT WTA_WP_ID      WTA_WP_ID,
                                    WFCA_ID         PARENT_OBJ_ID,
                                    1              CHILD_OBJ_TYPE,
                                    WTA_ID         CHILD_OBJ_ID,
                                    WTAC_ORDER     CHILD_ORDER
                                   FROM WF_TA_ACTIVATIONS
                                  INNER JOIN WF_TASK_ASSIGNMENTS
                                   ON WTAC_WTA_ID = WTA_ID
                                   LEFT JOIN (select * from WF_ACTIONS INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID)
                                   ON WTAC_WFCA_ID = WFCA_ID
                                  WHERE WTA_WP_ID   = PIN_WP_ID),

                 RECUR(WTA_WP_ID, CHILD_OBJ_ID, CHILD_OBJ_TYPE, CHILD_ORDER, HLEVEL, HPATH) AS

                 (SELECT WTA_WP_ID,
                     CHILD_OBJ_ID,
                     CHILD_OBJ_TYPE,
                     CHILD_ORDER,
                     0 HLEVEL,
                     '' || CHILD_OBJ_ID HPATH
                  FROM T
                 WHERE PARENT_OBJ_ID IS NULL
                UNION ALL
                SELECT T.WTA_WP_ID,
                     T.CHILD_OBJ_ID,
                     T.CHILD_OBJ_TYPE,
                     T.CHILD_ORDER,
                     RECUR.HLEVEL + 1 HLEVEL,
                     T.CHILD_OBJ_ID || ',' || RECUR.HPATH HPATH
                  FROM T
                 INNER JOIN RECUR
                  ON RECUR.CHILD_OBJ_ID =
                     T.PARENT_OBJ_ID
                   AND RECUR.WTA_WP_ID =
                     T.WTA_WP_ID)

                 SEARCH DEPTH FIRST BY CHILD_ORDER SET ORD

                SELECT  WPLF_SEQ.NEXTVAL  WPLF_ID,
                        WPLF_WP_ID,
                        WPLF_WTA_ID,
                        WPLF_LEVEL1_FIRST,
                        WPLF_LEVEL2_FIRST,
                        WPLF_LEVEL3_FIRST,
                        WPLF_LEVEL4_FIRST,
                        WPLF_LEVEL5_FIRST,
                        WPLF_LEVEL6_FIRST,
                        WPLF_LEVEL7_FIRST,
                        WPLF_LEVEL8_FIRST,
                        WPLF_LEVEL9_FIRST,
                        WPLF_LEVEL10_FIRST
                        FROM
                        (select DISTINCT
                            WTA_WP_ID         WPLF_WP_ID,
                            CHILD_OBJ_ID      WPLF_WTA_ID,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 3))  KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 3), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL1_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 5))  KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 5), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL2_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 7))  KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 7), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL3_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 9))  KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 9), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL4_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 11)) KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 11), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL5_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 13)) KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 13), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL6_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 15)) KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 15), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL7_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 17)) KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 17), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL8_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 19)) KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 19), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL9_FIRST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 21)) KEEP (DENSE_RANK FIRST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 21), 0, 1), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLF_LEVEL10_FIRST
                        FROM    RECUR
                        WHERE   CHILD_OBJ_TYPE = 1);

  -- delete the old records
  DELETE FROM WORKFLOW_PROCESS_LVL_LAST WPLL
  WHERE WPLL.WPLL_WP_ID = PIN_WP_ID;

  -- populate the last table
  INSERT INTO WORKFLOW_PROCESS_LVL_LAST
                 WITH T AS (SELECT  WTA_WP_ID      WTA_WP_ID,
                                    WTA_ID         PARENT_OBJ_ID,
                                    0              CHILD_OBJ_TYPE,
                                    WFCA_ID         CHILD_OBJ_ID,
                                    WFCA_ORDER      CHILD_ORDER
                                   FROM WF_ACTIONS
                                  INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID
                                  INNER JOIN WF_TASK_ASSIGNMENTS
                                   ON WFCA_WTA_ID = WTA_ID
                                  WHERE WTA_WP_ID  = PIN_WP_ID

                                 UNION ALL

                                 SELECT WTA_WP_ID      WTA_WP_ID,
                                    WFCA_ID         PARENT_OBJ_ID,
                                    1              CHILD_OBJ_TYPE,
                                    WTA_ID         CHILD_OBJ_ID,
                                    WTAC_ORDER     CHILD_ORDER
                                   FROM WF_TA_ACTIVATIONS
                                  INNER JOIN WF_TASK_ASSIGNMENTS
                                   ON WTAC_WTA_ID = WTA_ID
                                   LEFT JOIN (select * from WF_ACTIONS INNER JOIN WF_COMMON_ACTIONS ON WFCA_WFA_ID = WFA_ID)
                                   ON WTAC_WFCA_ID = WFCA_ID
                                  WHERE WTA_WP_ID   = PIN_WP_ID),

                 RECUR(WTA_WP_ID, CHILD_OBJ_ID, CHILD_OBJ_TYPE, CHILD_ORDER, HLEVEL, HPATH) AS

                 (SELECT WTA_WP_ID,
                     CHILD_OBJ_ID,
                     CHILD_OBJ_TYPE,
                     CHILD_ORDER,
                     0 HLEVEL,
                     '' || CHILD_OBJ_ID HPATH
                  FROM T
                 WHERE PARENT_OBJ_ID IS NULL
                UNION ALL
                SELECT T.WTA_WP_ID,
                     T.CHILD_OBJ_ID,
                     T.CHILD_OBJ_TYPE,
                     T.CHILD_ORDER,
                     RECUR.HLEVEL + 1 HLEVEL,
                     T.CHILD_OBJ_ID || ',' || RECUR.HPATH HPATH
                  FROM T
                 INNER JOIN RECUR
                  ON RECUR.CHILD_OBJ_ID =
                     T.PARENT_OBJ_ID
                   AND RECUR.WTA_WP_ID =
                     T.WTA_WP_ID)

                 SEARCH DEPTH FIRST BY CHILD_ORDER SET ORD

              SELECT  WPLL_SEQ.NEXTVAL  WPLL_ID,
                      WPLL_WP_ID,
                      WPLL_WTA_ID,
                      WPLL_LEVEL1_LAST,
                      WPLL_LEVEL2_LAST,
                      WPLL_LEVEL3_LAST,
                      WPLL_LEVEL4_LAST,
                      WPLL_LEVEL5_LAST,
                      WPLL_LEVEL6_LAST,
                      WPLL_LEVEL7_LAST,
                      WPLL_LEVEL8_LAST,
                      WPLL_LEVEL9_LAST,
                      WPLL_LEVEL10_LAST
                      FROM
                        (select DISTINCT
                            WTA_WP_ID         WPLL_WP_ID,
                            CHILD_OBJ_ID      WPLL_WTA_ID,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 3))  KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 3), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL1_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 5))  KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 5), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL2_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 7))  KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 7), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL3_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 9))  KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 9), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL4_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 11)) KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 11), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL5_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 13)) KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 13), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL6_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 15)) KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 15), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL7_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 17)) KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 17), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL8_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 19)) KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 19), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL9_LAST,
                            TO_NUMBER(MIN(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 21)) KEEP (DENSE_RANK LAST ORDER BY NVL2(REGEXP_SUBSTR(HPATH, '[0-9]+', 1, 21), 1, 0), ROWNUM) OVER (PARTITION BY CHILD_OBJ_ID)) WPLL_LEVEL10_LAST
              FROM    RECUR
              WHERE   CHILD_OBJ_TYPE = 1);

END UPDATE_WORKFLOW_FIRST_LAST;

  PROCEDURE UPDATE_DATA_RECORD_ON_ACTION
          (
            PI_APPLICATION_ID IN NUMBER,
            PI_COLTYPE_ACTION_DETAILS IN COLTYPE_ACTION_DETAILS,
            PI_ID_OF_TABLE_TO_BE_UPDATED IN NUMBER,
            PO_STATUS OUT COLTYPE_STATUS_IDS,
            PO_ENTITY_VALIDATION  OUT NUMBER     --1=PASS ,  0=FAIL
          ) IS
    V_SQL_SET_CLAUSE  CLOB;
    V_REQ_TABLE       VARCHAR2(30);
    V_TASK_TABLE      VARCHAR2(30);
    V_ASSOC_TBL_TABLE VARCHAR2(30);
    V_TREF            NUMBER(10);
    V_ASSOC_TBL_CD_ID NUMBER(10);
    V_REQ_TAB_ID      NUMBER(10);
    V_TSK_TAB_ID      NUMBER(10);
    V_LHS             VARCHAR2(30);
   V_FLD_DATA_TYPE   NUMBER;
    V_RHS             VARCHAR2(30);
    V_RHS_QUERY       CLOB;
    V_UPDATE_QUERY    CLOB;
    V_ENT_JOIN_CLAUSE CLOB;
    V_MRG_SELECT_CLAUSE CLOB;
    V_REL_REC_TYPE    NUMBER(10);
    V_DT_ENT_TBL_NAME VARCHAR2(30);
    v_unchanged_set_cnt       NUMBER;
    V_INVALID_ENT_CNT NUMBER := 0;
    V_STATUS_COUNTER  NUMBER := 0;
    V_INTERNAL_ENTITY_ID NUMBER;
    V_ENT_TABLE  VARCHAR2(30);
    V_ENT_KEY_COL VARCHAR2(30);
    V_ENT_TABLE_RHS  VARCHAR2(30);
    V_ENT_KEY_COL_RHS VARCHAR2(30);
    V_LOOP_COUNTER_J  NUMBER := 0;
    V_STATUS COLTYPE_STATUS_IDS;
    V_Request_IDs COLTYPE_ID;
    V_Request_IDs_comma_sperated clob;
    V_SET_VERSION NUMBER;
    v_tsk_gtt varchar2(250):='TASK_GTT_'||PI_APPLICATION_ID ;
    V_GTT_CLAUSE CLOB;
    EXP_NULL_VALUE_ASSIGNED EXCEPTION;
    PRAGMA EXCEPTION_INIT(EXP_NULL_VALUE_ASSIGNED, -01407);

    ---fix start for  40513---creating entity validation queries
    V_ENT_CHK_CLAUSE   CLOB;
    V_ENT_CHK_COL_CLAUSE CLOB;
    V_ENT_WHERE_CLAUSE CLOB;
    ---fix end for  40513---creating entity validation queries

  ---fix start for  40373---Data length validation
    V_RHS_VALIDATION CLOB;
    V_FLD_LENGTH NUMBER;
    V_IS_REQUIRED NUMBER;
    V_ERROR_SELECT CLOB:= NULL;
    V_ERROR_SELECT_WITH_NOT CLOB := NULL;
    V_RHS_FLAG NUMBER:=0;
    V_REQUIRED_FLAG NUMBER:=0;
    V_NULL_CHECK CLOB;
    V_NULL_SELECT CLOB;
    V_NULL_SELECT_WITH_NOT CLOB;
    V_PREV_WF_FLDMAPPINGS_SET_ID NUMBER;
  ---fix end for  40373---Data length validation

--fix start for OF-53369----Multilevel Task node update handling
    V_FLD_ID NUMBER;
    V_WFM_RELATED_WTA_ID NUMBER;
    V_WFCA_WTA_ID   NUMBER;
    V_WFM_LHS_ENT_ID NUMBER;
--fix END for OF-53369----Multilevel Task node update handling

    --TYPE TABLE_COLS IS TABLE OF TABLE_COLUMNS%ROWTYPE;

    T_TABLE_COLS COLTYPE_TABLE_COL_DTLS;



  BEGIN
    PO_STATUS := COLTYPE_STATUS_IDS();
    PO_ENTITY_VALIDATION := 1;
    V_STATUS := COLTYPE_STATUS_IDS();
    V_Request_IDs :=COLTYPE_ID();


    --------------------



    /*FOR i IN 1..PI_COLTYPE_ACTION_DETAILS.COUNT LOOP
      commons_utils.INSERT_LOGS('========='||I||'==========');
      commons_utils.INSERT_LOGS(TO_CHAR('REQUEST_ID='||PI_COLTYPE_ACTION_DETAILS(i).REQUEST_ID));
      commons_utils.INSERT_LOGS(TO_CHAR('ACTION_NODE_ID='||PI_COLTYPE_ACTION_DETAILS(i).ACTION_NODE_ID));
      commons_utils.INSERT_LOGS(TO_CHAR('WF_FLDMAPPINGS_SET_ID='||PI_COLTYPE_ACTION_DETAILS(i).WF_FLDMAPPINGS_SET_ID));
      commons_utils.INSERT_LOGS(TO_CHAR('WF_FLDMAPPINGS_SET_VERSION='||PI_COLTYPE_ACTION_DETAILS(i).WF_FLDMAPPINGS_SET_VERSION));
      commons_utils.INSERT_LOGS(TO_CHAR('ASSOCIATED_RECORD_ID='||PI_COLTYPE_ACTION_DETAILS(i).ASSOCIATED_RECORD_ID));
\*      commons_utils.INSERT_LOGS(TO_CHAR('PI_TASK_RECORD='||PI_TASK_RECORD));*\
    END LOOP;






      commons_utils.INSERT_LOGS('PI_ID_OF_TABLE_TO_BE_UPDATED='||PI_ID_OF_TABLE_TO_BE_UPDATED);
      commons_utils.INSERT_LOGS('PI_APPLICATION_ID='||PI_APPLICATION_ID);*/




    --------------------


-- Fix for OF-40377
-- used view id for join instead of tables id which was sending internal UID value instead of business name
    SELECT W.WA_REQUESTS_TABLES_ID,
           TR.TABLES_PHYSICAL_NAME REQ_TABLE,
           W.WA_TASKS_TABLES_ID,
           TT.TABLES_PHYSICAL_NAME TASK_TABLE
      INTO V_REQ_TAB_ID, V_REQ_TABLE, V_TSK_TAB_ID, V_TASK_TABLE
      FROM (SELECT * FROM WORKFLOW_APPLICATIONS WHERE WA_ID = PI_APPLICATION_ID) W
      LEFT OUTER JOIN TABLES TR
        ON (W.WA_REQUESTS_VIEW_ID = TR.TABLES_ID)
      LEFT OUTER JOIN TABLES TT
        ON (W.WA_TASKS_VIEW_ID = TT.TABLES_ID);

      SELECT T.TABLES_PHYSICAL_NAME INTO V_DT_ENT_TBL_NAME FROM TABLES T WHERE T.TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;

    /*IF(V_TREF IS NOT NULL) THEN
      IF(V_ASSOC_TBL_CD_ID = 2)THEN
        SELECT T.TABLES_PHYSICAL_NAME
          INTO V_ASSOC_TBL_TABLE
          FROM TABLES T
         WHERE T.TABLES_ID =
               (SELECT DT.DT_TABLES_ID
                  FROM DATA_TABLES DT
                 INNER JOIN TABLE_REFERENCES TRF
                    ON (DT.DT_ID = TRF.TREF_DEFINITION_ID AND
                       TRF.TREF_DEFINITION_ID = V_TREF));
      ELSIF(V_ASSOC_TBL_CD_ID = 2)THEN
      END IF;
    END IF;   */

    --LHS type : Entity(1),Field(2)
    --mapping type : EMPTY(1), CONSTANT(2) ,USER_ENTITY(3),USER_ENTITY_ATTRIBUTE(4), PARENT_VALUE (5), related record(6),
    --related record type : 0-data;1-request;2-task record
    SELECT OBJ_TABLE_COL_DTLS(TC.TC_FLD_ID,
                              TC.TC_ENTITY_ID,
                              TC.TC_TABLES_ID,
                              TC.TC_PHYSICAL_NAME,
                              T.TABLES_PHYSICAL_NAME,
                              TCE.TC_PHYSICAL_NAME)
      BULK COLLECT
      INTO T_TABLE_COLS
      FROM (SELECT * FROM TABLE_COLUMNS TC1 WHERE TC1.TC_TABLES_ID IN
           (V_REQ_TAB_ID, V_TSK_TAB_ID, PI_ID_OF_TABLE_TO_BE_UPDATED)) TC
      LEFT OUTER JOIN ENTITIES E
      ON TC.TC_ENTITY_ID = E.ENTITY_ID
      LEFT OUTER JOIN TABLES T
      ON E.ENTITY_TABLES_ID = T.TABLES_ID
      LEFT OUTER JOIN TABLE_COLUMNS TCE
      ON E.ENTITY_TABLES_ID = TCE.TC_TABLES_ID
      --Added autonumber value 5 in tc_logic_type to identify entity key
      --AND TCE.TC_LOGIC_TYPE = 1
      AND TCE.TC_LOGIC_TYPE IN (1,5);

    FOR I IN (SELECT /*REQUEST_ID,*/ distinct ACTION_NODE_ID, WF_FLDMAPPINGS_SET_ID, WF_FLDMAPPINGS_SET_VERSION /*,ASSOCIATED_RECORD_ID*//*, ASSOCIATED_RECORD_VERSION*/
                FROM TABLE(PI_COLTYPE_ACTION_DETAILS)) LOOP



      V_SQL_SET_CLAUSE := '';
      V_ENT_JOIN_CLAUSE := '';
      V_MRG_SELECT_CLAUSE := '';
      V_Request_IDs_comma_sperated :='';

      ---fix start for  40513---creating entity validation queries
      V_ENT_CHK_CLAUSE := '';
      V_ENT_CHK_COL_CLAUSE := '';
      V_ENT_WHERE_CLAUSE :='';
      ---fix end for  40513---creating entity validation queries


      -- OF-40311: Fix for duplicate request records with same data record associated id
      -- Create concatenated list of request ids
      EXECUTE IMMEDIATE 'SELECT REQUEST_ID FROM TABLE(:1)  WHERE ACTION_NODE_ID = :2' bulk collect into V_Request_IDs USING PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID;
      for i in 1..V_Request_IDs.count loop
        V_Request_IDs_comma_sperated :=  V_Request_IDs_comma_sperated || V_Request_IDs(i);

        if i <>V_Request_IDs.count then
           V_Request_IDs_comma_sperated :=  V_Request_IDs_comma_sperated || ',';
          end if;
        end loop;


      SELECT WFMS_VERSION INTO V_SET_VERSION FROM WF_FIELDS_MAPPING_SET WHERE WFMS_ID = I.WF_FLDMAPPINGS_SET_ID;

      IF I.WF_FLDMAPPINGS_SET_VERSION <> V_SET_VERSION THEN
          /*PO_STATUS.EXTEND();
          V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
          PO_STATUS(V_STATUS_COUNTER) := OBJTYPE_DR_UPDT_STATUS(ASSOCIATED_RECORD_ID => I.ASSOCIATED_RECORD_ID,
                                                                                     UPDATE_STATUS => 2);*/

           EXECUTE IMMEDIATE '
           SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
           SELECT  ASSOCIATED_RECORD_ID ID , 2 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||'
           UNION
           SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:2))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,V_STATUS;

           V_STATUS := PO_STATUS;

           CONTINUE;

      END IF;
      V_PREV_WF_FLDMAPPINGS_SET_ID:=null;
      V_RHS_VALIDATION := NULL;
      V_NULL_CHECK := NULL;
      V_RHS_FLAG :=0;
      V_REQUIRED_FLAG :=0;

      FOR J IN (SELECT M.*, S.WFMS_VERSION FROM WF_FIELDS_MAPPING M
        INNER JOIN WF_FIELDS_MAPPING_SET S
        ON (M.WFM_WFMS_ID = S.WFMS_ID AND S.WFMS_ID = I.WF_FLDMAPPINGS_SET_ID)
                ) LOOP
---fix start for  40373---Data length validation
IF V_PREV_WF_FLDMAPPINGS_SET_ID <> I.WF_FLDMAPPINGS_SET_ID THEN


  V_RHS_VALIDATION := NULL;
  V_NULL_CHECK := NULL;
  V_RHS_FLAG :=0;
  V_REQUIRED_FLAG :=0;
 END IF;
  V_FLD_LENGTH :=0;
  V_IS_REQUIRED :=0;
---fix end for  40373---Data length validation

        V_LOOP_COUNTER_J := V_LOOP_COUNTER_J +1;

        /*IF J.WFMS_VERSION <> I.WF_FLDMAPPINGS_SET_VERSION THEN
          \*PO_STATUS.EXTEND();
          V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
          PO_STATUS(V_STATUS_COUNTER) := OBJTYPE_DR_UPDT_STATUS(ASSOCIATED_RECORD_ID => I.ASSOCIATED_RECORD_ID,
                                                                                     UPDATE_STATUS => 2);*\

           EXECUTE IMMEDIATE '
           SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
           SELECT  ASSOCIATED_RECORD_ID ID , 2 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||'
           UNION
           SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:2))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,V_STATUS;

           V_STATUS := PO_STATUS;

           CONTINUE;

        END IF;
 */
        IF (V_SQL_SET_CLAUSE IS NOT NULL) THEN
          V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ',';
        END IF;
----Added V_WFM_LHS_ENT_ID for OF-53369----Multilevel Task node update handling
        IF (J.WFM_LHS_TYPE = 1) THEN --ENTITY
          SELECT TC.TC_PHYSICAL_NAME,
                 TC.ENT_TABLE,
                 TC.ENT_KEY_COL,
                 j.WFM_LHS_ENT_ID
            INTO V_LHS,V_ENT_TABLE,V_ENT_KEY_COL,V_WFM_LHS_ENT_ID
            FROM TABLE(T_TABLE_COLS) TC
           WHERE TC.TC_ENTITY_ID = J.WFM_LHS_ENT_ID
           AND TC.TC_TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;


          V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_LHS || ' = ';


          IF (J.WFM_MAPPING_TYPE = 1) THEN
            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' NULL';
          ELSIF (J.WFM_MAPPING_TYPE = 2) THEN

-- fix for of-40382 (used using instead of appending constant value)
          EXECUTE IMMEDIATE 'SELECT E_INTERNAL_ID FROM '||V_ENT_TABLE||' WHERE '||V_ENT_KEY_COL||' = :1' INTO V_INTERNAL_ENTITY_ID USING J.WFM_CONSTANT_VALUE;

          --V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN (select '||V_INTERNAL_ENTITY_ID||' E_'||V_ENT_TABLE||' from dual) al_'||V_ENT_TABLE||' on (1=1) ';



          /*IF V_INTERNAL_ENTITY_ID IS NULL THEN
            PO_STATUS.EXTEND();
            V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
            PO_STATUS(V_STATUS_COUNTER) := OBJTYPE_DR_UPDT_STATUS(ASSOCIATED_RECORD_ID => I.ASSOCIATED_RECORD_ID,
                                                                                     UPDATE_STATUS => 3);

            PO_ENTITY_VALIDATION := 0;
          END IF; */

            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_INTERNAL_ENTITY_ID;


            /*ELSIF(J.WFM_MAPPING_TYPE = 3)THEN
              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '';
            ELSIF(J.WFM_MAPPING_TYPE = 4)THEN
              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '';
            ELSIF(J.WFM_MAPPING_TYPE = 5)THEN
              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '';*/
          ELSIF (J.WFM_MAPPING_TYPE = 6) THEN   --RELATED RECORD FIELD

            IF (J.WFM_RELATED_RECORD_TYPE = 0) THEN
              SELECT TC.TC_PHYSICAL_NAME
                INTO V_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_FLD_ID = J.WFM_RHS_FLD_ID
                 and TC.TC_TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;

            IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
            END IF;



            V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_ENT_TABLE||' '||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||' on ('||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL||' = DT1.'||V_RHS||') ';

            V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID ENT_ID_'||V_LOOP_COUNTER_J;

            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||'MRG.ENT_ID_'||V_LOOP_COUNTER_J;


---fix start for  40513---creating entity validation queries
                    V_ENT_CHK_COL_CLAUSE := V_ENT_CHK_COL_CLAUSE || V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID ENT_ID_'||V_LOOP_COUNTER_J ||',DT1.' ||V_RHS ||' ENT_ID_VALUE_'||V_LOOP_COUNTER_J ||',' ;

                    V_ENT_WHERE_CLAUSE := V_ENT_WHERE_CLAUSE||'OR ('|| V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID IS NULL AND DT1.'|| V_RHS || ' IS NOT NULL )';

---fix end for  40513---creating entity validation queries

          /*IF V_INTERNAL_ENTITY_ID IS NULL THEN
            PO_STATUS.EXTEND();
            V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
           \* PO_STATUS(V_STATUS_COUNTER) := OBJTYPE_DR_UPDT_STATUS(ASSOCIATED_RECORD_ID => I.ASSOCIATED_RECORD_ID,
                                                                                     UPDATE_STATUS => 3);*\

            PO_ENTITY_VALIDATION := 0;
          END IF; */


             -- V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || 'al_'||V_ENT_TABLE||'.E_INTERNAL_ID';

            ELSIF (J.WFM_RELATED_RECORD_TYPE = 1) THEN
              SELECT TC.TC_PHYSICAL_NAME
                INTO V_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_FLD_ID = J.WFM_RHS_FLD_ID
                 and TC.TC_TABLES_ID = V_REQ_TAB_ID;


            IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
            END IF;

            -- OF-40311: Fix for duplicate request records with same data record associated id
            -- Added "and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) '||"
            V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_REQ_TABLE||' REQ_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (REQ_TAB_'||V_LOOP_COUNTER_J||'.ASSOCIATED_DATA_RECORD_ID = DT1.ROW_IDENTIFIER) and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) '||
                                 ' LEFT OUTER JOIN '|| V_ENT_TABLE || ' '||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||' ON('||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL||' = REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';




             /*V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_ENT_TABLE||' al_'||V_ENT_TABLE||' on ('||V_ENT_KEY_COL||' = '||V_RHS||') '||
             ' INNER JOIN (SELECT * FROM '||V_REQ_TABLE||' WHERE REQUEST_ID IN (SELECT REQUEST_ID from :1 WHERE ACTION_NODE_ID = )'||i.ACTION_NODE_ID||')
             AND '||V_REQ_TABLE||'.ASSOCIATED_DATA_RECORD_ID = ROW_IDENTIFIER) REQ_TAB_'||V_LOOP_COUNTER_J||
             ' ON (al_'||V_ENT_TABLE||'.V_ENT_KEY_COL = REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')'; */


             V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID ENT_ID_'||V_LOOP_COUNTER_J;

              --V_RHS_QUERY      := '(SELECT '||V_RHS||' FROM ' || V_REQ_TABLE || ' WHERE REQUEST_ID = '||I.REQUEST_ID||')';

             V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||'MRG.ENT_ID_'||V_LOOP_COUNTER_J;

            ---fix start for  40513---creating entity validation queries
            V_ENT_CHK_COL_CLAUSE := V_ENT_CHK_COL_CLAUSE || V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID ENT_ID_'||V_LOOP_COUNTER_J ||', REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' ENT_ID_VALUE_'||V_LOOP_COUNTER_J ||',' ;

            V_ENT_WHERE_CLAUSE := V_ENT_WHERE_CLAUSE||'OR ('|| V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID IS NULL AND REQ_TAB_'||V_LOOP_COUNTER_J||'.'|| V_RHS || ' IS NOT NULL )';
            ---fix end for  40513---creating entity validation queries

            ELSE


              SELECT TC.TC_PHYSICAL_NAME
                INTO V_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_FLD_ID = J.WFM_RHS_FLD_ID
                 and TC.TC_TABLES_ID = V_TSK_TAB_ID;

              --V_RHS_QUERY := '(SELECT '||V_RHS||' FROM ' || V_TASK_TABLE || ' WHERE REQUEST_ID = '||I.REQUEST_ID||' AND TASK_NODE = '||J.WFM_RELATED_WTA_ID||')';

            --PI_TASK_RECORD

                /*V_RHS_CLAUSE :=V_RHS_CLAUSE||'TSK_GTT.'||V_RHS||',';*/


              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;


            --fix start for OF-53369----Multilevel Task node update handling
                SELECT M.WFM_RELATED_WTA_ID
                INTO V_WFM_RELATED_WTA_ID
                FROM WF_FIELDS_MAPPING M
               WHERE M.WFM_WFMS_ID = I.WF_FLDMAPPINGS_SET_ID
                 AND M.WFM_LHS_ENT_ID = V_WFM_LHS_ENT_ID;

              SELECT S.WFCA_WTA_ID
                INTO V_WFCA_WTA_ID
                FROM WF_COMMON_ACTIONS S
               WHERE S.WFCA_ID = I.ACTION_NODE_ID;

               if V_WFM_RELATED_WTA_ID = V_WFCA_WTA_ID then

                 /*V_RHS_CLAUSE :=  RTRIM(V_RHS_CLAUSE,',') ;*/

              --fix end for OF-53369----Multilevel Task node update handling
              V_GTT_CLAUSE:='(SELECT REQ_TAB.ASSOCIATED_DATA_RECORD_ID DATA_REC_ID,TSK_GTT.'||V_RHS||' FROM '||V_TSK_GTT||' TSK_GTT JOIN '||V_REQ_TABLE||' REQ_TAB ON
                                  TSK_GTT.REQUEST_ID=REQ_TAB.REQUEST_ID)';

              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_GTT_CLAUSE||' TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER) '||
                                 ' LEFT OUTER JOIN '|| V_ENT_TABLE || ' '||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||' ON('||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL||' =  TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';




            --fix start for OF-53369----Multilevel Task node update handling
              ELSE
             V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN (SELECT TAB_TASK.'||V_RHS ||',ASSOCIATED_DATA_RECORD_ID DATA_REC_ID FROM '||V_TASK_TABLE||' TAB_TASK JOIN '||
                                  V_REQ_TABLE ||' TAB_REQ ON TAB_TASK.REQUEST_ID = TAB_REQ.REQUEST_ID JOIN WF_TASK_ASSIGNMENTS WTA
                                              ON WTA.WTA_NAME = TAB_TASK.TASK_NODE
                                              WHERE WTA.WTA_ID ='|| V_WFM_RELATED_WTA_ID ||' AND TAB_REQ.REQUEST_ID IN (' || V_Request_IDs_comma_sperated ||'))  TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER) '||
                                 ' LEFT OUTER JOIN '|| V_ENT_TABLE || ' '||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||' ON('||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL||' =  TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';

                END IF;
            --fix end for OF-53369----Multilevel Task node update handling

            V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID ENT_ID_'||V_LOOP_COUNTER_J;


              --V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '(SELECT E_INTERNAL_ID FROM '||V_ENT_TABLE||' WHERE '||V_ENT_KEY_COL||' = (SELECT '||V_RHS||' FROM '||PI_TASK_RECORD||'))';

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||'MRG.ENT_ID_'||V_LOOP_COUNTER_J;

---fix start for  40513---creating entity validation queries
            V_ENT_CHK_COL_CLAUSE := V_ENT_CHK_COL_CLAUSE || V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID ENT_ID_'||V_LOOP_COUNTER_J ||',TSK_TAB_'||V_LOOP_COUNTER_J||'.' ||V_RHS ||' ENT_ID_VALUE_'||V_LOOP_COUNTER_J ||',' ;

            V_ENT_WHERE_CLAUSE := V_ENT_WHERE_CLAUSE|| 'OR ('||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID IS NULL AND TSK_TAB_'||V_LOOP_COUNTER_J||'.'|| V_RHS || ' IS NOT NULL )';

---fix end for  40513---creating entity validation queries

            END IF;

            ---
            ELSIF (J.WFM_MAPPING_TYPE = 7) THEN    --RELATED RECORD ENTITY



            IF (J.WFM_RELATED_RECORD_TYPE = 0) THEN

              SELECT TC.TC_PHYSICAL_NAME,
                     TC.ENT_TABLE,
                     TC.ENT_KEY_COL
                INTO V_RHS,V_ENT_TABLE_RHS,V_ENT_KEY_COL_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_ENTITY_ID = J.WFM_RHS_ENT_ID
                 and TC.TC_TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;

              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;


              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN ( SELECT LENT.E_INTERNAL_ID LEFT_ENT, RENT.E_INTERNAL_ID RIGHT_ENT FROM '||V_ENT_TABLE||' LENT INNER JOIN '||V_ENT_TABLE_RHS||' RENT
              ON (LENT.'||V_ENT_KEY_COL||' = RENT.'||V_ENT_KEY_COL_RHS||')) ENT_JOIN_'||V_LOOP_COUNTER_J||' ON (ENT_JOIN_'||V_LOOP_COUNTER_J||'.RIGHT_ENT = DT1.'||V_RHS||')';

              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || ' ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT ENT_ID_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||'MRG.ENT_ID_'||V_LOOP_COUNTER_J;

---fix start for  40513---creating entity validation queries
              V_ENT_CHK_COL_CLAUSE := V_ENT_CHK_COL_CLAUSE || ' ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT ENT_ID_'||V_LOOP_COUNTER_J ||',DT1.' ||V_RHS ||' ENT_ID_VALUE_'||V_LOOP_COUNTER_J ||',' ;

              V_ENT_WHERE_CLAUSE := V_ENT_WHERE_CLAUSE||'OR ( ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT IS NULL AND DT1.'|| V_RHS || ' IS NOT NULL )';

---fix end for  40513---creating entity validation queries

             -- V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_RHS;

            ELSIF (J.WFM_RELATED_RECORD_TYPE = 1) THEN
               SELECT TC.TC_PHYSICAL_NAME,
                     TC.ENT_TABLE,
                     TC.ENT_KEY_COL
                INTO V_RHS,V_ENT_TABLE_RHS,V_ENT_KEY_COL_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_ENTITY_ID = J.WFM_RHS_ENT_ID
                 and TC.TC_TABLES_ID = V_REQ_TAB_ID;

              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;

            -- OF-40311: Fix for duplicate request records with same data record associated id
            -- Added "and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) '||"
              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_REQ_TABLE||' REQ_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (REQ_TAB_'||V_LOOP_COUNTER_J||'.ASSOCIATED_DATA_RECORD_ID = DT1.ROW_IDENTIFIER)  and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) '||
                                ' LEFT OUTER JOIN ( SELECT LENT.E_INTERNAL_ID LEFT_ENT, RENT.E_INTERNAL_ID RIGHT_ENT FROM '||V_ENT_TABLE||' LENT INNER JOIN '||V_ENT_TABLE_RHS||' RENT
              ON (LENT.'||V_ENT_KEY_COL||' = RENT.'||V_ENT_KEY_COL_RHS||')) ENT_JOIN_'||V_LOOP_COUNTER_J||' ON (ENT_JOIN_'||V_LOOP_COUNTER_J||'.RIGHT_ENT =  REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';

              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || ' ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT ENT_ID_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||'MRG.ENT_ID_'||V_LOOP_COUNTER_J;

---fix start for  40513---creating entity validation queries
              V_ENT_CHK_COL_CLAUSE := V_ENT_CHK_COL_CLAUSE || ' ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT ENT_ID_'||V_LOOP_COUNTER_J|| ', REQ_TAB_'||V_LOOP_COUNTER_J||'.' ||V_RHS ||' ENT_ID_VALUE_'||V_LOOP_COUNTER_J ||',' ;

              V_ENT_WHERE_CLAUSE := V_ENT_WHERE_CLAUSE||'OR ( ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT IS NULL AND REQ_TAB_'||V_LOOP_COUNTER_J||'.'|| V_RHS || ' IS NOT NULL )';
---fix end for  40513---creating entity validation queries

              --V_RHS_QUERY := '(SELECT '||V_RHS||' FROM ' || V_REQ_TABLE || ' WHERE REQUEST_ID = '||I.REQUEST_ID||')';

              --V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_RHS_QUERY;
            ELSE



              SELECT TC.TC_PHYSICAL_NAME,
                     TC.ENT_TABLE,
                     TC.ENT_KEY_COL
                INTO V_RHS,V_ENT_TABLE_RHS,V_ENT_KEY_COL_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_ENTITY_ID = J.WFM_RHS_ENT_ID
                 and TC.TC_TABLES_ID = V_TSK_TAB_ID;


                /*V_RHS_CLAUSE :=V_RHS_CLAUSE||'TSK_GTT.'||V_RHS||',';*/

                /*V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||(PI_TASK_RECORD)||' TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (1=1) '||
                                 ' LEFT OUTER JOIN '|| V_ENT_TABLE || ' '||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||' ON('||V_ENT_TABLE||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL||' =  TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';

                             */
              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;

              --fix start for OF-53369----Multilevel Task node update handling
                SELECT M.WFM_RELATED_WTA_ID
                INTO V_WFM_RELATED_WTA_ID
                FROM WF_FIELDS_MAPPING M
               WHERE M.WFM_WFMS_ID = I.WF_FLDMAPPINGS_SET_ID
                 AND M.WFM_LHS_ENT_ID = V_WFM_LHS_ENT_ID;

              SELECT S.WFCA_WTA_ID
                INTO V_WFCA_WTA_ID
                FROM WF_COMMON_ACTIONS S
               WHERE S.WFCA_ID = I.ACTION_NODE_ID;

               if V_WFM_RELATED_WTA_ID = V_WFCA_WTA_ID then

               /*V_RHS_CLAUSE :=  RTRIM(V_RHS_CLAUSE,',') ;*/
              --fix end for OF-53369----Multilevel Task node update handling.
              V_GTT_CLAUSE:='(SELECT REQ_TAB.ASSOCIATED_DATA_RECORD_ID DATA_REC_ID,TSK_GTT.'||V_RHS||' FROM '||V_TSK_GTT||' TSK_GTT JOIN '||V_REQ_TABLE||' REQ_TAB ON
                                  TSK_GTT.REQUEST_ID=REQ_TAB.REQUEST_ID)';

              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_GTT_CLAUSE||' TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER)
                                 LEFT OUTER JOIN ( SELECT LENT.E_INTERNAL_ID LEFT_ENT, RENT.E_INTERNAL_ID RIGHT_ENT FROM '||V_ENT_TABLE||' LENT INNER JOIN '||V_ENT_TABLE_RHS||' RENT
              ON (LENT.'||V_ENT_KEY_COL||' = RENT.'||V_ENT_KEY_COL_RHS||')) ENT_JOIN_'||V_LOOP_COUNTER_J||' ON (ENT_JOIN_'||V_LOOP_COUNTER_J||'.RIGHT_ENT =   TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';


               --fix START for OF-53369----Multilevel Task node update handling
              ELSE

              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN (SELECT TAB_TASK.'||V_RHS ||',ASSOCIATED_DATA_RECORD_ID DATA_REC_ID FROM '||V_TASK_TABLE||' TAB_TASK JOIN '||
                                  V_REQ_TABLE ||' TAB_REQ ON TAB_TASK.REQUEST_ID = TAB_REQ.REQUEST_ID JOIN WF_TASK_ASSIGNMENTS WTA
                                              ON WTA.WTA_NAME = TAB_TASK.TASK_NODE
                                              WHERE WTA.WTA_ID ='|| V_WFM_RELATED_WTA_ID ||' AND TAB_REQ.REQUEST_ID IN (' || V_Request_IDs_comma_sperated ||')) TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER)
                                 LEFT OUTER JOIN ( SELECT LENT.E_INTERNAL_ID LEFT_ENT, RENT.E_INTERNAL_ID RIGHT_ENT FROM '||V_ENT_TABLE||' LENT INNER JOIN '||V_ENT_TABLE_RHS||' RENT
              ON (LENT.'||V_ENT_KEY_COL||' = RENT.'||V_ENT_KEY_COL_RHS||')) ENT_JOIN_'||V_LOOP_COUNTER_J||' ON (ENT_JOIN_'||V_LOOP_COUNTER_J||'.RIGHT_ENT =   TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';

                        END IF;
              --fix end for OF-53369----Multilevel Task node update handling
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE ||' ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT ENT_ID_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||'MRG.ENT_ID_'||V_LOOP_COUNTER_J;

---fix start for  40513---creating entity validation queries
              V_ENT_CHK_COL_CLAUSE := V_ENT_CHK_COL_CLAUSE || ' ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT ENT_ID_'||V_LOOP_COUNTER_J ||', TSK_TAB_'||V_LOOP_COUNTER_J||'.' ||V_RHS ||' ENT_ID_VALUE_'||V_LOOP_COUNTER_J ||',' ;

              V_ENT_WHERE_CLAUSE := V_ENT_WHERE_CLAUSE||'OR ( ENT_JOIN_'||V_LOOP_COUNTER_J||'.LEFT_ENT IS NULL AND TSK_TAB_'||V_LOOP_COUNTER_J||'.'|| V_RHS || ' IS NOT NULL )';
---fix end for  40513---creating entity validation queries

              --V_RHS_QUERY := '(SELECT '||V_RHS||' FROM ' || V_TASK_TABLE || ' WHERE REQUEST_ID = '||I.REQUEST_ID||' AND TASK_NODE = '||J.WFM_RELATED_WTA_ID||')';

              --V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_RHS_QUERY;
            END IF;
            ---

          END IF;

---fix start for  40513---creating entity validation queries
 IF (J.WFM_MAPPING_TYPE in (6,7)) THEN
          V_ENT_CHK_CLAUSE :=  RTRIM(V_ENT_CHK_COL_CLAUSE,',') ;
      V_ENT_WHERE_CLAUSE := LTRIM (V_ENT_WHERE_CLAUSE,'OR');

     /* V_ENT_CHK_CLAUSE := ' SELECT DT1.ROW_IDENTIFIER DT1_ROW_IDENTIFIER ,'|| V_ENT_CHK_CLAUSE|| ' FROM '||V_DT_ENT_TBL_NAME||' DT1 '|| V_ENT_JOIN_CLAUSE ||' INNER JOIN TABLE(:1)
                            ON  (ASSOCIATED_RECORD_ID = DT1.ROW_IDENTIFIER) WHERE ('|| V_ENT_WHERE_CLAUSE||')';
     */

     ---CHANGE START FOR OF-63929--- REMOVING EXTRA COLUMN AND APPLYING ROWNUM=1
    /* V_ENT_CHK_CLAUSE := 'SELECT COUNT(*) FROM ( SELECT DT1.ROW_IDENTIFIER DT1_ROW_IDENTIFIER ,'|| V_ENT_CHK_CLAUSE|| ' FROM '||V_DT_ENT_TBL_NAME||' DT1 '|| V_ENT_JOIN_CLAUSE ||' INNER JOIN TABLE(:1)
                            ON  (ASSOCIATED_RECORD_ID = DT1.ROW_IDENTIFIER) WHERE ('|| V_ENT_WHERE_CLAUSE||'))';*/
        V_ENT_CHK_CLAUSE := ' SELECT COUNT(*) FROM '||V_DT_ENT_TBL_NAME||' DT1 '|| V_ENT_JOIN_CLAUSE ||' INNER JOIN TABLE(:1)
                            ON  (ASSOCIATED_RECORD_ID = DT1.ROW_IDENTIFIER) WHERE ('|| V_ENT_WHERE_CLAUSE||' ) AND ROWNUM=1 ';
     ---CHANGE END FOR OF-63929

       EXECUTE IMMEDIATE V_ENT_CHK_CLAUSE INTO V_INVALID_ENT_CNT USING PI_COLTYPE_ACTION_DETAILS;
       --DBMS_OUTPUT.put_line('PO_ENTITY_VALIDATION: '||PO_ENTITY_VALIDATION);


       IF V_INVALID_ENT_CNT <> 0 THEN
        PO_ENTITY_VALIDATION := 0;
        EXIT;
      END IF;
END IF;

---fix end for  40513---creating entity validation queries

----ADDED V_FLD_LENGTH, V_IS_REQUIRED FOR OF-40373
----Added V_FLD_ID for OF-53369----Multilevel Task node update handling
      ELSIF (J.WFM_LHS_TYPE = 2) THEN --FIELD
           SELECT TC.TC_PHYSICAL_NAME, fld.fld_data_type ,fld.fld_length, tac.tc_is_required,fld.fld_id
            INTO V_LHS, V_FLD_DATA_TYPE, V_FLD_LENGTH, V_IS_REQUIRED,V_FLD_ID
            FROM TABLE(T_TABLE_COLS) TC
            inner join fields fld
            on fld_id=TC.TC_FLD_ID
      join table_columns tac
            on tac.tc_tables_id = tc.tc_tables_id
            AND TAC.TC_FLD_ID = TC.TC_FLD_ID
            WHERE TC.TC_FLD_ID = J.WFM_LHS_FLD_ID
           AND TC.TC_TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;

           V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_LHS || ' = ';


          IF (J.WFM_MAPPING_TYPE = 1) THEN

            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' NULL';

---fix start for  40373---Data length validation
  IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK ||' 1=2 AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;
---fix END for  40373---Data length validation

          ELSIF (J.WFM_MAPPING_TYPE = 2) THEN

-- fix for OF-40381. did special handling for boolean data type since java code is storing value in a non-standard way in WFM table. storing true/false instead for 1/0
-- Also did special handling for date and datetime
---of-40634   DB upgrade to replace "true/false" with "1/0" for boolean field mapping with constant value(changed true to 1 and false to 0)
             if (V_FLD_DATA_TYPE=2 and J.WFM_CONSTANT_VALUE='1') then -- boolean
                          V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || 1;
              elsif (V_FLD_DATA_TYPE=2 and J.WFM_CONSTANT_VALUE='0') then                -- boolean
                          V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || 0;
              elsif (V_FLD_DATA_TYPE=6 ) then          -- number
            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||  J.WFM_CONSTANT_VALUE ;
            elsif (V_FLD_DATA_TYPE=3 ) then             -- date
            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||  'to_date('''|| J.WFM_CONSTANT_VALUE || ''', ''YYYY-MM-dd'')' ;
            elsif (V_FLD_DATA_TYPE=5 ) then             -- datetime
            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE ||  'to_timestamp('''|| J.WFM_CONSTANT_VALUE || ''', ''YYYY-MM-dd HH24:MI:SS'')' ;
               else
----Fix for OF-50688 Single quote in a string is replaced by double quotes
            V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '''' || replace ( J.WFM_CONSTANT_VALUE,'''', '''''')  || '''';
            end if;

            /*ELSIF(J.WFM_MAPPING_TYPE = 3)THEN
              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '';
            ELSIF(J.WFM_MAPPING_TYPE = 4)THEN
              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '';
            ELSIF(J.WFM_MAPPING_TYPE = 5)THEN
              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || '';*/
          ELSIF (J.WFM_MAPPING_TYPE = 6) THEN   --RELATED RECORD FIELD

            IF (J.WFM_RELATED_RECORD_TYPE = 0) THEN
              SELECT TC.TC_PHYSICAL_NAME
                INTO V_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_FLD_ID = J.WFM_RHS_FLD_ID
                 and TC.TC_TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' DT.'||V_RHS;

        ---fix start for  40373---Data length validation
              --------------RHS length validation
              if V_RHS = V_LHS THEN
                NULL;
                ELSE
              if V_FLD_DATA_TYPE =1 then
               V_RHS_VALIDATION := V_RHS_VALIDATION||' NVL(LENGTH(DT1.'||V_RHS||' ),0) <= '||V_FLD_LENGTH||' AND ' ;

               elsif V_FLD_DATA_TYPE = 6 then
               V_RHS_VALIDATION :=V_RHS_VALIDATION|| ' ( case when DT1.'||V_RHS ||' like ''%.%'' then
               NVL(LENGTH(SUBSTR(DT1.'||V_RHS ||',INSTR(DT1.'||V_RHS ||',''.'',1,1)+1)),0)
               else '||V_FLD_LENGTH||' end <='||V_FLD_LENGTH||' ) AND ' ;

                end if;
                IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK ||' NVL(DT1.'||V_RHS||',''1'') = NVL(DT1.'||V_RHS||',''2'') AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;
                END IF;
        ---fix end for  40373---Data length validation

            ELSIF (J.WFM_RELATED_RECORD_TYPE = 1) THEN
              SELECT TC.TC_PHYSICAL_NAME
                INTO V_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_FLD_ID = J.WFM_RHS_FLD_ID
                 and TC.TC_TABLES_ID = V_REQ_TAB_ID;

             IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
             END IF;

            V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_REQ_TABLE||' REQ_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (REQ_TAB_'||V_LOOP_COUNTER_J||'.ASSOCIATED_DATA_RECORD_ID = DT1.ROW_IDENTIFIER)  and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) ';


             V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || ' REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' ENT_KEY_'||V_LOOP_COUNTER_J;

             V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' MRG.ENT_KEY_'||V_LOOP_COUNTER_J;

             ---fix start for  40373---Data length validation
             --------------RHS length validation
             if V_FLD_DATA_TYPE =1 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' NVL(LENGTH(REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' ),0) <= '||V_FLD_LENGTH ||' AND '  ;

               elsif V_FLD_DATA_TYPE = 6 then
               V_RHS_VALIDATION :=V_RHS_VALIDATION || ' ( case when REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' like ''%.%'' then
               NVL(LENGTH(SUBSTR(REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',INSTR(REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',''.'',1,1)+1)),0)
               else '||V_FLD_LENGTH||' end <='||V_FLD_LENGTH||' ) AND ';

                end if;

             IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK || ' NVL(REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',''1'') = NVL(REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',''2'') AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;


       ---fix end for  40373---Data length validation


            ELSE




              SELECT TC.TC_PHYSICAL_NAME
                INTO V_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_FLD_ID = J.WFM_RHS_FLD_ID
                 and TC.TC_TABLES_ID = V_TSK_TAB_ID;

                 /* V_RHS_CLAUSE :=V_RHS_CLAUSE||'TSK_GTT.'||V_RHS||',';*/


              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;
              --fix start for OF-53369----Multilevel Task node update handling
                SELECT M.WFM_RELATED_WTA_ID
                INTO V_WFM_RELATED_WTA_ID
                FROM WF_FIELDS_MAPPING M
               WHERE M.WFM_WFMS_ID = I.WF_FLDMAPPINGS_SET_ID
                 AND M.WFM_LHS_FLD_ID = V_FLD_ID;

              SELECT S.WFCA_WTA_ID
                INTO V_WFCA_WTA_ID
                FROM WF_COMMON_ACTIONS S
               WHERE S.WFCA_ID = I.ACTION_NODE_ID;

               if V_WFM_RELATED_WTA_ID = V_WFCA_WTA_ID then
              --fix end for OF-53369----Multilevel Task node update handling
              /*V_RHS_CLAUSE :=  RTRIM(V_RHS_CLAUSE,',') ;*/

              V_GTT_CLAUSE:='(SELECT REQ_TAB.ASSOCIATED_DATA_RECORD_ID DATA_REC_ID,TSK_GTT.'||V_RHS||' FROM '||V_TSK_GTT||' TSK_GTT JOIN '||V_REQ_TABLE||' REQ_TAB ON
                                  TSK_GTT.REQUEST_ID=REQ_TAB.REQUEST_ID)';

              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_GTT_CLAUSE||' TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER) ';


               --fix start for OF-53369----Multilevel Task node update handling
              else

              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT JOIN '||' (SELECT TAB_TASK.'||V_RHS ||',ASSOCIATED_DATA_RECORD_ID DATA_REC_ID FROM '||V_TASK_TABLE||' TAB_TASK JOIN '||
                                  V_REQ_TABLE ||' TAB_REQ ON TAB_TASK.REQUEST_ID = TAB_REQ.REQUEST_ID JOIN WF_TASK_ASSIGNMENTS WTA
                                              ON WTA.WTA_NAME = TAB_TASK.TASK_NODE
                                              WHERE WTA.WTA_ID ='|| V_WFM_RELATED_WTA_ID ||' AND TAB_REQ.REQUEST_ID IN (' || V_Request_IDs_comma_sperated ||')) TSK_TAB_'||V_LOOP_COUNTER_J ||
                                ' ON TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID = DT1.ROW_IDENTIFIER' ;
                                 --' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER) ';

               end if;
              --fix end for OF-53369----Multilevel Task node update handling


              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE ||' TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' ENT_KEY_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' MRG.ENT_KEY_'||V_LOOP_COUNTER_J;
          ---fix start for  40373---Data length validation
            --------------RHS length validation
             if V_FLD_DATA_TYPE =1 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' NVL(LENGTH(TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' ),0) <= '||V_FLD_LENGTH ||' AND ';

               elsif V_FLD_DATA_TYPE = 6 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' ( case when TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||' like ''%.%'' then
               NVL(LENGTH(SUBSTR(TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',INSTR(TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',''.'',1,1)+1)),0)
               else '||V_FLD_LENGTH||' end <='||V_FLD_LENGTH||' ) AND ';

                end if;

               IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK || ' NVL(TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',''1'') = NVL(TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||',''2'') AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;


      ---fix end for  40373---Data length validation


            END IF;




            ---
            ELSIF (J.WFM_MAPPING_TYPE = 7) THEN    --RELATED RECORD ENTITY

            IF (J.WFM_RELATED_RECORD_TYPE = 0) THEN
              SELECT TC.TC_PHYSICAL_NAME,
                     TC.ENT_TABLE,
                     TC.ENT_KEY_COL
                INTO V_RHS,V_ENT_TABLE_RHS,V_ENT_KEY_COL_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_ENTITY_ID = J.WFM_RHS_ENT_ID
                 and TC.TC_TABLES_ID = PI_ID_OF_TABLE_TO_BE_UPDATED;

              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;

            --OF-40850
              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_ENT_TABLE_RHS||' RGHTENT_'||V_LOOP_COUNTER_J||' ON ( RGHTENT_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID = DT1.'||V_RHS||')';

              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE || ' RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' ENT_KEY_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' MRG.ENT_KEY_'||V_LOOP_COUNTER_J;

      ---fix start for  40373---Data length validation
              --------------RHS length validation
             if V_FLD_DATA_TYPE =1 then
               V_RHS_VALIDATION :=V_RHS_VALIDATION || ' NVL(LENGTH(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' ),0) <= '||V_FLD_LENGTH ||' AND ';


               elsif V_FLD_DATA_TYPE = 6 then
               V_RHS_VALIDATION :=V_RHS_VALIDATION || ' ( case when RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' like ''%.%'' then
               NVL(LENGTH(SUBSTR(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',INSTR(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''.'',1,1)+1)),0)
               else '||V_FLD_LENGTH||' end <='||V_FLD_LENGTH||' ) AND ';

                end if;

                IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK || ' NVL(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''1'') = NVL(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''2'') AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;

      ---fix end for  40373---Data length validation

            ELSIF (J.WFM_RELATED_RECORD_TYPE = 1) THEN
              SELECT TC.TC_PHYSICAL_NAME,
                     TC.ENT_TABLE,
                     TC.ENT_KEY_COL
                INTO V_RHS,V_ENT_TABLE_RHS,V_ENT_KEY_COL_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_ENTITY_ID = J.WFM_RHS_ENT_ID
                 and TC.TC_TABLES_ID = V_REQ_TAB_ID;

              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;

            -- OF-40311: Fix for duplicate request records with same data record associated id
            -- Added "and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) '||"
              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_REQ_TABLE||' REQ_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (REQ_TAB_'||V_LOOP_COUNTER_J||'.ASSOCIATED_DATA_RECORD_ID = DT1.ROW_IDENTIFIER)   and (REQ_TAB_'||V_LOOP_COUNTER_J||'.REQUEST_ID in ('|| V_Request_IDs_comma_sperated ||')) '||
                                ' LEFT OUTER JOIN '||V_ENT_TABLE_RHS||' RGHTENT_'||V_LOOP_COUNTER_J||' ON (RGHTENT_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID =  REQ_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';

              V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE ||' RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' ENT_KEY_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' MRG.ENT_KEY_'||V_LOOP_COUNTER_J;


              --V_RHS_QUERY      := '(SELECT '||V_RHS||' FROM ' || V_REQ_TABLE || ' WHERE REQUEST_ID = '||I.REQUEST_ID||')';

              --V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_RHS_QUERY;

      ---fix start for  40373---Data length validation
             --------------RHS length validation
             if V_FLD_DATA_TYPE =1 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' NVL(LENGTH(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' ),0) <= '||V_FLD_LENGTH||' AND ';



               elsif V_FLD_DATA_TYPE = 6 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' ( case when RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' like ''%.%'' then
               NVL(LENGTH(SUBSTR(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',INSTR(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''.'',1,1)+1)),0)
               else '||V_FLD_LENGTH||' end <='||V_FLD_LENGTH||' ) AND ';

                end if;

                IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK || ' NVL(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''1'') = NVL(RGHTENT_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''2'') AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;

            ---fix end for  40373---Data length validation



            ELSE



             SELECT TC.TC_PHYSICAL_NAME,
                     TC.ENT_TABLE,
                     TC.ENT_KEY_COL
                INTO V_RHS,V_ENT_TABLE_RHS,V_ENT_KEY_COL_RHS
                FROM TABLE(T_TABLE_COLS) TC
               WHERE TC.TC_ENTITY_ID = J.WFM_RHS_ENT_ID
                 and TC.TC_TABLES_ID = V_TSK_TAB_ID;

                 /*V_RHS_CLAUSE :=V_RHS_CLAUSE||','||'TSK_GTT.'||V_RHS||','; */

         --of-40365  removed "AND V_MRG_SELECT_CLAUSE <> ''"
              IF (V_MRG_SELECT_CLAUSE IS NOT NULL) THEN
                V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE||',';
              END IF;

              --fix start for OF-53369----Multilevel Task node update handling
                SELECT M.WFM_RELATED_WTA_ID
                INTO V_WFM_RELATED_WTA_ID
                FROM WF_FIELDS_MAPPING M
               WHERE M.WFM_WFMS_ID = I.WF_FLDMAPPINGS_SET_ID
                 AND M.WFM_LHS_FLD_ID = V_FLD_ID;

              SELECT S.WFCA_WTA_ID
                INTO V_WFCA_WTA_ID
                FROM WF_COMMON_ACTIONS S
               WHERE S.WFCA_ID = I.ACTION_NODE_ID;

               if V_WFM_RELATED_WTA_ID = V_WFCA_WTA_ID then
              --fix end for OF-53369----Multilevel Task node update handling
              /*V_RHS_CLAUSE :=  RTRIM(V_RHS_CLAUSE,',') ;*/

               V_GTT_CLAUSE:='(SELECT REQ_TAB.ASSOCIATED_DATA_RECORD_ID DATA_REC_ID,TSK_GTT.'||V_RHS||' FROM '||V_TSK_GTT||' TSK_GTT JOIN '||V_REQ_TABLE||' REQ_TAB ON
                                  TSK_GTT.REQUEST_ID=REQ_TAB.REQUEST_ID)';


              V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN '||V_GTT_CLAUSE||' TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER) '||
                                 ' LEFT OUTER JOIN '|| V_ENT_TABLE_RHS || ' '||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||' ON('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID =  TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';



               else
             V_ENT_JOIN_CLAUSE := V_ENT_JOIN_CLAUSE || ' LEFT OUTER JOIN (SELECT TAB_TASK.'||V_RHS ||',ASSOCIATED_DATA_RECORD_ID DATA_REC_ID FROM '||V_TASK_TABLE||' TAB_TASK JOIN '||
                                  V_REQ_TABLE ||' TAB_REQ ON TAB_TASK.REQUEST_ID = TAB_REQ.REQUEST_ID JOIN WF_TASK_ASSIGNMENTS WTA
                  ON WTA.WTA_NAME = TAB_TASK.TASK_NODE
                  WHERE WTA.WTA_ID ='|| V_WFM_RELATED_WTA_ID ||' AND TAB_REQ.REQUEST_ID IN (' || V_Request_IDs_comma_sperated ||')) TSK_TAB_'||V_LOOP_COUNTER_J||
                                 ' ON (TSK_TAB_'||V_LOOP_COUNTER_J||'.DATA_REC_ID=DT1.ROW_IDENTIFIER) '||
                                 ' LEFT OUTER JOIN '|| V_ENT_TABLE_RHS || ' '||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'
                 ON('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.E_INTERNAL_ID =  TSK_TAB_'||V_LOOP_COUNTER_J||'.'||V_RHS||')';


                 end if;


             ---fix start for  40373---Data length validation

                     V_MRG_SELECT_CLAUSE := V_MRG_SELECT_CLAUSE ||' '||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' ENT_KEY_'||V_LOOP_COUNTER_J;

              V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || ' MRG.ENT_KEY_'||V_LOOP_COUNTER_J;

             ---fix start for  40373---Data length validation
              --------------RHS length validation
             if V_FLD_DATA_TYPE =1 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' NVL(LENGTH('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' ),0) <= '||V_FLD_LENGTH||' AND ';

               elsif V_FLD_DATA_TYPE = 6 then
               V_RHS_VALIDATION := V_RHS_VALIDATION ||' ( case when '||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||' like ''%.%'' then
               NVL(LENGTH(SUBSTR('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',INSTR('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''.'',1,1)+1)),0)
               else '||V_FLD_LENGTH||' end <='||V_FLD_LENGTH||' ) AND ';

                end if;

              IF V_IS_REQUIRED = 1 THEN
                  V_NULL_CHECK := V_NULL_CHECK || ' NVL('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''1'') = NVL('||V_ENT_TABLE_RHS||'_'||V_LOOP_COUNTER_J||'.'||V_ENT_KEY_COL_RHS||',''2'') AND ';
                  V_REQUIRED_FLAG :=1;
                END IF;
             ---fix end for  40373---Data length validation

              --V_RHS_QUERY := '(SELECT '||V_RHS||' FROM ' || V_TASK_TABLE || ' WHERE REQUEST_ID = '||I.REQUEST_ID||' AND TASK_NODE = '||J.WFM_RELATED_WTA_ID||')';

              --V_SQL_SET_CLAUSE := V_SQL_SET_CLAUSE || V_RHS_QUERY;
            END IF;
            ---

          END IF;

        END IF;
V_PREV_WF_FLDMAPPINGS_SET_ID:= I.WF_FLDMAPPINGS_SET_ID;
      END LOOP;

     /* V_UPDATE_QUERY := 'UPDATE '|| V_DT_ENT_TBL_NAME ||' SET '
                        || V_SQL_SET_CLAUSE ||',ROW_IDENTIFIER = ROW_IDENTIFIER + 1'||
                        ' WHERE ROW_IDENTIFIER = '|| I.ASSOCIATED_RECORD_ID \*||' AND ROW_VERSION = '|| I.ASSOCIATED_RECORD_VERSION*\;*/

     IF V_SQL_SET_CLAUSE <> '' OR V_SQL_SET_CLAUSE IS NOT NULL THEN

     BEGIN
       V_UPDATE_QUERY := 'MERGE INTO '||V_DT_ENT_TBL_NAME||' DT '
                         ||' USING (SELECT DT1.ROW_IDENTIFIER DT1_ROW_IDENTIFIER';

       IF  V_MRG_SELECT_CLAUSE IS NOT NULL THEN
         V_UPDATE_QUERY :=  V_UPDATE_QUERY ||  ','||V_MRG_SELECT_CLAUSE;
       END IF;


---fix start for  40373---Data length validation

       IF V_REQUIRED_FLAG =0 THEN
       V_RHS_VALIDATION := rtrim(V_RHS_VALIDATION ,'AND ');
       ELSE
       V_NULL_CHECK := rtrim(V_NULL_CHECK ,'AND ');
       END IF;

       IF V_RHS_VALIDATION IS NULL
         THEN
           IF V_NULL_CHECK IS NOT NULL THEN
           V_RHS_VALIDATION := ' 1=1 AND ';
           ELSE
           V_RHS_VALIDATION := ' 1=1 ';
           END IF;
           V_RHS_FLAG:= 0;
         ELSE
           V_RHS_FLAG :=1;
           END IF;

---fix END for  40373---Data length validation

       /*V_UPDATE_QUERY :=  V_UPDATE_QUERY ||'
                           FROM '||V_DT_ENT_TBL_NAME||' DT1 '||V_ENT_JOIN_CLAUSE||' )  MRG '

                         ||' ON(DT.ROW_IDENTIFIER = MRG.DT1_ROW_IDENTIFIER AND DT.ROW_IDENTIFIER  IN (SELECT ASSOCIATED_RECORD_ID FROM TABLE(:1) '
                         ||' WHERE ACTION_NODE_ID = :2 ))'
                         ||' WHEN MATCHED THEN '
                         ||' UPDATE SET DT.ROW_VERSION = DT.ROW_VERSION + 1,'||V_SQL_SET_CLAUSE;*/

---fix START for  40373---Data length validation V_RHS_VALIDATION AND V_NULL_CHECK ADDED
V_UPDATE_QUERY :=  V_UPDATE_QUERY ||'
                           FROM '||V_DT_ENT_TBL_NAME||' DT1 '||V_ENT_JOIN_CLAUSE||'
                           WHERE ( '
                           || V_RHS_VALIDATION
                           || V_NULL_CHECK
                           ||' ))  MRG '
                         ||' ON(DT.ROW_IDENTIFIER = MRG.DT1_ROW_IDENTIFIER AND DT.ROW_IDENTIFIER  IN (SELECT ASSOCIATED_RECORD_ID FROM TABLE(:1) '
                         ||' WHERE ACTION_NODE_ID = :2 )'
                         --|| V_RHS_VALIDATION
                         ||')'
                         ||' WHEN MATCHED THEN '
                         ||' UPDATE SET DT.ROW_VERSION = DT.ROW_VERSION + 1,'||V_SQL_SET_CLAUSE;
---fix END for  40373---Data length validation

 --    insert_logs1('V_UPDATE_QUERY = '||V_UPDATE_QUERY);
 --    dbms_output.put_line(V_UPDATE_QUERY);

---fix START for  40373---Data length validation
       V_RHS_VALIDATION := rtrim(V_RHS_VALIDATION ,'AND ');

     V_ERROR_SELECT := '(SELECT DT1.ROW_IDENTIFIER DT1_ROW_IDENTIFIER
                           FROM '||V_DT_ENT_TBL_NAME||' DT1 '||V_ENT_JOIN_CLAUSE||'
                           WHERE ( '
                           || V_RHS_VALIDATION
                           ||' ) AND DT1.ROW_IDENTIFIER  IN (SELECT ASSOCIATED_RECORD_ID FROM TABLE(:2) WHERE ACTION_NODE_ID = :3 ))';
     --insert_logs1('V_ERROR_SELECT = '||V_ERROR_SELECT);
     ---,'|| V_MRG_SELECT_CLAUSE || '
     V_ERROR_SELECT_WITH_NOT := 'SELECT DT1.ROW_IDENTIFIER ID , 6 STATUS
                           FROM '||V_DT_ENT_TBL_NAME||' DT1 '||V_ENT_JOIN_CLAUSE||'
                           WHERE NOT ( '
                           || V_RHS_VALIDATION
                           ||' ) AND DT1.ROW_IDENTIFIER  IN (SELECT ASSOCIATED_RECORD_ID FROM TABLE(:1) WHERE ACTION_NODE_ID = :2 ))';
     --insert_logs1('V_UPDATE_QUERY = '||V_UPDATE_QUERY);
     --dbms_output.put_line(V_UPDATE_QUERY);

       V_RHS_VALIDATION := rtrim(V_NULL_CHECK ,'AND ');

     V_NULL_SELECT := '(SELECT DT1.ROW_IDENTIFIER DT1_ROW_IDENTIFIER
                           FROM '||V_DT_ENT_TBL_NAME||' DT1 '||V_ENT_JOIN_CLAUSE||'
                           WHERE ( '
                           || V_NULL_CHECK
                           ||' ) AND DT1.ROW_IDENTIFIER  IN (SELECT ASSOCIATED_RECORD_ID FROM TABLE(:4) WHERE ACTION_NODE_ID = :5 ))';

     V_NULL_SELECT_WITH_NOT := 'SELECT DT1.ROW_IDENTIFIER ID , 7 STATUS
                           FROM '||V_DT_ENT_TBL_NAME||' DT1 '||V_ENT_JOIN_CLAUSE||'
                           WHERE NOT ( '
                           || V_NULL_CHECK
                           ||' ) AND DT1.ROW_IDENTIFIER  IN (SELECT ASSOCIATED_RECORD_ID FROM TABLE(:1) WHERE ACTION_NODE_ID = :2 ))';

---fix END for  40373---Data length validation

---commenting due to OF-65604 --updating records after getting all the validations done
       --EXECUTE IMMEDIATE V_UPDATE_QUERY USING PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID;


---fix START for  40373---Data length validation
--COMMENTED DUE TO OF-40373 CHANGE
       /*EXECUTE IMMEDIATE '
       SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
       SELECT  ASSOCIATED_RECORD_ID ID , 1 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||' AND ASSOCIATED_RECORD_ID IN (SELECT ROW_IDENTIFIER FROM '||V_DT_ENT_TBL_NAME||')
       UNION
       SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:2))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,V_STATUS;*/

---NEW VALIDATION QUERY ADDED FOR SUCCESSFUL RECORDS
IF V_REQUIRED_FLAG=0 THEN
       EXECUTE IMMEDIATE '
       SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
       SELECT  ASSOCIATED_RECORD_ID ID , 1 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||' AND ASSOCIATED_RECORD_ID IN (SELECT ROW_IDENTIFIER FROM '||V_DT_ENT_TBL_NAME||')
       AND ASSOCIATED_RECORD_ID IN '||V_ERROR_SELECT ||'
       UNION
       SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:4))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID,V_STATUS;

       ELSIF V_REQUIRED_FLAG=1 THEN


       EXECUTE IMMEDIATE '
       SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
       SELECT  ASSOCIATED_RECORD_ID ID , 1 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||' AND ASSOCIATED_RECORD_ID IN (SELECT ROW_IDENTIFIER FROM '||V_DT_ENT_TBL_NAME||')
       AND ASSOCIATED_RECORD_ID IN '||V_ERROR_SELECT ||'
       AND ASSOCIATED_RECORD_ID IN '||V_NULL_SELECT ||'
       UNION
       SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:6))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID,PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID,V_STATUS;


       END IF;
---fix END for  40373---Data length validation

       V_STATUS := PO_STATUS;

       EXECUTE IMMEDIATE '
       SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
       SELECT  ASSOCIATED_RECORD_ID ID , 4 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||' AND ASSOCIATED_RECORD_ID NOT IN (SELECT ROW_IDENTIFIER FROM '||V_DT_ENT_TBL_NAME||')
       UNION
       SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:2))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,V_STATUS;

       V_STATUS := PO_STATUS;


---fix START for  40373---Data length validation
----NEW PO_STATUS ADDED 6 FOR DATA LENGTH VALIDATION AND 7 FOR NULL CHECK
IF V_RHS_FLAG = 1
         THEN
       EXECUTE IMMEDIATE '
       SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (( '|| V_ERROR_SELECT_WITH_NOT ||'
       UNION
       SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:3))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID,V_STATUS;

       V_STATUS := PO_STATUS;
          END IF;

          IF V_REQUIRED_FLAG=1 THEN
             EXECUTE IMMEDIATE '
       SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (( '|| V_NULL_SELECT_WITH_NOT ||'
       UNION
       SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:3))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID,V_STATUS;

       V_STATUS := PO_STATUS;
          END IF;

---fix END for  40373---Data length validation

EXECUTE IMMEDIATE V_UPDATE_QUERY USING PI_COLTYPE_ACTION_DETAILS,I.ACTION_NODE_ID;
     EXCEPTION
       WHEN EXP_NULL_VALUE_ASSIGNED THEN
         EXECUTE IMMEDIATE '
         SELECT OBJTYPE_DR_UPDT_STATUS(ID, STATUS) FROM (
         SELECT  ASSOCIATED_RECORD_ID ID , 5 STATUS FROM TABLE(:1) WHERE ACTION_NODE_ID = '||I.ACTION_NODE_ID||'
         UNION
         SELECT ASSOCIATED_RECORD_ID, UPDATE_STATUS FROM TABLE(:2))' BULK COLLECT INTO PO_STATUS USING PI_COLTYPE_ACTION_DETAILS,V_STATUS;

         V_STATUS := PO_STATUS;
         CONTINUE;
     END;

     END IF;
     --dbms_output.put_line(V_UPDATE_QUERY);

    /* IF SQL%ROWCOUNT = 0 THEN
       PO_STATUS.EXTEND();
       V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
                 PO_STATUS(V_STATUS_COUNTER) := OBJTYPE_DR_UPDT_STATUS(ASSOCIATED_RECORD_ID => I.ASSOCIATED_RECORD_ID,
                                                                                     UPDATE_STATUS => 4);
     ELSE
       PO_STATUS.EXTEND();
       V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
                 PO_STATUS(V_STATUS_COUNTER) := OBJTYPE_DR_UPDT_STATUS(ASSOCIATED_RECORD_ID => I.ASSOCIATED_RECORD_ID,
                                                                                     UPDATE_STATUS => 1);
     END IF;*/



    END LOOP;


---fix start for  40513---creating entity validation queries
    /*FOR I IN (SELECT TC.TC_PHYSICAL_NAME, T.TABLES_PHYSICAL_NAME ENTITY_TABLE
              FROM (SELECT DISTINCT WFM_LHS_ENT_ID LHS_ENT_ID
                             FROM WF_FIELDS_MAPPING
                            WHERE WFM_WFMS_ID IN (SELECT WF_FLDMAPPINGS_SET_ID
                                                    FROM TABLE(PI_COLTYPE_ACTION_DETAILS))
                              AND WFM_LHS_TYPE = 1
                              AND WFM_MAPPING_TYPE <> 1)M
               INNER JOIN TABLE_COLUMNS TC
                       ON (M.LHS_ENT_ID = TC.TC_ENTITY_ID)
               INNER JOIN ENTITIES E
                       ON (M.LHS_ENT_ID = E.ENTITY_ID)
               INNER JOIN TABLES T
                       ON (E.ENTITY_TABLES_ID = T.TABLES_ID )) LOOP

     \* insert_logs1('
      SELECT COUNT(*)
        FROM (SELECT ENT_COL, E.E_INTERNAL_ID
                FROM (SELECT '||I.TC_PHYSICAL_NAME||' ENT_COL
                        FROM '||V_DT_ENT_TBL_NAME||'
                       WHERE ROW_IDENTIFIER IN
                             (SELECT ASSOCIATED_RECORD_ID
                                FROM TABLE(:1))) DE
                LEFT OUTER JOIN '||I.ENTITY_TABLE||' E
                  ON DE.ENT_COL = E.E_INTERNAL_ID)
       WHERE E_INTERNAL_ID IS NULL');
                        *\

      EXECUTE IMMEDIATE '
      SELECT COUNT(*)
        FROM (SELECT ENT_COL, E.E_INTERNAL_ID
                FROM (SELECT '||I.TC_PHYSICAL_NAME||' ENT_COL
                        FROM '||V_DT_ENT_TBL_NAME||'
                       WHERE ROW_IDENTIFIER IN
                             (SELECT ASSOCIATED_RECORD_ID
                                FROM TABLE(:1))) DE
                LEFT OUTER JOIN '||I.ENTITY_TABLE||' E
                  ON DE.ENT_COL = E.E_INTERNAL_ID)
       WHERE E_INTERNAL_ID IS NULL' INTO V_INVALID_ENT_CNT USING PI_COLTYPE_ACTION_DETAILS;

      IF V_INVALID_ENT_CNT <> 0 THEN
        PO_ENTITY_VALIDATION := 0;
        EXIT;
      END IF;

    END LOOP;*/
---fix end for  40513---creating entity validation queries

   /* SELECT COUNT(*) into v_unchanged_set_cnt
           FROM WF_FIELDS_MAPPING_SET S
          WHERE (S.WFMS_ID,S.WFMS_VERSION) IN
                (SELECT WF_FLDMAPPINGS_SET_ID, WF_FLDMAPPINGS_SET_VERSION
                   FROM TABLE(PI_COLTYPE_ACTION_DETAILS));

    IF v_unchanged_set_cnt <> PI_COLTYPE_ACTION_DETAILS.COUNT THEN
      PO_STATUS.EXTEND();
      V_STATUS_COUNTER := V_STATUS_COUNTER + 1;
      PO_STATUS(V_STATUS_COUNTER) := 2;
    END IF;*/
exception
  WHEN no_data_found then
    PO_ENTITY_VALIDATION := 0;


  END UPDATE_DATA_RECORD_ON_ACTION;



PROCEDURE PRC_WF_TASK_CREATION(PI_TASK_NODE NUMBER,
                               PI_WA_ID NUMBER,
                               PI_ANH_CLAUSE CLOB DEFAULT NULL,
                               PI_FIL_CONDITION CLOB DEFAULT NULL,
                               PI_ET_CONDITION CLOB DEFAULT NULL,
                               PI_ACT_TASK_NODE_ID COLTYPE_ID DEFAULT NULL,
                               PI_TASK_REQ_ID TABLETYPE_ID_ID DEFAULT NULL,
                               PI_MAP_TASK_NODE_LST COLTYPE_ID DEFAULT NULL,
                               PI_IS_ASSO_MAPPED NUMBER DEFAULT NULL,
                               PI_CNDT_JOIN_CLAUSE CLOB DEFAULT NULL,
                               PI_EXTERNAL_CNDT_JOIN_CLAUSE CLOB DEFAULT NULL) AS

---------QUERY VARIABLES
  V_TEMP_FAIL_INSERT_S            CLOB;
  V_ENT_FLD_SELECT_CLAUSE         CLOB;
  V_TASK_CREATION_SELECT          CLOB;
  V_FC_ANDQUERY                   CLOB;
  V_FC_QUERYAND                   CLOB;
  V_FIL_QUERY                     CLOB;
  V_EC_QUERY                      CLOB;
  V_EC_ANDQUERY                   CLOB;
  V_EC_QUERYAND                   CLOB;
  V_EC_RID                        CLOB;
  V_ET_CONDITION                  CLOB;
  V_WHEN_CLAUSE                   CLOB;
  V_SELECT_NORMAL                 CLOB;
  V_FROM_CLAUSE                   CLOB;
  V_REQ_COL_LIST                  CLOB;
  V_REQUEST_QRY                   CLOB;
  V_EXT_SEL                       CLOB;
  V_REQ_GTT_TAB                   CLOB := 'REQ_GTT_'||PI_WA_ID ;
  V_ASSO_GTT_TAB                  CLOB := 'ASSO_GTT_'||PI_WA_ID ;
  V_TASK_GTT_TAB                  CLOB := 'TASK_GTT_'||PI_WA_ID ;
  V_MULTINODE_CONDTION            CLOB;
  V_IS_ASSO_MAPPED                NUMBER:=PI_IS_ASSO_MAPPED;

-----ID VARIABLES
  V_REQ_TABLE                     VARCHAR2(100);
  V_TASK_TABLE                    VARCHAR2(100);
  V_REQ_TAB_ID                    NUMBER;
  V_TSK_TAB_ID                    NUMBER;
  V_WA_ID                         NUMBER;
  V_CUR                           SYS_REFCURSOR;
  V_MIN_VALUE                     NUMBER;
  V_MAX_VALUE                     NUMBER;
  V_TIME_STAMP                    TIMESTAMP;
  V_ASSIGN_ENT                    CLOB;
  V_ENT_INT_ID_CLAUSE             CLOB;
  V_ENT_INT_ID_ALIAS              CLOB;
  V_ENT_PHY_TABLE                 NUMBER;
  V_ENT_PHY_KEY_COL               CLOB;
  V_INT_ID                        NUMBER;
  V_OFFSET                        NUMBER;
  V_EXT_TAB_ID                    NUMBER;
  V_IS_SYS_TASK                   NUMBER:=0;
  V_ENT_CLAUSE                    CLOB;
  V_ENT_VALUE_CLAUSE              CLOB;
  V_ACTION_ACTOR                  CLOB :='User';
  V_DR_JOIN_CLAUSE                CLOB;
  V_NEXT_TN_ID                    NUMBER := PI_TASK_NODE;
  V_CUR_TN_ID                     COLTYPE_ID := PI_ACT_TASK_NODE_ID;
  V_REQ_ROWID                     CLOB;
  V_TRID_JOIN_CLS                 CLOB;
  V_TASK_REQUEST_QRY              CLOB;
  V_TASK_NODE_QRY                 CLOB;
  V_ANH_DATE_CLS                  CLOB;
  V_ANH_FLD_COL_NAME              CLOB;
  V_CUR_TN_COMMA_SEP              CLOB;
  V_ENTITY_FILTER                 CLOB;

BEGIN
/*
---------START LOGGING-----LOG PARAMETER OF SP TO DEBUG
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_TASK_NODE='||PI_TASK_NODE));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_WA_ID='||PI_WA_ID));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_ANH_CLAUSE='||PI_ANH_CLAUSE));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_FIL_CONDITION='||PI_FIL_CONDITION));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_ET_CONDITION='||PI_ET_CONDITION));

    IF V_CUR_TN_ID  IS NULL THEN
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('V_CUR_TN_ID IS NULL'));
      ELSIF  V_CUR_TN_ID  IS NOT NULL THEN
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('V_CUR_TN_ID IS NOT NULL'));
            COMMONS_UTILS.INSERT_LOGS(TO_CHAR('V_CUR_TN_ID.COUNT'||V_CUR_TN_ID.COUNT));
        END IF;
IF PI_ACT_TASK_NODE_ID IS NOT NULL THEN
             FOR I IN 1..PI_ACT_TASK_NODE_ID.COUNT LOOP
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_ACT_TASK_NODE_ID='||PI_ACT_TASK_NODE_ID(I)));
END LOOP;
END IF;

IF PI_TASK_REQ_ID IS NOT NULL THEN
      FOR I IN 1..PI_TASK_REQ_ID.COUNT LOOP
      COMMONS_UTILS.INSERT_LOGS('========='||I||'==========');
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('TASK ID='||PI_TASK_REQ_ID(I).ID1));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('REQUEST_ID='||PI_TASK_REQ_ID(I).ID2));
        END LOOP;
END IF;
IF PI_MAP_TASK_NODE_LST IS NOT NULL THEN
             FOR I IN 1..PI_MAP_TASK_NODE_LST.COUNT LOOP
      COMMONS_UTILS.INSERT_LOGS('========='||I||'==========');
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('TASK NODE ID ='||PI_MAP_TASK_NODE_LST(I)));
             END LOOP;
END IF;
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_IS_ASSO_MAPPED='||PI_IS_ASSO_MAPPED));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_CNDT_JOIN_CLAUSE='||PI_CNDT_JOIN_CLAUSE));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('PI_EXTERNAL_CNDT_JOIN_CLAUSE='||PI_EXTERNAL_CNDT_JOIN_CLAUSE));
---------END LOGGING-----LOG PARAMETER OF SP TO DEBUG
*/

---SELECTING WF INFO
SELECT W.WA_ID,
       W.WA_REQUESTS_TABLES_ID,
       TR.TABLES_PHYSICAL_NAME REQ_TABLE,
       W.WA_TASKS_TABLES_ID,
       TT.TABLES_PHYSICAL_NAME TASK_TABLE
      INTO V_WA_ID,V_REQ_TAB_ID, V_REQ_TABLE, V_TSK_TAB_ID, V_TASK_TABLE
  FROM (SELECT * FROM WORKFLOW_APPLICATIONS WHERE WA_ID = PI_WA_ID) W
  LEFT OUTER JOIN TABLES TR
    ON (W.WA_REQUESTS_TABLES_ID = TR.TABLES_ID)
  LEFT OUTER JOIN TABLES TT
    ON (W.WA_TASKS_TABLES_ID = TT.TABLES_ID);

  BEGIN
  -------GETTING THE OFFET VALUES FOR TASK CREATION IDS BY COUNTING THE RECORDS FROM REQUEST GTT

        IF V_CUR_TN_ID IS NULL OR  V_CUR_TN_ID.COUNT =0   THEN
     EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM  '||V_REQ_GTT_TAB INTO V_OFFSET;
     ELSE
     V_OFFSET:=PI_TASK_REQ_ID.COUNT;
     END IF;
     COMMONS_TABLES.GET_SET_AUTO_VALUE(V_TSK_TAB_ID,V_OFFSET,V_CUR);
        FETCH V_CUR INTO V_MIN_VALUE, V_MAX_VALUE,V_TIME_STAMP;
  END;

  V_TEMP_FAIL_INSERT_S:= 'INSERT ALL ';

  FOR I IN (SELECT *
              FROM WF_TASK_ASSIGNMENTS WTA
              WHERE WTA.WTA_ID = PI_TASK_NODE ) LOOP
  IF I.WTA_IS_CONDITION_BASED =1 AND V_FC_ANDQUERY IS NULL THEN----FOR FILTER CONDITIONS
    IF I.WTA_ET_IS_EXT_TABLE =1 THEN ------FOR EXTERNAL TABLE CONDITION
      IF PI_ET_CONDITION IS NOT NULL THEN -----*NEW* IF EXTARNAL TABLE IS MAPPED AND ALSO FILTERING BASED ON ET
    V_ET_CONDITION := ' ON (1 = 1 AND (' ||PI_ET_CONDITION|| '))' ;
      ELSE -----*NEW* IF EXTARNAL TABLE IS MAPPED AND NOT FILTERING BASED ON ET
        V_ET_CONDITION := ' ON (1 = 1 )' ;
      END IF;
    V_EC_QUERY :=' WHEN EXT_TAB_VLDTION_RESULT = ''FALSE'' THEN INTO WF_EXT_TABLE_VALIDATION_GTT
                   (WETVG_RESULT)
                   VALUES
                   (''FAILED DUE TO EXTERNAL TABLE VALIDATION'')';
    V_EC_ANDQUERY := ' AND EXT_TAB_VLDTION_RESULT = ''TRUE'' ';
    V_EC_QUERYAND := ' EXT_TAB_VLDTION_RESULT = ''TRUE'' AND ';
    V_EC_RID      := ' ,ET.ROW_IDENTIFIER EXT_ROW_IDENTIFIER ';
    V_TASK_CREATION_SELECT := ',
                               EXTERNAL_TABLE_CHECK AS
                               (SELECT CASE
                                               WHEN ((SELECT COUNT(*) UNMAPPED_CNT
                                               FROM TASK_CREATION
                                               WHERE NVL(EXT_ROW_IDENTIFIER, -1) = -1
                                               AND ROWNUM = 1) = 0) AND
                                               ((SELECT COUNT(*) MAPPING_CNT FROM TASK_CREATION) = '||V_OFFSET||')
                                       THEN
                                               ''TRUE''
                                       ELSE
                                               ''FALSE''
                                       END EXT_TAB_VLDTION_RESULT
                               FROM DUAL)
                               ';

 ---GETTING TABLE REFERENCE IDS
  SELECT TABLES_ID INTO V_EXT_TAB_ID
  FROM TABLE_REFERENCES
  JOIN TABLES
    ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
 WHERE TREF_ID = I.WTA_ET_TREF_ID;

WITH ENT AS (SELECT * FROM ENTITIES)
/*SELECT LISTAGG(CASE WHEN (LEVEL =1 AND  TC_PHYSICAL_NAME <>'ROW_VERSION')
                                   THEN 'T'||TC_TABLES_ID||'.'||TC_PHYSICAL_NAME ||' ' ||TC_PHYSICAL_NAME
                    WHEN ((LEVEL = 2 AND TC_COLUMN_TYPE IN(1,2)))
                                   THEN 'ET_EN'|| (SELECT ENTITY_ID  FROM ENT WHERE ENTITY_TABLES_ID = TC_TABLES_ID AND ENTITY_BASE_ENTITY IS NULL)
                      ||'.'||TC_PHYSICAL_NAME||' FLD'||TC_FLD_ID||'_'|| (SELECT ENTITY_ID  FROM ENT WHERE ENTITY_TABLES_ID = TC_TABLES_ID AND ENTITY_BASE_ENTITY IS NULL) END ,','  )
                      WITHIN GROUP (ORDER BY TC_ORDER) COL_LIST*/
SELECT LISTAGG_JAVA(OBJTYPE_WORD_DLM(CASE WHEN (LEVEL =1 AND  TC_PHYSICAL_NAME <>'ROW_VERSION')
                                   THEN 'T'||TC_TABLES_ID||'.'||TC_PHYSICAL_NAME ||' ' ||TC_PHYSICAL_NAME
                    WHEN ((LEVEL = 2 AND TC_COLUMN_TYPE IN(1,2)))
                                   THEN 'ET_EN'|| (SELECT ENTITY_ID  FROM ENT WHERE ENTITY_TABLES_ID = TC_TABLES_ID AND ENTITY_BASE_ENTITY IS NULL)
                      ||'.'||TC_PHYSICAL_NAME||' FLD'||TC_FLD_ID||'_'|| (SELECT ENTITY_ID  FROM ENT WHERE ENTITY_TABLES_ID = TC_TABLES_ID AND ENTITY_BASE_ENTITY IS NULL) END ,',',NULL))
   INTO V_EXT_SEL
   FROM TABLE_COLUMNS T
   START WITH TC_TABLES_ID =V_EXT_TAB_ID
   CONNECT BY  TC_TABLES_ID = PRIOR (SELECT ENTITY_TABLES_ID FROM ENT WHERE  TC_ENTITY_ID= ENTITY_ID);

           V_EXT_SEL:= ' LEFT OUTER JOIN (SELECT '|| V_EXT_SEL ||' FROM T'||V_EXT_TAB_ID;

   ------TO ADD JOIN CONDITION WITH THE ENTITY TABLES IN THE REFERRED EXTERNAL TABLE
   FOR J IN (WITH ENT AS (SELECT * FROM ENTITIES)
   SELECT DISTINCT TC_TABLES_ID,(SELECT ENTITY_ID  FROM ENT WHERE ENTITY_TABLES_ID = TC_TABLES_ID AND ENTITY_BASE_ENTITY IS NULL) ENT_ID  FROM TABLE_COLUMNS T
   WHERE LEVEL<>1
   START WITH TC_TABLES_ID =V_EXT_TAB_ID
   CONNECT BY  TC_TABLES_ID = PRIOR (SELECT ENTITY_TABLES_ID FROM ENT WHERE  TC_ENTITY_ID= ENTITY_ID))     LOOP

           V_EXT_SEL := V_EXT_SEL ||' LEFT OUTER JOIN T'|| J.TC_TABLES_ID || ' ET_EN'||J.ENT_ID||' ON T'||V_EXT_TAB_ID||'.E'||J.ENT_ID ||'='|| 'ET_EN'||J.ENT_ID||'.'||'E_INTERNAL_ID ';
   END LOOP;
           V_EXT_SEL:=V_EXT_SEL|| ') ET '|| PI_EXTERNAL_CNDT_JOIN_CLAUSE||' ';---ADDED PI_EXTERNAL_CNDT_JOIN_CLAUSE FOR PERIOD FIELD MAPPING

    END IF;

  V_FC_ANDQUERY := ' WHEN 1 = 1 '|| V_EC_ANDQUERY||' AND TASK_CONDITION = 1 ';
  V_FC_QUERYAND := V_EC_QUERYAND||' TASK_CONDITION = 1 AND ';
  V_FIL_QUERY   := ' ,(CASE
                     WHEN 1 = 1 AND ( '|| PI_FIL_CONDITION ||') THEN
                     1
                     ELSE
                     0
                     END) TASK_CONDITION '|| V_EC_RID;
  END IF;

    IF I.WTA_ACTION_ACTOR =2 THEN -----FOR SYSTEM TASK
      V_ENT_INT_ID_CLAUSE := ' ASSGN_TO_ENT_INT_ID ';
      V_ASSIGN_ENT := '-1 ASSGN_TO_ENT_INT_ID ';
      V_IS_SYS_TASK :=1;
      V_ACTION_ACTOR := 'System';

    ELSIF I.WTA_ENTITY_VALUE_TYPE = 1 -----FOR CONSTANT MAPPING
     THEN
      V_ENT_INT_ID_ALIAS :=   ' ASSGN_TO_ENT_INT_ID_'||I.WTA_ENTITY_ID ;
      V_ENT_INT_ID_CLAUSE := V_ENT_INT_ID_ALIAS;

      -----GETTING ENTITY TABLES ID AND KEY COLUMN FOR THE CONSTANT MAPPING
      SELECT TC_TABLES_ID, TC_PHYSICAL_NAME INTO V_ENT_PHY_TABLE,V_ENT_PHY_KEY_COL
        FROM ENTITIES E
        JOIN TABLE_COLUMNS TC
          ON E.ENTITY_TABLES_ID = TC.TC_TABLES_ID
       WHERE ENTITY_ID = I.WTA_ENTITY_ID
         AND TC_LOGIC_TYPE IN (1,5);

         BEGIN
        ---SELECTING INTERNAL ID OF ENTITY FROM CONSTANT MAPPING
        --EXECUTE IMMEDIATE 'SELECT E_INTERNAL_ID  FROM T'||V_ENT_PHY_TABLE||' WHERE '|| V_ENT_PHY_KEY_COL ||'='''|| I.WTA_ENTITY_VALUE_CONSTANT||'''' INTO V_INT_ID;
        EXECUTE IMMEDIATE 'SELECT E_INTERNAL_ID  FROM T'||V_ENT_PHY_TABLE||' WHERE '|| V_ENT_PHY_KEY_COL ||'='''|| REPLACE(I.WTA_ENTITY_VALUE_CONSTANT,'''','''''')||'''' INTO V_INT_ID;
         ---ASSIGNING VALID VALUE OF MAPPED ENTITY
         V_ASSIGN_ENT := V_INT_ID ||  V_ENT_INT_ID_CLAUSE;
         EXCEPTION WHEN NO_DATA_FOUND THEN
           ---ASSIGNING NULL VALUE IF MAPPED ENTITY IS NOT VALID
           V_ASSIGN_ENT := 'REPLACE ('''||V_ENT_INT_ID_CLAUSE||''', '''||V_ENT_INT_ID_CLAUSE||''',NULL) '||V_ENT_INT_ID_CLAUSE;

         END;

    ELSIF I.WTA_ENTITY_VALUE_TYPE =2 -----FOR RELATED RECORD VALUES
    THEN
      V_ENT_INT_ID_ALIAS :=' ASSGN_TO_ENT_INT_ID_'||I.WTA_ENTITY_ID;
      V_ENT_INT_ID_CLAUSE := V_ENT_INT_ID_ALIAS;


      PRC_ENT_FLD_RR_EVAL(PI_WTA_ID => I.WTA_ID,
                          PI_ENT_INT_ID_CLAUSE => V_ENT_INT_ID_CLAUSE,
                          PO_ASSIGN_ENT => V_ASSIGN_ENT,
                          PO_ENT_FLD_SELECT_CLAUSE => V_ENT_FLD_SELECT_CLAUSE);

     ELSIF     I.WTA_ENTITY_VALUE_TYPE =3 -----FOR ANH
     THEN

            V_ENT_INT_ID_CLAUSE := ' LOOKUP_ENT_INT_ID ';
                  IF I.WTA_ENT_FLT_DATE_TO_USE IN (0,1,2)
      THEN
        SELECT FLD_COLUMN_NAME INTO V_ANH_FLD_COL_NAME FROM FIELDS WHERE FLD_ID =I.WTA_ENT_FLT_DATE_FLD_ID;
      V_ANH_DATE_CLS :=  ','||V_ANH_FLD_COL_NAME;
        END IF;

          PRC_ANH_ENT_FLD_RR_EVAL(PI_WTA_ID => I.WTA_ID,
                                      PI_ANH_CLAUSE => PI_ANH_CLAUSE,
                                      PI_ANH_DATE_CLS => V_ANH_DATE_CLS ,
                                      PI_TASK_CREATION_SELECT => V_TASK_CREATION_SELECT,
                                      PI_WTA_ET_IS_EXT_TABLE => I.WTA_ET_IS_EXT_TABLE,
                                      PO_ENTITY_FILTER => V_ENTITY_FILTER,
                                      PO_ASSIGN_ENT => V_ASSIGN_ENT,
                                      PO_TASK_CREATION_SELECT => V_TASK_CREATION_SELECT,
                                      PO_ENT_FLD_SELECT_CLAUSE => V_ENT_FLD_SELECT_CLAUSE);


    END IF;

     V_WHEN_CLAUSE :=CASE WHEN (V_EC_QUERY IS NULL AND V_FC_ANDQUERY IS NULL) THEN  ' WHEN 1=1 ' END;



     IF V_CUR_TN_ID IS NOT NULL AND  V_CUR_TN_ID.COUNT >0   THEN

     PRC_TASK_REQUEST_INFO(PI_REQ_TASK_COL => PI_TASK_REQ_ID,
                           PI_REQ_GTT_NAME => V_REQ_GTT_TAB,
                           PI_TASK_GTT_NAME => V_TASK_GTT_TAB,
                           PI_MAP_TASK_NODE => PI_MAP_TASK_NODE_LST,
                           PO_REQ_RID_LIST => V_REQ_ROWID,
                           PO_TR_QRY => V_TASK_REQUEST_QRY,
                           PO_TN_QRY => V_TASK_NODE_QRY);

      /*COMMONS_UTILS.INSERT_LOGS(TO_CHAR('V_REQ_ROWID='||V_REQ_ROWID));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('V_TASK_REQUEST_QRY='||V_TASK_REQUEST_QRY));
      COMMONS_UTILS.INSERT_LOGS(TO_CHAR('V_TASK_NODE_QRY='||V_TASK_NODE_QRY));
*/
      V_REQ_ROWID:=  to_clob(' WHERE (R.ROW_IDENTIFIER IN ('||V_REQ_ROWID||'))');   -----NEED TO REPLACE V_REQ_ROWID WITH COMMA SEPARATED ROWIDS FROM REQUEST GTT

      V_TRID_JOIN_CLS:=     to_clob(' INNER JOIN ('||V_TASK_REQUEST_QRY||') TRID
        ON TRID.REQUEST_ID = RR.REQUEST_ID ');-----NEED TO REPLACE V_TASK_REQUEST_QRY WITH THE QUERY VAIRABLE OF COLLECTION

        FOR I IN 1..V_CUR_TN_ID.COUNT LOOP
          V_CUR_TN_COMMA_SEP:=V_CUR_TN_COMMA_SEP|| TO_CLOB(V_CUR_TN_ID(I))||',';
        END LOOP;
          V_CUR_TN_COMMA_SEP:= RTRIM(V_CUR_TN_COMMA_SEP,',');

-----------CONDITION ADDITION FOR MULTINODE TASKS
      V_MULTINODE_CONDTION := to_clob(' WHERE NOT EXISTS
                                      (SELECT 1
                                              FROM '||V_TASK_TABLE||'
                                          WHERE (TASK_NODE = '||V_NEXT_TN_ID||' AND RR.REQUEST_ID = REQUEST_ID))
                                                 AND 1 =
                                                  (SELECT DECODE(COUNT(*), '||V_CUR_TN_ID.COUNT||', 1, 0)
                                                                FROM '||V_TASK_TABLE||'
                                                     WHERE (TASK_NODE IN ('||V_CUR_TN_COMMA_SEP||') AND ACTION_PERFORMED IS NOT NULL AND
                                                                   RR.REQUEST_ID = REQUEST_ID))');

      END IF;

     -------SELECTING COLUMN LIST FOR REQUEST GTT AND REFERENCED COLUMNS FROM OBJECT REGISTRATION
     --SELECT LISTAGG('R.'||COLUMN_NAME || ' ' || COLUMN_NAME, ',') WITHIN GROUP(ORDER BY U.COLUMN_NAME)
     SELECT LISTAGG_JAVA(OBJTYPE_WORD_DLM('R.'||COLUMN_NAME || ' ' || COLUMN_NAME, ',', NULL))
      INTO V_REQ_COL_LIST
      FROM USER_TAB_COLS U
     WHERE U.TABLE_NAME =  TO_CHAR(V_REQ_GTT_TAB)
       AND U.HIDDEN_COLUMN = 'NO'
       AND U.COLUMN_NAME NOT IN ('REQUEST_TYPE', 'REQUEST_STATUS');

       V_REQ_COL_LIST:=V_REQ_COL_LIST||',RS.OR_NAME REQUEST_STATUS,RT.OR_NAME REQUEST_TYPE';

       V_REQUEST_QRY := to_clob(' (SELECT '||V_REQ_COL_LIST||'
       FROM '|| V_REQ_GTT_TAB ||' R INNER JOIN OBJECT_REGISTRATION RT
                    ON RT.OR_ID = R.REQUEST_TYPE
                 INNER JOIN OBJECT_REGISTRATION RS
                    ON RS.OR_ID = R.REQUEST_STATUS '||V_REQ_ROWID||') RR');


       ----TO HANDLE THE ENTITY VALUES FOR SYSTEM TASK
       IF    V_IS_SYS_TASK <>1 THEN
       V_ENT_CLAUSE :=  ', E'||I.WTA_ENTITY_ID;
       V_ENT_VALUE_CLAUSE := ','|| V_ENT_INT_ID_CLAUSE;
                                   END IF;

     V_TEMP_FAIL_INSERT_S := to_clob(V_TEMP_FAIL_INSERT_S || V_EC_QUERY || V_FC_ANDQUERY || V_WHEN_CLAUSE||'
                               THEN INTO TEMP_WF_TASK_FAIL_ASSIGN_ENT
                                  (TWFTFE_REQUEST_ID,
                                   TWFTFE_TASK_ID,
                                   TWFTFE_TASK_NODE,
                                   TWFTFE_ENTITY_INTERNAL_ID)
                                  VALUES
                                   (REQUEST_ID,
                                   DECODE('||V_ENT_INT_ID_CLAUSE||',NULL,NULL,TASK_ID),
                                   '||PI_TASK_NODE||',
                                   '||V_ENT_INT_ID_CLAUSE||')
                              WHEN '|| V_FC_QUERYAND||V_ENT_INT_ID_CLAUSE||' IS NOT NULL
                                THEN INTO '|| V_TASK_TABLE||'
                                  (ROW_IDENTIFIER,
                                   ROW_VERSION,
                                   TASK_ID,
                                   TASK_ASSIGNED_TO,
                                   TASK_NODE,
                                   WORKFLOW_PROCESS,
                                   CREATED_DATE_TIME,
                                   REQUEST_ID ' ||V_ENT_CLAUSE||' )
                                   VALUES
                                  ('|| V_TASK_TABLE||'_ROW_IDENTIFIER_SEQ.NEXTVAL,
                                   0,
                                   TASK_ID,
                                   '''||V_ACTION_ACTOR||''',
                                   '||PI_TASK_NODE||',
                                   '||I.WTA_WP_ID||',
                                   TO_DATE(TO_CHAR(SYSDATE, ''DD.MM.RRRR HH24:MI:SS''), ''DD.MM.RRRR HH24:MI:SS''),
                                   REQUEST_ID
                                   '||V_ENT_VALUE_CLAUSE||')');
    IF I.WTA_ENT_FLT_DATE_TO_USE =0
      THEN
      V_ANH_DATE_CLS:= ',DR.'||LTRIM(V_ANH_DATE_CLS,',');
      ELSIF I.WTA_ENT_FLT_DATE_TO_USE =1 THEN
      V_ANH_DATE_CLS:= ',RR.'||LTRIM(V_ANH_DATE_CLS,',');
      ELSIF I.WTA_ENT_FLT_DATE_TO_USE =2 THEN
      V_ANH_DATE_CLS:= ',TR_'||I.WTA_ENT_FLT_DATE_TASK_NODE_ID||'.'||LTRIM(V_ANH_DATE_CLS,',');
      END IF;

    V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S||to_clob(' WITH TASK_CREATION AS
                                     (SELECT ('|| V_MIN_VALUE||' + ROWNUM - 1) TASK_ID,
                                             RR.REQUEST_ID REQUEST_ID,
                                             RR.CREATED_DATE_TIME RR_CREATED_DATE_TIME'||V_ANH_DATE_CLS||',
                                             '||V_ASSIGN_ENT||V_FIL_QUERY||' FROM ');

  /*IF TABLE IS MAPPED/ ASSOCIATED THEN WE ARE APPLYING JOIN WITH THE ASSOCIATED GTT*/
        IF V_IS_ASSO_MAPPED = 1 THEN
                 V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S||to_clob(' (SELECT * FROM '||V_ASSO_GTT_TAB||') DR INNER JOIN ');
                 V_DR_JOIN_CLAUSE := to_clob(' ON DR.ROW_IDENTIFIER = RR.ASSOCIATED_DATA_RECORD_ID ');
        END IF;


      V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S || V_REQUEST_QRY;

      V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S || V_DR_JOIN_CLAUSE;

      V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S || V_TRID_JOIN_CLS ||V_TASK_NODE_QRY;-----V_TRID_JOIN_CLS IS FOR TASK NODE MAPPING

      --V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S ||' INNER JOIN WF_TASK_ASSIGNMENTS WTA ON WTA.WTA_ID = '||  PI_TASK_NODE;--*************************NEED TO CHECK

      V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S || V_ENT_FLD_SELECT_CLAUSE ||V_EXT_SEL|| V_ET_CONDITION||' '||PI_CNDT_JOIN_CLAUSE ||' '||V_MULTINODE_CONDTION||')';-----V_MULTINODE_CONDTION EXISTANCE CHECK OF THE TASK
                                                                                                           ---PI_CNDT_JOIN_CLAUSE for period field filter condition

      V_FROM_CLAUSE := ' FROM TASK_CREATION TC ';


          --V_ENTITY_FILTER
          V_SELECT_NORMAL := ' SELECT TC.REQUEST_ID REQUEST_ID, TC.TASK_ID TASK_ID, TC.RR_CREATED_DATE_TIME CREATED_DATE_TIME '||
        --ANH,EXT TAB, FILTER COND SELELCT CLAUSE
        CASE WHEN (I.WTA_ENTITY_VALUE_TYPE =3 AND I.WTA_IS_CONDITION_BASED =1 AND I.WTA_ET_IS_EXT_TABLE=1) THEN ' ,EF.C_0_E_INTERNAL_ID LOOKUP_ENT_INT_ID,TASK_CONDITION ,(SELECT EXT_TAB_VLDTION_RESULT FROM EXTERNAL_TABLE_CHECK) EXT_TAB_VLDTION_RESULT ' ||V_FROM_CLAUSE ||V_ENTITY_FILTER
        --ANH,FILTER COND SELELCT CLAUSE
        WHEN (I.WTA_ENTITY_VALUE_TYPE =3 AND I.WTA_IS_CONDITION_BASED =1 AND NVL(I.WTA_ET_IS_EXT_TABLE,0)=0) THEN ' ,EF.C_0_E_INTERNAL_ID LOOKUP_ENT_INT_ID,TASK_CONDITION ' ||V_FROM_CLAUSE ||V_ENTITY_FILTER
        --EXT TAB SELECT CLAUSE
        WHEN I.WTA_ET_IS_EXT_TABLE=1 AND I.WTA_IS_CONDITION_BASED=1 THEN   ','||V_ENT_INT_ID_CLAUSE ||', TASK_CONDITION ,EXT_ROW_IDENTIFIER ,(SELECT EXT_TAB_VLDTION_RESULT FROM EXTERNAL_TABLE_CHECK) EXT_TAB_VLDTION_RESULT'||V_FROM_CLAUSE
        --FILTER SELECT CLAUSE
        WHEN I.WTA_IS_CONDITION_BASED=1 AND NVL(I.WTA_ET_IS_EXT_TABLE,0)=0 THEN   ','||V_ENT_INT_ID_CLAUSE ||', TASK_CONDITION '||V_FROM_CLAUSE
        --ANH SELECT CLAUE
         WHEN I.WTA_ENTITY_VALUE_TYPE =3 AND I.WTA_IS_CONDITION_BASED=0 THEN ', EF.C_0_E_INTERNAL_ID LOOKUP_ENT_INT_ID '||V_FROM_CLAUSE   ||V_ENTITY_FILTER
           ELSE  ','||V_ENT_INT_ID_CLAUSE  ||V_FROM_CLAUSE
          END;

         /* COMMONS_UTILS.INSERT_LOGS('WTA_ENTITY_VALUE_TYPE ' ||I.WTA_ENTITY_VALUE_TYPE);
                    COMMONS_UTILS.INSERT_LOGS('V_SELECT_NORMAL '||V_SELECT_NORMAL);*/
         --DBMS_OUTPUT.PUT_LINE(V_SELECT_NORMAL);

      V_TEMP_FAIL_INSERT_S := V_TEMP_FAIL_INSERT_S ||V_TASK_CREATION_SELECT|| V_SELECT_NORMAL;
      --COMMONS_UTILS.INSERT_LOGS(('V_TEMP_FAIL_INSERT_S='||V_TEMP_FAIL_INSERT_S));
      --COMMONS_UTILS.INSERT_LOGS(('V_TASK_CREATION_SELECT='||V_TASK_CREATION_SELECT));
      --COMMONS_UTILS.INSERT_LOGS(('V_SELECT_NORMAL='||V_SELECT_NORMAL));
    EXECUTE IMMEDIATE V_TEMP_FAIL_INSERT_S;
      END LOOP;
  EXCEPTION WHEN OTHERS THEN
       COMMONS_UTILS.INSERT_LOGS(('ERROR OCCURED WHILE CREATING TASK ='||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || '*****'||V_TEMP_FAIL_INSERT_S||SQLERRM));
   -- DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || '*****'||V_TEMP_FAIL_INSERT_S||SQLERRM);
   RAISE;

END PRC_WF_TASK_CREATION;

PROCEDURE PRC_TASK_REQUEST_INFO(PI_REQ_TASK_COL     IN  TABLETYPE_ID_ID,
                                PI_REQ_GTT_NAME     IN  VARCHAR2,
                                PI_TASK_GTT_NAME    IN  VARCHAR2,
                                PI_MAP_TASK_NODE    IN  COLTYPE_ID,
                                PO_REQ_RID_LIST     OUT CLOB,
                                PO_TR_QRY           OUT CLOB,
                                PO_TN_QRY           OUT CLOB
                               )
IS

      V_REQ_CURSOR      SYS_REFCURSOR;
      V_TASK_CURSOR     SYS_REFCURSOR;
      V_REQ_QUERY       CLOB;
      V_TASK_QUERY      CLOB;
      V_REQ_RID_LIST    CLOB;
      V_TASK_RID_LIST   CLOB;
      V_TR_QRY          CLOB;
      V_TASK_ID         NUMBER;
      V_REQST_ID        NUMBER;
      V_REQ_ROWID       NUMBER;
      V_TASK_NODE       NUMBER;
      V_TASK_COL_LIST   CLOB;
      V_TASK_QRY        CLOB;
      V_SUB_QRY         CLOB;
      V_TRID_JOIN_CLS   CLOB;
      V_SUBQRY_ALIAS    VARCHAR2(300);
      V_TR_SUB_QRY      CLOB;

BEGIN

    --SELECT LISTAGG('T.'||COLUMN_NAME || ' ' || COLUMN_NAME, ',') WITHIN GROUP(ORDER BY U.COLUMN_NAME)
    SELECT LISTAGG_JAVA(OBJTYPE_WORD_DLM('T.'||COLUMN_NAME || ' ' || COLUMN_NAME, ',', NULL))
      INTO V_TASK_COL_LIST
      FROM USER_TAB_COLS U
     WHERE U.TABLE_NAME =  TO_CHAR(PI_TASK_GTT_NAME)
       AND U.HIDDEN_COLUMN = 'NO'
       AND U.COLUMN_NAME NOT IN ('TASK_NODE', 'ACTION_PERFORMED','WORKFLOW_PROCESS');

    V_TASK_COL_LIST := V_TASK_COL_LIST||',TA.OR_NAME TASK_NODE, WA.OR_NAME ACTION_PERFORMED, WP.OR_NAME WORKFLOW_PROCESS';

    V_REQ_QUERY :=' SELECT T1.ID1,T2.REQUEST_ID,T2.ROW_IDENTIFIER FROM TABLE(:1) T1 JOIN '||PI_REQ_GTT_NAME||' T2 ON(T1.ID2=T2.REQUEST_ID)';

    OPEN V_REQ_CURSOR FOR V_REQ_QUERY USING PI_REQ_TASK_COL;
    LOOP
            FETCH V_REQ_CURSOR INTO V_TASK_ID,V_REQST_ID,V_REQ_ROWID;
            EXIT WHEN  V_REQ_CURSOR%NOTFOUND;
            V_REQ_RID_LIST :=V_REQ_RID_LIST|| to_clob(V_REQ_ROWID)||',';
            -- V_TR_QRY := V_TR_QRY||' SELECT '||V_TASK_ID||' TASK_ID ,'||V_REQST_ID||' REQUEST_ID FROM DUAL UNION ';
           V_TR_SUB_QRY := TO_CLOB(' SELECT '||V_TASK_ID||' TASK_ID ,'||V_REQST_ID||' REQUEST_ID FROM DUAL UNION ');
           V_TR_QRY := V_TR_QRY||V_TR_SUB_QRY;
           V_TR_SUB_QRY :=NULL;

     END LOOP;

        V_TASK_QUERY := Q'[SELECT T2.TASK_NODE, SUBSTR( XMLCAST( XMLAGG( XMLELEMENT(E, ',' || T2.ROW_IDENTIFIER) ) AS CLOB ) , 2 ) AS ROW_LIST FROM TABLE(:1) T1 JOIN ]'
                         ||PI_TASK_GTT_NAME||
                         ' T2 ON(T1.COLUMN_VALUE = T2.TASK_NODE)
                          WHERE EXISTS (SELECT 1 FROM TABLE(:2) T3
                           WHERE  T2.REQUEST_ID =T3.ID2
                           --AND T2.TASK_ID = T3.ID1
                           )
                           GROUP BY T2.TASK_NODE ' ;

    OPEN V_TASK_CURSOR FOR V_TASK_QUERY USING PI_MAP_TASK_NODE,PI_REQ_TASK_COL;
    LOOP

     FETCH V_TASK_CURSOR INTO V_TASK_NODE,V_TASK_RID_LIST;
     EXIT WHEN  V_TASK_CURSOR%NOTFOUND;

     V_SUBQRY_ALIAS :='TR_'||TO_CHAR(V_TASK_NODE);

     V_SUB_QRY := to_clob('( SELECT '||V_TASK_COL_LIST||'
                       FROM '|| PI_TASK_GTT_NAME ||' T
                       INNER JOIN OBJECT_REGISTRATION TA
                          ON TA.OR_ID = T.TASK_NODE
                       INNER JOIN OBJECT_REGISTRATION WP
                          ON WP.OR_ID = T.WORKFLOW_PROCESS
                       INNER JOIN OBJECT_REGISTRATION WA
                          ON WA.OR_ID = T.ACTION_PERFORMED
                         WHERE (T.ROW_IDENTIFIER IN ('||V_TASK_RID_LIST||')))');

      V_TRID_JOIN_CLS:= to_clob(' INNER JOIN '||V_SUB_QRY||' '||V_SUBQRY_ALIAS||
                                ' ON RR.REQUEST_ID = '||V_SUBQRY_ALIAS||'.REQUEST_ID '
                                );

      V_TASK_QRY:=V_TASK_QRY||CHR(10)||V_TRID_JOIN_CLS;

      V_SUB_QRY:=NULL;
     END LOOP;

    PO_REQ_RID_LIST    := RTRIM(V_REQ_RID_LIST,',');
    PO_TR_QRY          := RTRIM(V_TR_QRY,' UNION');
    PO_TN_QRY          := V_TASK_QRY;

EXCEPTION
   WHEN OTHERS THEN
          COMMONS_UTILS.INSERT_LOGS(('ERROR OCCURED WHILE FETCHING REQUEST TASK INFO FOR TASK CREATION ='||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || '*****'||SQLERRM));
   --DBMS_OUTPUT.PUT_LINE(SQLERRM(SQLCODE));
END PRC_TASK_REQUEST_INFO;

PROCEDURE PRC_ANH_ENT_FLD_RR_EVAL(PI_WTA_ID IN NUMBER,
                                  PI_ANH_CLAUSE IN CLOB,
                                  PI_ANH_DATE_CLS IN CLOB,
                                  PI_TASK_CREATION_SELECT IN CLOB,
                                  PI_WTA_ET_IS_EXT_TABLE IN NUMBER,
                                  PO_ENTITY_FILTER OUT CLOB,
                                  PO_ASSIGN_ENT OUT CLOB,
                                  PO_TASK_CREATION_SELECT OUT CLOB,
                                  PO_ENT_FLD_SELECT_CLAUSE OUT CLOB) AS
  V_ENT_KEY_COL                   VARCHAR2(100);
  V_ENT_KEY_COL_NAME              VARCHAR2(100);
  V_FLD_COL_NAME                  VARCHAR2(100);
  V_ENT                           NUMBER;
  V_ENT_TABLE                     NUMBER;
  V_ENT_INT_ID_ALIAS              CLOB;
  V_ANH_TASK_CREATION             CLOB;
  V_ASSIGN_ENT                    CLOB;
  V_ENT_FLD_SELECT_CLAUSE         CLOB;
  V_TASK_CREATION_SELECT          CLOB;
  V_FLD_PREFIX_NAME               CLOB;
  V_ENT_INT_ID_ALIAS_LIST         CLOB;
  V_ENTITY_FILTER                 CLOB;
  BEGIN
    V_TASK_CREATION_SELECT:= PI_TASK_CREATION_SELECT;
    V_ENTITY_FILTER:= ' LEFT OUTER JOIN ENTITY_FILTER EF ON ';
      FOR I IN (SELECT *
              FROM WF_TASK_ASSIGNMENTS WTA
              LEFT JOIN WF_TA_RELATED_RECORDS
              ON WTRR_WTA_ID = WTA_ID
             WHERE WTA.WTA_ID = PI_WTA_ID ) LOOP

        IF I.WTRR_RELATED_ENTITY_OR_FLD=1 ---FOR ENTITY FROM RELATED RECORD
         THEN
     SELECT tr.TC_PHYSICAL_NAME ENT_KEY_COL,
       'FLD' || tc.TC_FLD_ID || '_' || i.wtrr_related_entity_or_fld_id  ENT_KEY_COL_NAME,
       i.wtrr_lookup_entity_id ENT,
       tr.TC_TABLES_ID ENT_TABLE
       INTO V_ENT_KEY_COL, V_ENT_KEY_COL_NAME, V_ENT, V_ENT_TABLE
  FROM ENTITIES ee
  JOIN TABLE_COLUMNS tc
    ON tc.TC_TABLES_ID = ee.entity_tables_id
    join entities el
    ON el.ENTITY_ID = i.wtrr_lookup_entity_id
    join TABLE_COLUMNS tr
    on tr.tc_tables_id=el.entity_tables_id
      WHERE tr.TC_LOGIC_TYPE IN (1,5)
 and tc.TC_LOGIC_TYPE IN (1,5)
    and ee.ENTITY_ID = i.WTRR_RELATED_ENTITY_OR_FLD_ID;--I.WTA_ENTITY_ID;

    IF I.WTRR_RELATED_RECORD_TYPE = 0 --FOR ANH ENTITY FROM DATA RECORD
       THEN
         V_FLD_PREFIX_NAME:= ' DR.'|| V_ENT_KEY_COL_NAME;
    ELSIF I.WTRR_RELATED_RECORD_TYPE = 1 --FOR ANH ENTITY FROM REQUEST RECORD
       THEN
         V_FLD_PREFIX_NAME:= ' RR.'|| V_ENT_KEY_COL_NAME;
     ELSIF I.WTRR_RELATED_RECORD_TYPE = 2 --FOR ANH ENTITY FROM TASK RECORD
       THEN
         V_FLD_PREFIX_NAME:= ' TR_'||I.WTRR_RELATED_TA_ID||'.'|| V_ENT_KEY_COL_NAME  ;
    END IF;

     V_ENT_INT_ID_ALIAS :=   ' ASSGN_TO_ENT_INT_ID_'||V_ENT;
     V_ENT_INT_ID_ALIAS_LIST:=V_ENT_INT_ID_ALIAS  || ','||V_ENT_INT_ID_ALIAS_LIST;

     V_ASSIGN_ENT := V_ASSIGN_ENT||' ENT_'||V_ENT||'.E'||V_ENT || V_ENT_INT_ID_ALIAS||',';

     V_ENT_FLD_SELECT_CLAUSE := ' LEFT OUTER JOIN (SELECT '|| V_ENT_KEY_COL ||' '|| V_ENT_KEY_COL_NAME ||', E_INTERNAL_ID E'||V_ENT||' FROM T'
                              ||V_ENT_TABLE||' ) ENT_'||V_ENT ||' ON '||V_FLD_PREFIX_NAME ||'= ENT_'||V_ENT ||'.'|| V_ENT_KEY_COL_NAME ||' '||V_ENT_FLD_SELECT_CLAUSE;

     V_ENTITY_FILTER := V_ENTITY_FILTER|| ' EF.'||V_ENT_INT_ID_ALIAS||' = TC.'||V_ENT_INT_ID_ALIAS ||' AND ';


     ELSIF I.WTRR_RELATED_ENTITY_OR_FLD=2 ---FOR FIELD FROM RELATED RECORD
     THEN

    SELECT TC_PHYSICAL_NAME ENT_KEY_COL,
       FLD_COLUMN_NAME FLD_COL_NAME,
       I.WTRR_LOOKUP_ENTITY_ID ENT,
       TC_TABLES_ID ENT_TABLE
       INTO V_ENT_KEY_COL, V_FLD_COL_NAME, V_ENT, V_ENT_TABLE
  FROM ENTITIES
  JOIN TABLE_COLUMNS
    ON TC_TABLES_ID = ENTITY_TABLES_ID
    JOIN FIELDS
    ON FLD_ID =I.WTRR_RELATED_ENTITY_OR_FLD_ID
 WHERE ENTITY_ID = I.WTRR_LOOKUP_ENTITY_ID
 AND TC_LOGIC_TYPE IN (1,5);

  IF I.WTRR_RELATED_RECORD_TYPE = 0 --FOR ANH FIELD FROM DATA RECORD
       THEN
         V_FLD_PREFIX_NAME:= ' DR.'|| V_FLD_COL_NAME;
    ELSIF I.WTRR_RELATED_RECORD_TYPE = 1 --FOR ANH FIELD FROM REQUEST RECORD
       THEN
         V_FLD_PREFIX_NAME:= ' RR.'|| V_FLD_COL_NAME;
     ELSIF I.WTRR_RELATED_RECORD_TYPE = 2 --FOR ANH FIELD FROM TASK RECORD
       THEN
         V_FLD_PREFIX_NAME:= ' TR_'||I.WTRR_RELATED_TA_ID||'.'|| V_FLD_COL_NAME  ;
    END IF;

     V_ENT_INT_ID_ALIAS :=   ' ASSGN_TO_ENT_INT_ID_'||V_ENT;
     V_ENT_INT_ID_ALIAS_LIST:=V_ENT_INT_ID_ALIAS  || ','||V_ENT_INT_ID_ALIAS_LIST;

     V_ASSIGN_ENT := V_ASSIGN_ENT||' ENT_'||V_ENT||'.E'||V_ENT || V_ENT_INT_ID_ALIAS||',';

     V_ENT_FLD_SELECT_CLAUSE := ' LEFT OUTER JOIN (SELECT '|| V_ENT_KEY_COL ||' '|| V_FLD_COL_NAME ||', E_INTERNAL_ID E'||V_ENT||' FROM T'
                              ||V_ENT_TABLE||' ) ENT_'||V_ENT ||' ON '||V_FLD_PREFIX_NAME ||'= ENT_'||V_ENT ||'.'|| V_FLD_COL_NAME ||' '||V_ENT_FLD_SELECT_CLAUSE;

     V_ENTITY_FILTER := V_ENTITY_FILTER|| ' EF.'||V_ENT_INT_ID_ALIAS||' = TC.'||V_ENT_INT_ID_ALIAS ||' AND ';

END IF;

        END LOOP;

        V_ENT_INT_ID_ALIAS_LIST:= RTRIM(V_ENT_INT_ID_ALIAS_LIST,',');
        V_ASSIGN_ENT:= RTRIM(V_ASSIGN_ENT,',');
        V_ENTITY_FILTER:= RTRIM(V_ENTITY_FILTER,' AND ');
        V_ANH_TASK_CREATION := ' TASK_CREATION_DISTINCT AS
                                   (SELECT DISTINCT '|| V_ENT_INT_ID_ALIAS_LIST||/*', RR_CREATED_DATE_TIME '||*/PI_ANH_DATE_CLS ||'
                                                FROM TASK_CREATION),
                                                  ENTITY_FILTER AS
                                                     ( ';
        V_TASK_CREATION_SELECT := CASE WHEN PI_WTA_ET_IS_EXT_TABLE =1 THEN V_TASK_CREATION_SELECT END||','||V_ANH_TASK_CREATION ||PI_ANH_CLAUSE ||')';

        PO_ENTITY_FILTER := V_ENTITY_FILTER;
        PO_ASSIGN_ENT := V_ASSIGN_ENT;
        PO_TASK_CREATION_SELECT := V_TASK_CREATION_SELECT;
        PO_ENT_FLD_SELECT_CLAUSE := V_ENT_FLD_SELECT_CLAUSE;
        EXCEPTION
   WHEN OTHERS THEN
          COMMONS_UTILS.INSERT_LOGS(('ERROR OCCURED WHILE FETCHING ANH DETAILS ='||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || '*****'||SQLERRM));

    END;

PROCEDURE PRC_ENT_FLD_RR_EVAL(PI_WTA_ID IN NUMBER,
                              PI_ENT_INT_ID_CLAUSE IN CLOB,
                              PO_ASSIGN_ENT OUT CLOB,
                              PO_ENT_FLD_SELECT_CLAUSE OUT CLOB) AS

  V_ENT_KEY_COL               VARCHAR2(100);
  V_ENT_INT_ID_ALIAS          CLOB;
  V_ASSIGN_ENT                CLOB;
  V_ENT_FLD_SELECT_CLAUSE     CLOB;
  V_ENT_KEY_COL_NAME          CLOB;
  V_ENT_INT_ID_CLAUSE         CLOB;
  V_ENT                       NUMBER;
  V_ENT_TABLE                 NUMBER;
  V_FLD_PREFIX_NAME           CLOB;
  V_FLD_COL_NAME              CLOB;

BEGIN
 V_ENT_INT_ID_CLAUSE:= PI_ENT_INT_ID_CLAUSE;
      FOR I IN (SELECT *
              FROM WF_TASK_ASSIGNMENTS WTA
              LEFT JOIN WF_TA_RELATED_RECORDS
              ON WTRR_WTA_ID = WTA_ID
             WHERE WTA.WTA_ID = PI_WTA_ID ) LOOP

             IF I.WTRR_RELATED_ENTITY_OR_FLD=1 ---FOR ENTITY FROM RELATED RECORD
        THEN

   SELECT TC.TC_PHYSICAL_NAME ENT_KEY_COL,
        'FLD' || TR.TC_FLD_ID || '_' || I.WTRR_RELATED_ENTITY_OR_FLD_ID ENT_KEY_COL_NAME,
        EWTA.ENTITY_ID ENT,
        TC.TC_TABLES_ID ENT_TABLE
   INTO V_ENT_KEY_COL, V_ENT_KEY_COL_NAME, V_ENT, V_ENT_TABLE
   FROM ENTITIES EWTA
   JOIN TABLE_COLUMNS TC
     ON TC.TC_TABLES_ID = EWTA.ENTITY_TABLES_ID
   JOIN ENTITIES EWTR
     ON EWTR.ENTITY_ID = I.WTRR_RELATED_ENTITY_OR_FLD_ID
   JOIN TABLE_COLUMNS TR
     ON TR.TC_TABLES_ID = EWTR.ENTITY_TABLES_ID
  WHERE TC.TC_LOGIC_TYPE IN (1, 5)
    AND TR.TC_LOGIC_TYPE IN (1, 5)
    AND EWTA.ENTITY_ID = I.WTA_ENTITY_ID;

        IF I.WTRR_RELATED_RECORD_TYPE=0 ---FOR ENTITY FROM RELATED RECORD(DATA RECORD)
        THEN
          V_FLD_PREFIX_NAME := ' DR.'|| V_ENT_KEY_COL_NAME ;
        ELSIF I.WTRR_RELATED_RECORD_TYPE = 1 ---FOR ENTITY FROM RELATED RECORD(REQUEST RECORD)
     THEN
          V_FLD_PREFIX_NAME := ' RR.'|| V_ENT_KEY_COL_NAME ;
        ELSIF I.WTRR_RELATED_RECORD_TYPE = 2 ---FOR ENTITY FROM RELATED RECORD(TASK RECORD)
     THEN
          V_FLD_PREFIX_NAME := ' TR_'||I.WTRR_RELATED_TA_ID||'.'|| V_ENT_KEY_COL_NAME;
          END IF;

     V_ENT_INT_ID_ALIAS :=V_ENT_INT_ID_CLAUSE;
     V_ASSIGN_ENT := ' ENT_'||V_ENT||'.E'||I.WTA_ENTITY_ID||V_ENT_INT_ID_ALIAS;

     V_ENT_FLD_SELECT_CLAUSE := ' LEFT OUTER JOIN (SELECT '|| V_ENT_KEY_COL ||' '|| V_ENT_KEY_COL_NAME ||', E_INTERNAL_ID E'||V_ENT||' FROM T'
                              ||V_ENT_TABLE||' ) ENT_'||V_ENT ||' ON ' ||V_FLD_PREFIX_NAME || '= ENT_'||V_ENT ||'.'|| V_ENT_KEY_COL_NAME   ;


     ELSIF I.WTRR_RELATED_ENTITY_OR_FLD=2 ---FOR FIELD FROM RELATED RECORD
     THEN

       SELECT TC_PHYSICAL_NAME ENT_KEY_COL,
       FLD_COLUMN_NAME FLD_COL_NAME,
       I.WTA_ENTITY_ID ENT,
       TC_TABLES_ID ENT_TABLE
       INTO V_ENT_KEY_COL, V_FLD_COL_NAME, V_ENT, V_ENT_TABLE
  FROM ENTITIES
  JOIN TABLE_COLUMNS
    ON TC_TABLES_ID = ENTITY_TABLES_ID
    JOIN FIELDS
    ON FLD_ID =I.WTRR_RELATED_ENTITY_OR_FLD_ID
 WHERE ENTITY_ID = I.WTA_ENTITY_ID
   AND TC_LOGIC_TYPE IN (1,5);

   IF I.WTRR_RELATED_RECORD_TYPE = 0 THEN----FIELD FROM RELATED DATA RECORD
      V_FLD_PREFIX_NAME:=  ' DR.'|| V_FLD_COL_NAME;
   ELSIF I.WTRR_RELATED_RECORD_TYPE = 1 THEN----FIELD FROM RELATED REQUEST RECORD
      V_FLD_PREFIX_NAME:=  ' RR.'|| V_FLD_COL_NAME;
   ELSIF I.WTRR_RELATED_RECORD_TYPE = 2 THEN----FIELD FROM RELATED TASK RECORD
      V_FLD_PREFIX_NAME := ' TR_'||I.WTRR_RELATED_TA_ID||'.'|| V_FLD_COL_NAME;
   END IF;
   V_ENT_INT_ID_ALIAS := V_ENT_INT_ID_CLAUSE;
   V_ASSIGN_ENT := ' ENT_'||V_ENT||'.E'||V_ENT||V_ENT_INT_ID_ALIAS;

     V_ENT_FLD_SELECT_CLAUSE := ' LEFT OUTER JOIN (SELECT '|| V_ENT_KEY_COL ||' '|| V_FLD_COL_NAME ||', E_INTERNAL_ID E'||V_ENT||' FROM T'
                              ||V_ENT_TABLE||' ) ENT_'||V_ENT ||' ON '||V_FLD_PREFIX_NAME ||' = ENT_'||V_ENT ||'.'|| V_FLD_COL_NAME   ;


     END IF;

             END LOOP;

             PO_ASSIGN_ENT := V_ASSIGN_ENT;
             PO_ENT_FLD_SELECT_CLAUSE := V_ENT_FLD_SELECT_CLAUSE;
EXCEPTION

   WHEN OTHERS THEN
          COMMONS_UTILS.INSERT_LOGS(('ERROR OCCURED WHILE FETCHING FIELD DETAILS ='||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || '*****'||SQLERRM));

              END;


-- *******************************    PUBLIC PROCEDURES END         *******************************
END WORKFLOW_BUILDER;
/
