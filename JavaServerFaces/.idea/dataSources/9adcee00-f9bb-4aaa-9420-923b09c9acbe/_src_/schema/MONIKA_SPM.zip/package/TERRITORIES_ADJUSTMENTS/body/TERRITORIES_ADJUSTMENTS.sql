CREATE PACKAGE BODY TERRITORIES_ADJUSTMENTS AS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2015 - 2016 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : territories_adjustments
-- Module           : territories_adjustments
-- Requester        : Horlescu, Gabriel
-- Author           : Macarie, Sabina
-- Reviewer         :
-- Review date      : 15 MAY 2016
-- Description      : Package used to handle all territories_adjustments processing
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160720
-- Description: Functions that constructs date condition to filter assignment tables/metric tables - used for impact metric calculations
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_assign_table_id      NUMBER      Assignment table ID
   pi_alias                VARCHAR2    Assignment table alias
   pi_metric_table_id      NUMBER      Metric table ID
   pi_start_date           DATE        Start Date
   pi_option               NUMBER      1 - date condition for assignment table + metric table, 2 - only for assignment table
*/
-----------------------------------------------------------------------------------------
FUNCTION RETURN_DATE_CONDITION(pi_assign_table_id NUMBER,
                               pi_alias           VARCHAR2,
                               pi_metric_table_id NUMBER,
                               pi_start_date      DATE,
                               pi_option          NUMBER
                               )
RETURN CLOB
IS
v_sql CLOB;
BEGIN

    -- case when assignment table is effective for a range of dates
    SELECT CASE WHEN assign_table.tables_record_dating_option = 4
                THEN ' WHERE TO_DATE(''' || pi_start_date || ''', ''DD-MON-RR'')
                       BETWEEN NVL(TO_DATE(' || pi_alias || '.START_DATE, ''DD-MON-RR''), TO_DATE(''01/01/1800'', ''MM/DD/RRRR''))
                          AND NVL(TO_DATE(' || pi_alias || '.END_DATE, ''DD-MON-RR''), TO_DATE(''12/31/9999'', ''MM/DD/RRRR''))' END ||
    -- case when metric table is effective for a date or a range of dates
           CASE WHEN pi_option = 2
                THEN
                       -- effective for a date
                       CASE WHEN metric_table.tables_record_dating_option = 2
                            THEN CASE WHEN assign_table.tables_record_dating_option != 4
                                      THEN ' WHERE '
                                      ELSE ' AND'
                                 END || ' TO_DATE(dt.SYNDATE, ''DD-MON-RRRR'') = TO_DATE(''' || pi_start_date || ''', ''DD-MON-RR'')'
                       -- effective for a range of dates
                            WHEN metric_table.tables_record_dating_option = 4
                            THEN CASE WHEN assign_table.tables_record_dating_option != 4
                                      THEN ' WHERE '
                                      ELSE ' AND'
                                 END || ' TO_DATE(''' || pi_start_date || ''', ''DD-MON-RR'')
                                  BETWEEN NVL(TO_DATE(dt.START_DATE, ''DD-MON-RR''), TO_DATE(''01/01/1800'', ''MM/DD/RRRR''))
                                      AND NVL(TO_DATE(dt.END_DATE, ''DD-MON-RR''), TO_DATE(''12/31/9999'', ''MM/DD/RRRR''))' END
           END
      INTO v_sql
      FROM tables assign_table
      LEFT JOIN (SELECT metric_table.tables_record_dating_option
                   FROM tables metric_table
                  WHERE metric_table.tables_id = pi_metric_table_id) metric_table
        ON 1 = 1
     WHERE assign_table.tables_id = pi_assign_table_id;

RETURN v_sql;

END RETURN_DATE_CONDITION;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20161115
-- Description: Procedure that calculates the number of adjustments made on each territory
 /*

 Example :

 REALIGN
 ----------------------------------------
 account   territory_old    territory_new
 1         1                10
 1         1                11
 1         15               1
 2         1                10

 RESULT
 ----------------------------------------
 territory  adjustment_type   count
 1          Align             3
 10         Align             2
 11         Align             1
 15         Align             1

 */

-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_adjustments_count_table      VARCHAR2                    Table name that holds the adjustments count
   pi_territory_type               NUMBER                      The count is calculated for old(1) or new(2) territory
   pi_proposals                    TABLETYPE_TERRIT_PROPOSALS  Proposal list
*/
-----------------------------------------------------------------------------------------
PROCEDURE COUNT_ADJUSTMENTS(pi_adjustments_count_table VARCHAR2,
                            pi_territory_type          NUMBER, -- 1 - old, 2 - new
                            pi_proposals               TABLETYPE_TERRIT_PROPOSALS
                            )

IS
BEGIN

  EXECUTE IMMEDIATE
    'MERGE INTO ' || pi_adjustments_count_table || ' dst'                                                                      || chr(10) ||
    'USING ('                                                                                                                  || chr(10) ||
    '       SELECT ' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ',' || chr(10) ||
    '               CASE'                                                                                                      || chr(10) ||
    '                 WHEN adjustment_type IN (''Realign'', ''Align'', ''Close Alignment'', ''Bulk Adjustments'') THEN ''Align'''                    || chr(10) ||
    '                 ELSE ''Assign'''                                                                                         || chr(10) ||
    '               END AS adjustment_type,'                                                                                   || chr(10) ||
    '               SUM(cnt) as sum_value'                                                                                     || chr(10) ||
    '         FROM (SELECT  ' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ','                       || chr(10) ||
    '                       adjustment_type,'                                                                                                                 || chr(10) ||
                            -- using count distinct to count only 1 value when the same account is moved to multiple territories in the same adjustment
    '                       COUNT(DISTINCT ' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ') AS cnt' || chr(10) ||
    '                  FROM TABLE(:v_proposals)'                                                                                                              || chr(10) ||
    '                 GROUP BY ' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ','                    || chr(10) ||
    '                          CASE'                                                      || chr(10) ||
    '                            WHEN adjustment_type IN'                                 || chr(10) ||
    '                                 (''Realign'', ''Align'', ''Close Alignment'', ''Bulk Adjustments'') THEN' || chr(10) ||
    '                             account_entity_id'                                      || chr(10) ||
    '                            ELSE'                                                    || chr(10) ||
    '                             rep_entity_id'                                          || chr(10) ||
    '                          END,'                                                      || chr(10) ||
    '                          adjustment_type)'                                          || chr(10) ||
    '        WHERE ' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ' IS NOT NULL'         || chr(10) ||
    '        GROUP BY ' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ', adjustment_type' || chr(10) ||
    '' || chr(10) ||
    '       ) src' || chr(10) ||
    'ON (dst.territory_id = src.' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ' AND dst.adjustment_type = src.adjustment_type)' || chr(10) ||
    'WHEN MATCHED THEN' || chr(10) ||
    '  UPDATE' || chr(10) ||
    '     SET dst.count_adjustment_value = dst.count_adjustment_value + src.sum_value' || chr(10) ||
    'WHEN NOT MATCHED THEN'                                                            || chr(10) ||
    '  INSERT'                                                                         || chr(10) ||
    '    (territory_id,'                                                               || chr(10) ||
    '     adjustment_type,'                                                            || chr(10) ||
    '     count_adjustment_value,'                                                     || chr(10) ||
    '     row_identifier,'                                                             || chr(10) ||
    '     row_version)'                                                                || chr(10) ||
    '  VALUES'                                                                         || chr(10) ||
    '    (src.' || CASE WHEN pi_territory_type = 1 THEN ' territory_old_entity_id' ELSE ' territory_entity_id' END || ',' || chr(10) ||
    '     src.adjustment_type,'  || chr(10) ||
    '     src.sum_value,'        || chr(10) ||
    '     uid_sequence.nextval,' || chr(10) ||
    '     0)' USING pi_proposals;

END;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160801
-- Description: Procedure that updates assignment table snapshots when proposing adjustments
--              https://confluence.optymyze.net/display/Territories/Close+Assignments+-+Examples

-- Assignment = assignment between territory and user/rep entity
-- Alignment  = assignment between territory and account entity


-- Align/Assign                               = INSERT
-- Realign/Reassign           - not eff dated = UPDATE
--                            - eff dated     = UPDATE END DATE, INSERT
-- Close assignment/alignment - not eff dated = DELETE
--                            - eff dated     = UPDATE END DATE


-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id          NUMBER                      - Snapshot ID
    pi_territory_entity_id  NUMBER                      - Territory entity ID
    pi_account_entity_id    NUMBER                      - Account entity ID
    pi_rep_entity_id        NUMBER                      - Rep entity ID
    pi_proposals            TABLETYPE_TERRIT_PROPOSALS  - List of proposed adjustments
    pi_selected_date        DATE                        - Selected date from date picker
    pout_invalid_entities   OUT TABLETYPE_NUMBER        - Return list of acc/reps on which the adjustment could not be applied
                                                          if no rec updated for reassign/realign or close assignment/alignment for eff dated

*/
  -----------------------------------------------------------------------------------------
PROCEDURE APPLY_ADJUSTMENTS(pi_snapshot_id           NUMBER,
                            pi_territory_entity_id   NUMBER,
                            pi_account_entity_id     NUMBER,
                            pi_rep_entity_id         NUMBER,
                            pi_proposals             TABLETYPE_TERRIT_PROPOSALS,
                            pi_selected_date         DATE,
                            pi_live_or_snapshot      VARCHAR2,
                            pi_assignment_table      VARCHAR2,
                            pi_user_assignment_table VARCHAR2
                            )
IS


v_terr_acc_table_name      VARCHAR2(30 CHAR);
v_terr_rep_table_name      VARCHAR2(30 CHAR);
v_terr_column_name         VARCHAR2(30 CHAR);
v_account_column_name      VARCHAR2(30 CHAR);
v_rep_column_name          VARCHAR2(30 CHAR);
v_terr_acc_table_id        NUMBER(10);
v_terr_rep_table_id        NUMBER(10);
v_impacted_territories     TABLETYPE_NUMBER;
v_adj_count_table          VARCHAR2(30 CHAR);
v_row_count_for_remove     number(10) := 0;

BEGIN

 -- ****************************************************************************************************
 -- I. GET INFO - entities column names, assignment tables
 -- ****************************************************************************************************

  SELECT terr_to_acc.tables_physical_name,
         tc_terr.tc_physical_name AS Territory,
         tc_acc.tc_physical_name  AS Account,
         terr_to_rep.tables_physical_name,
         tc_rep.tc_physical_name  AS Rep,
         terr_to_acc.tables_id,
         terr_to_rep.tables_id
    INTO v_terr_acc_table_name, v_terr_column_name, v_account_column_name,
         v_terr_rep_table_name, v_rep_column_name,
         v_terr_acc_table_id, v_terr_rep_table_id
    FROM territories_snapshots ts
   -- Territory to Account table
   INNER JOIN tables terr_to_acc
      ON ts.ts_assign_table_id = terr_to_acc.tables_id
   -- Territory Column
    LEFT JOIN table_columns tc_terr
      ON terr_to_acc.tables_id = tc_terr.tc_tables_id
     AND tc_terr.tc_entity_id = pi_territory_entity_id
   -- Account Column
    LEFT JOIN table_columns tc_acc
      ON terr_to_acc.tables_id = tc_acc.tc_tables_id
     AND tc_acc.tc_entity_id = pi_account_entity_id
    -- Territory to Sales Rep table
    LEFT JOIN tables terr_to_rep
      ON ts.ts_user_assign_table_id = terr_to_rep.tables_id
    -- Sales Rep Column
    LEFT JOIN table_columns tc_rep
      ON terr_to_rep.tables_id = tc_rep.tc_tables_id
     AND tc_rep.tc_entity_id = pi_rep_entity_id
   WHERE ts.ts_id = pi_snapshot_id;

  -- get count adjustments table name. MAX for NO DATA FOUND
  SELECT MAX(t.tables_physical_name)
    INTO v_adj_count_table
    FROM territories_snapshots ts
   INNER JOIN tables t
      ON ts.ts_adjustments_count_table_id = t.tables_id
   WHERE ts.ts_id = pi_snapshot_id;

  -- get all impacted territories
  WITH impacted_territories AS
   (SELECT territory_entity_id AS territory
      FROM TABLE(pi_proposals)
    UNION
    SELECT territory_old_entity_id
      FROM TABLE(pi_proposals))
  SELECT territory BULK COLLECT
    INTO v_impacted_territories
    FROM impacted_territories;


 -- ****************************************************************************************************
 -- II. GET ALL PROPOSALS
 -- Improvement : map adjustment types to numbers
 -- ****************************************************************************************************
  FOR c IN (SELECT proposal_values.*,
                   ROW_NUMBER() OVER (PARTITION BY territory_entity_id,
                                                   entity_value,
                                                   adjustment_start_date,
                                                   adjustment_end_date
                                      ORDER BY territory_entity_id) occurrence_number
              FROM
                (SELECT p.territory_entity_id,
                       p.territory_old_entity_id,
                       p.adjustment_type,
                       p.adjustment_start_date,
                       p.adjustment_end_date,
                       p.adjustment_role,
                       CASE WHEN p.adjustment_type IN ('Assign', 'Reassign', 'Close Assignment') THEN v_rep_column_name
                            WHEN p.adjustment_type IN ('Align', 'Realign', 'Close Alignment', 'Bulk Adjustments') THEN v_account_column_name
                       END AS entity_column_name,
                       CASE WHEN p.adjustment_type IN ('Assign', 'Reassign', 'Close Assignment')
                            THEN CASE WHEN pi_live_or_snapshot = 'LIVE'
                                      THEN pi_user_assignment_table
                                      WHEN pi_live_or_snapshot = 'SNAPSHOT'
                                      THEN v_terr_rep_table_name
                                 END
                            WHEN p.adjustment_type IN ('Align', 'Realign', 'Close Alignment', 'Bulk Adjustments')
                            THEN CASE WHEN pi_live_or_snapshot = 'LIVE'
                                      THEN pi_assignment_table
                                      WHEN pi_live_or_snapshot = 'SNAPSHOT'
                                      THEN v_terr_acc_table_name
                                 END
                       END AS assignment_table_name,
                       CASE WHEN p.adjustment_type IN ('Assign', 'Reassign', 'Close Assignment') THEN p.rep_entity_id
                            WHEN p.adjustment_type IN ('Align', 'Realign', 'Close Alignment', 'Bulk Adjustments') THEN p.account_entity_id
                       END AS entity_value,
                       CASE WHEN p.adjustment_type IN ('Assign', 'Reassign', 'Close Assignment') THEN assignment_tables.user_assign_table_dated
                            WHEN p.adjustment_type IN ('Align', 'Realign', 'Close Alignment', 'Bulk Adjustments') THEN assignment_tables.assign_table_dated
                       END AS assign_table_dating_option
                  FROM TABLE(pi_proposals) p
                  LEFT JOIN (SELECT t_assign_table.tables_record_dating_option      AS assign_table_dated,
                                    t_user_assign_table.tables_record_dating_option AS user_assign_table_dated
                               FROM territories_snapshots ts
                               LEFT JOIN tables t_assign_table
                                 ON ts.ts_assign_table_id = t_assign_table.tables_id
                               LEFT JOIN tables t_user_assign_table
                                 ON ts.ts_user_assign_table_id =
                                    t_user_assign_table.tables_id
                              WHERE ts.ts_id = pi_snapshot_id) assignment_tables
                   ON 1=1
                  ) proposal_values

  ) LOOP


    /* -------------------------- */
    /* ---------- MOVE ---------- */
    /* -------------------------- */

    IF c.adjustment_type IN ('Reassign', 'Realign', 'Bulk Adjustments') THEN
      IF c.assign_table_dating_option = 1 THEN /* NOT EFFECTIVE DATED */

        EXECUTE IMMEDIATE 'DELETE FROM ' || c.assignment_table_name || CHR(10) ||
                          'WHERE ' || c.entity_column_name || ' =  ' || c.entity_value || ' AND ' || v_terr_column_name || ' = ' || c.territory_old_entity_id;

        -- if condition for cases when we have Acc1 moved from T1, T2 to T3 in the same action - would cause a duplicate insert and fail
        -- insert only for the first occurrence
        IF c.occurrence_number = 1 THEN
          EXECUTE IMMEDIATE 'INSERT INTO ' || c.assignment_table_name || '(' || c.entity_column_name || ', ' || v_terr_column_name || ', ROW_IDENTIFIER, ROW_VERSION
                             ' || CASE WHEN c.adjustment_type = 'Reassign' AND pi_rep_entity_id IS NOT NULL
                                       THEN ', ROLE'
                                  END ||
                            ')
                            VALUES (' || c.entity_value || ', ' || c.territory_entity_id || ',' || c.assignment_table_name || '_ROW_IDENTIFIER_SEQ.nextval, 0
                               ' || CASE WHEN c.adjustment_type = 'Reassign' AND pi_rep_entity_id IS NOT NULL
                                         THEN ', ''' || c.adjustment_role || ''''
                                    END ||
                            ')';
         END IF;
      ELSIF c.assign_table_dating_option = 4 THEN /* EFFECTIVE DATED */

        EXECUTE IMMEDIATE 'UPDATE ' || c.assignment_table_name || ' SET END_DATE = ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR') - 1) ||
                          ''' WHERE ' || c.entity_column_name || ' =  ' || c.entity_value ||
                          ' AND ' || v_terr_column_name || ' = ' || c.territory_old_entity_id ||
                          ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) > ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR') - 1) || '''' ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) <= ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR') - 1) || '''';


        IF c.occurrence_number = 1 THEN
          EXECUTE IMMEDIATE 'INSERT INTO ' || c.assignment_table_name || '(' || c.entity_column_name || ', ' || v_terr_column_name || ', START_DATE, END_DATE, ROW_IDENTIFIER, ROW_VERSION
                               ' || CASE WHEN c.adjustment_type = 'Reassign' AND pi_rep_entity_id IS NOT NULL
                                         THEN ', ROLE'
                                    END ||
                               ')
                             VALUES (' || c.entity_value || ', ' || c.territory_entity_id || ', ''' || TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR') || ''', ''' || TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR') || ''', ' || c.assignment_table_name || '_ROW_IDENTIFIER_SEQ.nextval, 0
                                     ' || CASE WHEN c.adjustment_type = 'Reassign' AND pi_rep_entity_id IS NOT NULL
                                               THEN ', ''' || c.adjustment_role || ''''
                                          END ||
                                   ')';
        END IF;

      END IF;

    /* -------------------------- */
    /* ---------- ADD ----------- */
    /* -------------------------- */

    ELSIF c.adjustment_type IN ('Assign', 'Align') THEN
        EXECUTE IMMEDIATE 'INSERT INTO ' || c.assignment_table_name || ' (ROW_IDENTIFIER, ROW_VERSION, ' || c.entity_column_name || ', ' || v_terr_column_name
                                         || CASE WHEN c.assign_table_dating_option = 4 THEN ', START_DATE, END_DATE ' END
                                         || CASE WHEN c.adjustment_type = 'Assign' AND pi_rep_entity_id IS NOT NULL THEN ', ROLE' END
                                         || ')
                           VALUES (' || c.assignment_table_name || '_ROW_IDENTIFIER_SEQ.nextval, 0, ' || c.entity_value  || ', ' || c.territory_entity_id
                                   || CASE WHEN c.assign_table_dating_option = 4
                                           THEN ', ''' || TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR') || ''', ''' || TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR') || ''''
                                      END
                                   || CASE WHEN c.adjustment_type = 'Assign' AND pi_rep_entity_id IS NOT NULL
                                           THEN ', ''' || c.adjustment_role || ''''
                                      END
                                   || ')';

    /* -------------------------- */
    /* ---------- DELETE -------- */
    /* -------------------------- */
    ELSIF c.adjustment_type IN ('Close Assignment', 'Close Alignment') THEN

      IF c.assign_table_dating_option = 1 THEN /* NOT EFFECTIVE DATED */
        EXECUTE IMMEDIATE 'DELETE FROM ' || c.assignment_table_name || ' WHERE ' || v_terr_column_name || ' = ' || c.territory_old_entity_id ||
                          ' AND ' || c.entity_column_name || ' =  ' || c.entity_value;

      ELSIF c.assign_table_dating_option = 4 THEN /* EFFECTIVE DATED */
        IF c.adjustment_end_date IS NULL THEN /* remove after a selected date option */
            EXECUTE IMMEDIATE 'UPDATE ' || c.assignment_table_name || ' SET END_DATE = ''' || TO_DATE(c.adjustment_start_date - 1, 'DD/MM/RRRR') ||
                          ''' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                          ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id ||
                          ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) >= ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''' ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) < ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''';

            EXECUTE IMMEDIATE 'DELETE FROM ' || c.assignment_table_name || ' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                          ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) >= ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''';

        ELSIF c.adjustment_end_date IS NOT NULL THEN /* remove between selected dates option */
          EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || c.assignment_table_name || ' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                          ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id || ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) < ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) ||
                          ''' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) > ''' || (TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR')) || ''' AND ROWNUM <= 1' INTO v_row_count_for_remove;

          IF v_row_count_for_remove = 1 THEN
             EXECUTE IMMEDIATE 'INSERT INTO ' || c.assignment_table_name || '(' || c.entity_column_name || ', ' || v_terr_column_name || ', START_DATE, END_DATE, ROW_IDENTIFIER, ROW_VERSION
                               ' || CASE WHEN c.adjustment_type = 'Reassign' AND pi_rep_entity_id IS NOT NULL
                                         THEN ', ROLE'
                                    END ||
                               ') SELECT ' || c.entity_column_name || ', ' || v_terr_column_name || ', ''' || TO_DATE(c.adjustment_end_date - 1, 'DD/MM/RRRR') || ''', ' || ' END_DATE' || ', ' || c.assignment_table_name || '_ROW_IDENTIFIER_SEQ.nextval, 0 ' || CASE WHEN c.adjustment_type = 'Reassign' AND pi_rep_entity_id IS NOT NULL
                                         THEN ', ROLE'
                                    END ||
                               ' FROM ' || c.assignment_table_name || ' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                               ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id || ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) < ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) ||
                          ''' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) > ''' || (TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR')) || '''';
             EXECUTE IMMEDIATE 'UPDATE ' || c.assignment_table_name || ' SET END_DATE = ''' || TO_DATE(c.adjustment_start_date - 1, 'DD/MM/RRRR') ||
                               ''' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                               ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id || ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) < ''' || c.adjustment_start_date ||
                          ''' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) > ''' || c.adjustment_end_date || '''';
          END IF;

             EXECUTE IMMEDIATE 'UPDATE ' || c.assignment_table_name || ' SET END_DATE = ''' || TO_DATE(c.adjustment_start_date - 1, 'DD/MM/RRRR') ||
                               ''' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                               ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id ||
                          ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) <= ''' || (TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR')) || '''' ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) < ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''' ||
                          ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) > ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''';
             EXECUTE IMMEDIATE 'UPDATE ' || c.assignment_table_name || ' SET START_DATE = ''' || TO_DATE(c.adjustment_end_date + 1, 'DD/MM/RRRR') ||
                               ''' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                               ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) >= ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''' ||
                          ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) > ''' || (TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR')) || '''' ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) < ''' || (TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR')) || '''';
             EXECUTE IMMEDIATE 'DELETE FROM ' || c.assignment_table_name || ' WHERE ' || c.entity_column_name || ' = ' || c.entity_value ||
                               ' AND ' || v_terr_column_name || ' =  ' || c.territory_old_entity_id ||
                          ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) <= ''' || (TO_DATE(c.adjustment_end_date, 'DD/MM/RRRR')) || '''' ||
                          ' AND NVL(START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) >= ''' || (TO_DATE(c.adjustment_start_date, 'DD/MM/RRRR')) || '''';
        END IF;
      END IF;
    END IF;

  END LOOP;

  -- update 'Last Updated Date-Time' column in territories snapshot definition
  EXECUTE IMMEDIATE 'UPDATE TERRITORIES_SNAPSHOTS TS SET TS.TS_LAST_UPDATED_TIME = SYSTIMESTAMP AT TIME ZONE ''UTC'' WHERE TS.TS_ID = ' || pi_snapshot_id;


 -- ***********************************************************************************************************************
 -- III. CALCULATE METRICS - only for selected date, since if the user changes the date it will automatically be recalculated
 -- ***********************************************************************************************************************
    IF pi_live_or_snapshot = 'SNAPSHOT' THEN
      CALCULATE_METRICS(pi_snapshot_id              => pi_snapshot_id,
                        pi_territory_entity_id      => pi_territory_entity_id,
                        pi_account_entity_id        => pi_account_entity_id,
                        pi_rep_entity_id            => pi_rep_entity_id,
                        pi_selected_date            => pi_selected_date,
                        pi_proposals                => v_impacted_territories
                        );
    END IF;

 -- ***********************************************************************************************************************
 -- III. COUNT ADJUSTMENTS
 -- ***********************************************************************************************************************

    IF v_adj_count_table IS NOT NULL THEN
      -- old territories
      COUNT_ADJUSTMENTS(pi_adjustments_count_table => v_adj_count_table,
                        pi_territory_type          => 1,
                        pi_proposals               => pi_proposals);
      -- new territories
      COUNT_ADJUSTMENTS(pi_adjustments_count_table => v_adj_count_table,
                        pi_territory_type          => 2,
                        pi_proposals               => pi_proposals);
    END IF;

END APPLY_ADJUSTMENTS;


-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160720
-- Description: Calculate impact metrics for start date, when changing the date, when proposing adjustments
--              The metrics can be of type - COUNT - no of acc/reps assigned to each territory
--                                         - SUM - calculates a sum based on an additional data table with metrics
--              The procedure is called when - creating a new snapshot to have impact metric calculated for start date
--                                           - changing the date from the date picker to have impact metrics calculated for that date
--                                           - when making an adjustment (align, assign, etc) to recalculate metrics for the impacted territories
--              The procedure calculates initial value and current value of a impact metric using snapshot tables:
--                  TS_INIT_ASSIGN_TABLE_ID, TS_INIT_USER_ASSIGN_TABLE_ID(for initial values), TS_ASSIGN_TABLE_ID, TS_USER_ASSIGN_TABLE_ID(for current values)
--              It uses 2 types of snapshot - one for keeping inital values and one for modified values because it cannot calculate all initial values
--                  at the beginning for the snapshot interval (since we can have a null end date) and we have to calculate initial values only when
--                  needed, but the assignment tables are modifid at each proposal => the initial values will not be the correct ones
--              Future improvement - use an algorithm to determine initial value based on backtracking proposals
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_snapshot_id          NUMBER            Snapshot ID
   pi_territory_entity_id  NUMBER            Territory entity ID
   pi_account_entity_id    NUMBER            Account entity ID
   pi_rep_entity_id        NUMBER            Rep entity ID
   pi_selected_date        DATE              Selected date for which metrics are calculated
   pi_proposals            TABLETYPE_NUMBER  Used when calculated metrics after an adjutment is made - contains a list of impacted territories

*/
  -----------------------------------------------------------------------------------------
-- Call example:
/*
   calculate_metrics(1, 123, 345, 556, sysdate, tabletype_number(1,2,3));
*/
-------------------------------------------------------------------------------------------
PROCEDURE CALCULATE_METRICS(pi_snapshot_id              NUMBER,
                            pi_territory_entity_id      NUMBER,
                            pi_account_entity_id        NUMBER,
                            pi_rep_entity_id            NUMBER,
                            pi_selected_date            DATE,
                            pi_proposals                TABLETYPE_NUMBER
                            )
IS

v_metrics_table_name        VARCHAR2(30 CHAR);
v_sum_metrics_sql           CLOB;
v_count_metrics_sql         CLOB;
v_sql                       CLOB;
v_territory_def_id          NUMBER(10);

v_terr_acc_table_name       VARCHAR2(30 CHAR);
v_terr_rep_table_name       VARCHAR2(30 CHAR);
v_terr_column_name          VARCHAR2(30 CHAR);
v_account_column_name       VARCHAR2(30 CHAR);
v_rep_column_name           VARCHAR2(30 CHAR);
v_init_assign_table         VARCHAR2(30 CHAR);
v_init_user_assign_table    VARCHAR2(30 CHAR);

v_terr_acc_table_id         NUMBER(10);
v_terr_rep_table_id         NUMBER(10);
v_init_assign_table_id      NUMBER(10);
v_init_user_assign_table_id NUMBER(10);
v_temp_terr_ids_count       NUMBER(10);

v_stamp                     VARCHAR2(250 CHAR);

v_start_date                DATE;
v_end_date                  DATE;


BEGIN

    v_stamp := 'TERRITORIES_ADJUSTMENTS.CALCULATE_METRICS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_snapshot_id),         ',pi_snapshot_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_territory_entity_id), ',pi_territory_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_account_entity_id),   ',pi_account_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_rep_entity_id),       ',pi_rep_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertDate(pi_selected_date),         ',pi_selected_date => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_proposals),       ',pi_proposals => <value>', v_stamp);
    END;


 -- table used to hold territory entities from hierarchy - for which impact metrics will be calculated
 EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_TERRITORY_IDS';
 EXECUTE IMMEDIATE 'BEGIN '                                                          || chr(10) ||
                   ' INSERT INTO TEMP_TERRITORY_IDS '                                || chr(10) ||
                   ' SELECT column_value '                                           || chr(10) ||
                   '   FROM territories_snapshots ts, TABLE(ts.ts_lowest_entities) ' || chr(10) ||
                   ' WHERE ts.ts_id = ' || pi_snapshot_id || ';'                     || chr(10) ||
                   ':SQLROWCNT := SQL%ROWCOUNT;'                                     || chr(10) ||
                   'END;' USING OUT v_temp_terr_ids_count;

  -- ****************************************************************************************************
  -- I. GET INFO - entities column names, assignment tables
  -- ****************************************************************************************************

  -- Start date, End date
  SELECT TS_START_DATE, TS_END_DATE
    INTO v_start_date, v_end_date
    FROM TERRITORIES_SNAPSHOTS
   WHERE TS_ID = pi_snapshot_id;


  SELECT terr_to_acc.tables_physical_name AS current_assign_table,
         tc_terr.tc_physical_name AS Territory,
         tc_acc.tc_physical_name  AS Account,
         terr_to_rep.tables_physical_name AS current_user_assign_table,
         tc_rep.tc_physical_name  AS Rep,
         terr_to_acc.tables_id,
         terr_to_rep.tables_id,
         init_terr_to_acc.tables_physical_name AS init_assign_table,
         init_terr_to_rep.tables_physical_name AS init_user_assign_table,
         init_terr_to_acc.tables_id,
         init_terr_to_rep.tables_id
    INTO v_terr_acc_table_name, v_terr_column_name, v_account_column_name,
         v_terr_rep_table_name, v_rep_column_name,
         v_terr_acc_table_id, v_terr_rep_table_id, v_init_assign_table, v_init_user_assign_table,
         v_init_assign_table_id, v_init_user_assign_table_id
    FROM territories_snapshots ts
   -- Territory to Account table
   INNER JOIN tables terr_to_acc
      ON ts.ts_assign_table_id = terr_to_acc.tables_id
   -- Territory Column
    LEFT JOIN table_columns tc_terr
      ON terr_to_acc.tables_id = tc_terr.tc_tables_id
     AND tc_terr.tc_entity_id = pi_territory_entity_id
   -- Account Column
    LEFT JOIN table_columns tc_acc
      ON terr_to_acc.tables_id = tc_acc.tc_tables_id
     AND tc_acc.tc_entity_id = pi_account_entity_id
    -- Territory to Sales Rep table
    LEFT JOIN tables terr_to_rep
      ON ts.ts_user_assign_table_id = terr_to_rep.tables_id
    LEFT JOIN tables init_terr_to_acc
      ON ts.ts_init_assign_table_id = init_terr_to_acc.tables_id
    LEFT JOIN tables init_terr_to_rep
      ON ts.ts_init_user_assign_table_id = init_terr_to_rep.tables_id
    -- Sales Rep Column
    LEFT JOIN table_columns tc_rep
      ON terr_to_rep.tables_id = tc_rep.tc_tables_id
     AND tc_rep.tc_entity_id = pi_rep_entity_id
   WHERE ts.ts_id = pi_snapshot_id;

  -- Metrics table
  SELECT metric_table.tables_physical_name,
         ts.ts_territory_def_id
    INTO v_metrics_table_name, v_territory_def_id
    FROM territories_snapshots ts
   INNER JOIN tables metric_table
      ON metric_table.tables_id = ts.ts_metrics_table_id
   WHERE ts.ts_id = pi_snapshot_id;


   -- iterate through all the impact metrics from the territory definition
   FOR c IN (SELECT tam.tam_id,
                     f.fld_column_name,
                     tam.tam_metric_entity_id,
                     t.tables_physical_name,
                     t.tables_id,
                     tc.tc_physical_name,
                     tam.tam_calculation_type,
                     tam.tam_type
                FROM territories_adj_metrics tam
                LEFT JOIN fields f
                  ON tam.tam_field_id = f.fld_id
                LEFT JOIN tables t
                  ON tam.tam_table_id = t.tables_id
                LEFT JOIN table_columns tc
                  ON t.tables_id = tc.tc_tables_id
                 AND tc.tc_entity_id = tam.tam_metric_entity_id
               WHERE tam.tam_territory_def_id = v_territory_def_id) LOOP

   -- ****************************************************************************************************
   -- II. QUERY FOR SUM METRICS
   -- Future improvement : move query for initial/current values in a function - remove duplicate code

   -- The query includes the following validations:
   --       If the territory is in the hierarchy, but not in the assignment table => impact metric = 0
   --       If the territory is in the assignment table, but its assigned acc/rep is not in the metric table => error (NULL)
   --       If the territory is in the assignment table, but its assigned acc/rep has multiple values in the metric table => error (NULL)
   --       If the metric value for an acc/rep is NULL => NULL

   -- ****************************************************************************************************

      IF c.tam_calculation_type = 0 THEN
        v_sum_metrics_sql :=  v_sum_metrics_sql ||
            'SELECT /*+ CARDINALITY(ent_ids ' || v_temp_terr_ids_count || ') */ '              || chr(10) ||
            '       ent_ids.id AS territory_internal_id, '                                    || chr(10) ||
            '       TO_DATE(''' || pi_selected_date || ''', ''DD-MON-RR'') AS METRIC_DATE, '  || chr(10) ||
            '       ' || c.tam_id || ' AS METRIC_ID, '                                        || chr(10) ||
            '        CASE WHEN initial_values.sum_value >= 1E38 THEN NULL ELSE ROUND(NVL(initial_values.sum_value,0), 2) END AS initial_value, ' || chr(10) ||
            '        CASE WHEN current_values.sum_value >=  1E38 THEN NULL ELSE ROUND(NVL(current_values.sum_value,0), 2) END AS current_value , ' || chr(10) ||
            '        0 AS ROW_VERSION ' || chr(10) ||
            '   FROM TEMP_TERRITORY_IDS ent_ids ' || chr(10) ||
            '   LEFT JOIN  '                                                                || chr(10) ||
            -- query for current values
            '      (SELECT assign.' || v_terr_column_name || ' AS TERRITORY_INTERNAL_ID,'   || chr(10) ||
            '              SUM(NVL(sum_v, 1E38)) AS sum_value '                                   || chr(10) ||
            '        FROM '  || CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_name ELSE v_terr_rep_table_name  END || ' assign '        || chr(10) ||
            '        LEFT JOIN '                                                                 || chr(10) ||
            '             (SELECT X.' || v_terr_column_name || ', dt.' || c.tc_physical_name || ', COUNT(dt. ' || c.tc_physical_name || '),'|| chr(10) ||
            '                     CASE WHEN COUNT(DT.' || c.tc_physical_name || ') != 1 OR SUM(DT.' || c.fld_column_name || ') IS NULL ' || chr(10) ||
            '                          THEN 1E38 ' || chr(10) ||
            '                     ELSE SUM(DT.' || c.fld_column_name || ') ' || chr(10) ||
            '                     END sum_v ' || chr(10) ||
            '                FROM '  || CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_name ELSE v_terr_rep_table_name END || ' X '        || chr(10) ||
            '                LEFT JOIN ' || c.tables_physical_name || ' dt'                                                                || chr(10) ||
            '                  ON X.' || c.tc_physical_name || ' = dt.' || c.tc_physical_name                                              || chr(10) ||
            '              ' || return_date_condition(CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_id ELSE v_terr_rep_table_id END, 'X', c.tables_id,
                                                      pi_selected_date, 2)                                                                                  || chr(10) ||
            '               GROUP BY x.' || v_terr_column_name || ', dt.' || c.tc_physical_name                                  || chr(10) ||
            '             ) filtered_assignments ' || chr(10) ||
            '        ON assign.' || v_terr_column_name || ' = filtered_assignments.' || v_terr_column_name || chr(10) ||
            '       AND assign.' || c.tc_physical_name || ' = filtered_assignments.' || c.tc_physical_name || chr(10) ||
            '       ' || return_date_condition(CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_id ELSE v_terr_rep_table_id END, 'assign', c.tables_id,
                                                  pi_selected_date, 1)                                                                                  || chr(10) ||
            '     GROUP BY assign.' || v_terr_column_name || chr(10) ||
            '     ) current_values ' || chr(10) ||
            ' ON ent_ids.id = current_values.TERRITORY_INTERNAL_ID ' || chr(10) ||
            ' LEFT JOIN '                                                                   || chr(10) ||
            -- query for initial values
            '      (SELECT assign.' || v_terr_column_name || ' AS TERRITORY_INTERNAL_ID,'   || chr(10) ||
            '              SUM(NVL(sum_v, 1E38)) AS sum_value '                                   || chr(10) ||
            '        FROM '  || CASE WHEN c.tam_type = 0 THEN v_init_assign_table ELSE v_init_user_assign_table  END || ' assign '        || chr(10) ||
            '        LEFT JOIN '                                                                 || chr(10) ||
            '             (SELECT X.' || v_terr_column_name || ', dt.' || c.tc_physical_name || ', COUNT(dt. ' || c.tc_physical_name || '),'|| chr(10) ||
            '                     CASE WHEN COUNT(DT.' || c.tc_physical_name || ') != 1 OR SUM(DT.' || c.fld_column_name || ') IS NULL ' || chr(10) ||
            '                          THEN 1E38 ' || chr(10) ||
            '                     ELSE SUM(DT.' || c.fld_column_name || ') ' || chr(10) ||
            '                     END sum_v ' || chr(10) ||
            '                FROM '  || CASE WHEN c.tam_type = 0 THEN v_init_assign_table ELSE v_init_user_assign_table END || ' X '       || chr(10) ||
            '                LEFT JOIN ' || c.tables_physical_name || ' dt'                                                                || chr(10) ||
            '                  ON X.' || c.tc_physical_name || ' = dt.' || c.tc_physical_name                                              || chr(10) ||
            '                ' || return_date_condition(CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_id ELSE v_terr_rep_table_id END, 'X', c.tables_id,
                                                  pi_selected_date, 2)                                                                                  || chr(10) ||
            '               GROUP BY x.' || v_terr_column_name || ', dt.' || c.tc_physical_name                                  || chr(10) ||
            '             ) filtered_assignments ' || chr(10) ||
            '        ON assign.' || v_terr_column_name || ' = filtered_assignments.' || v_terr_column_name || chr(10) ||
            '       AND assign.' || c.tc_physical_name || ' = filtered_assignments.' || c.tc_physical_name || chr(10) ||
            '       ' || return_date_condition(CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_id ELSE v_terr_rep_table_id END, 'assign', c.tables_id,
                                               pi_selected_date, 1)                                                                        || chr(10) ||
            '     GROUP BY assign.' || v_terr_column_name || chr(10) ||
            '     ) initial_values ' || chr(10) ||
            ' ON ent_ids.id = initial_values.TERRITORY_INTERNAL_ID ' || chr(10) ||
            ' UNION ALL ';


   -- ****************************************************************************************************
   -- II. QUERY FOR COUNT METRICS
   -- The query includes the following validations:
   --       If the territory is in the hierarchy, but not in the assignment table => impact metric = 0
   -- ****************************************************************************************************

     ELSIF c.tam_calculation_type = 1 THEN
        v_count_metrics_sql := v_count_metrics_sql ||
               'SELECT /*+ CARDINALITY(ent_ids ' || v_temp_terr_ids_count || ') */ '             || chr(10) ||
               '       ent_ids.id AS territory_internal_id,                        '             || chr(10) ||
               '       TO_DATE(''' || pi_selected_date || ''', ''DD-MON-RR'') AS METRIC_DATE, '  || chr(10) ||
               '       ' || c.tam_id || ' AS METRIC_ID,                                     '    || chr(10) ||
               '       NVL(count_init.count_init_value, 0) AS initial_value,                 '   || chr(10) ||
               '       NVL(count_current.count_current_value, 0) AS current_value,           '   || chr(10) ||
               '       0 AS ROW_VERSION                                                      '   || chr(10) ||
               ' FROM TEMP_TERRITORY_IDS ent_ids                                     '           || chr(10) ||
               ' LEFT JOIN ' || chr(10) ||
               -- current values
               ' (SELECT assign_table.' || v_terr_column_name || ' AS territory_internal_id, '                                                                  || chr(10) ||  -- Territory ID
               '         COUNT(assign_table.' || CASE WHEN c.tam_type = 0 THEN v_account_column_name ELSE v_rep_column_name END || ') AS count_current_value ' || chr(10) ||  -- Initial Value
               '  FROM ' || CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_name ELSE v_terr_rep_table_name END || ' assign_table '                              || chr(10) ||
                 return_date_condition(CASE WHEN c.tam_type = 0 THEN v_terr_acc_table_id  ELSE v_terr_rep_table_id END, 'assign_table', NULL,
                                       pi_selected_date, 2)  || CHR(10) ||
               ' GROUP BY assign_table.' || v_terr_column_name || ') count_current' || chr(10) ||
               '    ON ent_ids.id = count_current.territory_internal_id ' ||
               '  LEFT JOIN  ' || chr(10) ||
               -- initial values
               ' (SELECT assign_table.' || v_terr_column_name || ' AS territory_internal_id, '                                                                  || chr(10) ||  -- Territory ID
               '         COUNT(assign_table.' || CASE WHEN c.tam_type = 0 THEN v_account_column_name ELSE v_rep_column_name END || ') AS count_init_value '    || chr(10) ||  -- Initial Value
               '  FROM ' || CASE WHEN c.tam_type = 0 THEN v_init_assign_table ELSE v_init_user_assign_table END || ' assign_table '                             || chr(10) ||
                 return_date_condition(CASE WHEN c.tam_type = 0 THEN v_init_assign_table_id  ELSE v_init_user_assign_table_id END, 'assign_table', NULL,
                                       pi_selected_date, 2)  || CHR(10) ||
               ' GROUP BY assign_table.' || v_terr_column_name || ') count_init' || chr(10) ||
               '    ON ent_ids.id = count_init.territory_internal_id ' ||
               ' UNION ALL ';


      END IF;

    END LOOP;


   v_sum_metrics_sql := SUBSTR(v_sum_metrics_sql, 1, LENGTH(v_sum_metrics_sql) - 11);
   v_count_metrics_sql := SUBSTR(v_count_metrics_sql, 1, LENGTH(v_count_metrics_sql) - 11);


  -- ****************************************************************************************************
  -- II. QUERY FOR UPATING METRICS TABLE WITH INITIAL/CURRENT VALUE
  -- ****************************************************************************************************


  v_sql := ' MERGE INTO ' || v_metrics_table_name  || ' DST '  || CHR(10) ||
           ' USING '                                           || CHR(10) ||
           ' (  '                                              || CHR(10) ||
               --------------------------------
               -- Query for sum defined metrics
               --------------------------------
               CASE WHEN v_sum_metrics_sql IS NOT NULL
                    THEN v_sum_metrics_sql
               END
               ||
               -------------------------------
               -- Query for count metrics
               --------------------------
               CASE WHEN v_sum_metrics_sql IS NOT NULL AND v_count_metrics_sql IS NOT NULL THEN ' UNION ALL '
               END
               ||

               CASE WHEN v_count_metrics_sql IS NOT NULL
                    THEN  v_count_metrics_sql
               END                                                                 || CHR(10) ||
               ' ) SRC '                                                           || CHR(10) ||
            ' ON (DST.' || v_terr_column_name || ' = SRC.TERRITORY_INTERNAL_ID
                  AND DST.METRIC_ID = SRC.METRIC_ID
                  AND DST.METRIC_DATE = SRC.METRIC_DATE
                  ) ' || CHR(10) ||
            -- if the records already exists, update current value
            ' WHEN MATCHED THEN UPDATE SET DST.CURRENT_VALUE = SRC.CURRENT_VALUE ' || CHR(10) ||
            -- an adjustment was made => update only for affected territories
                 CASE WHEN pi_proposals IS NOT NULL THEN ' WHERE DST.' || v_terr_column_name || '
                IN (SELECT column_value FROM TABLE(:pi_proposals)) ' END ||
            -- else insert initial and current value
            ' WHEN NOT MATCHED THEN                     ' || CHR(10) ||
            '  INSERT (' || v_terr_column_name || ',    ' || CHR(10) ||
            '    METRIC_DATE,                           ' || CHR(10) ||
            '    METRIC_ID,                             ' || CHR(10) ||
            '    INITIAL_VALUE,                         ' || CHR(10) ||
            '    CURRENT_VALUE,                         ' || CHR(10) ||
            '    ROW_IDENTIFIER,                        ' || CHR(10) ||
            '    ROW_VERSION                            ' || CHR(10) ||
            '   ) VALUES                                ' || CHR(10) ||
            '       ( SRC.TERRITORY_INTERNAL_ID,        ' || CHR(10) ||
            '         SRC.METRIC_DATE,                  ' || CHR(10) ||
            '         SRC.METRIC_ID,                    ' || CHR(10) ||
            '         SRC.INITIAL_VALUE,                ' || CHR(10) ||
            '         SRC.CURRENT_VALUE,                ' || CHR(10) ||
            '         uid_sequence.nextval,             ' || CHR(10) ||
            '         SRC.ROW_VERSION)';


  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), ',calculate_metrics_sql => <value>' , v_stamp);

  IF pi_proposals IS NOT NULL THEN
    -- the metrics are calculated only for some territories - after an adjustment
    EXECUTE IMMEDIATE v_sql USING pi_proposals;
  ELSE
    -- the metrics are calculated for all territories from the organizational hierarchy
    EXECUTE IMMEDIATE v_sql;
  END IF;


END CALCULATE_METRICS;
-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160510
-- Description: Procedure used at create snapshot - copies data from assignment tables to snapshot tables
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_table_mapping             TABLETYPE_ID_ID   Mappings between snapshot and assignment tables
   pi_snapshot_id               NUMBER            Snapshot ID
   pi_territory_entity_id       NUMBER            Territory entity ID
   pi_account_entity_id         NUMBER            Account entity ID
   pi_rep_entity_id             NUMBE             Rep entity ID

*/
  -----------------------------------------------------------------------------------------
-- Call example:
/*
   create_snapshot(tabletype_id_id(objtype_id_id(1234, 5678)), 123456,  123, 567, 890)
*/
-----------------------------------------------------------------------------------------
PROCEDURE CREATE_SNAPSHOT(pi_table_mapping              TABLETYPE_ID_ID,
                          pi_snapshot_id                NUMBER,
                          pi_territory_entity_id        NUMBER,
                          pi_account_entity_id          NUMBER,
                          pi_rep_entity_id              NUMBER,
                          pout_inserted_rows_coll       OUT TABLETYPE_ID_ID)
IS
  v_sql                      CLOB;
  v_stamp                    VARCHAR2(250 CHAR);
  v_metrics_table_id         NUMBER(10);
  v_terr_acc_table_name      VARCHAR2(30 CHAR);
  v_terr_rep_table_name      VARCHAR2(30 CHAR);
  v_terr_column_name         VARCHAR2(30 CHAR);
  v_account_column_name      VARCHAR2(30 CHAR);
  v_rep_column_name          VARCHAR2(30 CHAR);
  v_terr_acc_table_id        NUMBER(10);
  v_terr_rep_table_id        NUMBER(10);
  v_start_date               DATE;
  v_end_date                 DATE;
  v_select_column_list       CLOB;

BEGIN

    v_stamp := 'TERRITORIES_ADJUSTMENTS.CREATE_SNAPSHOT - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_table_mapping),   ',pi_table_mapping => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_snapshot_id),         ',pi_snapshot_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_territory_entity_id), ',pi_territory_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_account_entity_id),   ',pi_account_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_rep_entity_id),       ',pi_rep_entity_id => <value>', v_stamp);
    END;

  pout_inserted_rows_coll := TABLETYPE_ID_ID();

 -- ****************************************************************************************************
 -- I. GET INFO - entities column names, assignment tables
 -- ****************************************************************************************************


 -- metric table, start date, end date
 SELECT TS_METRICS_TABLE_ID, TS_START_DATE, TS_END_DATE
   INTO v_metrics_table_id, v_start_date, v_end_date
   FROM TERRITORIES_SNAPSHOTS
  WHERE TS_ID = pi_snapshot_id;


  SELECT terr_to_acc.tables_physical_name,
         tc_terr.tc_physical_name AS Territory,
         tc_acc.tc_physical_name  AS Account,
         terr_to_rep.tables_physical_name,
         tc_rep.tc_physical_name  AS Rep,
         terr_to_acc.tables_id,
         terr_to_rep.tables_id
    INTO v_terr_acc_table_name, v_terr_column_name, v_account_column_name,
         v_terr_rep_table_name, v_rep_column_name,
         v_terr_acc_table_id, v_terr_rep_table_id
    FROM territories_snapshots ts
   -- Territory to Account table
   INNER JOIN tables terr_to_acc
      ON ts.ts_assign_table_id = terr_to_acc.tables_id
   -- Territory Column
    LEFT JOIN table_columns tc_terr
      ON terr_to_acc.tables_id = tc_terr.tc_tables_id
     AND tc_terr.tc_entity_id = pi_territory_entity_id
   -- Account Column
    LEFT JOIN table_columns tc_acc
      ON terr_to_acc.tables_id = tc_acc.tc_tables_id
     AND tc_acc.tc_entity_id = pi_account_entity_id
    -- Territory to Sales Rep table
    LEFT JOIN tables terr_to_rep
      ON ts.ts_user_assign_table_id = terr_to_rep.tables_id
    -- Sales Rep Column
    LEFT JOIN table_columns tc_rep
      ON terr_to_rep.tables_id = tc_rep.tc_tables_id
     AND tc_rep.tc_entity_id = pi_rep_entity_id
   WHERE ts.ts_id = pi_snapshot_id;

  -- iterate through all assignment tables and snapshot tables
  FOR c IN (
    SELECT t_dst.tables_id AS dest_table_id,
           t_src.tables_physical_name AS source_table,
           t_dst.tables_physical_name AS dest_table,
           t_src.tables_record_dating_option,
           LISTAGG(tc.tc_physical_name, ', ') WITHIN GROUP(ORDER BY tc.tc_order) AS column_list
      FROM TABLE(pi_table_mapping) maps
      LEFT JOIN tables t_src
        ON maps.id1 = t_src.tables_id
      LEFT JOIN tables t_dst
        ON maps.id2 = t_dst.tables_id
      LEFT JOIN table_columns tc
        ON tc.tc_tables_id = maps.id2
     WHERE tc.tc_physical_name != 'ROLE'
     GROUP BY t_src.tables_physical_name, t_dst.tables_physical_name, t_src.tables_record_dating_option, t_dst.tables_id
  ) LOOP


 -- **************************************************************************************************************
 -- II. COPY DATA - from assignment tables to snapshot tables , all the records that intersect the snapshot period
 -- **************************************************************************************************************
    v_select_column_list := c.column_list;
    v_select_column_list := replace(v_select_column_list, 'ROW_IDENTIFIER', c.dest_table || '_ROW_IDENTIFIER_SEQ.nextval AS ROW_IDENTIFIER');
    v_select_column_list := replace(v_select_column_list, 'ROW_VERSION', '0 AS ROW_VERSION');
    v_sql :=  'INSERT '                                      || chr(10) ||
              'INTO ' || c.dest_table || ' dst'              || chr(10) ||
              '  (' || c.column_list ||  ')'                 || chr(10) ||
              '  SELECT ' || v_select_column_list                   || chr(10) ||
              '    FROM ' || c.source_table || ' src_table ' || chr(10) ||
                CASE WHEN c.tables_record_dating_option = 4 THEN
              ' WHERE NOT EXISTS (SELECT 1'                            || chr(10) ||
              '                     FROM ' || c.source_table || ' src' || chr(10) ||
              '                    WHERE (NVL(src.END_DATE, TO_DATE(''12/31/9999'', ''MM/DD/RRRR'')) '                                      || chr(10) ||
              '                         < NVL(TO_DATE(''' || v_start_date || ''', ''DD-MON-RR''), TO_DATE(''01/01/1800'', ''MM/DD/RRRR''))' || chr(10) ||
              '                      OR  NVL(src.START_DATE, TO_DATE(''01/01/1800'', ''MM/DD/RRRR'')) '                                     || chr(10) ||
              '                         > NVL(TO_DATE(''' || v_end_date || ''', ''DD-MON-RR''), TO_DATE(''12/31/9999'', ''MM/DD/RRRR''))) ' || chr(10) ||
              '                      AND src.ROW_IDENTIFIER = src_table.ROW_IDENTIFIER'                                                     || chr(10) ||
              '                  )' END;



    EXECUTE IMMEDIATE v_sql;
    pout_inserted_rows_coll.extend(1);
    pout_inserted_rows_coll(pout_inserted_rows_coll.last) := OBJTYPE_ID_ID(c.dest_table_id, SQL%ROWCOUNT);
  END LOOP;


 -- **************************************************************************************************************
 -- III. CALCULATE METRICS - for snapshot start date
 -- **************************************************************************************************************

  CALCULATE_METRICS(pi_snapshot_id             => pi_snapshot_id,
                    pi_territory_entity_id     => pi_territory_entity_id,
                    pi_account_entity_id       => pi_account_entity_id,
                    pi_rep_entity_id           => pi_rep_entity_id,
                    pi_selected_date           => v_start_date,
                    pi_proposals               => NULL
   );


END;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160707
-- Description: Get adjustment initial data - procedure used for view display
-----------------------------------------------------------------------------------------
PROCEDURE GET_ADJUSTMENTS_INITIAL_DATA ( pin_assigned_entities_query       IN CLOB,
                                         pin_leaf_entities_validation      IN CLOB,
                                         pin_territories_query             IN CLOB,
                                         pin_count_territories_entities    IN CLOB,
                                         pin_entity_info_query             IN CLOB,
                                         pin_entity_ass_dates_query        IN CLOB,
                                         pout_territory_id_to_key          OUT SYS_REFCURSOR,
                                         pout_territory_to_entities        OUT SYS_REFCURSOR,
                                         pout_entities_assignment_dates    OUT SYS_REFCURSOR,
                                         pout_count_terr_entities          OUT SYS_REFCURSOR )
AS

v_stamp           VARCHAR2(250 CHAR);
v_entities_count  NUMBER;
v_leaf_ent_count  NUMBER;
v_sql             CLOB;

BEGIN
    v_stamp := 'TERRITORIES_ADJUSTMENTS.GET_ADJUSTMENTS_INITIAL_DATA - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_assigned_entities_query),    ',pin_assigned_entities_query => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_leaf_entities_validation),   ',pin_leaf_entities_validation => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_territories_query),           ',pin_territories_query => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_count_territories_entities), ',pin_count_territories_entities => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_entity_info_query),           ',pin_entity_info_query => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pin_entity_ass_dates_query),     ',pin_entity_ass_dates_query => <value>', v_stamp);
    END;

    -- ****************************************************************************************************
    -- I. Get assignments between user entities and organization hierarchy entities
    -- ****************************************************************************************************

    v_sql := 'INSERT INTO TEMP_ID_ID(ID1, ID2) ' || pin_assigned_entities_query;
    EXECUTE IMMEDIATE v_sql;
    v_entities_count := SQL%ROWCOUNT;

    -- check if there are no assigned entities for user entity
    IF v_entities_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20920, 'No entitites are assigned to user entity through assignment or hierarchy tables');
    END IF;

    -- ********************************************************************************************************
    -- II. Validate that the assigned entities are in the hierarchy relationship
    -- ********************************************************************************************************

    EXECUTE IMMEDIATE REPLACE(pin_leaf_entities_validation, 'rec_for_card_hint', v_entities_count) INTO v_leaf_ent_count;
    IF v_leaf_ent_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20921, 'Assigned entities are not in the hierarchy relationships');
    END IF;

  -- ********************************************************************************************************
    -- III. Get all territories
    -- ********************************************************************************************************

    v_sql := 'INSERT INTO TEMP_ID(ID) (SELECT LEAF_ID FROM (' || REPLACE(pin_territories_query, 'rec_for_card_hint', v_entities_count) || '))';
    EXECUTE IMMEDIATE v_sql;
    v_leaf_ent_count := SQL%ROWCOUNT;

    -- check if there are any territories the user has rights to propose adjustments to
    IF v_leaf_ent_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20922, 'No territories were determined for the current user that he has rights to propose adjustments to');
    END IF;

    OPEN pout_territory_id_to_key FOR REPLACE(pin_territories_query, 'rec_for_card_hint', v_entities_count);

    -- ********************************************************************************************************
    -- IV. Count entities per territory, order by territory
    -- ********************************************************************************************************
    DELETE FROM TEMP_ID_ID;
    v_sql := 'INSERT INTO TEMP_ID_ID(ID1) (SELECT LEAF_ID FROM (' || REPLACE(pin_count_territories_entities, 'rec_for_card_hint', v_leaf_ent_count) || ') WHERE TOTAL > 0 AND ROWNUM = 1)';
    EXECUTE IMMEDIATE v_sql;
    v_entities_count := SQL%ROWCOUNT;

  -- ********************************************************************************************************
    -- V. Get all assigned entities for the previously retrieved territory
    -- ********************************************************************************************************

    --EXECUTE IMMEDIATE REPLACE(pin_entity_info_query, 'rec_for_card_hint', v_entities_count);

  -- ********************************************************************************************************
    -- VI. Get all assigned entities start and end dates for the previously retrieved territory
    -- ********************************************************************************************************

    IF pin_entity_ass_dates_query IS NOT NULL THEN
      -- open cursor for assigned entities start and end dates query
      OPEN pout_entities_assignment_dates FOR REPLACE(pin_entity_ass_dates_query, 'rec_for_card_hint', v_entities_count);
    END IF;

    -- ********************************************************************************************************
    -- VII. Return cursor for territories and count territories assigned entities
    -- ********************************************************************************************************

    OPEN pout_territory_to_entities FOR REPLACE(pin_entity_info_query, 'rec_for_card_hint', v_entities_count);
    OPEN pout_count_terr_entities FOR REPLACE(pin_count_territories_entities, 'rec_for_card_hint', v_leaf_ent_count);

END GET_ADJUSTMENTS_INITIAL_DATA;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160726
-- Description: Procedure that inserts adjustments into proposed adjustment table
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id          NUMBER                      - Snapshot id
    pi_territory_entity_id  NUMBER                      - Territory entity id
    pi_account_entity_id    NUMBER                      - Account entity id
    pi_rep_entity_id        NUMBER                      - Sales rep entity id
    pi_proposals            TABLETYPE_TERRIT_PROPOSALS  - List of proposals
    pi_selected_date        DATE                        - Selected date from date picker
    pout_invalid_entities   OUT TABLETYPE_NUMBER        - Return list of acc/reps on which the adjustment could not be applied
                                                          if no rec updated for reassign/realign or close assignment/alignment for eff dated

*/
  -----------------------------------------------------------------------------------------
PROCEDURE PROPOSE_ADJUSTMENTS(pi_snapshot_id             NUMBER,
                              pi_territory_entity_id     NUMBER,
                              pi_account_entity_id       NUMBER,
                              pi_rep_entity_id           NUMBER,
                              pi_proposals               TABLETYPE_TERRIT_PROPOSALS,
                              pi_selected_date           DATE)
IS


v_terr_old_column_name     VARCHAR2(30 CHAR);
v_proposals_table_name     VARCHAR2(30 CHAR);
v_sql                      CLOB;

v_terr_acc_table_name      VARCHAR2(30 CHAR);
v_terr_rep_table_name      VARCHAR2(30 CHAR);
v_terr_column_name         VARCHAR2(30 CHAR);
v_account_column_name      VARCHAR2(30 CHAR);
v_rep_column_name          VARCHAR2(30 CHAR);
v_terr_acc_table_id        NUMBER(10);
v_terr_rep_table_id        NUMBER(10);
v_stamp                    VARCHAR2(250 CHAR);


BEGIN

    v_stamp := 'TERRITORIES_ADJUSTMENTS.PROPOSE_ADJUSTMENTS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_snapshot_id),         ',pi_snapshot_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_territory_entity_id), ',pi_territory_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_account_entity_id),   ',pi_account_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_rep_entity_id),       ',pi_rep_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_proposals),       ',pi_proposals => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertDate(pi_selected_date),         ',pi_selected_date => <value>', v_stamp);
    END;

 -- ****************************************************************************************************
 -- I. GET INFO - entities column names, assignment tables
 -- ****************************************************************************************************

  SELECT terr_to_acc.tables_physical_name,
         tc_terr.tc_physical_name AS Territory,
         tc_acc.tc_physical_name  AS Account,
         terr_to_rep.tables_physical_name,
         tc_rep.tc_physical_name  AS Rep,
         terr_to_acc.tables_id,
         terr_to_rep.tables_id
    INTO v_terr_acc_table_name, v_terr_column_name, v_account_column_name,
         v_terr_rep_table_name, v_rep_column_name,
         v_terr_acc_table_id, v_terr_rep_table_id
    FROM territories_snapshots ts
   -- Territory to Account table
   INNER JOIN tables terr_to_acc
      ON ts.ts_assign_table_id = terr_to_acc.tables_id
   -- Territory Column
    LEFT JOIN table_columns tc_terr
      ON terr_to_acc.tables_id = tc_terr.tc_tables_id
     AND tc_terr.tc_entity_id = pi_territory_entity_id
   -- Account Column
    LEFT JOIN table_columns tc_acc
      ON terr_to_acc.tables_id = tc_acc.tc_tables_id
     AND tc_acc.tc_entity_id = pi_account_entity_id
    -- Territory to Sales Rep table
    LEFT JOIN tables terr_to_rep
      ON ts.ts_user_assign_table_id = terr_to_rep.tables_id
    -- Sales Rep Column
    LEFT JOIN table_columns tc_rep
      ON terr_to_rep.tables_id = tc_rep.tc_tables_id
     AND tc_rep.tc_entity_id = pi_rep_entity_id
   WHERE ts.ts_id = pi_snapshot_id;



   SELECT t.tables_physical_name, tc.tc_physical_name
     INTO v_proposals_table_name, v_terr_old_column_name
     FROM territories_snapshots ts
    INNER JOIN tables t
       ON ts.ts_proposed_adj_table_id = t.tables_id
    INNER JOIN table_columns tc
       ON t.tables_id = tc.tc_tables_id
    INNER JOIN entities e
       ON tc.tc_entity_id = e.entity_id
      AND e.entity_base_entity = pi_territory_entity_id
    WHERE ts.ts_id = pi_snapshot_id;

 -- ****************************************************************************************************
 -- II. INSERT PROPOSALS INTO PROPOSALS TABLE
 -- ****************************************************************************************************

   v_sql := 'INSERT /*+ APPEND */ INTO ' || v_proposals_table_name || CHR(10) ||
            '(' || v_terr_column_name || ', '      || CHR(10) ||
                   v_terr_old_column_name || ', '  || CHR(10) ||
                   v_account_column_name || ', '   || CHR(10) ||
                   CASE WHEN v_rep_column_name IS NOT NULL THEN v_rep_column_name || ', ' END || CHR(10) ||
             '     ADJUSTMENT_TYPE, '              || CHR(10) ||
             '     CREATED_DATE_TIME, '            || CHR(10) ||
             '     START_DATE, '                   || CHR(10) ||
             '     END_DATE, '                     || CHR(10) ||
             '     SYN_COMMENT, '                  || CHR(10) ||
             '     REASON, '                       || CHR(10) ||
             '     STATUS, '                       || CHR(10) ||
             '     ROLE, '                         || CHR(10) ||
             '     ROW_IDENTIFIER, '               || CHR(10) ||
             '     ROW_VERSION) '                  || CHR(10) ||
             '   SELECT TERRITORY_ENTITY_ID, '     || CHR(10) ||
             '          TERRITORY_OLD_ENTITY_ID, ' || CHR(10) ||
             '          ACCOUNT_ENTITY_ID, '       || CHR(10) ||
                        CASE WHEN v_rep_column_name IS NOT NULL THEN
             '          REP_ENTITY_ID, '       END || CHR(10) ||
             '          ADJUSTMENT_TYPE, '         || CHR(10) ||
             '          ADJUSTMENT_DATE, '         || CHR(10) ||
             '          ADJUSTMENT_START_DATE, '   || CHR(10) ||
             '          ADJUSTMENT_END_DATE, '     || CHR(10) ||
             '          ADJUSTMENT_COMMENT, '      || CHR(10) ||
             '          ADJUSTMENT_REASON, '       || CHR(10) ||
             '          ADJUSTMENT_STATUS, '       || CHR(10) ||
             '          ADJUSTMENT_ROLE, '         || CHR(10) ||
             '          uid_sequence.nextval, '    || CHR(10) ||
             '          0 '                        || CHR(10) ||
             '    FROM TABLE(:proposals)';


    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), ',propose_adj_sql => <value>' , v_stamp);
    EXECUTE IMMEDIATE v_sql USING pi_proposals;
    COMMIT;

 -- ****************************************************************************************************
 -- III. APPLY ADJUSTMENTS ON SNAPSHOT TABLES
 -- ****************************************************************************************************

    APPLY_ADJUSTMENTS(pi_snapshot_id           => pi_snapshot_id,
                      pi_territory_entity_id   => pi_territory_entity_id,
                      pi_account_entity_id     => pi_account_entity_id,
                      pi_rep_entity_id         => pi_rep_entity_id,
                      pi_proposals             => pi_proposals,
                      pi_selected_date         => pi_selected_date,
                      pi_live_or_snapshot      => 'SNAPSHOT',
                      pi_assignment_table      => NULL,
                      pi_user_assignment_table => NULL
                      );

END PROPOSE_ADJUSTMENTS;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20161028
-- Description: Procedure that merges adjustments from snapshot with live data
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id           NUMBER                      - Snapshot id
    pi_territory_entity_id   NUMBER                      - Territory entity id
    pi_account_entity_id     NUMBER                      - Account entity id
    pi_rep_entity_id         NUMBER                      - Sales rep entity id
    pi_proposals             TABLETYPE_TERRIT_PROPOSALS  - List of proposals
    pi_assignment_table      VARCHAR2                    - Assignment table
    pi_user_assignment_table VARCHAR2                    - Alignment table

*/
-----------------------------------------------------------------------------------------
PROCEDURE MERGE_SNAPSHOT_WITH_LIVE (pi_snapshot_id           NUMBER,
                                    pi_territory_entity_id   NUMBER,
                                    pi_account_entity_id     NUMBER,
                                    pi_rep_entity_id         NUMBER,
                                    pi_proposals             TABLETYPE_TERRIT_PROPOSALS,
                                    pi_assignment_table      VARCHAR2,
                                    pi_user_assignment_table VARCHAR2
                                    )
IS
v_stamp VARCHAR2(250 CHAR);
BEGIN

    v_stamp := 'TERRITORIES_ADJUSTMENTS.PROPOSE_ADJUSTMENTS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_snapshot_id),         ',pi_snapshot_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_territory_entity_id), ',pi_territory_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_account_entity_id),   ',pi_account_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_rep_entity_id),       ',pi_rep_entity_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_proposals),       ',pi_proposals => <value>', v_stamp);
    END;

  APPLY_ADJUSTMENTS(pi_snapshot_id           => pi_snapshot_id,
                    pi_territory_entity_id   => pi_territory_entity_id,
                    pi_account_entity_id     => pi_account_entity_id,
                    pi_rep_entity_id         => pi_rep_entity_id,
                    pi_proposals             => pi_proposals,
                    pi_selected_date         => NULL,
                    pi_live_or_snapshot      => 'LIVE',
                    pi_assignment_table      => pi_assignment_table,
                    pi_user_assignment_table => pi_user_assignment_table
                    );

END MERGE_SNAPSHOT_WITH_LIVE;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20170306
-- Description: Procedure that displays proposals on View Mode
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id           NUMBER                      - Snapshot id
    pi_territory_entity_id   NUMBER                      - Territory entity id
    pi_account_entity_id     NUMBER                      - Account entity id
    pi_rep_entity_id         NUMBER                      - Sales rep entity id
    pi_territory_disp_field  VARCHAR2                    - Territory display field
    pi_aligned_disp_field    VARCHAR2                    - Account display field
    pi_assigned_disp_field   VARCHAR2                    - Rep display field
    pi_lookup_territory      NUMBER                      - Used to display proposals for specific territory ID (old or new)

*/
-----------------------------------------------------------------------------------------
PROCEDURE GET_PROPOSAL_LIST(pi_snapshot_id          NUMBER,
                            pi_territory_entity_id  NUMBER,
                            pi_aligned_entity_id    NUMBER,
                            pi_assigned_entity_id   NUMBER,
                            pi_territory_disp_field VARCHAR2,
                            pi_aligned_disp_field   VARCHAR2,
                            pi_assigned_disp_field  VARCHAR2,
                            pi_lookup_territory     NUMBER,
                            po_result               OUT SYS_REFCURSOR)
IS

v_sql CLOB;

BEGIN

  SELECT  'SELECT proposals_data.emp_or_prescriber_bk,'                                                        || chr(10) ||
          '       -- use xmlagg to aggregate territories old and new because the string can exceed 4000 chars' || chr(10) ||
          '       -- use "following-sibling" to remove duplicates in aggregation'                              || chr(10) ||
          '       RTRIM(XMLAGG(XMLELEMENT("a", proposals_data.territory_old_bk || '','') ORDER BY proposals_data.territory_old_bk).EXTRACT(''//a[not(. = ./following-sibling::a)]/text()'')' || chr(10) ||
          '                     .GETCLOBVAL(),'                                                                || chr(10) ||
          '                     '','') AS territory_old,'                                                      || chr(10) ||
          '       RTRIM(XMLAGG(XMLELEMENT("a", proposals_data.territory_new_bk || '','') ORDER BY proposals_data.territory_new_bk).EXTRACT(''//a[not(. = ./following-sibling::a)]/text()'')' || chr(10) ||
          '                     .GETCLOBVAL(),'                 || chr(10) ||
          '                     '','') AS territory_new,'       || chr(10) ||
          '       proposals_data.created_date_time,'            || chr(10) ||
          '       proposals_data.adjustment_type,'              || chr(10) ||
          '       proposals_data.start_date,'                   || chr(10) ||
          '       proposals_data.end_date,'                     || chr(10) ||
          '       proposals_data.reason,'                       || chr(10) ||
          '       proposals_data.status'                        || chr(10) ||
          '  FROM (SELECT proposals_list.emp_or_prescriber_bk,' || chr(10) ||
          '               proposals_list.territory_old_bk,'     || chr(10) ||
          '               proposals_list.territory_new_bk,'     || chr(10) ||
          '               proposals_list.territory_old_id,'     || chr(10) ||
          '               proposals_list.territory_new_id,'     || chr(10) ||
          '               proposals_list.adjustment_type,'      || chr(10) ||
          '               proposals_list.created_date_time,'    || chr(10) ||
          '               proposals_list.start_date,'           || chr(10) ||
          '               proposals_list.end_date,'             || chr(10) ||
          '               proposals_list.reason,'               || chr(10) ||
          '               -- in case one adjustment has errors, the entire grouping of adjustments => errors' || chr(10) ||
          '               MAX(proposals_list.status) OVER(PARTITION BY emp_or_prescriber_bk, adjustment_type, created_date_time, start_date, end_date, reason) AS status' || chr(10) ||
          CASE WHEN pi_lookup_territory IS NOT NULL THEN
          '               ------------------------------------------------------------------------' || chr(10) ||
          '               -- get proposals that have the same group as the territory to search for' || chr(10) ||
          '               -- e.g. Move Prescriber1 to T1 and T2 in the same action -- return both'  || chr(10) ||
          '               ------------------------------------------------------------------------' || chr(10) ||
          '               ,MAX(CASE'                                                                || chr(10) ||
          '                     WHEN territory_old_id = ' || pi_lookup_territory                    || chr(10) ||
          '                       OR territory_new_id = ' || pi_lookup_territory || ' THEN'         || chr(10) ||
          '                      1'                                                                 || chr(10) ||
          '                     ELSE'                                                               || chr(10) ||
          '                      0'                                                                 || chr(10) ||
          '                   END) OVER(PARTITION BY emp_or_prescriber_bk, adjustment_type, created_date_time, start_date, end_date, reason, status) AS has_lookup_territory' END || chr(10) ||
          '               ---------------------------------------------------------------'                                          || chr(10) ||
          '          FROM (SELECT COALESCE(' || CASE WHEN pi_assigned_disp_field IS NOT NULL THEN
          '                                TO_CHAR(employees_table.' || pi_assigned_disp_field || ')' ELSE 'NULL' END || ','        || chr(10) ||
          '                                TO_CHAR(prescribers_table.' || pi_aligned_disp_field || ')) AS emp_or_prescriber_bk,'    || chr(10) ||
          '                       territories_table_old.' || pi_territory_disp_field || ' AS territory_old_bk,'                     || chr(10) ||
          '                       territories_table_new.' || pi_territory_disp_field || ' AS territory_new_bk,'                     || chr(10) ||
          '                       territories_table_old.e_internal_id as territory_old_id,'                                         || chr(10) ||
          '                       territories_table_new.e_internal_id as territory_new_id,'                                         || chr(10) ||
          '                       proposed_adj.adjustment_type,'                                                                    || chr(10) ||
          '                       proposed_adj.created_date_time,'                                                                  || chr(10) ||
          '                       proposed_adj.start_date,'                                                                         || chr(10) ||
          '                       proposed_adj.end_date,'                                                                           || chr(10) ||
          '                       proposed_adj.reason,'                                                                             || chr(10) ||
          '                       proposed_adj.status'                                                                              || chr(10) ||
          '                  FROM ' || proposals_table.tables_physical_name || ' proposed_adj'                                      || chr(10) ||
          '                  LEFT JOIN ' || rep_entity_table.tables_physical_name || ' employees_table'                             || chr(10) ||
          '                    ON proposed_adj.' || tc_rep.tc_physical_name || ' = employees_table.e_internal_id '                  || chr(10) ||
          '                  LEFT JOIN ' || account_entity_table.tables_physical_name || ' prescribers_table'                       || chr(10) ||
          '                    ON proposed_adj.' || tc_acc.tc_physical_name || ' ='                                                 || chr(10) ||
          '                       prescribers_table.e_internal_id -- join prescribers entity table'                                 || chr(10) ||
          '                  LEFT JOIN ' ||territory_entity_table.tables_physical_name || ' territories_table_new'                  || chr(10) ||
          '                    ON proposed_adj.' || tc_terr.tc_physical_name || ' ='                                                || chr(10) ||
          '                       territories_table_new.e_internal_id -- join territories entity table'                             || chr(10) ||
          '                  LEFT JOIN ' || territory_entity_table.tables_physical_name || ' territories_table_old'                 || chr(10) ||
          '                    ON proposed_adj.' || tc_terr_old.tc_physical_name || ' ='                                            || chr(10) ||
          '                       territories_table_old.e_internal_id -- join territories old entity table'                         || chr(10) ||
          '                ) proposals_list'                  || chr(10) ||
          '               ) proposals_data'                   || chr(10) ||
          CASE WHEN pi_lookup_territory IS NOT NULL THEN
          '------------------------------------------------'  || chr(10) ||
          ' WHERE proposals_data.has_lookup_territory = 1'END || chr(10) ||
          '------------------------------------------------'  || chr(10) ||
          ' GROUP BY proposals_data.emp_or_prescriber_bk,'    || chr(10) ||
          '          proposals_data.created_date_time,'       || chr(10) ||
          '          proposals_data.adjustment_type,'         || chr(10) ||
          '          proposals_data.start_date,'              || chr(10) ||
          '          proposals_data.end_date,'                || chr(10) ||
          '          proposals_data.reason,'                  || chr(10) ||
          '          proposals_data.status'                   || chr(10) ||
          ' ORDER BY proposals_data.created_date_time DESC, proposals_data.emp_or_prescriber_bk ASC'
    INTO v_sql
    FROM territories_snapshots ts
   -- Territory Column
   INNER JOIN table_columns tc_terr
      ON ts.ts_proposed_adj_table_id = tc_terr.tc_tables_id
     AND tc_terr.tc_entity_id = pi_territory_entity_id
   -- Territory Old Column
   INNER JOIN table_columns tc_terr_old
      ON ts.ts_proposed_adj_table_id = tc_terr_old.tc_tables_id
   INNER JOIN entities terr_old_entity
     ON tc_terr_old.tc_entity_id = terr_old_entity.entity_id
    AND terr_old_entity.entity_base_entity = pi_territory_entity_id
   -- Account Column
    LEFT JOIN table_columns tc_acc
      ON ts.ts_proposed_adj_table_id = tc_acc.tc_tables_id
     AND tc_acc.tc_entity_id = pi_aligned_entity_id
    -- Sales Rep Column
    LEFT JOIN table_columns tc_rep
      ON ts.ts_proposed_adj_table_id = tc_rep.tc_tables_id
     AND tc_rep.tc_entity_id = pi_assigned_entity_id
    -- Proposals Table
    LEFT JOIN tables proposals_table
      ON ts.ts_proposed_adj_table_id = proposals_table.tables_id
    -- Territory Entity Table
    LEFT JOIN entities territory_entity
      ON tc_terr.tc_entity_id = territory_entity.entity_id
    LEFT JOIN tables territory_entity_table
      ON territory_entity_table.tables_id = territory_entity.entity_tables_id
    -- Account Entity Table
    LEFT JOIN entities account_entity
      ON tc_acc.tc_entity_id = account_entity.entity_id
    LEFT JOIN tables account_entity_table
      ON account_entity_table.tables_id = account_entity.entity_tables_id
    -- Sales Rep Entity Table
    LEFT JOIN entities rep_entity
      ON tc_rep.tc_entity_id = rep_entity.entity_id
    LEFT JOIN tables rep_entity_table
      ON rep_entity_table.tables_id = rep_entity.entity_tables_id
    WHERE ts.ts_id = pi_snapshot_id;
  OPEN po_result FOR v_sql;

END GET_PROPOSAL_LIST;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END TERRITORIES_ADJUSTMENTS;
/
