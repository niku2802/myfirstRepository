CREATE PACKAGE COVERAGE_RULES AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2017 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : coveragerules
-- Module           : coveragerules
-- Requester        :
-- Author           :
-- Reviewer         :
-- Review date      : 17 OCT 2017
-- Description      : Package used to handle all coverage rules processing
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- ========================================================
  -- Author     : Dobranici, Alexandru
  -- Create date: 20151017
  -- Description: GET_ALL_HIERARCHIES: function that returns all the non-recursive and not efective dated hierarchies.
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
    -----------------------------------------------------------------------------------------
  -- Call example:
  /*
     select * from table(COVERAGE_RULES.GET_ALL_HIERARCHIES)
  */
  -----------------------------------------------------------------------------------------
  FUNCTION GET_ALL_HIERARCHIES
    RETURN TABLETYPE_ID_NAME;

-- *******************************    PUBLIC FUNCTIONS END         *******************************
END COVERAGE_RULES;
/
