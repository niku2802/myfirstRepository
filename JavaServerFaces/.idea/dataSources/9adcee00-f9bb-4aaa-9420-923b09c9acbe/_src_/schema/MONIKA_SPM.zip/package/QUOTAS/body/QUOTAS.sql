CREATE PACKAGE BODY QUOTAS AS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : quotas
-- Module           : quotas
-- Requester        : Horlescu, Gabriel
-- Author           : Banea, Elena; Macarie, Sabina
-- Reviewer         : Banea, Elena
-- Review date      : 29 JUL 2014
-- Description      : Package used to handle all quotas processing validations
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************


-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140826
-- Description: Returns the period name
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_gpn_tupr_id IN tu_periods_range.tupr_id%type -- period id
*/
-----------------------------------------------------------------------------------------
FUNCTION GET_PERIOD_NAME ( pi_gpn_tupr_id IN tu_periods_range.tupr_id%type )
  RETURN tu_periods_range.tupr_period_range_name% type
AS
  v_period_being_run tu_periods_range.tupr_period_range_name% type; -- period
BEGIN
  SELECT tupr_period_range_name
    INTO v_period_being_run
  FROM tu_periods_range
  WHERE tupr_id = pi_gpn_tupr_id;

  RETURN v_period_being_run;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
END GET_PERIOD_NAME;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160330
-- Description: Procedure used for upgrading quota definitions when removing Calculate Attainment option
-- Details : (Upgrade Considerations) - http://confluence.optymyze.net/display/Quotas/Quotas+-+Support+calculated+additional+fields+display+in+Quotas+Management+app
-----------------------------------------------------------------------------------------
PROCEDURE UPGRADE_QUOTA_ATTAINMENT
AS

v_sql           CLOB;
v_entities_list CLOB;
v_entities_join CLOB;

BEGIN


  FOR c IN (SELECT qd.qd_id,
                   qd.qd_multiple_q_entity_id    AS product_entity_id,
                   iq_table.tables_physical_name AS initial_quotas_table,
                   iq_table.tables_id            AS initial_quotas_table_id,
                   q_table.tables_physical_name  AS quotas_table,
                   tc.tc_physical_name           AS product_column_name,
                   tc_period.tc_physical_name    AS period_column_name,
                   qd.qd_include_quota_hierarchy AS q_has_quota_hierarchy
              FROM quota_definitions qd
              LEFT JOIN tables iq_table
                ON qd.qd_iq_tables_id = iq_table.tables_id
              LEFT JOIN tables q_table
                ON qd.qd_adj_tables_id = q_table.tables_id
              LEFT JOIN table_columns tc
                ON qd.qd_multiple_q_entity_id = tc.tc_entity_id
               AND tc.tc_tables_id = iq_table.tables_id
              LEFT JOIN table_columns tc_period
                ON tc_period.tc_tables_id = iq_table.tables_id
               AND tc_period.tc_logic_type = 8
             WHERE qd.qd_is_valid = 1
               AND EXISTS (SELECT 1 FROM table_columns tc
                            WHERE tc.tc_tables_id = iq_table.tables_id
                              AND tc.tc_physical_name = 'REACHED_QUOTA')
            ) LOOP

    SELECT LISTAGG('quotas_table.' || tc_physical_name || ' = initial_quotas_table.' || tc_physical_name
                   || CASE WHEN c.product_column_name IS NOT NULL THEN
                      ' AND quotas_table.' || c.product_column_name || ' = initial_quotas_table.' || c.product_column_name END
                   || ' AND quotas_table.' || c.period_column_name || ' = initial_quotas_table.' || c.period_column_name, ' OR ') WITHIN GROUP (ORDER BY 1),
           LISTAGG('q.' || tc_physical_name, ', ') WITHIN GROUP (ORDER BY 1)
      INTO v_entities_join, v_entities_list
      FROM table_columns tc
     WHERE tc.tc_tables_id = c.initial_quotas_table_id
       AND tc.tc_entity_id IS NOT NULL
       AND tc.tc_entity_id != NVL(c.product_entity_id, 1E38);

    EXECUTE IMMEDIATE 'UPDATE ' || c.initial_quotas_table || ' SET reached_quota = NULL';

    v_sql := 'MERGE INTO ' || c.initial_quotas_table || ' initial_quotas_table' || chr(10) ||
             'USING (SELECT ' || v_entities_list || CASE WHEN c.product_column_name IS NOT NULL THEN ' ,q.' || c.product_column_name END
                              || ',q.reached_quota' || ', q.' || c.period_column_name || chr(10) ||
             '         FROM ' || c.quotas_table || ' q) quotas_table' || chr(10) ||
             'ON (' || v_entities_join || ')' || chr(10) ||
             'WHEN MATCHED THEN' || chr(10) ||
             '  UPDATE' || chr(10) ||
             '     SET initial_quotas_table.reached_quota = quotas_table.reached_quota';

    EXECUTE IMMEDIATE v_sql;
  END LOOP;

END UPGRADE_QUOTA_ATTAINMENT;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20151202
-- Description: Returns the list of additional fields that are set to be displayed from the definition
                -- option -- 1 - returns the list as a string separated by comma
                -- option -- 2 - returns the list as a sum(field) seprated by comma, used in case of product hieararchy
                --               to calculate the sum for each field for each level in product hierarchy

-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_qd_id  IN quota_definitions.qd_id%TYPE -- quota definition id
   pi_option IN NUMBER -- 1 - list as string, 2 - list as sum(field)
   pi_alias  IN VARCHAR2 - returns the list with the appended alias
*/
-----------------------------------------------------------------------------------------
FUNCTION GET_ADDITIONAL_FIELDS (pi_qd_id  IN quota_definitions.qd_id%TYPE,
                                pi_option IN NUMBER,
                                pi_alias  IN VARCHAR2 DEFAULT NULL
                               )
  RETURN VARCHAR2
AS
v_field_list VARCHAR2(4000 CHAR);
BEGIN
  SELECT LISTAGG( CASE WHEN pi_option = 1 THEN pi_alias || tc.tc_physical_name
                       WHEN pi_option = 2 THEN CASE WHEN f.fld_data_type = 1 THEN ' NULL ' ELSE 'SUM(' || pi_alias || tc.tc_physical_name || ')' END || ' AS ' || tc.tc_physical_name
                       WHEN pi_option = 3 THEN 'dst.' || tc_physical_name || ' = src.' || tc_physical_name END, ',') WITHIN GROUP (ORDER BY tc_order)
    INTO v_field_list
    FROM quota_additional_fields qaf
   INNER JOIN fields f
      ON qaf.qaf_field_id = f.fld_id
   INNER JOIN table_columns tc
      ON f.fld_id = tc.tc_fld_id
   WHERE qaf_qd_id = pi_qd_id
     AND qaf_type = 0
     AND tc.tc_tables_id = (SELECT qd.qd_iq_tables_id
                              FROM quota_definitions qd
                             WHERE qd.qd_id = pi_qd_id);
  RETURN v_field_list;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
END GET_ADDITIONAL_FIELDS;



-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140826
-- Description: Procedure that validates that Initial Quotas table has records after filtering on the period being run
--  http://confluence.optymyze.net/display/SD/Determining+the+records+from+the+Initial+Quotas+table+that+are+relevant+for+the+period+being+run
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_vihr_tupr_id               IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_vihr_qd_id                 IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_vihr_iq_table_name         IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
  pi_vihr_no_dist_ent           IN NUMBER,                                 -- number of distinct entities from Entity Relationship
  pi_vihr_iq_period_col_name    IN table_columns.tc_physical_name%type,    -- name of period column from Initial Quotas table
  pout_vihr_no_rec_failed       OUT NUMBER                                 -- number of records that failed the validation
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_IQ_HAS_RECORDS ( pi_vihr_tupr_id               IN tu_periods_range.tupr_id%type ,
                                    pi_vihr_qd_id                 IN quota_definitions.qd_iq_tables_id%type ,
                                    pi_vihr_iq_table_name         IN tables.tables_physical_name%type ,
                                    pi_vihr_no_dist_ent           IN NUMBER,
                                    pi_vihr_iq_period_col_name    IN table_columns.tc_physical_name%type ,
                                    pout_vihr_no_rec_failed       OUT NUMBER
                                  )
AS
  v_sql                     CLOB;
BEGIN
    -- --------------------------------------------------------------------------------------------------
    --   II.1. Determining the records from the Initial Quotas table that are relevant for the period being run
    --         If there are no records after filtering the Initial Quotas table for the period being run, processing fails
    -- --------------------------------------------------------------------------------------------------
    v_sql := 'BEGIN'|| CHR(10 ) ||
             'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ERROR_MESSAGE)' || CHR(10 ) ||
             'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) ||
             '       -20901 AS failed_validation,' || CHR(10) ||
             '       ''-''' || CHR(10) ||
             'FROM DUAL' || CHR(10 ) ||
             'WHERE (SELECT COUNT(1) '||
             '      FROM ' ||pi_vihr_iq_table_name|| ' i '||
             '      WHERE i.' ||pi_vihr_iq_period_col_name || ' = ' || pi_vihr_tupr_id ||
             '        AND rownum <= 1) = 0;' || CHR(10) ||
             ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
             'END;';

    EXECUTE IMMEDIATE v_sql USING OUT pout_vihr_no_rec_failed;

    IF pout_vihr_no_rec_failed > 0 THEN
       COMMIT;
       RAISE e_stop_processing;
    END IF ;

    -- --------------------------------------------------------------------------------------------------
    --   II.2. Check that Initial Quotas table has an instance for each organization hierarchy
    --         Note that this validation is not performed if the entity relationships consist of a single
    ---        distinct entity (e.g., Employee -> Employee). If this validation fails, processing fails
    -- --------------------------------------------------------------------------------------------------
    -- this validation is performed if the entity relationships does NOT consist of a single distinct entity
    IF pi_vihr_no_dist_ent != 4 THEN
        -- Determine list of entities that don't have any value NOT NULL in Initial Quotas table
        SELECT -- COUNT is used to avoid NO_DATA_FOUND when all the records are correct
               'SELECT LISTAGG(entity_name,'', '') WITHIN GROUP (ORDER BY entity_name) AS entities_list, COUNT(*) AS cnt'||
               ' FROM ('|| LISTAGG('(SELECT ''' ||REPLACE(E.ENTITY_NAME, CHR(39), CHR(39 )||CHR(39)) || '''' ||' AS entity_name' ||
                                   ' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ' || pi_vihr_iq_table_name  ||
                                   '   WHERE '|| pi_vihr_iq_period_col_name || ' = ' || pi_vihr_tupr_id || -- consider only records from the period being run
                                   '     AND ' || tc_ent.tc_physical_name ||' IS NOT NULL))' ,' UNION ALL ')
                                         WITHIN GROUP (ORDER BY 1)||
               ')'
          INTO v_sql
        FROM         quota_definitions       qd
          -- Quota Entities
          INNER JOIN table_columns           tc_ent ON tc_ent.tc_tables_id = qd.qd_qe_tables_id
          INNER JOIN entities                e      ON e.entity_id = tc_ent.tc_entity_id
        WHERE qd.qd_id = pi_vihr_qd_id
          -- all the columns from TABLE_COLUMNS that are entities
          AND tc_ent.tc_column_type = 1
          -- and don't have a base entitiy (e.g. they are not upper entities)
          AND e.entity_base_entity IS NULL;

        EXECUTE IMMEDIATE 'BEGIN'|| CHR( 10) ||
                           'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ERROR_MESSAGE)' || CHR(10 ) ||
                           'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) ||
                           '       -20902 AS failed_validation,' || CHR(10) ||
                           '       entities_list ' || CHR(10) ||
                           'FROM ('||v_sql||')' || CHR(10) ||
                           'WHERE cnt > 0 ;' || CHR(10 ) ||
                           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                           'END;'
          USING OUT pout_vihr_no_rec_failed;

        IF pout_vihr_no_rec_failed > 0 THEN
          COMMIT;
          RAISE e_stop_processing;
        END IF ;
    END IF ;
    EXCEPTION
    WHEN e_stop_processing THEN
      pout_vihr_no_rec_failed := pout_vihr_no_rec_failed + 1;
      RAISE e_stop_processing;
END VALIDATE_IQ_HAS_RECORDS;



-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150515
-- Description: Procedure that validates that Quotas table has records after filtering on the period being run
-- http://confluence.optymyze.net/display/SD/Calculate+Attainment+process
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_vqhr_tupr_id               IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_vqhr_q_table_name          IN tables.tables_physical_name%type,       -- the name of the QUOTAS table
  pi_vqhr_q_period_col_name     IN table_columns.tc_physical_name%type,    -- name of period column from Quotas table
  pout_vqhr_no_rec_failed       OUT NUMBER                                 -- number of records that failed the validation
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_Q_HAS_RECORDS  ( pi_vqhr_tupr_id               IN tu_periods_range.tupr_id%type ,
                                    pi_vqhr_q_table_name          IN tables.tables_physical_name%type ,
                                    pi_vqhr_q_period_col_name     IN table_columns.tc_physical_name%type ,
                                    pout_vqhr_no_rec_failed       OUT NUMBER
                                  )
AS
  v_sql                     CLOB;
BEGIN
    -- --------------------------------------------------------------------------------------------------
    --   II.1. Determining the records from the Quotas table that are relevant for the period being run
    --         If there are no records after filtering the Initial Quotas table for the period being run, processing fails
    -- --------------------------------------------------------------------------------------------------
    v_sql := 'BEGIN'|| CHR(10 ) ||
             'INSERT INTO TEMP_QUOTAS_ATT_VALIDATIONS(TQAV_ROW_IDENTIFIER,TQAV_VALIDATION_ID,TQAV_ERROR_MESSAGE)' || CHR(10 ) ||
             'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) ||
             '       -20913 AS failed_validation,' || CHR(10) ||
             '       ''-''' || CHR(10) ||
             'FROM DUAL' || CHR(10 ) ||
             'WHERE (SELECT COUNT(1) '||
             '      FROM ' ||pi_vqhr_q_table_name|| ' i '||
             '      WHERE i.' ||pi_vqhr_q_period_col_name || ' = ' || pi_vqhr_tupr_id ||
             '        AND rownum <= 1) = 0;' || CHR(10) ||
             ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
             'END;';

    EXECUTE IMMEDIATE v_sql USING OUT pout_vqhr_no_rec_failed;

    IF pout_vqhr_no_rec_failed > 0 THEN
       COMMIT;
       RAISE e_stop_processing;
    END IF ;

END VALIDATE_Q_HAS_RECORDS;
-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140827
-- Description: Procedure that generates the temporary hierarchy query that holds all the leaf nodes
--              and upper instances present in IQ and in the hierarchy
-----------------------------------------------------------------------------------------
-- Parameters:
/*
pi_ghq_tupr_id            IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
pi_ghq_qd_id              IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
pi_ghq_iq_table_name      IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
pi_ghq_iq_qe_mapping      IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
pi_ghq_iq_period_col_name IN table_columns.tc_physical_name%type     -- name of the column from Initial Quotas that holds period information
pi_ghq_h_no_of_rec        IN NUMBER                                  -- the number of records from the hierarchy (TMP_IQ_HIERARCHY)
pi_ghq_no_of_records      OUT NUMBER                                 -- the number of records inserted in TEMP_QUOTAS_HIERARCHY_QUERY
*/
-----------------------------------------------------------------------------------------
PROCEDURE GENERATE_HIERARCHY_QUERY ( pi_ghq_tupr_id            IN tu_periods_range.tupr_id%type,
                                     pi_ghq_qd_id              IN quota_definitions.qd_iq_tables_id%type,
                                     pi_ghq_iq_table_name      IN tables.tables_physical_name%type,
                                     pi_ghq_iq_qe_mapping      IN TABLETYPE_NAME_MAP,
                                     pi_ghq_iq_period_col_name IN table_columns.tc_physical_name%type,
                                     pi_ghq_h_no_of_rec        IN NUMBER,
                                     pout_ghq_no_of_records      OUT NUMBER
                                    )
AS
  v_sql                     CLOB;
  v_stamp                   VARCHAR2(250 CHAR);
BEGIN
  -- Determine join conditions for the hierarchy

  SELECT LISTAGG_JAVA(OBJTYPE_WORD_DLM(CASE WHEN e.entity_id = qer.leaf_entity_id
                      THEN ' (SELECT /*+ CARDINALITY(hq ' || pi_ghq_h_no_of_rec || ') */ 1 ' || CHR(10) ||
                           '   FROM ' || pi_ghq_iq_table_name || ' IQ ' || CHR(10) ||
                           '  INNER JOIN TMP_IQ_HIERARCHY HQ ON' || CHR(10) ||
                           '  (hq.lower_entity_id = '|| tc.tc_entity_id || ' AND hq.lower_value = iq.'||tc.tc_physical_name || ')' || CHR(10) ||
                           'WHERE LEAFS = 1
                              AND IQ.' || pi_ghq_iq_period_col_name || ' = ' || pi_ghq_tupr_id || '
                              AND LOWER_ENTITY_ID = HH.PARENT_LOWER_ENTITY_ID
                              AND LOWER_VALUE = HH.PARENT_LOWER_VALUE)'
                      END,' OR EXISTS', 100)) AS hcond_leafs
     INTO v_sql
  FROM         quota_definitions             qd
     -- Quota Entities columns
     INNER JOIN table_columns                tc  ON tc.tc_tables_id = qd.qd_qe_tables_id
     INNER JOIN table(pi_ghq_iq_qe_mapping)  mp  ON tc.tc_physical_name = mp.name2
     INNER JOIN entities                     e   ON e.entity_id = tc.tc_entity_id
     -- Determine the entities that are at the lowest levels in Entity Relationship
     LEFT  JOIN (SELECT DISTINCT qer.qer_entity_id AS leaf_entity_id
                 FROM quota_entity_relations qer
                 WHERE qer.qer_qd_id = pi_ghq_qd_id
                   AND CONNECT_BY_ISLEAF=1
                   START WITH qer.qer_parent_node_id IS NULL
                   CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
                 ) qer ON e.entity_id = qer.leaf_entity_id
  WHERE qd.qd_id = pi_ghq_qd_id
     -- all the columns from TABLE_COLUMNS that are entities
     AND tc.tc_entity_id IS NOT NULL
     -- and don't have a base entity (e.g. they are not upper entities)
     AND e.entity_base_entity IS NULL;

  v_sql := 'BEGIN'|| CHR( 10) ||
           'INSERT INTO TEMP_QUOTAS_HIERARCHY_QUERY(TQHQ_ROW_IDENTIFIER, TQHQ_UPPER_ENTITY_ID, TQHQ_UPPER_VALUE, '||
                                                   'TQHQ_LOWER_ENTITY_ID, TQHQ_LOWER_VALUE, TQHQ_CON_UPPER_ENTITY_ID, TQHQ_CON_UPPER_VALUE)' || CHR( 10) ||
           '-- all the leaf nodes and upper instances present in IQ and in the hierarchy ' || CHR( 10) ||
           'SELECT TEMP_QUOTAS_HIERARCHY_QUER_SEQ.nextval,hh.upper_entity_id,hh.upper_value,hh.lower_entity_id,hh.lower_value,'|| CHR(10 ) ||
           '       hh.con_upper_entity_id,hh.con_upper_value ' || CHR(10) ||
           'FROM '|| CHR(10 ) ||
           '  (SELECT upper_entity_id, upper_value,' || CHR(10) ||
           '          lower_entity_id, lower_value,' || CHR(10) ||
           '          CONNECT_BY_ROOT lower_entity_id AS parent_lower_entity_id,' || CHR( 10) ||
           '          CONNECT_BY_ROOT lower_value AS parent_lower_value,' || CHR( 10) ||
           '          con_upper_entity_id,con_upper_value,' || CHR(10) ||
           '          leafs ' || CHR(10) ||
           '   FROM ' || CHR(10 ) ||
           '     (SELECT /*+ CARDINALITY(h ' || pi_ghq_h_no_of_rec || ') */ upper_entity_id,lower_entity_id,upper_value,lower_value,leafs,' || CHR(10) ||
           '             parent_upper_entity_id con_upper_entity_id, parent_upper_value con_upper_value' || CHR( 10) ||
           '      FROM TMP_IQ_HIERARCHY h) hq' || CHR(10) ||
           '      START WITH Leafs=1' || CHR(10) ||
           '      CONNECT BY PRIOR upper_entity_id = lower_entity_id' || CHR(10) ||
           '             AND PRIOR upper_value  = lower_value' || CHR(10) ||
           '   ) hh' || CHR(10 ) ||
           '   -- all the leaf nodes present in IQ ' || CHR(10) ||
           '   WHERE EXISTS' || v_sql || ';' || chr(10) ||
           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
           'END;';
  v_stamp := 'QUOTAS.GENERATE_HIERARCHY_QUERY - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),',v_sql => <value>', v_stamp);


  EXECUTE IMMEDIATE v_sql USING OUT pout_ghq_no_of_records;

END GENERATE_HIERARCHY_QUERY;


-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140912
-- Description: Procedure that validates:
--   -> there are records in Initial Quotas table at the lowest levels (10002)
--      (http://confluence.optymyze.net/pages/viewpage.action?pageId=8851225)
--   -> each hierarchy entity instance in the Initial Quotas table that is not at the
--      lowest level is an upper level to the lowest level (10005)
--      (http://confluence.optymyze.net/display/SD/Each+hierarchy+entity+instance+in+the+Initial+Quotas+table+that+is+not+at+the+lowest+level+is+an+upper+level+to+the+lowest+level)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_25_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
 pi_25_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
 pi_25_iq_table_name   IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
 pi_25_iq_qe_mapping   IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
 pi_25_no_dist_ent     IN NUMBER,                                 -- number of distinct entities from Entity Relationship
 pi_25_no_of_records   IN NUMBER,                                 -- number of records from TEMP_QUOTAS_HIERARCHY_QUERY
 pout_25_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_10002_10005 ( pi_25_tupr_id            IN tu_periods_range.tupr_id%type ,
                                 pi_25_qd_id              IN quota_definitions.qd_iq_tables_id%type ,
                                 pi_25_iq_table_name      IN tables.tables_physical_name%type ,
                                 pi_25_iq_qe_mapping      IN TABLETYPE_NAME_MAP,
                                 pi_25_no_dist_ent        IN NUMBER ,
                                 pi_25_no_of_records      IN NUMBER ,
                                 pi_25_iq_period_col_name IN table_columns.tc_physical_name%type ,
                                 pout_25_failed_val_no    OUT NUMBER
                               )
AS
  -- use many CLOB variables because the query generated can exceed the maximum number of characters allowed in SELECT (4000)
  v_sql                     CLOB;
  v_select                  CLOB;
  v_leaf_entity_ids         VARCHAR2(500 );
  v_parent_entity_id        entities.entity_id% type;
  v_stamp                   VARCHAR2(250 CHAR);
BEGIN

  SELECT CASE WHEN pi_25_no_dist_ent != 4 -- not one distinct entity
               THEN 'CASE ' ||LISTAGG('WHEN '|| pi_25_iq_table_name ||'.'|| tc.tc_physical_name ||' IS NOT NULL THEN '|| e.entity_id, ' ' ) WITHIN GROUP ( ORDER BY 1) || ' END AS entity_id,' || CHR(10 )||
                    'COALESCE('|| LISTAGG(pi_25_iq_table_name || '.' || tc.tc_physical_name,', ') WITHIN GROUP ( ORDER BY 1) || ') AS entity_value'
               ELSE LISTAGG( e.entity_id || ' AS entity_id,' || CHR(10)||
                             pi_25_iq_table_name || '.' || tc.tc_physical_name || ' AS entity_value',' ') WITHIN GROUP (ORDER BY 1)
          END AS entity_values,
          COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'VALIDATE_10002_10005', pi_25_qd_id, null) ||
          ' SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'VALIDATE_10002_10005', pi_25_qd_id, null) || ' TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || pi_25_iq_table_name || '.row_identifier,failed_validation,' || CHR( 10) ||
          '        ' || CASE WHEN pi_25_no_dist_ent != 4 -- not one distinct entity
                            THEN 'COALESCE(' || LISTAGG('TO_CHAR('||t.tables_physical_name|| '.' || tcbk.tc_physical_name||')' ,',')
                                    WITHIN GROUP (ORDER BY 1) || ')  AS TQV_ENTITY_VALUE,' || CHR( 10)||
                                 'CASE '||LISTAGG(' WHEN ' || t.tables_physical_name|| '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN '''||
                                       REPLACE(E.ENTITY_NAME, CHR(39 ), CHR(39)||CHR(39 ))||'''', ' ')
                                       WITHIN GROUP (ORDER BY 1) || ' END  AS TQV_ENTITY_NAME'
                            ELSE LISTAGG(t.tables_physical_name|| '.' || tcbk.tc_physical_name|| '  AS TQV_ENTITY_VALUE, ' || CHR(10)||
                                         ' '''||REPLACE (E.ENTITY_NAME, CHR(39), CHR(39 )||CHR(39))|| ''''||' AS TQV_ENTITY_NAME' ,' ') WITHIN GROUP (ORDER BY 1)
                      END || CHR(10 ) ||
           'FROM diff'|| CHR(10 ) ||
           '  INNER JOIN ' || pi_25_iq_table_name || ' ON ' || LISTAGG(' (diff.entity_id = ' || e.entity_id || ' AND ' || pi_25_iq_table_name || '.'|| tc.tc_physical_name || ' = diff.entity_value)' ,' OR ')
                                                                    WITHIN GROUP (ORDER BY 1) || CHR(10 ) ||
           '  -- join with entities in order to obtain entity BK value' || CHR(10) ||
           '  '|| LISTAGG('     LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = ' || pi_25_iq_table_name || '.' ||tc.tc_physical_name||CHR(10 ),' ')
                    WITHIN GROUP (ORDER BY 1)  || CHR(10 ) ||
           'WHERE rn <=1000 AND ' || pi_25_iq_table_name || '.'|| pi_25_iq_period_col_name || ' = '|| pi_25_tupr_id || ';',
          -- v_leaf_entity_ids
          LISTAGG(leaf_entity_id, ', ') WITHIN GROUP (ORDER BY 1 ) AS leaf_entity_ids,
          -- v_parent_entity_id
          LISTAGG(qer1.qer_entity_id, ',') WITHIN GROUP (ORDER BY 1 ) AS parent_entity_id
     INTO v_sql, v_select, v_leaf_entity_ids, v_parent_entity_id
   FROM       quota_definitions           qd
    INNER JOIN table_columns              tc ON tc.tc_tables_id = qd.qd_iq_tables_id
    INNER JOIN TABLE(pi_25_iq_qe_mapping) mp ON mp.name1 = tc.tc_physical_name
    INNER JOIN entities                   e  ON e.entity_id = tc.tc_entity_id
    INNER JOIN tables                     t  ON t.tables_id = e.entity_tables_id
    -- entities Business Key
    INNER JOIN table_columns              tcbk ON tcbk.tc_tables_id = t.tables_id
                                               AND tcbk.tc_logic_type IN (1, 5)
    -- Determine parent entity id in the hierarchy
    LEFT  JOIN quota_entity_relations     qer1 ON qer1.qer_qd_id = qd.qd_id
                                               AND qer1.qer_entity_id = e.entity_id
                                               AND qer1.qer_level=1
    -- Determine the entities that are at the lowest levels in Entity Relationship
    LEFT JOIN (SELECT DISTINCT qer.qer_entity_id AS leaf_entity_id
                       FROM quota_entity_relations qer
                       WHERE qer.qer_qd_id = pi_25_qd_id
                         AND CONNECT_BY_ISLEAF=1
                       START WITH qer.qer_parent_node_id IS NULL
                       CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
               ) l ON l.leaf_entity_id = e.entity_id
   WHERE qd.qd_id = pi_25_qd_id
       AND tc.tc_column_type = 1 ; -- entity column

  v_sql := 'BEGIN'|| CHR( 10) ||
           'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_IQ_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ENTITY_VALUE,TQV_ENTITY_NAME)' || CHR(10) ||
           'WITH diff AS (SELECT dif.*,'|| CHR(10 ) ||
           CASE WHEN pi_25_no_dist_ent != 4 -- not one distinct entity
                THEN '                     CASE WHEN entity_id IN (' || v_leaf_entity_ids || ') THEN 10002 ELSE 10005 END AS failed_validation,'|| CHR( 10) ||
                     '                     ROW_NUMBER() OVER (PARTITION BY CASE WHEN entity_id IN ('|| v_leaf_entity_ids || ') THEN 10002 ELSE 10005 END ORDER BY 1) AS rn'
                ELSE '                     10005 as failed_validation,' || CHR(10) ||
                     '                     ROWNUM as rn'
           END || CHR(10 ) ||
           '             FROM (SELECT ' || v_sql || CHR(10) ||
           '                    FROM ' || pi_25_iq_table_name || CHR(10) ||
           '                   WHERE ' || pi_25_iq_table_name || '.' || pi_25_iq_period_col_name || ' = '|| pi_25_tupr_id || CHR(10 ) ||
           '                   MINUS' || CHR(10) ||
           '                   (SELECT /*+ CARDINALITY(h ' || pi_25_no_of_records || ') */ h.tqhq_lower_entity_id,h.tqhq_lower_value' || CHR(10) ||
           '                     FROM TEMP_QUOTAS_HIERARCHY_QUERY h' || CHR(10) ||
           '                      UNION ALL' || CHR(10) ||
           '                   SELECT /*+ CARDINALITY(h ' || pi_25_no_of_records || ') */ DISTINCT h.tqhq_upper_entity_id,h.tqhq_upper_value'||
           '                     FROM TEMP_QUOTAS_HIERARCHY_QUERY h' || CHR(10) ||
           '                    WHERE NOT EXISTS (SELECT 1 FROM TEMP_QUOTAS_HIERARCHY_QUERY hh '|| CHR( 10) ||
           '                                       WHERE h.tqhq_upper_entity_id=hh.tqhq_lower_entity_id AND h.tqhq_upper_value=hh.tqhq_lower_value)' || CHR( 10) ||
           CASE WHEN pi_25_no_dist_ent = 1 -- top 2 entities are NOT the same
                THEN
           '                      -- not a branch that does not go all the way up'|| CHR(10) ||
           '                      AND h.tqhq_upper_entity_id = ' || v_parent_entity_id
           END || CHR(10 ) ||
           '                   )  ) dif' || CHR(10) ||

           '             )' || CHR(10) ||
           v_select || CHR( 10) ||
           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
           'END;';

  v_stamp := 'QUOTAS.VALIDATE_10002_10005 - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),      ',v_sql => <value>' , v_stamp);

  EXECUTE IMMEDIATE v_sql USING OUT pout_25_failed_val_no;
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_25_failed_val_no),',pout_25_failed_val_no => <value>', v_stamp);
END VALIDATE_10002_10005;

-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140912
-- Description: Procedure that validates that each upper level instance has a record
--              in the filtered Initial Quotas table
--      (http://confluence.optymyze.net/display/SD/Each+upper+level+instance+has+a+record+in+the+filtered+Initial+Quotas+table)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_4_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
 pi_4_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
 pi_4_iq_table_name   IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
 pi_4_iq_qe_mapping   IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
 pi_4_no_of_rec       IN NUMBER,                                 -- number of records from TEMP_QUOTAS_HIERARCHY_QUERY
 pout_4_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_10004 ( pi_4_tupr_id            IN tu_periods_range.tupr_id%type ,
                           pi_4_qd_id              IN quota_definitions.qd_iq_tables_id%type ,
                           pi_4_iq_table_name      IN tables.tables_physical_name%type ,
                           pi_4_iq_qe_mapping      IN TABLETYPE_NAME_MAP,
                           pi_4_no_of_rec          IN NUMBER ,
                           pi_4_iq_period_col_name IN table_columns.tc_physical_name%type ,
                           pi_4_no_dist_ent        IN NUMBER ,
                           pout_4_failed_val_no    OUT NUMBER
                         )
AS
  -- use many CLOB variables because the query generated can exceed the maximum number of characters allowed in SELECT (4000)
  v_sql                      CLOB;
  v_join_where               CLOB;
  v_10004_upper_entity_query CLOB;
  v_stamp                   VARCHAR2(250 CHAR);
BEGIN

  SELECT   -- v_sql
           '      '||ac_val.actual_entity_values||' AS TQV_ENTITY_NAME,'|| CHR( 10) ||
           '      '||CASE WHEN actual_rec_no> 1 THEN 'COALESCE('||ac_val.actual_values_col_names||')'
                          ELSE ac_val.actual_values_col_names END || ' AS TQV_ENTITY_VALUE',
           -- v_join_where
           '       LEFT JOIN ' || pi_4_iq_table_name || ' iq ON iq.'|| pi_4_iq_period_col_name || ' = ' || pi_4_tupr_id || CHR(10) ||
           '                                                 AND ('|| h_join_cond.hcond_no_upper || ')' || CHR(10) ||
                   '  -- join with entities in order to obtain entity BK value'|| CHR(10) || ac_val.actual_values_joins_for_h_lu || CHR( 10) ||
           '    WHERE IQ.ROW_IDENTIFIER IS NULL' || CHR(10) ||
           CASE WHEN pi_4_no_dist_ent != 4 -- not one distinct entity
                THEN '       AND hq.TQHQ_LOWER_ENTITY_ID NOT IN (' || h_join_cond.lowest_level_entities || ')'
           END || CHR(10 ) ||
           '       AND ROWNUM<=1000' ,
           -- v_10004_upper_entity_query
           '          ''' ||REPLACE(parent_ent.entity_name, CHR( 39), CHR(39)||CHR(39 ))||'''  AS TQV_ENTITY_NAME,'|| CHR( 10) ||
           '           TO_CHAR(' ||parent_t.tables_physical_name||'.'|| parent_tcbk.tc_physical_name ||') AS TQV_ENTITY_VALUE' || CHR(10) ||
           '      FROM TEMP_QUOTAS_HIERARCHY_QUERY hq' || CHR(10) ||
           '      LEFT JOIN ' ||pi_4_iq_table_name || ' iq ON iq.'|| pi_4_iq_period_col_name || ' = ' || pi_4_tupr_id|| CHR(10) ||
           '                           AND hq.tqhq_upper_value = iq.' || parent_IQ_col.Tc_Physical_Name|| CHR(10 ) ||
           '     LEFT JOIN ' || parent_t.tables_physical_name||' ON '||parent_t.tables_physical_name|| '.e_internal_id = hq.tqhq_upper_value '|| CHR(10) ||
           '                                                    AND hq.tqhq_upper_entity_id = '||parent_ent.entity_id
   INTO v_sql, v_join_where, v_10004_upper_entity_query
   FROM quota_definitions qd
   -- Determine join conditions for the hierarchy
   LEFT  JOIN (SELECT LISTAGG( '(hq.tqhq_lower_entity_id = '|| tc.tc_entity_id || ' AND hq.tqhq_lower_value = iq.' ||tc.tc_physical_name || ')'||CHR(10 )
                                , ' OR ') WITHIN GROUP (ORDER BY 1 ) AS hcond_no_upper,
                      LISTAGG(leaf_entity_id, ',') WITHIN GROUP (ORDER BY 1) AS lowest_level_entities,
                      LISTAGG(qer1.qer_entity_id, ',') WITHIN GROUP (ORDER BY 1) AS parent_entity_id
                 FROM         quota_definitions            qd
                    -- Quota Entities columns
                    INNER JOIN table_columns                tc  ON tc.tc_tables_id = qd.qd_qe_tables_id
                    INNER JOIN table(pi_4_iq_qe_mapping) mp  ON tc.tc_physical_name = mp.name2
                    INNER JOIN entities                     e   ON e.entity_id = tc.tc_entity_id
                    -- Determine the entities that are at the lowest levels in Entity Relationship
                    LEFT  JOIN (SELECT DISTINCT qer.qer_entity_id AS leaf_entity_id
                                      FROM quota_entity_relations qer
                                      WHERE qer.qer_qd_id = pi_4_qd_id
                                        AND CONNECT_BY_ISLEAF=1
                                      START WITH qer.qer_parent_node_id IS NULL
                                      CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
                                ) qer ON e.entity_id = qer.leaf_entity_id
                    LEFT  JOIN quota_entity_relations       qer1 ON qer1.qer_qd_id = qd.qd_id
                                                                 AND qer1.qer_entity_id = e.entity_id
                                                                 AND qer1.qer_level=1
                  WHERE qd.qd_id = pi_4_qd_id
                    -- all the columns from TABLE_COLUMNS that are entities
                    AND tc.tc_entity_id IS NOT NULL
                    -- and don't have a base entity (e.g. they are not upper entities)
                    AND e.entity_base_entity IS NULL
                  ) h_join_cond ON 1 = 1 -- => always 1 row
   LEFT JOIN entities parent_ent on parent_ent.entity_id = h_join_cond.parent_entity_id
   LEFT JOIN tables parent_t on parent_t.tables_id = parent_ent.entity_tables_id
   -- entities Business Key
   LEFT JOIN table_columns parent_tcbk ON parent_tcbk.tc_tables_id = parent_t.tables_id
                                        AND parent_tcbk.tc_logic_type IN (1, 5)
   LEFT JOIN table_columns parent_IQ_col ON parent_IQ_col.tc_tables_id = qd.qd_iq_tables_id
                                        AND parent_IQ_col.Tc_Entity_Id = parent_ent.entity_id
   -- Determine the business key values for the validations that fail
   LEFT JOIN (SELECT LISTAGG('     LEFT JOIN '|| t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = hq.tqhq_lower_value AND hq.tqhq_lower_entity_id = ' ||e.entity_id||CHR(10),' ' )
                         WITHIN GROUP (ORDER BY 1) AS actual_values_joins_for_h_lu,

                     LISTAGG( 'TO_CHAR('||t.tables_physical_name|| '.' || tcbk.tc_physical_name||')' ,',')
                         WITHIN GROUP (ORDER BY 1) AS actual_values_col_names,
                     'CASE '||LISTAGG(' WHEN ' || t.tables_physical_name|| '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN '''|| REPLACE(E.ENTITY_NAME, CHR( 39), CHR(39 )||CHR(39))|| '''',' ' )
                         WITHIN GROUP (ORDER BY 1) || ' END ' AS actual_entity_values,
                     -- used to add or not 'COALESCE' to actual_values_col_names
                     -- If we have distinct entitities than COALESCE should be used to take only the value that is not null
                     COUNT(*) AS actual_rec_no
              FROM       quota_definitions            qd
              INNER JOIN table_columns                tc   ON tc.tc_tables_id = qd.qd_iq_tables_id
              -- Initial Quotas columns
              INNER JOIN table(pi_4_iq_qe_mapping) mp   ON tc.tc_physical_name = mp.name1
              INNER JOIN entities                     e    ON e.entity_id = tc.tc_entity_id
              INNER JOIN tables                       t    ON t.tables_id = e.entity_tables_id
              -- entities Business Key
              INNER JOIN table_columns                tcbk ON tcbk.tc_tables_id = t.tables_id
                                                           AND tcbk.tc_logic_type IN (1, 5)
              WHERE qd.qd_id = pi_4_qd_id ) ac_val ON 1 = 1 -- => always 1 row
   WHERE qd.qd_id = pi_4_qd_id;

  v_sql := 'BEGIN'|| CHR( 10) ||
           'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_IQ_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ENTITY_NAME,TQV_ENTITY_VALUE)' || CHR(10) ||
           'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, d.*' || CHR(10) ||
           'FROM ' || CHR(10 ) ||
           '  (' || CHR(10 ) ||
           '    -- Each upper level instance has a record in the filtered Initial Quotas table' || CHR( 10) ||
           '    -- H-IQ' || CHR(10 ) ||
           '    SELECT /*+ CARDINALITY(hq ' || pi_4_no_of_rec || ') */ DISTINCT NULL AS row_identifier,' || CHR( 10) ||
           '         10004 AS failed_validation,' || CHR(10) ||
                     v_sql || CHR( 10) ||
           '    FROM TEMP_QUOTAS_HIERARCHY_QUERY hq' || CHR(10) ||
                    v_join_where|| CHR( 10) ||
           '    UNION ALL' || CHR(10 ) ||
           '    SELECT /*+ CARDINALITY(hq ' || pi_4_no_of_rec || ') */ DISTINCT NULL AS row_identifier, 10004 AS failed_validation,'|| CHR( 10) ||
                     v_10004_upper_entity_query|| CHR( 10) ||
           '    WHERE hq.TQHQ_upper_ENTITY_ID = hq.tqhq_con_upper_entity_id '|| CHR( 10) ||
           '      AND hq.tqhq_upper_value = hq.tqhq_con_upper_value' || CHR(10) ||
           '      AND IQ.ROW_IDENTIFIER IS NULL ' || CHR(10) ||
           '  ) d'|| CHR(10 ) ||
           'WHERE TQV_ENTITY_VALUE IS NOT NULL'|| CHR(10 ) ||
           '  AND ROWNUM<=1000;'|| CHR(10 ) ||
           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
           'END;';

  v_stamp := 'QUOTAS.VALIDATE_10004 - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),      ',v_sql => <value>' , v_stamp);


  EXECUTE IMMEDIATE v_sql USING OUT pout_4_failed_val_no;
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_4_failed_val_no),',pout_4_failed_val_no => <value>', v_stamp);
END VALIDATE_10004;

-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140912
-- Description: Procedure that validates that organization hierarchy has an instance
--              for each upper entity specified in the entity relationships
--      (http://confluence.optymyze.net/display/SD/Organization+hierarchy+has+an+instance+for+each+upper+entity+specified+in+the+entity+relationships)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_3_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
 pi_3_iq_qe_mapping   IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
 pi_3_no_of_records   IN NUMBER,                                 -- number of records from TMP_IQ_HIERARCHY
 pout_3_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_10003 ( pi_3_tupr_id             IN tu_periods_range.tupr_id%type ,
                           pi_3_qd_id               IN quota_definitions.qd_iq_tables_id%type ,
                           pi_3_iq_table_name       IN VARCHAR2 ,
                           pi_3_iq_period_col_name  IN VARCHAR2 ,
                           pi_3_iq_qe_mapping       IN TABLETYPE_NAME_MAP,
                           pi_3_no_of_records       IN NUMBER ,
                           pout_3_failed_val_no     OUT NUMBER
                         )
AS
  -- use many CLOB variables because the query generated can exceed the maximum number of characters allowed in SELECT (4000)
  v_sql                     CLOB;
  v_join_where              CLOB;
  v_stamp                   VARCHAR2(250 CHAR);
BEGIN

  SELECT  -- v_sql
           '      '||ac_val.actual_entity_values||' AS TQV_ENTITY_NAME,'|| CHR( 10) ||
           '      '||CASE WHEN actual_rec_no> 1 THEN 'COALESCE('||ac_val.actual_values_col_names||')'
                          ELSE ac_val.actual_values_col_names END || ' AS TQV_ENTITY_VALUE',
           -- v_join_where
           '  -- join with entities in order to obtain entity BK value'|| CHR(10) || ac_val.actual_values_joins_for_hierar || CHR( 10) ||
           '    INNER JOIN ' || pi_3_iq_table_name || ' q ON ' || ac_val.iq_join_condition || CHR(10 ) ||
           '    WHERE hq.lower_entity_id IN (' || h_join_cond.lowest_level_entities || ')' || CHR(10) ||
           '       AND NVL(hq.parent_upper_entity_id,1E38) != ' || h_join_cond.parent_entity_id || CHR(10 ) ||
           '       AND ROWNUM<=1000' || CHR(10) ||
           '       AND q.' || pi_3_iq_period_col_name || ' = ' || pi_3_tupr_id
   INTO v_sql, v_join_where
   FROM quota_definitions qd
   -- Determine join conditions for the hierarchy
   LEFT  JOIN (SELECT LISTAGG(leaf_entity_id,',') WITHIN GROUP (ORDER BY 1) AS lowest_level_entities,
                      LISTAGG(qer1.qer_entity_id, ',') WITHIN GROUP (ORDER BY 1) AS parent_entity_id
                 FROM         quota_definitions            qd
                    -- Quota Entities columns
                    INNER JOIN table_columns                tc  ON tc.tc_tables_id = qd.qd_qe_tables_id
                    INNER JOIN table(pi_3_iq_qe_mapping) mp  ON tc.tc_physical_name = mp.name2
                    INNER JOIN entities                     e   ON e.entity_id = tc.tc_entity_id
                    -- Determine the entities that are at the lowest levels in Entity Relationship
                    LEFT  JOIN (SELECT DISTINCT qer.qer_entity_id AS leaf_entity_id
                                      FROM quota_entity_relations qer
                                      WHERE qer.qer_qd_id = pi_3_qd_id
                                        AND CONNECT_BY_ISLEAF=1
                                      START WITH qer.qer_parent_node_id IS NULL
                                      CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
                                ) qer ON e.entity_id = qer.leaf_entity_id
                    LEFT  JOIN quota_entity_relations       qer1 ON qer1.qer_qd_id = qd.qd_id
                                                                 AND qer1.qer_entity_id = e.entity_id
                                                                 AND qer1.qer_level=1
                  WHERE qd.qd_id = pi_3_qd_id
                    -- all the columns from TABLE_COLUMNS that are entities
                    AND tc.tc_entity_id IS NOT NULL
                    -- and don't have a base entity (e.g. they are not upper entities)
                    AND e.entity_base_entity IS NULL
                  ) h_join_cond ON 1 = 1 -- => always 1 row
   -- Determine the business key values for the validations that fail
   LEFT JOIN (SELECT   LISTAGG('     LEFT JOIN '|| t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = hq.lower_value AND hq.lower_entity_id = ' ||e.entity_id||CHR( 10),' ' )
                         WITHIN GROUP (ORDER BY 1) AS actual_values_joins_for_hierar,
                      LISTAGG( ' TO_CHAR('||t.tables_physical_name|| '.' || tcbk.tc_physical_name||')' ,',')
                         WITHIN GROUP (ORDER BY 1) AS actual_values_col_names,
                     'CASE '||LISTAGG(' WHEN ' || t.tables_physical_name|| '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN '''|| REPLACE(E.ENTITY_NAME, CHR( 39), CHR(39 )||CHR(39))|| '''',' ' )
                         WITHIN GROUP (ORDER BY 1) || ' END ' AS actual_entity_values,
                      LISTAGG( '( q.' || tc.tc_physical_name || ' = hq.lower_value AND hq.lower_entity_id = ' ||e.entity_id|| ')' ||CHR(10),' OR ' )
                         WITHIN GROUP (ORDER BY 1) AS iq_join_condition,
                     -- used to add or not 'COALESCE' to actual_values_col_names
                     -- If we have distinct entitities than COALESCE should be used to take only the value that is not null
                     COUNT(*) AS actual_rec_no
              FROM       quota_definitions            qd
              INNER JOIN table_columns                tc   ON tc.tc_tables_id = qd.qd_iq_tables_id
              -- Initial Quotas columns
              INNER JOIN table(pi_3_iq_qe_mapping) mp   ON tc.tc_physical_name = mp.name1
              INNER JOIN entities                     e    ON e.entity_id = tc.tc_entity_id
              INNER JOIN tables                       t    ON t.tables_id = e.entity_tables_id
              -- entities Business Key
              INNER JOIN table_columns                tcbk ON tcbk.tc_tables_id = t.tables_id
                                                           AND tcbk.tc_logic_type IN (1, 5)
              WHERE qd.qd_id = pi_3_qd_id ) ac_val ON 1 = 1 -- => always 1 row
   WHERE qd.qd_id = pi_3_qd_id;


  v_sql := 'BEGIN'|| CHR( 10) ||
           'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_IQ_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ENTITY_NAME,TQV_ENTITY_VALUE)' || CHR(10) ||
           'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, d.*' || CHR(10) ||
           'FROM ' || CHR(10 ) ||
           '  (' || CHR(10 ) ||
           '    -- Organization hierarchy has an instance for each upper entity specified in the entity relationships' || CHR( 10) ||
           '    -- H (branches do not go all the way up)' || CHR(10) ||
                COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'VALIDATE_10003', pi_3_qd_id, null) || chr(10) ||
           '    SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'VALIDATE_10003', pi_3_qd_id, 'CARDINALITY(hq ' || pi_3_no_of_records ||')') || chr(10) ||
           '         DISTINCT NULL AS row_identifier,' || CHR( 10) ||
           '         10003 AS failed_validation,' || CHR(10) ||
                     v_sql || CHR( 10) ||
           '    FROM TMP_IQ_HIERARCHY hq' || CHR(10) ||
                     v_join_where|| CHR( 10) ||
           '  ) d;'|| CHR(10 ) ||
           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
           'END;';
  v_stamp := 'QUOTAS.VALIDATE_10003 - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),      ',v_sql => <value>' , v_stamp);


  EXECUTE IMMEDIATE v_sql USING OUT pout_3_failed_val_no;
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_3_failed_val_no),',pout_3_failed_val_no => <value>', v_stamp);
END VALIDATE_10003;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20170220
-- Description: Procedure that validates there is not an entity with multiple parents (all applicable after effective dated filtering)
-- https://confluence.optymyze.net/display/Quotas/Support+for+effective+dated+organizational+hierarchy
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_10_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
 pi_10_iq_qe_mapping   IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
 pi_10_no_of_records   IN NUMBER,                                 -- number of records from TMP_IQ_HIERARCHY
 pout_10_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_10010 ( pi_10_qd_id               IN quota_definitions.qd_id%type ,
                           pi_10_iq_qe_mapping       IN TABLETYPE_NAME_MAP,
                           pi_10_no_of_records       IN NUMBER ,
                           pout_10_failed_val_no     OUT NUMBER
                         )
AS
  v_sql                     CLOB;
  v_stamp                   VARCHAR2(250 CHAR);
BEGIN
  SELECT  'BEGIN ' || CHR(10) ||
          'INSERT INTO temp_quotas_validations(TQV_ROW_IDENTIFIER, TQV_VALIDATION_ID, TQV_ENTITY_VALUE, TQV_ENTITY_NAME) ' || CHR(10) ||
          -- filter duplicates from hierarchy
          'WITH invalid_rows AS' || chr(10) ||
          '   (SELECT  /*+ CARDINALITY(TMP_IQ_HIERARCHY ' || pi_10_no_of_records || ') */' || chr(10) ||
          '           lower_entity_id, lower_value, COUNT(lower_value)' || chr(10) ||
          '      FROM TMP_IQ_HIERARCHY' || chr(10) ||
          '     GROUP BY lower_entity_id, lower_value' || chr(10) ||
          '    HAVING COUNT(lower_value) > 1)' || chr(10) ||
          'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL,' || chr(10) ||
          '       10010,' || chr(10) ||
          '       COALESCE(' || LISTAGG('TO_CHAR('||t.tables_physical_name|| '.' || tcbk.tc_physical_name||')' ,',')
                                WITHIN GROUP (ORDER BY 1) || ', NULL)  AS TQV_ENTITY_VALUE,' || CHR( 10)||
          'CASE '||LISTAGG(' WHEN ' || t.tables_physical_name|| '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN '''||
                   REPLACE(E.ENTITY_NAME, CHR(39 ), CHR(39)||CHR(39 ))||'''', ' ')
                   WITHIN GROUP (ORDER BY 1) || ' END  AS TQV_ENTITY_NAME' || CHR(10 ) ||
          '  FROM invalid_rows' || chr(10) ||
          '  '|| LISTAGG('     LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = lower_value AND lower_entity_id = ' || tc.tc_entity_id ||CHR(10 ),' ')
                 WITHIN GROUP (ORDER BY 1)  || CHR(10 ) ||
          ' WHERE ROWNUM <= 1000;' || CHR(10) ||
          ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
          'END;'
   INTO v_sql
   FROM quota_definitions           qd
  INNER JOIN table_columns              tc ON tc.tc_tables_id = qd.qd_iq_tables_id
  INNER JOIN TABLE(pi_10_iq_qe_mapping) mp ON mp.name1 = tc.tc_physical_name
  INNER JOIN entities e
     ON e.entity_id = tc.tc_entity_id
  INNER JOIN tables t
     ON t.tables_id = e.entity_tables_id
  INNER JOIN table_columns tcbk
     ON tcbk.tc_tables_id = t.tables_id
    AND tcbk.tc_logic_type IN (1, 5)
  WHERE qd.qd_id = pi_10_qd_id
    AND tc.tc_column_type = 1 ;


  v_stamp := 'QUOTAS.VALIDATE_10010 - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),      ',v_sql => <value>' , v_stamp);


  EXECUTE IMMEDIATE v_sql USING OUT pout_10_failed_val_no;

L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_10_failed_val_no),',pout_1_failed_val_no => <value>', v_stamp);
END VALIDATE_10010;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150119
-- Description: Procedure that the quota hierarchy instances from Initial Quotas are at the lowest level in the quota hierarchy
--              for each upper entity specified in the entity relationships
--      (http://confluence.optymyze.net/pages/viewpage.action?pageId=15696232)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_12_tupr_id            IN tu_periods_range.tupr_id%type           -- the period for which the process is executed
 pi_12_qd_id              IN quota_definitions.qd_id%type,           -- id of the definition
 pi_12_iq_table_name      IN VARCHAR2,                               -- Initial Quotas table name
 pi_12_iq_period_col_name IN VARCHAR2,                               -- period column name from IQ
 pi_12_no_of_records      IN NUMBER,                                 -- number of records from TMP_PRODUCT_HIERARCHY
 pout_12_failed_val_no    OUT NUMBER                                 -- number of rows that failed the validations

*/

-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_10012 ( pi_12_tupr_id             IN  tu_periods_range.tupr_id%type ,
                           pi_12_qd_id               IN  quota_definitions.qd_iq_tables_id%type ,
                           pi_12_iq_table_name       IN  VARCHAR2 ,
                           pi_12_iq_period_col_name  IN  VARCHAR2 ,
                           pi_12_no_of_records       IN  NUMBER ,
                           pout_12_failed_val_no     OUT NUMBER
                         )
AS
  v_sql                     CLOB;
  v_select_condition        CLOB;
  v_no_q_entities_clause    CLOB;
  v_count                   NUMBER(10 );
  v_stamp                   VARCHAR2(250 CHAR);

BEGIN

  SELECT ' LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = iq.' || tc_prod.tc_physical_name || CHR( 10) ||
         '   WHERE NOT EXISTS (SELECT /*+ CARDINALITY(tmp ' || pi_12_no_of_records || ') */ tmp.lower_value FROM tmp_product_hierarchy tmp WHERE tmp.lower_value = iq.' || tc_prod.tc_physical_name || CHR( 10) ||
         '  AND ROWNUM<=1000' || CHR(10 ) ||
         '  AND tmp.lower_entity_id = ' || tc_prod.tc_entity_id || ')' || CHR(10) ||
         '  AND iq.' || pi_12_iq_period_col_name || ' = ' || pi_12_tupr_id ||'', '''' || REPLACE(e.entity_name, CHR( 39), CHR(39)||CHR(39 )) || ''' AS TQV_ENTITY_NAME, ' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ' AS TQV_ENTITY_VALUE from ' || pi_12_iq_table_name || ' iq' ,
         '  INNER JOIN tmp_product_hierarchy tmp on iq.' || tc_prod.tc_physical_name || ' = tmp.lower_value AND tmp.lower_entity_id = ' || tc_prod.tc_entity_id || ' WHERE iq.' || pi_12_iq_period_col_name || ' = ' || pi_12_tupr_id
  INTO v_sql, v_select_condition, v_no_q_entities_clause
  FROM quota_definitions qd
  INNER JOIN tables t_iq
      ON t_iq.tables_id = qd.qd_iq_tables_id
   INNER JOIN table_columns tc_prod
      ON tc_prod.tc_tables_id = t_iq.tables_id
     AND tc_prod.tc_entity_id = qd.qd_multiple_q_entity_id
   INNER JOIN entities e ON e.entity_id = qd.qd_multiple_q_entity_id
   INNER JOIN tables                       t    ON t.tables_id = e.entity_tables_id
   INNER JOIN table_columns                tcbk ON tcbk.tc_tables_id = t.tables_id
                                                AND tcbk.tc_logic_type IN (1, 5)
   WHERE qd.qd_id = pi_12_qd_id;

   EXECUTE IMMEDIATE 'SELECT /*+ CARDINALITY(tmp ' || pi_12_no_of_records ||') */ COUNT(*) FROM ' || pi_12_iq_table_name || ' iq ' || v_no_q_entities_clause INTO v_count;


   IF v_count = 0 THEN
      EXECUTE IMMEDIATE 'BEGIN'|| CHR( 10) ||
                           'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ERROR_MESSAGE)' || CHR(10 ) ||
                           'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) ||
                           '       -20912 AS failed_validation,' || CHR(10) ||
                           '       ''-''' || CHR(10) ||
                           'FROM DUAL;' || CHR(10 ) ||
                           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                           'END;'
        USING OUT pout_12_failed_val_no;
      COMMIT;
      RAISE e_stop_processing;
   END IF;


   v_sql := 'BEGIN'|| CHR(10 ) ||
            'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_IQ_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ENTITY_NAME,TQV_ENTITY_VALUE)' || CHR(10) ||
            'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, d.*' || CHR(10) ||
            'FROM ' || CHR(10 ) ||
            '  (' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'VALIDATE_10012', pi_12_qd_id, null) ||
            '    SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'VALIDATE_10012', pi_12_qd_id, null) ||
            '         DISTINCT NULL AS row_identifier,' || CHR(10) ||
            '         10012 AS failed_validation,' || CHR(10) || v_select_condition || ' ' || v_sql || CHR(10) ||
            '  ) d;'|| CHR(10 ) ||
            ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
            'END;';

  v_stamp := 'QUOTAS.VALIDATE_10012 - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),      ',v_sql => <value>' , v_stamp);

  EXECUTE IMMEDIATE v_sql USING OUT pout_12_failed_val_no;
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_12_failed_val_no),',pout_12_failed_val_no => <value>', v_stamp);

  EXCEPTION
    WHEN e_stop_processing THEN
      pout_12_failed_val_no := pout_12_failed_val_no + 1;
      RAISE e_stop_processing;
END VALIDATE_10012;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150119
-- Description: Procedure that validates that quota hierarchy has an instance
--              for each upper entity specified in the entity relationships
--      (http://confluence.optymyze.net/pages/viewpage.action?pageId=15696232)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_13_tupr_id            IN tu_periods_range.tupr_id%type           -- the period for which the process is executed
 pi_13_qd_id              IN quota_definitions.qd_id%type,           -- id of the definition
 pi_13_iq_table_name      IN VARCHAR2,                               -- Initial Quotas table name
 pi_13_iq_period_col_name IN VARCHAR2,                               -- period column name from IQ
 pi_13_no_of_records      IN NUMBER,                                 -- number of records from TMP_PRODUCT_HIERARCHY
 pout_13_failed_val_no    OUT NUMBER                                 -- number of rows that failed the validations

*/

-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_10013 ( pi_13_tupr_id             IN tu_periods_range.tupr_id%type ,
                           pi_13_qd_id               IN quota_definitions.qd_iq_tables_id%type ,
                           pi_13_iq_table_name       IN VARCHAR2 ,
                           pi_13_iq_period_col_name  IN VARCHAR2 ,
                           pi_13_no_of_records       IN NUMBER ,
                           pout_13_failed_val_no     OUT NUMBER
                         )
AS
  v_sql                     CLOB;
  v_join_where              CLOB;
  v_product_col_name        VARCHAR2(30 CHAR);
  v_stamp                   VARCHAR2(250 CHAR);

BEGIN

  -- get product column name
  SELECT tc_prod.tc_physical_name
    INTO v_product_col_name
    FROM quota_definitions qd
   INNER JOIN tables t_iq
      ON t_iq.tables_id = qd.qd_iq_tables_id
   INNER JOIN table_columns tc_prod
      ON tc_prod.tc_tables_id = t_iq.tables_id
     AND tc_prod.tc_entity_id = qd.qd_multiple_q_entity_id
   WHERE qd.qd_id = pi_13_qd_id;


  SELECT  -- v_sql
           '      '||entity_info.actual_entity_values    ||' AS TQV_ENTITY_NAME,'|| CHR( 10) ||
           '      '||entity_info.actual_values_col_names || ' AS TQV_ENTITY_VALUE',
           -- v_join_where
           '  -- join with entities in order to obtain entity BK value'|| CHR(10) || entity_info.actual_values_joins_for_hierar || CHR(10) ||
           '    INNER JOIN ' || pi_13_iq_table_name || ' q ON ph.lower_value = q.' || v_product_col_name || CHR( 10) ||
           '    WHERE ph.lower_entity_id IN (' || h_join_cond.leaf_entity_id || ')' || CHR(10) ||
           '       AND NVL(ph.parent_upper_entity_id,1E38) != ' || h_join_cond.upper_entity_id || CHR(10 ) ||
           '       AND ROWNUM<=1000' || CHR(10) ||
           '       AND q.' || pi_13_iq_period_col_name || ' = ' || pi_13_tupr_id
   INTO v_sql, v_join_where
   FROM quota_definitions qd
   -- Determine join conditions for the hierarchy
   LEFT  JOIN (SELECT DISTINCT qper.qper_entity_id  AS leaf_entity_id,
                               qper1.qper_entity_id as upper_entity_id
               FROM quotas_prod_ent_relations qper
               CROSS JOIN (SELECT qper.qper_entity_id
                             FROM quotas_prod_ent_relations qper
                            WHERE qper.qper_qd_id = pi_13_qd_id
                              AND qper.qper_level = 1 ) qper1

              WHERE qper.qper_qd_id = pi_13_qd_id
                AND CONNECT_BY_ISLEAF = 1
              START WITH qper.qper_parent_node_id IS NULL
             CONNECT BY PRIOR qper.qper_id = qper.qper_parent_node_id) h_join_cond ON 1 = 1 -- => always 1 row
   -- Determine the business key values for the validations that fail
   LEFT JOIN (SELECT ' LEFT JOIN '|| t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = ph.lower_value AND ph.lower_entity_id = ' ||e.entity_id||CHR( 10)
                   AS actual_values_joins_for_hierar,
                     ' TO_CHAR('||t.tables_physical_name|| '.' || tcbk.tc_physical_name||')'
                   AS actual_values_col_names,
                     ' CASE WHEN '|| t.tables_physical_name|| '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN ''' || REPLACE(E.ENTITY_NAME, CHR(39), CHR(39 )||CHR(39))|| ''' END'
                   AS actual_entity_values
              FROM       quota_definitions            qd
              INNER JOIN entities                     e    ON e.entity_id = qd.qd_multiple_q_entity_id
              INNER JOIN tables                       t    ON t.tables_id = e.entity_tables_id
              INNER JOIN table_columns                tcbk ON tcbk.tc_tables_id = t.tables_id
                                                           AND tcbk.tc_logic_type IN (1, 5)
              WHERE qd.qd_id = pi_13_qd_id ) entity_info ON 1 = 1 -- => always 1 row
   WHERE qd.qd_id = pi_13_qd_id;


   v_sql := 'BEGIN'|| CHR(10 ) ||
            'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_IQ_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ENTITY_NAME,TQV_ENTITY_VALUE)' || CHR(10) ||
            'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, d.*' || CHR(10) ||
            'FROM ' || CHR(10 ) ||
            '  (' || CHR(10 ) ||
            '    -- Quota hierarchy has an instance for each upper entity specified in the entity relationships' || CHR( 10) ||
            '    -- H (branches do not go all the way up)' || CHR(10) ||
                 COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'VALIDATE_10013', pi_13_qd_id, null) ||
            '    SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'VALIDATE_10013', pi_13_qd_id, 'CARDINALITY(ph ' || pi_13_no_of_records ||')') ||
            '         DISTINCT NULL AS row_identifier,' || CHR( 10) ||
            '         10013 AS failed_validation,' || CHR(10) ||
                     v_sql || CHR( 10) ||
            '    FROM TMP_PRODUCT_HIERARCHY ph' || CHR(10) ||
                      v_join_where|| CHR( 10) ||
            '  ) d;'|| CHR(10 ) ||
            ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
            'END;';

   v_stamp := 'QUOTAS.VALIDATE_10013 - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),      ',v_sql => <value>' , v_stamp);


   EXECUTE IMMEDIATE v_sql USING OUT pout_13_failed_val_no;
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_13_failed_val_no),',pout_13_failed_val_no => <value>', v_stamp);


END VALIDATE_10013;



-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140912
-- Description: Procedure that stops the prosess if:
--    -> the Entity Relationships consist of a single distinct entity (top 2 entities are the same with NO additional entity)
--    -> there is no value in Initial Quotas at the lowest levels
--      (http://confluence.optymyze.net/pages/viewpage.action?pageId=8851225)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_vln_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
 pi_vln_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
 pi_vln_iq_table_name   IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
 pi_vln_iq_qe_mapping   IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
 pi_vln_no_of_records   IN NUMBER,                                 -- number of records from TMP_IQ_HIERARCHY
 pout_vln_no_rec_failed OUT NUMBER                                 -- number of records that fail the validation
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_LEAF_NODES_IN_IQ (  pi_vln_tupr_id         IN tu_periods_range.tupr_id%type ,
                                       pi_vln_qd_id           IN quota_definitions.qd_iq_tables_id%type ,
                                       pi_vln_iq_table_name   IN tables.tables_physical_name%type ,
                                       pi_vln_iq_qe_mapping   IN TABLETYPE_NAME_MAP,
                                       pi_vln_no_of_records   IN NUMBER ,
                                       pi_vln_iq_per_col_name IN table_columns.tc_physical_name%type ,
                                       pout_vln_no_rec_failed OUT NUMBER
                                     )
AS
  v_leaf_nodes              CLOB;
  v_cnt                     NUMBER(10 );
BEGIN

  SELECT  --   v_leaf_nodes: all the leaf nodes present in IQ for Emp-Emp hierarchies
           'SELECT /*+ CARDINALITY(hq '|| pi_vln_no_of_records || ') */ COUNT(1)' || CHR(10) ||
           'FROM ' || pi_vln_iq_table_name || ' iq ' || CHR(10) ||
           'INNER JOIN TMP_IQ_HIERARCHY hq ON '|| h_join_cond.hcond_leafs_one_entity || CHR(10 ) ||
           'WHERE leafs=1 ' || CHR(10 ) ||
           '  AND iq.'|| pi_vln_iq_per_col_name || ' = ' || pi_vln_tupr_id || CHR(10 ) ||
           '  AND ROWNUM <= 1' -- should exist at least one record at the lowest level
   INTO v_leaf_nodes
   FROM quota_definitions qd
   -- Determine join conditions for the hierarchy
   LEFT  JOIN (SELECT LISTAGG(CASE WHEN e.entity_id = qer.leaf_entity_id
                                   THEN '(hq.lower_entity_id = ' || tc.tc_entity_id || ' AND hq.lower_value = iq.' ||tc.tc_physical_name || ')' ||CHR(10 )
                              END,' OR ' ) WITHIN GROUP ( ORDER BY 1) AS hcond_leafs_one_entity
                 FROM         quota_definitions            qd
                    -- Quota Entities columns
                    INNER JOIN table_columns                tc  ON tc.tc_tables_id = qd.qd_qe_tables_id
                    INNER JOIN table(pi_vln_iq_qe_mapping) mp  ON tc.tc_physical_name = mp.name2
                    INNER JOIN entities                     e   ON e.entity_id = tc.tc_entity_id
                    -- Determine the entities that are at the lowest levels in Entity Relationship
                    LEFT  JOIN (SELECT DISTINCT qer.qer_entity_id AS leaf_entity_id
                                      FROM quota_entity_relations qer
                                      WHERE qer.qer_qd_id = pi_vln_qd_id
                                        AND CONNECT_BY_ISLEAF=1
                                      START WITH qer.qer_parent_node_id IS NULL
                                      CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
                                ) qer ON e.entity_id = qer.leaf_entity_id
                    LEFT  JOIN quota_entity_relations       qer1 ON qer1.qer_qd_id = qd.qd_id
                                                                 AND qer1.qer_entity_id = e.entity_id
                                                                 AND qer1.qer_level=1
                  WHERE qd.qd_id = pi_vln_qd_id
                    -- all the columns from TABLE_COLUMNS that are entities
                    AND tc.tc_entity_id IS NOT NULL
                    -- and don't have a base entity (e.g. they are not upper entities)
                    AND e.entity_base_entity IS NULL
                  ) h_join_cond ON 1 = 1 -- => always 1 row
   WHERE qd.qd_id = pi_vln_qd_id;

    EXECUTE IMMEDIATE v_leaf_nodes INTO v_cnt;
    --    -> there is no value in Initial Quotas at the lowest levels
    IF v_cnt = 0 THEN
      EXECUTE IMMEDIATE 'BEGIN'|| CHR( 10) ||
                           'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ERROR_MESSAGE)' || CHR(10 ) ||
                           'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) ||
                           '       -20904 AS failed_validation,' || CHR(10) ||
                           '       ''-''' || CHR(10) ||
                           'FROM DUAL;' || CHR(10 ) ||
                           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                           'END;'
        USING OUT pout_vln_no_rec_failed;
      COMMIT;
      RAISE e_stop_processing;
    END IF ;

    EXCEPTION
    WHEN e_stop_processing THEN
      pout_vln_no_rec_failed := pout_vln_no_rec_failed + 1;
      RAISE e_stop_processing;
END VALIDATE_LEAF_NODES_IN_IQ;


-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140912
-- Description: Procedure that validates that there are records in the hierarchy after filtering for the period being run
--      (http://confluence.optymyze.net/display/SD/Filtering+the+organization+hierarchy+for+the+period+being+run)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_vhhr_qd_id           IN quota_definitions.qd_iq_tables_id%type,-- id of the definition
 pi_vhhr_no_of_records   IN NUMBER,                                -- number of records from the hierarchy
 pout_vhhr_no_rec_failed OUT NUMBER                                -- number of records that fail the validation
*/
-----------------------------------------------------------------------------------------
PROCEDURE VALIDATE_HIERARCHY_HAS_RECORDS ( pi_vhhr_qd_id              IN quota_definitions.qd_iq_tables_id%type ,
                                           pi_vhhr_no_of_records      IN NUMBER,
                                           pi_vhhr_hierarchy_type     IN NUMBER,
                                           pi_vhhr_prod_no_of_records IN NUMBER,
                                           pout_vhhr_no_rec_failed    OUT NUMBER
                                          )
AS
  v_sql              CLOB;
  v_stamp            VARCHAR2(250 );

BEGIN
    v_stamp := 'QUOTAS.VALIDATE_HIERARCHY_HAS_RECORDS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    --pout_vhhr_no_rec_failed := 0;
    --  If none of the hierarchy relationship tables have records after filtering, processing stops
    IF CASE WHEN pi_vhhr_hierarchy_type = 1 THEN pi_vhhr_no_of_records = 0               -- the hierarchy has no records => raise ERROR
                                            ELSE pi_vhhr_prod_no_of_records = 0 END THEN -- the product hierarchy has no records => raise ERROR
      SELECT LISTAGG(REPLACE (blo_ent.entity_name,CHR(39), CHR(39)||CHR(39 )) || ' to ' || REPLACE(bhi_ent.entity_name,CHR(39 ), CHR(39)||CHR(39 )),', ') WITHIN GROUP (ORDER BY blo_ent.entity_name || ' to ' || bhi_ent.entity_name)
        INTO v_sql
      FROM         quota_definitions      qd
        INNER JOIN hierarchy_tables       ht      ON ht.ht_id = CASE WHEN pi_vhhr_hierarchy_type = 1 THEN qd.qd_hierarchy_id ELSE qd.qd_product_hierarchy_id END
        INNER JOIN hierarchy_structure    hs      ON hs.hs_ht_id = ht.ht_id
        INNER JOIN hierarchy_relationship hr      ON hr.hr_hs_id = hs.hs_id
        INNER JOIN entities               hi_ent  ON hi_ent.entity_id = hr.hr_higher_entity_id
        INNER JOIN entities               bhi_ent ON bhi_ent.entity_id = hi_ent.entity_base_entity
        INNER JOIN entities               lo_ent  ON lo_ent.entity_id = hr.hr_lower_entity_id
        INNER JOIN entities               blo_ent ON blo_ent.entity_id = lo_ent.entity_base_entity
      WHERE qd.qd_id = pi_vhhr_qd_id;


      EXECUTE IMMEDIATE 'BEGIN'|| CHR( 10) ||
                         'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ERROR_MESSAGE)' || CHR(10 ) ||
                         'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) || CASE WHEN pi_vhhr_hierarchy_type = 1 THEN
                         '       -20903' ELSE
                         '       -20911' END ||
                         '        AS failed_validation,' || CHR(10) ||
                         '       ''' || v_sql || '''' || CHR( 10) ||
                         'FROM DUAL;' || CHR(10 ) ||
                         ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                         'END;'
      USING OUT pout_vhhr_no_rec_failed;
      COMMIT;
      RAISE e_stop_processing;

    ELSE -- check that all hierarchy relationship tables have records after filtering


      v_sql := 'SELECT LISTAGG(REPLACE(blo_ent.entity_name,CHR(39), CHR(39)||CHR(39))||'' to ''|| REPLACE(bhi_ent.entity_name,CHR(39), CHR(39)||CHR(39)), '', '')
                WITHIN GROUP (ORDER BY blo_ent.entity_name||'' to ''|| bhi_ent.entity_name)
                  FROM         quota_definitions      qd
                INNER JOIN hierarchy_tables       ht      ON ht.ht_id = ' || CASE WHEN pi_vhhr_hierarchy_type = 1 THEN 'qd.qd_hierarchy_id' ELSE 'qd.qd_product_hierarchy_id' END || '
                INNER JOIN hierarchy_structure    hs      ON hs.hs_ht_id = ht.ht_id
                INNER JOIN hierarchy_relationship hr      ON hr.hr_hs_id = hs.hs_id
                INNER JOIN entities               hi_ent  ON hi_ent.entity_id = hr.hr_higher_entity_id
                INNER JOIN entities               bhi_ent ON bhi_ent.entity_id = hi_ent.entity_base_entity
                INNER JOIN entities               lo_ent  ON lo_ent.entity_id = hr.hr_lower_entity_id
                INNER JOIN entities               blo_ent ON blo_ent.entity_id = lo_ent.entity_base_entity
                  WHERE qd.qd_id = ' || pi_vhhr_qd_id || '
                AND NOT EXISTS (SELECT 1
                                FROM '   || CASE WHEN pi_vhhr_hierarchy_type = 1 THEN 'TMP_IQ_HIERARCHY hq' ELSE 'TMP_PRODUCT_HIERARCHY ph' END || '
                                WHERE ' || CASE WHEN pi_vhhr_hierarchy_type = 1 THEN 'hq.upper_entity_id = bhi_ent.entity_id
                                                                                  AND hq.lower_entity_id = blo_ent.entity_id'
                                                                                ELSE 'ph.upper_entity_id = bhi_ent.entity_id
                                                                                  AND ph.lower_entity_id = blo_ent.entity_id' END || '
                                )' ;

      EXECUTE IMMEDIATE v_sql INTO v_sql;

      IF v_sql IS NOT NULL THEN
          v_sql := 'BEGIN'|| CHR(10 ) ||
                   'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_IQ_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ENTITY_NAME,TQV_ENTITY_VALUE, TQV_ERROR_MESSAGE)' || CHR(10) ||
                   'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, NULL AS ROW_IDENTIFIER,' || CHR( 10) || CASE WHEN pi_vhhr_hierarchy_type = 1 THEN
                   '       10001' ELSE
                   '       10011' END ||
                   '       AS failed_validation,' || CHR(10) ||
                   '       NULL AS TQV_ENTITY_NAME, NULL AS TQV_ENTITY_VALUE,'|| CHR( 10) ||
                   '       ''' || v_sql || '''' || CHR( 10) ||
                   'FROM DUAL;' || CHR(10 ) ||
                   ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                   'END;';

          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), 'INSERT INTO TEMP_QUOTAS_VALIDATIONS => <value>', v_stamp);
          EXECUTE IMMEDIATE v_sql USING OUT pout_vhhr_no_rec_failed;
      END IF ;

    END IF ;

    EXCEPTION
    WHEN e_stop_processing THEN
      pout_vhhr_no_rec_failed := pout_vhhr_no_rec_failed + 1;
      RAISE e_stop_processing;
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vhhr_no_rec_failed),',pout_vhhr_no_rec_failed => <value>', v_stamp);

END VALIDATE_HIERARCHY_HAS_RECORDS;
-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20140909
-- Description: Procedure to validate that the decimal number for Quota in Initial Quotas does not
--              exceed the decimal number specified in the definition
-- Input Parameters:
/*
   pi_vod_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_vod_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pout_vod_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/

-- Error code : 10007
-- Validation : http://confluence.optymyze.net/display/SD/Quotas+for+hierarchy+entity+instances+do+not+exceed+the+number+of+decimals+to+round+quotas+to
--------------------------------------------------------------------------------------------------
PROCEDURE VALIDATE_NO_OF_DECIMALS(pi_vod_tupr_id           IN TU_PERIODS_RANGE.tupr_id%TYPE
                                 ,pi_vod_qd_id             IN QUOTA_DEFINITIONS.qd_id%TYPE
                                 ,pi_vod_field_mapping     IN TABLETYPE_ID_ID
                                 ,pi_vod_hierarchy_mapping IN TABLETYPE_ID_ID
                                 ,pi_vod_import_query      IN CLOB
                                 ,pout_vod_failed_val_no   OUT NUMBER)
IS
v_sql                     CLOB;
v_iq_table_name           VARCHAR2(30 CHAR );
v_iq_period_col_name      VARCHAR2(30 CHAR);
v_col_list                CLOB;
v_values_list             CLOB;
v_join_conditions         CLOB;
v_no_of_decimals          NUMBER(3);
v_stamp                   VARCHAR2(250 CHAR);
v_quota_planning_col_name VARCHAR2(30 CHAR);

BEGIN
  v_stamp := 'QUOTAS.VALIDATE_NO_OF_DECIMALS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');


  -- get Initial Quotas table name and period column name
  SELECT t.tables_physical_name, tc.tc_physical_name
    INTO v_iq_table_name, v_iq_period_col_name
    FROM tables t
   INNER JOIN table_columns tc
      ON t.tables_id = tc.tc_tables_id
   INNER JOIN quota_definitions qd
      ON qd.qd_iq_tables_id = t.tables_id
   WHERE qd.qd_id = pi_vod_qd_id
     AND tc.tc_logic_type = 8 ;

  SELECT qd.qd_no_of_decimals
    INTO v_no_of_decimals
    FROM quota_definitions qd
   WHERE qd_id = pi_vod_qd_id;

   IF pi_vod_field_mapping IS NOT NULL THEN

     SELECT f_right.fld_column_name
       INTO v_quota_planning_col_name
       FROM table(pi_vod_field_mapping) fld_map
      INNER JOIN fields f_left
         ON fld_map.id1 = f_left.fld_id
       LEFT JOIN fields f_right
         ON fld_map.id2 = f_right.fld_id
      WHERE f_left.fld_column_name = 'QUOTA';
  END IF;


  FOR c IN (SELECT tc.tc_physical_name,
                   e.entity_name,
                   t.tables_physical_name AS tp,
                   tc_et.tc_physical_name AS et,
                   a.tu_name
              FROM table_columns tc
              LEFT JOIN entities e
               ON tc.tc_entity_id = e.entity_id
              LEFT JOIN tables t
                ON t.tables_id = e.entity_tables_id
              LEFT JOIN table_columns tc_et
                ON tc_et.tc_tables_id = e.entity_tables_id
               AND tc_et.tc_logic_type IN (1, 5)
             CROSS JOIN (SELECT tu_name
                          FROM time_units tu
                         INNER JOIN tu_periods_range tupr
                            ON tupr.tupr_tu_id = tu.tu_id
                           AND tupr.tupr_id = pi_vod_tupr_id) a
             WHERE tc.tc_tables_id = (SELECT qd.qd_iq_tables_id FROM quota_definitions qd WHERE qd.qd_id = pi_vod_qd_id)
               AND (tc.tc_column_type = 1 OR tc.tc_logic_type = 8)
             ORDER BY tc.tc_order) LOOP

    v_join_conditions := CASE WHEN c.entity_name IS NOT NULL THEN
                         v_join_conditions || ' LEFT JOIN ' || c.tp || ' ' || c.tp ||'
                                                ON iq.' || c.tc_physical_name || ' = ' || c.tp ||'.e_internal_id ' END;
    v_values_list := CASE WHEN c.entity_name IS NOT NULL THEN v_values_list || '||'';''||' || c.tp ||'.' || c.et END;
    v_col_list := v_col_list || '; ' || COALESCE(REPLACE(c.entity_name,CHR(39 ), CHR(39)||CHR( 39)), c.tu_name);

  END LOOP;

  v_values_list := SUBSTR(v_values_list, 8, LENGTH( v_values_list));
  v_col_list := SUBSTR(v_col_list, 3, LENGTH(v_col_list));



  -- insert invalid rows from Initial Quotas
  v_sql :=
  'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER
      ,TQV_VALIDATION_ID
      ,TQV_IQ_ROW_IDENTIFIER
      ,TQV_ENTITY_NAME
      ,TQV_ENTITY_VALUE
      ,TQV_ERROR_MESSAGE
      ,TQV_RECORD_COUNT)

    SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.nextval, 10007, NULL, NULL, NULL, invalid_rows.value_list, NULL
    FROM
    (SELECT ''' || REPLACE(QUOTAS.GET_PERIOD_NAME(pi_vod_tupr_id), CHR(39), CHR(39)||CHR(39 )) ||'''||'';''|| ' || v_values_list || ' value_list ' || chr(10)||
     ' FROM ' || CASE WHEN pi_vod_import_query IS NULL THEN v_iq_table_name ELSE '(' || pi_vod_import_query || ')' END || ' iq
     ' || v_join_conditions || '
     WHERE iq.' || v_iq_period_col_name || ' = ' || pi_vod_tupr_id || '
     GROUP BY
     ''' || REPLACE(QUOTAS.GET_PERIOD_NAME(pi_vod_tupr_id), CHR( 39), CHR(39)||CHR(39 )) ||'''||'';''|| ' || v_values_list || '
     HAVING MAX(LENGTH(TO_CHAR(MOD(ABS(iq.' || CASE WHEN pi_vod_field_mapping IS NOT NULL THEN v_quota_planning_col_name ELSE ' QUOTA' END || '), 1))) - 1) > ' || v_no_of_decimals || '
     ) invalid_rows WHERE rownum <= 1000' ;

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), 'INSERT INTO TEMP_QUOTAS_VALIDATIONS => <value>', v_stamp);


  IF pi_vod_hierarchy_mapping IS NOT NULL THEN
    EXECUTE IMMEDIATE v_sql USING IN pi_vod_hierarchy_mapping;
  ELSE
    EXECUTE IMMEDIATE v_sql;
  END IF;
  -- insert entity ids and number of failed records
  IF SQL%ROWCOUNT != 0 THEN
    v_sql := 'UPDATE TEMP_QUOTAS_VALIDATIONS SET TQV_RECORD_COUNT = ' || SQL%ROWCOUNT   || ' WHERE TQV_VALIDATION_ID = 10007';
    EXECUTE IMMEDIATE v_sql;

    v_sql :=
    'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER
        ,TQV_VALIDATION_ID
        ,TQV_IQ_ROW_IDENTIFIER
        ,TQV_ENTITY_NAME
        ,TQV_ENTITY_VALUE
        ,TQV_ERROR_MESSAGE
        ,TQV_RECORD_COUNT) VALUES (TEMP_QUOTAS_VALIDATIONS_SEQ.nextval, 10007, null, null, null, ''' || v_col_list || ''', ' || SQL %ROWCOUNT || ')';

    pout_vod_failed_val_no := SQL%ROWCOUNT ;
    EXECUTE IMMEDIATE v_sql;
  END IF;
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vod_failed_val_no),',pout_vod_failed_val_no => <value>', v_stamp);

END VALIDATE_NO_OF_DECIMALS;


-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20140909
-- Description: Procedure to validate quota entity instances for the hierarchy entity instances
-- Input Parameters:
/*
   pi_vqe_tupr_id             IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_vqe_qd_id               IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pi_vqe_iq_table_name       IN tables.tables_physical_name%type        -- the name if the IQ tabe
   pi_vqe_iq_entity_col_names IN TABLETYPE_NAME_MAP                      -- mapping between the IQ columns
                                                                            and Quota Entities columns
                                                                            (only used for IQ columns in this case)
   pout_vqe_failed_val_no     OUT NUMBER                                 -- number of rows that failed the validations
*/

-- Error code : 10006
-- Validation : http://confluence.optymyze.net/display/SD/Quota+entity+instances+for+the+hierarchy+entity+instances+in+the+filtered+Initial+Quotas+table+are+valid
--------------------------------------------------------------------------------------------------

PROCEDURE VALIDATE_QUOTA_ENTITIES(pi_vqe_tupr_id             IN TU_PERIODS_RANGE.tupr_id%TYPE ,
                                  pi_vqe_qd_id               IN QUOTA_DEFINITIONS.qd_id%TYPE ,
                                  pi_vqe_iq_table_name       IN tables.tables_physical_name%TYPE ,
                                  pi_vqe_iq_entity_col_names IN TABLETYPE_NAME_MAP,
                                  pi_vqe_h_no_of_rec         IN NUMBER ,
                                  pout_vqe_failed_val_no OUT NUMBER )
AS
  v_upper_join        CLOB;
  v_lower_join        CLOB;
  v_entity_table_join CLOB;
  v_sql               CLOB;
  v_entity_type       CLOB;
  v_entity_value      CLOB;
  v_iq_values         CLOB;
  v_prod_col_name     VARCHAR2(30 CHAR);
  v_prod_entity_table VARCHAR2(30 CHAR);
  v_prod_entity_id    VARCHAR2(30 CHAR);
  v_period_col_name   VARCHAR2(30 CHAR);
  v_entity_name       VARCHAR2(30 CHAR);
  v_stamp             VARCHAR2(250 );
begin
    v_stamp := 'QUOTAS.VALIDATE_QUOTA_ENTITIES - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

  -- period column name from IQ
    SELECT tc.tc_physical_name,
           tc_prod.tc_physical_name      iq_prod_col_name,
           t_prod.tables_physical_name   prod_entity_table,
           tc_prod_e_id.tc_physical_name prod_entity_id,
           e_prod.entity_name
      INTO v_period_col_name,
          v_prod_col_name, v_prod_entity_table, v_prod_entity_id, v_entity_name
      FROM tables t
     INNER JOIN quota_definitions qd
        ON t.tables_id = qd.qd_iq_tables_id
     INNER JOIN table_columns tc
        ON t.tables_id = tc.tc_tables_id AND tc.tc_logic_type = 8
      -- join with table columns to get product column name
     INNER JOIN table_columns tc_prod
      ON tc_prod.tc_entity_id = qd.qd_multiple_q_entity_id
      AND tc_prod.tc_tables_id = qd.qd_adj_tables_id
      AND tc_prod.tc_column_type = 1
      -- join with entities to get product entity
      INNER JOIN entities e_prod
        ON e_prod.entity_id = tc_prod.tc_entity_id
      -- join with tables to get product entity table
      INNER JOIN tables t_prod
        ON e_prod.entity_tables_id = t_prod.tables_id
      -- join with table columns to get product entity table business key column
      INNER JOIN table_columns tc_prod_e_id
        ON tc_prod_e_id.tc_tables_id = t_prod.tables_id
      AND tc_prod_e_id.tc_logic_type IN (1, 5)
      WHERE qd.qd_id = pi_vqe_qd_id;

    -- get info -- Initial Quotas column names, entity id, entity table physical names, Initial Quotas product col name,
    --             product entity table name, prod entity id, prod entity values

    FOR c IN (SELECT tc.tc_physical_name           iq_col_name,
                     tc.tc_entity_id,
                     t_et.tables_physical_name     entity_table,
                     tc_et.tc_physical_name        entity_col
                FROM quota_definitions qd
               INNER JOIN tables t
                  ON qd.qd_iq_tables_id = t.tables_id
               INNER JOIN table_columns tc
                  ON tc.tc_tables_id = t.tables_id
               -- join with Initial Quotas column names
               INNER JOIN table(pi_vqe_iq_entity_col_names) iq_cols
                  ON iq_cols.name1 = tc.tc_physical_name
               -- join with entities
               INNER JOIN entities e
                  ON e.entity_id = tc.tc_entity_id
               -- join with tables to get entity tables name
               INNER JOIN tables t_et
                  ON t_et.tables_id = e.entity_tables_id
               -- join with table columns to get entity tables business key column
               INNER JOIN table_columns tc_et
                  ON tc_et.tc_tables_id = t_et.tables_id
                 AND tc_et.tc_logic_type IN (1, 5)
                WHERE qd.qd_id = pi_vqe_qd_id) LOOP

      -- build join conditions
      v_upper_join        := v_upper_join || '(iq.' || c.iq_col_name || ' = t1.upper_value AND t1.upper_entity_id = ' || c.tc_entity_id || ') OR ';
      v_lower_join        := v_lower_join || '(iq.' || c.iq_col_name || ' = t1.lower_value AND t1.lower_entity_id = ' || c.tc_entity_id || ') OR ';
      v_entity_table_join := v_entity_table_join || ' LEFT JOIN ' || c.entity_table || ' ON ' ||c.entity_table ||'.e_internal_id = a.entity_value AND a.entity_type = ' || c.tc_entity_id || ' ';
      v_entity_type       := v_entity_type || ' WHEN iq.' || c.iq_col_name || ' IS NOT NULL THEN '   || c.tc_entity_id || ' ';
      v_entity_value      := v_entity_value || 'to_char(iq.'||c.iq_col_name||'),' ;

      -- build Initial Quotas column names list -- business key columns
      v_iq_values         := v_iq_values || ', TO_CHAR(' || c.entity_table || '.' || c.entity_col || ')' ;

    end loop ;

    v_iq_values  := SUBSTR(v_iq_values, 3, LENGTH(v_iq_values));
    v_upper_join := SUBSTR(v_upper_join, 1, LENGTH(v_upper_join) - 3 );
    v_lower_join := SUBSTR(v_lower_join, 1, LENGTH(v_lower_join) - 3 );

    v_sql := 'INSERT INTO temp_quotas_validations(TQV_ROW_IDENTIFIER,
                                                 TQV_VALIDATION_ID,
                                                 TQV_IQ_ROW_IDENTIFIER,
                                                 TQV_ENTITY_NAME,
                                                 TQV_ENTITY_VALUE,
                                                 TQV_ERROR_MESSAGE,
                                                 TQV_RECORD_COUNT
                                                 )
            WITH parents AS
               (SELECT /*+ CARDINALITY(t1 ' || pi_vqe_h_no_of_rec || ') */ DISTINCT upper_entity_id, upper_value, iq.row_identifier, iq.'||v_prod_col_name|| ' as product_id,
                       COALESCE(' ||v_entity_value||' NULL) as entity_value,
                       CASE ' || v_entity_type || '
                       END AS entity_type
                FROM TMP_IQ_HIERARCHY t1
                LEFT JOIN ' || pi_vqe_iq_table_name || ' iq ON ( ' || v_upper_join || '
                                        )
                                        AND iq.' || v_period_col_name || ' = ' || pi_vqe_tupr_id || '
               ),
             children as
             (SELECT /*+ CARDINALITY(t1 ' || pi_vqe_h_no_of_rec || ') */ DISTINCT upper_entity_id, upper_value,
                       lower_entity_id, lower_value, iq.row_identifier, iq.'||v_prod_col_name|| '  as product_id,
                       COALESCE(' ||v_entity_value||' NULL) as entity_value,
                       CASE ' || v_entity_type || '
                       END AS entity_type
                FROM TMP_IQ_HIERARCHY t1
                LEFT JOIN ' || pi_vqe_iq_table_name || ' iq ON ( ' || v_lower_join || '
                                           )
                                        AND ' || v_period_col_name || ' = ' || pi_vqe_tupr_id || '
               )
      SELECT temp_quotas_validations_seq.nextval, 10006, row_identifier, entity_value, entity_type, product, NULL
      FROM
        (SELECT DISTINCT a.row_identifier, e_up.entity_name AS entity_value, COALESCE(' || v_iq_values || ',null) AS entity_type, ' || v_prod_entity_table || '.' ||v_prod_entity_id || ' || '' (' || REPLACE (v_entity_name, CHR(39), CHR(39)||CHR(39 )) || ')'' as product
        FROM
            (SELECT row_identifier, entity_value, entity_type, product_id
            FROM children c
            WHERE NOT EXISTS (SELECT 1
                              FROM parents p
                              WHERE c.upper_entity_id = p.upper_entity_id
                                    AND c.upper_value = p.upper_value
                                    AND c.product_id = p.product_id)
              AND row_identifier > 0
              AND rownum<=1000
            UNION ALL
            SELECT row_identifier, entity_value, entity_type, product_id
            FROM parents c
            WHERE NOT EXISTS (SELECT 1
                              FROM children p
                              WHERE c.upper_entity_id = p.upper_entity_id
                                    AND c.upper_value = p.upper_value
                                    AND c.product_id = p.product_id)
              AND row_identifier > 0
              AND rownum<=1000
            ) a
          ' || v_entity_table_join || '
          LEFT JOIN entities e_up ON a.entity_type = e_up.entity_id
          LEFT JOIN ' || v_prod_entity_table ||' ON ' || v_prod_entity_table || '.e_internal_id = a.product_id  -- products table
        WHERE rownum<=1000) b' ;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), 'INSERT INTO TEMP_QUOTAS_VALIDATIONS => <value>', v_stamp);


    EXECUTE IMMEDIATE v_sql;
    pout_vqe_failed_val_no := SQL%ROWCOUNT ;
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vqe_failed_val_no),',pout_vqe_failed_val_no => <value>', v_stamp);

END VALIDATE_QUOTA_ENTITIES;




-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20140923
-- Description: Procedure to validate user assignments
-- Input Parameters:
/*
   pi_vua_tupr_id             IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_vua_qd_id               IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pi_vua_iq_entity_col_names IN TABLETYPE_NAME_MAP                      -- mapping between the IQ columns
                                                                            and Quota Entities columns
   pi_vua_user_assign_queries IN TABLETYPE_QUOTAS_QUERY_MAP              -- user assignment queries
   pout_vqe_failed_val_no     OUT NUMBER                                 -- number of rows that failed the validations
*/

-- Error codes : 10008 : http://confluence.optymyze.net/display/SD/Filtering+the+assignment+tables+for+the+period+being+run
--               10009 : http://confluence.optymyze.net/display/SD/Each+hierarchy+entity+instance+has+only+one+corresponding+user+entity+instance
--               10010 : http://confluence.optymyze.net/display/SD/Multiple+hierarchy+entity+instances+are+not+assigned+to+the+same+user+entity+instance
--              -20905 : http://confluence.optymyze.net/display/SD/Filtering+the+assignment+tables+for+the+period+being+run
--------------------------------------------------------------------------------------------------


PROCEDURE VALIDATE_USER_ASSIGNMENTS(pi_vua_tupr_id             IN TU_PERIODS_RANGE.tupr_id%TYPE
                                   ,pi_vua_qd_id               IN QUOTA_DEFINITIONS.qd_id%TYPE
                                   ,pi_vua_iq_entity_col_names IN TABLETYPE_NAME_MAP
                                   ,pi_vua_user_assign_queries IN TABLETYPE_QUOTAS_QUERY_MAP
                                   ,pout_vua_failed_val_no     OUT NUMBER)
AS
v_assignt_no_records_v         CLOB;
v_hinst_more_ue_v              CLOB;
v_query                        CLOB;
v_test                         VARCHAR2(250 CHAR);
v_failed_row_no                NUMBER(10 ) := 0;
v_temp_count                   NUMBER(10 ) := 0;
v_second_query                 CLOB;

v_user_cond                    VARCHAR2(250 CHAR);
v_uc_cond                      VARCHAR2(250 CHAR);

BEGIN


 -- determine columns from Initial Qotas, entity assign table name, entity names for org and user, Initial Quotas table name
    IF pi_vua_user_assign_queries.COUNT != 0 THEN

     FOR i IN (SELECT p.name1                       col_name,
                     q.query,
                     ea.ea_name,
                     ea.ea_id,
                     e_org.entity_name             AS e_org,
                     e_user.entity_name            AS e_user,
                     iq_table.tables_physical_name,
                     iq_table.tc_physical_name,
                     tc_et.tc_physical_name        AS e_table_bk_col,
                     t_et.tables_physical_name     AS e_table_name,
                     tc_user.tc_physical_name      AS tc_user,
                     tc.tc_physical_name           AS tc_org,
                     CASE WHEN ea.ea_entity_id_la = e_org.entity_id THEN 'LEFT_ENTITY_COL'
                          ELSE 'RIGHT_ENTITY_COL' END AS org_cond,
                     CASE WHEN ea.ea_entity_id_la != e_org.entity_id THEN 'LEFT_ENTITY_COL'
                          ELSE 'RIGHT_ENTITY_COL' END AS user_cond,
                     CASE WHEN ea.ea_entity_id_la != e_org.entity_id THEN 'ea_entity_id_la'
                          ELSE 'sa_entity_id' END AS uc_cond,
                     CASE WHEN ea.ea_entity_id_la = e_org.entity_id THEN 'ea_entity_id_la'
                          ELSE 'sa_entity_id' END AS og_cond
                FROM quota_definitions qd
               INNER JOIN table_columns tc
                  ON qd.qd_iq_tables_id = tc.tc_tables_id
                 AND qd.qd_id = pi_vua_qd_id
               INNER JOIN TABLE(pi_vua_iq_entity_col_names) p
                  ON p.name1 = tc.tc_physical_name
               INNER JOIN entities e_org
                  ON tc.tc_entity_id = e_org.entity_id

               INNER JOIN entity_assignments ea
                  ON ea.ea_entity_id_la = e_org.entity_id or  e_org.entity_id = (select sa.sa_entity_id from secondary_assignments sa where sa.sa_ea_id = ea.ea_id)
               INNER JOIN TABLE(pi_vua_user_assign_queries) q
                  ON ea.ea_id = q.object_id
              INNER JOIN table_columns tc_user
                  ON tc_user.tc_tables_id = ea.ea_tables_id
                    -- from assignment table -- type entity and different from org entity => user entity
                 AND tc_user.tc_column_type = 1
                 AND tc_user.tc_physical_name != p.name1
              -- entity name for user entity
               INNER JOIN entities e_user
                  ON tc_user.tc_entity_id = e_user.entity_id
              -- only one row -- Initial Quotas table name, Initial Quotas period column name
               CROSS JOIN (SELECT tc.tc_physical_name, tables_physical_name
                            FROM TABLES t
                           INNER JOIN quota_definitions qd
                              ON qd.qd_iq_tables_id = t.tables_id
                           INNER JOIN table_columns tc
                              ON tc.tc_tables_id = t.tables_id
                             AND tc.tc_logic_type = 8
                           WHERE qd.qd_id = pi_vua_qd_id) iq_table
              -- entity table business key column , entity table name
               INNER JOIN table_columns tc_et
                  ON tc_et.tc_tables_id = e_org.entity_tables_id
               INNER JOIN tables t_et
                  ON tc_et.tc_tables_id = t_et.tables_id
               INNER JOIN table_columns tc_et_user
                  ON tc_et_user.tc_tables_id = e_user.entity_tables_id
               INNER JOIN tables t_et_user
                  ON tc_et_user.tc_tables_id = t_et_user.tables_id
               WHERE tc_et_user.tc_logic_type IN (1, 5)
                 AND tc_et.tc_logic_type IN (1, 5)
               ORDER BY ea.ea_name --  the assignment tables are listed in alphabetical order
        ) LOOP

        v_user_cond := i.user_cond;
        v_uc_cond := i.uc_cond;

        --------------------------------------
        -- for Validation 1.2 and 3
        --------------------------------------

        v_query := v_query || ' SELECT DISTINCT ' || i.user_cond || ' as entx, ' || i.org_cond || ',
                       a.' || i.uc_cond || ' ent
                FROM (' || REPLACE(i.query, 'SELECT', 'SELECT DISTINCT' ) || ') t CROSS JOIN
                (SELECT ' || i.uc_cond || ' FROM entity_assignments ea
                   INNER JOIN secondary_assignments sa ON ea.ea_id = sa.sa_ea_id
                   WHERE ea_id = ' || i.ea_id ||'
                ) a
                 INNER JOIN ' || i.tables_physical_name || ' iq
                  ON iq.' || i.col_name || ' = LEFT_ENTITY_COL
                WHERE iq.' || i.tc_physical_name ||' = ' || pi_vua_tupr_id || '
                UNION ALL ' ;

        -- ***************************************************************************************************************************
        -- VALIDATION 1.1 - If one or more assignment tables have no records after filtering, processing fails but will still continue.
        -- ***************************************************************************************************************************
        -- determine assignment tables that are empty after filtering
        BEGIN

          v_second_query := 'SELECT 1 FROM (' || i.query || ') at WHERE ROWNUM <= 1';
          execute immediate v_second_query into v_test;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_assignt_no_records_v := v_assignt_no_records_v || ', ' || i.ea_name;
        END;

        v_second_query := v_second_query || ' union all ';
       -- **********************************************************************************************
       -- VALIDATION 2 - Each hierarchy entity instance has only one corresponding user entity instance
       -- **********************************************************************************************
       SELECT COUNT (TQV_ROW_IDENTIFIER) INTO v_temp_count FROM TEMP_QUOTAS_VALIDATIONS WHERE TQV_VALIDATION_ID = 10009;
       v_hinst_more_ue_v :=
                        'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER
                         ,TQV_VALIDATION_ID
                         ,TQV_IQ_ROW_IDENTIFIER
                         ,TQV_ENTITY_NAME
                         ,TQV_ENTITY_VALUE
                         ,TQV_ERROR_MESSAGE
                         ,TQV_RECORD_COUNT
                        )
                        SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, 10009, NULL, '''|| REPLACE(i.e_org, CHR( 39), CHR(39 )||CHR(39)) || ''', ' || i.e_table_bk_col ||', NULL, NULL FROM
                        (SELECT DISTINCT et.' || i.e_table_bk_col || ' FROM ' || i.tables_physical_name || ' iq
                        INNER JOIN (SELECT at.' || i.org_cond || ' FROM
                                    (' || i.query || ') at
                                        HAVING COUNT(at.' || i.org_cond || ') != 1
                                        GROUP BY at.' || i.org_cond || '
                                    ) assign_q
                          ON iq.' || i.col_name || ' = assign_q.' || i.org_cond || '
                        -- join with entity table to get the entity name based on internal id
                        INNER JOIN ' || i.e_table_name || ' et
                          ON et.E_INTERNAL_ID = iq.' || i.col_name || ' WHERE iq. '|| i.tc_physical_name || ' = ' || pi_vua_tupr_id ||')
                        WHERE ROWNUM <= (1000 - ' || v_temp_count || ')';

        EXECUTE IMMEDIATE v_hinst_more_ue_v;
        v_failed_row_no := v_failed_row_no + SQL%ROWCOUNT ;
      END LOOP ;

      -- ************************************************************************************************************************
      -- VALIDATION 1.2 - If all of the assignment tables have no records after filtering, processing fails and will not continue.
      -- ************************************************************************************************************************
      v_assignt_no_records_v := SUBSTR(v_assignt_no_records_v, 3, LENGTH(v_assignt_no_records_v));

      BEGIN


       EXECUTE IMMEDIATE 'SELECT 1 FROM (' || SUBSTR(v_second_query, 1, LENGTH(v_second_query) - 10 ) || ') at WHERE ROWNUM <= 1' INTO v_test;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            EXECUTE IMMEDIATE   'DELETE FROM TEMP_QUOTAS_VALIDATIONS WHERE TQV_VALIDATION_ID = 10009';
            EXECUTE IMMEDIATE   'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,TQV_VALIDATION_ID,TQV_ERROR_MESSAGE)
                                SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, -20905, ''' || v_assignt_no_records_v || '''
                                FROM DUAL' ;
            COMMIT;
            RAISE e_stop_processing;
      END;


      IF v_assignt_no_records_v IS NOT NULL THEN
        v_assignt_no_records_v := 'INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER
                       ,TQV_VALIDATION_ID
                       ,TQV_IQ_ROW_IDENTIFIER
                       ,TQV_ENTITY_NAME
                       ,TQV_ENTITY_VALUE
                       ,TQV_ERROR_MESSAGE
                      ) SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, 10008, null, null, null, ''' ||  REPLACE(v_assignt_no_records_v, CHR(39), CHR(39 )||CHR(39)) || ''' FROM DUAL' ;

      EXECUTE IMMEDIATE v_assignt_no_records_v;
      v_failed_row_no := v_failed_row_no + SQL%ROWCOUNT ;
      END IF ;


  END IF;
  pout_vua_failed_val_no := v_failed_row_no;



  EXCEPTION
    WHEN e_stop_processing THEN
      pout_vua_failed_val_no := pout_vua_failed_val_no + 1;
      RAISE e_stop_processing;
END VALIDATE_USER_ASSIGNMENTS;


-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20160316
-- Description: Procedure to validate that the decimal number for additional fields from IQ does not
--              exceed the decimal number specified for that field
-- Input Parameters:
/*
   pi_vfd_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_vfd_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pi_vfd_iq_q_mapping
   pi_vfd_calling_process                                            -- 1 = Load Initial Quotas, 2 = Calculate Additional Info
   pfut_vod_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/

-- Error code : 10025
-- Validation : http://confluence.optymyze.net/display/Quotas/Calculated+additional+quota+fields+-+Impact+on+Initial+Quota+Load+Process
--------------------------------------------------------------------------------------------------
PROCEDURE VALIDATE_FIELD_DECIMALS(pi_vfd_tupr_id           IN TU_PERIODS_RANGE.tupr_id%TYPE
                                 ,pi_vfd_qd_id             IN QUOTA_DEFINITIONS.qd_id%TYPE
                                 ,pi_vfd_iq_q_mapping      IN tabletype_name_map
                                 ,pi_vfd_calling_process   IN NUMBER
                                 ,pi_vfd_field_mapping     IN TABLETYPE_ID_ID
                                 ,pi_vfd_hierarchy_mapping IN TABLETYPE_ID_ID
                                 ,pi_vfd_import_query      IN CLOB
                                 ,pi_vfd_field_data_type   IN NUMBER -- 1 - numberic, 2 - character
                                 ,pout_vfd_failed_val_no   OUT NUMBER )
IS
  v_sql                         CLOB;
  v_entity_table_join           CLOB;
  v_entity_name_clause          CLOB;
  v_entity_bk_list              CLOB;
  v_simple_bk_list              CLOB;
  v_iq_q_join_condition         CLOB;
  v_add_fields_col              CLOB;

  v_stamp                       VARCHAR2(250 CHAR);
  v_quotas_table_id             NUMBER(10);
  v_quotas_table_name           VARCHAR2(30 CHAR);
  v_iq_table_name               VARCHAR2(30 CHAR);
  v_period_column_name          VARCHAR2(30 CHAR);
  v_product_column_name         VARCHAR2(30 CHAR);

  v_prod_entity_table           VARCHAR2(30 CHAR);
  v_prod_entity_bk_col          VARCHAR2(30 CHAR);
  v_prod_entity_name            VARCHAR2(30 CHAR);
BEGIN



  v_stamp := 'QUOTAS.VALIDATE_FIELD_DECIMALS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

  SELECT LISTAGG(' LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = q.' || tc.tc_physical_name, ' ')
   WITHIN GROUP (ORDER BY 1) AS entity_table_join,
         LISTAGG( ' WHEN ' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN ''' || REPLACE(e.entity_name, CHR(39 ), CHR(39)||CHR( 39)) || '''' , ' ')
   WITHIN GROUP (ORDER BY 1) AS entity_name_clause,
         LISTAGG( 'TO_CHAR(' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ')' , ', ')
   WITHIN GROUP (ORDER BY 1) AS entity_bk_list,
         LISTAGG( 'q.' || mp.name1 || ' = iq.' || mp.name2 , ' OR ')
   WITHIN GROUP (ORDER BY 1) AS entity_bk_list,
         LISTAGG(t.tables_physical_name || '.' || tcbk.tc_physical_name , ', ')
   WITHIN GROUP (ORDER BY 1) AS simple_entity_bk_list
      INTO v_entity_table_join, v_entity_name_clause, v_entity_bk_list, v_iq_q_join_condition, v_simple_bk_list
      FROM quota_definitions qd
     INNER JOIN table_columns tc           ON tc.tc_tables_id = qd.qd_adj_tables_id
     INNER JOIN TABLE(pi_vfd_iq_q_mapping) mp ON tc.tc_physical_name = mp.name1
     INNER JOIN entities e                 ON e.entity_id = tc.tc_entity_id
     INNER JOIN tables t                   ON t.tables_id = e.entity_tables_id
     INNER JOIN table_columns tcbk         ON tcbk.tc_tables_id = t.tables_id
                                          AND tcbk.tc_logic_type IN (1, 5)
     WHERE qd.qd_id = pi_vfd_qd_id;

  SELECT qd.qd_adj_tables_id                     AS quotas_table_id,
         t.tables_physical_name                  AS quotas_table_name,
         tc.tc_physical_name                     AS period_column_name,
         iq_table.tables_physical_name           AS iq_table_name,
         tc_product.tc_physical_name             AS product_column_name,
         quotas_ent_table.tables_physical_name   AS product_entity_table,
         quota_entity.entity_name                AS entity_name,
         quotas_tc.tc_physical_name              AS product_bk_column,
         add_fields.add_fields_clause
    INTO v_quotas_table_id,
         v_quotas_table_name,
         v_period_column_name,
         v_iq_table_name,
         v_product_column_name,
         v_prod_entity_table,
         v_prod_entity_name,
         v_prod_entity_bk_col,
         v_add_fields_col
    FROM quota_definitions qd
    LEFT JOIN tables t                  ON t.tables_id = qd.qd_adj_tables_id
    LEFT JOIN table_columns tc          ON tc.tc_tables_id = t.tables_id
                                        AND tc.tc_logic_type = 8
    LEFT JOIN table_columns tc_product  ON tc_product.tc_tables_id = qd.qd_adj_tables_id
                                        AND tc_product.tc_entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN tables iq_table           ON qd.qd_iq_tables_id = iq_table.tables_id
    LEFT JOIN entities quota_entity     ON quota_entity.entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN tables quotas_ent_table   ON quota_entity.entity_tables_id = quotas_ent_table.tables_id
    LEFT JOIN table_columns quotas_tc   ON quotas_tc.tc_tables_id = quotas_ent_table.tables_id
                                        AND quotas_tc.tc_logic_type IN (1, 5)
    LEFT JOIN (SELECT CASE WHEN pi_vfd_field_data_type = 1 THEN
                                LISTAGG('MAX(LENGTH(TO_CHAR(MOD(ABS(q.' || f.fld_column_name || '), 1))) - 1) > ' || CASE WHEN f.fld_display_as_percent = 1
                                                                                                                 THEN f.fld_length + 2
                                                                                                                 ELSE f.fld_length
                                                                                                            END, ' OR ' )
                                WITHIN GROUP (ORDER BY 1)
                           WHEN pi_vfd_field_data_type = 2 THEN
                                LISTAGG('MAX(LENGTH(q.' || f.fld_column_name || ')) > ' || f.fld_length, ' OR ' )
                                WITHIN GROUP (ORDER BY 1) END AS add_fields_clause
                 FROM quota_additional_fields qaf
                INNER JOIN fields f
                   ON qaf.qaf_field_id = f.fld_id
                WHERE qaf.qaf_qd_id = pi_vfd_qd_id
                  AND qaf.qaf_type = 0
                  AND f.fld_data_type = CASE WHEN pi_vfd_field_data_type = 1 THEN 6 ELSE 1 END
                 ) add_fields
     ON 1 = 1
   WHERE qd.qd_id = pi_vfd_qd_id;


    -- CHANGE for import from sales
   IF pi_vfd_field_mapping IS NOT NULL THEN
    -- get condition that calculates decimal numbers for all additional fields
    -- remove dynamic sql?
    SELECT LISTAGG('MAX(LENGTH(TO_CHAR(MOD(ABS(q.' || mapped_fields.fld_column_name || '), 1))) - 1) > ' || CASE WHEN quota_fields.fld_display_as_percent = 1
                                                                                                                 THEN quota_fields.fld_length + 2
                                                                                                                 ELSE quota_fields.fld_length
                                                                                                             END, ' OR ' )
             WITHIN GROUP (ORDER BY 1) AS add_fields_clause
                INTO v_add_fields_col
               FROM table(pi_vfd_field_mapping) mapped_fields_coll
              INNER JOIN fields mapped_fields
                 ON mapped_fields_coll.id2 = mapped_fields.fld_id
               LEFT JOIN fields quota_fields
                 ON mapped_fields_coll.id1 = quota_fields.fld_id
              WHERE quota_fields.fld_column_name != 'QUOTA';

   END IF;

    IF pi_vfd_calling_process = 1 AND v_add_fields_col IS NOT NULL THEN

      v_sql :=  '  SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'ATT_VALIDATE_10025', pi_vfd_qd_id, null) || chr(10) || -- change hint placeholder
                   CASE WHEN pi_vfd_field_data_type = 1 THEN ' 10025 ' ELSE '10029' END || ' AS TQV_VALIDATION_ID,' || chr(10) ||
                '       CASE ' || v_entity_name_clause || ' END AS TQV_ENTITY_NAME,' || chr( 10) ||
                '       COALESCE(' || v_entity_bk_list || ', NULL ) AS TQV_ENTITY_VALUE' || chr( 10) ||
                        CASE WHEN v_product_column_name IS NOT NULL THEN
                '            ,' || v_prod_entity_table || '.' || v_prod_entity_bk_col ||' || '' (' || v_prod_entity_name || ')'''  || ' AS TQV_ERROR_MESSAGE ' ELSE ',NULL' END || chr(10)||
                '  FROM ' || CASE WHEN pi_vfd_import_query IS NULL THEN v_iq_table_name ELSE '(' || pi_vfd_import_query || ')' END || ' q' || chr(10) ||
                             v_entity_table_join || chr(10) ||
                             CASE WHEN v_product_column_name IS NOT NULL
                                  THEN ' LEFT JOIN ' || v_prod_entity_table || ' ON ' || v_prod_entity_table || '.e_internal_id = q.' || v_product_column_name
                             END || chr(10 ) ||
                ' WHERE  ' || v_period_column_name || '=' || pi_vfd_tupr_id || chr(10) ||
                ' GROUP BY ' || CASE WHEN pi_vfd_import_query IS NULL THEN ' q.ROW_IDENTIFIER, ' END || v_simple_bk_list || CASE WHEN v_product_column_name IS NOT NULL
                                                                           THEN ', ' || v_prod_entity_table || '.' || v_prod_entity_bk_col END || chr(10) ||
                ' HAVING ' || v_add_fields_col;

      v_sql :=  'BEGIN' || chr(10) ||
                '  INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,' || chr(10) ||
                '    TQV_VALIDATION_ID,'     || chr(10) ||
                '    TQV_ENTITY_NAME,'       || chr(10) ||
                '    TQV_ENTITY_VALUE,'      || chr(10) ||
                '    TQV_ERROR_MESSAGE'      || chr(10) ||
                '    ) ' || chr(10) ||
                '    SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL AS TQV_ROW_IDENTIFIER, tqv.* FROM' || chr(10) ||
                '    (' || v_sql || ') tqv WHERE ROWNUM <= 1000;'  || chr(10) ||
                ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10) ||
                'END;';

      IF pi_vfd_hierarchy_mapping IS NOT NULL THEN
        EXECUTE IMMEDIATE v_sql USING IN pi_vfd_hierarchy_mapping, OUT pout_vfd_failed_val_no;
      ELSE
        EXECUTE IMMEDIATE v_sql USING OUT pout_vfd_failed_val_no;
      END IF;

    ELSIF pi_vfd_calling_process = 2 THEN

      -- use v_add_fields_col_from_model

      v_sql :=  '  SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'ATT_VALIDATE_10025', pi_vfd_qd_id, null) || chr(10) ||-- change hint placeholder
                   CASE WHEN pi_vfd_field_data_type = 1 THEN ' 10025 ' ELSE '10029' END || ' AS TQAV_VALIDATION_ID,' || chr(10) ||
                '       CASE ' || v_entity_name_clause || ' END AS TQAV_ENTITY_NAME,' || chr( 10) ||
                '       COALESCE(' || v_entity_bk_list || ', NULL ) AS TQAV_ENTITY_VALUE' || chr( 10) ||
                        CASE WHEN v_product_column_name IS NOT NULL THEN
                '            ,' || v_prod_entity_table || '.' || v_prod_entity_bk_col ||' || '' (' || v_prod_entity_name || ')'''  || ' AS TQAV_ERROR_MESSAGE ' ELSE ',NULL' END || chr(10)||
                '  FROM ' || v_iq_table_name || ' q' || chr(10) ||
                             v_entity_table_join || chr(10) ||
                             CASE WHEN v_product_column_name IS NOT NULL
                                  THEN ' LEFT JOIN ' || v_prod_entity_table || ' ON ' || v_prod_entity_table || '.e_internal_id = q.' || v_product_column_name
                             END || chr(10 ) ||
                ' WHERE  ' || v_period_column_name || '=' || pi_vfd_tupr_id || chr(10) ||
                ' GROUP BY q.ROW_IDENTIFIER, ' || v_simple_bk_list || CASE WHEN v_product_column_name IS NOT NULL
                                                                           THEN ', ' || v_prod_entity_table || '.' || v_prod_entity_bk_col END || chr(10) ||
                ' HAVING ' || v_add_fields_col;

    v_sql :=  'BEGIN' || chr(10) ||
              '  INSERT INTO TEMP_QUOTAS_ATT_VALIDATIONS(TQAV_ROW_IDENTIFIER,' || chr(10) ||
              '    TQAV_VALIDATION_ID,'     || chr(10) ||
              '    TQAV_ENTITY_NAME,'       || chr(10) ||
              '    TQAV_ENTITY_VALUE,'      || chr(10) ||
              '    TQAV_ERROR_MESSAGE'      || chr(10) ||
              '    ) ' || chr(10) ||
              '    SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL AS TQAV_ROW_IDENTIFIER, tqv.* FROM' || chr(10) ||
              '    (' || v_sql || ') tqv WHERE ROWNUM <= 1000;'  || chr(10) ||
              ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10) ||
              'END;';


    EXECUTE IMMEDIATE v_sql USING OUT pout_vfd_failed_val_no;

  END IF;

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vfd_failed_val_no),',pout_vqf_failed_no => <value>', v_stamp);

END VALIDATE_FIELD_DECIMALS;

-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20160316
-- Description: Procedure to validate that for each <organization entity, quota entity> pair from IQ we have a corresponding record
--              in the Q table when copying static fields
-- Input Parameters:
/*
   pi_vqf_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_vqf_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pi_vqf_iq_q_mapping IN TABLETYPE_NAME_MAP,                        -- mapping column names from IQ to Q tables
   pout_vqf_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/

-- Error code : 10026
-- Validation : http://confluence.optymyze.net/display/Quotas/Calculated+additional+quota+fields+-+Impact+on+Initial+Quota+Load+Process
--------------------------------------------------------------------------------------------------
PROCEDURE VALIDATE_QUOTAS_FIELDS(pi_vqf_tupr_id      IN tu_periods_range.tupr_id%TYPE,
                                 pi_vqf_qd_id        IN quota_definitions.qd_id%TYPE,
                                 pi_vqf_iq_q_mapping IN TABLETYPE_NAME_MAP,
                                 pout_vqf_failed_no  OUT NUMBER
                                 )
IS
  v_sql                     CLOB;
  v_entity_table_join       CLOB;
  v_entity_name_clause      CLOB;
  v_entity_bk_list          CLOB;
  v_iq_q_join_condition     CLOB;

  v_stamp                   VARCHAR2(250 CHAR);
  v_quotas_table_id         NUMBER(10);
  v_quotas_table_name       VARCHAR2(30 CHAR);
  v_iq_table_name           VARCHAR2(30 CHAR);
  v_period_column_name      VARCHAR2(30 CHAR);
  v_product_column_name     VARCHAR2(30 CHAR);

  v_prod_entity_table       VARCHAR2(30 CHAR);
  v_prod_entity_bk_col      VARCHAR2(30 CHAR);
  v_prod_entity_name        VARCHAR2(30 CHAR);
BEGIN

  v_stamp := 'QUOTAS.VALIDATE_QUOTAS_FIELDS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

  SELECT LISTAGG(' LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = q.' || tc.tc_physical_name, ' ')
   WITHIN GROUP (ORDER BY 1) AS entity_table_join,
         LISTAGG( ' WHEN ' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN ''' || REPLACE(e.entity_name, CHR(39 ), CHR(39)||CHR( 39)) || '''' , ' ')
   WITHIN GROUP (ORDER BY 1) AS entity_name_clause,
         LISTAGG( 'TO_CHAR(' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ')' , ', ')
   WITHIN GROUP (ORDER BY 1) AS entity_bk_list,
         LISTAGG( 'q_table.' || mp.name1 || ' = iq.' || mp.name2 , ' OR ')
   WITHIN GROUP (ORDER BY 1) AS entity_bk_list
      INTO v_entity_table_join, v_entity_name_clause, v_entity_bk_list, v_iq_q_join_condition
      FROM quota_definitions qd
     INNER JOIN table_columns tc           ON tc.tc_tables_id = qd.qd_adj_tables_id
     INNER JOIN TABLE(pi_vqf_iq_q_mapping) mp ON tc.tc_physical_name = mp.name1
     INNER JOIN entities e                 ON e.entity_id = tc.tc_entity_id
     INNER JOIN tables t                   ON t.tables_id = e.entity_tables_id
     INNER JOIN table_columns tcbk         ON tcbk.tc_tables_id = t.tables_id
                                          AND tcbk.tc_logic_type IN (1, 5)
     WHERE qd.qd_id = pi_vqf_qd_id;

  SELECT qd.qd_adj_tables_id                     AS quotas_table_id,
         t.tables_physical_name                  AS quotas_table_name,
         tc.tc_physical_name                     AS period_column_name,
         iq_table.tables_physical_name           AS iq_table_name,
         tc_product.tc_physical_name             AS product_column_name,
         quotas_ent_table.tables_physical_name   AS product_entity_table,
         quota_entity.entity_name                AS entity_name,
         quotas_tc.tc_physical_name              AS product_bk_column
    INTO v_quotas_table_id,
         v_quotas_table_name,
         v_period_column_name,
         v_iq_table_name,
         v_product_column_name,
         v_prod_entity_table,
         v_prod_entity_name,
         v_prod_entity_bk_col
    FROM quota_definitions qd
    LEFT JOIN tables t                  ON t.tables_id = qd.qd_adj_tables_id
    LEFT JOIN table_columns tc          ON tc.tc_tables_id = t.tables_id
                                        AND tc.tc_logic_type = 8
    LEFT JOIN table_columns tc_product  ON tc_product.tc_tables_id = qd.qd_adj_tables_id
                                        AND tc_product.tc_entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN tables iq_table           ON qd.qd_iq_tables_id = iq_table.tables_id
    LEFT JOIN entities quota_entity     ON quota_entity.entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN tables quotas_ent_table   ON quota_entity.entity_tables_id = quotas_ent_table.tables_id
    LEFT JOIN table_columns quotas_tc   ON quotas_tc.tc_tables_id = quotas_ent_table.tables_id
                                        AND quotas_tc.tc_logic_type IN (1, 5)
   WHERE qd.qd_id = pi_vqf_qd_id;

        v_sql :=  '  SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'ATT_VALIDATE_10023', pi_vqf_qd_id, null) || -- change hint placeholder
              '       TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL AS TQAV_ROW_IDENTIFIER, ' || chr(10) ||
              '       10026 AS TQAV_VALIDATION_ID,' || chr(10) ||
              '       CASE ' || v_entity_name_clause || ' END AS TQAV_ENTITY_NAME,' || chr( 10) ||
              '       COALESCE(' || v_entity_bk_list || ', NULL ) AS TQAV_ENTITY_VALUE' || chr( 10) ||
                      CASE WHEN v_product_column_name IS NOT NULL THEN
              '            ,' || v_prod_entity_table || '.' || v_prod_entity_bk_col ||' || '' (' || v_prod_entity_name || ')'''  || ' AS TQAV_ERROR_MESSAGE ' ELSE ',NULL' END || chr(10)||
              '  FROM ' || v_quotas_table_name || ' q' || chr(10) ||
                           v_entity_table_join || chr(10) ||
                           CASE WHEN v_product_column_name IS NOT NULL
                                THEN ' LEFT JOIN ' || v_prod_entity_table || ' ON ' || v_prod_entity_table || '.e_internal_id = q.' || v_product_column_name
                           END || chr(10 ) ||
              ' WHERE NOT EXISTS (SELECT q_table.row_identifier' || chr(10) ||
              '          FROM ' || v_iq_table_name || ' iq' || chr(10) ||
              '         INNER JOIN ' || v_quotas_table_name || ' q_table' || chr(10) ||
              '            ON (' || v_iq_q_join_condition || ')' || chr(10) ||
                        CASE WHEN v_product_column_name IS NOT NULL THEN
              '           AND iq.' || v_product_column_name || ' = q_table.' || v_product_column_name END || chr(10) ||
              '           AND iq.' || v_period_column_name || ' = q_table.' || v_period_column_name || chr(10) ||
              '           AND iq.' || v_period_column_name || ' = ' || pi_vqf_tupr_id || chr(10) ||
              '         WHERE q_table.row_identifier = q.row_identifier) ' || chr(10) ||
              '  AND q.' || v_period_column_name || ' = ' || pi_vqf_tupr_id || chr(10) ||
              '  AND ROWNUM <= 1000';

  v_sql :=  'BEGIN' || chr(10) ||
            '  INSERT INTO TEMP_QUOTAS_ATT_VALIDATIONS(TQAV_ROW_IDENTIFIER,' || chr(10) ||
            '    TQAV_VALIDATION_ID,'     || chr(10) ||
            '    TQAV_ENTITY_NAME,'       || chr(10) ||
            '    TQAV_ENTITY_VALUE,' || chr(10) ||
            '    TQAV_ERROR_MESSAGE' || chr(10) ||
            '    ) ' || v_sql || ';' || chr(10) ||
            ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10) ||
            'END;';

  EXECUTE IMMEDIATE v_sql USING OUT pout_vqf_failed_no;

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vqf_failed_no),',pout_vqf_failed_no => <value>', v_stamp);

END VALIDATE_QUOTAS_FIELDS;


-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20170801
-- Description: Procedure to validate that quota is a positive number
-- Input Parameters:
/*
   pi_vnq_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_vnq_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pi_vnq_iq_q_mapping IN TABLETYPE_NAME_MAP,                        -- mapping column names from IQ to Q tables
   pout_vng_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/

-- Error code : 10027
--------------------------------------------------------------------------------------------------
PROCEDURE VALIDATE_NEGATIVE_QUOTA(pi_vnq_tupr_id           IN tu_periods_range.tupr_id%TYPE,
                                  pi_vnq_qd_id             IN quota_definitions.qd_id%TYPE,
                                  pi_vnq_iq_q_mapping      IN TABLETYPE_NAME_MAP,
                                  pi_vnq_field_mapping     IN TABLETYPE_ID_ID,
                                  pi_vnq_hierarchy_mapping IN TABLETYPE_ID_ID,
                                  pi_vnq_import_query      IN CLOB,
                                  pout_vnq_failed_no       OUT NUMBER
                                 )
IS
  v_sql                     CLOB;
  v_entity_table_join       CLOB;
  v_entity_name_clause      CLOB;
  v_entity_bk_list          CLOB;
  v_iq_q_join_condition     CLOB;

  v_stamp                   VARCHAR2(250 CHAR);
  v_quotas_table_id         NUMBER(10);
  v_quotas_table_name       VARCHAR2(30 CHAR);
  v_iq_table_name           VARCHAR2(30 CHAR);
  v_period_column_name      VARCHAR2(30 CHAR);
  v_product_column_name     VARCHAR2(30 CHAR);

  v_prod_entity_table       VARCHAR2(30 CHAR);
  v_prod_entity_bk_col      VARCHAR2(30 CHAR);
  v_prod_entity_name        VARCHAR2(30 CHAR);
  v_quota_planning_col_name VARCHAR2(30 CHAR);
BEGIN

  v_stamp := 'QUOTAS.VALIDATE_NEGATIVE_QUOTA - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

  SELECT LISTAGG(' LEFT JOIN ' || t.tables_physical_name || ' ON ' ||
                 t.tables_physical_name || '.e_internal_id = q.' ||
                 tc.tc_physical_name,
                 ' ') WITHIN GROUP(ORDER BY 1) AS entity_table_join,
         LISTAGG(' WHEN ' || t.tables_physical_name || '.' ||
                 tcbk.tc_physical_name || ' IS NOT NULL THEN ''' ||
                 REPLACE(e.entity_name, CHR(39), CHR(39) || CHR(39)) || '''',
                 ' ') WITHIN GROUP(ORDER BY 1) AS entity_name_clause,
         LISTAGG('TO_CHAR(' || t.tables_physical_name || '.' ||
                 tcbk.tc_physical_name || ')',
                 ', ') WITHIN GROUP(ORDER BY 1) AS entity_bk_list,
         LISTAGG('q_table.' || mp.name1 || ' = iq.' || mp.name2, ' OR ') WITHIN GROUP(ORDER BY 1) AS entity_bk_list
    INTO v_entity_table_join,
         v_entity_name_clause,
         v_entity_bk_list,
         v_iq_q_join_condition
    FROM quota_definitions qd
   INNER JOIN table_columns tc
      ON tc.tc_tables_id = qd.qd_adj_tables_id
   INNER JOIN TABLE(pi_vnq_iq_q_mapping) mp
      ON tc.tc_physical_name = mp.name1
   INNER JOIN entities e
      ON e.entity_id = tc.tc_entity_id
   INNER JOIN tables t
      ON t.tables_id = e.entity_tables_id
   INNER JOIN table_columns tcbk
      ON tcbk.tc_tables_id = t.tables_id
     AND tcbk.tc_logic_type IN (1, 5)
   WHERE qd.qd_id = pi_vnq_qd_id;

  SELECT qd.qd_adj_tables_id                     AS quotas_table_id,
         t.tables_physical_name                  AS quotas_table_name,
         tc.tc_physical_name                     AS period_column_name,
         iq_table.tables_physical_name           AS iq_table_name,
         tc_product.tc_physical_name             AS product_column_name,
         quotas_ent_table.tables_physical_name   AS product_entity_table,
         quota_entity.entity_name                AS entity_name,
         quotas_tc.tc_physical_name              AS product_bk_column
    INTO v_quotas_table_id,
         v_quotas_table_name,
         v_period_column_name,
         v_iq_table_name,
         v_product_column_name,
         v_prod_entity_table,
         v_prod_entity_name,
         v_prod_entity_bk_col
    FROM quota_definitions qd
    LEFT JOIN tables t                  ON t.tables_id = qd.qd_adj_tables_id
    LEFT JOIN table_columns tc          ON tc.tc_tables_id = t.tables_id
                                        AND tc.tc_logic_type = 8
    LEFT JOIN table_columns tc_product  ON tc_product.tc_tables_id = qd.qd_adj_tables_id
                                        AND tc_product.tc_entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN tables iq_table           ON qd.qd_iq_tables_id = iq_table.tables_id
    LEFT JOIN entities quota_entity     ON quota_entity.entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN tables quotas_ent_table   ON quota_entity.entity_tables_id = quotas_ent_table.tables_id
    LEFT JOIN table_columns quotas_tc   ON quotas_tc.tc_tables_id = quotas_ent_table.tables_id
                                        AND quotas_tc.tc_logic_type IN (1, 5)
   WHERE qd.qd_id = pi_vnq_qd_id;

   -- in case the validation is called from the sales planning import process, we get the QUOTA equivalent field from Model table
   SELECT f_right.fld_column_name
     INTO v_quota_planning_col_name
     FROM table(pi_vnq_field_mapping) fld_map
    INNER JOIN fields f_left
       ON fld_map.id1 = f_left.fld_id
     LEFT JOIN fields f_right
       ON fld_map.id2 = f_right.fld_id
    WHERE f_left.fld_column_name = 'QUOTA';


  v_sql :=  '  SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'ATT_VALIDATE_10028', pi_vnq_qd_id, null) ||
            '         TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL AS TQV_ROW_IDENTIFIER, ' || chr(10) ||
            '         10028 AS TQV_VALIDATION_ID,' || chr(10) ||
            '         CASE ' || v_entity_name_clause || ' END AS TQV_ENTITY_NAME,' || chr( 10) ||
            '         COALESCE(' || v_entity_bk_list || ', NULL ) AS TQV_ENTITY_VALUE' || chr( 10) ||
                      CASE WHEN v_product_column_name IS NOT NULL THEN
            '            ,' || v_prod_entity_table || '.' || v_prod_entity_bk_col ||' || '' (' || v_prod_entity_name || ')'''  || ' AS TQV_ERROR_MESSAGE ' ELSE ',NULL' END || chr(10)||
            '  FROM (' || pi_vnq_import_query || ') q' || chr(10) ||
                         v_entity_table_join || chr(10) ||
                         CASE WHEN v_product_column_name IS NOT NULL
                              THEN ' LEFT JOIN ' || v_prod_entity_table || ' ON ' || v_prod_entity_table || '.e_internal_id = q.' || v_product_column_name
                         END || chr(10 ) ||
            ' WHERE q.' || v_quota_planning_col_name  || ' < 0 OR q.' || v_quota_planning_col_name  || ' IS NULL ' || chr(10) ||
            '   AND q.' || v_period_column_name || ' = ' || pi_vnq_tupr_id || chr(10) ||
            '   AND ROWNUM <= 1000';

  v_sql :=  'BEGIN' || chr(10) ||
            '  INSERT INTO TEMP_QUOTAS_VALIDATIONS(TQV_ROW_IDENTIFIER,' || chr(10) ||
            '    TQV_VALIDATION_ID,'     || chr(10) ||
            '    TQV_ENTITY_NAME,'       || chr(10) ||
            '    TQV_ENTITY_VALUE,' || chr(10) ||
            '    TQV_ERROR_MESSAGE' || chr(10) ||
            '    ) ' || v_sql || ';' || chr(10) ||
            ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10) ||
            'END;';

  EXECUTE IMMEDIATE v_sql USING IN pi_vnq_hierarchy_mapping, OUT pout_vnq_failed_no;

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vnq_failed_no),',pout_vqf_failed_no => <value>', v_stamp);

END VALIDATE_NEGATIVE_QUOTA;

-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140827
-- Description: Procedure that runs the validations on IQ and hierarchy
-----------------------------------------------------------------------------------------
-- Parameters:
/*
 pi_vihr_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
 pi_vihr_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
 pi_vihr_iq_table_name   IN tables.tables_physical_name%type,       -- the name of the INITIAL_QUOTAS table
 pi_vihr_iq_qe_mapping   IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quota Entities tables
 pi_vihr_no_dist_ent     IN NUMBER,                                 -- number of distinct entities from Entity Relationship
 pi_vihr_no_of_records   IN NUMBER,                                 -- number of records from TMP_IQ_HIERARCHY
 pout_vihr_failed_val_no OUT NUMBER                                 -- number of rows that failed the validations
*/
-----------------------------------------------------------------------------------------
PROCEDURE RUN_VALIDATIONS (  pi_vihr_tupr_id                IN tu_periods_range.tupr_id%type ,
                             pi_vihr_qd_id                  IN quota_definitions.qd_iq_tables_id%type ,
                             pi_vihr_iq_table_name          IN tables.tables_physical_name%type ,
                             pi_vihr_iq_qe_mapping          IN TABLETYPE_NAME_MAP,
                             pi_vihr_no_dist_ent            IN NUMBER ,
                             pi_vihr_no_of_records          IN NUMBER ,
                             pi_vihr_user_assign_queries    IN TABLETYPE_QUOTAS_QUERY_MAP,
                             pi_vihr_prod_hierarchy_defined IN NUMBER ,
                             pi_vihr_prod_no_of_records     IN NUMBER ,
                             pout_vihr_failed_val_no        OUT NUMBER
                           )
AS
  v_iq_period_col_name      table_columns.tc_physical_name% type;
  v_cnt                     NUMBER(10 );
  v_no_rec_failed           NUMBER(10 ) := 0;
  v_quota_has_product       NUMBER(1 );
  v_has_add_static_fields   NUMBER(1);
  v_has_static_num_fld      NUMBER(1);
  v_has_static_char_fld     NUMBER(1);
  v_stamp                   VARCHAR2( 250);
BEGIN

v_stamp := 'QUOTAS.RUN_VALIDATIONS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

  -- get Initial Quotas period column name and multiple quota
  SELECT tc_per.tc_physical_name, CASE WHEN qd_multiple_q_entity_id IS NOT NULL THEN 1 ELSE 0 END,
         (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 0 AND ROWNUM <= 1),
         (SELECT COUNT(1)
            FROM quota_additional_fields qaf
           INNER JOIN fields f
              ON qaf.qaf_field_id = f.fld_id
           WHERE qaf.qaf_type = 0
             AND qaf_qd_id = pi_vihr_qd_id
             AND f.fld_data_type = 1
             AND ROWNUM <= 1),
         (SELECT COUNT(1)
            FROM quota_additional_fields qaf
           INNER JOIN fields f
              ON qaf.qaf_field_id = f.fld_id
           WHERE qaf.qaf_type = 0
             AND qaf_qd_id = pi_vihr_qd_id
             AND f.fld_data_type = 6
             AND ROWNUM <= 1)
    INTO v_iq_period_col_name, v_quota_has_product, v_has_add_static_fields, v_has_static_char_fld, v_has_static_num_fld
  FROM quota_definitions qd
    -- period column from table_columns
    INNER JOIN table_columns tc_per ON tc_per.tc_tables_id = qd.qd_iq_tables_id
  WHERE qd.qd_id = pi_vihr_qd_id
     -- effective period
     AND tc_per.tc_logic_type = 8 ;

  pout_vihr_failed_val_no := 0;



  -- Determining the records from the Initial Quotas table that are relevant for the period being run
  VALIDATE_IQ_HAS_RECORDS ( pi_vihr_tupr_id            => pi_vihr_tupr_id,
                            pi_vihr_qd_id              => pi_vihr_qd_id,
                            pi_vihr_iq_table_name      => pi_vihr_iq_table_name,
                            pi_vihr_no_dist_ent        => pi_vihr_no_dist_ent,
                            pi_vihr_iq_period_col_name => v_iq_period_col_name,
                            pout_vihr_no_rec_failed    => v_no_rec_failed
                          );
  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

  VALIDATE_HIERARCHY_HAS_RECORDS ( pi_vhhr_qd_id              => pi_vihr_qd_id,
                                   pi_vhhr_no_of_records      => pi_vihr_no_of_records,
                                   pi_vhhr_hierarchy_type     => 1,
                                   pi_vhhr_prod_no_of_records => pi_vihr_prod_no_of_records,
                                   pout_vhhr_no_rec_failed    => v_no_rec_failed
                                  );
  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);


  VALIDATE_10010 ( pi_10_qd_id               => pi_vihr_qd_id,
                   pi_10_iq_qe_mapping       => pi_vihr_iq_qe_mapping,
                   pi_10_no_of_records       => pi_vihr_no_of_records,
                   pout_10_failed_val_no     => v_no_rec_failed
                 );

  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);


  -- If:
  --    -> the Entity Relationships consist of a single distinct entity (top 2 entities are the same with NO additional entity)
  --    -> there is no value in Initial Quotas at the lowest levels
  -- then processing stops
  IF pi_vihr_no_dist_ent = 4 THEN
    VALIDATE_LEAF_NODES_IN_IQ (pi_vln_tupr_id         => pi_vihr_tupr_id,
                               pi_vln_qd_id           => pi_vihr_qd_id,
                               pi_vln_iq_table_name   => pi_vihr_iq_table_name,
                               pi_vln_iq_qe_mapping   => pi_vihr_iq_qe_mapping,
                               pi_vln_no_of_records   => pi_vihr_no_of_records,
                               pi_vln_iq_per_col_name => v_iq_period_col_name,
                               pout_vln_no_rec_failed => v_no_rec_failed
                             );
    pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);
  END IF;

  -- generate the temporary hierarchy query that holds all the leaf nodes and upper instances present in IQ and in the hierarchy
  GENERATE_HIERARCHY_QUERY ( pi_ghq_tupr_id            => pi_vihr_tupr_id,
                             pi_ghq_qd_id              => pi_vihr_qd_id,
                             pi_ghq_iq_table_name      => pi_vihr_iq_table_name,
                             pi_ghq_iq_qe_mapping      => pi_vihr_iq_qe_mapping,
                             pi_ghq_iq_period_col_name => v_iq_period_col_name,
                             pi_ghq_h_no_of_rec        => pi_vihr_no_of_records,
                             pout_ghq_no_of_records    => v_cnt
                            );

  VALIDATE_10002_10005 ( pi_25_tupr_id            => pi_vihr_tupr_id,
                         pi_25_qd_id              => pi_vihr_qd_id,
                         pi_25_iq_table_name      => pi_vihr_iq_table_name,
                         pi_25_iq_qe_mapping      => pi_vihr_iq_qe_mapping,
                         pi_25_no_dist_ent        => pi_vihr_no_dist_ent,
                         pi_25_no_of_records      => v_cnt,
                         pi_25_iq_period_col_name => v_iq_period_col_name,
                         pout_25_failed_val_no    => v_no_rec_failed
                       );
  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

  -- top 2 entities are NOT the same
  IF pi_vihr_no_dist_ent = 1 THEN
      VALIDATE_10003 ( pi_3_tupr_id                => pi_vihr_tupr_id,
                       pi_3_qd_id                  => pi_vihr_qd_id,
                       pi_3_iq_table_name          => pi_vihr_iq_table_name,
                       pi_3_iq_period_col_name     => v_iq_period_col_name,
                       pi_3_iq_qe_mapping          => pi_vihr_iq_qe_mapping,
                       pi_3_no_of_records          => pi_vihr_no_of_records,
                       pout_3_failed_val_no        => v_no_rec_failed
                     );
    pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);
  END IF;
  VALIDATE_10004 ( pi_4_tupr_id            => pi_vihr_tupr_id,
                   pi_4_qd_id              => pi_vihr_qd_id,
                   pi_4_iq_table_name      => pi_vihr_iq_table_name,
                   pi_4_iq_qe_mapping      => pi_vihr_iq_qe_mapping,
                   pi_4_no_of_rec          => v_cnt,
                   pi_4_iq_period_col_name => v_iq_period_col_name,
                   pi_4_no_dist_ent        => pi_vihr_no_dist_ent,
                   pout_4_failed_val_no    => v_no_rec_failed
                 );
  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

  VALIDATE_NO_OF_DECIMALS( pi_vod_tupr_id           => pi_vihr_tupr_id,
                           pi_vod_qd_id             => pi_vihr_qd_id,
                           pi_vod_field_mapping     => NULL,
                           pi_vod_hierarchy_mapping => NULL,
                           pi_vod_import_query      => NULL,
                           pout_vod_failed_val_no   => v_no_rec_failed
                         );
  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

  IF v_quota_has_product = 1 THEN
      VALIDATE_QUOTA_ENTITIES ( pi_vqe_tupr_id              => pi_vihr_tupr_id,
                                pi_vqe_qd_id                => pi_vihr_qd_id,
                                pi_vqe_iq_table_name        => pi_vihr_iq_table_name,
                                pi_vqe_iq_entity_col_names  => pi_vihr_iq_qe_mapping,
                                pi_vqe_h_no_of_rec          => pi_vihr_no_of_records,
                                pout_vqe_failed_val_no      => v_no_rec_failed
                               );
      pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);
  END IF;

  IF pi_vihr_prod_hierarchy_defined = 1 THEN
    VALIDATE_HIERARCHY_HAS_RECORDS ( pi_vhhr_qd_id              => pi_vihr_qd_id,
                                     pi_vhhr_no_of_records      => pi_vihr_no_of_records,
                                     pi_vhhr_hierarchy_type     => 2,
                                     pi_vhhr_prod_no_of_records => pi_vihr_prod_no_of_records,
                                     pout_vhhr_no_rec_failed    => v_no_rec_failed
                                    );
    pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

    VALIDATE_10012 ( pi_12_tupr_id             => pi_vihr_tupr_id,
                     pi_12_qd_id               => pi_vihr_qd_id,
                     pi_12_iq_table_name       => pi_vihr_iq_table_name,
                     pi_12_iq_period_col_name  => v_iq_period_col_name,
                     pi_12_no_of_records       => pi_vihr_prod_no_of_records,
                     pout_12_failed_val_no     => v_no_rec_failed
                    );

    pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);


    VALIDATE_10013 ( pi_13_tupr_id            => pi_vihr_tupr_id,
                     pi_13_qd_id              => pi_vihr_qd_id,
                     pi_13_iq_table_name      => pi_vihr_iq_table_name,
                     pi_13_iq_period_col_name => v_iq_period_col_name,
                     pi_13_no_of_records      => pi_vihr_prod_no_of_records,
                     pout_13_failed_val_no    => v_no_rec_failed
                   );
    pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

  END IF;

  VALIDATE_USER_ASSIGNMENTS ( pi_vua_tupr_id              => pi_vihr_tupr_id,
                              pi_vua_qd_id                => pi_vihr_qd_id,
                              pi_vua_iq_entity_col_names  => pi_vihr_iq_qe_mapping,
                              pi_vua_user_assign_queries  => pi_vihr_user_assign_queries,
                              pout_vua_failed_val_no      => v_no_rec_failed
                           );
  pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);

  IF v_has_add_static_fields = 1 THEN

    -- check length for numeric fields
    IF v_has_static_num_fld = 1 THEN
      VALIDATE_FIELD_DECIMALS(pi_vfd_tupr_id           => pi_vihr_tupr_id,
                              pi_vfd_qd_id             => pi_vihr_qd_id,
                              pi_vfd_iq_q_mapping      => pi_vihr_iq_qe_mapping,
                              pi_vfd_calling_process   => 1,
                              pi_vfd_field_mapping     => NULL,
                              pi_vfd_hierarchy_mapping => NULL,
                              pi_vfd_import_query      => NULL,
                              pi_vfd_field_data_type   => 1,
                              pout_vfd_failed_val_no  => v_no_rec_failed
                            );
      pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);
    END IF;
    -- check length for character fields
    IF v_has_static_char_fld = 1 THEN
      VALIDATE_FIELD_DECIMALS(pi_vfd_tupr_id           => pi_vihr_tupr_id,
                              pi_vfd_qd_id             => pi_vihr_qd_id,
                              pi_vfd_iq_q_mapping      => pi_vihr_iq_qe_mapping,
                              pi_vfd_calling_process   => 1,
                              pi_vfd_field_mapping     => NULL,
                              pi_vfd_hierarchy_mapping => NULL,
                              pi_vfd_import_query      => NULL,
                              pi_vfd_field_data_type   => 2,
                              pout_vfd_failed_val_no  => v_no_rec_failed
                            );
      pout_vihr_failed_val_no := pout_vihr_failed_val_no + NVL(v_no_rec_failed,0);
    END IF;
  END IF;

L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_vihr_failed_val_no),',pout_vihr_failed_val_no => <value>', v_stamp);

END RUN_VALIDATIONS;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20140808
-- Description: Procedure to populate QUOTAS table
-----------------------------------------------------------------------------------------
PROCEDURE LOAD_QUOTAS(  pi_lq_tupr_id             IN tu_periods_range.tupr_id%TYPE
                       ,pi_lq_qd_id               IN quota_definitions.qd_id%TYPE
                       ,pi_lq_column_names        IN TABLETYPE_NAME_MAP
                       ,pi_lq_prod_herarchy       IN NUMBER
                       ,pout_lq_no_rec_q          OUT NUMBER
                     )
IS

  l_adj_columns                VARCHAR2(150 CHAR);
  l_adj_lower_upper_columns    VARCHAR2(70 CHAR);

  l_stamp                      VARCHAR2(250 CHAR);
  v_sql                        CLOB;
BEGIN
    l_stamp := 'QUOTAS.LOAD_QUOTAS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lq_tupr_id),                ',pi_lq_tupr_id => <value>', l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lq_qd_id),                  ',pi_lq_qd_id => <value>', l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_lq_column_names),       ',pi_lq_column_names => <value>' , l_stamp);
    END;




    -- *******************************
    -- LOAD_QUOTAS
    -- *******************************'

    -- LOAD_QUOTAS - DELETE DATA

    -- delete data from previous runs on the same period
    SELECT 'DELETE FROM ' || t2.tables_physical_name || ' WHERE ' || tc.tc_physical_name || ' = ' || pi_lq_tupr_id
         INTO v_sql
    FROM       quota_definitions qd
    -- Quotas table
    INNER JOIN tables            t2 ON qd.qd_adj_tables_id = t2.tables_id
    INNER JOIN table_columns     tc ON tc.tc_tables_id = t2.tables_id
                                    AND tc.tc_logic_type= 8
    WHERE qd.qd_id = pi_lq_qd_id;

    EXECUTE IMMEDIATE v_sql;

    -- LOAD_QUOTAS - POPULATE QUOTAS TABLE
    -- insert new data into Quotas table
    SELECT -- list of column names for Quotas table
             --      Outstanding Allocation applicable only if the 'Marking Adjustments Complete' sub-option is SELECTed
             LISTAGG( CASE WHEN oa.outstanding_allocation = 2
                            AND fld_column_name in ('INITIAL_QUOTA','ADJUSTMENTS','CURRENT_QUOTA','OUTSTANDING_ALLOCATION')
                          THEN fld_column_name
                          WHEN oa.outstanding_allocation != 2
                            AND fld_column_name in ('INITIAL_QUOTA', 'ADJUSTMENTS', 'CURRENT_QUOTA' )
                            THEN fld_column_name
                     END, ', ' ) WITHIN GROUP ( ORDER BY ROWNUM),
             -- list of column names for Lower Adjustment Limit and Upper Adjustment Limit
              LISTAGG( CASE WHEN fld_column_name in ( 'LOWER_ADJUSTMENT_LIMIT','UPPER_ADJUSTMENT_LIMIT')
                          THEN fld_column_name END , ', ' ) WITHIN GROUP (ORDER BY ROWNUM)
        INTO l_adj_columns,l_adj_lower_upper_columns
    FROM fields
    CROSS JOIN (SELECT qd.qd_ensure_net_q_adj AS outstanding_allocation
                FROM quota_definitions qd
                WHERE qd_id = pi_lq_qd_id) oa
    WHERE fld_column_name IN ('INITIAL_QUOTA', 'ADJUSTMENTS', 'CURRENT_QUOTA', 'OUTSTANDING_ALLOCATION',
                                  'LOWER_ADJUSTMENT_LIMIT', 'UPPER_ADJUSTMENT_LIMIT');

    SELECT 'BEGIN' || CHR(10) ||
           'INSERT INTO ' || t2.tables_physical_name || '('
                  || tc.tc_physical_name || ', '                                                             -- period column
                  || col.q_columns || ', '
                  || l_adj_columns
                  -- -- check if there are limits defined for this definition
                  || CASE WHEN qd.qd_single_q_upper_limit IS NOT NULL OR qd.qd_qa_tables_id IS NOT NULL THEN ',' || l_adj_lower_upper_columns END
                  || ', ROW_IDENTIFIER, ROW_VERSION '
                  -- check if entities in organization hierarchy have multiple quotas
                  || CASE WHEN qd.qd_multiple_q_entity_id IS NOT NULL THEN ',' || tc_prod.tc_physical_name END -- product column
                  || CASE WHEN pi_lq_prod_herarchy = 1 THEN ', UPPER_ENTITY_VALUE' END
                  || CASE WHEN (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 0 AND ROWNUM <= 1) = 1 THEN ',' || QUOTAS.GET_ADDITIONAL_FIELDS(qd.qd_id, 1) END
                  || CASE WHEN allow_non_zero_sum_adj.cnt = 1 THEN ', OUTSTANDING_ALLOCATION ' END || ')' || CHR(10) ||
              COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'LOAD_QUOTAS', pi_lq_qd_id, null) || CHR(10) ||
             'SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'LOAD_QUOTAS', pi_lq_qd_id, null)
                  || 'iq.' || tc_iq.tc_physical_name || ', '                                                           -- period column
                  || col.iq_columns || ', ' || ' iq. ' || q.quota_col_name || ', 0, '|| 'iq.' || q.quota_col_name || ', '
                  || CASE WHEN qd.qd_ensure_net_q_adj = 2 THEN ' 0,' END -- outstanding allocation
                  -- -- check if there are limits defined for this definition
                  || CASE WHEN qd.qd_single_q_upper_limit IS NOT NULL OR qd.qd_qa_tables_id IS NOT NULL
                          THEN -- check if the quota definition varies by product
                                'ROUND((100-' || CASE WHEN qd_qa_tables_id IS NOT NULL THEN 'qa.' || llim.lower_limit_col_name
                                                      ELSE 'qd.qd_single_q_lower_limit'
                                                 END || ') * iq.quota/100, qd.qd_no_of_decimals),
                                -- check if the quota definition varies by product
                                ROUND((100+' || CASE WHEN qd_qa_tables_id IS NOT NULL THEN 'qa.' || ulim.upper_limit_col_name
                                                     ELSE 'qd.qd_single_q_upper_limit'
                                                END || ') * iq.quota/100, qd.qd_no_of_decimals),'
                     END
                  || t2.tables_physical_name || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0 '
                  -- check if entities in organization hierarchy have multiple quotas
                  || CASE WHEN qd.qd_multiple_q_entity_id IS NOT NULL THEN ', iq.' || prod_iq.tc_physical_name END   -- product column
                  || CASE WHEN pi_lq_prod_herarchy = 1 THEN ', tmp.upper_value ' END
                  || CASE WHEN  (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 0 AND ROWNUM <= 1) = 1 THEN ',' || QUOTAS.GET_ADDITIONAL_FIELDS(qd.qd_id,  1, 'iq.') END
                  || CASE WHEN allow_non_zero_sum_adj.cnt = 1 THEN ', 0 as outstanding_allocation ' END  || CHR(10) ||
             'FROM ' || t1.tables_physical_name || ' iq ' ||CHR(10)||
              CASE WHEN pi_lq_prod_herarchy = 1 THEN  'INNER JOIN tmp_product_hierarchy tmp ON iq.' || prod_iq.tc_physical_name || ' = tmp.lower_value and tmp.lower_entity_id = ' || prod_iq.tc_entity_id END || CHR(10) ||
             'CROSS JOIN (SELECT qd_no_of_decimals, qd_single_q_upper_limit, qd_single_q_lower_limit '||CHR( 10)||
                         'FROM quota_definitions WHERE qd_id = ' || pi_lq_qd_id || ') qd '
             ||CHR( 10)||
             -- check if the quota definition varies by product
             CASE WHEN   qd_qa_tables_id IS NOT NULL THEN ' LEFT JOIN '|| t_adj.tables_physical_name ||' qa ON qa.'
                         || tc_adj.tc_physical_name || ' = iq.' || prod_iq.tc_physical_name
             END
             || ' WHERE iq.' || tc_iq.tc_physical_name || ' = ' || pi_lq_tupr_id || ';' || CHR(10 ) ||
           ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
           'END;'
         INTO v_sql
    FROM       quota_definitions   qd
      -- Initial Quotas table name
      INNER JOIN tables            t1       ON qd.qd_iq_tables_id = t1.tables_id
      INNER JOIN table_columns     tc_iq    ON tc_iq.tc_tables_id = t1.tables_id
                                            AND tc_iq.tc_logic_type = 8 -- period column
      -- Quotas table information
      INNER JOIN tables            t2       ON qd.qd_adj_tables_id = t2.tables_id
      INNER JOIN table_columns     tc       ON tc.tc_tables_id = t2.tables_id
                                            AND tc.tc_logic_type= 8
      -- Quota Adjustments table name and product column name if the table exists
      LEFT  JOIN tables            t_adj    ON qd.qd_qa_tables_id = t_adj.tables_id
      LEFT  JOIN table_columns     tc_adj   ON tc_adj.tc_tables_id = qd.qd_qa_tables_id
                                            AND tc_adj.tc_column_type = 1
      -- Product column name from Quotas table
      LEFT JOIN table_columns      tc_prod  ON tc_prod.tc_entity_id = qd.qd_multiple_q_entity_id
                                            AND tc_prod.tc_tables_id = qd.qd_adj_tables_id
                                            AND tc_prod.tc_column_type = 1 -- entity column
      -- Product column name from Initial Quotas table
      LEFT JOIN table_columns      prod_iq  ON prod_iq.tc_entity_id = qd.qd_multiple_q_entity_id
                                            AND prod_iq.tc_tables_id = qd.qd_iq_tables_id
                                            AND prod_iq.tc_column_type = 1 -- entity column
      -- only one row
      CROSS JOIN (SELECT LISTAGG( 'iq.'||NAME1, ', ' ) WITHIN GROUP (ORDER BY 1) AS iq_columns,
                         LISTAGG(NAME2, ', ' ) WITHIN GROUP (ORDER BY 1 ) AS q_columns
                  FROM table (pi_lq_column_names)
                 ) col
      -- only one row
      CROSS JOIN (SELECT fld_column_name AS quota_col_name FROM fields WHERE fld_column_name = 'QUOTA' ) q
      CROSS JOIN (SELECT fld_column_name AS lower_limit_col_name FROM fields WHERE fld_column_name = 'LOWER_LIMIT' ) llim
      CROSS JOIN (SELECT fld_column_name AS upper_limit_col_name FROM fields WHERE fld_column_name = 'UPPER_LIMIT' ) ulim
      CROSS JOIN (SELECT COUNT(1) AS cnt FROM quotas_non_zero_sum_relations qnzsr WHERE qnzsr.qnzsr_qd_id = pi_lq_qd_id
                                                                                  AND qnzsr.qnzsr_allow_non_zero_sum_adj = 1
                                                                                  AND ROWNUM <= 1) allow_non_zero_sum_adj
    WHERE qd.qd_id = pi_lq_qd_id;


    EXECUTE IMMEDIATE v_sql USING OUT pout_lq_no_rec_q;


    MERGE INTO quota_versions qv
           USING (SELECT pi_lq_qd_id AS qv_qd_id,
                         pi_lq_tupr_id AS qv_tupr_id
                    FROM DUAL) qv1
              ON (qv.qv_qd_id = qv1.qv_qd_id
                 AND qv.qv_tupr_id = qv1.qv_tupr_id)
    WHEN MATCHED THEN UPDATE SET qv_process_version = qv_process_version + 1
    WHEN NOT MATCHED THEN INSERT (qv_id
                  ,qv_qd_id
                  ,qv_tupr_id
                  ,qv_version
                  ,qv_process_version)
    VALUES (UID_SEQUENCE.NEXTVAL,qv1.qv_qd_id,qv1.qv_tupr_id,0, 0);


    EXCEPTION
       WHEN NO_DATA_FOUND THEN
         raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
END LOAD_QUOTAS;

-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140818
-- Description: Procedure to populate QUOTAS ENTITIES table
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_lqe_tupr_id               IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_lqe_qd_id                 IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_lqe_column_mapping        IN TABLETYPE_NAME_MAP,                     -- mapping between column names from the INITIAL_QUOTAS table and
                                                                          --   columns from Quota Entities table
  pi_lqe_user_assign_queries   IN TABLETYPE_QUOTAS_QUERY_MAP,             -- mapping between column names from Initial Quotas and Quota Entities tables
  pi_lqe_distinct_entities     IN NUMBER,                                 -- shows if the top 2 entities from Entity Relationship are the same and if they have another entity that participates or not to the workflow
  pi_lqe_no_of_records         IN NUMBER,                                 -- number of records from TMP_IQ_HIERARCHY
  pout_lqe_no_rec_qe           OUT NUMBER                                 -- number of records inserted in Quota Entities
*/
-----------------------------------------------------------------------------------------
PROCEDURE LOAD_QUOTA_ENTITIES ( pi_lqe_tupr_id               IN tu_periods_range.tupr_id%type ,
                                pi_lqe_qd_id                 IN quota_definitions.qd_iq_tables_id%type ,
                                pi_lqe_column_mapping        IN TABLETYPE_NAME_MAP,
                                pi_lqe_user_assign_queries   IN TABLETYPE_QUOTAS_QUERY_MAP,
                                pi_lqe_distinct_entities     IN NUMBER ,
                                pi_lqe_no_of_records         IN NUMBER ,
                                pout_lqe_no_rec_qe           OUT NUMBER
                               )
AS
       v_initial_quota_cols           CLOB;
       v_quota_entities_cols          CLOB;
       v_user_assignment_join         CLOB;
       v_hierarchy_join_cond          CLOB;

       v_quota_ent_tab_name           tables.tables_physical_name% type;
       v_quota_ent_per_col_name       table_columns.tc_physical_name%type ;
       v_initial_quotas_tab_name      tables.tables_physical_name% type;
       v_initial_quotas_per_col_name  table_columns.tc_physical_name%type ;

       v_sql                          CLOB;
       v_stamp                        VARCHAR2(250 CHAR);
BEGIN
    v_stamp := 'QUOTAS.LOAD_QUOTA_ENTITIES - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lqe_tupr_id),                ',pi_lqe_tupr_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lqe_qd_id),                  ',pi_lqe_qd_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_lqe_column_mapping),     ',pi_lqe_column_mapping => <value>' , v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_lqe_user_assign_queries),',pi_lqe_user_assign_queries => <value>' , v_stamp);
    END;

    -- --------------------------------------------------------------------------------------------------
    -- Get metadata needed
    -- --------------------------------------------------------------------------------------------------
    BEGIN
        SELECT te.tables_physical_name, tce.tc_physical_name, ti.tables_physical_name, tci.tc_physical_name
          INTO v_quota_ent_tab_name, v_quota_ent_per_col_name, v_initial_quotas_tab_name, v_initial_quotas_per_col_name
        FROM         quota_definitions qd
          -- Quotas Entities
          INNER JOIN tables            te  ON te.tables_id = qd.qd_qe_tables_id
          INNER JOIN table_columns     tce ON tce.tc_tables_id = te.tables_id
                                           AND tce.tc_logic_type=8
          -- Initial Quotas
          INNER JOIN tables            ti  ON ti.tables_id = qd.qd_iq_tables_id
          INNER JOIN table_columns     tci ON tci.tc_tables_id = ti.tables_id
                                           AND tci.tc_logic_type=8
        WHERE qd.qd_id = pi_lqe_qd_id;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
    END;

    -- --------------------------------------------------------------------------------------------------
    -- The software will delete all records for the period being run from the Quota Entities
    -- --------------------------------------------------------------------------------------------------
    -- in this case, corresponding periods are not applicable because Quota Entities table holds only periods from Quota Periods table
    v_sql := 'DELETE FROM '||v_quota_ent_tab_name|| ' WHERE '||v_quota_ent_per_col_name|| ' = '||pi_lqe_tupr_id;
    EXECUTE IMMEDIATE v_sql;

    -- --------------------------------------------------------------------------------------------------
    -- Add records to the Quota Entities table
    -- --------------------------------------------------------------------------------------------------
    -- determine quota entities columns and initial quotas columns
    FOR C IN (SELECT tc.tc_physical_name as quota_entity_cols,
                     mp.name1 as initial_quota_cols,
                     e.entity_base_entity,
                     qu.quota_entities_assign_join,
                     CASE WHEN INSTR(qu.user_tc_physical_name,',')> 0
                          --    assignments are made to the same user entity (e.g. Area -> Emp; Region -> Emp)
                          THEN 'COALESCE('||qu.user_tc_physical_name||')'
                          --    assignments are made to the distinct user entity (e.g. Area -> Emp; Region -> Territory)
                          ELSE NVL2(qu.user_tc_physical_name,qu.user_tc_physical_name || ' AS rec' || qu.qua_user_entity_id, NULL )
                          END AS user_tc_physical_name
              FROM        table_columns                tc
                LEFT JOIN TABLE(pi_lqe_column_mapping) mp ON tc.tc_physical_name = mp.name2
                LEFT JOIN entities                     e  ON e.entity_id = tc.tc_entity_id
                -- user assignments
                LEFT JOIN (SELECT DISTINCT qua.qua_user_entity_id,
                                  LISTAGG( '     LEFT JOIN (' ||
                                      CASE WHEN ea.ea_entity_id_la = qua.qua_org_entity_id THEN q.QUERY
                                           ELSE 'SELECT RIGHT_ENTITY_COL AS LEFT_ENTITY_COL, LEFT_ENTITY_COL AS RIGHT_ENTITY_COL FROM ('||q.QUERY||')'
                                      END || ') at' ||ea.ea_tables_id||' ON at' || ea.ea_tables_id || '.LEFT_ENTITY_COL' ||
                                                ' = iq.' || org_tc.tc_physical_name,' ' )
                                      WITHIN GROUP (ORDER BY 1)  AS quota_entities_assign_join,
                                  LISTAGG( 'at'|| ea.ea_tables_id || '.RIGHT_ENTITY_COL',',' )
                                      WITHIN GROUP (ORDER BY 1)  AS user_tc_physical_name
                          FROM         quota_user_assignments            qua
                            INNER JOIN entity_assignments                ea        ON ea.ea_id = qua.qua_ea_id
                            INNER JOIN tables                            t         ON t.tables_id = ea.ea_tables_id
                            INNER JOIN TABLE(pi_lqe_user_assign_queries) q         ON q.object_id = ea.ea_id
                            -- find the column from initial quotas table for organization assignment
                            INNER JOIN table_columns                     org_tc    ON org_tc.tc_entity_id = qua.qua_org_entity_id
                            CROSS JOIN (SELECT qd_iq_tables_id FROM quota_definitions WHERE qd_id = pi_lqe_qd_id) qdi -- will result in one row only
                          WHERE qua.qua_qd_id = pi_lqe_qd_id
                            -- initial quotas table
                            AND org_tc.tc_tables_id = qdi.qd_iq_tables_id
                            AND qua.qua_assignment_type = 0
                            GROUP BY qua.qua_user_entity_id
                          )                        qu ON qu.qua_user_entity_id = e.entity_base_entity
                CROSS JOIN (SELECT qd_qe_tables_id FROM quota_definitions WHERE qd_id = pi_lqe_qd_id) qd
              WHERE tc.tc_tables_id = qd.qd_qe_tables_id
                AND tc.tc_physical_name != 'ROW_IDENTIFIER'
              ORDER BY tc_order
             )
    LOOP
      v_user_assignment_join := v_user_assignment_join || c.quota_entities_assign_join;
      v_quota_entities_cols  := v_quota_entities_cols||',' ||c.quota_entity_cols;
      v_initial_quota_cols   := v_initial_quota_cols|| ','||
                                CASE  WHEN C.INITIAL_QUOTA_COLS IS NOT NULL THEN 'iq.'|| C.INITIAL_QUOTA_COLS                         -- ENTITY COLUMNS FROM HIERARCHY
                                      WHEN C.QUOTA_ENTITY_COLS = v_initial_quotas_per_col_name THEN 'iq.'|| v_initial_quotas_per_col_name -- PERIOD COLUMN
                                      WHEN c.user_tc_physical_name IS NOT NULL THEN c.user_tc_physical_name                           -- USER ASSIGNMENTS
                                      -- for the upper entity columns we will take the upper value from the hierarchy
                                      WHEN C.ENTITY_BASE_ENTITY IS NOT NULL
                                           THEN 'CASE WHEN tab2.upper_entity_id = ' || C.ENTITY_BASE_ENTITY|| ' THEN tab2.upper_value END' -- UPPER ENTITY COLUMNS
                                      WHEN C.QUOTA_ENTITY_COLS = 'ROW_VERSION' THEN '0'                                               -- TECHNICAL COLUMN
                                      WHEN C.QUOTA_ENTITY_COLS = 'HIERARCHY_LEVEL' THEN 'NVL(tab2.hlevel,1) AS hlevel'
                                      WHEN C.QUOTA_ENTITY_COLS = 'STATUS' THEN 'CASE WHEN tab2.status IS NULL '||CHR( 10)||
                                                                               '       AND NVL(tab2.hlevel,1) = 1 -- hierarchy level = 1 ' ||CHR(10)||
                                                                               '     THEN ''Adjustments in progress'' ELSE status ' ||CHR(10)||
                                                                               'END AS status'
                                END||CHR(10 );
    END LOOP ;

    v_initial_quota_cols  := SUBSTR(v_initial_quota_cols, 2, LENGTH(v_initial_quota_cols));
    v_quota_entities_cols := SUBSTR(v_quota_entities_cols, 2, LENGTH(v_quota_entities_cols));




    FOR c IN (SELECT tc.tc_entity_id, tc.tc_physical_name
                FROM quota_definitions            qd
               INNER JOIN table_columns                tc  ON tc.tc_tables_id = qd.qd_qe_tables_id
               INNER JOIN table(pi_lqe_column_mapping) mp  ON tc.tc_physical_name = mp.name1
               INNER JOIN entities                     e   ON e.entity_id = tc.tc_entity_id
                LEFT  JOIN quota_entity_relations       qer ON qer.qer_qd_id = qd.qd_id
                                                          AND qer.qer_entity_id = e.entity_id
                                                          AND qer.qer_level=1
              WHERE qd.qd_id = pi_lqe_qd_id
                AND tc.tc_entity_id IS NOT NULL
                AND e.entity_base_entity IS NULL) LOOP

      v_hierarchy_join_cond := v_hierarchy_join_cond ||
               COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'LOAD_QUOTA_ENTITIES', pi_lqe_qd_id, null) || chr(10) ||
               'SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'LOAD_QUOTA_ENTITIES', pi_lqe_qd_id, null) ||
               '   iq.*, hq.upper_value, hq.upper_entity_id, hq.hlevel, hq.status FROM ' || v_initial_quotas_tab_name || ' iq
                        INNER JOIN (SELECT /*+ CARDINALITY(hrc '||pi_lqe_no_of_records|| ') */ hrc.*,' ||CHR(10 )||
               '                     CASE ' ||CHR(10)||
               '                          WHEN  -- the hierarchy instance is of an entity selected to participate in workflow' ||CHR(10)||
               '                                wf_ent.qer_entity_id IS NOT NULL' ||CHR(10)||
               CASE WHEN pi_lqe_distinct_entities IN ( 2,3 ,4)
                     THEN  '                                -- the ''Number of levels'' setting is either ''All levels'' or ''top <n> levels'' where <n> >= hlevel' ||CHR( 10)||
                           '                                AND (lvl1.qer_no_of_levels_to_release_q = 0 -- All levels' ||CHR( 10)||
                           '                                     OR lvl1.qer_no_of_levels_to_release_q >= hrc.hlevel' ||CHR( 10)||
                           '                                     )'
                     END ||CHR(10 )||
               '                          THEN ''Not available'' ' ||CHR(10)||
               '                          END AS STATUS' ||CHR(10)||
               '             FROM TMP_IQ_HIERARCHY hrc' ||CHR(10)||
               CASE WHEN pi_lqe_distinct_entities IN ( 2,3 ,4)
                     THEN '             LEFT JOIN (SELECT qer_entity_id as level_1_entity, qer_no_of_levels_to_release_q ' ||CHR( 10)||
                          '                         FROM quota_entity_relations WHERE qer_qd_id=' || pi_lqe_qd_id || ' AND qer_level = 1) LVL1 ON 1=1 '
                     END ||CHR(10 )||
               '             LEFT JOIN (SELECT qer_entity_id ' ||CHR(10)||
               '                        FROM quota_entity_relations ' ||CHR(10)||
               '                        WHERE qer_qd_id=' || pi_lqe_qd_id || ' AND qer_quota_can_be_released=1) wf_ent ON wf_ent.qer_entity_id = hrc.lower_entity_id' ||CHR( 10)||
               '             ) hq ON (hq.lower_entity_id = ' || c.tc_entity_id || ' AND hq.lower_value = iq.'||c.tc_physical_name || ')' || CHR(10) ||
               v_user_assignment_join||CHR( 10)||
               ' WHERE iq.'||v_initial_quotas_per_col_name||' = '||pi_lqe_tupr_id || ' UNION ';
    END LOOP;

    v_hierarchy_join_cond := SUBSTR(v_hierarchy_join_cond, 1, LENGTH(v_hierarchy_join_cond) - 7 );

    v_sql :=   'BEGIN' || CHR(10 ) ||
               'INSERT /*+ APPEND */ INTO '||v_quota_ent_tab_name|| ' (' || v_quota_entities_cols || ', ROW_IDENTIFIER)' ||CHR(10)||
               'SELECT TAB.*,'||CHR(10 )||
               '       '||v_quota_ent_tab_name|| '_ROW_IDENTIFIER_SEQ.NEXTVAL'||CHR(10 )||
               'FROM '||CHR(10 )||
               '('||CHR(10 )||
               -- entity columns
               ' SELECT DISTINCT '|| v_initial_quota_cols ||
               -- INITIAL QUOTAS table
               ' FROM '|| v_initial_quotas_tab_name || ' iq ' ||CHR(10)||
               -- hierarchy information (LEFT JOIN because the hierarchy does not contain level 1
               ' LEFT JOIN (' || v_hierarchy_join_cond || ') tab2'  || CHR(10) ||
               ' ON iq.row_identifier = tab2.row_identifier ' || CHR(10) ||
               -- user assigments
               v_user_assignment_join||CHR( 10)||
               -- filter the Initial Quotas table for the period being run
               ' WHERE iq.'||v_initial_quotas_per_col_name||' = '||pi_lqe_tupr_id||
               ') TAB;'|| CHR(10 ) ||
               ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
               'END;';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),     'v_sql => <value>' , v_stamp);


    EXECUTE IMMEDIATE v_sql USING OUT pout_lqe_no_rec_qe;

END LOAD_QUOTA_ENTITIES;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150112
-- Description: Procedure to populate QUOTAS PRODUCTS tables
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_lqp_tupr_id               IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_lqp_qd_id                 IN quota_definitions.qd_id%type,           -- id of the definition
  pi_lgp_table_id              IN NUMBER,                                 -- id of the products table to be populated
  pi_lqp_prev_table_id         IN NUMBER                                  -- id of the previos table used for populating products table
  pi_lqp_column_mapping        IN TABLETYPE_NAME_MAP                      -- mapping between column names from the QUOTAS table and
  pi_lqp_no_of_records         IN NUMBER                                  -- number of records from TMP_PRODUCT_HIERARCHY                                                                         -- columns from Initial Quota table

*/
-----------------------------------------------------------------------------------------
PROCEDURE LOAD_QUOTA_PRODUCTS (pi_lqp_tupr_id               IN tu_periods_range.tupr_id%TYPE ,
                               pi_lqp_qd_id                 IN quota_definitions.qd_id%TYPE ,
                               pi_lqp_table_id              IN NUMBER ,
                               pi_lqp_prev_table_id         IN NUMBER ,
                               pi_lqp_column_mapping        IN TABLETYPE_NAME_MAP,
                               pi_lpq_no_of_records         IN NUMBER )
AS
v_sql CLOB;
v_q_period_col_name     VARCHAR2(30 CHAR);
v_qprod_table_name      VARCHAR2(30 CHAR);
v_quotas_table_name     VARCHAR2(30 CHAR);
v_prod_column_name      VARCHAR2(30 CHAR);
v_include_add_fields    NUMBER(1);
l_stamp                 VARCHAR2(250 CHAR);
v_allows_non_zero_sum   NUMBER(1);

BEGIN
    l_stamp := 'QUOTAS.LOAD_QUOTAS_PRODUCTS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lqp_tupr_id),              ',pi_lq_tupr_id => <value>'       , l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lqp_qd_id),                ',pi_lq_qd_id => <value>'         , l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lqp_table_id),             ',pi_lqp_table_id => <value>'     , l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_lqp_prev_table_id),        ',pi_lqp_prev_table_id => <value>' , l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_lqp_column_mapping),   ',pi_lq_column_mapping => <value>' , l_stamp);
    END;

    SELECT COUNT(1) AS cnt
      INTO v_allows_non_zero_sum
      FROM quotas_non_zero_sum_relations qnzsr
     WHERE qnzsr.qnzsr_qd_id = pi_lqp_qd_id
       AND qnzsr.qnzsr_allow_non_zero_sum_adj = 1
       AND ROWNUM <= 1;


    SELECT tc_period.tc_physical_name, prod_col_name.tc_physical_name,
            (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 0 AND ROWNUM <= 1)
      INTO v_q_period_col_name, v_prod_column_name, v_include_add_fields
      FROM quota_definitions qd
     INNER JOIN tables t
        ON t.tables_id = qd.qd_adj_tables_id
     INNER JOIN table_columns tc_period
        ON tc_period.tc_tables_id = t.tables_id
       AND tc_period.tc_logic_type = 8
     CROSS JOIN (SELECT tc.tc_physical_name
                  FROM table_columns tc
                 WHERE tc.tc_tables_id = pi_lqp_table_id
                   AND tc.tc_column_type = 1 ) prod_col_name
     WHERE qd.qd_id = pi_lqp_qd_id;

  -- delete data from tables where period = pi_lqp_tupr_id
  SELECT 'DELETE FROM ' || t2.tables_physical_name || ' WHERE ' ||
         v_q_period_col_name || ' = ' || pi_lqp_tupr_id
    INTO v_sql
    FROM quota_definitions qd
   INNER JOIN quotas_prod_ent_relations qper
      ON qper.qper_qd_id = qd.qd_id
     AND qper.qper_tables_id = pi_lqp_table_id
   INNER JOIN tables t2
      ON qper.qper_tables_id = t2.tables_id
   WHERE qd.qd_id = pi_lqp_qd_id;


  EXECUTE IMMEDIATE v_sql;

  -- get table name of the table that needs to be populated and QUOTAS table name

  SELECT t.tables_physical_name,
         quotas_table_name.tables_physical_name
    INTO v_qprod_table_name, v_quotas_table_name
    FROM tables t
   CROSS JOIN (SELECT t2.tables_physical_name
                 FROM tables t2
                INNER JOIN quota_definitions qd
                   ON qd.qd_adj_tables_id = t2.tables_id
                  AND qd.qd_id = pi_lqp_qd_id) quotas_table_name
   WHERE t.tables_id = pi_lqp_table_id;

  -- check if previous table id = 0 => populate the second level from bottom to top based on the Quotas table
  IF pi_lqp_prev_table_id = 0 THEN
    FOR c IN (SELECT tc.tc_physical_name,
                     tc.tc_entity_id,
                     t.tables_id,
                     t.tables_physical_name,
                     tc_prod.tc_physical_name              AS product_column_name,
                     tc_prod.tc_entity_id                  AS product_entity_id
              FROM quota_definitions qd
             INNER JOIN TABLES t
                ON qd.qd_adj_tables_id = t.tables_id
             INNER JOIN table_columns tc
                ON tc.tc_tables_id = t.tables_id
             INNER JOIN TABLE(pi_lqp_column_mapping) q_cols
                ON q_cols.name1 = tc.tc_physical_name
             INNER JOIN table_columns tc_prod
                ON tc_prod.tc_entity_id = qd.qd_multiple_q_entity_id
               AND tc_prod.tc_tables_id = t.tables_id
              WHERE qd.qd_id = pi_lqp_qd_id) LOOP


       EXECUTE IMMEDIATE 'INSERT INTO ' || v_qprod_table_name || ' (' || v_q_period_col_name || ', entity_id, entity_value, ' || v_prod_column_name || ',
                                    upper_entity_value, initial_quota, adjustments, current_quota '
                                    || CASE WHEN v_include_add_fields = 1
                                            THEN ',' || GET_ADDITIONAL_FIELDS(pi_lqp_qd_id, 1)
                                       END
                                    || CASE WHEN v_allows_non_zero_sum = 1
                                            THEN ',outstanding_allocation'
                                       END
                                    || ', row_identifier, row_version)
          SELECT q.' || v_q_period_col_name ||',
                 q.entity_id          AS ENTITY_ID,
                 q.entity_value       AS ENTITY_VALUE,
                 q.upper_value,
                 q.upper_upper_value  AS UPPER_ENTITY_VALUE,
                 q.initial_quota      AS INITIAL_QUOTA,
                 q.adjustments        AS ADJUSTMENTS,
                 q.initial_quota      AS CURRENT_QUOTA,
                 ' || CASE WHEN v_include_add_fields = 1
                           THEN GET_ADDITIONAL_FIELDS(pi_lqp_qd_id, 1) || ','
                      END  || '
                 ' || CASE WHEN v_allows_non_zero_sum = 1
                           THEN ' 0 AS OUTSTANDING_ALLOCATION' || ','
                      END  || '
                 ' || v_quotas_table_name ||'_Row_Identifier_Seq.Nextval AS ROW_IDENTIFIER,
                 0 AS ROW_VERSION
          FROM ( ' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'LOAD_QUOTA_PRODUCTS_1', pi_lqp_qd_id, null) || chr(10) ||
                 'SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'LOAD_QUOTA_PRODUCTS_1', pi_lqp_qd_id, 'CARDINALITY(ph ' || pi_lpq_no_of_records || ') CARDINALITY(ph_upper ' || pi_lpq_no_of_records || ')') ||
                      ' quotas_table.' || v_q_period_col_name ||',
                        quotas_table.' || C.TC_PHYSICAL_NAME ||' AS entity_value,
                                     ' || C.TC_ENTITY_ID     || ' AS entity_id,
                        ph.upper_value,
                        SUM(quotas_table.initial_quota) AS initial_quota,' ||
                        CASE WHEN v_include_add_fields = 1
                             THEN GET_ADDITIONAL_FIELDS(pi_lqp_qd_id, 2, 'quotas_table.') || ','
                        END || '
                        0 AS adjustments,
                        ph_upper.upper_value as upper_upper_value
                  FROM ' || C.TABLES_PHYSICAL_NAME || ' quotas_table
                   LEFT JOIN TMP_PRODUCT_HIERARCHY ph
                  ON quotas_table.' || C.Product_Column_Name || ' = ph.lower_value AND ph.lower_entity_id = ' || C.Product_Entity_Id || '
                   LEFT JOIN TMP_PRODUCT_HIERARCHY ph_upper
                  ON ph_upper.lower_value = ph.upper_value and ph_upper.lower_entity_id = ph.upper_entity_id
                  WHERE ' || C.TC_PHYSICAL_NAME || ' IS NOT NULL AND quotas_table.' || v_q_period_col_name || ' = ' || pi_lqp_tupr_id || '
                  GROUP BY ' || C.TC_PHYSICAL_NAME ||', ph.upper_value, quotas_table.' || v_q_period_col_name || ', ph_upper.upper_value
            ) q' ;

   END LOOP;

   -- else populate all product tables bottom up based on the previously populated table
   ELSE
    SELECT 'INSERT INTO ' || v_qprod_table_name  || ' (' || v_q_period_col_name || ', entity_id, entity_value, ' || v_prod_column_name || ',
                                    upper_entity_value, initial_quota, adjustments, current_quota '
                                    || CASE WHEN v_include_add_fields = 1
                                            THEN ',' || GET_ADDITIONAL_FIELDS(pi_lqp_qd_id, 1)
                                       END
                                    || CASE WHEN v_allows_non_zero_sum = 1
                                            THEN ',outstanding_allocation'
                                       END
                                    || ', row_identifier, row_version)
              SELECT q.'   || v_q_period_col_name ||',
                     q.entity_id          AS ENTITY_ID,
                     q.entity_value       AS ENTITY_VALUE,
                     q.upper_value,
                     q.upper_upper_value  AS UPPER_ENTITY_VALUE,
                     q.initial_quota      AS INITIAL_QUOTA,
                     q.adjustments        AS ADJUSTMENTS,
                     q.initial_quota      AS CURRENT_QUOTA,
                     ' || CASE WHEN v_include_add_fields = 1
                           THEN GET_ADDITIONAL_FIELDS(pi_lqp_qd_id,  1) || ','
                      END  || '
                     ' || CASE WHEN v_allows_non_zero_sum = 1
                           THEN ' 0 AS OUTSTANDING_ALLOCATION' || ','
                      END  || '
                     ' || v_quotas_table_name ||'_Row_Identifier_Seq.Nextval AS ROW_IDENTIFIER, 0 AS ROW_VERSION
              FROM (' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'LOAD_QUOTA_PRODUCTS_2', pi_lqp_qd_id, null) || chr(10) ||
                   ' SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'LOAD_QUOTA_PRODUCTS_2', pi_lqp_qd_id, 'CARDINALITY(ph ' || pi_lpq_no_of_records || ') CARDINALITY(ph_upper ' || pi_lpq_no_of_records || ')') ||
                         ' src_table.'||  v_q_period_col_name || ',
                           src_table.entity_value,
                           src_table.entity_id,
                           ph.upper_value,
                           SUM(src_table.initial_quota) AS initial_quota, ' ||
                           CASE WHEN v_include_add_fields = 1
                             THEN GET_ADDITIONAL_FIELDS(pi_lqp_qd_id, 2, 'src_table.')
                           || ',' END || '
                           0 AS adjustments,
                           ph_upper.upper_value as upper_upper_value
                    FROM ' || t_prev.tables_physical_name || ' src_table
                    LEFT JOIN TMP_PRODUCT_HIERARCHY ph
                      ON src_table.' || tc_product.tc_physical_name || ' = ph.lower_value AND ph.lower_entity_id = ' || tc_product.tc_entity_id || '
                    LEFT JOIN TMP_PRODUCT_HIERARCHY ph_upper
                      ON ph_upper.lower_value = ph.upper_value and ph_upper.lower_entity_id = ph.upper_entity_id
                    WHERE src_table.' ||  v_q_period_col_name ||' = ' || pi_lqp_tupr_id || '
                    GROUP BY src_table.entity_id, src_table.entity_value, ph.upper_value, src_table.'||  v_q_period_col_name ||', ph_upper.upper_value) q'
      INTO v_sql
      FROM tables t_prev
     INNER JOIN table_columns tc_product
        ON tc_product.tc_tables_id = t_prev.tables_id
       AND tc_product.tc_column_type = 1
     WHERE t_prev.tables_id = pi_lqp_prev_table_id;


   EXECUTE IMMEDIATE v_sql;
   END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
END;
-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
FUNCTION QUOTAS_CHECK_IF_HIERAR_EXISTS( pi_qd_id IN QUOTA_DEFINITIONS.QD_ID%TYPE
                                       ,pi_hierarchy_type NUMBER
                                       ,pi_quota_entities_list VARCHAR2)
RETURN TABLETYPE_ID_NAME
AS

  v_hierarchy_info TABLETYPE_ID_NAME;
  l_stamp VARCHAR2( 250 CHAR );
  v_sql clob;

BEGIN
    l_stamp := 'QUOTAS.QUOTAS_CHECK_IF_HIERAR_EXISTS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
      BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_qd_id)                , ',pi_qd_id => <value>', l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_hierarchy_type)       ,',pi_hierarchy_type => <value>', l_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_quota_entities_list),',pi_quota_entities_list => <value>', l_stamp);
      END;

    IF pi_qd_id IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qd_id'));
    END IF ;

    IF pi_hierarchy_type IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_hierarchy_type'));
    END IF ;

    -- add check for second param
     v_sql := 'SELECT objtype_id_name(ht_id,ht_name)
                          FROM
                            (SELECT hs_is_dated,ht_id, ht_name,hs_timeunit_id,LISTAGG(hn_entity_id||''-''||hn_entity_level,'','') WITHIN GROUP (ORDER BY hn_entity_level,hn_order) AS hn_entity_ids
                             FROM
                                (SELECT hs.hs_is_dated, ht.ht_id, ht.ht_name, hn.hn_entity_id, hs.hs_timeunit_id, hn.hn_order, LEVEL AS hn_entity_level
                                 FROM hierarchy_node hn
                                 INNER JOIN hierarchy_structure hs ON hs.hs_id = hn.hn_hs_id
                                 INNER JOIN hierarchy_tables ht ON ht.ht_id = hs.hs_ht_id
                                 START WITH hn.hn_parent_node_id IS NULL
                                 CONNECT BY PRIOR hn.hn_id=hn.hn_parent_node_id) t
                            GROUP BY ht_id,ht_name,hs_timeunit_id,hs_is_dated
                            ) t '
                            -- create a list of entity ids ordered by entity level and the order of entities. The level is necessary in LISTAGG function to test an exact match. E.g.:
                            -- Employee                                             Employee
                            --      Employee            should not be equal to          Employee
                            --          Account                                         Account
                            || CASE WHEN pi_hierarchy_type = 1 THEN '
                                INNER JOIN (SELECT qd_freqd_tu_id,LISTAGG(qer_entity_id||''-''||qer_entity_level,'','') WITHIN GROUP (ORDER BY qer_entity_level,qer_order) AS entity_ids
                                            FROM (SELECT qer.qer_entity_id, qer.qer_order, qd.qd_freqd_tu_id, LEVEL as qer_entity_level
                                                   FROM quota_entity_relations qer
                                                   INNER JOIN quota_definitions qd ON qd.qd_id = qer.qer_qd_id
                                                    WHERE qer.qer_qd_id = ' || pi_qd_id || '
                                                    START WITH qer.qer_parent_node_id IS NULL
                                                    CONNECT BY PRIOR qer.qer_id=qer.qer_parent_node_id
                                                 )
                                            GROUP BY qd_freqd_tu_id
                                            ) tt ON t.hn_entity_ids=tt.entity_ids
                            LEFT JOIN tu_correspondence tc ON tc.tuc_tu_id = tt.qd_freqd_tu_id AND tc.tuc_tu_id_corr = t.hs_timeunit_id
                                            -- Check that time unit is the same. The following cases are accepted:
                                            --       Quota Frequency = Quarter and Hierarchy effective range = Quarter
                                            --       Quota Frequency = Quarter and Hierarchy effective range = none
                                            --       Quota Frequency = Quarter and Hierarchy effective range = Semester (Quarter corresponds to Semester)
                              WHERE ( ( tt.qd_freqd_tu_id = NVL(t.hs_timeunit_id, tt.qd_freqd_tu_id))
                                 OR tc.tuc_tu_id IS NOT NULL
                              )'
                             ELSE CASE WHEN pi_quota_entities_list IS NOT NULL
                                       THEN ' WHERE t.hn_entity_ids = ''' || pi_quota_entities_list || ''' AND t.hs_is_dated = 0 AND t.hs_timeunit_id IS NULL'
                                       ELSE ' WHERE t.hs_is_dated = 0 AND t.hs_timeunit_id IS NULL' END
                             END || ' ORDER BY ht_name' ;
  EXECUTE IMMEDIATE v_sql  BULK COLLECT INTO v_hierarchy_info;
  RETURN v_hierarchy_info;

END QUOTAS_CHECK_IF_HIERAR_EXISTS;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150528
-- Description: Functions that returns all data tables in the software (in alphabetical order) that have in their structure all entities specified
--- for the organization hierarchy, the entity that represents the product entity only when multiple quotas are setup for the entities
--  in the organization hierarchy and have either no effective period or range of periods or have an effective period or range of periods
--  with the same time unit as the time unit specified as the quota frequency
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_q_frequency         IN NUMBER     -- quota frequency time unit id
   pi_quota_entities_list IN VARCHAR2   -- the list of organization entities and quota entity (if multiple quotas)
*/
-----------------------------------------------------------------------------------------
FUNCTION FILTER_PERFORMANCE_TABLES(pi_q_frequency         NUMBER,
                                   pi_quota_entities_list VARCHAR2)
RETURN TABLETYPE_ID_NAME
AS

  v_data_tables_info TABLETYPE_ID_NAME;
  v_sql CLOB;

BEGIN

  v_sql := '
  SELECT objtype_id_name(dt_entities.dt_id, dt_entities.dt_name)
  FROM
  (
    SELECT dt.dt_id, dt.dt_name, LISTAGG(tc.tc_entity_id, '', '') WITHIN GROUP (ORDER BY tc.tc_entity_id) AS ent_list
      FROM data_tables dt
     INNER JOIN tables t
        ON dt.dt_tables_id = t.tables_id
     INNER JOIN table_columns tc
        ON t.tables_id = tc.tc_tables_id
     WHERE (t.tables_record_dating_option = 1
        OR (t.tables_record_dating_option IN (3, 5)
       AND t.tables_tu_id = ' || pi_q_frequency || '))
       AND tc.tc_entity_id IN (' || pi_quota_entities_list || ')
     GROUP BY dt_id, dt_name
     ORDER BY dt.dt_name
  ) dt_entities
 WHERE dt_entities.ent_list = ''' || pi_quota_entities_list || '''';

 EXECUTE IMMEDIATE v_sql BULK COLLECT INTO v_data_tables_info;


RETURN v_data_tables_info;
END FILTER_PERFORMANCE_TABLES;




FUNCTION RUN_IMPORT_VALIDATIONS( pi_qp_table_name IN VARCHAR2
                                  ,pi_qp_period_col_name IN VARCHAR2
                                  ,pi_iq_table_name IN VARCHAR2
                                  ,pi_iq_period_col_name IN VARCHAR2
                                  ,pi_iq_entity_col_name_list IN COLTYPE_ADD_FIELDS_TO_CREDIT)
  RETURN TABLETYPE_NUMBER IS
  l_stamp VARCHAR2( 250 CHAR );
  l_validations_sql   CLOB;

  l_entity_validation CLOB;
  l_no_entity_validation CLOB;

  l_err_code_list TABLETYPE_NUMBER := TABLETYPE_NUMBER();
  l_quota_col_name VARCHAR2(30 CHAR);

  BEGIN
  l_stamp := 'QUOTAS.RUN_IMPORT_VALIDATIONS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');

  BEGIN
  SELECT fld_column_name INTO l_quota_col_name FROM fields WHERE fld_column_name = 'QUOTA' ;
  EXCEPTION
   WHEN NO_DATA_FOUND THEN
    raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
  END;

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_qp_table_name),              ',pi_qp_table_name => <value>' , l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_qp_period_col_name),         ',pi_qp_period_col_name => <value>' , l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_iq_table_name),              ',pi_iq_table_name => <value>' , l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_iq_period_col_name),         ',pi_iq_period_col_name => <value>' , l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_iq_entity_col_name_list),  ',pi_iq_entity_col_name_list => <value>' , l_stamp);
    END;

    IF pi_qp_table_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qp_table_name'));
    END IF ;
    IF pi_qp_period_col_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qp_period_col_name' ));
    END IF ;
    IF pi_iq_table_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_iq_table_name'));
    END IF ;
    IF pi_iq_period_col_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_iq_period_col_name' ));
    END IF ;

    -- entity list to check if there is more than one entity per row in initial quotas
    l_validations_sql := 'SELECT LISTAGG(''NVL2(''||COLUMN_VALUE||'',1,0)'',''+'') WITHIN GROUP (ORDER BY 1)
                            FROM TABLE(:entity_col_name_list)' ;
    -- entity list to check if there is no entity per row in initial quotas
    EXECUTE IMMEDIATE l_validations_sql INTO l_entity_validation USING pi_iq_entity_col_name_list;

    l_validations_sql := 'SELECT LISTAGG(COLUMN_VALUE,'' IS NULL AND '') WITHIN GROUP (ORDER BY 1)
                                FROM TABLE(:entity_col_name_list)' ;

    EXECUTE IMMEDIATE l_validations_sql INTO l_no_entity_validation USING pi_iq_entity_col_name_list;

    -- return error codes for each validation
    l_validations_sql := 'SELECT 10001 AS error_codes FROM ' || pi_iq_table_name || ' WHERE ' || l_entity_validation || ' > 1 and ROWNUM <= 1
                          UNION ALL
                          SELECT 10002 FROM ' || pi_iq_table_name || ' WHERE ' || l_no_entity_validation || ' IS NULL AND ROWNUM <= 1
                          UNION ALL
                          SELECT 10003
                          FROM ' || pi_iq_table_name || ' WHERE ' || pi_iq_period_col_name || ' NOT IN (SELECT ' || pi_qp_period_col_name || '
                          FROM ' || pi_qp_table_name || ') AND ROWNUM <= 1'
                          || ' UNION ALL ' ||
                         'SELECT 10004 FROM '|| pi_iq_table_name ||' WHERE ' || l_quota_col_name || ' < 0 and rownum <= 1';

    EXECUTE IMMEDIATE l_validations_sql BULK COLLECT INTO l_err_code_list;
    RETURN l_err_code_list;
END RUN_IMPORT_VALIDATIONS;

PROCEDURE RUN_LOAD_VALIDATIONS ( pi_qp_table_name             IN VARCHAR2
                                ,pi_qp_period_col_name        IN VARCHAR2
                                ,pi_temp_table_name           IN VARCHAR2
                                ,pi_temp_period_col_name      IN VARCHAR2
                                ,pi_temp_entity_col_name_list IN COLTYPE_ADD_FIELDS_TO_CREDIT
                                ,pio_validation_clauses       IN OUT TABLETYPE_OBJECTIVE_LOAD_VLD
                                )
AS

  l_validations_sql CLOB;
  l_entity_validation CLOB;
  l_no_entity_validation CLOB;
  l_quota_col_name VARCHAR2(30 CHAR);
  l_stamp VARCHAR2( 250 CHAR );
  l_idx PLS_INTEGER;

BEGIN
    l_stamp := 'QUOTAS.RUN_LOAD_VALIDATIONS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_qp_table_name),              ', pi_qp_table_name => <value>', l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_qp_period_col_name),         ', pi_qp_period_col_name => <value>', l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_temp_table_name),            ', pi_temp_table_name => <value>', l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_temp_period_col_name),       ', pi_temp_period_col_name => <value>', l_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_temp_entity_col_name_list),', pi_temp_entity_col_name_list => <value>', l_stamp);
    END;

    IF pi_qp_table_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qp_table_name'));
    END IF ;
    IF pi_qp_period_col_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qp_period_col_name' ));
    END IF ;
    IF pi_temp_table_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_temp_table_name'));
    END IF ;
    IF pi_temp_period_col_name IS NULL THEN
      raise_application_error(commons_exceptions.e_NullParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_temp_period_col_name' ));
    END IF ;

    BEGIN
      SELECT fld_column_name INTO l_quota_col_name FROM fields WHERE fld_column_name = 'QUOTA' ;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);
    END;

    -- entity column name list to check if there is more than one entity in a row in initial quotas
    l_validations_sql := 'SELECT LISTAGG(''NVL2(''||COLUMN_VALUE||'',1,0)'',''+'') WITHIN GROUP (ORDER BY 1)
                              FROM TABLE(:entity_col_name_list)' ;
    EXECUTE IMMEDIATE l_validations_sql INTO l_entity_validation USING pi_temp_entity_col_name_list;

    -- entity column name list to check if there is no entity in a row in initial quotas
    l_validations_sql := 'SELECT LISTAGG(COLUMN_VALUE,'' IS NULL AND '') WITHIN GROUP (ORDER BY 1)
                                  FROM TABLE(:entity_col_name_list)' ;

    EXECUTE IMMEDIATE l_validations_sql INTO l_no_entity_validation USING pi_temp_entity_col_name_list;

    -- build validations
    l_idx := pio_validation_clauses.FIRST;
    WHILE (l_idx IS NOT NULL)
    LOOP
      IF (pio_validation_clauses(l_idx).VLD_ID = 10001)
      THEN
        -- validation for more than one entity in row
        pio_validation_clauses(l_idx).VLD_WHEN_CLAUSE := 'CASE WHEN ' || l_entity_validation || ' > 1 THEN 0 ELSE 1 END' ;

      ELSIF (pio_validation_clauses(l_idx).VLD_ID = 10002)
      THEN
        -- validation for no entity in row
        pio_validation_clauses(l_idx).VLD_WHEN_CLAUSE := 'CASE WHEN ' || l_no_entity_validation || ' IS NULL THEN 0 ELSE 1 END' ;

      ELSIF (pio_validation_clauses(l_idx).VLD_ID = 10003)
      THEN
        -- validation for period not in quota periods table
        pio_validation_clauses(l_idx).VLD_WHEN_CLAUSE := 'CASE WHEN NOT EXISTS (SELECT 1 FROM ' || pi_qp_table_name || ' QP WHERE QP.'
                                                                || pi_qp_period_col_name || ' = ' || pi_temp_table_name ||'.' || pi_temp_period_col_name || ') THEN 0 ELSE 1 END' ;
      ELSIF (pio_validation_clauses(l_idx).VLD_ID = 10004)
      THEN
        -- validation for negative quota value
        pio_validation_clauses(l_idx).VLD_WHEN_CLAUSE := 'CASE WHEN ' || pi_temp_table_name || '.' || l_quota_col_name || ' < 0 THEN 0 ELSE 1 END';

      END IF ;

    l_idx := pio_validation_clauses.NEXT(l_idx);
    END LOOP ;

  END RUN_LOAD_VALIDATIONS;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160404
-- Description: Procedure that calculates additional fields
-- http://confluence.optymyze.net/display/Quotas/Quotas+-+Support+calculated+additional+fields+display+in+Quotas+Management+app
-----------------------------------------------------------------------------------------
-- Parameters:
/*
   pi_cqf_tupr_id             IN tu_periods_range.tupr_id%TYPE -- Period on which the process is being run
   pi_cqf_qd_id               IN quota_definitions.qd_id%TYPE  -- Quota definition ID
   pi_cqf_q_table_name        IN VARCHAR2                      -- Quotas table name
   pi_cqf_q_mapping           IN TABLETYPE_NAME_MAP            -- Mapping between columns from Quotas and Initial Quotas table
   pi_cqf_calling_process     IN NUMBER -- 1 - LIQ, 2 - CAI    -- The process which calls the procedure : 1 - Load Initial Quotas, 2 - Calculate Add Info
   pi_cqf_quotas_table_query  IN CLOB                          -- Query that calculates additional fields in Quotas table
   pi_cqf_qe_table_query1     IN CLOB                          -- Query that calculates additional fields in Quotas product table 1
                                                               -- There are maximum 3 levels in the products hierarchy, so there cand be max 3 update queries
   pi_cfq_qe_table_query2     IN CLOB                          -- Query that calculates additional fields in Quotas product table 2
   pi_cfq_qe_table_query3     IN CLOB                          -- Query that calculates additional fields in Quotas product table 3
   pout_cqf_no_rec_failed     OUT NUMBER                       -- Number of records that failed

*/
-----------------------------------------------------------------------------------------
PROCEDURE CALCULATE_QUOTAS_FIELDS(  pi_cqf_tupr_id             IN tu_periods_range.tupr_id%TYPE
                                   ,pi_cqf_qd_id               IN quota_definitions.qd_id%TYPE
                                   ,pi_cqf_q_table_name        IN VARCHAR2
                                   ,pi_cqf_q_mapping           IN TABLETYPE_NAME_MAP
                                   ,pi_cqf_calling_process     IN NUMBER
                                   ,pi_cqf_quotas_table_query  IN CLOB
                                   ,pi_cqf_qe_table_query1     IN CLOB
                                   ,pi_cfq_qe_table_query2     IN CLOB
                                   ,pi_cfq_qe_table_query3     IN CLOB
                                   ,pout_cqf_no_rec_failed     OUT NUMBER
                                  )
IS
v_entity_table_join      CLOB;
v_entity_name_clause     CLOB;
v_org_entities_join      CLOB;
v_entity_bk_list         CLOB;
v_calculated_fields_list CLOB;
v_sql                    CLOB;
v_quota_ent_joins        CLOB;
v_prod_hierarchy_defined NUMBER(1);
v_quotas_table_id        NUMBER(10);
v_stamp                  VARCHAR2(250 CHAR);
v_prod_col_name          VARCHAR2(30 CHAR);
v_prod_entity_bk_col     VARCHAR2(30 CHAR);
v_prod_entity_name       VARCHAR2(30 CHAR);
v_prod_entity_table      VARCHAR2(30 CHAR);
v_period_column_name     VARCHAR2(30 CHAR);

BEGIN

  --------------------------------------------------------
  -- 1. truncate error logging table and validations table
  --------------------------------------------------------

  EXECUTE IMMEDIATE 'TRUNCATE TABLE QUOTAS_ERROR_LOGS';

  ------------------------------------
  -- 2. get info
  ------------------------------------

  SELECT qd.qd_adj_tables_id INTO v_quotas_table_id FROM quota_definitions qd WHERE qd.qd_id = pi_cqf_qd_id;

  SELECT LISTAGG(' LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = q.' || tc.tc_physical_name, ' ')
          WITHIN GROUP (ORDER BY 1) AS entity_table_join,
         LISTAGG( ' WHEN ' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ' IS NOT NULL THEN ''' || REPLACE(e.entity_name, CHR(39 ), CHR(39)||CHR( 39)) || '''' , ' ')
          WITHIN GROUP (ORDER BY 1) as entity_name_clause,
         LISTAGG( '( dt.' || tc.tc_physical_name || ' = ' || 'q.' || tc.tc_physical_name || CASE WHEN prod_col_name.tc_physical_name IS NOT NULL
                                                                                                THEN ' AND dt.' || prod_col_name.tc_physical_name || ' = q.' || prod_col_name.tc_physical_name
                                                                                           END || ')' , ' OR ')
          WITHIN GROUP (ORDER BY 1) as org_entities_join,
         LISTAGG( 'TO_CHAR(' || t.tables_physical_name || '.' || tcbk.tc_physical_name || ')' , ', ')
          WITHIN GROUP (ORDER BY 1) as entity_bk_list,
         LISTAGG(' LEFT JOIN ' || t.tables_physical_name || ' ON ' || t.tables_physical_name || '.e_internal_id = q.entity_value AND q.entity_id = ' || tc.tc_entity_id, ' ')
          WITHIN GROUP (ORDER BY 1) AS quotas_ent_joins,
         prod_col_name.tc_physical_name,
         prod_col_name.prod_bk_col,
         prod_col_name.prod_entity_name,
         prod_col_name.prod_entity_table,
         calculated_fields.cf_list,
         qd.qd_include_quota_hierarchy,
         period_column_name.tc_physical_name
    INTO v_entity_table_join, v_entity_name_clause, v_org_entities_join, v_entity_bk_list, v_quota_ent_joins,
         v_prod_col_name, v_prod_entity_bk_col, v_prod_entity_name, v_prod_entity_table, v_calculated_fields_list,
         v_prod_hierarchy_defined, v_period_column_name
    FROM quota_definitions qd
    -- quotas table columns
   INNER JOIN table_columns tc           ON tc.tc_tables_id = qd.qd_adj_tables_id
   INNER JOIN TABLE(pi_cqf_q_mapping) mp ON tc.tc_physical_name = mp.name1
   INNER JOIN entities e                 ON e.entity_id = tc.tc_entity_id
   -- entity table
   INNER JOIN tables t                   ON t.tables_id = e.entity_tables_id
   -- bk column name
   INNER JOIN table_columns tcbk         ON tcbk.tc_tables_id = t.tables_id
                                         AND tcbk.tc_logic_type IN (1, 5)
   -- product column name
   LEFT JOIN (SELECT tc.tc_physical_name, e.entity_name as prod_entity_name, tcbk.tc_physical_name as prod_bk_col, tbk.tables_physical_name as prod_entity_table
                 FROM quota_definitions qd
                INNER JOIN tables t           ON t.tables_id = qd.qd_adj_tables_id
                INNER JOIN table_columns tc   ON tc.tc_tables_id = t.tables_id
                                              AND qd.qd_multiple_q_entity_id = tc.tc_entity_id
                INNER JOIN entities e         ON e.entity_id = tc.tc_entity_id
                INNER JOIN tables tbk         ON tbk.tables_id = e.entity_tables_id
                INNER JOIN table_columns tcbk ON tcbk.tc_tables_id = tbk.tables_id
                                              AND tcbk.tc_logic_type IN (1, 5)
               WHERE qd.qd_id = pi_cqf_qd_id) prod_col_name
   ON 1 = 1
   LEFT JOIN (SELECT tc.tc_physical_name
                FROM quota_definitions qd
               INNER JOIN table_columns tc
                  ON tc.tc_tables_id = qd.qd_adj_tables_id
                 AND tc.tc_logic_type = 8
               WHERE qd.qd_id = pi_cqf_qd_id
              ) period_column_name
   ON 1 = 1
   LEFT JOIN (SELECT LISTAGG(tc.tc_physical_name || ' = NULL ', ',') WITHIN GROUP(ORDER BY tc_order) AS cf_list
                FROM quota_additional_fields qaf
               INNER JOIN table_columns tc
                  ON tc.tc_fld_id = qaf.qaf_field_id
                 AND tc.tc_tables_id = v_quotas_table_id
               WHERE qaf.qaf_qd_id = pi_cqf_qd_id
                 AND qaf.qaf_type = 1) calculated_fields
   ON 1 = 1
   WHERE qd.qd_id = pi_cqf_qd_id
   GROUP BY prod_col_name.tc_physical_name,
            prod_col_name.prod_bk_col,
            prod_col_name.prod_entity_name,
            prod_col_name.prod_entity_table,
            calculated_fields.cf_list,
            qd.qd_include_quota_hierarchy,
            period_column_name.tc_physical_name;


  ----------------------------------------------------------------------------------------------------------
  -- 3. set calculated fields to NULL in case the procedure is called from Calculate Additional Info Process
  ----------------------------------------------------------------------------------------------------------

  IF pi_cqf_calling_process = 2 THEN
    EXECUTE IMMEDIATE 'UPDATE ' || pi_cqf_q_table_name || ' SET ' || v_calculated_fields_list || ' WHERE ' || v_period_column_name || ' = ' || pi_cqf_tupr_id;
  END IF;


   EXECUTE IMMEDIATE pi_cqf_quotas_table_query;

   IF pi_cqf_qe_table_query1 IS NOT NULL THEN
    EXECUTE IMMEDIATE pi_cqf_qe_table_query1;
   END IF;

   IF pi_cfq_qe_table_query2 IS NOT NULL THEN
    EXECUTE IMMEDIATE pi_cfq_qe_table_query2;
   END IF;

   IF pi_cfq_qe_table_query3 IS NOT NULL THEN
    EXECUTE IMMEDIATE pi_cfq_qe_table_query3;
   END IF;


  ----------------------------------------------------------------------------------------------------------
  -- 4. insert into validations table failed records from Quotas table
  ----------------------------------------------------------------------------------------------------------
  v_sql :=  ' BEGIN ' || chr(10 ) ||
            '   INSERT INTO TEMP_QUOTAS_ATT_VALIDATIONS' || chr(10) ||
            '     (TQAV_ROW_IDENTIFIER,' || chr(10) ||
            '      TQAV_IQ_ROW_IDENTIFIER,' || chr(10) ||
            '      TQAV_VALIDATION_ID,' || chr(10) ||
            '      TQAV_ENTITY_NAME,' || chr(10) ||
            '      TQAV_ENTITY_VALUE,' || chr(10) ||
            '      TQAV_ERROR_MESSAGE)' || chr(10) ||
            '     SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, d.*' || chr(10) ||
            '       FROM (' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'ATT_VALIDATE_10023', pi_cqf_qd_id, null) ||
            '             SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'ATT_VALIDATE_10023', pi_cqf_qd_id, null) ||
            '                    NULL  AS TQAV_IQ_ROW_IDENTIFIER,' || chr(10) ||
            '                    10027 AS TQAV_VALIDATION_ID,' || chr(10) ||
            '                    CASE ' || v_entity_name_clause || ' END AS TQAV_ENTITY_NAME,' || chr( 10) ||
            '                    COALESCE(' || v_entity_bk_list || ', NULL ) AS TQAV_ENTITY_VALUE' || chr( 10) ||
                                 CASE WHEN v_prod_col_name IS NOT NULL THEN
            '                    ,' || v_prod_entity_table || '.' || v_prod_entity_bk_col ||' || '' (' || v_prod_entity_name || ')'''  || ' AS TQAV_ERROR_MESSAGE ' ELSE ',NULL' END || chr(10) ||
            '               FROM ' || pi_cqf_q_table_name || ' q' || chr(10) ||
            '                ' || v_entity_table_join || chr(10 ) ||
            '                ' || CASE WHEN v_prod_col_name IS NOT NULL
                                       THEN ' LEFT JOIN ' || v_prod_entity_table || ' ON ' || v_prod_entity_table || '.e_internal_id = q.' || v_prod_col_name
                                  END || chr(10 ) ||
            '              WHERE q.' || v_period_column_name || ' = ' || pi_cqf_tupr_id || chr(10) ||
            '                AND EXISTS (SELECT 1 FROM quotas_error_logs qel WHERE qel.ORA_ERR_ROWID$ = q.rowid AND qel.ORA_ERR_TAG$ = ''' || pi_cqf_q_table_name || ''')) d; ' || chr(10) ||
            ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10 ) ||
            'END;';

    v_stamp := 'QUOTAS.CALCULATE_QUOTAS_FIELDS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),',v_sql => <value>' , v_stamp);

    IF pi_cqf_calling_process = 1 THEN
      v_sql := REPLACE(REPLACE(v_sql, 'TQAV', 'TQV'), 'TEMP_QUOTAS_ATT_VALIDATIONS', 'TEMP_QUOTAS_VALIDATIONS');
    END IF;


    EXECUTE IMMEDIATE v_sql USING OUT pout_cqf_no_rec_failed;

    ----------------------------------------------------------------------------------------------------------
    -- 5. insert into validations table failed records from products table
    ----------------------------------------------------------------------------------------------------------

    IF v_prod_hierarchy_defined = 1 THEN
    -- max 3 rows returned by for clause
      FOR c IN (SELECT qper.qper_tables_id, tc.tc_physical_name, t.tables_physical_name, e.entity_name,
                       t_ent.tables_physical_name AS quota_entity_table, tc_ent.tc_physical_name AS quota_ent_bk
                 FROM quotas_prod_ent_relations qper
                INNER JOIN tables t
                   ON t.tables_id = qper.qper_tables_id
                INNER JOIN table_columns tc
                   ON tc.tc_tables_id = t.tables_id
                  AND tc.tc_entity_id = qper.qper_entity_id
                INNER JOIN entities e
                   ON qper.qper_entity_id = e.entity_id
                INNER JOIN tables t_ent
                   ON t_ent.tables_id = e.entity_tables_id
                INNER JOIN table_columns tc_ent
                   ON t_ent.tables_id = tc_ent.tc_tables_id
                  AND tc_ent.tc_logic_type IN (1, 5)
                WHERE qper.qper_tables_id IS NOT NULL AND qper_qd_id = pi_cqf_qd_id) LOOP
        v_sql :=  ' BEGIN ' || chr(10 ) ||
                  '   INSERT INTO TEMP_QUOTAS_ATT_VALIDATIONS' || chr(10) ||
                  '     (TQAV_ROW_IDENTIFIER,' || chr(10) ||
                  '      TQAV_IQ_ROW_IDENTIFIER,' || chr(10) ||
                  '      TQAV_VALIDATION_ID,' || chr(10) ||
                  '      TQAV_ENTITY_NAME,' || chr(10) ||
                  '      TQAV_ENTITY_VALUE,' || chr(10) ||
                  '      TQAV_ERROR_MESSAGE)' || chr(10) ||
                  '     SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, d.*' || chr(10) ||
                  '       FROM (' || COMMONS_PROCESSING.GET_HINT_LOCATION_NAME('QUOTAS', 'ATT_VALIDATE_10023', pi_cqf_qd_id, null) ||
                  '             SELECT ' || COMMONS_PROCESSING.GET_HINTS('QUOTAS', 'ATT_VALIDATE_10023', pi_cqf_qd_id, null) ||
                  '                    NULL  AS TQAV_IQ_ROW_IDENTIFIER,' || chr(10) ||
                  '                    10027 AS TQAV_VALIDATION_ID,' || chr(10) ||
                  '                    CASE ' || v_entity_name_clause || ' END AS TQAV_ENTITY_NAME,' || chr( 10) ||
                  '                    COALESCE(' || v_entity_bk_list || ', NULL ) AS TQAV_ENTITY_VALUE' || chr( 10) ||
                  '                    ,' || c.quota_entity_table || '.' || c.quota_ent_bk ||' || '' (' || c.entity_name || ')'''  || ' AS TQAV_ERROR_MESAGE ' || chr(10) ||
                  '               FROM ' || c.tables_physical_name || ' q' || chr(10) ||
                  '                ' || v_quota_ent_joins || chr(10 ) ||
                  '                LEFT JOIN ' || c.quota_entity_table || ' ON ' || c.quota_entity_table || '.e_internal_id = q.' || c.tc_physical_name || chr(10) ||
                  '              WHERE q.' || v_period_column_name || ' = ' || pi_cqf_tupr_id || chr(10) ||
                  '                AND EXISTS (SELECT 1 FROM quotas_error_logs qel WHERE qel.ORA_ERR_ROWID$ = q.rowid AND qel.ORA_ERR_TAG$ = ''' || c.tables_physical_name || ''')) d; ' || chr(10) ||
                  ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10 ) ||
                  'END;';

      IF pi_cqf_calling_process = 1 THEN
        v_sql := REPLACE(REPLACE(v_sql, 'TQAV', 'TQV'), 'TEMP_QUOTAS_ATT_VALIDATIONS', 'TEMP_QUOTAS_VALIDATIONS');
      END IF;

      EXECUTE IMMEDIATE v_sql USING OUT pout_cqf_no_rec_failed; -- to be changed to add the above failed rows
      END LOOP;
   END IF;

END CALCULATE_QUOTAS_FIELDS;
-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20151215
-- Description: Procedure that calculates quota contribution
-- http://confluence.optymyze.net/pages/viewpage.action?pageId=19726370
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_iq_q_mapping         IN TABLETYPE_NAME_MAP,                     -- mapping between column names from Initial Quotas and Quotas tables
  pi_hierarchy_query      IN CLOB                                    -- hierarchy query
  pi_create_temp_tables   IN BOOLEAN DEFAULT TRUE                    -- true - repopulate temp tables in case the process in ran with attainment
                                                                               as a stand alone process
                                                                     -- false - when the procedure is ran from Load Initial Quotas process
  pi_adjusting_records    IN NUMBER DEFAULT NULL                     -- 1 - if the procedure is called from SAVE procedure (adjustments from the view)
                                                                     --     not all records will be updated by calculating q contribution
                                                                     -- 0 - called from process - all records must be updated with q contrib
  pi_no_of_adj_records    IN NUMBER DEFAULT NULL                     -- if pi_adjusting_records = 1 get number of adjusted rows to use for cardinality hint

*/
-----------------------------------------------------------------------------------------
PROCEDURE CALCULATE_QUOTA_CONTRIBUTION( pi_qd_id                IN quota_definitions.qd_id%TYPE,
                                        pi_tupr_id              IN NUMBER,
                                        pi_iq_q_mapping         IN TABLETYPE_NAME_MAP,
                                        pi_hierarchy_query      IN CLOB,
                                        pi_ht_cardinality       IN NUMBER DEFAULT NULL,
                                        pi_create_temp_tables   IN BOOLEAN DEFAULT TRUE,
                                        pi_adjusting_records    IN NUMBER DEFAULT NULL,
                                        pi_no_of_adj_records    IN NUMBER DEFAULT NULL,
                                        pi_modified_parent_map  IN TABLETYPE_ID_ENTITY_VALUE,
                                        pi_no_of_updated_rec    OUT NUMBER)
AS
v_include_q_hierarchy NUMBER(1);
v_period_col_name     VARCHAR2(30 CHAR);
v_populate_temp_sql   CLOB;
v_no_of_records       NUMBER;
v_stamp               VARCHAR2(250 CHAR);
v_quotas_table_id     NUMBER(10);
v_quotas_table_name   VARCHAR2(30 CHAR);
v_quota_entity_id     NUMBER(10);
v_product_col_name    VARCHAR2(30 CHAR);
v_temp_id_cardinality NUMBER(10);
v_sql                 CLOB;
v_children_ent_list   CLOB;
v_children_ent_ids    CLOB;


BEGIN

 SELECT t.tables_id, t.tables_physical_name, qd.qd_multiple_q_entity_id, tc.tc_physical_name
   INTO v_quotas_table_id, v_quotas_table_name, v_quota_entity_id, v_product_col_name
   FROM quota_definitions qd
  INNER JOIN tables t
     ON qd.qd_adj_tables_id = t.tables_id
  LEFT JOIN table_columns tc
     ON qd.qd_multiple_q_entity_id = tc.tc_entity_id
    AND tc.tc_tables_id = t.tables_id
  WHERE qd.qd_id = pi_qd_id;

 SELECT tc_period.tc_physical_name
   INTO v_period_col_name
   FROM table_columns tc_period
  INNER JOIN tables q_table
     ON q_table.tables_id = tc_period.tc_tables_id
  INNER JOIN quota_definitions qd
     ON q_table.tables_id = qd.qd_adj_tables_id
  WHERE qd.qd_id = pi_qd_id
    AND tc_period.tc_logic_type = 8;


 IF pi_create_temp_tables THEN
    EXECUTE IMMEDIATE 'TRUNCATE TABLE tmp_iq_hierarchy';
    SELECT
       'BEGIN
        INSERT INTO tmp_iq_hierarchy(upper_entity_id, lower_entity_id, upper_value, lower_value)
        WITH ent_values_list AS
        (
            SELECT COALESCE(' || children_ent_list|| ', NULL) AS lower_ent, COALESCE(' || children_ent_ids || ') AS lower_val,
                   COALESCE(' || parent_ent_list || ', NULL) AS upper_ent, COALESCE(' || parent_ent_ids || ') AS upper_val
            FROM ' || qe_table_name.tables_physical_name || '
           WHERE ' || v_period_col_name || ' = ' || pi_tupr_id || '
        )
        SELECT upper_ent, lower_ent, upper_val, lower_val
          FROM ent_values_list
         WHERE upper_ent IS NOT NULL;' || CHR(10) ||
         ':SQLROWCNT := SQL%ROWCOUNT;' || CHR(10) ||
         'END;', children_ent_list, children_ent_ids
    INTO v_populate_temp_sql, v_children_ent_list, v_children_ent_ids
    FROM
    (
      SELECT LISTAGG(' CASE WHEN ' || tc.tc_physical_name || ' IS NOT NULL THEN ' || e.entity_base_entity || ' END' , ', ') WITHIN GROUP (ORDER BY 1) AS parent_ent_list,
             LISTAGG(tc.tc_physical_name ||', NULL ', ', ') WITHIN GROUP (ORDER BY 1) AS parent_ent_ids,
             lower_entities.children_ent_list,
             lower_entities.children_ent_ids
       FROM table_columns tc
      INNER JOIN entities e
        ON tc.tc_entity_id = e.entity_id
      CROSS JOIN (SELECT LISTAGG (' CASE WHEN ' || name1 || ' IS NOT NULL THEN ' || tc.tc_entity_id || ' END', ', ') WITHIN GROUP (ORDER BY 1) AS children_ent_list,
                         LISTAGG (tc.tc_physical_name || ', NULL ', ', ') WITHIN GROUP (ORDER BY 1) AS children_ent_ids
                   FROM TABLE(pi_iq_q_mapping) mp
                  INNER JOIN table_columns tc
                    ON tc.tc_physical_name = mp.name1
                   AND tc.tc_tables_id = (SELECT qd.qd_qe_tables_id from quota_definitions qd where qd_id = pi_qd_id)
                  ) lower_entities
      WHERE tc.tc_tables_id = (SELECT qd.qd_qe_tables_id FROM quota_definitions qd WHERE qd_id = pi_qd_id)
        AND e.entity_base_entity IS NOT NULL
        AND e.entity_base_entity NOT IN (SELECT qua.qua_user_entity_id FROM quota_user_assignments qua WHERE qua.qua_qd_id = pi_qd_id AND qua.qua_assignment_type = 0)
      GROUP BY lower_entities.children_ent_list,
                lower_entities.children_ent_ids
    )
    CROSS JOIN (SELECT t.tables_physical_name FROM tables t
                 INNER JOIN quota_definitions qd
                    ON qd.qd_qe_tables_id = t.tables_id
                 WHERE qd.qd_id = pi_qd_id) qe_table_name;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), 'Populate TMP_IQ_HIERARCHY => <value>' , v_stamp);
    EXECUTE IMMEDIATE v_populate_temp_sql USING OUT v_no_of_records;


       -- when the quota contribution is called from SAVE and the parent is adjusted, get all children for modified parent to calculate contribution
       IF pi_modified_parent_map IS NOT NULL THEN


         EXECUTE IMMEDIATE
          'BEGIN ' || chr(10) ||
          'INSERT INTO TEMP_ID(ID) ' || chr(10) ||
          ' WITH parent AS' || chr(10) ||
          ' (SELECT modified_parent.entity_id,' || chr(10) ||
          '         modified_parent.entity_e_internal_id,' || chr(10) ||
          '         modified_parent.id' || chr(10) ||
          '    FROM TABLE(:pi_svqmm_modified_parent_map) modified_parent)' || chr(10) ||
          'SELECT quotas_table.row_identifier' || chr(10) ||
          '  FROM (SELECT /*+CARDINALITY tmp ' || v_no_of_records || '*/ tmp.lower_entity_id,' || chr(10) ||
          '               tmp.lower_value,' || chr(10) ||
          '               CONNECT_BY_ROOT parent.id as product_id' || chr(10) ||
          '          FROM tmp_iq_hierarchy tmp' || chr(10) ||
          '          LEFT JOIN parent' || chr(10) ||
          '            ON tmp.upper_entity_id = parent.entity_id' || chr(10) ||
          '           AND tmp.upper_value = parent.entity_e_internal_id' || chr(10) ||
          '         START WITH (tmp.upper_entity_id, tmp.upper_value) =' || chr(10) ||
          '                    (SELECT modified_parent.entity_id,' || chr(10) ||
          '                            modified_parent.entity_e_internal_id' || chr(10) ||
          '                       FROM parent modified_parent FETCH FIRST ROW ONLY)' || chr(10) ||
          '        CONNECT BY PRIOR lower_entity_id = upper_entity_id' || chr(10) ||
          '               AND PRIOR lower_value = upper_value) children' || chr(10) ||
          ' INNER JOIN ' || v_quotas_table_name || ' quotas_table' || chr(10) ||
          '    ON children.lower_entity_id = COALESCE(' || v_children_ent_list|| ', NULL) ' || chr(10) ||
          '   AND children.lower_value =  COALESCE(' || v_children_ent_ids || ')' || chr(10) ||
          ' WHERE ' || v_period_col_name || ' = ' || pi_tupr_id || ';' || chr(10) ||
          ':SQLROWCNT := SQL%ROWCOUNT;' || chr(10) ||
         'END;' USING IN pi_modified_parent_map, OUT v_temp_id_cardinality;
         END IF;


  END IF;

  -- 1. Calculate Quota Contribution at organization hierarchy levels

  FOR c IN (SELECT DISTINCT tmp_iq.lower_entity_id,
                            tc.tc_physical_name AS lower_column_name,
                            tmp_iq.upper_entity_id,
                            tc_upper.tc_physical_name AS upper_column_name
              FROM tmp_iq_hierarchy tmp_iq
             INNER JOIN table_columns tc
                ON tmp_iq.lower_entity_id = tc.tc_entity_id
               AND tc.tc_tables_id = v_quotas_table_id
             INNER JOIN table_columns tc_upper
                ON tmp_iq.upper_entity_id = tc_upper.tc_entity_id
               AND tc_upper.tc_tables_id = v_quotas_table_id
  )
  LOOP
    v_sql := v_sql ||
             'SELECT /*+ CARDINALITY(tmp_iq ' || CASE WHEN pi_create_temp_tables THEN v_no_of_records ELSE pi_ht_cardinality END || ')*/' || chr(10) ||
             '           q.row_identifier, ' || chr(10) ||
             '           q.quota_contribution, ' || chr(10) ||
             '           q_parents.current_quota, ' || chr(10) ||
             '           ROUND(q.current_quota / ' || chr(10) ||
             '                 DECODE(q_parents.current_quota, ' || chr(10) ||
             '                        0, ' || chr(10) ||
             '                        NULL, ' || chr(10) ||
             '                        q_parents.current_quota), ' || chr(10) ||
             '                 4) AS quota_contrib ' || chr(10) ||
             '            FROM ' || v_quotas_table_name || ' q ' || chr(10) ||
             '            INNER JOIN tmp_iq_hierarchy tmp_iq ' || chr(10) ||
             '              ON q.' || c.lower_column_name || ' = tmp_iq.lower_value AND ' || chr(10) ||
             '                 tmp_iq.lower_entity_id = ' || c.lower_entity_id || chr(10) ||
             '            INNER JOIN ' || v_quotas_table_name || ' q_parents' || chr(10) ||
             '              ON q_parents.' || c.upper_column_name || ' = tmp_iq.upper_value AND ' || chr(10) ||
             '                 tmp_iq.upper_entity_id = ' || c.upper_entity_id || chr(10) ||
             CASE WHEN v_quota_entity_id IS NOT NULL THEN
             '             AND q_parents.' || v_product_col_name || ' = q.' || v_product_col_name END || chr(10) ||
             '             AND q_parents.' || v_period_col_name  || ' = q.' || v_period_col_name  || chr(10) ||
             '           WHERE q.' || v_period_col_name  || ' = ' || pi_tupr_id || chr(10) ||
             CASE WHEN pi_adjusting_records = 1 THEN
             '             AND q.row_identifier IN ' || chr(10) ||
             '           (SELECT /*+ CARDINALITY(t ' || pi_no_of_adj_records || ')*/ '|| chr(10) ||
             '                   t.tqms_adj_row_identifier ' || chr(10) ||
             '              FROM temp_quotas_modify_save t ' || chr(10) ||
             '            UNION ' || chr(10) ||
             '            SELECT /*+ CARDINALITY(temp_id ' || NVL(v_temp_id_cardinality, 0) || ')*/ '|| chr(10) ||
             '                   id ' || chr(10) ||
             '              FROM temp_id )' END || chr(10) ||
             ' UNION ALL ';
  END LOOP;

  v_sql := SUBSTR(v_sql, 1, LENGTH(v_sql) - 11);
  v_sql := 'BEGIN ' ||
           'MERGE INTO ' || v_quotas_table_name || ' dst'               || chr(10) ||
           'USING ( ' || v_sql || ') src '                              || chr(10) ||
           'ON (src.row_identifier = dst.row_identifier)'               || chr(10) ||
           'WHEN MATCHED THEN'                                          || chr(10) ||
           '  UPDATE SET dst.quota_contribution = src.quota_contrib;'   || chr(10) ||
           ':SQLROWCNT := SQL%ROWCOUNT;'                                || chr(10) ||
          'END;';



   EXECUTE IMMEDIATE v_sql USING OUT pi_no_of_updated_rec;

   -- 2. Calculate Quota Contribution at quota hierarchy levels

   SELECT qd.qd_include_quota_hierarchy INTO v_include_q_hierarchy FROM quota_definitions qd WHERE qd.qd_id = pi_qd_id;

   IF v_include_q_hierarchy = 1 THEN

    FOR q_hierarchy_table IN (SELECT tc.tc_physical_name, t.tables_physical_name
                                FROM quotas_prod_ent_relations qper
                               INNER JOIN tables t
                                  ON t.tables_id = qper.qper_tables_id
                               INNER JOIN table_columns tc
                                  ON t.tables_id = tc.tc_tables_id
                                 AND tc.tc_entity_id = qper.qper_entity_id
                               WHERE qper.qper_qd_id = pi_qd_id)

    LOOP

      EXECUTE IMMEDIATE
      'MERGE INTO ' || q_hierarchy_table.tables_physical_name || ' dst'                                 || chr(10) ||
      'USING (SELECT /*+ CARDINALITY(tmp_iq ' || CASE WHEN pi_create_temp_tables THEN v_no_of_records ELSE pi_ht_cardinality END || ') ' ||
           CASE WHEN pi_adjusting_records IS NOT NULL THEN ' CARDINALITY (tqms ' || pi_no_of_adj_records || ')' END || ' */ product_table.row_identifier,' || chr(10) ||
      '              tmp_iq.upper_entity_id,'                           || chr(10) ||
      '              tmp_iq.upper_value,'                               || chr(10) ||
                     -- quota contribution
      '              ROUND(product_table.current_quota / decode(parent_product_table.current_quota, 0, null, parent_product_table.current_quota), 4) AS quota_contrib' || chr(10) ||
      '         FROM ' || q_hierarchy_table.tables_physical_name || ' product_table' || chr(10) ||
                -- join org hierarchy temp table to get parent entity for each org entity
      '         LEFT JOIN tmp_iq_hierarchy tmp_iq'                                   || chr(10) ||
      '           ON product_table.entity_id = tmp_iq.lower_entity_id'               || chr(10) ||
      '          AND product_table.entity_value = tmp_iq.lower_value'                || chr(10) ||
                -- join quotas table to get quota value for upper entities
      '         LEFT JOIN ' || q_hierarchy_table.tables_physical_name || ' parent_product_table' || chr(10) ||
      '           ON tmp_iq.upper_entity_id = parent_product_table.entity_id'                    || chr(10) ||
      '          AND tmp_iq.upper_value = parent_product_table.entity_value'                     || chr(10) ||
      '          AND product_table.' || q_hierarchy_table.tc_physical_name || ' = parent_product_table.' || q_hierarchy_table.tc_physical_name || chr(10) ||
      '          AND product_table.' || v_period_col_name || ' = parent_product_table.' || v_period_col_name                                   || chr(10) ||
      '        WHERE product_table.' || v_period_col_name || ' = ' || pi_tupr_id || ') src'                                                    || chr(10) ||
      'ON (dst.row_identifier = src.row_identifier)' || chr(10) ||
      'WHEN MATCHED THEN'                            || chr(10) ||
      '  UPDATE SET dst.quota_contribution = src.quota_contrib';
    END LOOP;

   END IF;

END CALCULATE_QUOTA_CONTRIBUTION;



-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140827
-- Description: Procedure that runs the process
-----------------------------------------------------------------------------------------
PROCEDURE LOAD_INITIAL_QUOTAS( pi_tupr_id                   IN tu_periods_range.tupr_id%type ,          -- the period for which the process is executed
                               pi_qd_id                     IN quota_definitions.qd_id%type ,           -- id of the definition
                               pi_iq_table_name             IN tables.tables_physical_name%type ,       -- the name of the INITIAL_QUOTAS table
                               pi_iq_qe_mapping             IN TABLETYPE_NAME_MAP,                      -- mapping between column names from Initial Quotas and Quota Entities tables
                               pi_iq_q_mapping              IN TABLETYPE_NAME_MAP,                      -- mapping between column names from Initial Quotas and Quotas tables
                               pi_temp_hierarchy_query      IN CLOB ,                                   -- hierarchy query
                               pi_temp_prod_hierarchy_query IN CLOB ,                                   -- product hierarchy query
                               pi_user_assign_queries       IN TABLETYPE_QUOTAS_QUERY_MAP,              -- mapping between user assignment tables_id and user assignment queries
                               pi_quotas_table_query        IN CLOB,
                               pi_qe_table_query1           IN CLOB,
                               pi_qe_table_query2           IN CLOB,
                               pi_qe_table_query3           IN CLOB,
                               pout_result                  OUT SYS_REFCURSOR,                          -- Cursor with rows that failed the validations
                               pout_no_rec_failed           OUT NUMBER ,                                -- Number of rows from pout_result cursor
                               pout_no_rec_qe               OUT NUMBER ,                                -- Number of rows from Quota Entities table
                               pout_no_rec_q                OUT NUMBER                                  -- Number of rows from Quotas table
                             )
AS
     v_distinct_entities       NUMBER(1 );
     v_no_of_records           NUMBER(10 );
     v_prod_no_of_records      NUMBER(10 ) := 0;
     v_prod_hierarchy_defined  NUMBER(1 ) := 0; -- is product hierarchy defined
     v_quota_contribution      NUMBER(1); -- is option to calc contribution enabled
     v_qd_has_calc_fields      NUMBER(1);
     v_sql                     CLOB;
     v_stamp                   VARCHAR2(250 CHAR);
     v_updated_cb              NUMBER(10);
     v_quotas_table_name       VARCHAR2(30 CHAR);
     v_calculated_fields       NUMBER(10);
     v_qe_table_name           VARCHAR2(30 CHAR);

BEGIN
    pout_no_rec_failed := 0;
    pout_no_rec_qe := 0;
    pout_no_rec_q := 0;


    v_stamp := 'QUOTAS.LOAD_INITIAL_QUOTAS - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_tupr_id),                ',pi_tupr_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_qd_id),                  ',pi_qd_id => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_iq_qe_mapping),      ',pi_iq_qe_mapping => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_iq_q_mapping),       ',pi_iq_q_mapping => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pi_iq_table_name),        ',pi_iq_table_name => <value>', v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pi_temp_hierarchy_query),     ',pi_temp_hierarchy_query => <value>' , v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pi_temp_prod_hierarchy_query),',pi_temp_prod_hierarchy_query => <value>' , v_stamp);
          L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_user_assign_queries),',pi_user_assign_queries => <value>' , v_stamp);
    END;

    -- ****************************************************************************************************
    -- I. VALIDATE INPUT PARAMETERS
    -- ****************************************************************************************************
      IF pi_tupr_id IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_tupr_id'));
      END IF ;

      IF pi_qd_id IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qd_id'));
      END IF ;

      IF pi_iq_qe_mapping IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_iq_qe_mapping'));
      END IF ;

      IF pi_iq_q_mapping IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_iq_q_mapping'));
      END IF ;

      IF pi_temp_hierarchy_query IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_temp_hierarchy_query'));
      END IF ;

      -- pi_temp_prod_hierarchy_query can be NULL (no product hierarchy defined)
      -- pi_user_assign_queries can be NULL (no user assignments are necessary)
      -- pi_iq_prod_col_name can be NULL (is entities in organization hierarchy have a single quota)


    -- ************************************ --
    --  Save processing session statistics  --
    -- ************************************ --

      COMMONS_PROCESSING.EXEC_START_PROC_TRANSACTION(pin_definition_id => pi_qd_id);


    -- ****************************************************************************************************
    -- II. Populate the temporary table for the product hierarchy
    -- ****************************************************************************************************
    -- v_prod_hierarchy_defined = 1 if product hierarchy is defined, 0 otherwise

    IF pi_temp_prod_hierarchy_query IS NOT NULL THEN
      v_prod_hierarchy_defined := 1;
      EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_PRODUCT_HIERARCHY';
      v_sql := 'BEGIN'|| CHR(10 ) ||
               'INSERT INTO TMP_PRODUCT_HIERARCHY(UPPER_ENTITY_ID, LOWER_ENTITY_ID, UPPER_VALUE, LOWER_VALUE, HLEVEL, LEAFS, '||
                                            'PARENT_UPPER_VALUE, PARENT_LOWER_VALUE, PARENT_UPPER_ENTITY_ID, PARENT_LOWER_ENTITY_ID) '||CHR(10)||
               pi_temp_prod_hierarchy_query|| ';'|| CHR(10 ) ||
               ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
               'END;';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), 'Populate TMP_PRODUCT_HIERARCHY => <value>' , v_stamp);
      EXECUTE IMMEDIATE v_sql USING OUT v_prod_no_of_records;
    END IF ;



    -- ****************************************************************************************************
    -- II'. Populate the temporary table for the hierarchy and create indexes
    -- ****************************************************************************************************
      EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_IQ_HIERARCHY';
      EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_QUOTAS_VALIDATIONS';
      v_sql := 'BEGIN'|| CHR(10 ) ||
               'INSERT INTO TMP_IQ_HIERARCHY(UPPER_ENTITY_ID, LOWER_ENTITY_ID, UPPER_VALUE, LOWER_VALUE, HLEVEL, LEAFS, '||
                                            'PARENT_UPPER_VALUE, PARENT_LOWER_VALUE, PARENT_UPPER_ENTITY_ID, PARENT_LOWER_ENTITY_ID) '||CHR(10)||
               pi_temp_hierarchy_query|| ';'|| CHR(10 ) ||
               ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
               'END;';

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), 'Populate TMP_IQ_HIERARCHY => <value>' , v_stamp);
      EXECUTE IMMEDIATE v_sql USING OUT v_no_of_records;

    -- ****************************************************************************************************
    -- III. VALIDATE DATA
    -- ****************************************************************************************************

    SELECT t.tables_physical_name
      INTO v_qe_table_name
      FROM quota_definitions qd
     INNER JOIN tables t
        ON t.tables_id = qd.qd_qe_tables_id
     WHERE qd.qd_id = pi_qd_id;

    SELECT qd.qd_calculate_contribution, t.tables_physical_name,
           (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 1 AND ROWNUM <= 1)
     INTO v_quota_contribution, v_quotas_table_name, v_qd_has_calc_fields
     FROM quota_definitions qd
    INNER JOIN tables t
       ON t.tables_id = qd.qd_adj_tables_id
    WHERE qd.qd_id = pi_qd_id;

    -- Determine if the top 2 entities are the same
    SELECT CASE -- top 2 entities are NOT the same
                WHEN level_1_entity != level_2_entity
                  THEN 1
                -- top 2 entities are the same with an additional entity that is SELECTed to participate in workflow
                WHEN level_1_entity = level_2_entity AND level_3_entity IS NOT NULL AND lvl3.qer_quota_can_be_released = 1
                  THEN 2
                -- top 2 entities are the same with an additional entity that is not SELECTed to participate in workflow
                WHEN level_1_entity = level_2_entity
                  AND -- an additional entity is applicable but is not SELECTed to participate in workflow
                      level_3_entity IS NOT NULL AND (lvl3.qer_quota_can_be_released != 1 OR lvl3.qer_quota_can_be_released IS NULL )
                  THEN 3
                -- top 2 entities are the same with NO additional entity
                WHEN level_1_entity = level_2_entity AND level_3_entity IS NULL -- no additional entity
                  THEN 4
                END
      INTO v_distinct_entities
    FROM (SELECT qer_entity_id AS level_1_entity, qer_id AS level_1_qer_id
          FROM quota_entity_relations
          WHERE qer_qd_id=pi_qd_id
            AND qer_level = 1 ) lvl1
    LEFT JOIN (SELECT qer_entity_id as level_2_entity, qer_id AS level_2_qer_id, qer_parent_node_id AS level_2_qer_parent_node_id
               FROM quota_entity_relations
               WHERE qer_qd_id=pi_qd_id
                 AND qer_level = 2
                 ) lvl2 on lvl1.level_1_qer_id = lvl2.level_2_qer_parent_node_id
    LEFT JOIN (SELECT qer_entity_id as level_3_entity,qer_parent_node_id AS level_3_qer_parent_node_id, qer_quota_can_be_released
               FROM quota_entity_relations
               WHERE qer_qd_id=pi_qd_id
                 AND qer_level = 3
                 ) lvl3 on lvl2.level_2_qer_id = lvl3.level_3_qer_parent_node_id
    -- necessary because we can have more than 1 entity on levels 2 and 3
    --    -> if we have more than 1 entity on level 2 => it does not matter which row is considered. The first 2 entities will not be the same
    --       because the topmost branch of the hierarchy is valid only if
    --            - Has only two entities and both are the same
    --            - Has only three entities with the top two entities the same and the third entity a different entity
    --            - Has all entities distinct
    --    -> if we have more than 1 entity on level 3 => it does not matter which row is considered because the check needed is that we have a third entity
    WHERE ROWNUM <=1 ;

    RUN_VALIDATIONS(  pi_vihr_tupr_id                 => pi_tupr_id,
                      pi_vihr_qd_id                   => pi_qd_id,
                      pi_vihr_iq_table_name           => pi_iq_table_name,
                      pi_vihr_iq_qe_mapping           => pi_iq_qe_mapping,
                      pi_vihr_no_dist_ent             => v_distinct_entities,
                      pi_vihr_no_of_records           => v_no_of_records,
                      pi_vihr_user_assign_queries     => pi_user_assign_queries,
                      pi_vihr_prod_hierarchy_defined  => v_prod_hierarchy_defined,
                      pi_vihr_prod_no_of_records      => v_prod_no_of_records,
                      pout_vihr_failed_val_no         => pout_no_rec_failed
                    );


    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pout_no_rec_failed), ',pout_no_rec_failed => <value>', v_stamp);

    -- Quota Entities and Quotas tables will be populated only if none of the previous validations have failed

    IF pout_no_rec_failed = 0 THEN


        -- ****************************************************************************************************
        -- IV. POPULATE QUOTA ENTITIES TABLE
        -- ****************************************************************************************************
        LOAD_QUOTA_ENTITIES (  pi_lqe_tupr_id             => pi_tupr_id,
                               pi_lqe_qd_id               => pi_qd_id,
                               pi_lqe_column_mapping      => pi_iq_qe_mapping,
                               pi_lqe_user_assign_queries => pi_user_assign_queries,
                               pi_lqe_distinct_entities   => v_distinct_entities,
                               pi_lqe_no_of_records       => v_no_of_records,
                               pout_lqe_no_rec_qe         => pout_no_rec_qe
                             );

        COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(pi_table   => v_qe_table_name
                                        ,pi_mode    => 2);

        -- ****************************************************************************************************
        -- V. POPULATE QUOTAS TABLE
        -- ****************************************************************************************************
        LOAD_QUOTAS  (pi_lq_tupr_id             => pi_tupr_id
                     ,pi_lq_qd_id               => pi_qd_id
                     ,pi_lq_column_names        => pi_iq_q_mapping
                     ,pi_lq_prod_herarchy       => v_prod_hierarchy_defined
                     ,pout_lq_no_rec_q          => pout_no_rec_q
                     );

        COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(pi_table   => v_quotas_table_name
                                                ,pi_mode    => 2);


        -- ****************************************************************************************************
        -- VI. POPULATE QUOTAS PRODUCTS TABLES
        -- ****************************************************************************************************
        IF v_prod_hierarchy_defined = 1 THEN
          -- max 3 rows returned by for clause
          FOR c IN (SELECT t.tables_physical_name, qper.qper_tables_id, LEAD(qper.qper_tables_id, 1, 0 ) OVER(ORDER BY qper.qper_level) AS table_id_prev
                      FROM quotas_prod_ent_relations qper
                     INNER JOIN tables t
                       ON t.tables_id = qper.qper_tables_id
                    WHERE qper.qper_tables_id IS NOT NULL AND qper.qper_qd_id = pi_qd_id
                    ORDER BY qper.qper_level DESC) LOOP

            LOAD_QUOTA_PRODUCTS (pi_lqp_tupr_id             => pi_tupr_id
                                ,pi_lqp_qd_id               => pi_qd_id
                                ,pi_lqp_table_id            => c.qper_tables_id
                                ,pi_lqp_prev_table_id       => c.table_id_prev
                                ,pi_lqp_column_mapping      => pi_iq_q_mapping
                                ,pi_lpq_no_of_records       => v_prod_no_of_records
                                );

           COMMONS_UTILS.GENERATE_TABLE_STATSISTICS(pi_table   => c.tables_physical_name
                                       ,pi_mode    => 2);

          END LOOP ;
        END IF ;


      -- ****************************************************************************************************
      -- VI. CALCULATE QUOTA CONTRIBUTION
      -- ****************************************************************************************************
      IF v_quota_contribution = 1 THEN
        CALCULATE_QUOTA_CONTRIBUTION(pi_qd_id => pi_qd_id,
                                     pi_tupr_id => pi_tupr_id,
                                     pi_iq_q_mapping => pi_iq_q_mapping,
                                     pi_hierarchy_query => pi_temp_hierarchy_query,
                                     pi_ht_cardinality => v_no_of_records,
                                     pi_create_temp_tables => false,
                                     pi_modified_parent_map => NULL,
                                     pi_no_of_updated_rec => v_updated_cb);
      END IF;


      IF v_qd_has_calc_fields = 1 THEN
        CALCULATE_QUOTAS_FIELDS( pi_cqf_tupr_id             => pi_tupr_id
                                ,pi_cqf_qd_id               => pi_qd_id
                                ,pi_cqf_q_table_name        => v_quotas_table_name
                                ,pi_cqf_q_mapping           => pi_iq_q_mapping
                                ,pi_cqf_calling_process     => 1
                                ,pi_cqf_quotas_table_query  => pi_quotas_table_query
                                ,pi_cqf_qe_table_query1     => pi_qe_table_query1
                                ,pi_cfq_qe_table_query2     => pi_qe_table_query2
                                ,pi_cfq_qe_table_query3     => pi_qe_table_query3
                                ,pout_cqf_no_rec_failed     => v_calculated_fields
                               );
      END IF;

    END IF ;

    v_sql := 'SELECT /*+ CARDINALITY(TMP ' || pout_no_rec_failed || ') */ TMP.*, IQ.* '||CHR(10)||
             'FROM TEMP_QUOTAS_VALIDATIONS TMP '||CHR(10 )||
             '  LEFT JOIN '|| pi_iq_table_name || ' IQ ON IQ.ROW_IDENTIFIER = TMP.TQV_IQ_ROW_IDENTIFIER'||CHR( 10)||
             'ORDER BY TMP.TQV_ROW_IDENTIFIER';

    OPEN pout_result FOR v_sql;


    COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);

    EXCEPTION

      WHEN e_stop_processing THEN

        COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);

      -- no need for cardinality hint since there will be only one row inserted in the table
        v_sql := 'SELECT TMP.*, IQ.* '||CHR(10 )||
             'FROM TEMP_QUOTAS_VALIDATIONS TMP '||CHR(10 )||
             '  LEFT JOIN '|| pi_iq_table_name || ' IQ ON IQ.ROW_IDENTIFIER = TMP.TQV_IQ_ROW_IDENTIFIER'||CHR( 10)||
             'ORDER BY TMP.TQV_ROW_IDENTIFIER';

        OPEN pout_result FOR v_sql;

        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM , v_stamp);

      WHEN NO_DATA_FOUND THEN

       COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);
       ROLLBACK;
        raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);

      WHEN OTHERS THEN

        COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM , v_stamp);
       RAISE;
END LOAD_INITIAL_QUOTAS;



-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150212
-- Description: Procedure that rollups the sums for quota entities when an adjustment is made on the lowest level
--              of the quota entity hierarchy
--      (http://confluence.optymyze.net/display/SOM/2015/01/29/Quotas+-+Quotas+View+examples)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_svqru_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_svqru_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_svqru_att_or_adjustment    IN NUMBER                                  -- calculate rollup sums for 1 - adjustments, 2 - attainment
*/
-----------------------------------------------------------------------------------------
PROCEDURE SAVE_QUOTAS_MODIFY_ROLLUP (pi_svqru_qd_id             IN quota_definitions.qd_iq_tables_id%TYPE ,
                                     pi_svqru_tupr_id           IN tu_periods_range.tupr_id%TYPE ,
                                     pi_svqru_att_or_adjustment IN NUMBER,
                                     pout_svqru_updated_rows    OUT tabletype_id_id)
AS
v_prev_table          VARCHAR2(30 CHAR);
v_period_col_name     VARCHAR2( 30 CHAR );
v_join_condition      CLOB;
v_inter_sql           CLOB;
v_q_table_name        VARCHAR2(30 CHAR);
idx                   NUMBER(1) := 1;
v_allows_non_zero_sum NUMBER(1);

BEGIN

  pout_svqru_updated_rows := tabletype_id_id();

  -- if allow non zero sum adjustments is checked
  SELECT COUNT(1) AS cnt
    INTO v_allows_non_zero_sum
    FROM quotas_non_zero_sum_relations qnzsr
   WHERE qnzsr.qnzsr_qd_id = pi_svqru_qd_id
     AND qnzsr.qnzsr_allow_non_zero_sum_adj = 1
     AND ROWNUM <= 1;


  -- v_prev_table = Quotas table name (initially); it will be updated each time with the previously populated table name
  -- period column name from Quotas table
  SELECT t_q.tables_physical_name, tc_period.tc_physical_name
    INTO v_prev_table, v_period_col_name
    FROM quota_definitions qd
   INNER JOIN tables t_q
      ON t_q.tables_id = qd.qd_adj_tables_id
   INNER JOIN table_columns tc_period
      ON t_q.tables_id = tc_period.tc_tables_id
     AND tc_period.tc_logic_type = 8
   WHERE qd_id = pi_svqru_qd_id;

    SELECT t.tables_physical_name,
           LISTAGG(tc.tc_physical_name ||
                   ' = qent_table.entity_value and qent_table.entity_id = ' ||
                   tc.tc_entity_id,
                   ' OR ') WITHIN GROUP (ORDER BY 1 )
      INTO v_q_table_name, v_join_condition
      FROM table_columns tc
     INNER JOIN tables t
        ON tc.tc_tables_id = t.tables_id
     INNER JOIN quota_definitions qd
        ON tc.tc_tables_id = qd.qd_adj_tables_id
     WHERE tc.tc_is_required = 0
       AND tc.tc_entity_id IS NOT NULL
     AND qd.qd_id = pi_svqru_qd_id
   GROUP BY t.tables_physical_name;

  -- quota entities table names -> max 3 rows returned by for clause
  FOR c IN (    SELECT t.tables_physical_name              AS qp_table_name,
                       t.tables_id                         AS qp_table_id,
                       tc.tc_physical_name                 AS qp_p_col_name,
                       quotas_tb_name.tables_physical_name AS quotas_table_name,
                       idx
                  FROM quotas_prod_ent_relations qper
                 INNER JOIN tables t
                    ON t.tables_id = qper.qper_tables_id
                 INNER JOIN table_columns tc
                    ON t.tables_id = tc.tc_tables_id
                   AND tc.tc_entity_id IS NOT NULL
                 -- 1 row -> Quotas table name
                 CROSS JOIN (SELECT t_q.tables_physical_name
                               FROM quota_definitions qd
                              INNER JOIN tables t_q
                                 ON t_q.tables_id = qd.qd_adj_tables_id
                              WHERE qd_id = pi_svqru_qd_id) quotas_tb_name
                 WHERE qper.qper_tables_id IS NOT NULL
                   AND qper.qper_qd_id = pi_svqru_qd_id
                 ORDER BY qper.qper_level DESC
   ) LOOP

   IF v_prev_table = v_q_table_name THEN

    -- performance improvement OF-39470 -- use union all instead of join on OR condition -- 16.2
    FOR joins IN (SELECT tc.tc_physical_name ||
                               ' = qent_table.entity_value and qent_table.entity_id = ' ||
                               tc.tc_entity_id as join_cond
                  FROM table_columns tc
                 INNER JOIN tables t
                    ON tc.tc_tables_id = t.tables_id
                 INNER JOIN quota_definitions qd
                    ON tc.tc_tables_id = qd.qd_adj_tables_id
                 WHERE tc.tc_is_required = 0
                   AND tc.tc_entity_id IS NOT NULL
                   AND qd.qd_id = pi_svqru_qd_id)
    LOOP
      v_inter_sql := v_inter_sql || 'SELECT qent_table.' || v_period_col_name || ' AS period,'  || chr(10) ||
                      '               qent_table.entity_id,'                        || chr(10) ||
                      '               qent_table.entity_value,'                     || chr(10) ||
                      '               qent_table.' || c.qp_p_col_name || ','        || chr(10)||
                      '               qent_table.initial_quota,'                    || chr(10) ||
                      '               qent_table.current_quota, '                   || chr(10) ||
                       CASE WHEN v_allows_non_zero_sum = 1 THEN
                      '              SUM(quotas_table.outstanding_allocation) as outstanding_allocation, '
                       END || chr(10) ||
                       CASE WHEN pi_svqru_att_or_adjustment IN (1,2) THEN
                      '              SUM(quotas_table.' || CASE WHEN pi_svqru_att_or_adjustment = 1
                                                                THEN 'adjustments'
                                                           END || ') AS adjustment_value '
                            ELSE GET_ADDITIONAL_FIELDS(pi_svqru_qd_id, 2, 'quotas_table.')
                       END || chr(10) ||
                      '         FROM ' || c.quotas_table_name || ' quotas_table '                         || chr( 10) ||
                      '        INNER JOIN ' || c.qp_table_name  || ' qent_table '                         || chr( 10) ||
                      '           ON (' || joins.join_cond || ') ' || chr(10) ||
                      '         AND qent_table.' || c.qp_p_col_name || ' = quotas_table.upper_entity_value ' || chr( 10) ||
                      '         AND qent_table.' || v_period_col_name || ' = quotas_table.' || v_period_col_name || chr(10 ) ||
                      '        WHERE quotas_table.' || v_period_col_name || ' = ' || pi_svqru_tupr_id || chr(10 ) ||
                      '        GROUP BY qent_table.entity_id,'                  || chr(10) ||
                      '                 qent_table.entity_value,'               || chr(10) ||
                      '                 qent_table.' || c.qp_p_col_name || ','  || chr(10 )||
                      '                 qent_table.initial_quota, '             || chr(10) ||
                      '                 qent_table.current_quota, '             || chr(10) ||
                      '                 qent_table.' || v_period_col_name       || chr(10) ||
                      '         UNION ALL ';
    END LOOP;

    v_inter_sql := SUBSTR(v_inter_sql, 1, LENGTH(v_inter_sql) - 11 );



    EXECUTE IMMEDIATE 'MERGE INTO ' || c.qp_table_name || ' dst'                                  || chr(10) ||
                      'USING (' || v_inter_sql || ') src'                                         || chr(10) ||
                      'ON (dst.entity_id = src.entity_id and dst.entity_value = src.entity_value' || chr(10) ||
                      'AND dst.' || c.qp_p_col_name || ' = src.' || c.qp_p_col_name               || chr(10) ||
                      'AND dst.' || v_period_col_name || ' = src.period) '                        || chr(10) ||
                      'WHEN MATCHED THEN' || chr(10 ) ||
                      '  UPDATE'          || chr(10) ||
                      '     SET ' || CASE WHEN pi_svqru_att_or_adjustment = 1 THEN 'dst.current_quota = dst.initial_quota + src.adjustment_value,' || chr( 10) ||
                      '                                                             dst.adjustments   = src.adjustment_value'
                                                                              || CASE WHEN v_allows_non_zero_sum = 1
                                                                                      THEN ', dst.outstanding_allocation = src.outstanding_allocation'
                                                                                 END
                                          WHEN pi_svqru_att_or_adjustment = 3 THEN GET_ADDITIONAL_FIELDS(pi_svqru_qd_id, 3, '')
                                     END;


   pout_svqru_updated_rows.extend(3);
   pout_svqru_updated_rows(idx) := objtype_id_id(c.qp_table_id, SQL%ROWCOUNT);




   ELSE

    EXECUTE IMMEDIATE 'MERGE INTO ' || c.qp_table_name || ' dst'                                        || chr(10) ||
                      'USING (SELECT ' || c.qp_table_name || '.' || v_period_col_name || ' AS period, ' || chr(10) ||
                      '              ' || c.qp_table_name || '.entity_id,'                              || chr(10) ||
                      '              ' || c.qp_table_name || '.entity_value,'                           || chr(10) ||
                      '              ' || c.qp_table_name || '.' || c.qp_p_col_name || ','              || chr(10) ||
                      '              ' || c.qp_table_name || '.initial_quota,'                          || chr(10) ||
                      '              ' || c.qp_table_name || '.current_quota,'                          || chr(10) ||
                                     CASE WHEN v_allows_non_zero_sum = 1 THEN
                      '              SUM(' || v_prev_table || '.outstanding_allocation) as outstanding_allocation,' END || chr(10) ||
                                     CASE WHEN pi_svqru_att_or_adjustment IN (1,2) THEN
                      '              SUM(' || v_prev_table || '.' || CASE WHEN pi_svqru_att_or_adjustment = 1 THEN 'adjustments' END || ') AS adjustment_value '
                                          ELSE GET_ADDITIONAL_FIELDS(pi_svqru_qd_id, 2, v_prev_table || '.') END || chr(10) ||
                      '         FROM ' || c.qp_table_name  || chr(10) ||
                      '        INNER JOIN ' || v_prev_table ||
                      '           ON ' || c.qp_table_name || '.' || c.qp_p_col_name || ' = ' || v_prev_table || '.upper_entity_value ' || chr(10) ||
                      '          AND ' || c.qp_table_name || '.entity_id = ' || v_prev_table || '.entity_id ' || chr(10 ) ||
                      '          AND ' || c.qp_table_name || '.entity_value = ' || v_prev_table || '.entity_value' || chr(10) ||
                      '          AND ' || c.qp_table_name || '.' || v_period_col_name || ' = ' || v_prev_table || '.' || v_period_col_name || chr(10) ||
                      '        WHERE ' || c.qp_table_name || '.' || v_period_col_name || ' = ' || pi_svqru_tupr_id || chr(10) ||
                      '        GROUP BY ' || c.qp_table_name || '.entity_id,'                        || chr(10) ||
                      '                 ' || c.qp_table_name || '.entity_value,'                     || chr(10) ||
                      '                 ' || c.qp_table_name || '.' || c.qp_p_col_name || ','        || chr(10 ) ||
                      '                 ' || c.qp_table_name || '.initial_quota, '                   || chr(10) ||
                      '                 ' || c.qp_table_name || '.current_quota, '                   || chr(10) ||
                      '                 ' || c.qp_table_name || '.' || v_period_col_name || ' ) src' || chr(10) ||
                      'ON (dst.entity_id = src.entity_id and dst.entity_value = src.entity_value'    || chr(10) ||
                      'AND dst.' || c.qp_p_col_name || ' = src.' || c.qp_p_col_name                  || chr(10) ||
                      'AND dst.' || v_period_col_name || ' = src.period) '                           || chr(10) ||
                      'WHEN MATCHED THEN' || chr(10 ) ||
                      '  UPDATE'          || chr(10) ||
                      '     SET ' || CASE WHEN pi_svqru_att_or_adjustment = 1 THEN 'dst.current_quota = dst.initial_quota + src.adjustment_value,' || chr( 10) ||
                      '                                                             dst.adjustments   = src.adjustment_value'
                                                                              || CASE WHEN v_allows_non_zero_sum = 1
                                                                                      THEN ', dst.outstanding_allocation = src.outstanding_allocation'
                                                                                 END
                                          WHEN pi_svqru_att_or_adjustment = 3 THEN GET_ADDITIONAL_FIELDS(pi_svqru_qd_id, 3, '')
                                     END;

    pout_svqru_updated_rows(idx) := objtype_id_id(c.qp_table_id, SQL%ROWCOUNT);
    END IF ;

    v_prev_table := c.qp_table_name;
   idx := idx + 1;
   END LOOP;


END SAVE_QUOTAS_MODIFY_ROLLUP;


-- ===============================================================================================
-- Author     : Macarie, Sabina
-- Create date: 20160316
-- Description: Procedure to copy static fields from Initial Quotas to Quotas table when running
--              Calculate Additional Info Process
-- Input Parameters:
/*
   pi_csf_tupr_id         IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
   pi_csf_qd_id           IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
   pi_csf_iq_q_mapping    IN TABLETYPE_NAME_MAP                      -- mapping between column names from Quotas and Initial Quotas table
*/

--------------------------------------------------------------------------------------------------
PROCEDURE COPY_STATIC_FIELDS(pi_csf_tupr_id      IN tu_periods_range.tupr_id%TYPE,
                             pi_csf_qd_id        IN quota_definitions.qd_id%TYPE,
                             pi_csf_iq_q_mapping IN TABLETYPE_NAME_MAP,
                             pout_updated_rows   OUT NUMBER)
IS

v_sql                 CLOB;

v_quotas_table_name     VARCHAR2(30 CHAR);
v_iq_table_name         VARCHAR2(30 CHAR);
v_product_column_name   VARCHAR2(30 CHAR);
v_period_column_name    VARCHAR2(30 CHAR);
v_updated_rows          tabletype_id_id;
v_has_product_hierarchy NUMBER(1);
v_entities_condition    CLOB;

BEGIN

  SELECT q_table.tables_physical_name, iq_table.tables_physical_name, period_tc.tc_physical_name, prod_tc.tc_physical_name,
         entities_clause.ent_clause, qd.qd_include_quota_hierarchy
    INTO v_quotas_table_name, v_iq_table_name, v_period_column_name, v_product_column_name, v_entities_condition, v_has_product_hierarchy
    FROM quota_definitions qd
   LEFT JOIN tables q_table
      ON q_table.tables_id = qd.qd_adj_tables_id
   LEFT JOIN tables iq_table
      ON iq_table.tables_id = qd.qd_iq_tables_id
   LEFT JOIN table_columns period_tc
     ON q_table.tables_id = period_tc.tc_tables_id
    AND period_tc.tc_logic_type = 8
   LEFT JOIN table_columns prod_tc
     ON q_table.tables_id = prod_tc.tc_tables_id
    AND prod_tc.tc_entity_id = qd.qd_multiple_q_entity_id
   LEFT JOIN (SELECT LISTAGG('initial_quotas.' || name1 || ' = quotas_table.' || name2  , ' OR ') WITHIN GROUP (ORDER BY 1) AS ent_clause
                FROM TABLE(pi_csf_iq_q_mapping)) entities_clause
     ON 1 = 1
   WHERE qd.qd_id = pi_csf_qd_id;

   FOR c IN (SELECT name1, name2 FROM table(pi_csf_iq_q_mapping)) LOOP

     v_sql := v_sql ||
          ' SELECT QUOTAS_TABLE.Row_Identifier,'                                               || chr(10) ||
          '        ' || GET_ADDITIONAL_FIELDS(pi_csf_qd_id, 1, 'initial_quotas.')              || chr(10) ||
          '           FROM ' || v_iq_table_name || ' initial_quotas'                           || chr(10) ||
          '          INNER JOIN ' || v_quotas_table_name || ' quotas_table'                    || chr(10) ||
          '             ON (INITIAL_QUOTAS.' || c.name1 || ' = QUOTAS_TABLE.' || c.name2 || ')'    || chr(10) ||
                    CASE WHEN v_product_column_name IS NOT NULL THEN
          '            AND INITIAL_QUOTAS.' || v_product_column_name || ' = QUOTAS_TABLE.' || v_product_column_name END || chr(10) ||
          '            AND INITIAL_QUOTAS.' || v_period_column_name || '  = QUOTAS_TABLE.' || v_period_column_name   || chr(10) ||
          '            AND INITIAL_QUOTAS.' || v_period_column_name || ' = ' || pi_csf_tupr_id || chr(10) ||
          ' UNION ALL ';


   END LOOP;

   v_sql := SUBSTR(v_sql,1,length(v_sql)-11);


   v_sql := 'BEGIN ' || chr(10) ||
            ' MERGE INTO ' || v_quotas_table_name || ' DST '           || chr(10) ||
            ' USING ( ' || v_sql || ') SRC '                           || chr(10) ||
            '    ON (DST.Row_Identifier = SRC.row_identifier) '        || chr(10) ||
            '  WHEN MATCHED THEN UPDATE SET ' || GET_ADDITIONAL_FIELDS(pi_csf_qd_id, 3, 'DST.') || ';' || chr(10) ||
            ' :SQLROWCNT := SQL%ROWCOUNT;'                             || chr(10 ) ||
            'END;';

   EXECUTE IMMEDIATE v_sql USING OUT pout_updated_rows;



   IF v_has_product_hierarchy = 1 THEN
    SAVE_QUOTAS_MODIFY_ROLLUP(pi_svqru_qd_id             => pi_csf_qd_id,
                              pi_svqru_tupr_id           => pi_csf_tupr_id,
                              pi_svqru_att_or_adjustment => 3,
                              pout_svqru_updated_rows    => v_updated_rows);
   END IF;

END COPY_STATIC_FIELDS;

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20150415
-- Description: Procedure that calculates quota additional info: attainment and/or contribution
-- http://confluence.optymyze.net/display/Quotas/Calculate+Additional+Quota+Information+Process
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_q_mapping            IN tabletype_name_map                      -- column names from quotas and initial quotas table
  pi_hierarchy_query      IN CLOB                                    -- product hierarchy query
*/
-----------------------------------------------------------------------------------------
PROCEDURE CALCULATE_ADDITIONAL_INFO  ( pi_tupr_id               IN tu_periods_range.tupr_id%TYPE ,         -- the period for which the process is executed
                                       pi_qd_id                 IN quota_definitions.qd_id%TYPE ,          -- id of the definition
                                       pi_q_mapping             IN TABLETYPE_NAME_MAP,                     -- quotas table column names
                                       pi_hierarchy_query       IN CLOB,                                   -- organization hierarchy query
                                       pi_quotas_table_query    IN CLOB,
                                       pi_qe_table_query1       IN CLOB,
                                       pi_qe_table_query2       IN CLOB,
                                       pi_qe_table_query3       IN CLOB,
                                       pout_no_rec_failed       OUT NUMBER,                                -- number of rows from pout_result cursor
                                       pout_no_rec_updated      OUT NUMBER,                                -- number of records updated
                                       pout_result              OUT SYS_REFCURSOR,                         -- cursor with rows that failed the validations
                                       pout_updated_rows        OUT tabletype_id_id                        -- collection with <no of rec, table id>
                                     )
AS
v_sql                 CLOB;
v_q_table_name        VARCHAR2 (30 CHAR);
v_iq_table_name       VARCHAR2 (30 CHAR);
v_period_col_name     VARCHAR2 (30 CHAR);
v_has_prod_hierarchy  NUMBER(1 );
v_stamp               VARCHAR2 (250 CHAR);
v_no_records_failed   NUMBER(10 ) := 0;

v_qd_calculate_contrib  NUMBER(1);
v_qd_has_add_fields     NUMBER(1);
v_qd_has_calc_fields    NUMBER(1);
v_qd_allow_non_zero_sum NUMBER(1);

v_updated_att           NUMBER(10) := 0;
v_updated_cb            NUMBER(10);
v_calculated_fields     NUMBER(10);
v_has_static_num_fld    NUMBER(1);
v_has_static_char_fld   NUMBER(1);

BEGIN

pout_no_rec_failed := 0;
pout_no_rec_updated := 0;

  v_stamp := 'QUOTAS.CALCULATE_ADDITIONAL_INFO - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF' );

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_tupr_id),                ',pi_tupr_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_qd_id),                  ',pi_qd_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_q_mapping),          ',pi_q_mapping => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pi_hierarchy_query),          ',pi_hierarchy_query => <value>', v_stamp);

    END ;

   -- ****************************************************************************************************
   -- I. VALIDATE INPUT PARAMETERS
   -- ****************************************************************************************************

    IF pi_tupr_id IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_tupr_id' ));
    END IF ;

    IF pi_qd_id IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qd_id' ));
    END IF ;

    IF pi_q_mapping IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_q_mapping'));
    END IF ;

    IF pi_hierarchy_query IS NULL THEN
          raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_hierarchy_query'));
    END IF ;


   -- Truncate validations temp table
   EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_QUOTAS_ATT_VALIDATIONS';

   SELECT q_table.tables_physical_name,
          iq_table.tables_physical_name,
          period_tc.tc_physical_name
     INTO v_q_table_name,
          v_iq_table_name,
          v_period_col_name
     FROM quota_definitions qd
     LEFT JOIN tables q_table
       ON q_table.tables_id = qd.qd_adj_tables_id
     LEFT JOIN tables iq_table
       ON iq_table.tables_id = qd.qd_iq_tables_id
     LEFT JOIN table_columns period_tc
       ON q_table.tables_id = period_tc.tc_tables_id
      AND period_tc.tc_logic_type = 8
    WHERE qd.qd_id = pi_qd_id;
    -----------------------------------------------------------------------------------------
    -- Validate if the Quotas table has records for the running period
    -----------------------------------------------------------------------------------------
    VALIDATE_Q_HAS_RECORDS (pi_vqhr_tupr_id            => pi_tupr_id,
                            pi_vqhr_q_table_name       => v_q_table_name,
                            pi_vqhr_q_period_col_name  => v_period_col_name,
                            pout_vqhr_no_rec_failed    => v_no_records_failed
                           );
    pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_records_failed,0 );


    -----------------------------------------------------------------------------------------
    -- Get options from quota definitions for : contribution, additional fields
    -----------------------------------------------------------------------------------------
    SELECT qd.qd_calculate_contribution,
           (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 0 AND ROWNUM <= 1),
           (SELECT COUNT(1) FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = qd.qd_id AND qaf.qaf_type = 1 AND ROWNUM <= 1),
           (SELECT COUNT(1) AS cnt FROM quotas_non_zero_sum_relations qnzsr WHERE qnzsr.qnzsr_qd_id = pi_qd_id
                                                                                  AND qnzsr.qnzsr_allow_non_zero_sum_adj = 1
                                                                                  AND ROWNUM <= 1),
           (SELECT COUNT(1)
              FROM quota_additional_fields qaf
             INNER JOIN fields f
                ON qaf.qaf_field_id = f.fld_id
             WHERE qaf.qaf_type = 0
               AND qaf_qd_id = pi_qd_id
               AND f.fld_data_type = 1
               AND ROWNUM <= 1),
           (SELECT COUNT(1)
              FROM quota_additional_fields qaf
             INNER JOIN fields f
                ON qaf.qaf_field_id = f.fld_id
             WHERE qaf.qaf_type = 0
               AND qaf_qd_id = pi_qd_id
               AND f.fld_data_type = 6
               AND ROWNUM <= 1)
      INTO v_qd_calculate_contrib, v_qd_has_add_fields, v_qd_has_calc_fields, v_qd_allow_non_zero_sum, v_has_static_char_fld, v_has_static_num_fld
      FROM quota_definitions qd
     WHERE qd.qd_id = pi_qd_id;


    -----------------------------------------------------------------------------------------
    -- Calculate Quota Contribution
    -----------------------------------------------------------------------------------------
    IF v_qd_calculate_contrib = 1 THEN
      calculate_quota_contribution(pi_qd_id               => pi_qd_id,
                                   pi_tupr_id             => pi_tupr_id,
                                   pi_iq_q_mapping        => pi_q_mapping,
                                   pi_hierarchy_query     => pi_hierarchy_query,
                                   pi_modified_parent_map => NULL,
                                   pi_no_of_updated_rec   => v_updated_cb);
      pout_no_rec_updated := v_updated_cb;
    END IF;

    -----------------------------------------------------------------------------------------
   -- Additional fields validations
    -----------------------------------------------------------------------------------------
   IF v_qd_has_add_fields = 1 THEN

    -- --------------------------------------------------------------------------------------------------
    --  Determining the records from the Initial Quotas table that are relevant for the period being run
    --  If there are no records after filtering the Initial Quotas table for the period being run, processing fails
    -- --------------------------------------------------------------------------------------------------
    v_sql := 'BEGIN'|| CHR(10 ) ||
             'INSERT INTO TEMP_QUOTAS_ATT_VALIDATIONS(TQAV_ROW_IDENTIFIER,TQAV_VALIDATION_ID,TQAV_ERROR_MESSAGE)' || CHR(10 ) ||
             'SELECT TEMP_QUOTAS_VALIDATIONS_SEQ.NEXTVAL, ' || CHR(10) ||
             '       -20901 AS failed_validation,' || CHR(10) ||
             '       ''-''' || CHR(10) ||
             'FROM DUAL' || CHR(10 ) ||
             'WHERE (SELECT COUNT(1) '||
             '      FROM ' ||v_iq_table_name|| ' i '||
             '      WHERE i.' ||v_period_col_name || ' = ' || pi_tupr_id ||
             '        AND rownum <= 1) = 0;' || CHR(10) ||
             ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
             'END;';

    EXECUTE IMMEDIATE v_sql USING OUT v_no_records_failed;

    IF v_no_records_failed > 0 THEN
       COMMIT;
       RAISE e_stop_processing;
    END IF ;

    VALIDATE_QUOTAS_FIELDS(pi_vqf_tupr_id      => pi_tupr_id,
                           pi_vqf_qd_id        => pi_qd_id,
                           pi_vqf_iq_q_mapping => pi_q_mapping,
                           pout_vqf_failed_no  => v_no_records_failed
                           );
    pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_records_failed,0 );

    IF v_has_static_num_fld = 1 THEN
      VALIDATE_FIELD_DECIMALS(pi_vfd_tupr_id           => pi_tupr_id,
                              pi_vfd_qd_id             => pi_qd_id,
                              pi_vfd_iq_q_mapping      => pi_q_mapping,
                              pi_vfd_calling_process   => 2,
                              pi_vfd_field_mapping     => NULL,
                              pi_vfd_hierarchy_mapping => NULL,
                              pi_vfd_import_query      => NULL,
                              pi_vfd_field_data_type   => 1,
                              pout_vfd_failed_val_no   => v_no_records_failed
                              );
      pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_records_failed,0 );
    END IF;

    IF v_has_static_char_fld = 1 THEN
      VALIDATE_FIELD_DECIMALS(pi_vfd_tupr_id           => pi_tupr_id,
                              pi_vfd_qd_id             => pi_qd_id,
                              pi_vfd_iq_q_mapping      => pi_q_mapping,
                              pi_vfd_calling_process   => 2,
                              pi_vfd_field_mapping     => NULL,
                              pi_vfd_hierarchy_mapping => NULL,
                              pi_vfd_import_query      => NULL,
                              pi_vfd_field_data_type   => 2,
                              pout_vfd_failed_val_no   => v_no_records_failed
                              );
      pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_records_failed,0 );
    END IF;
    IF pout_no_rec_failed = 0 THEN
      COPY_STATIC_FIELDS(pi_csf_tupr_id      => pi_tupr_id,
                         pi_csf_qd_id        => pi_qd_id,
                         pi_csf_iq_q_mapping => pi_q_mapping,
                         pout_updated_rows   => v_updated_att);

      IF v_qd_has_calc_fields = 1 THEN
          CALCULATE_QUOTAS_FIELDS( pi_cqf_tupr_id             => pi_tupr_id
                                  ,pi_cqf_qd_id               => pi_qd_id
                                  ,pi_cqf_q_table_name        => v_q_table_name
                                  ,pi_cqf_q_mapping           => pi_q_mapping
                                  ,pi_cqf_calling_process     => 2
                                  ,pi_cqf_quotas_table_query  => pi_quotas_table_query
                                  ,pi_cqf_qe_table_query1     => pi_qe_table_query1
                                  ,pi_cfq_qe_table_query2     => pi_qe_table_query2
                                  ,pi_cfq_qe_table_query3     => pi_qe_table_query3
                                  ,pout_cqf_no_rec_failed     => v_calculated_fields
                                 );
      END IF;

    END IF;

    END IF;

      pout_no_rec_updated := GREATEST(pout_no_rec_updated, v_updated_att);

      v_sql := 'SELECT /*+ CARDINALITY(TMP ' || pout_no_rec_failed || ') */ TMP.* ' ||CHR(10)||
           'FROM TEMP_QUOTAS_ATT_VALIDATIONS TMP ' ;

      OPEN pout_result FOR v_sql;

     ------------------------------------------------------------------
     -------------------- NON ZERO SUM ADJUSTMENTS --------------------
     ------------------------------------------------------------------
     -- in case the non zero sum adjustments is checked, update outstandin allocation
     -- values to 0 in case they are null (if the OA column has been added and the LIQ
     -- process was not run)

     IF v_qd_allow_non_zero_sum = 1 THEN
       EXECUTE IMMEDIATE 'UPDATE ' || v_q_table_name || ' adj '      || CHR(10) ||
                         '   SET adj.outstanding_allocation = 0 '    || CHR(10) ||
                         ' WHERE adj.outstanding_allocation IS NULL' || CHR(10) ||
                         '   AND adj.' || v_period_col_name || ' = ' || pi_tupr_id;

        IF v_has_prod_hierarchy = 1 THEN
          FOR c IN (SELECT t.tables_physical_name
                      FROM quotas_prod_ent_relations qper
                     INNER JOIN quota_definitions qd
                        ON qper.qper_qd_id = qd.qd_id
                     INNER JOIN tables t
                        ON qper.qper_tables_id = t.tables_id
                     WHERE qd.qd_id = pi_qd_id) LOOP
            EXECUTE IMMEDIATE 'UPDATE ' || c.tables_physical_name || ' SET outstanding_allocation = 0 WHERE outstanding_allocation IS NULL AND ' || v_period_col_name || ' = ' || pi_tupr_id;
          END LOOP ;
        END IF ;
     END IF;


  EXCEPTION

    WHEN e_stop_processing THEN
    COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);

    v_sql := 'SELECT /*+ CARDINALITY(TMP ' || pout_no_rec_failed || ') */ TMP.* ' ||CHR(10)||
             'FROM TEMP_QUOTAS_ATT_VALIDATIONS TMP ' ;

    OPEN pout_result FOR v_sql;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM , v_stamp);


    WHEN NO_DATA_FOUND THEN
     COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);
     ROLLBACK;
      raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);

/*    WHEN OTHERS THEN
      COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE , SQLERRM , v_stamp);
     RAISE;*/

END;


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20170508
-- Description: Procedure that scans the organizational hierarchy to check for started requests
--      (https://confluence.optymyze.net/display/Quotas/Quotas+-+Workflow+integration+to+support+quota+adjustments+approval)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_iq_q_mapping         IN TABLETYPE_NAME_MAP                      -- column names from Quotas table
  pi_svqmm_modified_col_mapping IN TABLETYPE_ID_ID_VALUE             -- adjustments for children
                                                                           -- mapping between:
                                                                           --         -> E_INTERNAL_ID for the product that is being modified
                                                                           --         -> ENTITIES.ENTITY_ID - ID of the entity being modified
                                                                           --         -> E_INTERNAL_ID of the value from Quota Entities table
                                                                           --         -> modified Quota value (Adjustments column from UI)
  pi_modified_parent_map  IN TABLETYPE_ID_ENTITY_VALUE                -- adjustments for current level
  pi_logged_entity_id     IN NUMBER
  pi_logged_entity_value  IN NUMBER
*/
-----------------------------------------------------------------------------------------
PROCEDURE SCAN_HIERARCHY_FOR_WF_REQUESTS(pi_qd_id IN NUMBER,
                                         pi_tupr_id                    IN NUMBER,
                                         pi_iq_q_mapping               IN TABLETYPE_NAME_MAP,
                                         pi_modified_col_mapping       IN TABLETYPE_ID_ENTITY_VALUE,
                                         pi_modified_parent_map        IN TABLETYPE_ID_ENTITY_VALUE,
                                         pi_logged_entity_id           IN NUMBER,
                                         pi_logged_entity_value        IN NUMBER,
                                         pi_scan_parents_or_children   IN NUMBER,
                                         pout_result                   OUT SYS_REFCURSOR,
                                         pout_canceled_requests_no     OUT NUMBER)

  IS

  v_sql                         CLOB;
  v_modif_parent_entity_id      NUMBER(10);
  v_modif_parent_value          NUMBER(10);
  v_quotas_entities_tables_name VARCHAR2(30 CHAR);
  v_product_col_name            VARCHAR2(30 CHAR);
  v_period_col_name             VARCHAR2(30 CHAR);
  v_request_table_name          VARCHAR2(30 CHAR);
  v_upper_no_of_values          NUMBER(10);
  v_children_ent_list           VARCHAR2(4000 CHAR);
  v_children_ent_ids            VARCHAR2(4000 CHAR);
  v_parent_ent_list             VARCHAR2(4000 CHAR);
  v_parent_ent_ids              VARCHAR2(4000 CHAR);
  TYPE requests_rec_type IS RECORD( request_id       NUMBER(10),
                                    is_parent_entity NUMBER(1),
                                    modified_by      VARCHAR2(250 CHAR),
                                    entity_id        NUMBER(10),
                                    entity_value     NUMBER(10),
                                    hierarchy_level  NUMBER);
  l_requests_rec_type requests_rec_type;


  BEGIN

   SELECT t.tables_physical_name, tc_quota_adj_table.tc_physical_name, tc_period.tc_physical_name, request_table.tables_physical_name
     INTO v_quotas_entities_tables_name,
          v_product_col_name,
          v_period_col_name,
          v_request_table_name
     FROM quota_definitions qd
    INNER JOIN tables t
       ON qd.qd_qe_tables_id = t.tables_id
     LEFT JOIN tables quota_adj_table
       ON qd.qd_adj_tables_id = quota_adj_table.tables_id
     LEFT JOIN table_columns tc_quota_adj_table
       ON quota_adj_table.tables_id = tc_quota_adj_table.tc_tables_id
      AND qd.qd_multiple_q_entity_id = tc_quota_adj_table.tc_entity_id
     LEFT JOIN tables request_table
       ON qd.qd_request_tables_id = request_table.tables_id
     LEFT JOIN table_columns tc_period
       ON t.tables_id = tc_period.tc_tables_id
      AND tc_period.tc_logic_type = 8
    WHERE qd.qd_id = pi_qd_id;

    SELECT LISTAGG(' CASE WHEN ' || tc.tc_physical_name || ' IS NOT NULL THEN ' || e.entity_base_entity || ' END' , ', ') WITHIN GROUP (ORDER BY 1) AS parent_ent_list,
           LISTAGG(tc.tc_physical_name ||', NULL ', ', ') WITHIN GROUP (ORDER BY 1) AS parent_ent_ids,
           lower_entities.children_ent_list,
           lower_entities.children_ent_ids
      INTO v_parent_ent_list,
           v_parent_ent_ids,
           v_children_ent_list,
           v_children_ent_ids
     FROM table_columns tc
    INNER JOIN entities e
      ON tc.tc_entity_id = e.entity_id
    CROSS JOIN (SELECT LISTAGG (' CASE WHEN ' || name1 || ' IS NOT NULL THEN ' || tc.tc_entity_id || ' END', ', ') WITHIN GROUP (ORDER BY 1) AS children_ent_list,
                       LISTAGG (tc.tc_physical_name || ', NULL ', ', ') WITHIN GROUP (ORDER BY 1) AS children_ent_ids
                 FROM TABLE(pi_iq_q_mapping) mp
                INNER JOIN table_columns tc
                  ON tc.tc_physical_name = mp.name1
                 AND tc.tc_tables_id = (SELECT qd.qd_qe_tables_id from quota_definitions qd where qd_id = pi_qd_id)
                ) lower_entities
    WHERE tc.tc_tables_id = (SELECT qd.qd_qe_tables_id FROM quota_definitions qd WHERE qd_id = pi_qd_id)
      AND e.entity_base_entity IS NOT NULL
      AND e.entity_base_entity NOT IN (SELECT qua.qua_user_entity_id FROM quota_user_assignments qua WHERE qua.qua_qd_id = pi_qd_id AND qua.qua_assignment_type = 0)
    GROUP BY lower_entities.children_ent_list,
              lower_entities.children_ent_ids;


  IF pi_modified_parent_map IS NOT NULL THEN

  -- get modified entity; only one parent modified once/multiple products so we use rownum <= 1
  -- use max for NO_DATA_FOUND
  SELECT MAX(modified_parent.entity_id), MAX(modified_parent.entity_e_internal_id)
    INTO v_modif_parent_entity_id, v_modif_parent_value
    FROM table(pi_modified_parent_map) modified_parent
   WHERE modified_parent.is_parent_modified = 1
     AND ROWNUM <= 1;

  END IF;

  v_sql :=  'WITH modified_children AS ' || chr(10) ||
            '(SELECT entity_id, ' || chr(10) ||
            '        entity_e_internal_id, ' || chr(10) ||
            '        id, ' || chr(10) ||
            '        is_parent_modified ' || chr(10) ||
            '   FROM table(:pi_modified_col_mapping)) ' || chr(10) ||
            -- get quota hierarchy relationships as lower - upper values from Quota Entities table
            -------------------------------------------------------------------------------------
            ',quota_hierarchy_relationships AS ' || chr(10) ||
            -------------------------------------------------------------------------------------
            '(SELECT COALESCE(' || v_children_ent_list|| ', NULL) AS LOWER_ENT ' || chr(10) ||
            '       ,COALESCE(' || v_children_ent_ids || ') AS LOWER_VAL '|| chr(10) ||
            '       ,COALESCE(' || v_parent_ent_list || ', NULL) AS UPPER_ENT ' || chr(10) ||
            '       ,COALESCE(' || v_parent_ent_ids || ') AS UPPER_VAL' || chr(10) ||
            '   FROM ' || v_quotas_entities_tables_name || ' qe' || chr(10) ||
            '  WHERE qe.' || v_period_col_name || ' = ' || pi_tupr_id || ')' || chr(10) ||
            -------------------------------------------------------------------------------------
            ',parents_and_children AS' || chr(10) ||
            -------------------------------------------------------------------------------------
            -- scan parents - P1
            --------------------
            ' (SELECT DISTINCT lower_ent,' || chr(10) ||
            '         lower_val,' || chr(10) ||
            '         upper_ent,' || chr(10) ||
            '         upper_val,' || chr(10) ||
            CASE WHEN pi_scan_parents_or_children = 1 THEN 'id ' ELSE 'CONNECT_BY_ROOT id AS id' END || chr(10) ||
            '    FROM (SELECT lower_ent, lower_val, upper_ent, upper_val, adj.id' || chr(10) ||
            '            FROM quota_hierarchy_relationships qez' || chr(10) ||
            CASE WHEN pi_scan_parents_or_children = 1 THEN
            '            LEFT JOIN modified_children adj ON 1=1 '
                 WHEN pi_scan_parents_or_children = 2 THEN
            '            LEFT JOIN modified_children adj' || chr(10) ||
            '              ON qez.lower_ent = adj.entity_id' || chr(10) ||
            '             AND qez.lower_val = adj.entity_e_internal_id ' END || chr(10) ||
            '          )' || chr(10) ||
            '  WHERE LEVEL > 1 ' || chr(10) || -- exclude current level
            -- 1. when scanning parents, get all parents starting from LOGGED entity
            CASE WHEN pi_scan_parents_or_children = 1 THEN
            '  START WITH lower_ent = ' || pi_logged_entity_id || chr(10) ||
            '    AND lower_val = ' || pi_logged_entity_value
            -- 2. when scanning children, get all parents starting from ADJUSTED entity
                 WHEN pi_scan_parents_or_children = 2 THEN
            '  START WITH (lower_ent, lower_val) IN' || chr(10) ||
            '        (SELECT entity_id, entity_e_internal_id FROM modified_children) ' END || chr(10) ||
            'CONNECT BY PRIOR upper_ent = lower_ent' || chr(10) ||
            '       AND PRIOR upper_val = lower_val' || chr(10) ||
            ---------------------
            -- scan children - P1
            ---------------------
            CASE WHEN pi_scan_parents_or_children = 2 THEN
            '  UNION ' || chr(10) ||
            '  SELECT lower_ent,' || chr(10) ||
            '         lower_val,' || chr(10) ||
            '         upper_ent,' || chr(10) ||
            '         upper_val,' || chr(10) ||
            '         CONNECT_BY_ROOT id as product' || chr(10) ||
            '    FROM (SELECT lower_ent, lower_val, upper_ent, upper_val, adj.id' || chr(10) ||
            '            FROM quota_hierarchy_relationships qez' || chr(10) ||
            '            LEFT JOIN modified_children adj' || chr(10) ||
            '              ON qez.lower_ent = adj.entity_id' || chr(10) ||
            '             AND qez.lower_val = adj.entity_e_internal_id)' || chr(10) ||
            '   START WITH (lower_ent, lower_val) IN' || chr(10) ||
            '         (SELECT entity_id, entity_e_internal_id FROM modified_children) ' || chr(10) ||
            '  CONNECT BY PRIOR lower_ent = upper_ent' || chr(10) ||
            '      AND PRIOR lower_val = upper_val' END || ')' || chr(10) ||
            --------
            -- P2 --
            --------
            -------------------------------------------------------------------------------------
            ', existing_requests AS ' || chr(10) ||
            -------------------------------------------------------------------------------------
            '(SELECT qrt.request_id, ' || chr(10) ||
            '        qrt.is_parent_entity, ' || chr(10) ||
            '        COALESCE(' || v_children_ent_list|| ', NULL) AS request_affected_entity_id, ' || chr(10) ||
            '        COALESCE(' || v_children_ent_ids || ') AS request_affected_entity_value, ' || chr(10) ||
            CASE WHEN v_product_col_name IS NOT NULL THEN
            '        qrt.' || v_product_col_name || ' AS product,' END ||chr(10) ||
            '        qrt.modified_by, ' || chr(10) ||
            '        qrt.entity_id, ' || chr(10) ||
            '        qrt.entity_value, ' || chr(10) ||
            '        qrt.hierarchy_level,' || chr(10) ||
            '        qrt.proposed_adjustment, ' || chr(10) ||
            '        qrt.adjustments ' || chr(10) ||
            '  FROM ' || v_request_table_name || ' qrt' || chr(10) || -- requests table
            ' INNER JOIN parents_and_children hier_ent' || chr(10) || -- get all requests started by anyone from parents_and_children list
            '    ON qrt.entity_id = hier_ent.lower_ent' || chr(10) ||
            '   AND qrt.entity_value = hier_ent.lower_val' || chr(10) ||
            CASE WHEN v_product_col_name IS NOT NULL THEN
            '   AND qrt.' || v_product_col_name || ' = hier_ent.id' END || chr(10) ||
            ' WHERE quota_status = 6' || chr(10) ||
            '   AND ' || v_period_col_name || ' = ' || pi_tupr_id || ')' || chr(10) ||
            -------------------------------------------------------------------------------------
            CASE WHEN pi_scan_parents_or_children = 1 THEN
            'SELECT COUNT(*) FROM (' END || chr(10) ||
            'SELECT qrt.request_id, qrt.is_parent_entity, qrt.modified_by, qrt.entity_id, qrt.entity_value, qrt.hierarchy_level ' || chr(10) ||
            '      ,qrt.request_affected_entity_id, request_affected_entity_value ' || chr(10) ||
            CASE WHEN v_product_col_name IS NOT NULL THEN
            '      ,qrt.product ' END || chr(10) ||
            '  FROM existing_requests qrt' || chr(10) ||
            '  WHERE qrt.is_parent_entity = 1 ' || chr(10) ||
            '    AND qrt.request_affected_entity_id = ' || CASE WHEN v_modif_parent_entity_id IS NULL THEN ' NULL ' ELSE TO_CHAR(v_modif_parent_entity_id) END || chr(10) ||
            '    AND qrt.request_affected_entity_value = ' || CASE WHEN v_modif_parent_value IS NULL THEN ' NULL ' ELSE TO_CHAR(v_modif_parent_value) END || chr(10) ||
            '    AND qrt.proposed_adjustment - qrt.adjustments != 0 ' || chr(10) ||

            'UNION' || chr(10) ||
            'SELECT qrt.request_id, qrt.is_parent_entity, qrt.modified_by, qrt.entity_id, qrt.entity_value, qrt.hierarchy_level ' || chr(10) ||
            '      ,qrt.request_affected_entity_id, request_affected_entity_value ' || chr(10) ||
            CASE WHEN v_product_col_name IS NOT NULL THEN
            '      ,qrt.product ' END || chr(10) ||
            '   FROM existing_requests qrt' || chr(10) ||
            '  WHERE qrt.is_parent_entity = 1' || chr(10) ||
            '    AND (qrt.request_affected_entity_id, qrt.request_affected_entity_value) NOT IN (SELECT NVL(' || CASE WHEN v_modif_parent_entity_id IS NULL THEN ' NULL ' ELSE TO_CHAR(v_modif_parent_entity_id) END || ', 1E38),' || chr(10) ||
            '    NVL(' || CASE WHEN v_modif_parent_value IS NULL THEN ' NULL ' ELSE TO_CHAR(v_modif_parent_value) END || ', 1E38) FROM DUAL)' || chr(10) ||
            '    AND EXISTS (SELECT parent_ent, parent_val' || chr(10) ||
            '                  FROM (SELECT lower_ent,' || chr(10) ||
            '                            lower_val,' || chr(10) ||
            '                            CONNECT_BY_ROOT upper_ent AS parent_ent,' || chr(10) ||
            '                            CONNECT_BY_ROOT upper_val AS parent_val' || chr(10) ||
            '                       FROM quota_hierarchy_relationships' || chr(10) ||
            '                      START WITH (lower_ent, lower_val) IN' || chr(10) ||
            '                                 (SELECT request_affected_entity_id,' || chr(10) ||
            '                                         request_affected_entity_value' || chr(10) ||
            '                                    FROM existing_requests' || chr(10) ||
            '                                   where is_parent_entity = 0)' || chr(10) ||
            '                     CONNECT BY PRIOR upper_ent = lower_ent' || chr(10) ||
            '                            AND PRIOR upper_val = lower_val) lower_affected_entity' || chr(10) ||
            '              INNER JOIN modified_children' || chr(10) ||
            '                 ON lower_affected_entity.lower_ent =' || chr(10) ||
            '                    modified_children.entity_id' || chr(10) ||
            '                AND lower_affected_entity.lower_val =' || chr(10) ||
            '                    modified_children.entity_e_internal_id' || chr(10) ||
            '                AND qrt.request_affected_entity_id =  lower_affected_entity.parent_ent' || chr(10) ||
            '                AND qrt.request_affected_entity_value =  lower_affected_entity.parent_val' || chr(10) ||
            '               )' || chr(10) ||

            'UNION ' || chr(10) ||
            'SELECT qrt.request_id, qrt.is_parent_entity, qrt.modified_by, qrt.entity_id, qrt.entity_value, qrt.hierarchy_level ' || chr(10) ||
            '      ,qrt.request_affected_entity_id, request_affected_entity_value ' || chr(10) ||
            CASE WHEN v_product_col_name IS NOT NULL THEN
            '      ,qrt.product ' END || chr(10) ||
            '  FROM existing_requests qrt' || chr(10) ||
            ' INNER JOIN (SELECT parent_ent, parent_val' || chr(10) ||
            '               FROM (SELECT lower_ent,' || chr(10) ||
            '                            lower_val,' || chr(10) ||
            '                            CONNECT_BY_ROOT lower_ent AS parent_ent,' || chr(10) ||
            '                            CONNECT_BY_ROOT lower_val AS parent_val' || chr(10) ||
            '                       FROM quota_hierarchy_relationships' || chr(10) ||
            '                      START WITH (lower_ent, lower_val) IN' || chr(10) ||
            '                                 (SELECT request_affected_entity_id,' || chr(10) ||
            '                                         request_affected_entity_value' || chr(10) ||
            '                                    FROM existing_requests' || chr(10) ||
            '                                   where is_parent_entity = 0)' || chr(10) ||
            '                     CONNECT BY PRIOR lower_ent = upper_ent' || chr(10) ||
            '                            AND PRIOR lower_val = upper_val) lower_affected_entity' || chr(10) ||
            '              INNER JOIN modified_children' || chr(10) ||
            '                 ON lower_affected_entity.lower_ent =' || chr(10) ||
            '                    modified_children.entity_id' || chr(10) ||
            '                AND lower_affected_entity.lower_val =' || chr(10) ||
            '                    modified_children.entity_e_internal_id) affected_entities' || chr(10) ||
            '    ON qrt.request_affected_entity_id =  affected_entities.parent_ent' || chr(10) ||
            '   AND qrt.request_affected_entity_value =  affected_entities.parent_val'  || chr(10) ||
            ' WHERE qrt.proposed_adjustment - qrt.adjustments != 0' || chr(10) ||
            CASE WHEN pi_scan_parents_or_children = 1 THEN ') FETCH FIRST 1 ROW ONLY' END;


    IF pi_scan_parents_or_children = 1 THEN
       EXECUTE IMMEDIATE v_sql INTO v_upper_no_of_values USING IN pi_modified_col_mapping;
       -- if pi_scan_parents_or_children = 1 raise else return cursor
       IF v_upper_no_of_values >= 1 THEN
        RAISE_APPLICATION_ERROR(-20911, 'One or more parents have already started a request');
       END IF;

    ELSIF pi_scan_parents_or_children = 2 THEN
      OPEN pout_result FOR v_sql USING pi_modified_col_mapping;
      IF pout_result%FOUND THEN
        FETCH pout_result INTO l_requests_rec_type;
        pout_canceled_requests_no := pout_result%ROWCOUNT;
      ELSE
        pout_canceled_requests_no :=0;
      END IF;
    END IF;

END SCAN_HIERARCHY_FOR_WF_REQUESTS;



-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20170801
-- Description: Procedure that populates Initial Quotas table from a Sales Planning model
-----------------------------------------------------------------------------------------
-- Parameters:
/*
pi_tupr_id                   IN tu_periods_range.tupr_id%TYPE - the period for which the process is executed
pi_qd_id                     IN quota_definitions.qd_id%TYPE  - id of the definition
pi_iq_qe_mapping             IN TABLETYPE_NAME_MAP            - iq column names
pi_import_query              IN CLOB                          - the query from sales planning used to populate IQ
pi_replace_or_append         IN NUMBER                        - option to replace or append records in IQ
pout_result                  OUT SYS_REFCURSOR                - validations cursor
pout_no_rec_failed           OUT NUMBER                       - number of records failed
pout_no_rec_updated_inserted OUT NUMBER                       - number of records updated or inserted
*/
-----------------------------------------------------------------------------------------
PROCEDURE IMPORT_IQ_FROM_PLANNING_MODEL(pi_tupr_id                   IN tu_periods_range.tupr_id%TYPE,
                                        pi_qd_id                     IN quota_definitions.qd_id%TYPE,
                                        pi_iq_qe_mapping             IN TABLETYPE_NAME_MAP,
                                        pi_field_mapping             IN TABLETYPE_ID_ID,
                                        pi_hierarchy_mapping         IN TABLETYPE_ID_ID,
                                        pi_import_query              IN CLOB,
                                        pi_replace_or_append         IN NUMBER,
                                        pout_result                  OUT SYS_REFCURSOR,
                                        pout_no_rec_failed           OUT NUMBER,
                                        pout_no_rec_updated_inserted OUT NUMBER)

IS

v_stamp                 VARCHAR2(250 CHAR);
v_has_add_static_fields NUMBER(1);
v_no_rec_failed         NUMBER(10) := 0;
v_iq_table_name         VARCHAR2(30 CHAR);
v_period_column_name    VARCHAR2(30 CHAR);
v_product_col_name      VARCHAR2(30 CHAR);
v_case_sql              VARCHAR2(4000 CHAR);
v_ent_list_sql          VARCHAR2(4000 CHAR);
v_quotas_cols_list      VARCHAR2(4000 CHAR);
v_model_cols_list       VARCHAR2(4000 CHAR);
v_model_alias_list       VARCHAR2(4000 CHAR);
v_field_mappings        VARCHAR2(4000 CHAR);
v_ent_match_condition   VARCHAR2(4000 CHAR);
v_model_cols_list_dist  VARCHAR2(4000 CHAR);
v_import_query          CLOB;



BEGIN



  v_stamp := 'QUOTAS.IMPORT_IQ_FROM_PLANNING_MODEL - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF' );
  pout_no_rec_failed := 0;

    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_tupr_id),           ',pi_tupr_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_qd_id),             ',pi_qd_id => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_iq_qe_mapping), ',pi_iq_qe_mapping => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_hierarchy_mapping), ',pi_hierarchy_mapping => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pi_import_query),        ',pi_import_query => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_replace_or_append), ',pi_replace_or_append => <value>', v_stamp);
    END;


 -- ****************************************************************************************************
 -- I. VALIDATE INPUT PARAMETERS
 -- ****************************************************************************************************

    IF pi_tupr_id IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_tupr_id' ));
    END IF;

    IF pi_qd_id IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_qd_id' ));
    END IF;

    IF pi_iq_qe_mapping IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_iq_qe_mapping'));
    END IF;

    IF pi_import_query IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_q_mapping'));
    END IF;

    IF pi_replace_or_append IS NULL THEN
        raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_hierarchy_query'));
    END IF;


    -- if the quota definition has static fields
    SELECT COUNT(1) INTO v_has_add_static_fields FROM quota_additional_fields qaf WHERE qaf.qaf_qd_id = pi_qd_id AND qaf.qaf_type = 0 AND ROWNUM <= 1;

    -- get IQ table name, product column name, period column name
    SELECT iq_table.tables_physical_name,
           period_column.tc_physical_name,
           tc_product.tc_physical_name
      INTO v_iq_table_name, v_period_column_name, v_product_col_name
      FROM quota_definitions qd
      LEFT JOIN tables iq_table
        ON qd.qd_iq_tables_id = iq_table.tables_id
      LEFT JOIN table_columns iq_table_columns
        ON iq_table_columns.tc_tables_id = iq_table.tables_id
      LEFT JOIN table_columns period_column
        ON period_column.tc_tables_id = iq_table.tables_id
       AND period_column.tc_logic_type= 8
      LEFT JOIN table_columns tc_product
        ON tc_product.tc_tables_id = qd.qd_adj_tables_id
       AND tc_product.tc_entity_id = qd.qd_multiple_q_entity_id
     WHERE qd.qd_id = pi_qd_id
       AND iq_table_columns.tc_physical_name NOT IN ('ROW_IDENTIFIER', 'ROW_VERSION')
     GROUP BY iq_table.tables_physical_name, period_column.tc_physical_name, tc_product.tc_physical_name;
    -- generate case condition use to replace entity values with NULL for upper levels in model table query
    SELECT LISTAGG('CASE WHEN ' || e.entity_id || ' = group_entities.id2 THEN ' ||
                   tc.tc_physical_name || ' ELSE NULL END AS ' ||
                   tc.tc_physical_name || CHR(10),
                   ', ') WITHIN GROUP(ORDER BY 1),
           LISTAGG('<alias>' || tc.tc_physical_name, ', ') WITHIN GROUP(ORDER BY 1),
           LISTAGG('dst.' || tc.tc_physical_name || ' = src.' || tc.tc_physical_name, ' OR ') WITHIN GROUP(ORDER BY 1),
           quotas_cols.quotas_cols_list,
           model_cols.model_cols_list,
           model_alias.model_alias_list,
           field_mappings.map_cols_list,
           model_cols_dist.model_cols_list
      INTO v_case_sql, v_ent_list_sql, v_ent_match_condition, v_quotas_cols_list, v_model_cols_list, v_model_alias_list, v_field_mappings, v_model_cols_list_dist
      FROM TABLE(pi_iq_qe_mapping) iq_columns
     INNER JOIN table_columns tc
        ON iq_columns.name1 = tc.tc_physical_name
     INNER JOIN quota_definitions qd
        ON qd.qd_iq_tables_id = tc.tc_tables_id
     INNER JOIN entities e
        ON tc.tc_entity_id = e.entity_id
     LEFT JOIN (SELECT LISTAGG('<alias>' || f.fld_column_name, ', ') WITHIN GROUP (ORDER BY fld_mapping.id1) AS quotas_cols_list
                  FROM TABLE(pi_field_mapping) fld_mapping
                 INNER JOIN fields f
                    ON fld_mapping.id1 = f.fld_id) quotas_cols ON 1=1
     LEFT JOIN (SELECT LISTAGG('<alias>' || f.fld_column_name || ' a' || rownum, ', ') WITHIN GROUP (ORDER BY fld_mapping.id1) AS model_cols_list
                  FROM TABLE(pi_field_mapping) fld_mapping
                 INNER JOIN fields f
                    ON fld_mapping.id2 = f.fld_id) model_cols ON 1=1
     LEFT JOIN (SELECT LISTAGG('src.' || 'a' || ROWNUM, ', ') WITHIN GROUP (ORDER BY fld_mapping.id1) AS model_alias_list
                  FROM TABLE(pi_field_mapping) fld_mapping) model_alias ON 1=1
     LEFT JOIN (SELECT LISTAGG('dst.' || quota_fields.fld_column_name || ' = src.' || 'a' || rownum, ', ') WITHIN GROUP (ORDER BY fld_mapping.id1) AS map_cols_list
                  FROM TABLE(pi_field_mapping) fld_mapping
                 INNER JOIN fields model_fields
                    ON fld_mapping.id2 = model_fields.fld_id
                 LEFT JOIN fields quota_fields
                    ON fld_mapping.id1 = quota_fields.fld_id) field_mappings ON 1=1
     LEFT JOIN (SELECT LISTAGG('<alias>' || fld.fld_column_name, ', ') WITHIN GROUP (ORDER BY fld.id1) AS model_cols_list
                  FROM (SELECT f.fld_column_name, fld_mapping.id1, ROW_NUMBER() OVER (PARTITION BY f.fld_column_name ORDER BY fld_mapping.id1) AS rn
                          FROM TABLE(pi_field_mapping) fld_mapping
                         INNER JOIN fields f
                            ON fld_mapping.id2 = f.fld_id) fld WHERE rn = 1) model_cols_dist ON 1=1
     WHERE qd.qd_id = pi_qd_id
     GROUP BY quotas_cols.quotas_cols_list, model_cols.model_cols_list, model_alias.model_alias_list, field_mappings.map_cols_list, model_cols_dist.model_cols_list;


     v_import_query :=
       'SELECT model_query.' || v_period_column_name || ', ' || chr(10) ||
       CASE WHEN v_product_col_name IS NOT NULL THEN
       '       model_query.' || v_product_col_name || ', ' END || chr(10) ||
       '       ' || v_case_sql || ', ' || chr(10) ||
       '       ' || REPLACE(v_model_cols_list_dist, '<alias>', 'model_query.')  || chr(10) ||
       '  FROM (' || pi_import_query || ') model_query' || chr(10) ||
       ' INNER JOIN TABLE(:pi_hierarchy_mapping) group_entities' || chr(10) ||
       '    ON model_query.gr_idx = group_entities.id1';



    -- truncate validations temp table
    EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_QUOTAS_VALIDATIONS';

 -- ****************************************************************************************************
 -- II. VALIDATE NEGATIVE QUOTA
 -- ****************************************************************************************************
    VALIDATE_NEGATIVE_QUOTA(pi_vnq_tupr_id           => pi_tupr_id,
                            pi_vnq_qd_id             => pi_qd_id,
                            pi_vnq_iq_q_mapping      => pi_iq_qe_mapping,
                            pi_vnq_field_mapping     => pi_field_mapping,
                            pi_vnq_hierarchy_mapping => pi_hierarchy_mapping,
                            pi_vnq_import_query      => v_import_query,
                            pout_vnq_failed_no       => v_no_rec_failed
                            );
    pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_rec_failed,0);

 -- ****************************************************************************************************
 -- III. VALIDATE NUMBER OF DECIMALS FOR QUOTA FIELD
 -- ****************************************************************************************************
    VALIDATE_NO_OF_DECIMALS(pi_vod_tupr_id           => pi_tupr_id,
                            pi_vod_qd_id             => pi_qd_id,
                            pi_vod_field_mapping     => pi_field_mapping,
                            pi_vod_hierarchy_mapping => pi_hierarchy_mapping,
                            pi_vod_import_query      => v_import_query,
                            pout_vod_failed_val_no   => v_no_rec_failed
                            );
    pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_rec_failed,0);

 -- ****************************************************************************************************
 -- IV. VALIDATE NUMBER OF DECIMALS FOR STATIC FIELDS
 -- ****************************************************************************************************
    IF v_has_add_static_fields = 1 THEN

     VALIDATE_FIELD_DECIMALS(pi_vfd_tupr_id           => pi_tupr_id,
                             pi_vfd_qd_id             => pi_qd_id,
                             pi_vfd_iq_q_mapping      => pi_iq_qe_mapping,
                             pi_vfd_calling_process   => 1,
                             pi_vfd_field_mapping     => pi_field_mapping,
                             pi_vfd_hierarchy_mapping => pi_hierarchy_mapping,
                             pi_vfd_import_query      => v_import_query ,
                             pi_vfd_field_data_type   => 1,
                             pout_vfd_failed_val_no   => v_no_rec_failed
                             );
      pout_no_rec_failed := pout_no_rec_failed + NVL(v_no_rec_failed,0);
    END IF;

    IF pout_no_rec_failed = 0 THEN

 -- ****************************************************************************************************
 -- V. IMPORT DATA FROM SALES PLANNING - REPLACE OPTION
 -- ****************************************************************************************************
      IF pi_replace_or_append = 0 THEN

        EXECUTE IMMEDIATE 'DELETE FROM ' || v_iq_table_name || ' WHERE ' || v_period_column_name || ' = ' || pi_tupr_id;
        EXECUTE IMMEDIATE 'BEGIN ' || chr(10) ||
                          'INSERT INTO ' || v_iq_table_name || '(' || v_period_column_name || ', ' || chr(10) ||
                          '                                      ' || CASE WHEN v_product_col_name IS NOT NULL THEN v_product_col_name || ', ' END || chr(10) ||
                          '                                      ' || REPLACE(v_ent_list_sql, '<alias>', '') || ', ' || chr(10) ||
                          '                                      ' || REPLACE(v_quotas_cols_list, '<alias>', '') || chr(10) ||
                          '                                      ' || ', ROW_IDENTIFIER, ROW_VERSION)' || chr(10) ||
                          ' SELECT ' || v_period_column_name || ', ' || chr(10) ||
                          '        ' || CASE WHEN v_product_col_name IS NOT NULL THEN v_product_col_name || ', ' END || chr(10) ||
                          '        ' || REPLACE(v_ent_list_sql, '<alias>', '') || ', '  || chr(10) ||
                          '        ' || REPLACE(v_model_cols_list, '<alias>', '') || ', ' || chr(10) ||
                          '        ' || v_iq_table_name || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0 ' || chr(10) ||
                          '   FROM ' || ' (' || v_import_query || ');' || chr(10) ||
                          ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                          'END;' USING IN pi_hierarchy_mapping, OUT pout_no_rec_updated_inserted;



 -- ****************************************************************************************************
 -- VI. IMPORT DATA FROM SALES PLANNING - APPEND OPTION
 -- ****************************************************************************************************
     ELSIF pi_replace_or_append = 1 THEN
      EXECUTE IMMEDIATE 'BEGIN ' || chr(10) ||
                        'MERGE INTO ' || v_iq_table_name || ' dst' || chr(10) ||
                        'USING (SELECT ' || v_period_column_name || ', ' || chr(10) ||
                                       CASE WHEN v_product_col_name IS NOT NULL THEN v_product_col_name || ', ' END || chr(10) ||
                        '              ' || REPLACE(v_ent_list_sql, '<alias>', '') || ', '  || chr(10) ||
                        '              ' || REPLACE(v_model_cols_list, '<alias>', '') || chr(10) ||
                        '         FROM ' || ' (' || v_import_query || ')) src' || chr(10) ||
                        '   ON (dst.' || v_period_column_name || ' = src.' || v_period_column_name || chr(10) ||
                        CASE WHEN v_product_col_name IS NOT NULL THEN
                        '  AND dst.' || v_product_col_name || ' = src.' || v_product_col_name END || chr(10) ||
                        '  AND (' || v_ent_match_condition || '))' || chr(10) ||
                        'WHEN MATCHED THEN ' || chr(10) ||
                        '   UPDATE SET ' || v_field_mappings || chr(10) ||
                        'WHEN NOT MATCHED THEN ' || chr(10) ||
                        '    INSERT (dst.' || v_period_column_name || ', ' || chr(10) ||
                                     CASE WHEN v_product_col_name IS NOT NULL THEN 'dst.' || v_product_col_name || ', ' END || chr(10) ||
                        '            ' || REPLACE(v_ent_list_sql, '<alias>', 'dst.') || ', ' || chr(10) ||
                        '            ' || REPLACE(v_quotas_cols_list, '<alias>', 'dst.') || chr(10) ||
                        '            ' || ', ROW_IDENTIFIER, ROW_VERSION)' || chr(10) ||
                        '     VALUES (src.' || v_period_column_name || ', ' || chr(10) ||
                                      CASE WHEN v_product_col_name IS NOT NULL THEN 'src.' || v_product_col_name || ', ' END || chr(10) ||
                        '             ' || REPLACE(v_ent_list_sql, '<alias>', 'src.') || ', '  || chr(10) ||
                        '             ' || REPLACE(v_model_alias_list, '<alias>', 'src.') || ', ' || chr(10) ||
                        '             ' || v_iq_table_name || '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0);' || chr(10) ||
                        ':SQLROWCNT := SQL%ROWCOUNT;'|| CHR(10 ) ||
                        'END;' USING IN pi_hierarchy_mapping, OUT pout_no_rec_updated_inserted;
      END IF;
    END IF;


    OPEN pout_result FOR 'SELECT /*+ CARDINALITY(TMP ' || pout_no_rec_failed || ') */ TMP.* FROM TEMP_QUOTAS_VALIDATIONS TMP';

  EXCEPTION

    WHEN NO_DATA_FOUND THEN
     COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(pin_definition_id => pi_qd_id);
     ROLLBACK;
      raise_application_error(commons_exceptions.e_NoMetadata_code,commons_exceptions.e_NoMetadata_msg);

/*    WHEN OTHERS THEN
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE , SQLERRM , v_stamp);
     RAISE;  */

END IMPORT_IQ_FROM_PLANNING_MODEL;


-- ========================================================
-- Author     : Banea, Elena
-- Create date: 20140922
-- Description: Procedure that saves and cascades the modifications made by the user
--      (http://confluence.optymyze.net/display/SD/Saving+quotas)
-----------------------------------------------------------------------------------------
-- Parameters:
/*
  pi_svqmm_qd_id                IN quota_definitions.qd_iq_tables_id%type, -- id of the definition
  pi_svqmm_tupr_id              IN tu_periods_range.tupr_id%type,          -- the period for which the process is executed
  pi_svqmm_modified_col_mapping IN TABLETYPE_ID_ID_VALUE                   -- mapping between:
                                                                           --         -> E_INTERNAL_ID for the product that is being modified
                                                                           --         -> ENTITIES.ENTITY_ID - ID of the entity being modified
                                                                           --         -> E_INTERNAL_ID of the value from Quota Entities table
                                                                           --         -> modified Quota value (Adjustments column from UI)
*/
-----------------------------------------------------------------------------------------
PROCEDURE SAVE_QUOTAS_MODIFY_MODE ( pi_svqmm_qd_id                IN quota_definitions.qd_iq_tables_id%type ,
                                    pi_svqmm_tupr_id              IN tu_periods_range.tupr_id%type ,
                                    pi_svqmm_modified_col_mapping IN TABLETYPE_ID_ENTITY_VALUE,
                                    pi_svqmm_modified_parent_map  IN TABLETYPE_ID_ENTITY_VALUE,
                                    pi_svqmm_parent_allocation    IN TABLETYPE_ID_ENTITY_VALUE,
                                    pi_svqmm_hierarchy_query      IN CLOB,
                                    pi_svqmm_q_mapping            IN tabletype_name_map,
                                    pi_quotas_table_query         IN CLOB,
                                    pi_qe_table_query1            IN CLOB,
                                    pi_qe_table_query2            IN CLOB,
                                    pi_qe_table_query3            IN CLOB,
                                    pi_hierarchy_type             IN NUMBER, -- 1 - distinct, 2 - recursive, 3 - semirecursive
                                    pi_save_exceed_threshold      IN NUMBER,
                                    pi_workflow_save              IN NUMBER,
                                    pi_logged_entity_id           IN NUMBER,
                                    pi_logged_entity_value        IN NUMBER,
                                    pout_threshold_validations    OUT SYS_REFCURSOR,
                                    pout_wf_validations           OUT SYS_REFCURSOR
                                  )
AS
    v_stamp                 VARCHAR2(250 CHAR);
    v_sql                   CLOB;
    v_from                  CLOB;
    v_parent_joins          CLOB;
    v_adj_parents_sql       CLOB;
    v_adj_table_name        tables.tables_physical_name% type;
    v_no_of_rec_inserted    NUMBER;
    v_failed_threshold_cnt  NUMBER := 0;
    v_warning_threshold_cnt NUMBER := 0;
    v_quota_has_product     NUMBER(1);
    v_has_product_hierarchy NUMBER(1);
    v_calculate_contrib     NUMBER(1);
    v_has_calc_fields       NUMBER(1);
    v_updated_rows          tabletype_id_id;
    v_modified_ent_count    NUMBER(10);
    v_updated_cb            NUMBER(10);
    v_canceled_requests_no  NUMBER(10);


BEGIN
  v_stamp := 'QUOTAS.SAVE_QUOTAS_MODIFY_MODE - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_svqmm_qd_id),                   ',pi_svqmm_qd_id => <value>' , v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(pi_svqmm_tupr_id),                 ',pi_svqmm_tupr_id => <value>' , v_stamp);
  END;


  -- ****************************************************************************************************
  -- I. VALIDATE INPUT PARAMETERS
  -- ****************************************************************************************************
  IF pi_svqmm_qd_id IS NULL THEN
    raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_svqmm_qd_id'));
  END IF;

  IF pi_svqmm_tupr_id IS NULL THEN
    raise_application_error(commons_exceptions.e_NullParam_code,commons_exceptions.error_text(commons_exceptions.e_NullParam_msg, 'pi_svqmm_tupr_id'));
  END IF;

  -- ****************************************************************************************************
  -- II. WORKFLOW - SCAN IF ANY PARENTS HAVE ALREADY STARTED A REQUEST
  -- ****************************************************************************************************
  IF pi_logged_entity_id IS NOT NULL THEN
    SCAN_HIERARCHY_FOR_WF_REQUESTS(pi_qd_id                    => pi_svqmm_qd_id,
                                   pi_tupr_id                  => pi_svqmm_tupr_id,
                                   pi_iq_q_mapping             => pi_svqmm_q_mapping,
                                   pi_modified_col_mapping     => pi_svqmm_modified_col_mapping,
                                   pi_modified_parent_map      => pi_svqmm_modified_parent_map,
                                   pi_logged_entity_id         => pi_logged_entity_id,
                                   pi_logged_entity_value      => pi_logged_entity_value,
                                   pi_scan_parents_or_children => 1,
                                   pout_result                 => pout_wf_validations,
                                   pout_canceled_requests_no   => v_canceled_requests_no
    );
  END IF;

  -- ****************************************************************************************************
  -- III. GET DATA NEEDED
  -- ****************************************************************************************************
  v_updated_rows := tabletype_id_id();

  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_QUOTAS_MODIFY_SAVE';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_QUOTAS_EXCEED_THRESHOLD';


  SELECT qd.qd_calculate_contribution,
         (SELECT COUNT(1)
            FROM quota_additional_fields qaf
           WHERE qaf.qaf_qd_id = pi_svqmm_qd_id
             AND qaf.qaf_type = 1
             AND ROWNUM <= 1),
         t.tables_physical_name,
         qd.qd_include_quota_hierarchy
    INTO v_calculate_contrib, v_has_calc_fields, v_adj_table_name, v_has_product_hierarchy
    FROM quota_definitions qd
   INNER JOIN tables t
      ON qd.qd_adj_tables_id = t.tables_id
   WHERE qd.qd_id = pi_svqmm_qd_id;



  IF pi_svqmm_modified_col_mapping IS NOT NULL THEN

    v_modified_ent_count := pi_svqmm_modified_col_mapping.count();

    SELECT '(SELECT tt.*,'|| CHR(10 ) ||
           '        ROW_NUMBER() OVER (PARTITION BY upper_entity_id, qe_upper_value'||
           -- product column
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN ', product_id'
           END ||
           ' ORDER BY upper_entity_id, qe_upper_value,' ||
           -- product column
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN ' product_id,'
           END || ' lower_entity_id, lower_entity_value ' ||
           ') AS RN'|| CHR(10 ) ||
           ' FROM '|| CHR(10 ) ||
           '                 (SELECT DISTINCT t.*,' || CHR(10) ||
           '                        ' || CASE WHEN INSTR(t1.parent_entity_group_alias,',' ) = 0
                                              THEN t1.parent_entity_group_alias
                                              ELSE 'COALESCE(' ||t1.parent_entity_group_alias||')'
                                          END|| ' AS parent_entity_value,'|| CHR( 10) ||
           '                        ' || t1.parent_entity_type_group|| CHR(10) ||
           '                        -- delta = updated Current Quota - Current Quota = (Initial Quota + Adjusted value) - Current Quota'|| CHR(10) ||
           '                        CASE WHEN t.hlevel = t.parent_hlevel THEN (adj_lo_initial_quota + ui_adj.value) - adj_lo_current_quota END AS delta,' || CHR(10) ||
           '                        ' ||qd.qd_no_of_decimals||' AS no_of_decimals,' || CHR( 10) ||
           '                        qnzsr.qnzsr_threshold_percentage,' || CHR(10) ||
           '                        qnzsr.qnzsr_threshold_min_value,'|| CHR(10) ||
           '                        qnzsr.qnzsr_threshold_max_value,'|| CHR(10) ||
           '                        qnzsr.qnzsr_threshold_type,'|| CHR(10) ||
           '                        qnzsr.qnzsr_allow_threshold,' || CHR(10) ||
           '                        qnzsr.qnzsr_option_exceed' || CHR(10) ||
           '                 FROM' || CHR(10) ||
           '                   (' || CHR(10) ||
           '                    SELECT DISTINCT ' || t3.qe_upper_value_group || ',' || CHR(10) ||
           '                           ' ||t2.qe_column_values_group|| CHR(10) ||
           '                           ' ||t1.parent_entity_group||','|| CHR(10) ||
           '                           ' ||t1.entity_group||','|| CHR( 10) ||
           -- product column
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN '                           qe.product_id  AS product_id,'
                ELSE '                           -1 AS product_id,'
           END || CHR(10) ||
           '                           ' ||t3.upper_entity_id_group||','|| CHR(10) ||
           '                           ' ||t2.lower_entity_id_group||','|| CHR(10) ||
           '                           ' ||t2.lower_entity_value_group,
           -- --------------------------- v_from
           -- Quotas Entities table
           '                    FROM ( SELECT qe.*, ' || chr(10) ||
           '                                   adj_lo.current_quota AS adj_lo_current_quota, ' || chr(10) ||
           '                                   adj_lo.row_identifier AS adj_lo_row_identifier, ' || chr(10) ||
           '                                   adj_up.row_identifier AS adj_up_row_identifier, ' || chr(10) ||
           '                                   adj_lo.initial_quota AS adj_lo_initial_quota, ' || chr(10) ||
           '                                   adj_lo.adjustments AS adj_lo_adjustment, ' || chr(10) ||
           '                                 ' || CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                                                       THEN '                           adj_lo.' ||
                                                          adj_pr.tc_physical_name || ' AS product_id'
                                                       ELSE '                           -1 AS product_id'
                                                  END || CHR(10 ) || '
                                       FROM ' ||qe_t.tables_physical_name||' qe ' || CHR(10) ||
           -- join with Quotas table
           '                      INNER JOIN ' ||adj_t.tables_physical_name || ' adj_lo ON (' || t2.qe_adj_join_conditions_group || ')' || CHR( 10) ||
           -- product column
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN '                                                        AND adj_lo.' ||
                     adj_pr.tc_physical_name || ' IN ('|| to_clob(pr.list_of_product_ids) ||')'
           END || CHR(10 ) ||
           '                      LEFT JOIN ' ||adj_t.tables_physical_name || ' adj_up ON (' || t3.adj_up_join_condition || ')' || CHR(10) ||
           -- period condition for Quotas table
           '                                                                           AND adj_up.'||adj_tc.tc_physical_name|| ' = '|| pi_svqmm_tupr_id || CHR(10) ||
           -- product column
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN '                                                        AND adj_up.' ||
                     adj_pr.tc_physical_name || ' IN ('|| pr.list_of_product_ids ||')' ||CHR(10) ||
                     '                                                        AND adj_up.'||
                     adj_pr.tc_physical_name || ' = adj_lo.'||adj_pr.tc_physical_name
           END || CHR(10 ) ||
           '                 -- period condition' || CHR(10) ||
           -- period condition for Quota Entities table
           '                 WHERE qe.' ||qe_tc.tc_physical_name||' = '|| pi_svqmm_tupr_id || CHR(10 ) ||
           -- period condition for Quotas table
           '                   AND adj_lo.' ||adj_tc.tc_physical_name||' = '|| pi_svqmm_tupr_id || ') qe ' || CHR( 10) ||
           -- join with entity tables
           t2.qe_upper_left_join_group || CHR( 10) ||

           '                 START WITH (' ||t1.start_with_clause || ')' || CHR(10) ||
           '                 CONNECT BY PRIOR ' ||t3.connect_by_condition || CHR(10) ||
           '                 ) t' ,
           -- --------------------------- v_parent_joins
           '                -- parent ' || CHR(10) ||
           '                LEFT JOIN ' || adj_t.tables_physical_name || ' parent_adj ON ('||t1.adj_parent_ent_alias|| ')'|| CHR(10 ) ||
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN '                                                                         AND parent_adj.' ||adj_pr.tc_physical_name || ' = t.product_id'
           END || CHR(10 ) ||
           '                INNER JOIN TABLE(' || mcol.mapped_cols || ') ui_adjp ON ('|| t1.ui_adj_join_conditionp|| ')'|| CHR(10 ) ||
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN '                                                                     AND ui_adjp.id = t.product_id'|| CHR( 10)
           END  ||
           '                                                                               AND ui_adjp.value != parent_adj.adjustments ' || CHR( 10) ||
           '                INNER JOIN TABLE(' || mcol.mapped_cols || ') ui_adj ON ('|| t1.ui_adj_join_condition|| ')'|| CHR(10 ) ||
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN '                                                                     AND ui_adj.id = t.product_id'|| CHR( 10)
           END  ||
           '                                                                               AND ( ( t.hlevel = t.parent_hlevel AND ui_adj.value != t.adj_lo_adjustment ) OR t.hlevel != t.parent_hlevel)' || CHR( 10) ||
           '                LEFT JOIN (SELECT qer.qer_entity_id, '                                || CHR(10) ||
           '                                  qer.qer_level, '                                    || CHR(10) ||
           '                                  qnzs.qnzsr_level, '                                 || CHR(10) ||
           '                                  qnzs.qnzsr_allow_threshold,'                        || CHR(10) ||
           '                                  qnzs.qnzsr_threshold_percentage,'                   || CHR(10) ||
           '                                  qnzs.qnzsr_threshold_min_value,'                    || CHR(10) ||
           '                                  qnzs.qnzsr_threshold_max_value,'                    || CHR(10) ||
           '                                  qnzs.qnzsr_threshold_type,'                         || CHR(10) ||
           '                                  qnzs.qnzsr_option_exceed'                           || CHR(10) ||
           '                  FROM quota_entity_relations qer'                                    || CHR(10) ||
           '                 INNER JOIN quotas_non_zero_sum_relations qnzs'                       || CHR(10) ||
           '                    ON qer.qer_id = qnzs.qnzsr_qer_id '                               || CHR(10) ||
           '                 WHERE qer_qd_id = ' || pi_svqmm_qd_id || ') qnzsr'                   || CHR(10) ||
           CASE WHEN pi_hierarchy_type = 1 THEN
           '       ON lower_entity_id = qnzsr.qer_entity_id AND hlevel = qnzsr.qer_level'
                WHEN pi_hierarchy_type = 2 THEN
           '       ON lower_entity_id = qnzsr.qer_entity_id AND hlevel = qnzsr.qnzsr_level'
                WHEN pi_hierarchy_type = 3 THEN
           '       ON lower_entity_id = qnzsr.qer_entity_id AND hlevel = NVL(qnzsr.qnzsr_level, hlevel)' END  || CHR(10) ||
           '                ) tt )' ,
           adj_t.tables_physical_name,
           CASE WHEN adj_pr.tc_physical_name IS NOT NULL -- there is a product column
                THEN 1 ELSE 0
           END, qd.qd_include_quota_hierarchy
        INTO v_sql, v_from, v_parent_joins, v_adj_table_name, v_quota_has_product, v_has_product_hierarchy
      FROM       quota_definitions qd
          -- Quota Entities table name
          INNER JOIN tables          qe_t   ON qd.qd_qe_tables_id = qe_t.tables_id
          -- Quota Entities period column
          INNER JOIN table_columns   qe_tc  ON qe_tc.tc_tables_id = qd.qd_qe_tables_id
                                            -- effective period
                                            AND qe_tc.tc_logic_type = 8
          -- Quotas table name
          INNER JOIN tables          adj_t  ON qd.qd_adj_tables_id = adj_t.tables_id
          -- Quotas period column
          INNER JOIN table_columns   adj_tc ON adj_tc.tc_tables_id = qd.qd_adj_tables_id
                                            -- effective period
                                            AND adj_tc.tc_logic_type = 8
          -- product column name in Quotas table
          LEFT JOIN table_columns   adj_pr ON adj_pr.tc_tables_id = qd.qd_adj_tables_id
                                            AND adj_pr.tc_entity_id = qd.qd_multiple_q_entity_id
          CROSS JOIN (SELECT LISTAGG(id, ', ') WITHIN GROUP (ORDER BY 1 ) AS list_of_product_ids
                      FROM TABLE (pi_svqmm_modified_col_mapping) ) pr
      CROSS JOIN (SELECT 'TABLETYPE_ID_ENTITY_VALUE('||
                       LISTAGG_JAVA(OBJTYPE_WORD_DLM('OBJTYPE_ID_ENTITY_VALUE(' || CASE WHEN id IS NOT NULL THEN id || ',' ELSE 'NULL,' END ||
                                                         entity_id || ',' || entity_e_internal_id || ',' || value|| ', 0' || ', 0' ||
                       ')',' , ', v_modified_ent_count)) || ')'
                       as mapped_cols
                  FROM TABLE (pi_svqmm_modified_col_mapping)
                 ) mcol
      -- always 1 row
      CROSS JOIN (SELECT LISTAGG(parent_entity_group , ',')
                            WITHIN GROUP (ORDER BY 1) AS parent_entity_group,
                         LISTAGG(entity_group , ',')
                            WITHIN GROUP (ORDER BY 1) AS entity_group,
                         LISTAGG(parent_entity_group_alias , ',') WITHIN GROUP (ORDER BY 1) AS parent_entity_group_alias,
                         'CASE '||LISTAGG(parent_entity_type_group,' ' )
                                            WITHIN GROUP (ORDER BY 1) ||' END AS parent_entity_type,' AS parent_entity_type_group,
                         LISTAGG( start_with_clause, ' OR ')  WITHIN GROUP (ORDER BY 1) AS start_with_clause,
                         LISTAGG(ui_adj_join_condition, ' OR ')  WITHIN GROUP (ORDER BY 1) AS ui_adj_join_condition,
                         LISTAGG(ui_adj_join_conditionp, ' OR ')  WITHIN GROUP (ORDER BY 1) AS ui_adj_join_conditionp,
                         LISTAGG(adj_parent_ent_alias , ' OR ') WITHIN GROUP (ORDER BY 1)  AS adj_parent_ent_alias
               FROM
                    ( SELECT DISTINCT 'connect_by_root qe.'|| CASE WHEN qe_e.entity_base_entity IS NOT NULL THEN qe_tc.tc_physical_name||' AS parent_'||qe_tc.tc_entity_id|| '_value'
                                        -- the adjustment is made to the lowest entity
                                        ELSE qe_tc_up.tc_physical_name||' AS parent_'||qe_tc_up.tc_entity_id|| '_value' END AS parent_entity_group,
                          'qe.'||CASE WHEN qe_e.entity_base_entity IS NOT NULL THEN qe_tc.tc_physical_name||' AS qe_'||qe_tc.tc_entity_id|| '_value'
                                        -- the adjustment is made to the lowest entity
                                        ELSE qe_tc_up.tc_physical_name||' AS qe_'||qe_tc_up.tc_entity_id|| '_value' END AS entity_group,
                          CASE WHEN qe_e.entity_base_entity IS NOT NULL THEN 'parent_' ||qe_tc.tc_entity_id||'_value'
                                        -- the adjustment is made to the lowest entity
                                        ELSE 'parent_'||qe_tc_up.tc_entity_id||'_value' END AS parent_entity_group_alias,
                          CASE WHEN qe_e.entity_base_entity IS NOT NULL THEN 'WHEN parent_' ||qe_tc.tc_entity_id||'_value IS NOT NULL THEN '||qe_tc.tc_entity_id
                                               -- the adjustment is made to the lowest entity
                                               ELSE 'WHEN parent_'||qe_tc_up.tc_entity_id|| '_value IS NOT NULL THEN '||qe_tc_up.tc_entity_id
                                          END  AS parent_entity_type_group,
                          'qe.'||CASE WHEN qe_e.entity_base_entity IS NOT NULL THEN qe_tc.tc_physical_name
                                      -- the adjustment is made to the lowest entity
                                      ELSE qe_tc_up.tc_physical_name
                                END || ' IN (' ||adj_ent.ent_internal_ids || ') ' AS start_with_clause,
                          '(ui_adj.entity_id = '||COALESCE(qe_e.entity_base_entity,qe_e.entity_id)|| ' AND ui_adj.entity_e_internal_id = t.parent_'||
                                        COALESCE(qe_e.entity_base_entity,qe_e.entity_id)||'_value ' ||')' AS ui_adj_join_condition
                          , '(ui_adjp.entity_id = '||COALESCE(qe_e.entity_base_entity,qe_e.entity_id)|| ' AND ui_adjp.entity_e_internal_id = t.parent_'||
                                        COALESCE(qe_e.entity_base_entity,qe_e.entity_id)||'_value ' ||')' AS ui_adj_join_conditionp,
                          CASE WHEN qe_e.entity_base_entity IS NOT NULL THEN '(parent_adj.' ||qe_tc_adj.adj_parent_col||' IS NOT NULL AND parent_adj.'||qe_tc_adj.adj_parent_col|| ' = t.'||
                               'parent_'||qe_tc.tc_entity_id||'_value)'
                                        -- the adjustment is made to the lowest entity
                                        ELSE '(parent_adj.'||qe_tc_adj.adj_parent_col||' IS NOT NULL AND parent_adj.'||qe_tc_adj.adj_parent_col|| ' = t.'||
                                'parent_'||qe_tc_up.tc_entity_id||'_value)' END AS adj_parent_ent_alias
                    FROM         quota_definitions qd
                    -- Quota Entities - upper columns
                    INNER JOIN table_columns    qe_tc_up   ON qe_tc_up.tc_tables_id = qd.qd_qe_tables_id
                    inner JOIN entities         qe_e       ON qe_e.entity_id = qe_tc_up.tc_entity_id
                    -- Determine the entities that are at the lowest levels in Entity Relationship
                         LEFT  JOIN (SELECT DISTINCT qer.qer_entity_id AS leaf_entity_id
                                     FROM quota_entity_relations qer
                                     WHERE qer.qer_qd_id = pi_svqmm_qd_id
                                       AND CONNECT_BY_ISLEAF=1
                                       START WITH qer.qer_entity_id in (SELECT distinct entity_id
                                               FROM TABLE(pi_svqmm_modified_col_mapping))
                                       CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
                                     ) qer ON qe_e.entity_id = qer.leaf_entity_id
                    LEFT JOIN table_columns    qe_tc   ON qe_tc.tc_tables_id = qd.qd_qe_tables_id
                                                        AND qe_tc.tc_entity_id = qe_e.entity_base_entity
                    -- Quotas table
                    LEFT JOIN (SELECT entity_id, LISTAGG(entity_e_internal_id,',' ) WITHIN GROUP ( ORDER BY 1) AS ent_internal_ids
                                FROM TABLE (pi_svqmm_modified_col_mapping)
                               GROUP BY entity_id) adj_ent ON adj_ent.entity_id = qe_e.entity_id
                                                           OR adj_ent.entity_id = qe_e.entity_base_entity
                    LEFT JOIN (SELECT adj_tc.tc_tables_id,adj_tc.tc_entity_id AS adj_ent_id,
                                      adj_tc.tc_physical_name AS adj_parent_col
                                FROM         quota_definitions qd
                                INNER JOIN table_columns    adj_tc   ON adj_tc.tc_tables_id = qd.qd_adj_tables_id
                                INNER JOIN entities         adj_ent  ON adj_ent.entity_id = adj_tc.tc_entity_id
                                WHERE qd.qd_id = pi_svqmm_qd_id
                               ) qe_tc_adj ON qe_tc_adj.tc_tables_id = qd.qd_adj_tables_id
                                           AND qe_tc_adj.adj_ent_id = adj_ent.entity_id
                    WHERE qd.qd_id = pi_svqmm_qd_id
                      AND -- upper entity
                        (qe_e.entity_base_entity in (SELECT distinct entity_id FROM TABLE (pi_svqmm_modified_col_mapping))
                         OR
                         (qe_e.entity_base_entity IS NULL AND qer.leaf_entity_id in (SELECT distinct entity_id FROM TABLE(pi_svqmm_modified_col_mapping)) )
                        )
                 )
         ) t1
      -- always 1 row
      CROSS JOIN (SELECT 'COALESCE('||LISTAGG( 'TO_CHAR('||qe_et.tables_physical_name||'.' || qe_etc.tc_physical_name||')' ,',')
                              WITHIN GROUP (ORDER BY 1)||',NULL) AS qe_column_values, -- bk' AS qe_column_values_group,
                         LISTAGG( '                      LEFT JOIN '||qe_et.tables_physical_name|| ' ON '||qe_et.tables_physical_name|| '.e_internal_id = qe.'||
                                             qe_tc_all.tc_physical_name  ,' ')
                              WITHIN GROUP (ORDER BY 1) AS qe_upper_left_join_group,
                         'CASE '|| LISTAGG('WHEN qe.'||qe_tc_all.tc_physical_name|| ' IS NOT NULL THEN '||qe_tc_all.tc_entity_id, ' ')
                                     WITHIN GROUP (ORDER BY 1)||' END AS lower_entity_id' AS lower_entity_id_group,
                         'COALESCE('|| LISTAGG('qe.'||qe_tc_all.tc_physical_name,', ' )
                                     WITHIN GROUP (ORDER BY 1)||', NULL) AS lower_entity_value' AS lower_entity_value_group,
                         LISTAGG( 'qe.'||qe_tc_all.tc_physical_name||' = adj_lo.'||adj_tc.tc_physical_name , ' OR ')
                                        WITHIN GROUP (ORDER BY 1) AS qe_adj_join_conditions_group
                  FROM         quota_definitions qd
                  -- Quota Entities - all entity columns that are adjusted or a children of the adjusted columns
                  INNER JOIN table_columns    qe_tc_all   ON qe_tc_all.tc_tables_id = qd.qd_qe_tables_id
                  INNER JOIN entities    qe_e_all   ON qe_e_all.entity_id = qe_tc_all.tc_entity_id
                  -- Determine the entities that are at a lower level then the entities modified
                  INNER  JOIN (SELECT DISTINCT qer.qer_entity_id AS entity_ids--,
                                         -- CASE WHEN CONNECT_BY_ISLEAF=1 THEN qer.qer_entity_id END AS leaf_entity_id
                                   FROM quota_entity_relations qer
                                   WHERE qer.qer_qd_id = pi_svqmm_qd_id
                                     START WITH qer.qer_entity_id in (SELECT distinct entity_id
                                       FROM TABLE(pi_svqmm_modified_col_mapping))
                                     CONNECT BY PRIOR qer.qer_id = qer.qer_parent_node_id
                                   ) qer ON qe_tc_all.tc_entity_id = qer.entity_ids
                  -- determine business key of the entity for which adjustments were made
                  INNER JOIN tables           qe_et   ON qe_et.tables_id = qe_e_all.entity_tables_id
                  LEFT JOIN table_columns     qe_etc  ON qe_etc.tc_tables_id = qe_et.tables_id
                                                      AND qe_etc.tc_logic_type IN (1, 5) -- business key

                  -- Quotas table (adjustments)
                  LEFT JOIN table_columns      adj_tc  ON adj_tc.tc_tables_id = qd.qd_adj_tables_id
                                                        AND adj_tc.tc_entity_id = qe_tc_all.tc_entity_id
                  WHERE qd.qd_id = pi_svqmm_qd_id
                        AND qe_tc_all.tc_logic_type IN (1, 5) -- entity
                        AND qe_e_all.entity_base_entity IS NULL -- not an upper entity
                  ) t2
      -- always 1 row
      CROSS JOIN (SELECT LISTAGG(  'qe.'||qe_column_name||' = qe.'||upper_qe_column_name, ' OR PRIOR ')
                                     WITHIN GROUP (ORDER BY 1) AS connect_by_condition,
                         'CASE '|| LISTAGG('WHEN qe.'||upper_qe_column_name|| ' IS NOT NULL THEN '||tc_entity_id,' ' )
                                     WITHIN GROUP (ORDER BY 1)||' END as upper_entity_id' AS upper_entity_id_group,
                         'COALESCE('||LISTAGG('qe.' ||upper_qe_column_name,', ')
                             WITHIN GROUP (ORDER BY 1)  ||',NULL) AS qe_upper_value' AS qe_upper_value_group,
                         LISTAGG( 'qe.'||upper_qe_column_name||' = adj_up.'||adj_column_name , ' OR ')
                            WITHIN GROUP (ORDER BY 1)  AS adj_up_join_condition
                  FROM
                      ( SELECT DISTINCT
                             qe_tc.tc_physical_name AS qe_column_name,
                             qe_tc_up.tc_physical_name AS upper_qe_column_name,
                             qe_tc.tc_entity_id,
                             adj_tc.tc_physical_name AS adj_column_name
                      FROM quota_entity_relations qer
                      INNER JOIN quota_entity_relations qer_p ON qer.qer_parent_node_id = qer_p.qer_id
                      INNER JOIN quota_definitions qd ON qd.qd_id = qer.qer_qd_id
                      INNER JOIN table_columns qe_tc ON qe_tc.tc_tables_id = qd.qd_qe_tables_id
                                               AND qe_tc.tc_entity_id = qer_p.qer_entity_id
                      INNER JOIN table_columns qe_tc_up ON  qe_tc_up.tc_tables_id = qd.qd_qe_tables_id
                      INNER JOIN entities qe_tc_up_e ON qe_tc_up.tc_entity_id =  qe_tc_up_e.entity_id
                                 AND qe_tc_up_e.entity_base_entity = qer_p.qer_entity_id
                      -- Quotas table
                      -- lower column names in Quotas table
                      LEFT JOIN table_columns    adj_tc   ON adj_tc.tc_tables_id = qd.qd_adj_tables_id
                                                         AND adj_tc.tc_entity_id = qe_tc_up_e.entity_base_entity
                      WHERE qer.qer_qd_id = pi_svqmm_qd_id AND qer_p.qer_qd_id = pi_svqmm_qd_id
                      )
                  ) t3
      WHERE qd.qd_id = pi_svqmm_qd_id;

      -- cascading algorithm
      v_sql := 'DECLARE ' || CHR(10 )||
               '   v_rcq                  NUMBER;' || CHR(10)||
               '   v_delta                NUMBER;' || CHR(10)||
               '   v_diff                 NUMBER;' || CHR(10)||
               '   v_sum_rcq              NUMBER;' || CHR(10)||
               '   v_no_of_rec_inserted   NUMBER := 0;' || CHR(10)||
               '   v_failed_threshold_cnt NUMBER := 0;' || CHR(10) ||
               '   v_sql                  CLOB;' || CHR(10)||
               'BEGIN' || CHR(10 )||
               '   FOR t IN (WITH qv AS '||v_sql|| CHR(10 )||
               '                           ,qe.hierarchy_level AS hlevel,'|| CHR(10) ||
               '                           connect_by_root qe.hierarchy_level AS parent_hlevel,'|| CHR( 10) ||
               '                           qe.adj_lo_current_quota AS adj_lo_current_quota,'|| CHR( 10) ||
               '                           qe.adj_lo_row_identifier AS adj_lo_row_identifier,'|| CHR( 10) ||
               '                           qe.adj_up_row_identifier AS adj_up_row_identifier,'|| CHR( 10) ||
               '                           qe.adj_lo_initial_quota AS adj_lo_initial_quota,'|| CHR( 10) ||
               '                           qe.adj_lo_adjustment AS adj_lo_adjustment'|| CHR( 10) ||
                             v_from|| CHR( 10)||
                             v_parent_joins|| CHR( 10)||
               '             SELECT c.*,' || CHR(10)||
               '                  -- if all current quota values in the set are 0, the software uses the same algorithm except that the CI is calculated ' || CHR(10)||
               '                  -- assuming all the new quota values are equal ' || CHR(10)||
               '                  -- (i.e., CI is 1/n, WHERE n is the number of current quota values in the set). ' || CHR( 10)||
               '                  CASE WHEN cc.sum_cq != 0 AND delta IS NULL AND no_of_values_in_the_set != 1' || CHR( 10)||
               '                          THEN c.adj_lo_current_quota/cc.sum_cq' || CHR( 10)||
               '                       WHEN delta IS NOT NULL or no_of_values_in_the_set=1 THEN 1' || CHR( 10)||
               '                       ELSE 1/no_of_values_in_the_set' || CHR(10)||
               '                  END AS ci,' || CHR(10)||
               '                  cc.no_of_values_in_the_set,' || CHR(10)||
               '                  cc.sum_cq' || CHR(10)||
               '              FROM qv c' || CHR(10)||
               '              INNER JOIN (SELECT hlevel, upper_entity_id, qe_upper_value,product_id,' || CHR( 10)||
               '                           -- number of subordinates ' || CHR(10)||
               '                           COUNT(*) AS no_of_values_in_the_set,' || CHR( 10)||
               '                           -- number of subordinates that have a positive Current Quota value' || CHR( 10)||
               '                           SUM(CASE WHEN adj_lo_current_quota > 0 THEN 1 ELSE 0 END) AS no_of_positive_values,' || CHR(10)||
               '                           SUM(adj_lo_current_quota) AS sum_cq' || CHR(10)||
               '                          FROM qv' || CHR(10)||
               '                          GROUP BY hlevel, upper_entity_id, qe_upper_value,product_id) cc ON c.upper_entity_id = cc.upper_entity_id ' || CHR( 10)||
               '                                                                              AND c.qe_upper_value=cc.qe_upper_value' || CHR( 10)||
               '                                                                              AND c.hlevel = cc.hlevel' || CHR( 10)||
               '                                                                              AND c.product_id = cc.product_id'|| CHR( 10)||
               '             WHERE c.hlevel = c.parent_hlevel -- the node where the adjustment was made' || CHR( 10)||
               '               OR --  If all of the subordinates have a zero Current Quota value, the distribution is made among all of the subordinates' || CHR(10)||
               '                    (cc.sum_cq=0 ' || CHR(10)||
               '                     AND cc.no_of_positive_values = 0' || CHR(10)||
               '                    )' || CHR(10)||
               '               OR -- If one or more of the subordinates have a positive Current Quota value, the distribution is made among only those subordinates ' || CHR( 10)||
               '                  -- that have a positive Current Quota value' || CHR(10)||
               '                    (cc.sum_cq != 0 AND adj_lo_current_quota > 0 AND cc.no_of_positive_values != 0'|| CHR( 10)||
               '                    )' || CHR(10)||
               '              ORDER BY c.hlevel, rn ' || CHR(10)||
               '             )' || CHR(10)||
               '   LOOP'|| CHR(10 ) ||
               '    IF t.hlevel != t.parent_hlevel THEN' || CHR(10) ||
               '      SELECT COUNT(*) INTO v_rcq ' || CHR(10) ||
               '          FROM temp_quotas_modify_save i ' || CHR(10) ||
               '          WHERE t.qe_upper_value = i.tqms_qe_lower_value '|| CHR(10) ||
               '              AND t.upper_entity_id = i.tqms_qe_lower_entity_id'|| CHR( 10) ||
               CASE WHEN v_quota_has_product = 1 THEN
                    '              AND i.tqms_product_id=t.product_id'
               END||
               ';'|| CHR(10 ) ||
               '    ELSE v_rcq :=1;'|| CHR(10 ) ||
               '    END IF;'|| CHR(10 ) ||
               '     IF v_rcq > 0 THEN' || CHR(10) ||
               '      IF t.delta IS NULL THEN' || CHR(10) ||
               '        SELECT adj.tqms_rcq-adj.tqms_current_quota ' || CHR(10) ||
               '          INTO v_delta' || CHR(10) ||
               '        FROM temp_quotas_modify_save adj' || CHR(10) ||
               '        WHERE adj.tqms_adj_row_identifier = t.adj_up_row_identifier'|| CHR( 10) ||
               CASE WHEN v_quota_has_product = 1 THEN
                    '              AND adj.tqms_product_id=t.product_id'
               END||
                ';'|| CHR(10 ) ||
               '      ELSE' || CHR(10) ||
               '        v_delta := t.delta;' || CHR(10) ||
               '      END IF;' || CHR(10) ||
               '      v_rcq := round(t.adj_lo_current_quota+COALESCE(t.delta,v_delta)*t.ci,t.no_of_decimals);'|| CHR(10 ) ||
               '      -- The cascaded adjustment to a subordinate fails if updated Current Quota value after the cascaded distribution is a negative number'|| CHR( 10) ||
               '      -- If an error is returned, the entire save step fails (i.e., no quotas are updated). '|| CHR( 10) ||
               '      IF v_rcq < 0 THEN' || CHR(10) ||
               '         raise_application_error(-20910,''entity="''||t.parent_entity_type||'';''||t.parent_entity_value||'';''||TO_CHAR(t.hlevel - t.parent_hlevel)||'';''||
                                                                      t.product_id||''"'');'|| CHR( 10) ||
               '      END IF;' || CHR(10) ||
               -- use insert into a temp table because we need the calculated delta value from previous nodes
               -- E.g. for node N from the hierarchy, delta depends on node n-1, which depends on node n-2, which depends on node n-3 ... which depends on the first modified node
               '      INSERT INTO temp_quotas_modify_save (tqms_adj_row_identifier,'|| CHR( 10) ||
               '                                           tqms_delta,'|| CHR(10) ||
               '                                           tqms_no_of_decimals,'|| CHR( 10) ||
               '                                           tqms_rcq,'|| CHR(10) ||
               '                                           tqms_current_quota,'|| CHR( 10) ||
               '                                           tqms_initial_quota,'|| CHR( 10) ||
               '                                           tqms_ci,'|| CHR(10) ||
               '                                           tqms_qe_column_values,'|| CHR( 10) ||
               '                                           tqms_qe_hlevel,'|| CHR( 10) ||
               '                                           tqms_root_entity_id,'|| CHR( 10) ||
               '                                           tqms_root_entity_value,'|| CHR( 10) ||
               '                                           tqms_qe_upper_value,'|| CHR( 10) ||
               '                                           tqms_qe_upper_entity_id,'|| CHR( 10) ||
               '                                           tqms_qe_lower_value,'|| CHR( 10) ||
               '                                           tqms_qe_lower_entity_id,'|| CHR( 10) ||
               '                                           tqms_no_of_values_in_the_set,'|| CHR( 10) ||
               '                                           tqms_outstanding_allocation'|| CHR( 10) ||
               CASE WHEN v_quota_has_product = 1 THEN
                    '                                           ,tqms_product_id'
               END|| CHR(10 ) ||
               '                                          )' || CHR(10) ||
               '      VALUES (t.adj_lo_row_identifier, ' || CHR(10) ||
               '              v_delta, ' || CHR(10) ||
               '              t.no_of_decimals, ' || CHR(10) ||
               '              v_rcq, ' || CHR(10) ||
               '              t.adj_lo_current_quota, ' || CHR(10) ||
               '              t.adj_lo_initial_quota, ' || CHR(10) ||
               '              t.ci, ' || CHR(10) ||
               '              t.qe_column_values, ' || CHR(10) ||
               '              t.hlevel,' || CHR(10) ||
               '              t.parent_entity_type, ' || CHR(10) ||
               '              t.parent_entity_value, ' || CHR(10) ||
               '              t.qe_upper_value, ' || CHR(10) ||
               '              t.upper_entity_id,' || CHR(10) ||
               '              t.lower_entity_value,' || CHR(10) ||
               '              t.lower_entity_id,' || CHR(10) ||
               '              t.no_of_values_in_the_set,' || CHR(10) ||
               '              0 ' || CHR(10) ||
               CASE WHEN v_quota_has_product = 1 THEN
                    '                                           ,t.product_id'
               END|| CHR(10 ) ||
               '             );' || CHR(10) ||
               '      v_no_of_rec_inserted := v_no_of_rec_inserted+1;' || CHR(10) ||
               '      IF t.rn = t.no_of_values_in_the_set THEN ' || CHR(10) ||
               '           SELECT SUM(adj.tqms_rcq)' || CHR(10) ||
               '             INTO v_sum_rcq' || CHR(10) ||
               '           FROM temp_quotas_modify_save adj' || CHR(10) ||
               '           WHERE adj.tqms_qe_upper_value = t.qe_upper_value'|| CHR( 10) ||
               '             AND adj.tqms_qe_upper_entity_id = t.upper_entity_id'|| CHR( 10) ||
               CASE WHEN v_quota_has_product = 1 THEN
                    '             AND adj.tqms_product_id = t.product_id'
               END||
                ';'|| CHR(10 ) ||
               '           v_diff := CASE WHEN t.delta IS NULL THEN v_delta - ( v_sum_rcq - t.sum_cq) ELSE 0 END;'|| CHR( 10) ||
               '           IF v_diff < 0 AND v_sum_rcq = 0 THEN' || CHR(10) ||
               '             raise_application_error(-20910,''entity="''||t.parent_entity_type||'';''||t.parent_entity_value||'';''||TO_CHAR(t.hlevel - t.parent_hlevel)||'';''||
                                                                      t.product_id||''"'');'|| CHR( 10) ||
               '            END IF;' || CHR(10) ||
               '            IF v_diff != 0 THEN' || CHR(10) ||
               '               v_sql := ''UPDATE TEMP_QUOTAS_MODIFY_SAVE adj'|| CHR(10) ||
               '               SET adj.TQMS_RCQ  = (SELECT CASE WHEN rn > no_of_units THEN tqms_rcq'|| CHR( 10) ||
               '                                                   WHEN '' || v_diff || '' > 0 THEN tqms_rcq + one_unit'|| CHR( 10) ||
               '                                                   ELSE tqms_rcq - one_unit'|| CHR( 10) ||
               '                                                 END AS updated_cq_value'|| CHR( 10) ||
               '                                          FROM' || CHR(10) ||
               '                                              (SELECT d.tqms_adj_row_identifier,'|| CHR( 10) ||
               '                                                     d.tqms_qe_upper_value,d.tqms_qe_upper_entity_id,'|| CHR( 10) ||
               '                                                     d.tqms_initial_quota,'|| CHR( 10) ||
               '                                                     d.tqms_rcq,'|| CHR(10) ||
               '                                                     tqms_rcq -(tqms_current_quota + (tqms_delta*tqms_ci)) AS re,'|| CHR( 10) ||
               '                                                     one_unit,'|| CHR(10) ||
               '                                                     -- the maximum number of units that would need to be distributed will be not more than 1/2 (half) '|| CHR( 10) ||
               '                                                     -- the number of quotas into which the quota is being distributed'|| CHR(10) ||
               '                                                     CASE WHEN no_of_units < max_no_of_units'|| CHR( 10) ||
               '                                                          THEN no_of_units'|| CHR( 10) ||
               '                                                          ELSE max_no_of_units'|| CHR( 10) ||
               '                                                     END AS no_of_units,'|| CHR( 10) ||
               '                                                     ROW_NUMBER() OVER (PARTITION BY tqms_qe_hlevel, tqms_root_entity_value,'|| CHR( 10) ||
               '                                                                                     tqms_root_entity_id, tqms_qe_upper_value'||
               CASE WHEN v_quota_has_product = 1 THEN
                              ', tqms_product_id'
               END|| CHR(10 ) ||
               '                                                                        ORDER BY tqms_qe_hlevel, tqms_root_entity_value,'|| CHR( 10) ||
               '                                                                                 tqms_root_entity_id, tqms_qe_upper_value,'' || '|| CHR( 10) ||
               '                                                                    CASE WHEN v_diff > 0 THEN ''re ASC'' ELSE ''re DESC'' END||'',''|| '|| CHR(10) ||
               '                                                                    CASE WHEN v_diff > 0 THEN ''tqms_current_quota DESC'' ELSE ''tqms_current_quota ASC'' END||'','|| CHR( 10) ||
               '                                                                                 -- subordinate groups are displayed in alphabetical order based on the value '|| CHR(10) ||
               '                                                                                 -- to display in the organization hierarchy entity column'|| CHR( 10) ||
               '                                                                                 tqms_qe_column_values'|| CHR( 10) ||
               '                                                                      ) AS rn'|| CHR(10) ||
               '                                              FROM'|| CHR(10) ||
               '                                                  (SELECT d.tqms_adj_row_identifier, '|| CHR( 10) ||
               '                                                     d.tqms_initial_quota,'|| CHR( 10) ||
               '                                                     d.tqms_rcq,tqms_ci,'|| CHR( 10) ||
               '                                                     d.tqms_qe_column_values,'|| CHR( 10) ||
               '                                                     d.tqms_current_quota,'|| CHR( 10) ||
               '                                                     d.tqms_qe_hlevel, d.tqms_root_entity_value, '|| CHR( 10) ||
               '                                                     d.tqms_root_entity_id, d.tqms_qe_upper_value,d.tqms_qe_upper_entity_id,'|| CHR( 10) ||
               '                                                     d.tqms_delta,'|| CHR(10) ||
               '                                                     tqms_rcq -(tqms_current_quota + (tqms_delta*tqms_ci)) AS re,'|| CHR( 10) ||
               '                                                     1/power(10,tqms_no_of_decimals) AS one_unit,'|| CHR( 10) ||
               '                                                     -- ABS is used to assure we have a positive number'|| CHR( 10) ||
               '                                                     ABS( ''|| v_diff || '' / (1/power(10,tqms_no_of_decimals))) AS no_of_units, '|| CHR(10) ||
               '                                                     TRUNC(tqms_no_of_values_in_the_set/2)  AS max_no_of_units'||
               CASE WHEN v_quota_has_product = 1 THEN
                              ', tqms_product_id'
               END|| CHR(10 ) ||
               '                                                   FROM TEMP_QUOTAS_MODIFY_SAVE d'|| CHR( 10) ||
               '                                                   ) d'|| CHR(10) ||
               '                                              ) d'|| CHR(10) ||
               '                                           WHERE d.tqms_qe_upper_value =  adj.tqms_qe_upper_value'|| CHR( 10) ||
               '                                                 and d.tqms_qe_upper_entity_id = adj.tqms_qe_upper_entity_id'|| CHR( 10) ||
               '                                                 and d.tqms_adj_row_identifier = adj.tqms_adj_row_identifier)'|| CHR( 10) ||
               '               WHERE adj.tqms_qe_upper_value = :1 ' || CHR(10) ||
               '               AND adj.tqms_qe_upper_entity_id = :2 ' || CHR(10) ||
               CASE WHEN v_quota_has_product = 1 THEN
                              '               AND adj.tqms_product_id= :3 '
               END||
               ' '';'|| CHR(10 ) ||
               CASE WHEN v_quota_has_product = 1 THEN
                              '               EXECUTE IMMEDIATE v_sql USING IN t.qe_upper_value, t.upper_entity_id, t.product_id;'
                    ELSE      '               EXECUTE IMMEDIATE v_sql USING IN t.qe_upper_value, t.upper_entity_id;'
               END||CHR(10 ) ||
               '           END IF;' || CHR(10) ||
               '       END IF;' || CHR(10) ||
               '      END IF;' || CHR(10) ||
                -- threshold
               '      IF t.qnzsr_allow_threshold = 1 AND t.delta IS NULL THEN ' || CHR(10) ||
               '        IF (t.qnzsr_threshold_type = 0 AND (ABS(v_rcq - t.adj_lo_initial_quota) > t.adj_lo_initial_quota * t.qnzsr_threshold_percentage))' || chr(10) ||
               '            OR (t.qnzsr_threshold_type = 1 AND((v_rcq - t.adj_lo_initial_quota) NOT BETWEEN t.qnzsr_threshold_min_value AND t.qnzsr_threshold_max_value)) THEN ' || chr(10) ||
               '          INSERT INTO tmp_quotas_exceed_threshold(tqet_entity_id,' || chr(10) ||
               '                                                  tqet_entity_internal_id,' || chr(10) ||
               '                                                  tqet_entity_value,' || chr(10) ||
               '                                                  tqet_product_id,' || chr(10) ||
               '                                                  tqet_level,' || chr(10) ||
               '                                                  tqet_threshold_type,' || chr(10) ||
               '                                                  tqet_threshold_percentage,' || chr(10) ||
               '                                                  tqet_threshold_min,' || chr(10) ||
               '                                                  tqet_threshold_max,' || chr(10) ||
               '                                                  tqet_adjustment,' || chr(10) ||
               '                                                  tqet_parent_entity_id,' || chr(10) ||
               '                                                  tqet_parent_entity_value,' || chr(10) ||
               '                                                  tqet_initial_quota,' || chr(10) ||
               '                                                  tqet_option_exceed' || chr(10) ||
               '                                               )' || chr(10) ||
               '            VALUES (t.lower_entity_id,' || chr(10) ||
               '                    t.lower_entity_value,' || chr(10) ||
               '                    t.qe_column_values,' || chr(10) ||
               '                    t.product_id,' || chr(10) ||
               '                    t.hlevel,' || chr(10) ||
               '                    t.qnzsr_threshold_type,' || chr(10) ||
               '                    t.qnzsr_threshold_percentage,' || chr(10) ||
               '                    t.qnzsr_threshold_min_value,' || chr(10) ||
               '                    t.qnzsr_threshold_max_value,' || chr(10) ||
               '                    (v_rcq - t.adj_lo_initial_quota),' || chr(10) ||
               '                    t.parent_entity_type,' || chr(10) ||
               '                    t.parent_entity_value,' || chr(10) ||
               '                    t.adj_lo_initial_quota,' || chr(10) ||
               '                    t.qnzsr_option_exceed);' || chr(10) ||
               '          v_failed_threshold_cnt := v_failed_threshold_cnt + 1;' || CHR(10) ||
               '          END IF;' || chr(10) ||
               '        END IF;' || chr(10) ||
               '   END LOOP;'|| CHR(10 ) ||
               ':no_of_rec_inserted := v_no_of_rec_inserted;' || CHR(10) ||
               'END;';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql), ',populate TEMP_QUOTAS_MODIFY_SAVE => <value>', v_stamp);

    EXECUTE IMMEDIATE v_sql USING OUT v_no_of_rec_inserted;
  END IF;

  -- ****************************************************************************************************
  -- IV. NON ZERO SUM ADJUSTMENTS - allows adjustments for current level (parent)
  -- ****************************************************************************************************


  IF pi_svqmm_modified_parent_map IS NOT NULL THEN

    SELECT 'INSERT INTO TEMP_QUOTAS_MODIFY_SAVE'                                                     || chr(10) ||
         '  (TQMS_ADJ_ROW_IDENTIFIER,'                                                               || chr(10) ||
         '   TQMS_QE_LOWER_VALUE,'                                                                   || chr(10) ||
         '   TQMS_QE_LOWER_ENTITY_ID,'                                                               || chr(10) ||
         '   TQMS_RCQ,'                                                                              || chr(10) ||
         '   TQMS_CURRENT_QUOTA, '                                                                   || chr(10) ||
         '   TQMS_INITIAL_QUOTA,'                                                                    || chr(10) ||
         '   TQMS_OUTSTANDING_ALLOCATION)'                                                           || chr(10) ||
         '  SELECT q_table.row_identifier,'                                                          || chr(10) ||
         '         parent_adj.entity_e_internal_id,'                                                 || chr(10) ||
         '         parent_adj.entity_id,'                                                            || chr(10) ||
         '         ROUND(q_table.initial_quota + parent_adj.value, ' || qd.qd_no_of_decimals || '),' || chr(10) ||
         '         q_table.current_quota, '                                                          || chr(10) ||
         '         q_table.initial_quota,'                                                           || chr(10) ||
         '         parent_adj.outstanding_allocation'                                                || chr(10) ||
         '    FROM ' || t.tables_physical_name || ' q_table'                                         || chr(10) ||
         '   INNER JOIN TABLE(:pi_svqmm_modified_parent_map) parent_adj'                             || chr(10) ||
         '      ON q_table.' || tc.tc_physical_name || ' = parent_adj.entity_e_internal_id'          || chr(10) ||
               CASE WHEN tc_product.tc_physical_name IS NOT NULL THEN
         '     AND q_table.' || tc_product.tc_physical_name || ' = parent_adj.id' END                || chr(10) ||
         '     AND q_table.' || tc_period.tc_physical_name || ' = ' || pi_svqmm_tupr_id
    INTO v_adj_parents_sql
    FROM quota_definitions qd
   INNER JOIN tables t
      ON qd.qd_adj_tables_id = t.tables_id
   INNER JOIN table_columns tc
      ON t.tables_id = tc.tc_tables_id
   INNER JOIN (SELECT parent_adjustments.entity_id
                 FROM TABLE(pi_svqmm_modified_parent_map) parent_adjustments
                WHERE ROWNUM <= 1) parent_adjustments
      ON parent_adjustments.entity_id = tc.tc_entity_id
    LEFT JOIN table_columns tc_product
      ON t.tables_id = tc_product.tc_tables_id
     AND tc_product.tc_entity_id = qd.qd_multiple_q_entity_id
    LEFT JOIN table_columns tc_period
      ON t.tables_id = tc_period.tc_tables_id
     AND tc_period.tc_logic_type = 8
   WHERE qd.qd_id = pi_svqmm_qd_id;

  EXECUTE IMMEDIATE v_adj_parents_sql USING pi_svqmm_modified_parent_map;
  v_no_of_rec_inserted := v_no_of_rec_inserted + SQL%ROWCOUNT;

  END IF;


  -- ****************************************************************************************************
  -- V. UPDATE QUOTAS TABLE
  -- ****************************************************************************************************
  SELECT COUNT(*) INTO v_failed_threshold_cnt FROM tmp_quotas_exceed_threshold WHERE tqet_option_exceed = 0 AND rownum <= 1;
  SELECT COUNT(*) INTO v_warning_threshold_cnt FROM tmp_quotas_exceed_threshold WHERE tqet_option_exceed = 1 AND rownum <= 1;

  IF pi_logged_entity_id IS NOT NULL THEN
    SCAN_HIERARCHY_FOR_WF_REQUESTS(pi_qd_id                    => pi_svqmm_qd_id,
                                   pi_tupr_id                  => pi_svqmm_tupr_id,
                                   pi_iq_q_mapping             => pi_svqmm_q_mapping,
                                   pi_modified_col_mapping     => pi_svqmm_modified_col_mapping,
                                   pi_modified_parent_map      => pi_svqmm_modified_parent_map,
                                   pi_logged_entity_id         => pi_logged_entity_id,
                                   pi_logged_entity_value      => pi_logged_entity_value,
                                   pi_scan_parents_or_children => 2,
                                   pout_result                 => pout_wf_validations,
                                   pout_canceled_requests_no   => v_canceled_requests_no
    );
  END IF;

  IF v_failed_threshold_cnt = 0 AND (v_warning_threshold_cnt = 0 OR (v_warning_threshold_cnt = 1 AND pi_save_exceed_threshold = 1)) THEN
     -- check if def has workflow in quota definition; if worflow_save = 1 but the scan for children returned requests => fail
     IF pi_workflow_save = 1 AND NVL(v_canceled_requests_no, 0) = 0
     THEN
      v_sql := 'UPDATE '|| v_adj_table_name || ' adj'|| CHR(10 ) ||
               'SET (adj.current_quota,
                     adj.adjustments ' ||
                     CASE WHEN pi_svqmm_modified_parent_map IS NOT NULL THEN ', adj.outstanding_allocation' END
                     || ')
               = (SELECT /*+ CARDINALITY(tmp '||v_no_of_rec_inserted|| ')*/ tqms_rcq AS updated_cq_value, '|| CHR( 10) ||
               -- new Adjustments value formula:
               -- (updated Current Quota after distribution) - (currently saved Initial Quota value).
               '                    tqms_rcq - tqms_initial_quota AS adjustment_value'|| CHR( 10) ||
                                    CASE WHEN pi_svqmm_modified_parent_map IS NOT NULL
                                         THEN ', tmp.tqms_outstanding_allocation'
                                    END || CHR(10) ||
               '                                             FROM TEMP_QUOTAS_MODIFY_SAVE tmp'|| CHR( 10) ||
               '                                             WHERE tmp.tqms_adj_row_identifier = adj.row_identifier '|| CHR( 10) ||
               '                                             )'|| CHR(10) ||
               'WHERE EXISTS (SELECT /*+ CARDINALITY(tmp '||v_no_of_rec_inserted|| ')*/ 1'|| CHR(10 ) ||
               '              FROM TEMP_QUOTAS_MODIFY_SAVE TMP' || CHR(10) ||
               '              WHERE tmp.tqms_adj_row_identifier = adj.row_identifier'|| CHR( 10) ||
               '              )' ;



      EXECUTE IMMEDIATE v_sql;

      -- in case allow non-zero sum adjustments is checked, rollup outstanding allocation for immediate upper entity
      -- from organizational hierarchy
      IF pi_svqmm_parent_allocation IS NOT NULL THEN
        SELECT  'MERGE INTO ' || v_adj_table_name || ' dst' || chr(10) ||
                'USING (SELECT parent_allocation.entity_id,' || chr(10) ||
                '              parent_allocation.outstanding_allocation,' || chr(10) ||
                '              parent_allocation.entity_e_internal_id,' || chr(10) ||
                '              parent_allocation.id' || chr(10) ||
                '         FROM TABLE(:pi_svqmm_parent_allocation) parent_allocation) src' || chr(10) ||
                'ON (dst.' || tc.tc_physical_name || ' = src.entity_e_internal_id ' || chr(10) ||
                 CASE WHEN tc_product.tc_physical_name IS NOT NULL THEN
                '     AND dst.' || tc_product.tc_physical_name || ' = src.id ' END || chr(10) ||
                '     AND dst.' || tc_period.tc_physical_name || ' = ' || pi_svqmm_tupr_id || ')' || chr(10) ||
                'WHEN MATCHED THEN' || chr(10) ||
                '  UPDATE' || chr(10) ||
                '     SET dst.outstanding_allocation = dst.outstanding_allocation - src.outstanding_allocation'
          INTO v_sql
          FROM quota_definitions qd
         INNER JOIN tables t
            ON qd.qd_adj_tables_id = t.tables_id
         INNER JOIN table_columns tc
            ON t.tables_id = tc.tc_tables_id
         INNER JOIN (SELECT parent_allocation.entity_id,
                            parent_allocation.outstanding_allocation,
                            parent_allocation.entity_e_internal_id,
                            parent_allocation.id
                       FROM TABLE(pi_svqmm_parent_allocation) parent_allocation
                      WHERE ROWNUM <= 1) parent_allocation
            ON parent_allocation.entity_id = tc.tc_entity_id
          LEFT JOIN table_columns tc_product
            ON t.tables_id = tc_product.tc_tables_id
           AND tc_product.tc_entity_id = qd.qd_multiple_q_entity_id
          LEFT JOIN table_columns tc_period
            ON t.tables_id = tc_period.tc_tables_id
           AND tc_period.tc_logic_type = 8
         WHERE qd.qd_id = pi_svqmm_qd_id;

         EXECUTE IMMEDIATE v_sql USING pi_svqmm_parent_allocation;
       END IF;

      -- ****************************************************************************************************
      -- VI. ROLLUP QUOTA ENTITIES SUMS
      -- ****************************************************************************************************

      IF v_has_product_hierarchy = 1 THEN
        SAVE_QUOTAS_MODIFY_ROLLUP(pi_svqru_qd_id             => pi_svqmm_qd_id,
                                  pi_svqru_tupr_id           => pi_svqmm_tupr_id,
                                  pi_svqru_att_or_adjustment => 1,
                                  pout_svqru_updated_rows    => v_updated_rows);
      END IF;

      -- ****************************************************************************************************
      -- VII. CALCULATE QUOTA CONTRIBUTION
      -- ****************************************************************************************************
      IF v_calculate_contrib = 1 THEN
        CALCULATE_QUOTA_CONTRIBUTION(pi_qd_id               => pi_svqmm_qd_id,
                                     pi_tupr_id             => pi_svqmm_tupr_id,
                                     pi_iq_q_mapping        => pi_svqmm_q_mapping,
                                     pi_hierarchy_query     => pi_svqmm_hierarchy_query,
                                     pi_adjusting_records   => 1,
                                     pi_no_of_adj_records   => v_no_of_rec_inserted,
                                     pi_modified_parent_map => pi_svqmm_modified_parent_map,
                                     pi_no_of_updated_rec   => v_updated_cb);

      END IF;

      IF v_has_calc_fields = 1 THEN
           EXECUTE IMMEDIATE pi_quotas_table_query;

           IF pi_qe_table_query1 IS NOT NULL THEN
            EXECUTE IMMEDIATE pi_qe_table_query1;
           END IF;

           IF pi_qe_table_query2 IS NOT NULL THEN
            EXECUTE IMMEDIATE pi_qe_table_query2;
           END IF;

           IF pi_qe_table_query3 IS NOT NULL THEN
            EXECUTE IMMEDIATE pi_qe_table_query3;
           END IF;
      END IF;
      -- ****************************************************************************************************
      -- VII_. UPDATE VERSION
      -- ****************************************************************************************************

      UPDATE quota_versions
        SET qv_version = qv_version + 1
      WHERE qv_qd_id = pi_svqmm_qd_id
        AND qv_tupr_id = pi_svqmm_tupr_id;

    END IF;
  END IF;

  OPEN pout_threshold_validations FOR SELECT * FROM TMP_QUOTAS_EXCEED_THRESHOLD;

  COMMIT;

END SAVE_QUOTAS_MODIFY_MODE;
-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END QUOTAS;
/
