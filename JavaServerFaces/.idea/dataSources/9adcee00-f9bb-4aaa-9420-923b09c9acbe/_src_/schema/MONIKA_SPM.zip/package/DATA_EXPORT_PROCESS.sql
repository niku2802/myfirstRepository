CREATE PACKAGE DATA_EXPORT_PROCESS IS

  PROCEDURE RUN_TXT_DATA_EXPORT(PIN_EXPORT_PROCESS_ID IN NUMBER,
                                PIN_OUTPUT_FILENAME   IN varchar2,
                                PIN_INPUT_SOURCE      IN CLOB,
                                PIN_COLUMN_LIST       IN TABLETYPE_DE_COL_TYPE_LIST,
                                POUT_ROW_COUNTER      out number,
                                POUT_ERROR_CODE       OUT NUMBER);

/*
Parameters:
PIN_EXPORT_PROCESS_ID        number                       not null      - id of the export process
PIN_OUTPUT_FILENAME          varchar2                     not null      - name for the output file, with the extension
PIN_INPUT_SOURCE             clob                         not null      - initial query containing the main exported table along
                                                                          with entity or period tables;
                                                                          it includes the filter condition as well.
PIN_COLUMN_LIST              TABLETYPE_DE_COL_TYPE_LIST   not null      - Column mapping
                                                                          Columns:
                                                                          - column_name  - column name as it is represented in the from clause
                                                                          - column_header - name that should be shown in the header, in included
                                                                          - column_type  - data type of the column : 0-Character field, 1-Boolean field, 2-Date field, 3-Note field, 4-Datetime field, 5- Numeric field,7 - Period Field
                                                                                          (relevant only for numeric fields at the moment)

                                                                 E.G.:  TABLETYPE_DE_COL_TYPE_LIST(OBJTYPE_DE_COL_TYPE_LIST('F1', 'First_column',2),
                                                                                                      OBJTYPE_DE_COL_TYPE_LIST('A2', 'Second_column',6),
                                                                                                      OBJTYPE_DE_COL_TYPE_LIST('F5', 'Third_column',6),
                                                                                                      OBJTYPE_DE_COL_TYPE_LIST('F9', 'Fourth_column',3)
                                                                                                       )
POUT_ROW_COUNTER             number                                       - output parameter containing the number of processed rows
POUT_ERROR_CODE              NUMBER                                       - has value 1 if there is an encoding error (export text is non ascii/ Latin-1)
)
*/


TYPE COLUMN_ARR IS TABLE OF VARCHAR2(255);

END DATA_EXPORT_PROCESS;
/
