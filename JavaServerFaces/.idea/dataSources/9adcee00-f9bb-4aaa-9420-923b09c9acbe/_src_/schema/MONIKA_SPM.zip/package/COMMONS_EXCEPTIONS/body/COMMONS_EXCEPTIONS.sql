CREATE package body commons_exceptions is
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  appframework
  -- Requester    :  Lazar, Lucian
  -- Author    :  Lazar, Lucian
  -- Reviewer    :
  -- Review date    :
  -- Description    :  Used for handling custom errors
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC FUNCTIONS START       *******************************

  function error_text(pi_error_msg in varchar2, pi_string in varchar2)
    return varchar2 is
    l_percents  integer;
    l_commas    integer;
    l_error_msg varchar2(4000 CHAR);
    l_value     varchar2(1000 CHAR);
    l_percent   varchar2(1 CHAR) := '%';
    l_separator varchar2(1 CHAR) := ';';
    l_idx       pls_integer := 1;
  begin
    l_error_msg := pi_error_msg;
    l_percents  := regexp_count(pi_error_msg, l_percent);
    l_commas    := regexp_count(pi_string, l_separator);
    if l_percents = l_commas + 1 then
      if l_commas >= 0 then
        for i in 1 .. l_commas + 1 loop
          l_value     := regexp_substr(pi_string,
                                       '[^' || l_separator || ']+',
                                       1,
                                       l_idx);
          l_error_msg := replace(l_error_msg, '%' || l_idx, l_value);
          l_idx       := l_idx + 1;
        end loop;
      end if;
    else
      l_error_msg := l_error_msg ||
                     ' (internal note: please set the correct error parameters)';
    end if;
    return l_error_msg;
  end error_text;

  -- *******************************    PUBLIC FUNCTIONS END       *******************************

end commons_exceptions;
/
