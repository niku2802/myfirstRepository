CREATE PACKAGE BODY commons AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type  : SPM
-- Product        : commons
-- Module         : commons
-- Requester      : Cozac, Tudor
-- Author         : Cozac, Tudor
-- Reviewer       :
-- Review date    :
-- Description    :
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

	-- ################################ CREATE_PK_TRIGGER START	################################
	PROCEDURE CREATE_PK_TRIGGER (pi_table_name    IN VARCHAR2,
					 pi_column_name   IN VARCHAR2)
	IS
	BEGIN
	   EXECUTE IMMEDIATE   '
		CREATE OR REPLACE TRIGGER '||pi_table_name||'_PK BEFORE INSERT ON '|| pi_table_name||' FOR EACH ROW
		BEGIN
		   SELECT UID_SEQUENCE.NEXTVAL INTO :NEW.'||pi_column_name||' FROM DUAL;
		END;
		';

	EXCEPTION
	   WHEN OTHERS
	   THEN
		  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, 'Error in creating identity trigger over table "'|| pi_table_name||'"', SQLCODE, SQLERRM);
		  raise_application_error(-20001,SQLERRM);

	END CREATE_PK_TRIGGER;
	-- ################################ CREATE_PK_TRIGGER END	################################

	-- ################################ LISTAGG_COLLECT START	################################
	FUNCTION LISTAGG_COLLECT (
		 pin_wordlist	IN TABLETYPE_CHARMAX
		,pin_delimiter	IN VARCHAR2 DEFAULT ','
		,pin_maxcount	IN NUMBER DEFAULT NULL
	) RETURN CLOB IS
		v_list_idx		PLS_INTEGER;
		v_word_idx		PLS_INTEGER;
		v_final_list	CLOB;
	BEGIN
		v_list_idx	:= pin_wordlist.FIRST;
		v_word_idx	:= 0;
    --this needs more comments
		WHILE (	v_list_idx IS NOT NULL
				AND	(pin_maxcount IS NULL OR v_word_idx < pin_maxcount))
		LOOP
			v_final_list := v_final_list || pin_wordlist(v_list_idx) || pin_delimiter;
			v_list_idx := pin_wordlist.NEXT(v_list_idx);
			v_word_idx := v_word_idx + 1;
		END LOOP;

		v_final_list := SUBSTR(v_final_list, 1, LENGTH(v_final_list) - LENGTH(pin_delimiter));
		RETURN v_final_list;
	END LISTAGG_COLLECT;
	-- ################################ LISTAGG_COLLECT END		################################

	   -- ############################# FIELD_PRECISION_AND_SCALE START   #############################
	   FUNCTION FIELD_PRECISION_AND_SCALE(pin_field_name	IN VARCHAR2)
	    RETURN VARCHAR2
	   IS
	    v_prec_scale            VARCHAR2(30);
	    c_integer_part_length   NUMERIC(10);
	   BEGIN
	      SELECT PR_VALUE INTO c_integer_part_length FROM PROPERTIES WHERE PR_NAME='INTEGER_PART_LENGTH';
	      SELECT '('||TO_CHAR(FLD_LENGTH+c_integer_part_length)||','||FLD_LENGTH||')' INTO v_prec_scale FROM FIELDS WHERE FLD_COLUMN_NAME =pin_field_name;
	      RETURN v_prec_scale;
	   END;
	   -- ############################# FIELD_PRECISION_AND_SCALE START   #############################

	   -- ############################# FIELD_SCALE START   #############################
	   FUNCTION FIELD_SCALE(pin_field_name	IN VARCHAR2,pin_precision IN NUMBER)
	    RETURN VARCHAR2
	   IS
	    v_prec_scale            VARCHAR2(30);
	    c_integer_part_length   NUMERIC(10);
	   BEGIN
	      SELECT PR_VALUE INTO c_integer_part_length FROM PROPERTIES WHERE PR_NAME='INTEGER_PART_LENGTH';
	      SELECT '('||TO_CHAR(pin_precision+c_integer_part_length)||','||pin_precision||')' INTO v_prec_scale FROM FIELDS WHERE FLD_COLUMN_NAME =pin_field_name;
	      RETURN v_prec_scale;
	   END;
	   -- ############################# FIELD_SCALE START   #############################

	-- ############################# FIELD_PRECISION_AND_SCALE START   #############################
  function check_record_existence (pi_sql in clob) return integer as
    v_count integer;
  begin
    execute immediate 'select count(*) cnt from (select rownum from (' || pi_sql || ') where rownum = 1)' into v_count;
    return v_count;
  end check_record_existence;
	-- ############################# FIELD_PRECISION_AND_SCALE START   #############################

  -- ############################# FIELD_PRECISION_AND_SCALE START   #############################
	   FUNCTION FIND_ENITY_BUSINESS_KEY(pin_table_name	IN VARCHAR2)
	    RETURN VARCHAR2
	   IS
	    v_business_key            VARCHAR2(30);
	   BEGIN
       --bla
     select tc.tc_physical_name into v_business_key
     from tables t inner join table_columns tc on t.tables_id = tc.tc_tables_id
     where tables_physical_name = pin_table_name and tc_logic_type in (1,5);

     RETURN v_business_key;
	   END;
	   -- ############################# FIELD_PRECISION_AND_SCALE START   #############################

	FUNCTION FIND_ENT_BUSINESS_KEY_BY_NAME(pin_entity_name	IN VARCHAR2)
	  RETURN VARCHAR2
	  IS
	    v_business_key            VARCHAR2(30);
      v_table_name              VARCHAR2(30);
	   BEGIN

     select t.tables_physical_name into v_table_name
     from tables t inner join entities e on t.tables_id = e.entity_tables_id where e.entity_id = substr(pin_entity_name, 2);
     v_business_key := commons.FIND_ENITY_BUSINESS_KEY(v_table_name);

     RETURN v_business_key;
	 END;

      FUNCTION FIND_ENT_TABLE_NAME(pin_entity_name	IN VARCHAR2)
	    RETURN VARCHAR2
	   IS
	    v_table_name            VARCHAR2(30);
	   BEGIN
     select 'T'||e.entity_tables_id into v_table_name
     from entities e where entity_id = substr(pin_entity_name, 2);

     RETURN v_table_name;
	   END;

	-- ############################# get_process_details start   #############################
	function get_process_details(pi_run_id in number) return varchar2 is
    v_process_name run_data.rd_name%type;
    v_process_type utl_process_type.process_type_name%type;
    v_process_log run_data.rd_log_id%type;
    v_parent_name run_data.rd_name%type;
    v_parent_type utl_process_type.process_type_name%type;
    v_missing_process number(1) := 0;
    v_process_details varchar2(32767);
  begin

    -- get process details
    begin
      select rd_name, process_type_name, rd_log_id
        into v_process_name, v_process_type, v_process_log
        from run_data
        join utl_process_type on rd_type = process_type_id
       where rd_id = pi_run_id;
      select rd_name, process_type_name
        into v_parent_name, v_parent_type
        from run_data
        join utl_process_type on rd_type = process_type_id
       where rd_id = (select rd_parent_id
                        from run_data
                       where rd_id = pi_run_id);
    exception
      when no_data_found then v_missing_process := 1;
      when others then raise;
    end;

    -- build process details string
    if v_missing_process = 0 then
      v_process_details := 'The current run of the component "' || v_process_name || '" of type ' || v_process_type ||
                           ' with parent "' || v_parent_name || '" of type ' || v_parent_type ||
                           ' presents a risk of occupying a large part of the project temp space. ' ||
                           'Please investigate the run and decide to abort it if it takes too long. ' ||
                           'The run id is ' || pi_run_id || ' and the process log id is ' || v_process_log || ' on schema ' || user || '.' ;
    end if;
    return v_process_details;

  end get_process_details;
	-- ############################# get_process_details end   #############################

	-- ############################# terminate_insane_query start   #############################
  procedure terminate_insane_query(pi_sql in clob, pi_run_id in number) as
    pragma autonomous_transaction;
    v_stop_threshold number;
    v_warning_threshold number;
    v_temp_threshold_percent number;
    v_project_temp_space number;
    v_temp_space number;
    v_temp_threshold number;
    v_cardinality number;
    v_alert varchar2(32767);
  begin

    -- get the tresholds from properties
    select to_number(PR_VALUE) into v_stop_threshold from PROPERTIES where PR_NAME = 'QUERY_CARDINALITY_THRESHOLD_VALUE';
    select to_number(PR_VALUE) into v_warning_threshold from PROPERTIES where PR_NAME = 'WARNING_CARDINALITY_THRESHOLD_VALUE';
    select to_number(PR_VALUE) into v_temp_threshold_percent from PROPERTIES where PR_NAME = 'TEMP_SPACE_FOR_PROCESSING_ALERT';

    -- get the project temp space and set the temp threshold
    v_project_temp_space := optymyze_admin.dba_utils.getMaxProjectTempSpace(upper(user) || '_TMP');
    v_temp_threshold := v_project_temp_space * v_temp_threshold_percent;

    -- get the estimated cardinality
    dba_analysis.getEstimatedCardinalityTemp(pi_sql,v_cardinality,v_temp_space);

    -- handle cardinality estimation
    -- if the estimated cardinality is higher then the warning limit log the query
    if v_cardinality >= v_warning_threshold then
      insert into INSANE_QUERIES(IQ_ID,IQ_QUERY,IQ_RUN_ID,IQ_CARDINALITY) values(INSANE_QUERIES_SEQ.NEXTVAL,pi_sql,pi_run_id,v_cardinality);
      commit;
    end if;
    -- if the estimated cardinality is higher then the stop limit raise exception
    if v_cardinality >= v_stop_threshold then
      raise_application_error(commons_exceptions.e_TerminateQuery_code,commons_exceptions.e_TerminateQuery_msg);
    end if;

    -- handle temp space estimation
    if v_temp_space >= v_temp_threshold then
      v_alert := get_process_details(pi_run_id);
      commons_utils.send_db_alert('Process about to consume the temp space of the project',v_alert);
    end if;

	commit;
  end terminate_insane_query;
	-- ############################# terminate_insane_query end   #############################

	   -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END commons;
/
