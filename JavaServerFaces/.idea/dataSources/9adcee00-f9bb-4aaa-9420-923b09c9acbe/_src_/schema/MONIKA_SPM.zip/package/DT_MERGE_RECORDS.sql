CREATE PACKAGE DT_MERGE_RECORDS AS

/* GET_TABLE_COLUMNS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_COLUMNS
(   pin_table_id IN NUMBER
) RETURN TABLETYPE_DT_MR_COL_PROPS;


/* GET_TABLE_NAME
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_NAME
(   pin_table_id IN NUMBER
) RETURN VARCHAR2;


/* GET_TABLE_SEQUENCE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_SEQUENCE
(   pin_table_id IN NUMBER
) RETURN VARCHAR2;


/* GET_TABLE_ID_BY_REF
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_ID_BY_REF
(   pin_table_ref_id IN NUMBER
) RETURN NUMBER;


/* GET_OPERATION_INPUTS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_OPERATION_INPUTS
(    pin_definition_id          IN NUMBER
    ,pin_processing_date        IN DATE
    ,pin_processing_period      IN NUMBER
    ,pin_run_type               IN NUMBER
) RETURN TABLETYPE_DT_MR_OP_INPUTS;


/* GET_COLUMN_MAPPINGS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_COLUMN_MAPPINGS
(    pin_output_cols    IN TABLETYPE_DT_MR_COL_PROPS
    ,pin_op_inputs      IN TABLETYPE_DT_MR_OP_INPUTS
) RETURN TABLETYPE_DT_MR_COL_MAP_LIST;


/* GET_EQUAL_MATCH_CONDITION
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_EQUAL_MATCH_CONDITION
(    pin_left_member        IN CLOB
    ,pin_right_member       IN CLOB
    ,pin_members_col_type   IN NUMBER
    ,pin_members_data_type  IN NUMBER
) RETURN CLOB;


/* GET_TUPR_BY_DATE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TUPR_BY_DATE
(    pin_timeunit_id    IN NUMBER
    ,pin_date           IN DATE
) RETURN NUMBER;


/* GET_TUPR_BY_CORR_TUPR
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TUPR_BY_CORR_TUPR
(    pin_timeunit_id    IN NUMBER
    ,pin_tupr_id        IN NUMBER
) RETURN NUMBER;


/* GET_ENTITY_BK_VALUE
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ENTITY_BK_VALUE
(    pin_ent_tab_name   IN VARCHAR2
    ,pin_ent_bk_col     IN VARCHAR2
    ,pin_ent_id         IN NUMBER
) RETURN VARCHAR2;


/* GET_TUPR_NAME
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TUPR_NAME
(    pin_tupr_id IN NUMBER
) RETURN VARCHAR2;


/* RUN_MERGE_RECORDS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pin_definition_id          IN NUMBER
        -   NOT NULL
        -   the id of the operation definition in DT_OPERATIONS

    ,pin_processing_date        IN DATE
        -   NULL
        -   date of processing when the timeunit used is Day

    ,pin_processing_period      IN NUMBER
        -   NULL
        -   TUPR_ID of processing when the timeunit used is different than Day

    ,pin_run_type               IN NUMBER
        -   NOT NULL
        -   property that shows whether the operation is execute within a JOB or not.
        -   0 - not executed through a job, 1 - executed through a job

    ,pin_result_table_id        IN NUMBER
        -   NOT NULL
        - the id from the corresponding DT_RESULT_TABLES.DTRT_TABLES_ID entry

    ,pin_filters                IN TABLETYPE_DT_MR_FILTER_LIST
        -   NULL
        -   filters defined on the inputs and outputs of the operation
        -   members:
            *   FILTER_ID - NUMBER - NOT NULL : ID of the filter
            *   WHERE_CLAUSE - CLOB - NOT NULL : WHERE clause to use for filtering the input
                        - input filters:    = Table alias for field columns - "DTIN" plus the id of the input ex: "DTIN123"
                                            = Table alias for business keys/entity attributes from entity columns - the name of the column from input ex: "E2303"
                                            = Table alias for period attributes (TUPR_START_DATE, TUPR.PERIOD_NUMBER) from period columns - the name of the column from input ex: "F45"
                                            = Table alias for reference columns - the name of the column from input ex: "PLAN_NAME" - the entire column name will be "PLAN_NAME.OR_NAME" instead of "T_.PLAN_NAME"
                        - output filters:   = Table alias for field columns - "DTOUT" plus the id of the output ex: "DTOUT4321"
                                            = Table alias for reference columns - the same as for fields.
                                            = Table alias for business keys/entity attributes from entity columns - the name of the column from output ex: "E2303"
                                            = Table alias for period attributes (TUPR_START_DATE, TUPR.PERIOD_NUMBER) from period columns - the name of the column from output ex: "F45"
            *   FROM_CLAUSE - CLOB - NULL : if filter conditions are specified on period fields, then joins with the TU_PERIODS_RANGE tables are needed
                                             which will be referenced in the WHERE_CLAUSE through aliases. The FROM_CLAUSE will be counstructed as:
                        - input filters:    = <if input column is NULLABLE - LEFT, else - INNER> JOIN TU_PERIODS_RANGE AS OF SCN :SCN <input column name> ON DTIN<id_of_input>.<input column name> = <input column name>.TUPR_ID
                                        ex: = INNER JOIN TU_PERIODS_RANGE AS OF SCN :SCN F45 ON DTIN123.F45 = F45.TUPR_ID
                        - output filters:   = LEFT JOIN TU_PERIODS_RANGE AS OF SCN :SCN <output column name> ON DTOUT<id_of_output>.<output column name> = <output column name>.TUPR_ID
                                        ex: = LEFT JOIN TU_PERIODS_RANGE AS OF SCN :SCN F546 ON DTOUT321.F546 = F546.TUPR_ID
            *   FILTER_ENTITIES - TABLETYPE_DT_NUMBER - NULL: if filter conditions are specified on entities, then joins with the entity tables are needed
                                                             which will be referenced in the WHERE_CLAUSE through aliases. The FILTER_ENTITIES member contains
                                                             for each filter a collection of ENTITY_IDs.
        -   ex: TABLETYPE_DT_MR_FILTER_LIST
                    (OBJTYPE_DT_MR_FILTER_LIST
                        (111383
                        ,'E2303.F6521 = ''employee001'' AND E2328.F4241 = ''territory002'' AND F40.TUPR_START_DATE = A_DATE_CONSTANT'
                        ,'INNER JOIN TU_PERIODS_RANGE AS OF SCN :SCN F40 ON DTIN123.F40 = F40.TUPR_ID'
                        ,TABLETYPE_DT_NUMBER(2303, 2328))
                    ,OBJTYPE_DT_MR_FILTER_LIST
                        (111385
                        ,'DTIN123.F26319 > 100'
                        ,NULL
                        ,NULL)
                    ,OBJTYPE_DT_MR_FILTER_LIST
                        (111387
                        ,'DTOUT4321.F26319 NOT IN (100)'
                        ,NULL
                        ,NULL)
                    );

    ,pin_column_mappings        IN TABLETYPE_DT_MR_COL_MAP_LIST
        -   NULL
        -   column mappings as specified when option used is "take selected fields from inputs"
            when option used is "take all fields from all inputs", then this will be NULL
        -   members:
            *   COLUMN_NAME - VARCHAR2 - NOT NULL : name of the column from the result table (E200, F300)
            *   INPUT_ID - NUMBER - NOT NULL : corresponding DTIN_ID of the input being mapped
            *   MAPPING_OPTION - NUMBER - NOT NULL : these will be the options chosen in UI based on the type of the result field
                        1   - empty (for entity, char, date, num, period)
                        2   - constant (for all - entity, bool, char, date, num, period)
                        3   - field from input (for all - entity, bool, char, date, num, period)
                        4   - entity from input (for entity, char, num)
                        5   - based on processing period (for date, period)
            *   MAPPING_VALUE - CLOB - NULL : value mapped depending on the type of the result field and the option used:
                        1   - value will be always NULL
                        2   - bool:     "0"/"1" (for YES/NO)
                            - entity:   "23" (id of the entity)
                            - char:     "asd"
                            - date:     "31/12/2012" (the following format will be used - DD/MM/YYYY)
                            - datetime: "31/12/2012 13:30:34" (the following format will be used - DD/MM/YYYY HH24:MI:SS)
                            - num:      "123.65"
                            - period:   "321" (id of the period range)
                        3   - name of the field: "F300"
                        4   - name of the entity column: "E200"
                        5   - value will be always NULL
        -   ex: for one input:
            TABLETYPE_DT_MR_COL_MAP_LIST
                    (OBJTYPE_DT_MR_COL_MAP_LIST('E100'      ,223    ,1  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('E200'      ,223    ,2  ,'321')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('E300'      ,223    ,3  ,'E100')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('E400'      ,223    ,4  ,'F300')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F11_BOOL'  ,223    ,2  ,'0')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F12_BOOL'  ,223    ,3  ,'F99')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F21_CHAR'  ,223    ,1  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F22_CHAR'  ,223    ,2  ,'asd')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F23_CHAR'  ,223    ,3  ,'F300')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F31_DATE'  ,223    ,1  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F32_DATE'  ,223    ,2  ,'01/01/2010')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F33_DATE'  ,223    ,5  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F34_DATE'  ,223    ,3  ,'F555')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F41_NUM'   ,223    ,1  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F42_NUM'   ,223    ,2  ,'303.09')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F43_NUM'   ,223    ,3  ,'F90')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F51_PER'   ,223    ,1  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F52_PER'   ,223    ,2  ,'324')
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F53_PER'   ,223    ,5  ,NULL)
                    ,OBJTYPE_DT_MR_COL_MAP_LIST('F54_PER'   ,223    ,3  ,'F123'));

    ,pin_flashback_scn          IN NUMBER
        -   NULL
        -   this represents a SCN valid for all tables which will be part of the processing and need read consistency:
            *   all entity tables part of validations, filtering, matching conditions
            *   TU_PERIODS_RANGE
            *   all inputs which are not operation outputs

    ,pout_vld_results           OUT SYS_REFCURSOR
        -   NULL
        -   a cursor returning all values that have not passed the validations
        -   result set: VLD_DTIN_ID     NUMBER: id of the input
                        VLD_FIELD_ID    NUMBER: field from the input which contains the invalid value
                        VLD_ENTITY_ID   NUMBER: entity that is being mapped
                        TRG_VALUES      TABLETYPE_DT_CLOB : it is a collection/array of all values which have triggered this validation
                                                            TABLETYPE_DT_CLOB("<business_id1>",...,"<business_id2>")
-----------------------------------------------------------------------------------------------
*/
PROCEDURE RUN_MERGE_RECORDS
(    pin_definition_id          IN NUMBER
    ,pin_processing_date        IN DATE
    ,pin_processing_period      IN NUMBER
    ,pin_run_type               IN NUMBER
    ,pin_result_table_id        IN NUMBER
    ,pin_filters                IN TABLETYPE_DT_MR_FILTER_LIST
    ,pin_column_mappings        IN TABLETYPE_DT_MR_COL_MAP_LIST
    ,pin_flashback_scn          IN NUMBER
    ,pout_insert_rowcount       OUT NUMBER
    ,pout_vld_results           OUT SYS_REFCURSOR
);

END DT_MERGE_RECORDS;
/
