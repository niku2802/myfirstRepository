CREATE PACKAGE performance_analyzer IS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Module         : performance_analyser
  -- Requester      : Mohasin Shaikh
  -- Author         : Shriniket Pimparkar
  -- Reviewer       : Pooja Sharma
  -- Review date    : 09 Mar 2016
  -- Description    : package to perform performance analyzer checks
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

    PROCEDURE perf_analyser_checks(pi_def_type_id IN NUMBER,
                                 pi_def_id      IN NUMBER,
                                 pi_run_id      IN NUMBER,
                                 pi_process_id  IN tabletype_number DEFAULT NULL,
                                 po_flag        OUT NUMBER) ;

FUNCTION  get_mf_fields_in_adv_exp(pi_operation_id in number) RETURN TABLETYPE_ID_ID PIPELINED;

/*-- ========================================================
  -- Author         : Shriniket Pimparkar
  -- Create date    : 06 Mar 2016
  -- Description    : proc to perform performance analyzer checks
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
   pi_def_type_id      IN  NUMBER    Definition type of the definition for which performance check is to be done
   pi_def_id           IN  NUMBER    Definition ID
   pi_run_id           IN  NUMBER    Run ID
   po_flag             OUT NUMBER    Flag to be sent out. 0: No checks passed for this definition, 1 : 1 or more checks failed for this definition
-----------------------------
  Example:
  declare
   v_flag number;
  begin
   performance_analyzer.Perf_Analyser_Checks(pi_def_type_id => 21313,
                                             pi_def_id      => 10,
                                             pi_run_id      => 4,
                                             po_flag        => v_flag);
   dbms_output.put_line(v_flag);
  end;*/
-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END       *******************************

END performance_analyzer;
/
