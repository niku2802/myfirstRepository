CREATE PACKAGE BODY DATA_TRANSFORMATION_PROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
    -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
    -- is not to be divulged or used by parties who have not received written
    -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- PRODUCT      : DataManagement
  -- MODULE     : DataTransformation
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
    -- ############################# SEL_INPUT_FIELDS START #############################
    FUNCTION SEL_INPUT_FIELDS
    (
      pin_input_table_list  IN COLTYPE_ID
     ,pin_operation_id  IN NUMBER
      )   RETURN SYS_REFCURSOR IS

    -- records with dat from input parameters
    v_input_table_list      COLTYPE_ID;
    -- sql sections
    v_select_clause       CLOB;

    -- resultset
    c_resultset         SYS_REFCURSOR;

    BEGIN
    /* Step1 validate input parameters

    IF        pin_input_table_list IS NOT NULL AND  pin_operation_id IS NOT NULL THEN raise_application_error(-20001, 'Only one parameter can be not null.');
    ELSIF     pin_input_table_list IS     NULL AND  pin_operation_id IS     NULL THEN raise_application_error(-20001, 'At least one parameter has to be not null.');
    END IF;


    v_select_clause :=;
    v_from_clause:=v_from_roster||v_from_inputs;

    v_where_clause:=;

    v_query:=v_select_clause||v_from_clause||v_where_clause;
    */
    /* Output resultset
    */
    --DBMS_OUTPUT.put_line(v_query);

     -- OPEN c_resultset FOR v_query;
    RETURN c_resultset;


    END SEL_INPUT_FIELDS;
    -- ############################# SEL_INPUT_FIELDS STOP #############################

    -- ############################# INPUT_FIELDS START #############################
    FUNCTION INPUT_FIELDS
    (
      pin_operation_id      IN NUMBER
     ,pin_output_type_id    IN NUMBER
     ,pin_input_list      IN CLOB
      )   RETURN SYS_REFCURSOR IS

    -- resultset
    c_resultset         SYS_REFCURSOR;
    v_query           CLOB;
    v_single_input        CLOB;
    v_input_list        CLOB;
    v_operation_id        NUMBER(10);
    v_post_result         NUMBER(1);
    v_stamp             VARCHAR2(200);
    v_is_inp_reg_result number(1):=0;
    BEGIN

       select count(*)
       into v_is_inp_reg_result -- flag to check whether input is result of regression operation OF-67002
  from dt_inputs dtin
 inner join dt_outputs dtout
    on dtin.dtin_dtout_id = dtout.dtout_id
 inner join dt_regression dtr
    on dtout.dtout_dto_id = dtr.dtr_dto_id
 where dtin_dto_id = pin_operation_id;



        v_stamp := 'DATA_TRANSFORMATION_PROCESSING.INPUT_FIELDS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
      /*commons_utils.insert_logs('pin_operation_id : '||pin_operation_id || ' pin_output_type_id : '||pin_output_type_id);*/

    IF pin_output_type_id IS NOT NULL THEN
      select count(*) into v_is_inp_reg_result from dt_regression where dtr_dto_id = pin_operation_id;-- flag to check whether input is result of regression operation OF-67002
      v_single_input:=' UNION ALL
                              SELECT null OP_RES_TYPE_DYN_NO_OUT,1 INPUT_ORDER,0 OPERATION_ID,DTO_IN.DTO_ID OPERATION_ID_IN
                                    ,DTOUT_IN.DTOUT_ID OP_RESULT_ID_IN,0 OP_RESULT_ID_OUT,null TREF_ID_IN
                                    ,CASE WHEN DTOUTT_IN.DTOUTT_ORDER !=1 THEN 1
                                            ELSE
                                           DTO_IN.DTO_RESULT_FIELDS_TYPE END DTO_RESULT_FIELDS_TYPE_IN
                                    ,1 DTO_RESULT_FIELDS_TYPE_OUT
                                    ,NULL DTIN_ID,1 DTOUTT_PRIMARY,'||case when v_is_inp_reg_result > 0 then ' DTOUT_IN.DTOUT_DTOUTT_ID DTOUTT_IN_PRIMARY ' else ' null 'end ||-- case when added for OF-67002
                                    ',DTO_IN.DTO_DTOPT_ID                                              OPERATION_TYPE_IN
                                FROM DT_OPERATIONS DTO_IN
                          INNER JOIN DT_OUTPUTS DTOUT_IN ON DTOUT_IN.DTOUT_DTO_ID = DTO_IN.DTO_ID
                           LEFT JOIN DT_OUTPUT_TYPES DTOUTT_IN ON DTOUTT_IN.DTOUTT_DTOPT_ID=DTO_IN.DTO_DTOPT_ID AND DTOUTT_IN.DTOUTT_ID=DTOUT_IN.DTOUT_DTOUTT_ID
                 WHERE DTO_IN.DTO_ID='||pin_operation_id||'
                   AND DTOUT_IN.DTOUT_DTOUTT_ID='||pin_output_type_id;
      v_operation_id:=0;

    ELSE
      v_operation_id:=pin_operation_id;
    END IF;

    IF pin_input_list IS NOT NULL THEN
      v_input_list:=' AND INPUT_ID IN ('||pin_input_list||')';
    END IF;

    -- check if the operation has as input the additional result of a post
    select count(*)
      into v_post_result
      from DT_INPUTS
      join DT_OUTPUTS on DTIN_DTOUT_ID = DTOUT_ID
     where DTIN_DTO_ID = pin_operation_id
       and DTOUT_DTOUTT_ID between 13 and 16;

    v_query := '
    SELECT  MIN(RESULTS_FIELDS_DETERMINED)    RESULTS_FIELDS_DETERMINED
         ,INPUT_ID
         ,FLD_ID
         ,ENTITY_ID
         --,MIN(FIELD_ORDER)          FIELD_ORDER
      FROM (
        SELECT CASE WHEN DTO_RESULT_FIELDS_TYPE_IN IS NULL THEN 0 ELSE 1 END    RESULTS_FIELDS_DETERMINED
          ,INPUT_ID                             INPUT_ID
          ,NVL(TC_FLD_ID,DTORF_FLD_ID)                    FLD_ID
          ,NVL(TC_ENTITY_ID,DTORF_ENTITY_ID)                  ENTITY_ID
          ,ROW_NUMBER() OVER (ORDER BY TABLE_ORDER,NVL(TC_ORDER,DTORF_ORDER)) FIELD_ORDER
        FROM (
                    SELECT DTO_RESULT_FIELDS_TYPE_IN,TREF_ID_IN,OP_RESULT_ID_IN,OP_RESULT_ID_OUT,OPERATION_ID,INPUT_ORDER,rownum table_order,INPUT_ID,OPERATION_ID_IN,DTO_RESULT_FIELDS_TYPE_OUT,OPERATION_TYPE_IN,DTOUTT_PRIMARY,DTOUTT_IN_PRIMARY
                      FROM (SELECT DTO_RESULT_FIELDS_TYPE_IN,OP_RESULT_ID_IN,OP_RESULT_ID_OUT,OPERATION_ID,INPUT_ORDER,OP_RES_TYPE_DYN_NO_OUT,TREF_ID_IN,DTO_RESULT_FIELDS_TYPE_OUT,OPERATION_TYPE_IN
                  ,CONNECT_BY_ROOT DTIN_ID INPUT_ID,LEVEL LEV,OPERATION_ID_IN,DTOUTT_PRIMARY,DTOUTT_IN_PRIMARY
                         FROM (    SELECT CASE WHEN DTO.DTO_DTOPT_ID = 30 AND DTOUTT.DTOUTT_PRIMARY =0
                                            THEN 0 END                                             OP_RES_TYPE_DYN_NO_OUT
                                       ,DTIN.DTIN_ORDER                                                  INPUT_ORDER
                                       ,DTO.DTO_ID                                                       OPERATION_ID
                                       ,DTO_IN.DTO_ID                                                    OPERATION_ID_IN
                                       ,DTIN.DTIN_DTOUT_ID                         OP_RESULT_ID_IN
                                       ,DTOUT.DTOUT_ID                                                   OP_RESULT_ID_OUT
                                       ,DTIN.DTIN_TREF_ID                                                TREF_ID_IN
                                       ,CASE WHEN DTIN.DTIN_TREF_ID IS NOT NULL THEN 1
                                                                                 WHEN DTOUTT_IN.DTOUTT_ORDER !=1 AND DTO_IN.DTO_DTOPT_ID!=90 THEN 1
                                                                                    ELSE
                                                                                    DTO_IN.DTO_RESULT_FIELDS_TYPE END                        DTO_RESULT_FIELDS_TYPE_IN
                                       ,CASE WHEN DTOUTT.DTOUTT_ORDER !=1
                                         THEN 1 ELSE
                                                                                    DTO.DTO_RESULT_FIELDS_TYPE   END                         DTO_RESULT_FIELDS_TYPE_OUT
                                       ,DTIN.DTIN_ID                           DTIN_ID
                                       ,case when DTOUTT.DTOUTT_ID between 13 and 16 then 2 else DTOUTT.DTOUTT_PRIMARY end                   DTOUTT_PRIMARY
                                       ,case when DTOUTT_IN.DTOUTT_ID between 13 and 16 then 2 else DTOUTT_IN.DTOUTT_ID end                  DTOUTT_IN_PRIMARY
                                       ,DTO_IN.DTO_DTOPT_ID                                              OPERATION_TYPE_IN
                                   FROM DT_OPERATIONS DTO
                               LEFT JOIN DT_OUTPUTS DTOUT ON DTOUT.DTOUT_DTO_ID = DTO.DTO_ID
                               LEFT JOIN DT_OUTPUT_TYPES DTOUTT ON DTOUTT.DTOUTT_DTOPT_ID=DTO.DTO_DTOPT_ID AND DTOUTT.DTOUTT_ID=DTOUT.DTOUT_DTOUTT_ID
                               LEFT JOIN (    SELECT DTIN_ID
                                        ,DTIN_DTO_ID
                                        ,DTIN_TREF_ID
                                        ,DTIN_PERIOD_TYPE
                                        ,DTIN_ABSOLUTE_PERIOD
                                        ,DTIN_ORDER
                                        ,DTIN_FILTER_ENABLED
                                        ,DTIN_FILTER_ID
                                        ,DTIN_CD_ID
                                        ,DTIN_DTOUT_ID
                                      FROM DT_INPUTS
                                    INNER JOIN DT_OPERATIONS ON DTIN_DTO_ID = DTO_ID AND DTO_DTOPT_ID!=90
                                  UNION ALL
                                      SELECT DTDR_ID      DTIN_ID
                                        ,DTDR_ID      DTIN_DTO_ID
                                        ,DTDR_TABLE_TREF_ID DTIN_TREF_ID
                                        ,NULL       DTIN_PERIOD_TYPE
                                        ,NULL       DTIN_ABSOLUTE_PERIOD
                                        ,0          DTIN_ORDER
                                        ,NULL       DTIN_FILTER_ENABLED
                                        ,NULL       DTIN_FILTER_ID
                                        ,NULL       DTIN_CD_ID
                                        ,NULL       DTIN_DTOUT_ID
                                      FROM DT_DELETE_RECORDS  -- for delete records the input is considered as an exception the tabel we delete from
                                      ) DTIN ON     DTIN.DTIN_DTO_ID = DTO.DTO_ID
                               LEFT JOIN DT_OUTPUTS DTOUT_IN ON DTIN.DTIN_DTOUT_ID=DTOUT_IN.DTOUT_ID
                               LEFT JOIN DT_OPERATIONS DTO_IN ON DTO_IN.DTO_ID=DTOUT_IN.DTOUT_DTO_ID
                               LEFT JOIN DT_OUTPUT_TYPES DTOUTT_IN ON DTOUTT_IN.DTOUTT_DTOPT_ID=DTO_IN.DTO_DTOPT_ID AND DTOUTT_IN.DTOUTT_ID=DTOUT_IN.DTOUT_DTOUTT_ID
                                  '||v_single_input||'
                                              ) OP_INP ' || case when v_post_result > 0 then ' where OPERATION_ID = :v_input_table ' else '' end || '
                START WITH OPERATION_ID = :v_input_table  AND NVL(DTOUTT_PRIMARY,1) in (1,2)
                CONNECT BY PRIOR OP_RESULT_ID_IN = OP_RESULT_ID_OUT AND COALESCE(OP_RES_TYPE_DYN_NO_OUT,INPUT_ORDER,0)=NVL(INPUT_ORDER,0) AND DTO_RESULT_FIELDS_TYPE_OUT !=2 '||case when v_is_inp_reg_result = 1 then 'and tref_id_in is null ' else '' end||-- case when added for OF-67002
               ' ORDER SIBLINGS BY INPUT_ORDER)
            ) INP
    LEFT JOIN TABLE_REFERENCES TR ON TR.TREF_ID = INP.TREF_ID_IN AND (DTOUTT_IN_PRIMARY in (0,1) or DTOUTT_IN_PRIMARY is null)
    LEFT JOIN (SELECT OBR.OR_ID,OBR.OR_NAME,CR.CR_PARENT_DEFINITION_ID
                   FROM OBJECT_REGISTRATION OBR
             INNER JOIN CATEGORY_RELATIONSHIPS CR ON CR.CR_DEFINITION_ID = OBR.OR_ID
                 ) OBRC ON  OBRC.OR_NAME = TR.TREF_DEFINITION_NAME
                        AND OBRC.CR_PARENT_DEFINITION_ID = TR.TREF_PARENT_DEFINITION_ID
    left join DT_RESULT_TABLES DTRT on INP.OP_RESULT_ID_IN = DTRT.DTRT_DTOUT_ID
    LEFT JOIN TABLES T ON (NVL(T.TABLES_DEFINITION_ID,T.TABLES_ID) = NVL(TR.TREF_DEFINITION_ID,OBRC.OR_ID))  OR (T.TABLES_ID = dtrt.dtrt_tables_id and (DTOUTT_IN_PRIMARY = 2 or DTOUTT_IN_PRIMARY is null))
    LEFT JOIN TABLE_COLUMNS TC ON TC.TC_TABLES_ID = T.TABLES_ID AND TC_COLUMN_TYPE !=3
      LEFT JOIN DT_OP_RESULT_FIELDS DTORF ON DTORF.DTORF_DTO_ID = INP.OPERATION_ID_IN AND '||case when v_is_inp_reg_result = 1 then 'dtorf.dtorf_dtoutt_id = inp.DTOUTT_IN_PRIMARY and ' else '' end|| -- case when added for OF-67002
      ' (INP.DTO_RESULT_FIELDS_TYPE_IN=2 OR INP.OPERATION_TYPE_IN IN (10,20,70,60,100,110,120))-- AGG,CF,CRT,RR
      LEFT JOIN FIELDS ON NVL(TC_FLD_ID,DTORF_FLD_ID) = FLD_ID -- OF-34669 Hide Attachment type fields in Data Transformation, OF-37062 Hide picture fields in the data transformation inputs
      WHERE (FLD_DATA_TYPE is null or FLD_DATA_TYPE not in (9,10)) AND (COALESCE(TC_FLD_ID,DTORF_FLD_ID,TC_ENTITY_ID,DTORF_ENTITY_ID) IS NOT NULL
          OR DTO_RESULT_FIELDS_TYPE_IN IS NULL)
      '||v_input_list||'
        ) A
     where fld_id is null or entity_id is null
     GROUP BY INPUT_ID,FLD_ID,ENTITY_ID
     ORDER BY MIN(FIELD_ORDER)
         ';
    /*commons_utils.insert_logs('v_query : '||v_query);*/
    IF v_post_result > 0 then
      OPEN c_resultset FOR v_query using v_operation_id, v_operation_id;
    else
      OPEN c_resultset FOR v_query using v_operation_id;
    end if;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query || ' - v_operation_id(var) ' || v_operation_id) ,'v_query := <value>', v_stamp);

    RETURN c_resultset;
    /*exception when others then
      commons_utils.insert_logs('Exception : '||sqlerrm);*/
    END INPUT_FIELDS;
    -- ############################# INPUT_FIELDS STOP #############################

  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  procedure get_inputs_cardinality(pi_inputs             in tabletype_dt_op_inputs,
                                   po_inputs_cardinality out tabletype_dt_op_inputs_card) as
    v_output_list clob;
    v_sql clob;
  begin
    -- move the input collection in a GTT
    insert into DT_OP_INPUTS(INPUT_ID,OUTPUT_ID,TABLE_NAME,ALIAS_NAME)
    select INPUT_ID,OUTPUT_ID,TABLE_NAME,ALIAS_NAME from
      table(pi_inputs);
    -- build the outputs list
    select listagg(OUTPUT_ID, ',') within group (order by OUTPUT_ID) into v_output_list from DT_OP_INPUTS;
    -- build the query returning the cardinality
    if v_output_list is not null then
      v_sql := 'select INPUT_ID, OUTPUT_ID, RDP_CARDINALITY, ''CARDINALITY('' || decode(ALIAS_NAME,null,TABLE_NAME,ALIAS_NAME) || '' '' || RDP_CARDINALITY || '')'' RDP_HINT
                  from DT_OP_INPUTS
                  join (select *
                          from (select RDP_ID, RDP_OUTPUT_ID, RDP_CARDINALITY, rank() over(partition by RDP_OUTPUT_ID order by RDP_ID desc) rnk
                                  from RUN_DATA_PROFILE
                                 where RDP_OUTPUT_ID in (' || v_output_list || '))
                         where rnk = 1)
                    on OUTPUT_ID = RDP_OUTPUT_ID';
      -- return the results
      execute immediate 'select objtype_dt_op_inputs_card(INPUT_ID, OUTPUT_ID, RDP_CARDINALITY, RDP_HINT) from (' || v_sql || ')'
         bulk collect into po_inputs_cardinality;
    end if;
  end get_inputs_cardinality;

  procedure get_input_cardinality_hint(pi_input_id   in number,
                                       pi_output_id  in number,
                                       pi_table_name in varchar2,
                                       pi_alias_name in varchar2,
                                       po_hint       out varchar2) as
    v_input tabletype_dt_op_inputs;
    v_output tabletype_dt_op_inputs_card;
    v_hint varchar2(100);
  begin
    v_input := tabletype_dt_op_inputs(objtype_dt_op_inputs(pi_input_id,pi_output_id,pi_table_name,pi_alias_name));
    get_inputs_cardinality(v_input,v_output);
    select max(cardinal_hint) into v_hint from table(v_output);
    po_hint := v_hint;
  end get_input_cardinality_hint;

  -- *******************************    PUBLIC PROCEDURES END         *******************************

END DATA_TRANSFORMATION_PROCESSING;
/
