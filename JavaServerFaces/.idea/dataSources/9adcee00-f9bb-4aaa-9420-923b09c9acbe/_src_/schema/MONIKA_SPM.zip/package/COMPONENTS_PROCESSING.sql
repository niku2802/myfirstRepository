CREATE PACKAGE COMPONENTS_PROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : COMPENSATION
  -- Module   : COMPENSATION-PROCESSING
  -- Description    :
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
-- ############################# RUN_COMPONENT START #############################
	/*
	Author     : Cozac, Tudor
	Create date: 20110603
	Description:
	---------------------------------------------------------------------------------------
	Input Parameters:
		pin_definition_id   IN NUMBER : NOT NULL - the id of the component being executed
    pin_lookup_table	IN tabletype_lookup_table_list NULL: lookup definition
					 * lookup_column	     -	The column from input to use for lookup (metric_value from the input)
					 * table_name          -  The name of the lookup table
					 * lower_value_option  -  The option when entity lookup value is less than the smallest lookup value
								 Possble values:
                  1-the result value from the smallest lookup value,
									2-based on the slope between the two smallest lookup values,
									5-zero,
                  6-an error
					 * higher_value_option -  The option when entity lookup value is greater than the largest lookup value
								 Possble values:
                  3-the result value from the largest lookup value,
									4-based on the slope between the two largest lookup values,
									5-zero,
                  6-an error
					 * used_for	-
                   1 earning calculation                : for pin_component_type=1 ,pin_component_subtype=1,2,3,4
								  ,2 rate calculation                   : for pin_component_type=2 ,pin_component_subtype=101,102,103,104
                  ,3 Tiered rate calculation            : for pin_component_type=4 ,pin_component_subtype=401,402
                  ,4 Exceptions Tiered rate calculation : for pin_component_type=4 ,pin_component_subtype=401,402
							     NOT NULL for pin_component_type=1 OR pin_component_type=2  ,pin_component_subtype=101,102,103,104
           * vary_by_fields -
					 * from_clause  - used to join input and tiers/expceptions/ other lookup tables
                          - EX:  TIERS on I.E1708078 = TIERS.PRODUCTID
                                 EX on I.E1708042 = EX.employeeid

					 * where_clause - used for periods
					 * effective_date_props - collection of type OBJTYPE_DATE_RANGE_INTERNAL with the following columns
							ENTITY_COLUMN_NAME          - will contain the column name of the date field to be compared from Roster or Input (ex: TRANSACTION_DATE),
							RELATIONSHIP_TABLE_ALIAS    - will contain the alias of the field's source (R for Roster, I for Input),
							ENTITY_DATE_RANGE_PART_1    - will contain the name of the effective start date column from lookup (ex: START_DATE),
							ENTITY_DATE_RANGE_PART_2    - will contain the name of the effective end date column from lookup (ex: END_DATE).


    pin_input_table_list	IN tabletype_input_table_list  NOT NULL :list of tables used in calculations(except lookups)
					 * table_name   - phisical table name;
					 * from_clause  - NOT NULL for table_type in (3,4,5,6,30) a from clause will be send: MT_COM,MT_WEIGTH,MT_P_TARGET,MT_C_TARGET,RC is the alias for the match_table
                                                                                            (3 comision rate,4 component weight, 5 plan target,6 component target, 30 comp roster)
                          I  is the alias for the input table
                          R  is the alias for the roster table
                          for table_type=3,6 search fields in input calculation entity fields then in roster fields
                              table_type=4,5,30 search fields in roster fields
                          TARGETS is the alias for table_type 18 (TARGETS on I.E1708042 = TARGETS.employeeid)
                          Templates for 3,4,5,6:
                           all match fields found in input 3,6
                            <alias for the match_table> ON <alias for the match_table>.<field1> = I.<field1> AND <alias for the match_table>.<field2> = I.<field2>
                           not all match fields found in input; some are in roster 3,6
                            <alias for the match_table> ON <alias for the match_table>.<field1> = I.<field1> AND <alias for the match_table>.<field2> = R.<field2> ...
                           all match fields took from roster 4,5
                            <alias for the match_table> ON <alias for the match_table>.<field1> = I.<field1> AND <alias for the match_table>.<field2> = R.<field2> ...
                           no fields set for match table 3,4,5,6
                            <alias for the match_table> ON 1=1
                     * where_clause - where clause that contain period filter
                                        - NULL for 8 Detailed earnings ,9 Aggregated Earnings,10 Modified Earnings,11 Component Earnings
                          - usually this contains user filters or period restraints
					 * table_type   -
                              0 roster
                            , 1 roster with earning entity and payment entity when earning entity <> payment entity
                            , 2 input (for pin_component_type = 3 then it's possible to have multiple inputs)
                            , 3 comision rate match table
                            , 4 component weight match table
                            , 5 plan target earning match table
                            , 6 component target earning match table
                            , 7 eligibility table
                            , 8 Detailed   Earnings
                            , 9 Aggregated Earnings
                            ,10 Modified   Earnings
                            ,11 Component  Earnings
                            ,17 Component  Detailed Tiered Earnings (New Result table for Tiered Commission Rate)
                            ,12 commission rate input table (metric result table used in commission rate lookup)
                            ,14 roster - selected items
                            ,15 roster - selected items with earning entity and payment entity when earning entity <> payment entity
                            ,16 entity table for earning entity;
                            ,18 Target Values Table (Tiered commission type: Percent of Target Treshold)
                            ,30 component roster

					 * input_number - NULL - for pin_component_type = 3 the inputs (table_type = 2) will have this populated with the ID of the metric that is the actual input
    pin_input_values_column			IN VARCHAR2 - depending on the input this will contain either 'METRIC', 'DETAILED_EARNINGS', 'AGGREGATED_EARNINGS' or 'MODIFIED_EARNINGS'
    pin_earning_entity	IN TABLETYPE_NAME_MAP  NOT NULL :column names of the earning entity
					 * NAME1 :column name of the earning entity
					 * NAME2 :column name of the earning entity business id
    pin_payment_entity	IN VARCHAR2	      NOT NULL :column name of the payment entity
  	pin_earning_calc_ent	IN TABLETYPE_CPM_ENTITIES      NULL :list columns that form the earning calculation entity
				* ENTITY_NAME		    - VARCHAR2 - NOT NULL - physical column name of the ECE as it will be in the output F.. for fields, E.. for entities
				* ENTITY_ORDER	    - NUMERIC  - NOT NULL - order of the ICM entity within the ECE, starting with 1
				* ENTITY_TYPE		    - NUMERIC  - NOT NULL - type of ICM entity: 1 = earning entity, 2 = payment entity, 3 = calc entity, 4 = plan calc entity
				* COLUMN_TYPE		    - NUMERIC  - NOT NULL - 1 = entity, 2 = field
				* INPUT_NUMBER	    - NUMERIC  - NULL
				* MAPPING_TYPE	    - NUMERIC  - NULL
				* ENTITY_TABLE_NAME	- VARCHAR2 - NULL - if COLUMN_TYPE = 1 then this is the physical table name of entity table
				* ENTITY_FIELD_NAME - VARCHAR2 - NULL - if COLUMN_TYPE = 1 then this is the name of the business key column in the entity table
    pin_use_target		IN NUMBER     NOT NULL : 0 no target, 1 with plan target, 2 with component target
    pin_component_type	IN NUMBER     NOT NULL : 1 lookup, 2 commision rate, 3 custom formula, 4 Tiered Commission Rate
    pin_component_subtype	IN NUMBER	  NULL : for pin_component_type=1 :
									                                    1  step,
                                                      2 continuous,
                                                      3 discrete value,
                                                      4 matrix lookup
								                             for pin_component_type=2 :
									                                    100 rate value,
                                                      101 lookup rate step,
                                                      102 lookup rate continuous,
									                                    103 lookup rate discrete value,
                                                      104 lookup rate matrix,
									                                    105 match table rate;
                                             for pin_component_type=3 : -
                                             for pin_component_type=4 :
                                                      400 Fixed Value
                                                      401 Percent of Target
	pin_comision_rate_value		  IN NUMBER	 NULL : comision rate value set in the component
    pin_component_weight_value	IN NUMBER	 NULL : component weight value set in the plan
    pin_plan_target_earn_val	  IN NUMBER	 NULL : target earning value set in the plan
    pin_comp_target_earn_val	  IN NUMBER	 NULL : target earning value set in the component
	pin_no_comp_per_pas_in_sub	IN NUMBER	 NULL : represents the number of component periods passed in the subtract period time frame
	pin_lookup_precision        IN VARCHAR2 NULL : represents the number of decimal places the result field "Detailed earnings" has to be rounded to

<<CUSTOM FORMULA>>
    pin_cust_form_exp           IN CLOB      NULL : if pin_component_type = 3 then this is the SQL translated formula to populate the DETAILED_EARNINGS column
    pin_cust_form_clauses       IN TABLETYPE_CUST_FORM_CLAUSES NULL : if pin_component_type = 3 then user might have used in the formula functions of type LastPeriodInTable or LastDateInTable
                                                    the functions can be applied to either:
                                                        * attribute fields from roster
                                                        * MCE fields - but values in these fields are the same in all metrics so we will apply the clauses only to one metric
                                                    this means the collection can have at most two records - one for roster and one for metrics
                    * input_number - NOT NULL - 0 for clauses to be applied on the roster
                                            - the id of an input metric (any one of them) for clauses to be applied on metrics; has the same value with pin_input_table_list.input_number
                    * select_clause - NOT NULL - comma separated columns created for LastPeriodInTable or LastDateInTable functions
                                        ex: TPRV_LNVT_1027989405.TUPR_RANGE_NUMBER RN_1027989405
                                            ,MAX(TPRV_LNVT_1027989405.TUPR_RANGE_NUMBER) KEEP (DENSE_RANK FIRST ORDER BY TPRV_LNVT_1027989405.TUPR_RANGE_NUMBER DESC NULLS LAST) OVER (PARTITION BY NULL) MAX_RN_1027989405
                                            ,MAX(TPRV_LNVT_1027989405.TUPR_ID) KEEP (DENSE_RANK FIRST ORDER BY TPRV_LNVT_1027989405.TUPR_RANGE_NUMBER DESC NULLS LAST) OVER (PARTITION BY NULL) MAX_VALUE_1027989405
                    * from_clause - NULL - all joins needed for calculating the columns above
                                        ex: LEFT JOIN TU_PERIODS_RANGE_V TPRV_LNVT_1027989405 ON I210631.F209616 = TPRV_LNVT_1027989405.TUPR_ID
    pin_cust_form_ass_ent       IN TABLETYPE_NAME_JOIN_MAP NULL : if pin_component_type = 3 and roster is generated based on an assignment between
                                                earning entity and another entity then this will have one record with information about that entity
                    NAME1 - NOT NULL - entity column name. Ex E123
                    NAME2 - NOT NULL - entity table name. Ex T430
                    NAME3 - NOT NULL - entity BK field name in the table. Ex F5434
                    NAME4 - NULL
                    NAME5 - NULL

    pin_aggregation_type		     IN NUMBER	            NULL     : 1 sum, 2 avg, 3 min,4 max;
							                                          NULL     : when there is no need for aggregation ECE=earning entity+plan calc entities

    pin_agg_round_type			      IN NUMBER         NULL : Round type: 16-ROUND, 17-ROUND UP, 18-ROUND DOWN.
    pin_agg_round_dec_num			      IN NUMBER     NULL : Number of decimals to round (0-10). Might be removed because the system field has only 2 decs.

<<PERIODS>>
    pin_period_column		         IN VARCHAR2            NOT NULL : column name for component period run
    pin_current_period		       IN NUMBER              NOT NULL : component period run
    pin_projected_period_column	 IN VARCHAR2            NULL     : column name for Projected payment period;
							                                          NOT NULL : when projected payments are calculated in the plan; NULL for the rest
		pin_projected_period		     IN NUMBER	            NULL     : period of the component run
							                                          NOT NULL : when projected payments are calculated in the plan; NULL for the rest
		pin_projected			           IN NUMBER	            NULL     : 1 projected period run,0 normal run
							                                          NOT NULL : when projected payments are calculated in the plan; NULL for the rest
		pin_no_plan_per_for_comp_per IN NUMBER	            NULL     : number of plan periods that correspond to the component period
							                                          NOT NULL : when pin_use_target=1
		pin_no_plan_per_for_target	 IN NUMBER	            NULL     : number of plan periods the target earnings are for)
							                                          NOT NULL : when pin_use_target=1
		pin_no_comp_per_for_target	 IN NUMBER	            NULL     : number of component periods the target earnings are for
							                                          NOT NULL : when pin_use_target=1

    pin_component_weight_fields	 IN tabletype_id_name   NULL     : the COMPONENT_WEIGHT fields for all components within the same plan version with the executing one
							                                          NOT NULL : when pin_use_target=1 and match weight table MT_WEIGTH is used
							      * ID - 0 current component, 1 other component
							      * NAME - column name of COMPONENT_WEIGHT field for components - ex: F1234

<<VALIDATIONS>>
		pin_vld_when			           IN CLOB		NULL : the output string which holds the "insert when" clauses related to validations.
		pin_vld_select			         IN CLOB		NULL : the output string which holds the "select" clauses related to validations.
		pin_vld_avg				           IN CLOB		NULL : the output string which holds the "AVG" clause related to validations.
		pin_vld_from			           IN CLOB		NULL : the output string which holds the "from join" clauses related to validations.
		pin_vld_get_values		       IN CLOB		NULL : the output string which holds the query that selects the triggered validations.
		pin_vld_need_to_count	       IN CLOB		NULL : 0 if there is no need to do a count; 1 if there is at least one validation that needs the count.

<<MODIFIERS>>
        pin_mod_apply_option            IN NUMBER  NULL - populated if pin_aggregation_type is not null with value taken
                                                    from PLAN_COMP_ENTITIES_TAB.PCET_AGGREGATION_OPT - 1- apply mod BEFORE agg, 2-AFTER
        pin_before_mod_when			          IN CLOB    NULL - a string holding the modifiers when clause of the modifier that has to be executed before aggregation
		pin_before_mod_select			      IN CLOB    NULL - a string holding the modifiers select clause  of the modifier that has to be executed before aggregation
		pin_before_mod_from			          IN CLOB    NULL - a string holding the modifiers from clause  of the modifier that has to be executed before aggregation
		pin_before_mod_where			      IN CLOB    NULL - a string holding the modifiers where clause  of the modifier that has to be executed before aggregation

        pin_after_mod_when                    IN CLOB    NULL - a string holding the modifiers when clause of the modifier that has to be executed after aggregation
        pin_after_mod_select                  IN CLOB    NULL - a string holding the modifiers select clause  of the modifier that has to be executed after aggregation
        pin_after_mod_from                    IN CLOB    NULL - a string holding the modifiers from clause  of the modifier that has to be executed after aggregation
        pin_after_mod_where                   IN CLOB    NULL - a string holding the modifiers where clause  of the modifier that has to be executed after aggregation



		pout_ee_posted_count	OUT NUMBER -
                      0 = all earning entities had errors - there were no earning entities posted in the result table
											1 = at least 1 earning entity had no errors and was posted in the result table
		pout_vld_results		OUT SYS_REFCURSOR : Result set :
						VALIDATION_ID	     NUMBER            : the id of the validation posible values 1,2,3,4,5
						VALIDATION_TYPE	   VARCHAR2          : type of validation trigger ERROR/WARNING
						VALIDATION_ENT_CNT NUMBER            : count of all entities that have triggered the validation
						VALIDATION_DETAILS TABLETYPE_CHARMAX : the business ids of all entities which have triggered this validation
								       TABLETYPE_CHARMAX("<business_id1>",...,"<business_id2>")
	-----------------------------------------------------------------------------------------
	*/
	PROCEDURE RUN_COMPONENT
	(	 pin_definition_id              IN NUMBER
        ,pin_lookup_table				        IN TABLETYPE_LOOKUP_TABLE_LIST
		,pin_input_table_list			      IN TABLETYPE_INPUT_TABLE_LIST
        ,pin_earning_entity				      IN TABLETYPE_NAME_MAP
		,pin_payment_entity				      IN VARCHAR2
		,pin_earning_calc_ent			      IN TABLETYPE_CPM_ENTITIES
		,pin_use_target					        IN NUMBER
        ,pin_input_values_columns			IN TABLETYPE_ID_NAME
		,pin_component_type				      IN NUMBER
		,pin_component_subtype			    IN NUMBER
		,pin_comision_rate_value		    IN NUMBER
		,pin_component_weight_value		  IN NUMBER
		,pin_plan_target_earn_val		    IN NUMBER
		,pin_comp_target_earn_val		    IN NUMBER
        ,pin_cust_form_exp              IN CLOB
        ,pin_cust_form_clauses          IN TABLETYPE_CUST_FORM_CLAUSES
        ,pin_cust_form_ass_ent          IN TABLETYPE_NAME_JOIN_MAP
		,pin_aggregation_type			      IN NUMBER
        ,pin_agg_round_type			      IN NUMBER
        ,pin_agg_round_dec_num			      IN NUMBER
		,pin_period_column				      IN VARCHAR2
		,pin_current_period				      IN NUMBER
		,pin_projected_period_column	  IN VARCHAR2
		,pin_projected_period			      IN NUMBER
		,pin_projected					        IN NUMBER
		,pin_no_plan_per_for_comp_per	  IN NUMBER
		,pin_no_plan_per_for_target		  IN NUMBER
		,pin_no_comp_per_for_target		  IN NUMBER
		,pin_no_comp_per_pas_in_sub  IN NUMBER
		,pin_component_weight_fields	  IN TABLETYPE_ID_NAME
		,pin_vld_when					          IN CLOB
		,pin_vld_select					        IN CLOB
		,pin_vld_from					          IN CLOB
		,pin_vld_get_values				      IN CLOB
		,pin_vld_need_to_count			    IN NUMBER
        --,pin_mod_apply_option			   IN NUMBER DEFAULT 2
        ,pin_before_mod_when                IN CLOB
        ,pin_before_mod_select              IN CLOB
        ,pin_before_mod_from                IN CLOB
        ,pin_before_mod_where               IN CLOB
        ,pin_after_mod_when                 IN CLOB
        ,pin_after_mod_select               IN CLOB
        ,pin_after_mod_from                 IN CLOB
        ,pin_after_mod_where                IN CLOB
		,pin_lookup_precision           IN VARCHAR2
		,pout_ee_posted_count			      OUT NUMBER
		,pout_vld_results	    	        OUT SYS_REFCURSOR
	);

-- ############################# RUN_COMPONENT END   #############################

  -- *******************************    PUBLIC PROCEDURES END         *******************************
END COMPONENTS_PROCESSING;
/
