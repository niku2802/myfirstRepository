CREATE PACKAGE COMMONS_APPFRAMEWORK AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : commons
  -- Module      : appframework
  -- Requester    : Cozac, Tudor
  -- Author      : Cozac, Tudor
  -- Reviewer    :
  -- Review date  : 20101116
  -- Description  : Creates UID_SEQUENCE
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************

/*-- ========================================================
  -- Author     : Cozac, Tudor
  -- Create date: 20110131
  -- Description: Verify uniqueness for a given table with ID and Name
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
   pin_table_name    IN  VARCHAR2    the table for which the validation is done
     pin_name_col_name    IN  VARCHAR2    name of the column for which the uniqueness is checked (usually name)
     pin_id_col_name    IN  VARCHAR2    name of the unique column (usually id)
     pin_name_space_col_names  IN  tabletype_id_name     column names (along with their types) that determine the namespace (uniqueness is at their level)
            ID  : column type : 1 positive numeric ; 2 varchar
            NAME  : column name
          NULL when uniqueness is at the table level
     pin_data     IN  tabletype_id_name a nested table variable with the names to be updated along with their ID's

  -----------------------------------------------------------------------------------------
  -- Resultset : List with duplicates.
  --  : ID NUMERIC(10)
  --  : NAME VARCHAR(30)
  -----------------------------------------------------------------------------------------
  Example:
  variable c refcursor
  exec :c := COMMONS_APPFRAMEWORK.CHECK_UNIQUENESS('TEST1','NAME','ID',NULL,tabletype_id_name( objtype_id_name(1, 'bb'),objtype_id_name(2, '00aa')))
  print c
*/
FUNCTION CHECK_UNIQUENESS(pin_table_name           IN VARCHAR2,
            pin_name_col_name        IN VARCHAR2,
            pin_id_col_name          IN VARCHAR2,
            pin_name_space_col_names IN tabletype_id_name,
            pin_data                 IN tabletype_id_name)
RETURN SYS_REFCURSOR;

FUNCTION CHECK_UNIQUENESS_COL(pin_table_name           IN VARCHAR2,
                              pin_name_col_name        IN VARCHAR2,
                              pin_id_col_name          IN VARCHAR2,
                              pin_name_space_col_names IN tabletype_id_name,
                              pin_data                 IN tabletype_id_name,
                               pin_table_ver_col_name   IN VARCHAR2 DEFAULT NULL)
RETURN tabletype_id_name;

  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************

/*  -- ========================================================
*/
PROCEDURE CREATE_PK_TRIGGER(pi_table_name  IN VARCHAR2,
              pi_column_name IN VARCHAR2);


/*  -- ========================================================
declare
-- Non-scalar parameters require additional processing
PO_OR_DEF sys_refcursor;

 TYPE temprec is RECORD
(
  OR_ID    OBJECT_REGISTRATION.OR_ID%TYPE,
  OR_NAME  clob,
  OR_NAME_UNRESOLVED  OBJECT_REGISTRATION.OR_NAME%type,
  OR_TYPE  OBJECT_REGISTRATION.OR_TYPE%type,
  OR_CONTAINER_ID OBJECT_REGISTRATION.OR_CONTAINER_ID%type
 );


TYPE array_t IS TABLE OF temprec INDEX BY BINARY_INTEGER;
rec_array array_t;
begin
  dbms_output.put_line(1);
-- Call the procedure
COMMONS_APPFRAMEWORK.GET_OBJECTS_BY_ID(PI_OR_IDS => coltype_id(68376,69761),
                     PO_OBJECTS => PO_OR_DEF);
dbms_output.put_line(2);
FETCH PO_OR_DEF BULK COLLECT
  INTO rec_array;
  dbms_output.put_line(3);
FOR I IN 1 .. rec_array.COUNT LOOP

  dbms_output.put_line(rec_array(I).OR_ID);
  dbms_output.put_line(rec_array(I).OR_NAME);
  dbms_output.put_line(rec_array(I).OR_NAME_UNRESOLVED);
   dbms_output.put_line(rec_array(I).OR_TYPE);
   dbms_output.put_line(rec_array(I).OR_CONTAINER_ID);
END LOOP;
  dbms_output.put_line(4);
end;

*/

PROCEDURE GET_OBJECTS_BY_ID(PI_OR_IDS  IN coltype_id,
                            PO_OBJECTS OUT sys_refcursor);


/*  -- ========================================================
    declare
    -- Non-scalar parameters require additional processing
    PO_OR_DEF sys_refcursor;

     TYPE temprec is RECORD
    (
        OR_ID    OBJECT_REGISTRATION.OR_ID%TYPE,
        OR_NAME  clob,
        OR_NAME_UNRESOLVED  OBJECT_REGISTRATION.OR_NAME%type,
        OR_TYPE  OBJECT_REGISTRATION.OR_TYPE%type,
    OR_CONTAINER_ID OBJECT_REGISTRATION.OR_CONTAINER_ID%type
     );


    TYPE array_t IS TABLE OF temprec INDEX BY BINARY_INTEGER;
    rec_array array_t;
  begin
      dbms_output.put_line(1);
    -- Call the procedure
    COMMONS_APPFRAMEWORK.GET_OBJECTS_BY_UNRESOLVED_NAME(PI_OR_NAME => 'Report 06',
                                             PO_OBJECTS => PO_OR_DEF);
    dbms_output.put_line(2);
    FETCH PO_OR_DEF BULK COLLECT
      INTO rec_array;
        dbms_output.put_line(3);
    FOR I IN 1 .. rec_array.COUNT LOOP

      dbms_output.put_line(rec_array(I).OR_ID);
      dbms_output.put_line(rec_array(I).OR_NAME);
      dbms_output.put_line(rec_array(I).OR_NAME_UNRESOLVEDOR_TYPE);
       dbms_output.put_line(rec_array(I).OR_TYPE);
     dbms_output.put_line(rec_array(I).OR_CONTAINER_ID);
    END LOOP;
      dbms_output.put_line(4);
  end;
 */
PROCEDURE GET_OBJECTS_BY_UNRESOLVED_NAME(PI_OR_NAME IN VARCHAR2,
                          PO_OBJECTS OUT sys_refcursor);


/*  -- ========================================================

declare
-- Non-scalar parameters require additional processing
PO_OR_DEF sys_refcursor;

 TYPE temprec is RECORD
(
  OR_ID    OBJECT_REGISTRATION.OR_ID%TYPE,
  OR_NAME  clob,
  OR_NAME_UNRESOLVED  OBJECT_REGISTRATION.OR_NAME%type,
  OR_TYPE  OBJECT_REGISTRATION.OR_TYPE%type,
  OR_CONTAINER_ID OBJECT_REGISTRATION.OR_CONTAINER_ID%type
 );


TYPE array_t IS TABLE OF temprec INDEX BY BINARY_INTEGER;
rec_array array_t;
begin
  dbms_output.put_line(1);
-- Call the procedure
COMMONS_APPFRAMEWORK.GET_OBJECTS_BY_TYPE(pi_or_type => 16,
                       PO_OBJECTS  => PO_OR_DEF);

dbms_output.put_line(2);
FETCH PO_OR_DEF BULK COLLECT
  INTO rec_array;
  dbms_output.put_line(3);
FOR I IN 1 .. rec_array.COUNT LOOP

  dbms_output.put_line(rec_array(I).OR_ID);
  dbms_output.put_line(rec_array(I).OR_NAME);
  dbms_output.put_line(rec_array(I).OR_NAME_UNRESOLVED);
   dbms_output.put_line(rec_array(I).OR_TYPE);
   dbms_output.put_line(rec_array(I).OR_CONTAINER_ID);
END LOOP;
  dbms_output.put_line(4);
end;

*/
PROCEDURE GET_OBJECTS_BY_TYPE(PI_OR_TYPE IN NUMBER,
              PO_OBJECTS OUT sys_refcursor);


/*  -- ========================================================
declare
result varchar2(250);
begin
  -- Call the function
  result := commons_appframework.get_name(pi_name => '|~937~|-|~1565~|');
  --DD-ZZ- YYYYyyy-() Y01234 56789-Edit Validation Entity 10
end;

*/
FUNCTION GET_NAME(pi_name IN VARCHAR2) RETURN VARCHAR2;

/* ========================================================
-- Author     : Andries, Adriana
-- Create date: 20121204
-- Description: Return a valid SCN for a select on one or multiple tables
-----------------------------------------------------------
Parameters:
   PIN_TABLE_LIST        NOT_NULL  - list of tables in the select statement

-----------------------------------------------------------
Example:
DECLARE v_SCN NUMBER;
BEGIN
  v_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => 'TEST_TABLE, TEST_TABLE_JOIN');
END;

-- ========================================================*/
FUNCTION GET_VALID_SCN(PIN_TABLE_LIST IN VARCHAR2) RETURN NUMBER;


 PROCEDURE VERSION_OVERLAP_CHECK(pi_TABLE_CLOB IN VARCHAR2,
                                  pi_KEY_FIELDS      IN CLOB,
                                  PI_effective_start IN VARCHAR2,
                                  PI_effective_end   IN VARCHAR2,
                                  PI_is_Period       IN number,
                                  po_OVERLAP_CHK_RES OUT NUMBER

                                  ) ;

  /* ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20131021
  -- Description: Return NLS properties
  -----------------------------------------------------------
  Parameters:
     pi_property_name  - NOT_NULL - NLS propery name
  -----------------------------------------------------------
  Example:
  BEGIN  commons_appframework.get_nls_property
            (pi_property_name => 'NLS_SORT');
  END;

  -- ========================================================*/
  function get_nls_property(pi_property_name in varchar2) return varchar2;
  function get_characterset_name return varchar2 ;
   /* ========================================================
-- Author     : Andries, Adriana
-- Create date: 20140224
-- Description: Return a cursor containing object registration details for certain roles and one feature
-----------------------------------------------------------
Parameters:
   pin_role_ids              NOT_NULL  - list of role ids
   pin_feature_id            NOT_NULL  - feature id
   pout_object_registration            - return cursor

-----------------------------------------------------------
Example:
declare
pout_object_registration sys_refcursor;
begin
  -- Call the procedure
  get_role_objects_permissions(to_clob('455750,428941,476500'),
                               133,
                               pout_object_registration);
end;
-- ========================================================*/
 procedure get_role_objects_permissions (pin_role_ids in TABLETYPE_NUMBER,
                                         pin_feature_id in number,
                                         pout_object_registration out sys_refcursor );

/*  PROCEDURE SET_CONTEXT_VALUE
  ========================================================
  Description and usage details:
  ========================================================
  History:
  2015.01.28 - Andries, Adriana - created
  ========================================================*/
PROCEDURE SET_CONTEXT_VALUE
(    pi_pr_name     IN PROPERTIES.PR_NAME%TYPE
    ,pi_pr_value    IN PROPERTIES.PR_VALUE%TYPE
);

/*  PROCEDURE GET_CONTEXT_VALUE
  ========================================================
  Description and usage details:
  ========================================================
  History:
  2015.01.28 - Andries, Adriana - created
  ========================================================*/
FUNCTION GET_CONTEXT_VALUE
(    pi_pr_name     IN PROPERTIES.PR_NAME%TYPE
) RETURN PROPERTIES.PR_VALUE%TYPE;

	/*
	----------------------------------------------------------------------------------------
	Author     	: Lazar, Lucian
	Create date	: 20150505
	Description	: Returns the row identifier sequence name for normal or partitioned tables
	----------------------------------------------------------------------------------------
	Input Parameters:
		pi_table_name  not null  clob    The table name; can be partitioned (T2700449_PART_320) or unpartitioned (T2700449)
    pi_period_id   not null  number  The period id used in partitioning
	----------------------------------------------------------------------------------------
	Result:
		<row_idenitifer_sequence_name> from <table_name>_PART_<period_id>
    T2700449_ROW_IDENTIFIER_SEQ from T2700449_PART_320
	----------------------------------------------------------------------------------------
	Example: commons_appframework.get_row_identifier_sequence('T2700449_PART_320',320);
	----------------------------------------------------------------------------------------
	*/
  function get_row_identifier_sequence(pi_table_name in varchar2,
                                       pi_period_id  in number)
    return varchar2;

-------------------------------------------------
  FUNCTION GET_TREF_ID(pi_pvv_id IN NUMBER) RETURN NUMBER;

/*  PROCEDURE GET_CONTEXT_VALUE
  ========================================================
  Description and usage details: it's a job created to cleanup the JOBS_COMPARE table
  ========================================================
  History:
  2015.12.11 - Kristo, Robert - created
  ========================================================*/
  PROCEDURE CLEANUP_JOBS_COMPARE;


/* GET_TABLE_COLUMNS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_COLUMNS
(   pin_table_id IN NUMBER
) RETURN TABLETYPE_DT_MR_COL_PROPS;


/* GET_TABLE_NAME
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_NAME
(   pin_table_id IN NUMBER
) RETURN VARCHAR2;


/* GET_TABLE_ID_BY_REF
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_ID_BY_REF
(   pin_table_ref_id IN NUMBER
) RETURN NUMBER;


/* CREATE_MV_LOG_TABLE
-- Author       : Kristo, Robert
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  : The procedure will create a log table to be used for fast refresh by the materialized views created on the PLA schema (for different server cases)
-----------------------------------------------------------------------------------------------
-- Assumptions: pin_table_name    VARCHAR2 - contains the SPM table name
--              pin_tx_id         VARCHAR2 - contains the transaction id

Call example:
EXEC CREATE_MV_LOG_TABLE(pin_table_name => 'T100', pin_tx_id => '1231');

*/
PROCEDURE CREATE_MV_LOG_TABLE(pin_table_name VARCHAR2,
                              pin_tx_id      VARCHAR2);


/* DROP_MV_LOG_TABLE
-- Author       : Kristo, Robert
-- Create date  : 10/11/2016
-- Reviewer     :
-- Review date  :
-- Description  : The procedure will delete a mv log table
-----------------------------------------------------------------------------------------------
-- Assumptions: pin_table_name    VARCHAR2 - contains the SPM table name

Call example:
EXEC DROP_MV_LOG_TABLE(pin_table_name => 'T100');

*/
PROCEDURE DROP_MV_LOG_TABLE(pin_table_name VARCHAR2,
							pin_tx_id      VARCHAR2);


/* GRANT_SELECT_ON_TABLE
-- Author       : Kristo, Robert
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  : The procedure will grant select on a table from SPM to the PLA schema (for same server cases)
-----------------------------------------------------------------------------------------------
-- Assumptions: pin_table_name    VARCHAR2 - contains the SPM table name
--              pin_schema_name   VARCHAR2 - PLA schema name

Call example:
EXEC GRANT_SELECT_ON_TABLE(pin_table_name => 'T100', pin_schema_name => 'ROBI_PLA');

*/
PROCEDURE GRANT_SELECT_ON_TABLE(pin_table_name  VARCHAR2,
                                pin_schema_name VARCHAR2);


/* CREATE_SYNONYM_FOR_PLA_TABLE
-- Author       : Dumitriu, Cosmin
-- Create date  : 25.NOV.2016
-- Reviewer     :
-- Review date  :
-- Description  : Whenever a model table will be created on the new PLA schema the SPM will have to gain acces to it in order to
                  be able to use it as input to Data Load/whatever. For this we will create in either deployment mode "same/different server"
                  a synonym pointing to that object.
-----------------------------------------------------------------------------------------------
-- Assumptions:
     pin_table_name     VARCHAR2 - NOT NULL
                        - the table name from PLA that need to be accessed in SPM
    ,pin_tx_id          VARCHAR2 - NULL
                        - the tx id under which the synonym will be created
    ,pin_run_id         NUMBER - NULL
                        - the process run id under which the synonym will be created
                        - as part of creating a new model table on PLA from java code, the procedure will always either recieve
                          the tx_id or run_id. however there is functionality at install/upgrade time of PLA (usually executed as part of a restore)
                          where if we switch the deployment mode from "diff to same sever" or viceversa then we will have to recreate all synonyms
                          that are cross schemas. in that case this SP will be executed for each model table in PLA and it is possible to not
                          have a tx_id / run_id to register with.
*/
PROCEDURE CREATE_SYNONYM_FOR_PLA_TABLE
(    pin_table_name     VARCHAR2
    ,pin_tx_id          VARCHAR2 DEFAULT NULL
    ,pin_run_id         NUMBER DEFAULT NULL
);


/* DROP_SYNONYM_FOR_PLA_TABLE
-- Author       : Dumitriu, Cosmin
-- Create date  : 25.NOV.2016
-- Reviewer     :
-- Review date  :
-- Description  : Whenever a model table will be deleted from PLA we need to delete the synonym we created for it in the SPM schema.
-----------------------------------------------------------------------------------------------
-- Assumptions:
     pin_table_name     VARCHAR2 - NOT NULL
                        - the table name from PLA that was also accessed in SPM
    ,pin_tx_id          VARCHAR2 - NULL
                        - the tx id under which the synonym will be dropped
    ,pin_run_id         NUMBER - NULL
                        - the process run id under which the synonym will be dropped
                        - as part of creating a new model table on PLA from java code, the procedure will always either recieve
*/
PROCEDURE DROP_SYNONYM_FOR_PLA_TABLE
(    pin_table_name     VARCHAR2
    ,pin_tx_id          VARCHAR2 DEFAULT NULL
    ,pin_run_id         NUMBER DEFAULT NULL
);

  -- *******************************    PUBLIC PROCEDURES END         *******************************
END commons_appframework;
/
