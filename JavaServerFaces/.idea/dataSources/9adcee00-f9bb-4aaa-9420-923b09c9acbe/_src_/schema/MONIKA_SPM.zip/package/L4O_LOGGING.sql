CREATE PACKAGE L4O_LOGGING
IS
-- ---------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type: SPM
-- Product		: commons
-- Module		: appframework
-- Requester    : Cozac, Tudor
-- Author		: Dumitriu, Cosmin
-- Reviewer		:
-- Review date	:
-- Description	: This package contains all necessary functions for logging PLSQL messages into database.
-- ---------------------------------------------------------------------------

/* ========================================================
Settings used throughout the package:
L4O_LOGGING_LEVEL		- Logging level used in LOG4ORA framework. FATAL < ERROR < WARN < INFO < DEBUG
						- abbreviation: LVL
						- Possible values:
							"FATAL"	- L4O_LOGGING.LVL_FATAL
							"ERROR"	- L4O_LOGGING.LVL_ERROR
							"WARN"	- L4O_LOGGING.LVL_WARN
							"INFO"	- L4O_LOGGING.LVL_INFO
							"DEBUG"	- L4O_LOGGING.LVL_DEBUG
L4O_OUTPUT_DEVICE		- Output device used in LOG4ORA framework.
						- abbreviation: DEV
						- Possible values:
							"BUFFER"-logs are sent to dbms_output,
							"DATABASE"-logs are saved in the L4O_LOGS table
L4O_INCLUDE_TIMESTAMP	- Include or not timestamps in the logs if these are sent to dbms_output.
						- abbreviation: TMT
						- Possible values:
							"TRUE",
							"FALSE"
L4O_COLL_INCLUDE_INDEX	- Include or not comments of collection element indexes.
						- abbreviation: IND
						- Possible values:
							"TRUE",
							"FALSE"
The abbreviations are set in GET_CTX_VALUES.
-- ========================================================*/
LVL_FATAL				CONSTANT VARCHAR2(20) := 'FATAL';
LVL_ERROR				CONSTANT VARCHAR2(20) := 'ERROR';
LVL_WARN				CONSTANT VARCHAR2(20) := 'WARN';
LVL_INFO				CONSTANT VARCHAR2(20) := 'INFO';
LVL_DEBUG				CONSTANT VARCHAR2(20) := 'DEBUG';

OUT_BUFFER      CONSTANT VARCHAR2(20) := 'BUFFER';
OUT_DATABASE    CONSTANT VARCHAR2(20) := 'DATABASE';


/* ========================================================
-- Author     : Dumitriu, Cosmin
-- Create date: 20120222
-- Description: Log a message
-----------------------------------------------------------
Parameters:
	 pi_log_level		NOT_NULL	- log level to use
	,pi_message			NOT NULL	- message to be logged
	,pi_error_code		NULL		- error code to log
	,pi_error_message	NULL		- error message to log
	,pi_identifier		NULL		- if multiple messages of the same type must be logged from concurrent sessions, this identifier can help developers
									  identify the parent session/transaction of a particular message.

-----------------------------------------------------------
Example 1: log a simple message

BEGIN	L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_INFO, 'First set of variables.');
END;

-----------------------------------------------------------
Example 2: log messages with identifiers

DECLARE	v_stamp	VARCHAR2(200);
BEGIN	v_stamp := TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
		L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'First step has finished.', NULL, NULL, v_stamp);
		L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Second step has finished.', NULL, NULL, v_stamp);
END;

LOG_ID	LOG_TIMESTAMP			LOG_MESSAGE					LOG_IDENTIFIER
1		22-FEB-12 02.51.00 PM	'First step has finished.'	22-FEB-12 02.40.00 PM
2		22-FEB-12 02.52.00 PM	'First step has finished.'	22-FEB-12 02.50.00 PM
3		22-FEB-12 02.53.00 PM	'Second step has finished.'	22-FEB-12 02.50.00 PM
4		22-FEB-12 02.54.00 PM	'Second step has finished.'	22-FEB-12 02.40.00 PM

-----------------------------------------------------------
Example 3: log errors

BEGIN	L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, 'An error has occurred at processing.', SQLCDE, SQLERRM);
END;

-- ========================================================*/
PROCEDURE LOG_MESSAGE
(	 pi_log_level		L4O_LOGS.L4OL_LEVEL%TYPE
	,pi_message			L4O_LOGS.L4OL_MESSAGE%TYPE
	,pi_error_code		L4O_LOGS.L4OL_ERROR_CODE%TYPE DEFAULT NULL
	,pi_error_message	L4O_LOGS.L4OL_ERROR_MESSAGE%TYPE DEFAULT NULL
	,pi_identifier		L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL
);


/* ========================================================
-- Author     : Dumitriu, Cosmin
-- Create date: 20120222
-- Description: Log a variable value. Please use with caution as it may require intensive processing.
				It is ment to be used mostly with DEBUG logging level.
-----------------------------------------------------------
Parameters:
	 pi_log_level		NOT_NULL	- log level to use
	,pi_variable		NOT NULL	- variable to be logged
	,pi_message_format	NULL		- a template for message format, "<value>" will be replaced with the actual computed value of the variable
	,pi_identifier		NULL		- if multiple messages of the same type must be logged from concurrent sessions, this identifier can help developers
									  identify the parent session/transaction of a particular message.

-----------------------------------------------------------
Example 1: log a variable

DECLARE	v_e1 VARCHAR2(200);
BEGIN	v_e1 := 'asd';
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_e1));
END;

Message logged:
'asd'

-----------------------------------------------------------
Example 1: log a variable with a template

DECLARE	v_e1 VARCHAR2(200);
BEGIN	v_e1 := 'asd';
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_e1), 'v_e1 := <value>;');
END;

Message logged:
v_e1 := 'asd';


L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_e1)		,'v_e1 := <value>;');
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_e4)			,'v_e4 := <value>;');
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_e5)			,'v_e5 := <value>;');
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(vobj_c2)		,'vobj_c2 := <value>;');
L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(vtab_c3)	,'vtab_c3 := <value>;');
-- ========================================================*/
PROCEDURE LOG_VARIABLE
(	 pi_log_level		L4O_LOGS.L4OL_LEVEL%TYPE
	,pi_variable		ANYDATA
	,pi_message_format	VARCHAR2 DEFAULT NULL
	,pi_identifier		L4O_LOGS.L4OL_IDENTIFIER%TYPE DEFAULT NULL
);


/* ========================================================
  -- Author     : Kristo Robert
  -- Create date: 18/06/2013
  -- Reviewer : Hrubaru Ionut
  -- Review date:
  -- Description: Create logging text
   -----------------------------------------------------------------------------------------------
         -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Creates logging text
      -- Input Parameters:
      --    ->> INPUT
pin_package_name             The name of the package where the function/procedure is located
  pin_procedure_name           The name of the function/procedure
   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      SELECT CREATE_LOG(
        pin_package_name   => 'ROLLUP_HIERARCHY',
        pin_procedure_name => 'ROLLUP_THE_HIERARCHY'
      )
      FROM DUAL;
-- ========================================================*/
FUNCTION CREATE_LOG(
pin_package_name   varchar2,
pin_procedure_name varchar2
)
RETURN CLOB;

END L4O_LOGGING;
/
