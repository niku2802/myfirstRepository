CREATE PACKAGE BODY commons_appframework AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : appframework
  -- Requester      : Cozac, Tudor
  -- Author         : Cozac, Tudor
  -- Reviewer       :
  -- Review date    : 20101116
  -- Description    :
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
-- ############################# CREATE_PK_TRIGGER START #############################
  PROCEDURE CREATE_PK_TRIGGER(pi_table_name  IN VARCHAR2,
                              pi_column_name IN VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE '
        CREATE OR REPLACE TRIGGER ' || pi_table_name ||
                      '_PK BEFORE INSERT ON ' || pi_table_name ||
                      ' FOR EACH ROW
        BEGIN
           SELECT UID_SEQUENCE.NEXTVAL INTO :NEW.' ||
                      pi_column_name || ' FROM DUAL;
        END;
        ';

  EXCEPTION
    WHEN OTHERS THEN
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, 'Error in creating identity trigger over table "' || pi_table_name || '"', SQLCODE, SQLERRM);
      raise_application_error(-20001, SQLERRM);
  END CREATE_PK_TRIGGER;
-- ############################# CREATE_PK_TRIGGER END #############################

-- ############################# CHECK_UNIQUENESS START #############################
  FUNCTION CHECK_UNIQUENESS(pin_table_name           IN VARCHAR2,
                            pin_name_col_name        IN VARCHAR2,
                            pin_id_col_name          IN VARCHAR2,
                            pin_name_space_col_names IN tabletype_id_name,
                            pin_data                 IN tabletype_id_name)
    RETURN SYS_REFCURSOR IS
    c_output                SYS_REFCURSOR;
    l_count                 INTEGER;
    v_name_space_col_names1 VARCHAR2(4000);
    v_name_space_col_names2 VARCHAR2(4000);
    v_name_space_col_names3 VARCHAR2(4000);
  BEGIN
  FOR C IN (SELECT ID, NAME FROM TABLE(pin_name_space_col_names)) LOOP
    v_name_space_col_names1 := v_name_space_col_names1 || ',PTN.' || C.NAME;
    v_name_space_col_names2 := v_name_space_col_names2 || C.NAME ||',';
    v_name_space_col_names3 := v_name_space_col_names3 || ' AND NVL(PTN.' || C.NAME ||','|| CASE C.ID WHEN 1 THEN '-1' WHEN 2 THEN 'CHR(0)' END || ') = NVL(RES.' || C.NAME ||','|| CASE C.ID WHEN 1 THEN '-1' WHEN 2 THEN 'CHR(0)' END || ')';
  END LOOP;

    -- move the data in a temp table(performance)

    EXECUTE IMMEDIATE 'DELETE TEMP_TABLE_ID_NAME';
    EXECUTE IMMEDIATE 'DELETE TEMP_TABLE_ID_NAME_BAD';

    EXECUTE IMMEDIATE 'INSERT INTO TEMP_TABLE_ID_NAME SELECT ID,NAME FROM TABLE(:pin_data)'
      USING pin_data;

    FOR i IN (SELECT ID, NAME FROM TABLE(pin_data)) LOOP

      execute immediate 'INSERT INTO TEMP_TABLE_ID_NAME_BAD
                   SELECT TTIN.ID,TTIN.NAME
                     FROM TEMP_TABLE_ID_NAME TTIN
                INNER JOIN ' || pin_table_name || ' PTN ON PTN.' || pin_id_col_name || '= TTIN.ID
                INNER JOIN ( SELECT DISTINCT ' || v_name_space_col_names2 || '"_NAME"
                 FROM ( SELECT ' || v_name_space_col_names2 || '"_NAME"
                      ,ROW_NUMBER() OVER (PARTITION BY ' || v_name_space_col_names2 ||'"_NAME" ORDER BY "_ID") DUPL
                    FROM (    SELECT PTN.' || pin_id_col_name || ' "_ID"
                            ,UPPER(NVL(TTIN.NAME,PTN.' || pin_name_col_name || ')) "_NAME"
                              ' || v_name_space_col_names1 || '
                           FROM ' || pin_table_name || ' PTN
                        LEFT JOIN TEMP_TABLE_ID_NAME TTIN ON PTN.' || pin_id_col_name || '= TTIN.ID)
                   )
                               WHERE DUPL > 1 ) RES ON UPPER(RES."_NAME")=UPPER(TTIN.NAME) ' || v_name_space_col_names3;

      l_count := sql%rowcount;

      IF l_count = 0 THEN
        EXIT;
      END IF;

      DELETE FROM TEMP_TABLE_ID_NAME
       WHERE (ID, NAME) IN (SELECT ID, NAME FROM TEMP_TABLE_ID_NAME_BAD);
    END LOOP;

    OPEN c_output FOR
      SELECT * FROM TEMP_TABLE_ID_NAME_BAD;
    RETURN c_output;
  END CHECK_UNIQUENESS;
-- ############################# CHECK_UNIQUENESS END #############################

-- ############################# CHECK_UNIQUENESS PIPE ROW START #############################
  FUNCTION CHECK_UNIQUENESS_COL(pin_table_name           IN VARCHAR2,
                                pin_name_col_name        IN VARCHAR2,
                                pin_id_col_name          IN VARCHAR2,
                                pin_name_space_col_names IN tabletype_id_name,
                                pin_data                 IN tabletype_id_name,
                            pin_table_ver_col_name   IN VARCHAR2 DEFAULT NULL)
    RETURN tabletype_id_name IS
    l_count                 INTEGER;
    v_name_space_col_names1 VARCHAR2(4000);
    v_name_space_col_names2 VARCHAR2(4000);
    v_name_space_col_names3 VARCHAR2(4000);
    v_ver_object_id      NUMBER(10);
    v_Ver_base_object_id NUMBER(10);
    l_collection            tabletype_id_name;
    l_collection_return     tabletype_id_name;
    l_ver_object_names      tabletype_dt_char;
    v_stamp            VARCHAR2(250);
BEGIN
    v_stamp := 'COMMONS_APPFRAMEWORK.CHECK_UNIQUENESS_COL - input - ' || TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_TABLE_NAME),    ',PIN_TABLE_NAME => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_NAME_COL_NAME),    ',PIN_NAME_COL_NAME => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_ID_COL_NAME),    ',PIN_ID_COL_NAME => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_NAME_SPACE_COL_NAMES),    ',PIN_NAME_SPACE_COL_NAMES => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_DATA),    ',PIN_DATA => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_table_ver_col_name),    ',pin_table_ver_col_name => <value>', v_stamp);
    END;

    l_collection_return := tabletype_id_name();

  FOR C IN (SELECT ID, NAME FROM TABLE(pin_name_space_col_names)) LOOP
    v_name_space_col_names1 := v_name_space_col_names1 || ',PTN.' || C.NAME;
    v_name_space_col_names2 := v_name_space_col_names2 || C.NAME ||',';
    v_name_space_col_names3 := v_name_space_col_names3 || ' AND NVL(PTN.' || C.NAME ||','|| CASE C.ID WHEN 1 THEN '-1' WHEN 2 THEN 'CHR(0)' END || ') = NVL(RES.' || C.NAME ||','|| CASE C.ID WHEN 1 THEN '-1' WHEN 2 THEN 'CHR(0)' END || ')';
  END LOOP;

    -- move the data in a temp table(performance)

    EXECUTE IMMEDIATE 'DELETE TEMP_TABLE_ID_NAME';
    EXECUTE IMMEDIATE 'DELETE TEMP_TABLE_ID_NAME_BAD';

    EXECUTE IMMEDIATE 'INSERT INTO TEMP_TABLE_ID_NAME SELECT ID,NAME FROM TABLE(:pin_data)'
      USING pin_data;

 IF (pin_table_ver_col_name IS NOT NULL) THEN
    -- add the ver column
    v_name_space_col_names1 := v_name_space_col_names1 || ',PTN.' || pin_table_ver_col_name;
    v_name_space_col_names2 := v_name_space_col_names2 || pin_table_ver_col_name ||',';
    v_name_space_col_names3 := v_name_space_col_names3 || ' AND NVL(PTN.' || pin_table_ver_col_name ||',-1) = NVL(RES.' || pin_table_ver_col_name ||',-1)';

    -- get the version id of the edited rows
        EXECUTE IMMEDIATE 'SELECT ' || pin_table_ver_col_name || ' FROM ' || pin_table_name || ' WHERE ' || pin_id_col_name || ' = (SELECT ID FROM TABLE(:pin_data) WHERE ROWNUM = 1)'
          INTO V_VER_OBJECT_ID
          USING pin_data;

    -- get the plan id of the edited rows
        EXECUTE IMMEDIATE 'SELECT VER_BASE_OBJECT_ID FROM VERSIONS WHERE VER_OBJECT_ID = ' || V_VER_OBJECT_ID
          INTO V_VER_BASE_OBJECT_ID;

    -- move the data in a temp table(performance)
        EXECUTE IMMEDIATE 'SELECT UPPER(INPUT_TABLE.' || pin_name_col_name ||
                          ') FROM TABLE(:pin_data) pin_data
                           INNER JOIN ' || pin_table_name || ' INPUT_TABLE
                           ON pin_data.id = INPUT_TABLE.' || pin_id_col_name
        BULK COLLECT INTO l_ver_object_names
        USING pin_data;

    FOR i IN (SELECT ID, NAME FROM TABLE(pin_data)) LOOP

      EXECUTE IMMEDIATE 'INSERT INTO TEMP_TABLE_ID_NAME_BAD
                   SELECT TTIN.ID,TTIN.NAME
                     FROM TEMP_TABLE_ID_NAME TTIN
                INNER JOIN ' || pin_table_name || ' PTN ON PTN.' || pin_id_col_name || '= TTIN.ID
                INNER JOIN ( SELECT DISTINCT ' || v_name_space_col_names2 || '"_NAME"
                 FROM ( SELECT ' || v_name_space_col_names2 || '"_NAME"
                      ,ROW_NUMBER() OVER (PARTITION BY ' || v_name_space_col_names2 ||'"_NAME" ORDER BY "_ID") DUPL
                    FROM (    SELECT PTN.' || pin_id_col_name || ' "_ID"
                            ,UPPER(NVL(TTIN.NAME,PTN.' || pin_name_col_name || ')) "_NAME"
                              ' || v_name_space_col_names1 || '
                           FROM ' || pin_table_name || ' PTN
                        LEFT JOIN TEMP_TABLE_ID_NAME TTIN ON PTN.' || pin_id_col_name || '= TTIN.ID)
                   )
                               WHERE DUPL > 1 ) RES ON UPPER(RES."_NAME")=UPPER(TTIN.NAME) ' || v_name_space_col_names3
                     || ' UNION
                          SELECT DISTINCT ID, INPUT_VER_COL.' || pin_name_col_name ||
                        ' FROM ' || pin_table_name || ' INPUT_VER_COL
                          INNER JOIN VERSIONS VER
                          ON INPUT_VER_COL.' || pin_table_ver_col_name || ' = VER.VER_OBJECT_ID
                          INNER JOIN TEMP_TABLE_ID_NAME
                          ON UPPER(INPUT_VER_COL.' || pin_name_col_name || ') = UPPER(NAME)
                          WHERE VER.VER_BASE_OBJECT_ID = ' || V_VER_BASE_OBJECT_ID ||
                         ' AND UPPER(INPUT_VER_COL.' || pin_name_col_name || ') NOT IN (select * from TABLE(:l_ver_objects_names))'
       USING l_ver_object_names;


      l_count := sql%ROWCOUNT;

      IF l_count = 0 THEN
        EXIT;
      END IF;

      execute immediate 'select objtype_id_name(ID, NAME) from TEMP_TABLE_ID_NAME_BAD'
                        bulk collect into l_collection;
      --l_collection_return := l_collection_return multiset union all l_collection;

      DELETE FROM TEMP_TABLE_ID_NAME
       WHERE (ID, NAME) IN (SELECT ID, NAME FROM TEMP_TABLE_ID_NAME_BAD);
    END LOOP;

ELSE

    FOR i IN (SELECT ID, NAME FROM TABLE(pin_data)) LOOP

      execute immediate 'INSERT INTO TEMP_TABLE_ID_NAME_BAD
                   SELECT TTIN.ID,TTIN.NAME
                     FROM TEMP_TABLE_ID_NAME TTIN
                INNER JOIN ' || pin_table_name || ' PTN ON PTN.' || pin_id_col_name || '= TTIN.ID
                INNER JOIN ( SELECT DISTINCT ' || v_name_space_col_names2 || '"_NAME"
                 FROM ( SELECT ' || v_name_space_col_names2 || '"_NAME"
                      ,ROW_NUMBER() OVER (PARTITION BY ' || v_name_space_col_names2 ||'"_NAME" ORDER BY "_ID") DUPL
                    FROM (    SELECT PTN.' || pin_id_col_name || ' "_ID"
                            ,UPPER(NVL(TTIN.NAME,PTN.' || pin_name_col_name || ')) "_NAME"
                              ' || v_name_space_col_names1 || '
                           FROM ' || pin_table_name || ' PTN
                        LEFT JOIN TEMP_TABLE_ID_NAME TTIN ON PTN.' || pin_id_col_name || '= TTIN.ID)
                   )
                               WHERE DUPL > 1 ) RES ON UPPER(RES."_NAME")=UPPER(TTIN.NAME) ' || v_name_space_col_names3;

      l_count := sql%rowcount;

      IF l_count = 0 THEN
        EXIT;
      END IF;

      execute immediate 'select objtype_id_name(ID, NAME) from TEMP_TABLE_ID_NAME_BAD' bulk collect into l_collection;
      --l_collection_return := l_collection_return multiset union all l_collection;

      DELETE FROM TEMP_TABLE_ID_NAME
       WHERE (ID, NAME) IN (SELECT ID, NAME FROM TEMP_TABLE_ID_NAME_BAD);
    END LOOP;
END IF;

    --return l_collection_return;
	return l_collection;

  END CHECK_UNIQUENESS_COL;

-- ############################# CHECK_UNIQUENESS PIPE ROW END #############################

-- ############################# GET_OBJECTS_BY_ID START #############################
/*  procedure GET_OBJECTS_BY_ID(PI_OR_IDS  IN varchar2,
                              PO_OBJECTS OUT sys_refcursor) AS

    v_sql clob;
  BEGIN
    if (PI_OR_IDS is null) then

      raise_application_error(-20000, 'PI_OR_ID cannot be null ');

    end if;

    v_sql := 'SELECT OR_ID,commons_appframework.GET_NAME(OR_NAME) as OR_NAME,OR_NAME as OR_NAME_UNRESOLVED,OR_TYPE,OR_CONTAINER_ID
      FROM OBJECT_REGISTRATION
     WHERE OR_ID in ('||PI_OR_IDS||')';
  --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
    OPEN PO_OBJECTS FOR v_sql;

  end;*/
  -- ############################# GET_OBJECTS_BY_ID END #############################



-- ############################# GET_OBJECTS_BY_ID START #############################
  procedure GET_OBJECTS_BY_ID(PI_OR_IDS  IN coltype_id,
                              PO_OBJECTS OUT sys_refcursor) AS

    v_sql clob;
  BEGIN
    if (PI_OR_IDS is null) then

      raise_application_error(-20000, 'PI_OR_ID cannot be null ');

    end if;

    v_sql := 'SELECT OR_ID, commons_appframework.GET_NAME(OR_NAME) as OR_NAME,OR_NAME as OR_NAME_UNRESOLVED,OR_TYPE,OR_CONTAINER_ID
          FROM OBJECT_REGISTRATION
     WHERE OR_ID in (SELECT * FROM TABLE(:1))';
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
    OPEN PO_OBJECTS FOR v_sql
      using PI_OR_IDS;

  end;
  -- ############################# GET_OBJECTS_BY_ID END #############################



-- ############################# GET_OBJECTS_BY_TYPE START #############################
  procedure GET_OBJECTS_BY_TYPE(PI_OR_TYPE IN NUMBER,
                                PO_OBJECTS OUT sys_refcursor) AS
    v_sql clob;
  BEGIN
    if (PI_OR_TYPE is null) then

      raise_application_error(-20000, 'PI_OR_TYPE cannot be null ');

    end if;
    v_sql := 'SELECT OR_ID,commons_appframework.GET_NAME(OR_NAME) as OR_NAME,OR_NAME as OR_NAME_UNRESOLVED,OR_TYPE,OR_CONTAINER_ID
      FROM OBJECT_REGISTRATION
     WHERE OR_TYPE = :1' ;

    OPEN PO_OBJECTS FOR v_sql using PI_OR_TYPE;

  end;
-- ############################# GET_OBJECTS_BY_TYPE END #############################


-- ############################# GET_OBJECTS_BY_UNRESOLVED_NAME START #############################
  procedure GET_OBJECTS_BY_UNRESOLVED_NAME(PI_OR_NAME IN VARCHAR2,
                                PO_OBJECTS OUT sys_refcursor) AS
    v_sql clob;
  BEGIN
    if (PI_OR_NAME is null) then

      raise_application_error(-20000, 'PI_OR_NAME cannot be null ');

    end if;
    v_sql := 'SELECT OR_ID,commons_appframework.GET_NAME(OR_NAME) as OR_NAME,OR_NAME as OR_NAME_UNRESOLVED,OR_TYPE,OR_CONTAINER_ID
      FROM OBJECT_REGISTRATION
     WHERE UPPER(OR_NAME) = UPPER(:1)';


    OPEN PO_OBJECTS FOR v_sql using PI_OR_NAME;

  end;
-- ############################# GET_OBJECTS_BY_UNRESOLVED_NAME END #############################

-- ############################# GET_NAME START #############################
FUNCTION GET_NAME(pi_name IN VARCHAR2) RETURN VARCHAR2

 IS
  v_return_string      clob;
  v_return_string_temp OBJECT_REGISTRATION.OR_NAME%type := pi_name;
  v_field_to_convert   varchar2(200);
  v_id_start           number(10);
  v_id_end             number(10);
  v_id_start_symbol    varchar2(2):='|~';
  v_id_end_symbol      varchar2(2):='~|';
  v_status             number(1):=1;
  v_return_value      OBJECT_REGISTRATION.OR_NAME%type;

BEGIN
  --iterate through the string
 WHILE v_return_string_temp is not null LOOP
 /*  if (v_status=0) then
    v_return_string:=null;
    exit;


  else
  */
    --search for the symbol
    v_id_start := instr(v_return_string_temp, v_id_start_symbol);
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_id_start),'v_id_start := <value>', null);
    --if the start symbol is not present then append the remaining string the result
    if (v_id_start = 0) then
      v_return_string := v_return_string || substr(v_return_string_temp, 1);

      exit;
    else
    --append string before the start symbol to result
      v_return_string := v_return_string ||
                         substr(v_return_string_temp, 1, v_id_start - 1);

    end if;
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_return_string),'v_return_string := <value>', null);
    --remove the characters before the start symbol to from the processing string
    v_return_string_temp := substr(v_return_string_temp, v_id_start);
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_return_string_temp),'v_return_string_temp := <value>', null);
    --reset the start position ideally 1
    v_id_start := instr(v_return_string_temp, v_id_start_symbol);
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_id_start),'v_id_start := <value>', null);
    --set teh end position
    v_id_end := instr(v_return_string_temp, v_id_end_symbol);
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_id_end),'v_id_end := <value>', null);
    --if the end symbol is not present then append the remaining string the result
    if (v_id_end = 0) then
      v_return_string := v_return_string || substr(v_return_string_temp, 1);

      exit;
    end if;
    --if all is well take out the object id
    v_field_to_convert := substr(v_return_string_temp,
                                 v_id_start + 2,
                                 v_id_end - v_id_start - 2);
    --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_field_to_convert),'v_field_to_convert := <value>', null);

    begin
      v_return_value:=null;
      --if all is well convert the object id into object name
      /*select OR_NAME into v_return_value
                from OBJECT_REGISTRATION
               where OR_ID = v_field_to_convert;*/

      execute immediate 'select OR_NAME
                           from OBJECT_REGISTRATION
                          where OR_ID = :1'  into v_return_value using v_field_to_convert;


    v_return_string:=  v_return_string || case when REGEXP_COUNT(v_return_value, '|~(.*)~|')>0 then
                           null
                           else v_return_value end   ;

    /* select v_return_string || case when REGEXP_COUNT(v_return_value, '|~(.*)~|')>0 then
                           null
                           else v_return_value end
        into v_return_string
        from dual;*/



      --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_return_string),'v_return_string := <value>', null);
    exception

   /* when NO_DATA_FOUND then
       v_return_string:= null;
       exit;*/
      --if all is not well pur teh exact same sting in the result
      when others then
   /*     select v_return_string || v_id_start_symbol || v_field_to_convert || v_id_end_symbol
          into v_return_string
          from dual;*/
          --L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'inside exception');
           v_return_string:= null;
           v_status:=0;

       exit;
        --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_return_string),'v_return_string := <value>', null);
    end;
    --reset the processing string
    -- change made here

/*    SELECT REGEXP_COUNT('IF |~66985~| < Hurdle', '|~(.*)~|') from dual;*/

    v_return_string_temp:= case when REGEXP_COUNT(v_return_value, '|~(.*)~|')>0 then
                           v_return_value
                           else null end ||substr(v_return_string_temp, v_id_end + 2);

   -- v_return_string_temp :=substr(v_return_string_temp, v_id_end + 2);

  /*select substr(v_return_string_temp, decode(v_id_end,0,1) + 2)
      into v_return_string_temp
      from dual;*/

  --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_return_string_temp),'v_return_string_temp := <value>', null);

/* end if; */
  END LOOP;

  --L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_return_string),'v_return_string := <value>', null);

  return v_return_string;
END;
-- ############################# GET_NAME END #############################

/*  FUNCTION GET_VALID_SCN
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:

  2012.12.04 - Andries, Adriana - created
  ========================================================*/
FUNCTION GET_VALID_SCN(PIN_TABLE_LIST IN VARCHAR2) RETURN NUMBER IS
  RESULT NUMBER;
  V_SCN  NUMBER;
  V_VALID_SCN  NUMBER := 0;
  V_SQL CLOB;


BEGIN

IF(trim(PIN_TABLE_LIST) IS NOT NULL) THEN
      LOOP
        EXIT WHEN V_VALID_SCN =1;

        -- get SCN
        SELECT DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER
        INTO  V_SCN
        FROM DUAL;
       --
       V_SQL := 'SELECT 1 FROM (SELECT 1 FROM '||TRIM(PIN_TABLE_LIST)||' where rownum<1) AS OF SCN ('||V_SCN||')';
        BEGIN

         EXECUTE IMMEDIATE V_SQL;
         V_VALID_SCN := 1;
         EXCEPTION WHEN OTHERS THEN
           IF SQLCODE = '-1466' THEN
            --dbmS_LOCK.SLEEP(0.6);
            continue;
           ELSE
              raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM||V_SQL);
           END IF;
        END;
      END LOOP;
ELSE

    SELECT DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER
      INTO  V_SCN
      FROM DUAL;
 END IF;

  RESULT := v_scn;
  RETURN (RESULT);

END GET_VALID_SCN;


 PROCEDURE VERSION_OVERLAP_CHECK(pi_TABLE_CLOB IN VARCHAR2,
                                  pi_KEY_FIELDS      IN CLOB,
                                  PI_effective_start IN VARCHAR2,
                                  PI_effective_end   IN VARCHAR2,
                                  PI_is_Period       IN number,
                                  po_OVERLAP_CHK_RES OUT NUMBER

                                  ) IS
  begin
    COMMONS_TABLES.COMMON_OVERLAP_CHECK(pi_TABLE           => 'versions',
                         pi_TABLE_CLOB      => pi_TABLE_CLOB,
                         pi_KEY_FIELDS      => pi_KEY_FIELDS,
                         PI_effective_start => PI_effective_start,
                         PI_effective_end   => PI_effective_end,
                         PI_is_Period       => PI_is_Period,
                         PI_ID_COLUMN       => 'VER_OBJECT_ID',
                         po_OVERLAP_CHK_RES => po_OVERLAP_CHK_RES);

  end VERSION_OVERLAP_CHECK;

  function get_nls_property(pi_property_name in varchar2) return varchar2 is
    v_default_value varchar2(160 char);
    v_propery_value varchar2(160 char);
  begin
    if upper(pi_property_name) = 'NLS_COMP' then
      v_default_value := 'LINGUISTIC';
    elsif upper(pi_property_name) = 'NLS_SORT' then
      v_default_value := 'BINARY_CI';
    end if;
    execute immediate 'select nvl(max(value),''' || v_default_value || ''') from NLS_PARAMETERS where PARAMETER = upper(''' || pi_property_name || ''')' into v_propery_value;
    return v_propery_value;
  end get_nls_property;

 function get_characterset_name return varchar2 is
    v_propery_value varchar2(160 char);
  begin
    execute immediate 'select max(VALUE) from NLS_DATABASE_PARAMETERS where PARAMETER=''NLS_CHARACTERSET''' into v_propery_value;
    return v_propery_value;

  end get_characterset_name;

/*  PROCEDURE get_role_objects_permissions
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:

  2014.02.24 - Andries, Adriana - created
  ========================================================*/
 procedure get_role_objects_permissions (pin_role_ids in TABLETYPE_NUMBER,
                                                          pin_feature_id in number,
                                                          pout_object_registration out sys_refcursor )   is
    feature_contained_object_type number(10);
  begin
    if pin_role_ids is not null then  -- open cursor when the role_ids variable is not null
        open pout_object_registration for
        with  role_objects_null_perm as -- get all applications when the permission is given for all the applications for that feature
        (select distinct or_id
         from role_objects
         join object_registration on ro_or_Type = or_type
         where ro_or_id is null
         and ro_rol_id in (select column_value from table(cast(pin_role_ids as TABLETYPE_NUMBER)))
         and ro_feature_id = pin_feature_id
         and ro_feature_id <> 143
         and ro_permission in (1,3)
         and or_container_id is null
        ),

        role_folders_all as     -- get all folders when the permission is given for all the folders in the feature)
       (select fol_id , fol_contained_obj_type_id from role_objects
        join folders on ro_or_type = fol_contained_obj_type_id
        where ro_or_id is null
        and ro_rol_id in (select column_value from table(cast(pin_role_ids as TABLETYPE_NUMBER)))
        and ro_feature_id = pin_feature_id
        and ro_feature_id <> 143
        and ro_permission in (1,3)
        union all
        select pf_id fol_id , 53  fol_contained_obj_type_id
        from role_objects, portal_folders
        where ro_or_id is null
        and ro_rol_id in (select column_value from table(cast(pin_role_ids as TABLETYPE_NUMBER)))
        and ro_feature_id = pin_feature_id
        and ro_feature_id = 139
        and ro_or_type = 60
        and ro_permission in (1,3)
        )
        ,
        --
        role_objects_all as        -- get all objects from role_objects when the folder id is specified
        (select ro_or_id , fol_contained_obj_type_id
        from role_objects
        left join folders on  fol_id = ro_or_id
        where ro_or_id is not null
        and ro_rol_id in (select column_value from table(cast(pin_role_ids as TABLETYPE_NUMBER)))
        and ro_feature_id = pin_feature_id
        and ro_feature_id <> 143
        and ro_permission in (1,3)
        union all
        select ro_or_id , 53 fol_contained_obj_type_id
        from role_objects
        left join portal_folders on  pf_id = ro_or_id
        where ro_or_id is not null
        and ro_rol_id in (select column_value from table(cast(pin_role_ids as TABLETYPE_NUMBER)))
        and ro_feature_id = pin_feature_id
        and ro_feature_id = 139
        and ro_permission in (1,3)),
        --
        role_obj_contained as    -- get all objects within folders for which the role has permissions
       (select or_id
        from object_registration
        join (select fol_id container_id, fol_contained_obj_type_id
              from role_folders_all
              union all
              select ro_or_id container_id, fol_contained_obj_type_id
              from role_objects_all
              where fol_contained_obj_type_id is not null)  on container_id = or_container_id and or_type = fol_contained_obj_type_id
       ),
         role_obj_union as
       (
         select ro_or_id from (select ro_or_id ro_or_id from role_objects_all
                               union all
                               select fol_id ro_or_id from role_folders_all
                               union all
                               select or_id ro_or_id from role_obj_contained
                               union all
                               select or_id ro_or_id from role_objects_null_perm)
       ),
       plans_roster_roles as
       (
        select or_id, get_name(or_name) or_name, or_type, or_container_id
        from tables
        join object_registration oreg on tables_id = or_id
        where tables_type = 'EARNINGS_ENTITY_TO_PLAN_ROSTER'
        and pin_feature_id = 143
        and exists (select 1
                    from role_objects
                    where ro_feature_id = 143
                    and ro_or_id is null)
       )
       select or_id,or_name,or_type, or_container_id
       from
       (select  or_id, or_name, or_type, case when pf_id is not null then pf_pa_id else or_container_id end or_container_id
       from object_registration oreg
       left join portal_folders on pf_id = or_id and pin_feature_id = 122
        where (or_id in (select ro_or_id from role_obj_union)
               or (or_type =28 and pin_feature_id = 130)
               )
        and not exists  (select 1
                           from ENTITIES e
                          where e.entity_id = or_id
                            and e.entity_base_entity is not null)
        union all
        select  distinct or_id, or_name, or_type, or_container_id
        from plans_roster_roles
        ) ;
    else   -- when no role is specified, get all objects for a certain feature
       select ft_contained_object_type    -- get the object type in the feature
       into feature_contained_object_type
       from features
       where ft_feature_id = pin_feature_id;

       open pout_object_registration for
       select distinct or_id, or_name, or_type, or_container_id   -- get the objects
       from object_Registration oreg
       where  (or_type =  feature_contained_object_type or (or_type = 28 and pin_feature_id = 130))
       and ((or_type <>4) or (or_Type = 4 and pin_feature_id = 111))
       and not exists  (select 1
                        from ENTITIES e
                        where e.entity_id = or_id
                          and e.entity_base_entity is not null)
       union all
       select distinct or_id, or_name, or_type, or_container_id  -- get the folders and the portal applications containing those objects
       from object_Registration oreg
       join folders on or_id = fol_id or or_id = fol_container_id
       where fol_contained_obj_type_id = feature_contained_object_type and (or_type <> 28 and pin_feature_id <> 130)
       and  pin_feature_id <> 143
       union all
       select distinct or_id, or_name, or_type, or_container_id  -- get the portal folders for the portal application
       from object_Registration oreg
       join portal_folders on or_id = pf_id
       where  pin_feature_id = 139
       union all
       select distinct or_id, or_name, or_type, or_container_id  -- get the portal views inside portal folders
       from object_Registration oreg
       join pv_portal_views on pvpv_id = or_id
       join portal_folders on or_container_id = pf_id
       where  pin_feature_id = 139
       union all
       select distinct or_id, get_name(or_name), or_type, or_container_id
       from tables
       join object_registration oreg on tables_id = or_id
       where tables_type = 'EARNINGS_ENTITY_TO_PLAN_ROSTER'
       and pin_feature_id=143;
    end if;
end get_role_objects_permissions;

/*  PROCEDURE SET_CONTEXT_VALUE
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:
  2015.01.28 - Andries, Adriana - created
  ========================================================*/
PROCEDURE SET_CONTEXT_VALUE
(    pi_pr_name     IN PROPERTIES.PR_NAME%TYPE
    ,pi_pr_value    IN PROPERTIES.PR_VALUE%TYPE
) IS
   	PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    UPDATE PROPERTIES
    SET PR_VALUE = pi_pr_value
    WHERE PR_NAME = pi_pr_name;

    DBA_UTILS.SET_CONTEXT_VALUE(p_attribute_name => pi_pr_name
                               ,p_value => pi_pr_value);
    COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
        L4O_LOGGING.LOG_MESSAGE(pi_log_level => L4O_LOGGING.LVL_ERROR
                               ,pi_message => 'Setting context value has failed.'
                               ,pi_error_code => SQLCODE
                               ,pi_error_message => SQLERRM);
		RAISE;
END SET_CONTEXT_VALUE;

/*  PROCEDURE GET_CONTEXT_VALUE
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:
  2015.01.28 - Andries, Adriana - created
  ========================================================*/
FUNCTION GET_CONTEXT_VALUE
(    pi_pr_name     IN PROPERTIES.PR_NAME%TYPE
) RETURN PROPERTIES.PR_VALUE%TYPE
IS
BEGIN
    RETURN DBA_UTILS.GET_CONTEXT_VALUE(p_attribute_name => pi_pr_name);
EXCEPTION
	WHEN OTHERS THEN
		RETURN NULL;
END GET_CONTEXT_VALUE;

  function get_row_identifier_sequence(pi_table_name in varchar2,
                                       pi_period_id  in number)
    return varchar2 as
    v_table_name varchar2(30);
  begin
    if pi_period_id is not null then
      v_table_name := regexp_replace(pi_table_name, '_PART_' || pi_period_id, '') || '_ROW_IDENTIFIER_SEQ';
    else
      v_table_name := regexp_replace(pi_table_name, '_PART_[0-9]+', '') || '_ROW_IDENTIFIER_SEQ';
    end if;
    return v_table_name;
  end get_row_identifier_sequence;

FUNCTION GET_TREF_ID(pi_pvv_id IN NUMBER) RETURN NUMBER

 IS

  v_tref_id           number(10);
BEGIN
 IF pi_pvv_id IS NULL THEN
   RETURN NULL;
 END IF;
 BEGIN
  SELECT extractValue(xmltype(od.od_Definition),'dataView/tableReferenceId')
  INTO   v_tref_id
  FROM   object_definitions od
  WHERE  od_container_id = pi_pvv_id;
 EXCEPTION WHEN NO_DATA_FOUND THEN RETURN NULL;
          WHEN OTHERS THEN RAISE;
 END;
RETURN v_tref_id;
END GET_TREF_ID;

/*  PROCEDURE CLEANUP_JOBS_COMPARE
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:
  2015.12.11 - Kristo, Robert - created
  ========================================================*/
PROCEDURE CLEANUP_JOBS_COMPARE
AS
   v_table_names             TABLETYPE_CHARMAX;
   c_offset                  CONSTANT VARCHAR2(1300) := '90';
BEGIN
   LOOP
     SELECT table_name
     bulk collect into v_table_names
   FROM
     (SELECT table_name
     FROM RUN_COMPARE
     WHERE run_date < SYSDATE - TO_NUMBER(c_offset))
   WHERE rownum <= 1000;

     exit when SQL%ROWCOUNT = 0;

     FOR i IN (SELECT * FROM TABLE(v_table_names))
     LOOP
       BEGIN
         DELETE FROM RUN_COMPARE

         WHERE table_name = i.column_value;

         EXECUTE IMMEDIATE 'DROP TABLE ' || i.column_value;
       EXCEPTION
         WHEN OTHERS THEN NULL;
       END;
     END LOOP;

   END LOOP;
END;


/* GET_TABLE_COLUMNS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_COLUMNS
(   pin_table_id IN NUMBER
) RETURN TABLETYPE_DT_MR_COL_PROPS
IS
    vtab_cols TABLETYPE_DT_MR_COL_PROPS;
BEGIN
    SELECT OBJTYPE_DT_MR_COL_PROPS
    (        TC1.TC_PHYSICAL_NAME
            ,TC1.TC_ORDER
            ,TC1.TC_COLUMN_TYPE
            ,TC1.TC_ENTITY_ID
            ,TABLES_PHYSICAL_NAME
            ,TC2.TC_PHYSICAL_NAME
            ,F2.FLD_DATA_TYPE
            ,TC1.TC_FLD_ID
            ,F1.FLD_DATA_TYPE
            ,F1.FLD_TIMEUNIT
            ,TC1.TC_IS_NULLABLE
            ,TC1.TC_DEF_TYPE_ID
    )
    BULK COLLECT INTO vtab_cols
    FROM    TABLE_COLUMNS               TC1
            LEFT JOIN FIELDS            F1 ON TC1.TC_FLD_ID = F1.FLD_ID
            LEFT JOIN ENTITIES          ON TC1.TC_ENTITY_ID = ENTITY_ID
            LEFT JOIN TABLES            ON ENTITY_TABLES_ID = TABLES_ID
            LEFT JOIN TABLE_COLUMNS     TC2 ON ENTITY_TABLES_ID = TC2.TC_TABLES_ID AND TC2.TC_LOGIC_TYPE in (1,5)
            LEFT JOIN FIELDS            F2 ON TC2.TC_FLD_ID = F2.FLD_ID
    WHERE   TC1.TC_TABLES_ID = pin_table_id;

    RETURN vtab_cols;
END GET_TABLE_COLUMNS;


/* GET_TABLE_NAME
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_NAME
(   pin_table_id IN NUMBER
) RETURN VARCHAR2
IS
    v_tab VARCHAR2(200);
BEGIN
    SELECT TABLES_PHYSICAL_NAME
    INTO v_tab
    FROM TABLES
    WHERE TABLES_ID = pin_table_id;

    RETURN v_tab;
END GET_TABLE_NAME;


/* GET_TABLE_ID_BY_REF
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    1. 2012.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_TABLE_ID_BY_REF
(   pin_table_ref_id IN NUMBER
) RETURN NUMBER
IS
    v_tab_id NUMBER;
BEGIN
    SELECT  T.TABLES_ID
    INTO    v_tab_id
    FROM    TABLE_REFERENCES TR
            LEFT JOIN
            (   SELECT   OBR.OR_ID
                        ,OBR.OR_NAME
                        ,CR.CR_PARENT_DEFINITION_ID
                FROM    OBJECT_REGISTRATION OBR
                        INNER JOIN CATEGORY_RELATIONSHIPS CR ON CR.CR_DEFINITION_ID = OBR.OR_ID
            ) ORC ON ORC.OR_NAME = TR.TREF_DEFINITION_NAME
                    AND ORC.CR_PARENT_DEFINITION_ID = TR.TREF_PARENT_DEFINITION_ID
            LEFT JOIN TABLES T ON NVL(T.TABLES_DEFINITION_ID,T.TABLES_ID) = NVL(TR.TREF_DEFINITION_ID,ORC.OR_ID)
    WHERE   TR.TREF_ID = pin_table_ref_id;

    RETURN v_tab_id;
END GET_TABLE_ID_BY_REF;


/* CREATE_MV_LOG_TABLE
-----------------------------------------------------------------------------------------------
History:
    1. 2016.11.02 - Kristo, Robert - created
    2. 2016.11.10 - Kristo, Robert - updated with commons_ddl_handling
-----------------------------------------------------------------------------------------------
*/
PROCEDURE CREATE_MV_LOG_TABLE(pin_table_name VARCHAR2,
                              pin_tx_id      VARCHAR2)
AS
BEGIN
  FOR i IN (SELECT 1 FROM user_mview_logs WHERE master = pin_table_name)
  LOOP
    EXECUTE IMMEDIATE 'DROP MATERIALIZED VIEW LOG ON ' || pin_table_name;
  END LOOP;

  COMMONS_DDL_HANDLING.execute_ddl(
              pi_transaction_id   => pin_tx_id,
              pi_description      => 'CREATE MATERIALIZED VIEW LOG FOR ' || pin_table_name,
              pi_ddl              => 'CREATE MATERIALIZED VIEW LOG ON ' || pin_table_name || '
                                            TABLESPACE ' || USER || '_DTS
                                            WITH PRIMARY KEY
                                            INCLUDING NEW VALUES',
              pi_undo_ddl         => 'BEGIN
                                      FOR i IN (SELECT 1 FROM user_mview_logs WHERE master = ''' || pin_table_name ||''')
                                      LOOP
                                        EXECUTE IMMEDIATE ''DROP MATERIALIZED VIEW LOG ON ' || pin_table_name || ''';
                                      END LOOP;
                                      END;');

END;


/* DROP_MV_LOG_TABLE
-----------------------------------------------------------------------------------------------
History:
    1. 2016.11.10 - Kristo, Robert - created
	2. 2017.02.10 - Luca, Iulian   - updated with commons_ddl_handling when given a transaction id
-----------------------------------------------------------------------------------------------
*/
PROCEDURE DROP_MV_LOG_TABLE(pin_table_name VARCHAR2,
							              pin_tx_id      VARCHAR2)
AS
BEGIN
  IF (pin_tx_id IS NULL)
  THEN
	  FOR i IN (SELECT 1 FROM user_mview_logs WHERE master = pin_table_name)
	  LOOP
		    EXECUTE IMMEDIATE 'DROP MATERIALIZED VIEW LOG ON ' || pin_table_name;
	  END LOOP;
  ELSE
	  COMMONS_DDL_HANDLING.execute_ddl(
				  pi_transaction_id   => pin_tx_id,
				  pi_description      => 'DROP MATERIALIZED VIEW LOG FOR ' || pin_table_name,
				  pi_ddl              => 'BEGIN
                                  FOR i IN (SELECT 1 FROM user_mview_logs WHERE master = ''' || pin_table_name ||''')
                                  LOOP
                                      EXECUTE IMMEDIATE ''DROP MATERIALIZED VIEW LOG ON ' || pin_table_name || ''';
                                  END LOOP;
                                  END;',
				  pi_undo_ddl         => 'CREATE MATERIALIZED VIEW LOG ON ' || pin_table_name || '
                                    TABLESPACE ' || USER || '_DTS
                                    WITH PRIMARY KEY
                                    INCLUDING NEW VALUES');
	END IF;
END;


/* GRANT_SELECT_ON_TABLE
-----------------------------------------------------------------------------------------------
History:
    1. 2016.11.02 - Kristo, Robert - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GRANT_SELECT_ON_TABLE(pin_table_name  VARCHAR2,
                                pin_schema_name VARCHAR2)
AS
BEGIN
  EXECUTE IMMEDIATE 'GRANT SELECT ON ' || pin_table_name || ' TO ' || pin_schema_name || ' WITH GRANT OPTION';
END;


/* CREATE_SYNONYM_FOR_PLA_TABLE
-- Author       : Dumitriu, Cosmin
-----------------------------------------------------------------------------------------------
-- History:
    1. 2016.11.25 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE CREATE_SYNONYM_FOR_PLA_TABLE
(    pin_table_name     VARCHAR2
    ,pin_tx_id          VARCHAR2 DEFAULT NULL
    ,pin_run_id         NUMBER DEFAULT NULL
) AS
    v_is_on_same_db         VARCHAR2(200 CHAR);
    v_pla_schema_name       VARCHAR2(200 CHAR);
    v_spm_to_pla_link_name  VARCHAR2(200 CHAR);
    v_ddl                   CLOB;
    v_undo_ddl              CLOB;
BEGIN
    SELECT PR_VALUE INTO v_is_on_same_db FROM PROPERTIES WHERE PR_NAME = 'SPM_PLA_ON_SAME_DB';
    SELECT PR_VALUE INTO v_pla_schema_name FROM PROPERTIES WHERE PR_NAME = 'PLA_NAME';
    SELECT PR_VALUE INTO v_spm_to_pla_link_name FROM PROPERTIES WHERE PR_NAME = 'SPM_TO_PLA_DB_LINK_NAME';

    IF (v_is_on_same_db = '1')
    THEN
        v_ddl := 'BEGIN '||v_pla_schema_name||'.COMMONS_APPFRAMEWORK.GRANT_SELECT_ON_TABLE
            (    pin_table_name  => '''||pin_table_name||'''
                ,pin_schema_name => '''||USER||'''
            );
            EXECUTE IMMEDIATE ''CREATE OR REPLACE SYNONYM '||pin_table_name||' FOR '||v_pla_schema_name||'.'||pin_table_name||''';
            END;';
    ELSE
        v_ddl := 'CREATE OR REPLACE SYNONYM '||pin_table_name||' FOR '||pin_table_name||'@'||v_spm_to_pla_link_name;
    END IF;

    v_undo_ddl := 'BEGIN FOR C IN (SELECT SYNONYM_NAME FROM USER_SYNONYMS WHERE UPPER(SYNONYM_NAME) = '''||pin_table_name||''')
        LOOP EXECUTE IMMEDIATE ''DROP SYNONYM ''||C.SYNONYM_NAME;
        END LOOP;
        END;';

    IF (pin_tx_id IS NOT NULL OR pin_run_id IS NOT NULL)
    THEN
        COMMONS_DDL_HANDLING.EXECUTE_DDL
        (   pi_transaction_id   => pin_tx_id,
            pi_run_id           => pin_run_id,
            pi_description      => 'CREATE SYNONYM FOR PLA TABLE ' || pin_table_name,
            pi_ddl              => v_ddl,
            pi_undo_ddl         => v_undo_ddl
        );
    ELSE
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => v_ddl);
    END IF;
END CREATE_SYNONYM_FOR_PLA_TABLE;


/* DROP_SYNONYM_FOR_PLA_TABLE
-- Author       : Dumitriu, Cosmin
-----------------------------------------------------------------------------------------------
-- History:
    1. 2016.11.25 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE DROP_SYNONYM_FOR_PLA_TABLE
(    pin_table_name     VARCHAR2
    ,pin_tx_id          VARCHAR2 DEFAULT NULL
    ,pin_run_id         NUMBER DEFAULT NULL
) AS
    v_is_on_same_db         VARCHAR2(200 CHAR);
    v_pla_schema_name       VARCHAR2(200 CHAR);
    v_spm_to_pla_link_name  VARCHAR2(200 CHAR);
    v_ddl                   CLOB;
    v_undo_ddl              CLOB;
BEGIN
    SELECT PR_VALUE INTO v_is_on_same_db FROM PROPERTIES WHERE PR_NAME = 'SPM_PLA_ON_SAME_DB';
    SELECT PR_VALUE INTO v_pla_schema_name FROM PROPERTIES WHERE PR_NAME = 'PLA_NAME';
    SELECT PR_VALUE INTO v_spm_to_pla_link_name FROM PROPERTIES WHERE PR_NAME = 'SPM_TO_PLA_DB_LINK_NAME';

    v_ddl := 'BEGIN FOR C IN (SELECT SYNONYM_NAME FROM USER_SYNONYMS WHERE UPPER(SYNONYM_NAME) = '''||pin_table_name||''')
        LOOP EXECUTE IMMEDIATE ''DROP SYNONYM ''||C.SYNONYM_NAME;
        END LOOP;
        END;';

    IF (v_is_on_same_db = '1')
    THEN
        v_undo_ddl := 'BEGIN '||v_pla_schema_name||'.COMMONS_APPFRAMEWORK.GRANT_SELECT_ON_TABLE
            (    pin_table_name  => '''||pin_table_name||'''
                ,pin_schema_name => '''||USER||'''
            );
            EXECUTE IMMEDIATE ''CREATE OR REPLACE SYNONYM '||pin_table_name||' FOR '||v_pla_schema_name||'.'||pin_table_name||''';
            END;';
    ELSE
        v_undo_ddl := 'CREATE OR REPLACE SYNONYM '||pin_table_name||' FOR '||pin_table_name||'@'||v_spm_to_pla_link_name;
    END IF;

    IF (pin_tx_id IS NOT NULL OR pin_run_id IS NOT NULL)
    THEN
        COMMONS_DDL_HANDLING.EXECUTE_DDL
        (   pi_transaction_id   => pin_tx_id,
            pi_run_id           => pin_run_id,
            pi_description      => 'DROP SYNONYM FOR PLA TABLE ' || pin_table_name,
            pi_ddl              => v_ddl,
            pi_undo_ddl         => v_undo_ddl
        );
    ELSE
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => v_ddl);
    END IF;
END DROP_SYNONYM_FOR_PLA_TABLE;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END commons_appframework;
/
