CREATE package body agreements as

  procedure display_agreements(pi_agreement_type in number,
                               pi_user_id        in number,
                               pi_object_id      in number,
                               po_agreements    out sys_refcursor) is
    l_reports_clause clob;
    l_no_reports_clause clob;
    l_agreements_clause clob;
    l_nls_sort varchar2(100);
    v_stamp						VARCHAR2(200);
  begin
    v_stamp := 'agreements.display_agreements - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_agreement_type) ,'pi_agreement_type := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_user_id) ,'pi_user_id := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_object_id) ,'pi_object_id := <value>', v_stamp);

    -- get nlssort
    l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
    -- use dynamic sql in order to allow joins with report tables
    for c in (select distinct aa_id, aa_name, rep_lists_id, rep_lists_name, nvl2(aa_attachment_rl_id,rep_lists_tables_id,null) rep_lists_tables_id
                from acceptance_agreements aa
                join role_objects ro
                  on aa.aa_id = ro.ro_or_id
                join report_lists rl
                  on aa.aa_attachment_rl_id = rl.rep_lists_id
               where aa.aa_type = pi_agreement_type
                 and ro_rol_id in (select ur_role_id from user_roles where ur_user_id = pi_user_id)) loop
      if c.rep_lists_tables_id is not null then
        -- add the reports for the agreements with attachments
        -- the join with dual ensures that when the report list is empty we return the agreement and when the report list contains reports we return all the reports
        l_reports_clause := l_reports_clause || ' union all
                                                  select aa_id, aa_name, rep_lists_id, rep_lists_name, rep_lists_tables_id, report_name, row_identifier
                                                    from x
                                                    join (select ' || to_char(c.rep_lists_tables_id) || ' id,
                                                                 row_identifier,
                                                                 report_name
                                                            from dual
                                                            left join T' || to_char(c.rep_lists_tables_id) || '
                                                              on 1 = 1)
                                                      on rep_lists_tables_id = id';
      end if;
    end loop;
    -- for login display all the agreements that have at least one report that wasn't accepted by the user
    if pi_agreement_type = 1 then
      -- add the agreements without attachments
      l_no_reports_clause := 'select distinct aa_id, aa_name, null rep_lists_id, null rep_lists_name, null rep_lists_tables_id, null report_name, null row_identifier
                                from acceptance_agreements aa
                                join role_objects ro
                                  on aa.aa_id = ro.ro_or_id
                               where aa.aa_type = ' || to_char(pi_agreement_type) || '
                                 and aa.aa_attachment_rl_id is null
                                 and ro_rol_id in (select ur_role_id from user_roles where ur_user_id = ' || to_char(pi_user_id) || ')';
      if l_reports_clause is null then
        l_reports_clause := l_reports_clause || l_no_reports_clause;
      else
        l_reports_clause := substr(l_reports_clause,11) || '
                            union all ' || l_no_reports_clause;
      end if;
      -- add the agreements with attachments
      l_agreements_clause := 'with x as
                               (select distinct aa_id, aa_name, rep_lists_id, rep_lists_name, rep_lists_tables_id
                                  from acceptance_agreements aa
                                  join role_objects ro
                                    on aa.aa_id = ro.ro_or_id
                                  join report_lists rl
                                    on aa.aa_attachment_rl_id = rl.rep_lists_id
                                 where aa.aa_type = ' || to_char(pi_agreement_type) || '
                                   and ro_rol_id in (select ur_role_id from user_roles where ur_user_id = ' || to_char(pi_user_id) || '))
                              select distinct aa_id, aa_name, NLSSORT(aa_name,''nls_sort='''''||l_nls_sort||''''''') as x
                                from (' || l_reports_clause || ') y
                               where not exists (select 1
                                                   from accepted_agreements a
                                                  where user_id = ' || to_char(pi_user_id) || '
                                                    and nvl(a.attachment_table_id,0) = nvl(y.rep_lists_tables_id,0)
                                                    and nvl(a.attachment_report_id,0) = nvl(y.row_identifier,0)
                                                    and a.acceptance_aa_id = y.aa_id)
                               order by x';

    -- for views display all the agreements that have at least one view that wasn't accepted by the user
    -- for report lists display all the agreements that have at least one view that wasn't accepted by the user
    elsif pi_agreement_type in (2,3) then
      -- add the agreements without attachments
      l_no_reports_clause := 'select distinct aa_id, aa_name, null rep_lists_id, null rep_lists_name, null rep_lists_tables_id, null report_name, null row_identifier
                                from acceptance_agreements aa
                                join role_objects ro
                                  on aa.aa_id = ro.ro_or_id
                                join acceptance_agreements_objects ao
                                  on aa.aa_id = ao.aao_aa_id
                               where aa.aa_type = ' || to_char(pi_agreement_type) || '
                                 and aa.aa_attachment_rl_id is null
                                 and aao_obj_id = ' || pi_object_id || '
                                 and ro_rol_id in (select ur_role_id from user_roles where ur_user_id = ' || to_char(pi_user_id) || ')';
      if l_reports_clause is null then
        l_reports_clause := l_reports_clause || l_no_reports_clause;
      else
        l_reports_clause := substr(l_reports_clause,11) || '
                            union all ' || l_no_reports_clause;
      end if;
      -- add the agreements with attachments
      l_agreements_clause := 'with x as
                               (select distinct aa_id, aa_name, rep_lists_id, rep_lists_name, rep_lists_tables_id
                                  from acceptance_agreements aa
                                  join role_objects ro
                                    on aa.aa_id = ro.ro_or_id
                                  join acceptance_agreements_objects ao
                                    on aa.aa_id = ao.aao_aa_id
                                  join report_lists rl
                                    on aa.aa_attachment_rl_id = rl.rep_lists_id
                                 where aa.aa_type = ' || to_char(pi_agreement_type) || '
                                   and aao_obj_id = ' || pi_object_id || '
                                   and ro_rol_id in (select ur_role_id from user_roles where ur_user_id = ' || to_char(pi_user_id) || '))
                              select distinct aa_id, aa_name, NLSSORT(aa_name,''nls_sort='''''||l_nls_sort||''''''') as x
                                from (' || l_reports_clause || ') y
                               where not exists (select 1
                                                   from accepted_agreements a
                                                  where user_id = ' || to_char(pi_user_id) || '
                                                    and nvl(a.attachment_table_id,0) = nvl(y.rep_lists_tables_id,0)
                                                    and nvl(a.attachment_report_id,0) = nvl(y.row_identifier,0)
                                                    and a.acceptance_aa_id = y.aa_id)
                               order by x';
    end if;
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(l_agreements_clause) ,'l_agreements_clause := <value>', v_stamp);
    open po_agreements for l_agreements_clause;
  end display_agreements;

  procedure filter_agreements(pi_agreements  in TABLETYPE_ID_CONDITION,
                              pi_report_id   in number,
                              po_agreements out sys_refcursor) is
    l_agreements_clause clob;
    l_nls_sort varchar2(100);
    v_stamp						VARCHAR2(200);
  begin
    v_stamp := 'agreements.filter_agreements - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_agreements) ,'pi_agreements := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_report_id) ,'pi_report_id := <value>', v_stamp);

    -- get nlssort
    l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
    -- use dynamic sql in order to allow joins with report tables
    for c in (select aa_id, rep_lists_tables_id, condition, report_list_entity_condition, user_entity_condition, period_join_clause
                from acceptance_agreements aa
                join acceptance_agreements_objects ao
                  on aa.aa_id = ao.aao_aa_id
                join report_lists rl
                  on ao.aao_obj_id = rl.rep_lists_id
                join (select id, condition, report_list_entity_condition, user_entity_condition, period_join_clause from table(pi_agreements))
                  on aa.aa_id = id
              ) loop
      -- use union because we can have two agreements linked to the same report list and we can filter only one of them
      l_agreements_clause := l_agreements_clause || ' union
                             select distinct aa_id, aa_name, NLSSORT(aa_name,''nls_sort='''''||l_nls_sort||''''''') as x
                               from acceptance_agreements aa
                               join acceptance_agreements_objects ao
                                 on aa.aa_id = ao.aao_aa_id
                               join report_lists rl
                                 on ao.aao_obj_id = rl.rep_lists_id' || case when c.condition is not null then '
                               join (select ' || to_char(c.rep_lists_tables_id) || ' id, t.* from dual left join T' || to_char(c.rep_lists_tables_id) || ' t on 1 = 1 where row_identifier = ' || pi_report_id || ') reportTable' || to_char(c.aa_id) || '
                                 on rep_lists_tables_id = reportTable' || to_char(c.aa_id) || '.id' end || case when c.report_list_entity_condition is not null then
                              c.report_list_entity_condition end || case when c.user_entity_condition is not null then '
                              cross join ' || c.user_entity_condition end || case when c.period_join_clause is not null then c.period_join_clause end || '
                              where aa.aa_id = ' || to_char(c.aa_id) || case when c.condition is not null then '
                                and (reportTable' || to_char(c.aa_id) || '.row_identifier is not null)
                                and ' || c.condition end;
    end loop;
    if l_agreements_clause is not null then
      l_agreements_clause := ltrim(l_agreements_clause,'union ') || ' order by x';
    else
      l_agreements_clause := 'select 1 aa_id, ''x'' aa_name from dual where 0 = 1';
    end if;
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(l_agreements_clause) ,'l_agreements_clause := <value>', v_stamp);
    open po_agreements for l_agreements_clause;
  end filter_agreements;

  procedure filter_attachments(pi_agreement_id            in number,
                               pi_user_id                 in number,
                               pi_report_list_id          in number,
                               pi_report_id               in number,
                               pi_filter_condition        in clob,
                               pi_user_entity_condition   in clob,
                               pi_report_entity_condition in clob,
                               pi_attachment_date_filter  in date,
                               pi_period_range_id_filter  in number,
                               pi_current_login_filter    in number,
                               pi_current_login_date      in date,
                               pi_effective_field_filter  in number,
                               pi_ass_hierarchy_condition in clob,
                               po_reports                 out sys_refcursor) is
    l_check_clause clob;
    l_reports_clause clob;
    l_clause clob;
    l_report_list_table_clause clob;
    l_report_list_table varchar2(30);
    l_report_period_field_clause clob;
    l_report_period_field varchar2(30);
    l_effective_field_table_clause clob;
    l_effective_field_table varchar2(30);
    l_effective_field_date_clause clob;
    l_effective_field_date date;
    l_effective_table_tu_clause clob;
    l_effective_table_tu number(10);
    l_effective_table_tu_field varchar2(30);
    l_report_list_table_tu_clause clob;
    l_report_list_table_tu number(10);
    l_report_list_table_tu_field varchar2(30);
    l_effective_field_corr number(1);
    l_correspondence_clause clob;
    type r_type is record(row_identifier number, report_name varchar2(250 char), physical_file_name varchar2(250 char), x varchar2(1300 char));
    l_rec r_type;
    l_check_reports sys_refcursor;
    l_reports sys_refcursor;
    l_nls_sort varchar2(100);
    invalid_identifier exception;
    pragma exception_init(invalid_identifier,-904);
    v_stamp						VARCHAR2(200);
  begin
    v_stamp := 'agreements.filter_attachments - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_agreement_id) ,'pi_agreement_id := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_user_id) ,'pi_user_id := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_report_list_id) ,'pi_report_list_id := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_report_id) ,'pi_report_id := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_filter_condition) ,'pi_filter_condition := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_user_entity_condition) ,'pi_user_entity_condition := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_report_entity_condition) ,'pi_report_entity_condition := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertDate(pi_attachment_date_filter) ,'pi_attachment_date_filter := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_range_id_filter) ,'pi_period_range_id_filter := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_current_login_filter) ,'pi_current_login_filter := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertDate(pi_current_login_date) ,'pi_current_login_date := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_effective_field_filter) ,'pi_effective_field_filter := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_ass_hierarchy_condition) ,'pi_ass_hierarchy_condition := <value>', v_stamp);

    -- get nlssort
    l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
    -- get report table
    l_report_list_table_clause :=  'select tbl.tables_physical_name
                                      from acceptance_agreements aa
                                      join report_lists rl
                                        on aa.aa_attachment_rl_id = rl.rep_lists_id
                                      join tables tbl
                                        on rl.rep_lists_tables_id = tbl.tables_id
                                     where aa.aa_id = ' || pi_agreement_id;
    execute immediate l_report_list_table_clause into l_report_list_table;
    -- get period field in report table if needed
    if pi_period_range_id_filter is not null or pi_current_login_filter = 2 then
      BEGIN
        l_report_period_field_clause :=  'select fld_column_name
                                          from acceptance_agreements
                                          join report_lists on aa_attachment_rl_id = rep_lists_id
                                          join tables on rep_Lists_tables_id = tables_id
                                          join table_columns on tables_id = tc_tables_id
                                          join fields on tc_fld_id = fld_id
                                         where fld_data_type = 8
                                           and aa_id = ' || pi_agreement_id;
        execute immediate l_report_period_field_clause into l_report_period_field;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20004,'The report list table does not contain a period field.');
      END;
    end if;
    -- get effective field date filter if needed
    if pi_report_list_id is not null and pi_report_id is not null then
      l_effective_field_table_clause :=  'select tbl.tables_physical_name
                                            from report_lists rl
                                            join tables tbl
                                              on rl.rep_lists_tables_id = tbl.tables_id
                                           where rl.rep_lists_id = ' || pi_report_list_id;
      execute immediate l_effective_field_table_clause into l_effective_field_table;
      if pi_effective_field_filter = 1 then
        l_effective_field_date_clause := 'select syndate from ' || l_effective_field_table || ' where row_identifier = ' || pi_report_id;
        execute immediate l_effective_field_date_clause into l_effective_field_date;
      end if;
      if pi_effective_field_filter = 2 then
        -- get the timeunit of the attachment report table
        l_effective_table_tu_clause := 'select fld_timeunit, tc_physical_name
                                          from tables
                                          join table_columns on tables_id = tc_tables_id
                                          join fields on tc_fld_id = fld_id
                                         where tables_physical_name = ''' || l_effective_field_table || '''
                                           and fld_data_type = 8
                                           and fld_timeunit is not null';
        execute immediate l_effective_table_tu_clause into l_effective_table_tu, l_effective_table_tu_field;
        -- get the timeunit of the accessed report table
        l_report_list_table_tu_clause := 'select fld_timeunit, tc_physical_name
                                            from tables
                                            join table_columns on tables_id = tc_tables_id
                                            join fields on tc_fld_id = fld_id
                                           where tables_physical_name = ''' || l_report_list_table || '''
                                             and fld_data_type = 8
                                             and fld_timeunit is not null';
        execute immediate l_report_list_table_tu_clause into l_report_list_table_tu, l_report_list_table_tu_field;
        -- if the timeunits are identical compare them without correspondence
        if l_effective_table_tu = l_report_list_table_tu then
          l_effective_field_corr := 0;
        else
          l_effective_field_corr := 1;
          l_correspondence_clause := 'with x as (select tupr_tp.tupr_id a, tupr_tpc.tupr_id b
                                                   from tu_correspondence
                                                   join tu_periods_correspondence on tuc_id = tupc_tuc_id
                                                   join tu_periods_range tupr_tp on tuc_tu_id = tupr_tp.tupr_tu_id and ((tupc_correspondence_type = 1 and tupc_tup_id = tupr_tp.tupr_tup_id) or (tupc_correspondence_type <> 1 and tupc_period_number = tupr_tp.tupr_period_number))
                                                   join tu_periods_range tupr_tpc on tuc_tu_id_corr = tupr_tpc.tupr_tu_id and ((tupc_correspondence_type = 1 and tupc_tup_id_corr = tupr_tpc.tupr_tup_id) or (tupc_correspondence_type <> 1 and tupc_period_number_corr = tupr_tpc.tupr_period_number)) and case when tupc_year_offset = 1 then tupr_tp.tupr_year - 1 when tupc_year_offset = 2 then tupr_tp.tupr_year when tupc_year_offset = 3 then tupr_tp.tupr_year + 1 else null end = tupr_tpc.tupr_year
                                                  where tuc_tu_id = ' || l_report_list_table_tu || ' and tuc_tu_id_corr = ' || l_effective_table_tu || ') ';
        end if;
      end if;
    end if;

     l_clause := ' select ATTACHMENTTABLE.row_identifier REPORT_ID, ATTACHMENTTABLE.report_name REPORT_NAME, ATTACHMENTTABLE.physical_file_name PHYSICAL_FILE_NAME, NLSSORT(ATTACHMENTTABLE.report_name,''nls_sort='''''||l_nls_sort||''''''') as x
                      from acceptance_agreements aa
                      join role_objects ro
                        on aa.aa_id = ro.ro_or_id
                      join report_lists rl
                        on aa.aa_attachment_rl_id = rl.rep_lists_id
                     cross join ' || l_report_list_table || ' ATTACHMENTTABLE' ||
                      case when pi_user_entity_condition is not null then ' cross join ' || pi_user_entity_condition end ||
                      case when pi_report_list_id is not null and pi_report_id is not null then ' cross join (select * from ' || l_effective_field_table || ' where row_identifier = ' || pi_report_id || ') ACCESSEDTABLE' end ||
                      case when pi_report_entity_condition is not null then pi_report_entity_condition end || '
                     where aa.aa_id = ' || pi_agreement_id || '
                       and ro_rol_id in (select ur_role_id from user_roles where ur_user_id = ' || pi_user_id || ')' ||
                      case when pi_filter_condition is not null then ' and ' || pi_filter_condition end ||
                      case when pi_attachment_date_filter is not null then ' and ATTACHMENTTABLE.syndate = ''' || pi_attachment_date_filter || '''' end ||
                      case when pi_period_range_id_filter is not null then ' and ATTACHMENTTABLE.' || l_report_period_field || ' = ' || pi_period_range_id_filter end ||
                      case when pi_current_login_filter = 1 then ' and ATTACHMENTTABLE.syndate = ''' || pi_current_login_date || '''' end ||
                      case when pi_current_login_filter = 2 then ' and ''' || pi_current_login_date || ''' between (select TUPR_START_DATE from tu_periods_range where tupr_id = ATTACHMENTTABLE.' || l_report_period_field || ') and (select TUPR_END_DATE from tu_periods_range where tupr_id = ATTACHMENTTABLE.' || l_report_period_field || ')' end ||
                      case when pi_effective_field_filter = 1 and pi_report_list_id is not null and pi_report_id is not null then ' and ATTACHMENTTABLE.syndate = ''' || l_effective_field_date || '''' end ||
                      case when pi_effective_field_filter = 2 and pi_report_list_id is not null and pi_report_id is not null and l_effective_field_corr = 0 then ' and ATTACHMENTTABLE.' || l_report_list_table_tu_field || ' = ACCESSEDTABLE.' || l_effective_table_tu_field end ||
                      case when pi_effective_field_filter = 2 and pi_report_list_id is not null and pi_report_id is not null and l_effective_field_corr = 1 then ' and (ATTACHMENTTABLE.' || l_report_list_table_tu_field || ', ACCESSEDTABLE.' || l_effective_table_tu_field || ') in (select a, b from x)' end ||
                      case when pi_ass_hierarchy_condition is not null then ' and ATTACHMENTTABLE.row_identifier in ( ' || pi_ass_hierarchy_condition || ' ) ' end;

     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(l_clause) ,'l_clause := <value>', v_stamp);

     -- build check clause
     l_check_clause := case when pi_effective_field_filter = 2 and pi_report_list_id is not null and pi_report_id is not null and l_effective_field_corr = 1 then l_correspondence_clause  end
                       || l_clause;

     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(l_check_clause) ,'l_check_clause := <value>', v_stamp);

    -- build final clause
    l_reports_clause :=
    case when pi_effective_field_filter = 2 and pi_report_list_id is not null and pi_report_id is not null and l_effective_field_corr = 1 then l_correspondence_clause || ' , res1 AS ( ' else ' WITH res1 AS ( ' end
         || l_clause
         || '
                       and not exists (select 1
                                         from accepted_agreements a
                                        where user_id = ' || pi_user_id || '
                                          and nvl(a.attachment_table_id, 0) = nvl(rl.rep_lists_tables_id, 0)
                                          and nvl(a.attachment_report_id, 0) = nvl(ATTACHMENTTABLE.row_identifier, 0)
                                          and a.acceptance_aa_id = aa.aa_id)
                     order by x';

	l_reports_clause :=  l_reports_clause || ')
        SELECT  distinct REPORT_ID, REPORT_NAME,PHYSICAL_FILE_NAME, X
        FROM   res1 ORDER BY X';

     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(l_reports_clause) ,'l_reports_clause := <value>', v_stamp);

    begin
      open l_reports for l_reports_clause;
    exception
      when invalid_identifier then
        raise_application_error(-20005,'The definition of the agreement is invalid');
    end;
    fetch l_reports into l_rec;
    if (l_reports%notfound) then
      -- if the sp returns nothing then test if this happens because either all the attachments were accepted or because of the filter
      open l_check_reports for l_check_clause;
      fetch l_check_reports into l_rec;
      if (l_check_reports%notfound) then
        -- throw exception if there are no possible reports to display as attachments for a user based on the acceptance agreement definition
        raise_application_error(-20002,'The filter returns no attachment');
      else
        raise_application_error(-20003,'All the attachments were already accepted');
      end if;
    end if;
    close l_reports;
    open po_reports for l_reports_clause;
  end filter_attachments;

end agreements;
/
