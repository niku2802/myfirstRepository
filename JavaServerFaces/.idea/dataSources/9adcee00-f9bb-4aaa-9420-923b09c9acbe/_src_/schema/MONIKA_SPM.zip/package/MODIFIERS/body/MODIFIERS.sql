CREATE PACKAGE BODY MODIFIERS AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type      : SPM
  -- Product            : compensation
  -- Module             : compensation-processing
  -- Requester          : Homeuca, Victor
  -- Authors            : Popescu, Mircea;
  -- Create date        : 20110916
  -- Reviewer           :
  -- Review date        :
  -- Description        : package used to handle all operations for modifiers processing
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  CON_START_DATE           CONSTANT VARCHAR2(12) :=  '''01/01/1900''';
  CON_END_DATE             CONSTANT VARCHAR2(12) :=  '''12/31/9999''';
  CON_DATE_FORMAT          CONSTANT VARCHAR2(12) :=  '''mm/dd/yyyy''';
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

  PROCEDURE INSERT_METRIC_INPUTS (
                                   pin_metricInputTable           in      varchar2           default null
                                  ,pin_metricInputSequence        in      varchar2           default null
                                  ,pin_thresholdInputFields       in      tabletype_name_map default null
                                  ,pin_thresholdFilterFields      in      tabletype_name_map default null
                                  ,pin_thresholdConstants         in      tabletype_name_map default null
                                  ,pin_lookupFilterFields         in      tabletype_name_map default null
                                  ,pin_lookupInputFields          in      tabletype_name_map default null
                                  ,pin_lookupConstants            in      tabletype_name_map default null
                                 )
  IS
    v_stamp              varchar2(250);
    v_metricInputTable   varchar2(30);
    v_input_type         varchar2(250);
    v_modifier_name      varchar2(250);
    v_input_category     varchar2(250);
    v_input_category_def varchar2(250);
    v_input_name         varchar2(250);
    v_sql                clob;
    BEGIN
      v_stamp := 'MODIFIERS.INSERT_METRIC_INPUTS - input - '|| TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
      BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metricInputTable),        ',pin_metricInputTable      => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metricInputSequence),     ',pin_metricInputSequence      => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdInputFields),  ',pin_thresholdInputFields  => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdFilterFields), ',pin_thresholdFilterFields  => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdConstants),    ',pin_thresholdConstants    => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupFilterFields),    ',pin_lookupFilterFields    => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupInputFields),     ',pin_lookupInputFields     => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupConstants),       ',pin_lookupConstants       => <value>', v_stamp);
      END;

  END;

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

  FUNCTION FIELD_PREC_AND_SCALE(pin_precision IN NUMBER)
   RETURN VARCHAR2
  IS
    v_return_value VARCHAR2(10);
  BEGIN
    SELECT '('||TO_CHAR(pin_precision+(SELECT TO_NUMBER(PR_VALUE) FROM PROPERTIES WHERE PR_NAME='INTEGER_PART_LENGTH'))||','||pin_precision||')'
      INTO v_return_value
      FROM dual;
     RETURN v_return_value;
  END;

  FUNCTION GET_PRECISION_AND_SCALE(pin_field_name       VARCHAR2,
                                   pin_lookup_precision NUMBER) RETURN VARCHAR2 AS
    v_precision_and_scale VARCHAR2(30);
  BEGIN
    CASE WHEN pin_lookup_precision IS NULL THEN
      v_precision_and_scale := COMMONS.FIELD_PRECISION_AND_SCALE(pin_field_name);
    WHEN REGEXP_SUBSTR(COMMONS.FIELD_PRECISION_AND_SCALE(pin_field_name),'[0-9]+', 1, 2) <= REGEXP_SUBSTR(COMMONS.FIELD_SCALE(pin_field_name, pin_lookup_precision),'[0-9]+', 1, 2) THEN
      v_precision_and_scale := COMMONS.FIELD_PRECISION_AND_SCALE(pin_field_name);
    ELSE
      v_precision_and_scale := COMMONS.FIELD_SCALE(pin_field_name, pin_lookup_precision);
    END CASE;
    -- return the smallest precision between the calculation field and lookup precision
    RETURN v_precision_and_scale;
  END;

  function REMOVE_DUPLICATE_COLUMNS(PIN_COLLIST in clob) return clob is
    V_DISTINCTCOLS clob;
  begin

    select LISTAGG(DISTINCTCOLS, ',') WITHIN group(order by 1)
    into   V_DISTINCTCOLS
    from   (select distinct COLLIST DISTINCTCOLS from   XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' ||  replace(PIN_COLLIST, ',', '</C><C>') || '</C></R>') COLUMNS COLLIST varchar2(100) PATH '.'));

    return V_DISTINCTCOLS;

  end REMOVE_DUPLICATE_COLUMNS;



 PROCEDURE PROCESS_INPUT(pin_input           in  varchar2
                        ,pin_input_alias     in  varchar2
                        ,pin_input_fields    in  varchar2
                        ,pin_MCE_fields      in  varchar2
                        ,pin_aditional_fields in  varchar2
                        ,pout_new_input      out varchar2)
 is
   type tabletype_varchar  is table of varchar2(100);
   vcol_InputFields        tabletype_varchar;
   vcol_MCEFields          tabletype_varchar;
   v_prefixed_select_list clob;
   v_InputEntitiesJoin    clob;
 begin
   SELECT InputFields BULK COLLECT INTO vcol_InputFields FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_input_fields,',','</C><C>') || '</C></R>') COLUMNS InputFields VARCHAR2(100) PATH '.');
   SELECT MCEFields   BULK COLLECT INTO vcol_MCEFields   FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_MCE_fields,',','</C><C>') || '</C></R>') COLUMNS MCEFields   VARCHAR2(100) PATH '.');

   FOR I IN 1..vcol_InputFields.COUNT loop
     --<<I>> CREATE SELECT LIST        If i have duality then select BK
     if vcol_MCEFields(i) LIKE '%METRIC_CALC_ENTITY_NAME_%' AND REGEXP_LIKE(vcol_InputFields(i) ,'E[0-9]' ) THEN
       v_prefixed_select_list := v_prefixed_select_list || COMMONS.FIND_ENT_TABLE_NAME(vcol_InputFields(i))           || '.'
                                                        || COMMONS.FIND_ENT_BUSINESS_KEY_BY_NAME(vcol_InputFields(i)) || ',';
     else
       v_prefixed_select_list := v_prefixed_select_list || pin_input_alias    || '.' || vcol_InputFields(i) || ',';
     end if;

     --<<II>> RECREATE INPUT JOINED WITH NEEDED ENTITIES
     if vcol_MCEFields(i) LIKE '%METRIC_CALC_ENTITY_NAME_%' AND REGEXP_LIKE(vcol_InputFields(i) ,'E[0-9]' ) THEN
       v_InputEntitiesJoin := v_InputEntitiesJoin || ' LEFT JOIN ' || COMMONS.FIND_ENT_TABLE_NAME(vcol_InputFields(i)) || ' ON ' || pin_input_alias || '.' || vcol_InputFields(i) || ' = '
                                                                   || COMMONS.FIND_ENT_TABLE_NAME(vcol_InputFields(i)) || '.E_INTERNAL_ID';
     end if;

   end loop;
   -- Remove last comma and any duplicate entries (If you have F1 in MCE and also F1 as the INPUT FIELD, there will be duplicat entries)
   v_prefixed_select_list := REMOVE_DUPLICATE_COLUMNS(SUBSTR(v_prefixed_select_list,1,LENGTH(v_prefixed_select_list)-1) || ',' ||  pin_aditional_fields );

   -- Change the Input only if i have Fields in MCE and Entity in Input
   if v_InputEntitiesJoin is not null then
     pout_new_input := '(SELECT ' || v_prefixed_select_list || ' FROM (SELECT * FROM ' || pin_input || ')' || pin_input_alias || v_InputEntitiesJoin || ')' || pin_input_alias;
   else
     pout_new_input := pin_input;
   end if;
 end;


 PROCEDURE PROCESS_INPUT_LOOKUP(pin_input            in  varchar2
                               ,pin_input_alias      in  varchar2
                               ,pin_input_fields     in  varchar2
                               ,pin_MCE_fields       in  varchar2
                               ,pin_aditional_fields in  varchar2
                               ,pout_select_list     out varchar2
                               ,pout_new_input       out varchar2)
  is
   type tabletype_varchar  is table of varchar2(100);
   vcol_InputFields        tabletype_varchar;
   vcol_MCEFields          tabletype_varchar;
   v_prefixed_select_list clob;
   v_InputEntitiesJoin    clob;
   v_aditional_fields     varchar2(4000 char) := REMOVE_DUPLICATE_COLUMNS(pin_aditional_fields);
  begin
    SELECT InputFields BULK COLLECT INTO vcol_InputFields FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_input_fields,',','</C><C>') || '</C></R>') COLUMNS InputFields VARCHAR2(100) PATH '.');
    SELECT MCEFields   BULK COLLECT INTO vcol_MCEFields   FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_MCE_fields,',','</C><C>') || '</C></R>') COLUMNS MCEFields   VARCHAR2(100) PATH '.');

    FOR I IN 1..vcol_InputFields.COUNT loop
      --<<I>> APPEND SELECT LIST
      if  REGEXP_LIKE(vcol_MCEFields(i)   ,'E[0-9]')
      and REGEXP_LIKE(vcol_InputFields(i) ,'F[0-9]')  then

        v_prefixed_select_list := v_prefixed_select_list || COMMONS.FIND_ENT_TABLE_NAME(vcol_MCEFields(i))           || '.E_INTERNAL_ID AS '  || vcol_MCEFields(i) || ',';

      elsif REGEXP_LIKE(vcol_MCEFields(i)  ,'F[0-9]')
        and REGEXP_LIKE(vcol_InputFields(i) ,'E[0-9]') then

        v_prefixed_select_list := v_prefixed_select_list || COMMONS.FIND_ENT_TABLE_NAME(vcol_InputFields(i))           || '.'
                                                         || COMMONS.FIND_ENT_BUSINESS_KEY_BY_NAME(vcol_InputFields(i)) || ',';
      end if;


      --<<II>> RECREATE INPUT JOINED WITH NEEDED ENTITIES
      if  REGEXP_LIKE(vcol_MCEFields(i)   ,'F[0-9]')
      and REGEXP_LIKE(vcol_InputFields(i) ,'E[0-9]') THEN

        v_InputEntitiesJoin := v_InputEntitiesJoin || ' LEFT JOIN ' || COMMONS.FIND_ENT_TABLE_NAME(vcol_InputFields(i)) || ' ON ' || pin_input_alias || '.' || vcol_InputFields(i) || ' = '
                                                          || COMMONS.FIND_ENT_TABLE_NAME(vcol_InputFields(i)) || '.E_INTERNAL_ID';

      elsif REGEXP_LIKE(vcol_MCEFields(i)   ,'E[0-9]')
        and REGEXP_LIKE(vcol_InputFields(i) ,'F[0-9]') THEN

        v_InputEntitiesJoin := v_InputEntitiesJoin || ' LEFT JOIN ' || COMMONS.FIND_ENT_TABLE_NAME(vcol_MCEFields(i)) || ' ON ' || pin_input_alias || '.' || vcol_InputFields(i) || ' = '
                                                          || COMMONS.FIND_ENT_TABLE_NAME(vcol_MCEFields(i)) || '.' || COMMONS.FIND_ENT_BUSINESS_KEY_BY_NAME(vcol_MCEFields(i));
      end if;

    end loop;

    -- remove last comma and any duplicate entries
    v_prefixed_select_list := REMOVE_DUPLICATE_COLUMNS(SUBSTR(v_prefixed_select_list,1,LENGTH(v_prefixed_select_list)-1) || ',' ||  v_aditional_fields );

    -- Change the Input only if i have Fields in MCE and Entity in Input
    if v_InputEntitiesJoin is not null then
      pout_new_input := '(SELECT ' || pin_input_alias || '.' || REPLACE(v_aditional_fields, ',', ',' || pin_input_alias || '.') || ' FROM ' || pin_input || ')' || pin_input_alias || v_InputEntitiesJoin;
    else
      pout_new_input := pin_input;
    end if;

    pout_select_list := v_prefixed_select_list;
  end;

PROCEDURE LOG_AND_RETURN_PARAMETERS(pin_stamp               in  varchar2,
                                    pin_Select_Clause       in  clob,
                                    pin_From_Clause         in  clob,
                                    pin_Where_Clause        in  clob,
                                    pin_When_Clause         in  clob,
                                    pin_Modifier_Operations in  clob,
                                    pin_Module              in  clob,
                                    pout_Aux_Clause         out OBJTYPE_MODIFIER_CLAUSES
                                    )
IS
  v_stamp    VARCHAR2(250) := pin_stamp;
  V_RETURN_CLAUSE OBJTYPE_MODIFIER_CLAUSES := OBJTYPE_MODIFIER_CLAUSES(NULL,NULL,NULL,NULL,NULL,NULL);
BEGIN

  V_RETURN_CLAUSE.SELECT_CLAUSE       := pin_Select_Clause;
  V_RETURN_CLAUSE.FROM_CLAUSE         := pin_From_Clause;
  V_RETURN_CLAUSE.WHERE_CLAUSE        := pin_Where_Clause;
  V_RETURN_CLAUSE.WHEN_CLAUSE         := pin_When_Clause;
  V_RETURN_CLAUSE.MODIFIER_OPERATIONS := pin_Modifier_Operations;
  V_RETURN_CLAUSE.MODULE              := pin_Module;

  -- Logg the out parameters
  v_stamp := replace(v_stamp, 'input', 'output');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_RETURN_CLAUSE.SELECT_CLAUSE      ),',SELECT_CLAUSE       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_RETURN_CLAUSE.FROM_CLAUSE        ),',FROM_CLAUSE         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_RETURN_CLAUSE.WHERE_CLAUSE       ),',WHERE_CLAUSE        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_RETURN_CLAUSE.WHEN_CLAUSE        ),',WHEN_CLAUSE         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_RETURN_CLAUSE.MODIFIER_OPERATIONS),',MODIFIER_OPERATIONS => <value>', v_stamp);
  END;

  pout_Aux_Clause := V_RETURN_CLAUSE;
END;


PROCEDURE PROCESS_PARAMETER_TABLE(pin_parameterTable        IN       VARCHAR2
                                 ,pin_parameterTableAlias   IN       VARCHAR2
                                 ,pin_rosterTable           IN       VARCHAR2
                                 ,pin_inputTable            IN       VARCHAR2
                                 ,pin_modifierIndex         IN       PLS_INTEGER
                                 ,pin_entitiesToLog         IN       CLOB
                                 ,pin_parameterAlias        IN       VARCHAR2
                                 ,pin_additionalParameterAlias IN    VARCHAR2
                                 ,pin_periodFilter          IN       CLOB
                                 ,pin_joinWithRoster        IN       OBJTYPE_NAME_JOIN_MAP
                                 ,pin_joinWithInput         IN       OBJTYPE_NAME_JOIN_MAP
                                 ,pin_modType               IN       VARCHAR2
                                 ,pin_modId                 IN       PLS_INTEGER
                                 ,pin_parameterTableType    IN       CLOB
                                 ,pin_lookupTableType       IN       CLOB
                                 ,pin_calledFrom            IN       pls_integer
                                 ,pin_MetricComponent_id    IN       NUMBER default null
                                 ,pin_inputCol              in       varchar2 default null
                                 ,pin_effective_date_cols   IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL
                                 ,pin_period_filter         IN       BOOLEAN

                                 ,pio_aliasIndex            IN OUT   PLS_INTEGER
                                 ,pio_selectClause          IN OUT   CLOB

                                 ,pout_joinClause           OUT      CLOB
                                 ,pout_whenClause           OUT      CLOB
                                 ,pout_Rejected_Values      OUT      CLOB
                                 ,pout_lookup_column_alias  OUT      CLOB
                                 ,pout_period_filter        OUT      BOOLEAN)

IS
   V_ENTITIES_COUNT           PLS_INTEGER;
   V_REJECTED_TABLE_VALUES    CLOB;
   V_JOIN_CLAUSE              CLOB;
   V_ALIAS_NAME               CLOB;
   V_STRING_TABLE_1           NT_STRING_TABLE;
   V_STRING_TABLE_1_DATATYPES NT_STRING_TABLE;
   V_STRING_TABLE_2           NT_STRING_TABLE;
   V_WHEN_CLAUSE_AUX          CLOB;
   V_ALIAS_NAME_PARAM         CLOB;
   v_stamp                    VARCHAR2(250);
   V_JOIN_WITH_PARAM_TAB_NEW  CLOB;

   V_VALIDATION_NON_MATCHING      PLS_INTEGER;
   V_VALIDATION_NON_MATCHING_LEFT PLS_INTEGER;
   V_VAL_PER_NON_MATCHING         PLS_INTEGER;
   V_VAL_PER_NON_MATCHING_LEFT    PLS_INTEGER;
   V_VALIDATION_EMPTY_RESULT      PLS_INTEGER;
   V_VALIDATION_ERROR_RESULT      PLS_INTEGER;
   V_VALIDATION_NO_LK_CURVES      PLS_INTEGER; --OF-28361

   V_AUX_WHEN_EMPTY_RESULT_LOOKUP CLOB;
   V_AUX_WHEN_ERROR_RESULT_LOOKUP CLOB;
   V_AUX_WHEN_NO_LOOKUP_CURVE     CLOB; --OF-28361
   V_AUX_WHEN_ADDITIONAL_PAR      CLOB;

   V_ALIAS_LOOKUP_COLUMN     CLOB;
   V_ALIAS_LOOKUP_RESULT     CLOB;
   V_ALIAS_VLD_NO_LKCURVES   CLOB;   --OF-28361

   V_JOIN_CLAUSE_AUX         CLOB;

   v_hint_loc_sel_param  VARCHAR2(4000 CHAR);
   v_hint_sel_param      VARCHAR2(4000 CHAR);
   V_CHECK_ALIAS         varchar2(200 char) := pin_parameterAlias;  --OF-20957 Fix VALIDATION
   v_date_format         varchar2(200 char);
   v_right_member        varchar2(4000 char);
   v_parameter_Table clob;

   v_period_filter       BOOLEAN := TRUE;

BEGIN

  v_stamp := 'MODIFIERS.PROCESS_PARAMETER_TABLE - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
  -- Log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLE),        ',PIN_PARAMETERTABLE      => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEALIAS),   ',PIN_PARAMETERTABLEALIAS => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_ROSTERTABLE),           ',PIN_ROSTERTABLE         => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLE),            ',PIN_INPUTTABLE          => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERINDEX),           ',PIN_MODIFIERINDEX       => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_ENTITIESTOLOG),             ',PIN_ENTITIESTOLOG       => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERALIAS),        ',PIN_PARAMETERALIAS      => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_additionalParameterAlias),        ',pin_additionalParameterAlias      => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_PERIODFILTER),              ',PIN_PERIODFILTER        => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(PIN_JOINWITHROSTER),          ',PIN_JOINWITHROSTER      => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(PIN_JOINWITHINPUT),           ',PIN_JOINWITHINPUT       => <value>' , v_stamp);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIO_ALIASINDEX),              ',PIO_ALIASINDEX          => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIO_SELECTCLAUSE),              ',PIO_SELECTCLAUSE        => <value>' , v_stamp);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calledFrom),              ',pin_calledFrom          => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_parameterTableType),        ',pin_parameterTableType  => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_lookupTableType),           ',pin_lookupTableType     => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),      ',PIN_METRICCOMPONENT_ID  => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols),     ',pin_effective_date_cols => <value>' , v_stamp);
  END;

  -- Set hint variables
  v_hint_loc_sel_param := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.PROCESS_PARAMETER_TABLE' ,pi_hint_id=> 'SEL_PARAM_TAB' ,pi_proc_id => pin_MetricComponent_id) || CHR(10);
  v_hint_sel_param     := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.PROCESS_PARAMETER_TABLE' ,pi_hint_id=> 'SEL_PARAM_TAB' ,pi_proc_id => pin_MetricComponent_id) || CHR(10);

  V_WHEN_CLAUSE_AUX := 'WHEN';
  -- Create ENTITIES array that must be logged in case of REJECTED RECORDS
  SELECT REGEXP_COUNT(pin_entitiesToLog,',') INTO V_ENTITIES_COUNT FROM DUAL;

  -- Non matching records validations

  IF pin_modId = 1 THEN                             --Lookup Parameter Table
    V_VALIDATION_NON_MATCHING    := 1270;
    V_VALIDATION_EMPTY_RESULT    := 1320;
    V_VALIDATION_ERROR_RESULT    := 1310;
    IF (pin_calledFrom = 1) THEN
       -- metric
       V_VALIDATION_NON_MATCHING_LEFT := 1260;
       V_VALIDATION_NO_LK_CURVES    := 1300;    --OF-30763
    ELSE
       -- component
       V_VALIDATION_NON_MATCHING_LEFT := 2265;
       V_VALIDATION_NO_LK_CURVES    := 2300;    --OF-30763
    END IF;

    -- We need to add LOOKUP_COLUMN and RESULT_VALUE to the list of selected columns and to give them aliases
    pio_aliasIndex := pio_aliasIndex + 1;
    V_ALIAS_LOOKUP_COLUMN := 'F' || TO_CHAR(pin_modifierIndex) || TO_CHAR(pio_aliasIndex);
    pout_lookup_column_alias := V_ALIAS_LOOKUP_COLUMN;
    pio_aliasIndex := pio_aliasIndex + 1;
    V_ALIAS_LOOKUP_RESULT := 'F' || TO_CHAR(pin_modifierIndex) || TO_CHAR(pio_aliasIndex);

    pio_aliasIndex := pio_aliasIndex + 1;
    V_ALIAS_VLD_NO_LKCURVES := 'F' || TO_CHAR(pin_modifierIndex) || TO_CHAR(pio_aliasIndex);
    --OF-28361

    pio_selectClause := pio_selectClause || ',T' || TO_CHAR(pin_modifierIndex)||'.LOOKUP_COLUMN   AS '  || V_ALIAS_LOOKUP_COLUMN   ||
                                            ',T' || TO_CHAR(pin_modifierIndex)||'.RESULT_VALUE    AS '  || V_ALIAS_LOOKUP_RESULT   ||
                                            ',T' || TO_CHAR(pin_modifierIndex)||'.VLD_NO_LKCURVES AS '  || V_ALIAS_VLD_NO_LKCURVES;       --OF-28361


  ELSIF pin_modId = 2 THEN                          --Input Table
    V_VALIDATION_NON_MATCHING := 1220;
    V_VALIDATION_EMPTY_RESULT := 1240;
  ELSIF pin_modId = 3 THEN                          --Parameter table
    IF (pin_calledFrom = 1) THEN
       -- metric
       V_VALIDATION_NON_MATCHING := 1260;
       V_VALIDATION_NON_MATCHING_LEFT := 1260;
       V_VAL_PER_NON_MATCHING_LEFT := 1260;
       V_VAL_PER_NON_MATCHING := 1260;
    ELSE
       -- component
       V_VALIDATION_NON_MATCHING_LEFT := 2266;
       V_VALIDATION_NON_MATCHING := 2265;
       V_VAL_PER_NON_MATCHING_LEFT := 2268;
       V_VAL_PER_NON_MATCHING := 2267;
    END IF;
  END IF;

  --OF-30155 OF-29495
  -- Used for  Modifier Input / Modifier Lookup Input
  -- This PS will return a join between the Input Table and any needed entities in order to handle Metrics Duality
  -- The only situation when the Modifier/Lookup Input must be joined with an Entity Table is when we have Entity in Modifier/Lookup Input and BusinessKey in MCE
  -- For the ogher scenarios we do not need to transform v_parameter_Table since TEMP_METRIC_VALUES contains EntityID and BK also

  v_parameter_Table := pin_parameterTable;
  if(pin_modId in (1,2)) then
    PROCESS_INPUT(pin_input            => pin_parameterTable
                 ,pin_input_alias      => pin_parameterTableAlias
                 ,pin_input_fields     => pin_joinWithInput.NAME1
                 ,pin_MCE_fields       => pin_joinWithInput.NAME2
                 ,pin_aditional_fields => pin_inputCol
                 ,pout_new_input       => v_parameter_Table);
   end if;

   -- Add to values CLAUSE of the INSERT into REJECTED RECORDS TABLE the aliases of the entity names
  -- Entities from MCE will start at F02 (F01 is the value e.g. MV_FINAL_VALUE)
  FOR I IN 1..V_ENTITIES_COUNT LOOP
    -- Increment alias name because of THE FIELD ON WHICH THE MODIFIER IS APPLIED is the first in the select clause
    V_REJECTED_TABLE_VALUES := V_REJECTED_TABLE_VALUES || ',F0' || TO_CHAR(I+1) || '_BK'; --FVC Fix Logging!
  END LOOP;

  -- Add NULL to the resto of the ENTYTY FIELDS in the REJECTED RECORDS TABLE
  WHILE V_ENTITIES_COUNT < 7 LOOP
     V_ENTITIES_COUNT := V_ENTITIES_COUNT+1;
     V_REJECTED_TABLE_VALUES := V_REJECTED_TABLE_VALUES || ',NULL';
  END LOOP;


  -- Add join with PARAMETER TABLE
  IF pin_periodFilter IS NULL THEN
    V_JOIN_CLAUSE := ' LEFT JOIN ' || v_parameter_Table || ' ON ';
    v_period_filter := FALSE;
  ELSE
    V_JOIN_CLAUSE := ' LEFT JOIN ('|| v_hint_loc_sel_param || ' SELECT ' || v_hint_sel_param || ' * FROM ' || v_parameter_Table || ' WHERE ' || pin_periodFilter || ') ' || pin_parameterTableAlias || ' ON 1=1 AND ';
  END IF;

  -- add the effective dated join
  IF pin_effective_date_cols.RELATIONSHIP_TABLE_ALIAS = 'R' THEN
    V_JOIN_CLAUSE := V_JOIN_CLAUSE || pin_rosterTable || '.' || pin_effective_date_cols.ENTITY_COLUMN_NAME || ' BETWEEN
                                          NVL(' || pin_parameterTableAlias || '.' || pin_effective_date_cols.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                      AND NVL(' || pin_parameterTableAlias || '.' || pin_effective_date_cols.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) AND ';

   v_period_filter := FALSE;
  ELSIF pin_effective_date_cols.RELATIONSHIP_TABLE_ALIAS IN ('I', 'TAB') THEN
    V_JOIN_CLAUSE := V_JOIN_CLAUSE || pin_inputTable || '.' || pin_effective_date_cols.ENTITY_COLUMN_NAME || ' BETWEEN
                                          NVL(' || pin_parameterTableAlias || '.' || pin_effective_date_cols.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                      AND NVL(' || pin_parameterTableAlias || '.' || pin_effective_date_cols.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) AND ';
   v_period_filter := FALSE;
  END IF;

  -- Join ROSTER TABLE with PARAMETER TABLE
  IF pin_joinWithRoster IS NOT NULL and pin_joinWithRoster.NAME1 IS NOT NULL THEN

    -- Get columns (and the datatype) that are used to join PARAMETER TABLE WITH ROSTER TABLE
    SELECT NEW_STR BULK COLLECT INTO V_STRING_TABLE_1           from XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_joinWithRoster.NAME1,',','</C><C>') || '</C></R>') COLUMNS NEW_STR VARCHAR2(100) PATH '.');
    SELECT NEW_STR BULK COLLECT INTO V_STRING_TABLE_1_DATATYPES from XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_joinWithRoster.NAME5,',','</C><C>') || '</C></R>') COLUMNS NEW_STR VARCHAR2(100) PATH '.');

    FOR I IN 1..V_STRING_TABLE_1.COUNT LOOP
      --Add null handling
      V_JOIN_CLAUSE := V_JOIN_CLAUSE || commons_utils.GET_EQUAL_MATCH_CONDITION(pin_left_member       => pin_parameterTableAlias || '.' || V_STRING_TABLE_1(I),
                                                                                pin_right_member      => pin_rosterTable || '.' || V_STRING_TABLE_1(I),
                                                                                pin_members_col_type  => null,
                                                                                pin_members_data_type => V_STRING_TABLE_1_DATATYPES(I)) || ' AND ';

      -- ADD IN COLUMNS AND VALUES LIST FOR THE INSERT IN REJECTED RECORDS TABLE THE FIELD USED IN THE JOIN CONDITION IF THIS IS NOT ENTITY INTERNAL ID
      --(THIS LOGIC IS APPLIED IN ORDER TO AVOID HAVING DUPLICATE FIELDS IN REJECTED RECORDS TABLE AS ENTITY INTERNAL ID IS SENT IN THE SELECT CLAUSE OF THE FIRST MODIFIER)

      --Add the parameter fields to select list and rejected values
      pio_aliasIndex := pio_aliasIndex + 1;
      V_ALIAS_NAME := 'F' || TO_CHAR(pin_modifierIndex) || TO_CHAR(pio_aliasIndex);
      V_ALIAS_NAME_PARAM := 'F' || TO_CHAR(pin_modifierIndex) || TO_CHAR(pio_aliasIndex) || '_1';

      pio_selectClause := pio_selectClause || ',' || pin_rosterTable || '.' || V_STRING_TABLE_1(I) || ' ' || V_ALIAS_NAME || ',' || pin_parameterTableAlias || '.' || V_STRING_TABLE_1(I) || ' ' || V_ALIAS_NAME_PARAM;
      V_ENTITIES_COUNT := V_ENTITIES_COUNT+1;
      V_REJECTED_TABLE_VALUES := V_REJECTED_TABLE_VALUES || ',' || V_ALIAS_NAME;

    END LOOP;

    v_period_filter := FALSE;
  END IF;

  -- JOIN INPUT TABLE WITH PARAMETER TABLE IN CASE OF METRIC MODIFIER PROCESSING (pin_InputJoinMap(2) is sent here)
  IF pin_joinWithInput IS NOT NULL AND
     pin_joinWithInput.NAME1 IS NOT NULL AND
     pin_joinWithInput.NAME2 IS NOT NULL
  THEN

    -- GET COLUMNS (and the datatype) THAT FORM THE MCE FROM PARAMETER TABLE
    SELECT NEW_STR BULK COLLECT INTO V_STRING_TABLE_1           FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_joinWithInput.NAME1,',','</C><C>') || '</C></R>') COLUMNS NEW_STR VARCHAR2(100) PATH '.');
    SELECT NEW_STR BULK COLLECT INTO V_STRING_TABLE_1_DATATYPES FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_joinWithInput.NAME5,',','</C><C>') || '</C></R>') COLUMNS NEW_STR VARCHAR2(100) PATH '.');
       -- GET COLUMNS THAT FORM THE MCE FROM METRIC GTT
    SELECT NEW_STR BULK COLLECT INTO V_STRING_TABLE_2 FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_joinWithInput.NAME2,',','</C><C>') || '</C></R>') COLUMNS NEW_STR VARCHAR2(100) PATH '.');
    --
    FOR I IN 1..V_STRING_TABLE_1.COUNT LOOP

     IF pin_calledFrom = 1 AND V_STRING_TABLE_2(I) LIKE '%METRIC_CALC_ENTITY_NAME_%' AND REGEXP_LIKE(V_STRING_TABLE_1(I) ,'E[0-9]' ) THEN
        -- REMOVE THE LAST 'AND' FROM JOIN CLAUSE WITH PARAMETER TABLE
          V_JOIN_CLAUSE := V_JOIN_CLAUSE || commons_utils.GET_EQUAL_MATCH_CONDITION(pin_left_member       => pin_inputTable          || '.' || V_STRING_TABLE_2(I) ,
                                                                                    pin_right_member      => pin_parameterTableAlias || '.' || COMMONS.FIND_ENT_BUSINESS_KEY_BY_NAME(V_STRING_TABLE_1(I)) ,
                                                                                    pin_members_col_type  => null,
                                                                                    pin_members_data_type => V_STRING_TABLE_1_DATATYPES(I)) || ' AND ';
     ELSE
        -- OF-26928 -- For Metric Modifiers the input may save DATE fields in  VARCHAR2 columns in the TEMP_METRIC_VALUES table, which leads to null handling issues
        if(V_STRING_TABLE_1_DATATYPES(I) = 3) then -- DATE
          select value into v_date_format from NLS_SESSION_PARAMETERS where parameter = 'NLS_DATE_FORMAT';
          v_right_member := 'to_date(' || pin_inputTable || '.' || V_STRING_TABLE_2(I) || ','''|| v_date_format || ''')';
        elsif (V_STRING_TABLE_1_DATATYPES(I) = 5) then
          select value into v_date_format from NLS_SESSION_PARAMETERS where parameter = 'NLS_TIMESTAMP_FORMAT';
          v_right_member := 'to_timestamp(' || pin_inputTable || '.' || V_STRING_TABLE_2(I) || ','''|| v_date_format || ''')';
        else
          v_right_member := pin_inputTable || '.' || V_STRING_TABLE_2(I);
        end if;

        V_JOIN_CLAUSE := V_JOIN_CLAUSE || commons_utils.GET_EQUAL_MATCH_CONDITION(pin_left_member       => pin_parameterTableAlias || '.' || V_STRING_TABLE_1(I) ,
                                                                                  pin_right_member      => v_right_member,
                                                                                  pin_members_col_type  => null,
                                                                                  pin_members_data_type => V_STRING_TABLE_1_DATATYPES(I)) || ' AND ';
      END IF;
    END LOOP;

    v_period_filter := FALSE;
  END IF;


  -- Create Columns and values list for the INSERT IN REJECTED RECORDS TABLE
  CASE
  WHEN pin_modId = 1 THEN
    IF pin_additionalParameterAlias IS NOT NULL THEN
       V_WHEN_CLAUSE_AUX := V_WHEN_CLAUSE_AUX || ' (' || V_ALIAS_LOOKUP_COLUMN || ' IS NULL) '; -- TODO: Fix this by sending the right value in pin_parameterAlias
    END IF;                                                                                     -- when running this sp for lookups
  WHEN pin_modId = 2 AND pin_calledFrom <> 2 THEN
    V_WHEN_CLAUSE_AUX := V_WHEN_CLAUSE_AUX || ' (' || V_CHECK_ALIAS || ' IS NULL) ';       --OF-20957 Fix VALIDATION
  ELSE
    NULL;
  end CASE;

  -- REMOVE THE LAST 'AND' FROM JOIN CLAUSE WITH PARAMETER TABLE
  V_JOIN_CLAUSE := SUBSTR(V_JOIN_CLAUSE,1,LENGTH(V_JOIN_CLAUSE)-4);
  V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' ' || V_JOIN_WITH_PARAM_TAB_NEW;

  IF TRIM(V_JOIN_CLAUSE_AUX) <> 'LEFT JOIN' THEN
    V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' ' || V_JOIN_CLAUSE_AUX;
  END IF;

  WHILE V_ENTITIES_COUNT < 14 LOOP
     V_ENTITIES_COUNT        := V_ENTITIES_COUNT+1;
     V_REJECTED_TABLE_VALUES := V_REJECTED_TABLE_VALUES || ',NULL';
  END LOOP;
  -- COMPLETE VALUES CLAUSE
  V_REJECTED_TABLE_VALUES := 'MODIFIERS_REJECTED_SEQ.nextval' || V_REJECTED_TABLE_VALUES || ',' || TO_CHAR(pin_modifierIndex);
  --
  pout_joinClause := V_JOIN_CLAUSE;

  IF (V_WHEN_CLAUSE_AUX <> 'WHEN' AND ((pin_modId = 2 AND pin_calledFrom <> 2) OR (pin_modId = 1 AND pin_additionalParameterAlias IS NOT NULL))) THEN
    V_WHEN_CLAUSE_AUX       := V_WHEN_CLAUSE_AUX || CASE WHEN (pin_modId = 1 AND pin_additionalParameterAlias IS NOT NULL) THEN ' AND ' || pin_additionalParameterAlias || ' IS NOT NULL ' ELSE '' END || ' THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES ( '
                                                 || V_REJECTED_TABLE_VALUES   || ','
                                                 || V_VALIDATION_NON_MATCHING || ', 1, '''
                                                 || TO_CHAR(pin_modifierIndex)|| ','
                                                 || pin_modType               || ','
                                                 || pin_parameterTableType    || ','
                                                 || pin_lookupTableType       ||''' ,'''
                                                 || pin_modType               ||''', F02,1)';
  END IF;

  IF pin_modId = 1 then  --Lookup

    IF pin_calledFrom = 1 and (pin_modType IN ('accelerator', 'decelerator')) THEN
        V_AUX_WHEN_EMPTY_RESULT_LOOKUP := ' WHEN ' || CASE WHEN pin_additionalParameterAlias IS NULL THEN '' ELSE pin_additionalParameterAlias || ' IS NOT NULL AND ' END
                                                   || V_ALIAS_VLD_NO_LKCURVES   || ' = 0 THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES ( '
                                                   || V_REJECTED_TABLE_VALUES   || ','
                                                   || V_VALIDATION_EMPTY_RESULT || ', 1, '''
                                                   || TO_CHAR(pin_modifierIndex)|| ','
                                                   || pin_modType               || ','
                                                   || pin_parameterTableType    || ','
                                                   || pin_lookupTableType       || ''' ,'''
                                                   || pin_modType               ||''', F02,1)';
    END IF;

    V_AUX_WHEN_ERROR_RESULT_LOOKUP   := ' WHEN ' || V_ALIAS_LOOKUP_COLUMN     || ' IS NOT NULL AND '
                                                 || V_ALIAS_LOOKUP_RESULT     || ' IS NULL AND     '
                                                 || V_ALIAS_VLD_NO_LKCURVES   || ' = 1 THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES ( '
                                                 || V_REJECTED_TABLE_VALUES   || ','
                                                 || V_VALIDATION_ERROR_RESULT || ',1,'''
                                                 || TO_CHAR(pin_modifierIndex)|| ','
                                                 || pin_modType               || ','
                                                 || pin_parameterTableType    || ','
                                                 || pin_lookupTableType       || ''','''
                                                 || pin_modType               ||''', F02,1)';

     IF pin_modType IN ('accelerator', 'decelerator') THEN
       --OF-30763
       V_AUX_WHEN_NO_LOOKUP_CURVE      := ' WHEN ' || CASE WHEN pin_additionalParameterAlias IS NULL THEN '' ELSE pin_additionalParameterAlias || ' IS NOT NULL AND ' END || V_ALIAS_VLD_NO_LKCURVES     || ' = 0 THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES ( '
                                                   || V_REJECTED_TABLE_VALUES     || ','
                                                   || V_VALIDATION_NO_LK_CURVES   || ', 1, '''
                                                   || TO_CHAR(pin_modifierIndex)  || ','
                                                   || pin_modType                 || ','
                                                   || pin_parameterTableType      || ','
                                                   || pin_lookupTableType         || ''' ,'''
                                                   || pin_modType                 ||''', F02,1)';
     END IF;

    IF pin_additionalParameterAlias IS NOT NULL THEN
      V_AUX_WHEN_ADDITIONAL_PAR       := ' WHEN ' || pin_additionalParameterAlias || ' IS NULL AND (('
                                                  || V_ALIAS_LOOKUP_COLUMN     || ' IS NOT NULL AND '
                                                  || V_ALIAS_LOOKUP_RESULT     || ' IS NOT NULL) OR ('
                                                  || V_ALIAS_LOOKUP_COLUMN     || ' IS NOT NULL AND '
                                                  || V_ALIAS_LOOKUP_RESULT     || ' IS NULL AND '
                                                  || V_ALIAS_VLD_NO_LKCURVES   || ' > 1))'
                                                  || ' THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES('
                                                  || V_REJECTED_TABLE_VALUES   || ','
                                                  || V_VALIDATION_NON_MATCHING_LEFT || ',1, '''
                                                  || TO_CHAR(pin_modifierIndex)|| ','
                                                  || pin_modType               || ','
                                                  || pin_parameterTableType    || ','
                                                  || pin_lookupTableType       || ''' , '''
                                                  || pin_modType               || ''', F02,1)';
    END IF;

    pout_whenClause := V_AUX_WHEN_EMPTY_RESULT_LOOKUP
                    || V_AUX_WHEN_ERROR_RESULT_LOOKUP
                    || V_AUX_WHEN_NO_LOOKUP_CURVE
                    || V_AUX_WHEN_ADDITIONAL_PAR
                    || CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;


  ELSIF pin_modId = 2 then --Input Table

    IF pin_calledFrom = 1 THEN
      pout_whenClause :=               ' WHEN ' || pin_parameterAlias        || ' IS NULL THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES('
                                                || V_REJECTED_TABLE_VALUES   || ','
                                                || V_VALIDATION_EMPTY_RESULT || ',1, '''
                                                || TO_CHAR(pin_modifierIndex)|| ','
                                                || pin_modType               || ','
                                                || pin_parameterTableType    || ','
                                                || pin_lookupTableType       || ''' , '''
                                                || pin_modType               || ''', F02,1)'
                                                || CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;
    ELSE
      pout_whenClause := CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;
    END IF;

  ELSIF pin_modId = 3 AND pin_additionalParameterAlias IS NOT NULL THEN --Parameter Table

    IF (pin_period_filter) THEN
      -- left plan parameter table
      pout_whenClause   :=               ' WHEN ' || pin_parameterAlias || ' IS NOT NULL AND '
                                                  || pin_additionalParameterAlias || ' IS NULL '
                                                  || ' THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES('
                                                  || V_REJECTED_TABLE_VALUES   || ','
                                                  || V_VAL_PER_NON_MATCHING_LEFT || ',1, '''
                                                  || TO_CHAR(pin_modifierIndex)|| ','
                                                  || pin_modType               || ','
                                                  || pin_parameterTableType    || ','
                                                  || pin_lookupTableType       || ''' , '''
                                                  || pin_modType               || ''', F02,1)'
                                                  || CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;
    ELSE
      -- left plan parameter table
      pout_whenClause   :=               ' WHEN ' || pin_parameterAlias || ' IS NOT NULL AND '
                                                  || pin_additionalParameterAlias || ' IS NULL '
                                                  || ' THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES('
                                                  || V_REJECTED_TABLE_VALUES   || ','
                                                  || V_VALIDATION_NON_MATCHING_LEFT || ',1, '''
                                                  || TO_CHAR(pin_modifierIndex)|| ','
                                                  || pin_modType               || ','
                                                  || pin_parameterTableType    || ','
                                                  || pin_lookupTableType       || ''' , '''
                                                  || pin_modType               || ''', F02,1)'
                                                  || CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;
    END IF;

    IF (v_period_filter) THEN
      -- right plan parameter table
      pout_whenClause   := pout_whenClause || ' WHEN ' || pin_parameterAlias || ' IS NULL AND '
                                                  || pin_additionalParameterAlias || ' IS NOT NULL '
                                                  || ' THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES('
                                                  || V_REJECTED_TABLE_VALUES   || ','
                                                  || V_VAL_PER_NON_MATCHING || ',1, '''
                                                  || TO_CHAR(pin_modifierIndex)|| ','
                                                  || pin_modType               || ','
                                                  || case WHEN (pin_calledFrom = 1) THEN pin_parameterTableType ELSE pin_modType END
                                                  || pin_lookupTableType       || ''' , '''
                                                  || pin_modType               || ''', F02,1)'
                                                  || CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;
    ELSE
      -- right plan parameter table
      pout_whenClause   := pout_whenClause || ' WHEN ' || pin_parameterAlias || ' IS NULL AND '
                                                  || pin_additionalParameterAlias || ' IS NOT NULL '
                                                  || ' THEN INTO TEMP_MODIFIERS_REJECTED_TABLE VALUES('
                                                  || V_REJECTED_TABLE_VALUES   || ','
                                                  || V_VALIDATION_NON_MATCHING || ',1, '''
                                                  || TO_CHAR(pin_modifierIndex)|| ','
                                                  || pin_modType               || ','
                                                  || case WHEN (pin_calledFrom = 1) THEN pin_parameterTableType ELSE pin_modType END
                                                  || pin_lookupTableType       || ''' , '''
                                                  || pin_modType               || ''', F02,1)'
                                                  || CASE WHEN V_WHEN_CLAUSE_AUX = 'WHEN' THEN NULL ELSE V_WHEN_CLAUSE_AUX END;
    END IF;
  END IF;

  pout_period_filter := v_period_filter;
  pout_Rejected_Values := V_REJECTED_TABLE_VALUES;

  v_stamp := replace(v_stamp, 'input', 'output');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIO_ALIASINDEX),    ',PIO_ALIASINDEX   => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIO_SELECTCLAUSE),    ',PIO_SELECTCLAUSE => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_JOINCLAUSE),     ',POUT_JOINCLAUSE  => <value>'  , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_WHENCLAUSE),     ',POUT_WHENCLAUSE  => <value>'  , v_stamp);
  END;

END PROCESS_PARAMETER_TABLE;
------------------------

FUNCTION MODIFIER_FLOOR_CAP_OVERRIDE(pin_clauses              IN       TABLETYPE_MODIFIER_CLAUSES
                                     ,pin_modifierType         IN       NUMBER
                                     ,pin_value                IN       NUMBER
                                     ,pin_parameterTable       IN       VARCHAR2
                                     ,pin_parameterTableAlias  IN       VARCHAR2
                                     ,pin_parameterCol         IN       VARCHAR2
                                     ,pin_inputJoinMap         IN       tabletype_name_join_map
                                     ,pin_rosterCols           IN       tabletype_name_join_map
                                     ,pin_paramPeriodFilter    IN       clob
                                     ,pin_MetricComponent_id   IN       NUMBER default NULL
                                     ,pin_effective_date_cols  IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                     ,pin_lookup_precision     IN       VARCHAR2 DEFAULT NULL
                                     )
RETURN TABLETYPE_MODIFIER_CLAUSES
IS
   VCOL_CLAUSES                   TABLETYPE_MODIFIER_CLAUSES;
   VOBJ_AUX_CLAUSE                OBJTYPE_MODIFIER_CLAUSES;
   V_MODIFIER_OPERATION           CLOB;
   V_SELECT_CLAUSE                CLOB;
   V_JOIN_CLAUSE                  CLOB;
   V_JOIN_WITH_ROSTER             CLOB;
   V_JOIN_WITH_PARAM_TAB          CLOB;
   V_OPERATOR                     VARCHAR2(30);
   V_OPERAND                      CLOB;
   V_WHEN_CLAUSE                  CLOB;
   V_ALIAS_INDEX                  PLS_INTEGER := 0;
   V_ALIAS_NAME                   VARCHAR2(30);
   V_MODIFIER_INDEX               PLS_INTEGER;
   V_INPUT_TABLE_NAME             CLOB;
   V_ROSTER_TABLE_NAME            CLOB;
   CON_METRIC                     CONSTANT CLOB := 'METRIC';
   CON_MODIFIED_EARNINGS          CONSTANT CLOB := 'MODIFIED_EARNINGS';
   CON_FLOOR                      CONSTANT CLOB := 'FLOOR';
   CON_CAP                        CONSTANT CLOB := 'CAP';
   CON_OVERRIDE                   CONSTANT CLOB := 'OVERRIDE';
   V_PRECISION                    VARCHAR2(30);
   V_FLOOR_CAP_PRECISION          VARCHAR2(30);
   V_PARAMETER_VALUE              VARCHAR2(2000);
   V_MOD_TYPE                     VARCHAR2(30);
   v_stamp                        VARCHAR2(250);
   V_PARAMETER_TABLE_TYPE         VARCHAR2(30);
   V_REJECTED_VALUES              CLOB;
   v_alias_lookup_column          VARCHAR2(30);

   V_CALLED_FROM                 PLS_INTEGER;
   v_period_filter               BOOLEAN;
BEGIN

  v_stamp := 'MODIFIERS.MODIFIER_FLOOR_CAP_OVERRIDE - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
/*    begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;
*/
  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_CLAUSES),            ',PIN_CLAUSES             => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERTYPE),           ',PIN_MODIFIERTYPE        => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_VALUE),                  ',PIN_VALUE               => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLE),       ',PIN_PARAMETERTABLE      => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEALIAS),  ',PIN_PARAMETERTABLEALIAS => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERCOL),         ',PIN_PARAMETERCOL        => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_INPUTJOINMAP),       ',PIN_INPUTJOINMAP        => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_ROSTERCOLS),         ',PIN_ROSTERCOLS          => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_PARAMPERIODFILTER),        ',PIN_PARAMPERIODFILTER   => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),     ',PIN_METRICCOMPONENT_ID  => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols),    ',pin_effective_date_cols => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_precision),     ',pin_lookup_precision    => <value>' , v_stamp);
  END;

   -- Validations
   IF pin_clauses IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_clauses parameter can not be null');
   END IF;
   --
   IF pin_modifierType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_modifierType parameter can not be null');
   END IF;
   --
   IF pin_parameterTable IS NOT NULL AND pin_inputJoinMap IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputJoinMap parameter can not be null');
   END IF;
   --
   IF pin_value IS NULL AND pin_parameterTable IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_value and pin_parameterTable parameters can not be both null');
   END IF;
   --
   IF pin_value IS NOT NULL AND pin_parameterTable IS NOT NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_value and pin_parameterTable parameters can not be both not null');
   END IF;
   --
   IF pin_modifierType NOT IN (1, 2, 3) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid value for pin_modifierType parameter');
   END IF;
   --
   VCOL_CLAUSES         := pin_clauses;
   VOBJ_AUX_CLAUSE      := VCOL_CLAUSES(1);
   V_MODIFIER_INDEX  := VCOL_CLAUSES.COUNT;

   -- GET THE PRECISION OF THE MODIFIED VALUE
   IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
      V_PRECISION := GET_PRECISION_AND_SCALE(CON_METRIC, pin_lookup_precision);
      V_CALLED_FROM := 1;
   ELSIF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
      V_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_MODIFIED_EARNINGS);
      V_CALLED_FROM := 2;
   END IF;

   -- GET THE PROCESSING INPUT TABLE NAME
   V_INPUT_TABLE_NAME := VOBJ_AUX_CLAUSE.FROM_CLAUSE;
   --

   IF V_MODIFIER_INDEX = 1 THEN -- IF FIRST MODIFIER,OPERATOR IS THE RESULT FIELD

      V_OPERAND     := SUBSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,1,INSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,',',1,1) - 1);
      -- ADD THE ALIAS OF THE FIRST UNMODIFIED VALUE
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || UNMODIFIED_VALUE_ALIAS;

   ELSE -- IF NOT THE FIRST MODIFIER,GET THE OPERATION OF THE LAST MODIFIER

      V_OPERAND     := SUBSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE, INSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,';',-1)+1);
      -- DUPLICATE IN THE VALUES CLAUSE OF THE MODIFIER RESULT TABLE THE ALIAS OF THE PRECEDING MODIFIER OPERATION AS THIS IS THE UNMODIFIED VALUE FOR THE CURRENT MODIFIER
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1) + 1);
      -- REMOVE ALIAS FROM OPERAND IF IT IS THE CASE
      --FC V_OPERAND     := SUBSTR(V_OPERAND,1,INSTR(V_OPERAND,' ',-1) - 1);
      V_OPERAND:= SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1)); --FC Fix 7Mod --
   END IF;

   --
   V_ROSTER_TABLE_NAME := pin_inputJoinMap(1).NAME3;
   -- JOIN INPUT TABLE WITH ROSTER TABLE
   IF pin_inputJoinMap IS NOT NULL AND
      pin_inputJoinMap(1).NAME1 IS NOT NULL AND
      pin_inputJoinMap(1).NAME2 IS NOT NULL
   THEN
      -- JOIN INPUT TABLE WITH ROSTER
      V_JOIN_WITH_ROSTER := ' LEFT JOIN ' || V_ROSTER_TABLE_NAME || ' ON ' || V_ROSTER_TABLE_NAME || '.' || pin_inputJoinMap(1).NAME1 || '=' || V_INPUT_TABLE_NAME || '.' || pin_inputJoinMap(1).NAME2;
   END IF;

   -- CREATE SELECT CLAUSE
   CASE
     WHEN pin_modifierType = 1 THEN -- IF FLOOR MODIFIER
      V_OPERATOR := 'GREATEST';
      V_FLOOR_CAP_PRECISION := GET_PRECISION_AND_SCALE(CON_FLOOR, pin_lookup_precision);
      V_MOD_TYPE := 'floor';
      V_PARAMETER_TABLE_TYPE := 'floor';
     WHEN pin_modifierType = 2 THEN -- IF CAP MODIFIER
      V_OPERATOR := 'LEAST';
      V_FLOOR_CAP_PRECISION := GET_PRECISION_AND_SCALE(CON_CAP, pin_lookup_precision);
      V_MOD_TYPE := 'cap';
      V_PARAMETER_TABLE_TYPE := 'cap';
     ELSE
      V_OPERATOR := 'COALESCE';
      V_FLOOR_CAP_PRECISION := GET_PRECISION_AND_SCALE(CON_OVERRIDE, pin_lookup_precision);
      V_MOD_TYPE := 'override';
      V_PARAMETER_TABLE_TYPE := 'override';
   END CASE;

   -- CREATE THE ALIAS OF THE PARAMETER VALUE USED IN MODIFIERS PROCESSING
   V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);


   -- ADD PARAMETER VALUE TO SELECT CLAUSE
   V_SELECT_CLAUSE   := 'CAST(' || NVL(TO_CHAR(pin_value),NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol) || ' AS NUMBER' || V_FLOOR_CAP_PRECISION || ') ' || V_ALIAS_NAME;
   if V_MODIFIER_INDEX = 1 then --FVC
     V_PARAMETER_VALUE := 'CAST(' || NVL(TO_CHAR(pin_value),NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol) || ' AS NUMBER' || V_FLOOR_CAP_PRECISION || ')';
   else
     V_PARAMETER_VALUE := V_ALIAS_NAME;
   end if;                      --FVC
   -- ADD ALIAS TO BE USED IN VALUES CLAUSE WHEN INSERTING IN MODIFIER RESULT TABLE
   V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || V_ALIAS_NAME;

   -- IF PARAMETER TABLE IS USED
   IF pin_parameterTable IS NOT NULL then
           MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable           => pin_parameterTable,
                                             pin_parameterTableAlias      => NVL(pin_parameterTableAlias, pin_parameterTable),
                                             pin_rosterTable              => V_ROSTER_TABLE_NAME,
                                             pin_inputTable               => V_INPUT_TABLE_NAME,
                                             pin_modifierIndex            => V_MODIFIER_INDEX,
                                             pin_entitiesToLog            => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                             pin_parameterAlias           => V_ALIAS_NAME,
                                             pin_additionalParameterAlias => NULL,
                                             pin_periodFilter             => pin_paramPeriodFilter,
                                             pin_joinWithRoster           => pin_rosterCols(1),
                                             pin_joinWithInput            => pin_inputJoinMap(2),
                                             pin_modType                  => V_MOD_TYPE,
                                             pin_modId                    => 3,-- Parameter Table
                                             pin_parameterTableType       => V_PARAMETER_TABLE_TYPE,
                                             pin_lookupTableType          => NULL,
                                             pin_calledFrom               => V_CALLED_FROM,
                                             pin_MetricComponent_id       => pin_MetricComponent_id,
                                             pin_inputCol                 => NULL,
                                             pin_effective_date_cols      => pin_effective_date_cols,
                                             pin_period_filter            => NULL,

                                             pio_selectClause             => V_SELECT_CLAUSE,
                                             pio_aliasIndex               => V_ALIAS_INDEX,

                                             pout_joinClause              => V_JOIN_WITH_PARAM_TAB,
                                             pout_whenClause              => V_WHEN_CLAUSE,
                                             pout_Rejected_Values         => V_REJECTED_VALUES,
                                             pout_lookup_column_alias     => v_alias_lookup_column,
                                             pout_period_filter           => v_period_filter);
        END IF;

   -- CREATE ALIAS FOR MODIFIER OPERATION
   V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   -- APPEND MODIFIER OPERATION TO SELECT CLAUSE
   IF (pin_modifierType = 3) THEN
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ';CAST((' || V_OPERATOR || '(' || V_PARAMETER_VALUE || ',' || V_OPERAND || ')) AS NUMBER' || V_PRECISION || ') ' || V_ALIAS_NAME;
   ELSE
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ';CAST((' || V_OPERATOR || '(COALESCE(' || V_PARAMETER_VALUE || ',' || V_OPERAND || '),' || V_OPERAND || ')) AS NUMBER' || V_PRECISION || ') ' || V_ALIAS_NAME;
   END IF;
   -- ADD ALIAS TO BE USED IN VALUES CLAUSE WHEN INSERTING IN MODIFIER RESULT TABLE / REMOVE FIRST COMMA
   V_MODIFIER_OPERATION := SUBSTR(V_MODIFIER_OPERATION,2) || ',' || V_ALIAS_NAME;

   -- CREATE JOIN CLAUSE
   V_JOIN_CLAUSE := V_JOIN_WITH_ROSTER || V_JOIN_WITH_PARAM_TAB;

  MODIFIERS.LOG_AND_RETURN_PARAMETERS(pin_stamp               => V_STAMP,
                                         pin_Select_Clause       => V_SELECT_CLAUSE,
                                         pin_From_Clause         => V_JOIN_CLAUSE,
                                         pin_Where_Clause        => NULL,
                                         pin_When_Clause         => V_WHEN_CLAUSE,
                                         pin_Modifier_Operations => V_MODIFIER_OPERATION,
                                         pin_Module              => VOBJ_AUX_CLAUSE.MODULE,
                                         pout_Aux_Clause         => VOBJ_AUX_CLAUSE);

  --
  VCOL_CLAUSES.EXTEND;
  VCOL_CLAUSES(V_MODIFIER_INDEX+1) := VOBJ_AUX_CLAUSE;
  --
  RETURN VCOL_CLAUSES;
END MODIFIER_FLOOR_CAP_OVERRIDE;
------------------------

FUNCTION MODIFIER_HURDLE_QUALIFIER(pin_clauses                    IN       TABLETYPE_MODIFIER_CLAUSES
                                  ,pin_modifierType               IN       NUMBER
                                  ,pin_inputTable                 IN       VARCHAR2
                                  ,pin_inputCol                   IN       VARCHAR2
                                  ,pin_leftParameterValue         IN       NUMBER
                                  ,pin_leftParameterTable         IN       VARCHAR2
                                  ,pin_leftParameterTableAlias    IN       VARCHAR2
                                  ,pin_leftParameterCol           IN       VARCHAR2
                                  ,pin_leftParameterPeriodFilter  IN       CLOB
                                  ,pin_parameterValue             IN       NUMBER
                                  ,pin_parameterTable             IN       VARCHAR2
                                  ,pin_parameterTableAlias        IN       VARCHAR2
                                  ,pin_parameterCol               IN       VARCHAR2
                                  ,pin_parameterPeriodFilter      IN       CLOB
                                  ,pin_inputJoinMap               IN       tabletype_name_join_map
                                  ,pin_rosterJoinMap              IN       tabletype_name_join_map
                                  ,pin_inputTableFilter           IN       VARCHAR2
                                  ,pin_InputTableName             IN       VARCHAR2
                                  ,pin_SCN                        IN       NUMBER
                                  ,pin_MetricComponent_id         IN       NUMBER default NULL
                                  ,pin_effective_date_cols_lhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                  ,pin_effective_date_cols_rhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                                  ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                                  ,pin_metricInputTable           in       varchar2           default null
                                  ,pin_metricInputSequence        in       varchar2           default null
                                  ,pin_thresholdInputFields       in       tabletype_name_map default null
                                  ,pin_thresholdFilterFields      in       tabletype_name_map default null
                                  ,pin_thresholdConstants         in       tabletype_name_map default null
                                  )
RETURN TABLETYPE_MODIFIER_CLAUSES
IS
   VCOL_CLAUSES                  TABLETYPE_MODIFIER_CLAUSES;
   VOBJ_AUX_CLAUSE               OBJTYPE_MODIFIER_CLAUSES;
   V_MODIFIER_VALUES_CLAUSE      CLOB;
   --
   V_SELECT_CLAUSE               CLOB;
   V_JOIN_CLAUSE                 CLOB;
   V_WHEN_CLAUSE                 CLOB;
   V_WHERE_CLAUSE                CLOB;
   --
   V_JOIN_WITH_ROSTER            CLOB;
   V_JOIN_WITH_PARAM_TAB         CLOB;
   V_JOIN_WITH_INPUT_METRIC      CLOB;
   V_JOIN_WITH_LPARAM_TAB        CLOB;
   --
   V_INPUT_METRIC_WHEN_CLAUSE    CLOB;
   V_LPARAMETER_WHEN_CLAUSE      CLOB;
   V_PARAMETER_WHEN_CLAUSE       CLOB;
   --
   V_OPERATOR                    CLOB;
   V_OPERAND                     CLOB;
   V_ALIAS_INDEX                 PLS_INTEGER := 0;
   V_ALIAS_NAME                  VARCHAR2(30);
   v_leftParamterAlias           VARCHAR2(30);
   V_MODIFIER_INDEX              PLS_INTEGER;
   V_INPUT_TABLE_NAME            CLOB;
   V_ROSTER_TABLE_NAME           CLOB;
   --
   CON_HURDLE                    CONSTANT VARCHAR2(50) := 'HURDLE';
   CON_QUALIFIER                 CONSTANT VARCHAR2(50) := 'QUALIFIER';
   CON_MODIFIER_VALUE            CONSTANT VARCHAR2(50) := 'MODIFIER_VALUE';
   --
   V_PRECISION                   VARCHAR2(30);
   V_LPARAMETER_PRECISION        VARCHAR2(30);
   V_INPUT_METRIC_PRECISION      VARCHAR2(30);
   V_MODIFIER_VALUE_PRECISION    VARCHAR2(30);
   V_UNMODIFIED_PRECISION        VARCHAR2(30);
   --
   V_INPUT_METRIC_VALUE          VARCHAR2(2000);
   --
   V_INPUT_METRIC_TABLE          CLOB;
   V_INPUT_METRIC_ALIAS          VARCHAR2(30);
   --
   V_LPARAMETER_VALUE            VARCHAR2(2000);
   V_PARAMETER_VALUE             VARCHAR2(2000);
   VOBJ_PINPUT_MODIF_VALUE_JOIN  objtype_name_join_map;
   VOBJ_PINPUT_HURDLE_QUAL_JOIN  objtype_name_join_map;
   --
   CON_PINPUT_ROSTER_JOIN_INDEX          CONSTANT PLS_INTEGER := 1;
   CON_PINPUT_INP_MET_JOIN_INDEX         CONSTANT PLS_INTEGER := 2;
   CON_PINPUT_LPARAM_JOIN_INDEX          CONSTANT PLS_INTEGER := 3;
   CON_PINPUT_PARAM_JOIN_INDEX           CONSTANT PLS_INTEGER := 4;
   CON_ROSTER_LPARAM_JOIN_INDEX          CONSTANT PLS_INTEGER := 1;
   CON_ROSTER_PARAM_JOIN_INDEX           CONSTANT PLS_INTEGER := 2;
   --
   V_AUX_VAR                     PLS_INTEGER;  -- USED FOR VARIOUS VALUES LIKE INSTR(STR1,STR2)
   V_MOD_TYPE                    VARCHAR2(30);
   V_REJECTED_VALUES             CLOB;
   -- FUNCTION/PROCEDURE NR 1
    v_stamp            VARCHAR2(250);
    V_PARAMETER_TABLE_TYPE VARCHAR2(30);
    v_called_from pls_integer;
    v_alias_lookup_column VARCHAR2(30);

    --FVC ADD HINTS
    v_hint_loc_sel1  VARCHAR2(4000 CHAR);
    v_hint_sel1      VARCHAR2(4000 CHAR);
    v_hint_loc_sel2  VARCHAR2(4000 CHAR);
    v_hint_sel2      VARCHAR2(4000 CHAR);

    v_period_filter  BOOLEAN;
BEGIN

  v_stamp := 'MODIFIERS.MODIFIER_HURDLE_QUALIFIER - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

/*    begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;
*/
  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_CLAUSES),               ',PIN_CLAUSES                     => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERTYPE),              ',PIN_MODIFIERTYPE                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLE),              ',PIN_INPUTTABLE                  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOL),                ',PIN_INPUTCOL                    => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LEFTPARAMETERVALUE),        ',PIN_LEFTPARAMETERVALUE          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LEFTPARAMETERTABLE),      ',PIN_LEFTPARAMETERTABLE          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LEFTPARAMETERTABLEALIAS), ',PIN_LEFTPARAMETERTABLEALIAS     => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LEFTPARAMETERCOL),        ',PIN_LEFTPARAMETERCOL            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_LEFTPARAMETERPERIODFILTER),   ',PIN_LEFTPARAMETERPERIODFILTER   => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_PARAMETERVALUE),            ',PIN_PARAMETERVALUE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLE),          ',PIN_PARAMETERTABLE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEALIAS),     ',PIN_PARAMETERTABLEALIAS         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERCOL),            ',PIN_PARAMETERCOL                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_PARAMETERPERIODFILTER),       ',PIN_PARAMETERPERIODFILTER       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_INPUTJOINMAP),          ',PIN_INPUTJOINMAP                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_ROSTERJOINMAP),         ',PIN_ROSTERJOINMAP               => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLEFILTER),        ',PIN_INPUTTABLEFILTER            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLENAME),          ',PIN_INPUTTABLENAME              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_SCN),                       ',PIN_SCN                         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),        ',PIN_METRICCOMPONENT_ID          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_precision),        ',pin_lookup_precision            => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metricInputTable),        ',pin_metricInputTable            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdInputFields),  ',pin_thresholdInputFields        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdFilterFields), ',pin_thresholdFilterFields       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdConstants),    ',pin_thresholdConstants          => <value>', v_stamp);

  END;

  --set hint variables
   v_hint_loc_sel1 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.MODIFIER_HURDLE_QUALIFIER' ,pi_hint_id=> 'SEL1' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
   v_hint_sel1     := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.MODIFIER_HURDLE_QUALIFIER' ,pi_hint_id=> 'SEL1' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
   v_hint_loc_sel2 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.MODIFIER_HURDLE_QUALIFIER' ,pi_hint_id=> 'SEL2' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
   v_hint_sel2     := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.MODIFIER_HURDLE_QUALIFIER' ,pi_hint_id=> 'SEL2' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
  --set hint variables

   IF pin_modifierType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_modifierType parameter can not be null');
   END IF;
   --
   IF pin_inputTable IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputTable parameter can not be null');
   END IF;
   --
   IF pin_inputJoinMap IS NULL THEN
     RAISE_APPLICATION_ERROR(-20001,'pin_inputJoinMap parameter can not be null');
   END IF;
   --
   IF pin_inputCol IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputCol parameter can not be null');
   END IF;
   --
   IF pin_parameterValue IS NOT NULL AND pin_parameterTable IS NOT NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_parameterValue and pin_parameterTable parameters can not be both not null');
   END IF;
   --
   IF pin_modifierType NOT IN (1,2) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid value for pin_modifierType parameter');
   END IF;
   --
   VCOL_CLAUSES            := pin_clauses;
   VOBJ_AUX_CLAUSE         := VCOL_CLAUSES(1);
   -- GET MODIFIER INDEX
   V_MODIFIER_INDEX     := VCOL_CLAUSES.COUNT;
   -- GET THE ROSTER TABLE NAME
   V_ROSTER_TABLE_NAME := pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME3;
   -- GET THE PROCESSING INPUT TABLE NAME
   V_INPUT_TABLE_NAME := VOBJ_AUX_CLAUSE.FROM_CLAUSE;
   -- GET THE PRECISION OF THE MODIFIED VALUE
   IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
      V_PRECISION                := GET_PRECISION_AND_SCALE(MODIFIERS.METRIC, pin_lookup_precision);
      V_INPUT_METRIC_PRECISION   := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIER_INPUT_VALUE);
      V_UNMODIFIED_PRECISION     := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.UNMODIFIED_METRIC);
      --
      v_called_from := 1;
      --V_MOD_TYPE := 1;
   ELSIF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
      V_PRECISION                := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIED_EARNINGS);
      V_INPUT_METRIC_PRECISION   := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIER_METRIC_VALUE);
      V_UNMODIFIED_PRECISION     := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.UNMODIFIED_EARNINGS);
      v_called_from := 2;
      --V_MOD_TYPE := 2;
   END IF;

   VOBJ_PINPUT_HURDLE_QUAL_JOIN     := pin_inputJoinMap(CON_PINPUT_LPARAM_JOIN_INDEX);
   VOBJ_PINPUT_MODIF_VALUE_JOIN  := pin_inputJoinMap(CON_PINPUT_PARAM_JOIN_INDEX);

   -- GET HURDLE/QUALIFIER SYSTEM FIELD PRECISION
   IF pin_modifierType = 1 THEN
      V_LPARAMETER_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_HURDLE);
      V_MOD_TYPE := 'hurdle';
   ELSE
      V_LPARAMETER_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_QUALIFIER);
      V_MOD_TYPE := 'qualifier';
   END IF;
   -- JOIN PROCESS INPUT TABLE WITH ROSTER TABLE
   IF pin_inputJoinMap IS NOT NULL AND
      pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME1 IS NOT NULL AND
      pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME2 IS NOT NULL
   THEN
      V_JOIN_WITH_ROSTER := ' LEFT JOIN ' || V_ROSTER_TABLE_NAME || ' ON ' || V_ROSTER_TABLE_NAME || '.' || pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME1 || '=' || V_INPUT_TABLE_NAME || '.' || pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME2;
   END IF;
   -- GET THE ALIAS OF THE MODIFIER METRIC/INPUT VALUE USED IN MODIFIERS PROCESSING

   IF pin_inputTableFilter IS NOT NULL THEN
      V_AUX_VAR := INSTR(pin_inputTable,' INNER JOIN',1,1);
      IF V_AUX_VAR > 0 THEN        -- IF INPUT TABLE IS JOINED WITH ENTITY TABLE GET THE INPUT TABLE ALIAS
         V_INPUT_METRIC_ALIAS := SUBSTR(pin_inputTable,INSTR(pin_inputTable,' ',1,1)+1,INSTR(pin_inputTable,' ',1,2) - INSTR(pin_inputTable,' ',1,1) - 1);
      ELSE     -- IF INPUT TABLE IS NOT JOINED WITH ENTITY TABLE BUT AN FILTER IS USED (ONLY IN METRIC MODIFIER PROCESSING)
         V_INPUT_METRIC_ALIAS := SUBSTR(pin_inputTable,INSTR(pin_inputTable,' ',1,1)+1);
      END IF;

      IF PIN_SCN IS NOT NULL AND INSTR(pin_inputTable,' ',1,1) = 0 THEN
        V_INPUT_METRIC_TABLE := '(' || v_hint_loc_sel1 || 'SELECT ' || v_hint_sel1 || V_INPUT_METRIC_ALIAS || '.* FROM '
        || REPLACE(pin_inputTable, pin_InputTableName, '(' || v_hint_loc_sel2 || 'SELECT '|| v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||') '|| pin_InputTableName ) || ' WHERE ' || pin_inputTableFilter || ') ' || V_INPUT_METRIC_ALIAS;
      END IF;
      IF PIN_SCN IS NOT NULL AND INSTR(pin_inputTable,' ',1,1) <> 0 THEN
        V_INPUT_METRIC_TABLE := '(' || v_hint_loc_sel1 || 'SELECT ' || v_hint_sel1 || V_INPUT_METRIC_ALIAS || '.* FROM '
        || REPLACE(pin_inputTable, pin_InputTableName, '(' || v_hint_loc_sel2 || 'SELECT '|| v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||') ') || ' WHERE ' || pin_inputTableFilter || ') ' || V_INPUT_METRIC_ALIAS;
      END IF;

     IF PIN_SCN IS NULL THEN
        V_INPUT_METRIC_TABLE := '(' || v_hint_loc_sel1 || 'SELECT ' || v_hint_sel1 || V_INPUT_METRIC_ALIAS || '.* FROM '
        || pin_inputTable || ' WHERE ' || pin_inputTableFilter || ') ' || V_INPUT_METRIC_ALIAS;
     END IF;
   ELSE
      V_INPUT_METRIC_TABLE := pin_inputTable;
      V_AUX_VAR := INSTR(pin_inputTable,' ',1,1);
      IF PIN_SCN IS NOT NULL AND V_AUX_VAR = 0 THEN
         V_INPUT_METRIC_TABLE := REPLACE(pin_inputTable, pin_InputTableName, '(' || v_hint_loc_sel2 || 'SELECT '|| v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||') ' || pin_InputTableName);
      END IF;

      IF PIN_SCN IS NOT NULL AND V_AUX_VAR > 0 THEN
         V_INPUT_METRIC_TABLE := REPLACE(pin_inputTable, pin_InputTableName, '(' || v_hint_loc_sel2 || 'SELECT '|| v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||')' );
      END IF;
      IF PIN_SCN IS NULL THEN
         V_INPUT_METRIC_TABLE := pin_inputTable;
      END IF;

      IF V_AUX_VAR > 0 THEN -- IF THE INPUT/METRIC TABLE NAME PARAMETER CONTAINS A SPACE CHAR, THEN IT CONTAINS ALSO THE INPUT/METRIC TABLE NAME ALIAS
         V_INPUT_METRIC_ALIAS := SUBSTR(pin_inputTable,V_AUX_VAR+1);
      ELSE -- IF THE INPUT/METRIC TABLE NAME PARAMETER DOES NOT CONTAIN A SPACE CHAR
         V_INPUT_METRIC_ALIAS := pin_inputTable;
      END IF;
   END IF;
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   V_SELECT_CLAUSE            := 'CAST( ' || V_INPUT_METRIC_ALIAS || '.' || pin_inputCol || ' AS NUMBER' || V_INPUT_METRIC_PRECISION || ') ' || V_ALIAS_NAME;

   V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || V_ALIAS_NAME;
   if V_MODIFIER_INDEX = 1 then --FVC
     V_INPUT_METRIC_VALUE       := 'CAST( COALESCE(' || V_INPUT_METRIC_ALIAS || '.' || pin_inputCol || ',0) AS NUMBER' || V_INPUT_METRIC_PRECISION || ')';
   else
     V_INPUT_METRIC_VALUE       := ' COALESCE(' || V_ALIAS_NAME || ',0) ';
   end if;

   -- JOIN PROCESS INPUT WITH INPUT/METRIC TABLE
    MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable        => V_INPUT_METRIC_TABLE,
                                      pin_parameterTableAlias   => V_INPUT_METRIC_ALIAS,
                                      pin_rosterTable           => V_ROSTER_TABLE_NAME,
                                      pin_inputTable            => V_INPUT_TABLE_NAME,
                                      pin_modifierIndex         => V_MODIFIER_INDEX,
                                      pin_entitiesToLog         => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                      pin_parameterAlias        => V_ALIAS_NAME,
                                      pin_additionalParameterAlias => NULL,
                                      pin_periodFilter          => NULL,
                                      pin_joinWithRoster        => NULL,
                                      pin_joinWithInput         => pin_inputJoinMap(CON_PINPUT_INP_MET_JOIN_INDEX),
                                      pin_modType               => V_MOD_TYPE,
                                      pin_modId                 => 2,
                                      pin_parameterTableType    => NULL,
                                      pin_lookupTableType       => NULL,
                                      pin_calledFrom            => v_called_from,
                                      pin_MetricComponent_id    => pin_MetricComponent_id,
                                      pin_inputCol              => V_INPUT_METRIC_ALIAS || '.' || pin_inputCol,-- #ADDED OF-30155 OF-29495
                                      pin_effective_date_cols   => NULL,
                                      pin_period_filter         => NULL,

                                      pio_aliasIndex            => V_ALIAS_INDEX,
                                      pio_selectClause          => V_SELECT_CLAUSE,

                                      pout_joinClause           => V_JOIN_WITH_INPUT_METRIC,
                                      pout_whenClause           => V_INPUT_METRIC_WHEN_CLAUSE,
                                      pout_Rejected_Values      => V_REJECTED_VALUES,
                                      pout_lookup_column_alias  => v_alias_lookup_column,
                                      pout_period_filter        => v_period_filter);
   -- CREATE THE ALIAS OF THE HURDLE/QUALIFIER VALUE USED IN MODIFIERS PROCESSING AND ADD THE HURDLE/QUALIFIER VALUE IN SELECT CLAUSE
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   v_leftParamterAlias   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   V_SELECT_CLAUSE            := V_SELECT_CLAUSE || ',' || 'CAST(' || NVL(TO_CHAR(pin_leftParameterValue),NVL(pin_leftParameterTableAlias, pin_leftParameterTable) || '.' || pin_leftParameterCol) || ' AS NUMBER' || V_LPARAMETER_PRECISION || ') ' || v_leftParamterAlias;
   V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || v_leftParamterAlias;
   if V_MODIFIER_INDEX = 1 then
     V_LPARAMETER_VALUE         := 'CAST(' || NVL(TO_CHAR(pin_leftParameterValue),NVL(pin_leftParameterTableAlias, pin_leftParameterTable) || '.' || pin_leftParameterCol) || ' AS NUMBER' || V_LPARAMETER_PRECISION || ')';
   else
     V_LPARAMETER_VALUE := v_leftParamterAlias;
   end if;
   -- PROCESS HURDLE/QUALIFIER TABLE
   IF pin_leftParameterTable IS NOT NULL THEN
      IF pin_modifierType = 1 THEN
          V_PARAMETER_TABLE_TYPE := 'hurdle' ;
      ELSE
          V_PARAMETER_TABLE_TYPE := 'qualifier' ;
      END IF;

      MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable          => pin_leftParameterTable,
                                        pin_parameterTableAlias     => NVL(pin_leftParameterTableAlias, pin_leftParameterTable),
                                        pin_rosterTable             => V_ROSTER_TABLE_NAME,
                                        pin_inputTable              => V_INPUT_TABLE_NAME,
                                        pin_modifierIndex           => V_MODIFIER_INDEX,
                                        pin_entitiesToLog           => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                        pin_parameterAlias          => v_leftParamterAlias,
                                        pin_additionalParameterAlias => NULL,
                                        pin_periodFilter            => pin_leftParameterPeriodFilter,
                                        pin_joinWithRoster          => pin_rosterJoinMap(CON_ROSTER_LPARAM_JOIN_INDEX),
                                        pin_joinWithInput           => VOBJ_PINPUT_HURDLE_QUAL_JOIN,
                                        pin_modType                 => V_MOD_TYPE,
                                        pin_modId                   => 3,
                                        pin_parameterTableType      => V_PARAMETER_TABLE_TYPE,
                                        pin_lookupTableType         => NULL,
                                        pin_calledFrom              => v_called_from,
                                        pin_MetricComponent_id      => pin_MetricComponent_id,
                                        pin_inputCol                => NULL,
                                        pin_effective_date_cols     =>  pin_effective_date_cols_lhs,
                                        pin_period_filter           => v_period_filter,

                                        pio_aliasIndex              => V_ALIAS_INDEX,
                                        pio_selectClause            => V_SELECT_CLAUSE,

                                        pout_joinClause             => V_JOIN_WITH_LPARAM_TAB,
                                        pout_whenClause             => V_LPARAMETER_WHEN_CLAUSE,
                                        pout_Rejected_Values        => V_REJECTED_VALUES,
                                        pout_lookup_column_alias    => v_alias_lookup_column,
                                        pout_period_filter          => v_period_filter);
   END IF;
   --
   IF V_MODIFIER_INDEX = 1 THEN -- IF FIRST MODIFIER,OPERATOR IS THE RESULT FIELD
      V_OPERAND := SUBSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,1,INSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,',',1,1) - 1);
      -- ADD THE ALIAS OF THE FIRST UNMODIFIED VALUE
      V_MODIFIER_VALUES_CLAUSE := V_MODIFIER_VALUES_CLAUSE || ',' || MODIFIERS.UNMODIFIED_VALUE_ALIAS;
   ELSE -- IF NOT THE FIRST MODIFIER,GET THE OPERATION OF THE LAST MODIFIER
      V_OPERAND := SUBSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,
                          INSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,';',-1)+1);
      -- DUPLICATE IN THE VALUES CLAUSE OF THE MODIFIER RESULT TABLE THE ALIAS OF THE PRECEDING MODIFIER OPERATION
      -- AS THIS IS THE UNMODIFIED VALUE FOR THE CURRENT MODIFIER
      V_MODIFIER_VALUES_CLAUSE := V_MODIFIER_VALUES_CLAUSE || ',' || SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1) + 1);
      -- REMOVE ALIAS FROM OPERAND IF IT IS THE CASE
       --FC Fix 7Mod -- V_OPERAND := SUBSTR(V_OPERAND,1,INSTR(V_OPERAND,' ',-1) - 1);
      V_OPERAND := SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1)); --FC Fix 7Mod --
   END IF;
   -- CAST THE UNMODIFIED VALUE
   V_OPERAND := 'CAST(' || V_OPERAND || ' AS NUMBER' || V_UNMODIFIED_PRECISION || ')';
   --
   IF pin_modifierType = 1 THEN -- IF HURDLE MODIFIER
      -- GET PRECISION OF THE PARAMETER VALUE,CREATE THE ALIAS USED IN MODIFIERS PROCESSING AND ADD THE PARAMETER VALUE IN SELECT CLAUSE
      V_MODIFIER_VALUE_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_MODIFIER_VALUE);
      V_ALIAS_INDEX              := V_ALIAS_INDEX + 1;
      V_ALIAS_NAME               := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
      V_SELECT_CLAUSE            := V_SELECT_CLAUSE || ',' || 'CAST(' || NVL(TO_CHAR(pin_parameterValue),NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol) || ' AS NUMBER' || V_MODIFIER_VALUE_PRECISION || ') ' || V_ALIAS_NAME;
      V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || V_ALIAS_NAME;
      if V_MODIFIER_INDEX = 1 then
        V_PARAMETER_VALUE          := 'CAST(' || NVL(TO_CHAR(pin_parameterValue),NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol) || ' AS NUMBER' || V_MODIFIER_VALUE_PRECISION || ')';
      else
        V_PARAMETER_VALUE        := V_ALIAS_NAME;
      end if;






      -- PROCESS PARAMETER TABLE
      IF pin_parameterTable IS NOT NULL THEN
         MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable       => pin_parameterTable,
                                           pin_parameterTableAlias  => NVL(pin_parameterTableAlias, pin_parameterTable),
                                           pin_rosterTable          => V_ROSTER_TABLE_NAME,
                                           pin_inputTable           => V_INPUT_TABLE_NAME,
                                           pin_modifierIndex        => V_MODIFIER_INDEX,
                                           pin_entitiesToLog        => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                           pin_parameterAlias       => V_ALIAS_NAME,
                                           pin_additionalParameterAlias => CASE WHEN pin_leftParameterValue IS NULL THEN v_leftParamterAlias ELSE NULL END,
                                           pin_periodFilter         => pin_parameterPeriodFilter,
                                           pin_joinWithRoster       => pin_rosterJoinMap(CON_ROSTER_PARAM_JOIN_INDEX),
                                           pin_joinWithInput        => VOBJ_PINPUT_MODIF_VALUE_JOIN,
                                           pin_modType              => V_MOD_TYPE,
                                           pin_modId                => 3,
                                           pin_parameterTableType   => 'value',
                                           pin_lookupTableType      => NULL,
                                           pin_calledFrom           => v_called_From,
                                           pin_MetricComponent_id   => pin_MetricComponent_id,
                                           pin_inputCol             => NULL,
                                           pin_effective_date_cols  => pin_effective_date_cols_rhs,
                                           pin_period_filter        => v_period_filter,

                                           pio_aliasIndex           => V_ALIAS_INDEX,
                                           pio_selectClause         => V_SELECT_CLAUSE,

                                           pout_joinClause          => V_JOIN_WITH_PARAM_TAB,
                                           pout_whenClause          => V_PARAMETER_WHEN_CLAUSE,
                                           pout_Rejected_Values     => V_REJECTED_VALUES,
                                           pout_lookup_column_alias => v_alias_lookup_column,
                                           pout_period_filter       => v_period_filter);
      END IF;

      -- CREATE MODIFIER OPERATION
      V_OPERATOR := ';(CASE WHEN ' || V_INPUT_METRIC_VALUE || ' < ' || V_LPARAMETER_VALUE ||
                    ' THEN CAST(COALESCE(' || V_PARAMETER_VALUE || ', ' || V_OPERAND || ') AS NUMBER' || V_PRECISION || ')' ||
                    ' ELSE CAST(' || V_OPERAND || ' AS NUMBER' || V_PRECISION || ') END) ';
   ELSE -- IF QUALIFIER MODIFIER
      V_OPERATOR := ';(CASE WHEN ' || V_INPUT_METRIC_VALUE || ' < ' || V_LPARAMETER_VALUE ||
                    ' THEN 0 ELSE CAST(' || V_OPERAND || ' AS NUMBER' || V_PRECISION || ') END) ';
   END IF;
   -- CREATE ALIAS FOR MODIFIER OPERATION AND ADD MODIFIER OPERATION TO SELECT CLAUSE
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   V_OPERATOR := V_OPERATOR || V_ALIAS_NAME;
   V_SELECT_CLAUSE := V_SELECT_CLAUSE || V_OPERATOR;
   -- ADD ALIAS TO BE USED IN VALUES CLAUSE WHEN INSERTING IN MODIFIER RESULT TABLE
   -- REMOVE FIRST COMMA
   V_MODIFIER_VALUES_CLAUSE := SUBSTR(V_MODIFIER_VALUES_CLAUSE,2) || ',' || V_ALIAS_NAME;
   -- CREATE WHERE CLAUSE,JOINS AND WHEN CONDITION
   --V_WHERE_CLAUSE := pin_inputTableFilter;
   V_JOIN_CLAUSE := V_JOIN_WITH_ROSTER || V_JOIN_WITH_INPUT_METRIC || V_JOIN_WITH_LPARAM_TAB || V_JOIN_WITH_PARAM_TAB;
   V_WHEN_CLAUSE := V_INPUT_METRIC_WHEN_CLAUSE || V_LPARAMETER_WHEN_CLAUSE || V_PARAMETER_WHEN_CLAUSE;
   --
   MODIFIERS.LOG_AND_RETURN_PARAMETERS(pin_stamp               => V_STAMP,
                                       pin_Select_Clause       => V_SELECT_CLAUSE,
                                       pin_From_Clause         => V_JOIN_CLAUSE,
                                       pin_Where_Clause        => V_WHERE_CLAUSE,
                                       pin_When_Clause         => V_WHEN_CLAUSE,
                                       pin_Modifier_Operations => V_MODIFIER_VALUES_CLAUSE,
                                       pin_Module              => VOBJ_AUX_CLAUSE.MODULE,
                                       pout_Aux_Clause         => VOBJ_AUX_CLAUSE);

   --
   VCOL_CLAUSES.EXTEND;
   VCOL_CLAUSES(V_MODIFIER_INDEX+1) := VOBJ_AUX_CLAUSE;
   --
   RETURN VCOL_CLAUSES;
END MODIFIER_HURDLE_QUALIFIER;

------------------------

FUNCTION MODIFIER_ACC_DEC(pin_clauses                    IN       tabletype_modifier_clauses
                         ,pin_modifierType               IN       NUMBER
                         ,pin_inputTable                 IN       VARCHAR2
                         ,pin_inputCol                   IN       VARCHAR2
                         ,pin_thresholdValue             IN       NUMBER
                         ,pin_thresholdTable             IN       VARCHAR2
                         ,pin_thresholdTableAlias        IN       VARCHAR2
                         ,pin_thresholdCol               IN       VARCHAR2
                         ,pin_thresholdPeriodFilter      IN       CLOB
                         ,pin_lookupType                 IN       NUMBER
                         ,pin_lookupTable                IN       VARCHAR2
                         ,pin_LowerValueOption           IN       NUMBER
                         ,pin_HigherValueOption          IN       NUMBER
                         ,pin_parameterValue             IN       NUMBER
                         ,pin_parameterTable             IN       VARCHAR2
                         ,pin_parameterTableAlias        IN       VARCHAR2
                         ,pin_parameterCol               IN       VARCHAR2
                         ,pin_parameterPeriodFilter      IN       CLOB
                         ,pin_inputJoinMap               IN       tabletype_name_join_map
                         ,pin_rosterJoinMap              IN       tabletype_name_join_map
                         ,pin_inputTableFilter           IN       VARCHAR2
                         ,pin_parameterTableFilter       IN       VARCHAR2
                         ,pin_InputTableName             IN       VARCHAR2
                         ,pin_SCN                        IN       NUMBER
                         ,pin_MetricComponent_id         IN       NUMBER default null
                         ,pin_LookupInputJoinMap         IN       tabletype_name_join_map default null
                         ,pin_LookupJoinClause           in       varchar2 default null
                         ,pin_LookupVaryByFields         in       varchar2 default null
                         ,pin_LookupInputEE              in       varchar2 default null
                         ,pin_LookupRosterFilter         in       varchar2 default null --
                         ,pin_LookupPeriodFilter         in       clob default null --
                         ,pin_effective_date_cols_lhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                         ,pin_effective_date_cols_rhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                         ,pin_effective_date_cols_lookup IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                         ,pin_lookup_date_field          IN       VARCHAR2 DEFAULT NULL
                         ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                         ,pin_lookup_value_precision     IN       VARCHAR2 DEFAULT NULL
                         ,pin_lookup_result_precision    IN       VARCHAR2 DEFAULT NULL
                         ,pin_metricInputTable           in       varchar2           default null
                         ,pin_metricInputSequence        in       varchar2           default null
                         ,pin_thresholdInputFields       in       tabletype_name_map default null
                         ,pin_thresholdFilterFields      in       tabletype_name_map default null
                         ,pin_thresholdConstants         in       tabletype_name_map default null
                         ,pin_lookupFilterFields         in       tabletype_name_map default null
                         ,pin_lookupInputFields          in       tabletype_name_map default null
                         ,pin_lookupConstants            in       tabletype_name_map default null
                         )
RETURN TABLETYPE_MODIFIER_CLAUSES
IS

   CON_EFF_DATE_FIELDS           CONSTANT VARCHAR2(70) := CASE WHEN pin_effective_date_cols_lookup IS NULL THEN '' ELSE ', LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 END;
   CON_EFF_DATE_VARY_BY          CONSTANT VARCHAR2(70) := CASE WHEN pin_effective_date_cols_lookup IS NULL THEN '' ELSE ', ' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', ' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 END;
   CON_EFF_DATE_JOIN             CONSTANT VARCHAR2(2000) :=
                        CASE WHEN pin_LookupJoinClause IS NULL THEN
                          CASE WHEN pin_effective_date_cols_lookup IS NOT NULL THEN
                          ' LOOKUP ON ' || CASE WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS = 'R' THEN
                                  'R.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS IN ('I', 'TAB') THEN
                                   'TAB.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  ELSE NULL
                                  END
                           ELSE NULL
                           END
                        ELSE
                          pin_LookupJoinClause || CASE WHEN pin_effective_date_cols_lookup IS NOT NULL THEN
                            CASE WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS = 'R' THEN
                                  ' AND R.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS IN ('I', 'TAB') THEN
                                   ' AND TAB.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  ELSE NULL
                                  END
                           ELSE NULL
                           END
                        END;

   V_LOOKUP_SELECT               CLOB;
   V_LOOKUP_FROM_CLAUSE          CLOB;
   VCOL_CLAUSES                  TABLETYPE_MODIFIER_CLAUSES;
   VOBJ_AUX_CLAUSE               OBJTYPE_MODIFIER_CLAUSES;
   V_MODIFIER_VALUES_CLAUSE      CLOB;
   --
   V_SELECT_CLAUSE               CLOB;
   V_JOIN_CLAUSE                 CLOB;
   V_WHEN_CLAUSE                 CLOB;
   V_WHERE_CLAUSE                CLOB;
   --
   V_JOIN_WITH_ROSTER            CLOB;
   V_JOIN_WITH_PARAM_TAB         CLOB;
   V_JOIN_WITH_INPUT_METRIC      CLOB;
   V_JOIN_WITH_THRESHOLD         CLOB;
   --
   V_INPUT_METRIC_WHEN_CLAUSE    CLOB;
   V_THRESHOLD_WHEN_CLAUSE       CLOB;
   V_PARAMETER_WHEN_CLAUSE       CLOB;
   --
   V_OPERATOR                    VARCHAR2(2000);
   V_OPERAND                     CLOB;
   V_LOOKUP_INPUT_TABLE_COLS     CLOB;
   V_ALIAS_INDEX                 PLS_INTEGER := 0;
   V_ALIAS_NAME                  VARCHAR2(30);
   V_THRESHOLD_ALIAS_NAME        VARCHAR2(30);
   V_MODIFIER_INDEX              PLS_INTEGER;
   V_INPUT_TABLE_NAME            CLOB;
   V_ROSTER_TABLE_NAME           CLOB;
   --
   CON_ACCELERATOR               CONSTANT VARCHAR2(50) := 'ACCELERATOR';
   CON_DECELERATOR               CONSTANT VARCHAR2(50) := 'DECELERATOR';
   CON_THRESHOLD                 CONSTANT VARCHAR2(50) := 'THRESHOLD';
   CON_MODIFIER                  CONSTANT VARCHAR2(50) := 'MODIFIER';
   --
   V_PRECISION                   VARCHAR2(30);
   V_ACC_DEC_PRECISION           VARCHAR2(30);
   V_THRESHOLD_PRECISION         VARCHAR2(30);
   V_UNMODIFIED_PRECISION        VARCHAR2(30);
   V_INPUT_METRIC_PRECISION      VARCHAR2(30);
   --
   V_INPUT_METRIC_VALUE          CLOB;
   --
   V_INPUT_METRIC_TABLE          CLOB;
   V_INPUT_METRIC_ALIAS          CLOB;
   --
   V_THRESHOLD_VALUE             CLOB;
   V_PARAMETER_VALUE             CLOB;
   V_PARAMETER_TABLE             CLOB;
   V_PARAMETER_TABLE_ALIAS       VARCHAR2(30);
   V_PARAMETER_COL               CLOB;
   VOBJ_PINPUT_ACC_DEC_JOIN      objtype_name_join_map;
   VOBJ_PINPUT_THRES_JOIN        objtype_name_join_map;
   --
   CON_PINPUT_ROSTER_JOIN_INDEX          CONSTANT PLS_INTEGER := 1;
   CON_PINPUT_INP_MET_JOIN_INDEX         CONSTANT PLS_INTEGER := 2;
   CON_PINPUT_THRES_JOIN_INDEX           CONSTANT PLS_INTEGER := 3;
   CON_PINPUT_ACC_DEC_JOIN_INDEX         CONSTANT PLS_INTEGER := 4;
   CON_ROSTER_THRES_JOIN_INDEX           CONSTANT PLS_INTEGER := 1;
   CON_ROSTER_ACC_DEC_JOIN_INDEX         CONSTANT PLS_INTEGER := 2;
   --
   V_AUX_VAR                     PLS_INTEGER;   -- USED FOR VARIOUS VALUES LIKE INSTR(STR1,STR2)
   V_MOD_TYPE                    VARCHAR2(30);
   V_REJECTED_VALUES             CLOB;
   V_PARAMETER_TABLE_TYPE        VARCHAR2(30);

   V_LOOKUP_TABLE_TYPE           VARCHAR2(30);
-- FUNCTION/PROCEDURE NR 1
   v_stamp            VARCHAR2(250);

   V_MOD_ID PLS_INTEGER;
   V_CALLED_FROM PLS_INTEGER;
   v_alias_lookup_column VARCHAR2(30);

   --FVC ADD HINTS
   v_hint_loc_sel1  VARCHAR2(4000 CHAR);
   v_hint_sel1      VARCHAR2(4000 CHAR);
   v_hint_loc_sel2  VARCHAR2(4000 CHAR);
   v_hint_sel2      VARCHAR2(4000 CHAR);

   -- Lookups that varyby
   V_LOOKUP_INPUT_TABLE_COLS_AL  CLOB;
   roster_lookup_clause   VARCHAR2(4000 CHAR);
   roster_join_clause     VARCHAR2(4000 CHAR);
   v_varybyfields         VARCHAR2(4000 CHAR);
   v_lookupTable clob;

   v_period_filter BOOLEAN;

BEGIN

  v_stamp := 'MODIFIERS.MODIFIER_ACC_DEC - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_CLAUSES),           ',PIN_CLAUSES                     => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERTYPE),          ',PIN_MODIFIERTYPE                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLE),          ',PIN_INPUTTABLE                  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOL),            ',PIN_INPUTCOL                    => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_THRESHOLDVALUE),        ',PIN_THRESHOLDVALUE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_THRESHOLDTABLE),      ',PIN_THRESHOLDTABLE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_THRESHOLDTABLEALIAS), ',PIN_THRESHOLDTABLEALIAS         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_THRESHOLDCOL),        ',PIN_THRESHOLDCOL                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_THRESHOLDPERIODFILTER),   ',PIN_THRESHOLDPERIODFILTER       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LOOKUPTYPE),            ',PIN_LOOKUPTYPE                  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LOOKUPTABLE),         ',PIN_LOOKUPTABLE                 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LOWERVALUEOPTION),      ',PIN_LOWERVALUEOPTION            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_HIGHERVALUEOPTION),     ',PIN_HIGHERVALUEOPTION           => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_PARAMETERVALUE),        ',PIN_PARAMETERVALUE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLE),      ',PIN_PARAMETERTABLE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEALIAS), ',PIN_PARAMETERTABLEALIAS         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERCOL),        ',PIN_PARAMETERCOL                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_PARAMETERPERIODFILTER),   ',PIN_PARAMETERPERIODFILTER       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_INPUTJOINMAP),      ',PIN_INPUTJOINMAP                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_ROSTERJOINMAP),     ',PIN_ROSTERJOINMAP               => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLEFILTER),    ',PIN_INPUTTABLEFILTER            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEFILTER),',PIN_PARAMETERTABLEFILTER        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTTABLENAME),      ',PIN_INPUTTABLENAME              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_SCN),                   ',PIN_SCN                         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),    ',PIN_METRICCOMPONENT_ID          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_LookupInputJoinMap),      ',pin_LookupInputJoinMap                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupJoinClause),',pin_LookupJoinClause        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupVaryByFields),',pin_LookupVaryByFields        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupInputEE),',pin_LookupInputEE        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupRosterFilter),',pin_LookupRosterFilter        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_LookupPeriodFilter),   ',pin_LookupPeriodFilter       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols_lhs),     ',pin_effective_date_cols_lhs => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols_rhs),     ',pin_effective_date_cols_rhs => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols_lookup),  ',pin_effective_date_cols_lookup => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_precision),     ',pin_lookup_precision    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_value_precision),',pin_lookup_value_precision    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_result_precision),',pin_lookup_result_precision    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metricInputTable),        ',pin_metricInputTable      => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdInputFields),  ',pin_thresholdInputFields  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdFilterFields), ',pin_thresholdInputFields  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_thresholdConstants),    ',pin_thresholdConstants    => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupFilterFields),    ',pin_lookupFilterFields    => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupInputFields),     ',pin_lookupInputFields     => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupConstants),       ',pin_lookupConstants       => <value>', v_stamp);
  END;


  --set hint variables
   v_hint_loc_sel1 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.MODIFIER_ACC_DEC' ,pi_hint_id=> 'SEL1' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
   v_hint_sel1     := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.MODIFIER_ACC_DEC' ,pi_hint_id=> 'SEL1' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
   v_hint_loc_sel2 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.MODIFIER_ACC_DEC' ,pi_hint_id=> 'SEL2' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
   v_hint_sel2     := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.MODIFIER_ACC_DEC' ,pi_hint_id=> 'SEL2' ,pi_proc_id => pin_MetricComponent_id ) || CHR(10);
  --set hint variables

   -- VALIDATIONS
   IF pin_modifierType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_modifierType parameter can not be null');
   END IF;

   --
   IF pin_inputTable IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputTable parameter can not be null');
   END IF;

   --
   IF pin_inputCol IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputCol parameter can not be null');
   END IF;

   --
   IF pin_parameterValue IS NULL AND pin_parameterTable IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_parameterValue and pin_parameterTable parameters can not be both null');
   END IF;

   --
   IF pin_parameterValue IS NOT NULL AND pin_parameterTable IS NOT NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_parameterValue and pin_parameterTable parameters can not be both not null');
   END IF;

   --
   IF pin_modifierType NOT IN (1,2) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid value for pin_modifierType parameter');
   END IF;

   --
   VCOL_CLAUSES         := pin_clauses;
   VOBJ_AUX_CLAUSE      := VCOL_CLAUSES(1);
   -- GET MODIFIER INDEX
   V_MODIFIER_INDEX     := VCOL_CLAUSES.COUNT;
   -- GET THE ROSTER TABLE NAME
   V_ROSTER_TABLE_NAME := pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME3;
   -- GET THE PROCESSING INPUT TABLE NAME
   V_INPUT_TABLE_NAME := VOBJ_AUX_CLAUSE.FROM_CLAUSE;
   -- GET THE PRECISION OF THE MODIFIED VALUE
   IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
      V_PRECISION                := GET_PRECISION_AND_SCALE(MODIFIERS.METRIC, pin_lookup_precision);
      V_INPUT_METRIC_PRECISION   := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIER_INPUT_VALUE);
      V_UNMODIFIED_PRECISION     := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.UNMODIFIED_METRIC);

      V_CALLED_FROM :=1;
     -- V_MOD_TYPE := 1;
   ELSIF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
      V_PRECISION                := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIED_EARNINGS);
      V_INPUT_METRIC_PRECISION   := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIER_METRIC_VALUE);
      V_UNMODIFIED_PRECISION     := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.UNMODIFIED_EARNINGS);
      V_CALLED_FROM := 2;
     -- V_MOD_TYPE := 2;

   END IF;

   -- GET THE JOIN BETWEEN PROCESS INPUT AND THRESHOLD TABLE AND PROCESS INPUT AND ACCELERATOR/DECELERATOR TABLE
   VOBJ_PINPUT_THRES_JOIN        := pin_inputJoinMap(CON_PINPUT_THRES_JOIN_INDEX);
   VOBJ_PINPUT_ACC_DEC_JOIN      := pin_inputJoinMap(CON_PINPUT_ACC_DEC_JOIN_INDEX);

   -- JOIN PROCESS INPUT TABLE WITH ROSTER TABLE
   IF pin_inputJoinMap IS NOT NULL AND
      pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME1 IS NOT NULL AND
      pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME2 IS NOT NULL
   THEN
      V_JOIN_WITH_ROSTER := ' LEFT JOIN ' || V_ROSTER_TABLE_NAME || ' ON ' || V_ROSTER_TABLE_NAME || '.' || pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME1 || '=' || V_INPUT_TABLE_NAME || '.' || pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME2;
   END IF;

   -- CREATE THE ALIAS OF THE MODIFIER METRIC/INPUT VALUE USED IN MODIFIERS PROCESSING
   -- GET THE ALIAS OF THE MODIFIER METRIC/INPUT VALUE USED IN MODIFIERS PROCESSING

   IF pin_inputTableFilter IS NOT NULL THEN
      V_AUX_VAR := INSTR(pin_inputTable,' INNER JOIN',1,1);
      IF V_AUX_VAR > 0 THEN        -- IF INPUT TABLE IS JOINED WITH ENTITY TABLE GET THE INPUT TABLE ALIAS
         V_INPUT_METRIC_ALIAS := SUBSTR(pin_inputTable,INSTR(pin_inputTable,' ',1,1)+1,INSTR(pin_inputTable,' ',1,2) - INSTR(pin_inputTable,' ',1,1) - 1);
      ELSE     -- IF INPUT TABLE IS NOT JOINED WITH ENTITY TABLE BUT A FILTER IS USED (ONLY IN METRIC MODIFIER PROCESSING)
         V_INPUT_METRIC_ALIAS := SUBSTR(pin_inputTable,INSTR(pin_inputTable,' ',1,1)+1);

      END IF;

      IF PIN_SCN IS NOT NULL AND INSTR(pin_inputTable,' ',1,1) = 0 THEN
        V_INPUT_METRIC_TABLE := '('|| v_hint_loc_sel1 ||'SELECT ' || v_hint_sel1 || V_INPUT_METRIC_ALIAS || '.* FROM '
        || REPLACE(pin_inputTable, pin_InputTableName, '(' || v_hint_loc_sel2 ||'SELECT '|| v_hint_sel2 || ' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||') '|| pin_InputTableName ) || ' WHERE ' || pin_inputTableFilter || ') ' || V_INPUT_METRIC_ALIAS;
      END IF;

      IF PIN_SCN IS NOT NULL AND INSTR(pin_inputTable,' ',1,1) <> 0 THEN
        V_INPUT_METRIC_TABLE := '('|| v_hint_loc_sel1 ||'SELECT '|| v_hint_sel1 || V_INPUT_METRIC_ALIAS || '.* FROM '
        || REPLACE(pin_inputTable, pin_InputTableName, '('|| v_hint_loc_sel2 ||'SELECT '|| v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||') ') || ' WHERE ' || pin_inputTableFilter || ') ' || V_INPUT_METRIC_ALIAS;
      END IF;


     IF PIN_SCN IS NULL THEN
        V_INPUT_METRIC_TABLE := '('|| v_hint_loc_sel1 ||'SELECT '|| v_hint_sel1 || V_INPUT_METRIC_ALIAS || '.* FROM '
        || pin_inputTable || ' WHERE ' || pin_inputTableFilter || ') ' || V_INPUT_METRIC_ALIAS;
     END IF;

   ELSE
      V_INPUT_METRIC_TABLE := pin_inputTable;
      V_AUX_VAR := INSTR(pin_inputTable,' ',1,1);
      IF PIN_SCN IS NOT NULL AND V_AUX_VAR = 0 THEN
         V_INPUT_METRIC_TABLE := REPLACE(pin_inputTable, pin_InputTableName, '('|| v_hint_loc_sel2 ||'SELECT ' || v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||') ' || pin_InputTableName);
      END IF;


      IF PIN_SCN IS NOT NULL AND V_AUX_VAR > 0 THEN
         V_INPUT_METRIC_TABLE := REPLACE(pin_inputTable, pin_InputTableName, '('|| v_hint_loc_sel2 ||'SELECT '|| v_hint_sel2 ||' * FROM '||pin_InputTableName||' AS OF SCN '||pin_SCN||')' );
      END IF;

      IF PIN_SCN IS NULL THEN
         V_INPUT_METRIC_TABLE := pin_inputTable;
      END IF;

      IF V_AUX_VAR > 0 THEN -- IF THE INPUT/METRIC TABLE NAME PARAMETER CONTAINS A SPACE CHAR, THEN IT CONTAINS ALSO THE INPUT/METRIC TABLE NAME ALIAS
         V_INPUT_METRIC_ALIAS := SUBSTR(pin_inputTable,V_AUX_VAR+1);
      ELSE -- IF THE INPUT/METRIC TABLE NAME PARAMETER DOES NOT CONTAIN A SPACE CHAR
         V_INPUT_METRIC_ALIAS := pin_inputTable;

      END IF;

   END IF;

   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   -- ADD THE MODIFIER METRIC/INPUT VALUE IN SELECT CLAUSE
   V_SELECT_CLAUSE            := 'CAST(' || V_INPUT_METRIC_ALIAS || '.' || pin_inputCol || ' AS NUMBER' || V_INPUT_METRIC_PRECISION || ') ' || V_ALIAS_NAME;

   V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || V_ALIAS_NAME;

   if V_MODIFIER_INDEX = 1 then--FVC
     V_INPUT_METRIC_VALUE       := 'CAST(COALESCE(' || V_INPUT_METRIC_ALIAS || '.' || pin_inputCol || ',0) AS NUMBER' || V_INPUT_METRIC_PRECISION || ')';
   else
     V_INPUT_METRIC_VALUE       := ' COALESCE(' || V_ALIAS_NAME || ',0) ';
   end if;

   IF pin_modifierType = 1 THEN
     V_MOD_TYPE := 'accelerator';
   ELSE
     V_MOD_TYPE := 'decelerator';

   END IF;

   -- JOIN PROCESS INPUT TABLE WITH INPUT/METRIC TABLE
    MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable       => V_INPUT_METRIC_TABLE,
                                      pin_parameterTableAlias  => V_INPUT_METRIC_ALIAS,
                                      pin_rosterTable          => V_ROSTER_TABLE_NAME,
                                      pin_inputTable           => V_INPUT_TABLE_NAME,
                                      pin_modifierIndex        => V_MODIFIER_INDEX,
                                      pin_entitiesToLog        => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                      pin_parameterAlias       => V_ALIAS_NAME,
                                      pin_additionalParameterAlias => NULL,
                                      pin_periodFilter         => NULL,
                                      pin_joinWithRoster       => NULL,
                                      pin_joinWithInput        => pin_inputJoinMap(CON_PINPUT_INP_MET_JOIN_INDEX),
                                      pin_modType              => V_MOD_TYPE,
                                      pin_modId                => 2,
                                      pin_parameterTableType   => NULL,
                                      pin_lookupTableType      => NULL,
                                      pin_MetricComponent_id   => pin_MetricComponent_id,
                                      pin_inputCol             => V_INPUT_METRIC_ALIAS || '.' || pin_inputCol,
                                      pin_calledFrom           => V_CALLED_FROM,
                                      pin_effective_date_cols  => NULL,
                                      pin_period_filter        => NULL,

                                      pio_aliasIndex           => V_ALIAS_INDEX,
                                      pio_selectClause         => V_SELECT_CLAUSE,

                                      pout_joinClause          => V_JOIN_WITH_INPUT_METRIC,
                                      pout_whenClause          => V_INPUT_METRIC_WHEN_CLAUSE,
                                      pout_Rejected_Values     => V_REJECTED_VALUES,
                                      pout_lookup_column_alias => v_alias_lookup_column,
                                      pout_period_filter       => v_period_filter);

   -- CREATE THE ALIAS OF THE THRESHOLD VALUE USED IN MODIFIERS PROCESSING
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_THRESHOLD_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   -- GET THRESHOLD SYSTEM FIELD PRECISION AND ADD THE THRESHOLD VALUE IN SELECT CLAUSE
   V_THRESHOLD_PRECISION   := COMMONS.FIELD_PRECISION_AND_SCALE(CON_THRESHOLD);
   V_SELECT_CLAUSE         := V_SELECT_CLAUSE || ',' || 'CAST(' || NVL(TO_CHAR(pin_thresholdValue),NVL(pin_thresholdTableAlias, pin_thresholdTable) || '.' || pin_thresholdCol) || ' AS NUMBER' || V_THRESHOLD_PRECISION || ') ' || V_THRESHOLD_ALIAS_NAME;
   V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || V_THRESHOLD_ALIAS_NAME;
   if V_MODIFIER_INDEX = 1 then
     V_THRESHOLD_VALUE       := 'CAST(' || NVL(TO_CHAR(pin_thresholdValue),NVL(pin_thresholdTableAlias, pin_thresholdTable) || '.' || pin_thresholdCol) || ' AS NUMBER' || V_THRESHOLD_PRECISION || ')';
   else
     V_THRESHOLD_VALUE := V_THRESHOLD_ALIAS_NAME;
   end if;
   -- PROCESS THRESHOLD TABLE
   IF pin_thresholdTable IS NOT NULL THEN
      MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable       => pin_thresholdTable,
                                        pin_parameterTableAlias  => NVL(pin_thresholdTableAlias, pin_thresholdTable),
                                        pin_rosterTable          => V_ROSTER_TABLE_NAME,
                                        pin_inputTable           => V_INPUT_TABLE_NAME,
                                        pin_modifierIndex        => V_MODIFIER_INDEX,
                                        pin_entitiesToLog        => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                        pin_parameterAlias       => V_THRESHOLD_ALIAS_NAME,
                                        pin_additionalParameterAlias => NULL,
                                        pin_periodFilter         => pin_thresholdPeriodFilter,
                                        pin_joinWithRoster       => pin_rosterJoinMap(CON_ROSTER_THRES_JOIN_INDEX),
                                        pin_joinWithInput        => VOBJ_PINPUT_THRES_JOIN,
                                        pin_modType              => V_MOD_TYPE,
                                        pin_modId                => 3,
                                        pin_parameterTableType   => 'threshold ',
                                        pin_lookupTableType      => NULL,
                                        pin_MetricComponent_id   => pin_MetricComponent_id,
                                        pin_calledFrom           => V_CALLED_FROM,
                                        pin_effective_date_cols  => pin_effective_date_cols_lhs,
                                        pin_period_filter        => v_period_filter,

                                        pio_aliasIndex           => V_ALIAS_INDEX,
                                        pio_selectClause         => V_SELECT_CLAUSE,

                                        pout_joinClause          => V_JOIN_WITH_THRESHOLD,
                                        pout_whenClause          => V_THRESHOLD_WHEN_CLAUSE,
                                        pout_Rejected_Values     => V_REJECTED_VALUES,
                                        pout_lookup_column_alias => v_alias_lookup_column,
                                        pout_period_filter       => v_period_filter);
   END IF;

   --
   IF V_MODIFIER_INDEX = 1 THEN -- IF FIRST MODIFIER,OPERATOR IS THE RESULT FIELD
      V_OPERAND := SUBSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,1,INSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,',',1,1) - 1);
      -- ADD THE ALIAS OF THE FIRST UNMODIFIED VALUE
      V_MODIFIER_VALUES_CLAUSE := V_MODIFIER_VALUES_CLAUSE || ',' || MODIFIERS.UNMODIFIED_VALUE_ALIAS;
   ELSE -- IF NOT THE FIRST MODIFIER,GET THE OPERATION OF THE LAST MODIFIER
      V_OPERAND := SUBSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,
                          INSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,';',-1)+1);
      -- DUPLICATE IN THE VALUES CLAUSE OF THE MODIFIER RESULT TABLE THE ALIAS OF THE PRECEDING MODIFIER OPERATION
      -- AS THIS IS THE UNMODIFIED VALUE FOR THE CURRENT MODIFIER
      V_MODIFIER_VALUES_CLAUSE := V_MODIFIER_VALUES_CLAUSE || ',' || SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1) + 1);
      -- REMOVE ALIAS FROM OPERAND IF IT IS THE CASE
      --FC Fix 7Mod --  V_OPERAND := SUBSTR(V_OPERAND,1,INSTR(V_OPERAND,' ',-1) - 1);
      V_OPERAND := SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1)); --FC Fix 7Mod --
   END IF;

   -- CAST THE UNMODIFIED VALUE
   V_OPERAND := 'CAST(' || V_OPERAND || ' AS NUMBER' || V_UNMODIFIED_PRECISION || ')';
   -- GET PRECISION OF THE PARAMETER VALUE AND BEGIN CREATION OF MODIFIER OPERATION
   IF pin_modifierType = 1 THEN
      V_ACC_DEC_PRECISION  := GET_PRECISION_AND_SCALE(CON_ACCELERATOR, pin_lookup_result_precision);
      V_OPERATOR := ';(CASE WHEN ' || V_INPUT_METRIC_VALUE || ' >= ' || V_THRESHOLD_VALUE || ' THEN CAST((' || V_OPERAND || ' * ';
   ELSE
      V_ACC_DEC_PRECISION  := GET_PRECISION_AND_SCALE(CON_DECELERATOR, pin_lookup_result_precision);
      V_OPERATOR := ';(CASE WHEN ' || V_INPUT_METRIC_VALUE || ' < ' || V_THRESHOLD_VALUE || ' THEN CAST((' || V_OPERAND || ' * ';

   END IF;

   -- CREATE THE ALIAS OF THE PARAMETER VALUE USED IN MODIFIERS PROCESSING
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   --
   IF pin_lookupType IS NOT NULL THEN -- IF LOOKUP TABLE IS USED
      V_MOD_ID := 1;
    --
      V_LOOKUP_FROM_CLAUSE := pin_parameterTable;
      IF pin_parameterTableFilter IS NOT NULL THEN
         V_LOOKUP_FROM_CLAUSE := V_LOOKUP_FROM_CLAUSE || ' WHERE ' || pin_parameterTableFilter;
      END IF;

      -- GET THE INPUT LOOKUP TABLE NAME TO PREFIX THE COLUMNS USED IN LOOKUP
      V_AUX_VAR := INSTR(pin_parameterTable,' INNER JOIN',1,1);
      IF V_AUX_VAR > 0 THEN -- IF JOIN IS NEEDED (ONLY IN METRIC MODIFIER PROCESSING), GET THE INPUT LOOKUP TABLE ALIAS BETWEEN FIRST AND SECOND OCCURRENCE OF SPACE CHAR
         V_PARAMETER_TABLE := SUBSTR(pin_parameterTable,INSTR(pin_parameterTable,' ',1,1)+1,INSTR(pin_parameterTable,' ',1,2)-INSTR(pin_parameterTable,' ',1,1)-1);
      ELSE
         V_AUX_VAR := INSTR(pin_parameterTable,' ',1,1);
         IF V_AUX_VAR > 0 THEN -- IF NO JOIN IS PROVIDED BUT CONTAINS SPACE CHAR, THIS MEANS THE PARAMETER CONTAINS THE INPUT LOOKUP TABLE NAME AND ALIAS
            V_PARAMETER_TABLE := SUBSTR(pin_parameterTable,V_AUX_VAR + 1);
         ELSE
            V_PARAMETER_TABLE := pin_parameterTable;

         END IF;

      END IF;

      -- If the pin_LookupInputEE is not null, the we have multiple lookup curves
      if pin_LookupInputEE is not null then

        IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
          -- For Metrics, the MCE might have Entity and the Lookup Input the BK duality or viceversa
          -- The SP below transforms the Lookup input in order to be able to acces the fields exactly as they are selected on the MCE
          -- this way the pin_LookupJoinClause and roster_join_clause will have the same fields in TAB./R. and LOOKUP. tables
          -- Returns a list of columns to be selected
          -- Returns an Input joined with all needed entity tables
          PROCESS_INPUT_LOOKUP(pin_input            => V_LOOKUP_FROM_CLAUSE
                              ,pin_input_alias      => V_PARAMETER_TABLE
                              ,pin_input_fields     => pin_LookupInputJoinMap(1).NAME1 -- The fields as they are on the Input
                              ,pin_MCE_fields       => pin_LookupInputJoinMap(1).NAME2 -- The Fields as they are on Lookup / MCE
                              ,pin_aditional_fields => pin_LookupInputJoinMap(1).NAME1 || ',' || pin_parameterCol
                              ,pout_select_list     => V_LOOKUP_INPUT_TABLE_COLS
                              ,pout_new_input       => V_LOOKUP_FROM_CLAUSE);

          V_LOOKUP_INPUT_TABLE_COLS_AL := 'TAB.' || REGEXP_REPLACE(pin_LookupInputJoinMap(1).NAME1,',',',TAB.',1,0,'i');
        end if;

        --for components there is no duality issue so just select the input join fields
        IF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
          V_LOOKUP_INPUT_TABLE_COLS    := pin_inputJoinMap(CON_PINPUT_ACC_DEC_JOIN_INDEX).NAME1;
          V_LOOKUP_INPUT_TABLE_COLS_AL := 'TAB.' || REGEXP_REPLACE(pin_inputJoinMap(CON_PINPUT_ACC_DEC_JOIN_INDEX).NAME1,',',',TAB.',1,0,'i');
        end if;

        roster_lookup_clause := ' FROM (SELECT ' || V_ROSTER_TABLE_NAME || '.* FROM ' || V_ROSTER_TABLE_NAME
                                || case when pin_LookupRosterFilter is not null then ' WHERE ' || pin_LookupRosterFilter end || ' ) R ';
        roster_join_clause   := ' ON R.' || pin_LookupInputEE || ' = TAB.' || pin_LookupInputEE;

      else
        V_LOOKUP_INPUT_TABLE_COLS    := pin_inputJoinMap(CON_PINPUT_ACC_DEC_JOIN_INDEX).NAME1;
        V_LOOKUP_INPUT_TABLE_COLS_AL := V_LOOKUP_INPUT_TABLE_COLS;
      end if;

      v_varybyfields := replace(replace(pin_LookupVaryByFields,'TAB.'),'R.');

      -- Add period filter
      if pin_LookupPeriodFilter is not null then
        v_lookupTable := ' (SELECT * FROM ' || pin_lookupTable || ' WHERE ' || pin_LookupPeriodFilter || ') ';
      else
        v_lookupTable := pin_lookupTable;
      end if;

      IF pin_lookupType = STEP_LOOKUP THEN
         V_LOOKUP_SELECT := COMPENSATION_PROCESSING.STEP_LOOKUP(pin_InputColumns      => V_PARAMETER_TABLE || '.' || REPLACE(V_LOOKUP_INPUT_TABLE_COLS, ',', ',' || V_PARAMETER_TABLE || '.'),
                                                                pin_InputColumnsAlias => V_LOOKUP_INPUT_TABLE_COLS_AL|| ', LOOKUP_COLUMN ' || con_eff_date_fields,
                                                                pin_InputFrom         => V_LOOKUP_FROM_CLAUSE,
                                                                pin_InputLookupColumn => V_PARAMETER_TABLE || '.' || pin_parameterCol,
                                                                pin_LookupTable       => v_lookupTable,
                                                                pin_LowerValueOption  => pin_LowerValueOption,
                                                                pin_HigherValueOption => pin_HigherValueOption,
                                                                pin_RosterFrom        => roster_lookup_clause,
                                                                pin_RosterJoinClause  => roster_join_clause,
                                                                pin_LookupJoinClause  => CON_EFF_DATE_JOIN,
                                                                pin_varyByFields      => CASE WHEN v_varybyfields IS NULL THEN substr(CON_EFF_DATE_VARY_BY, 2) ELSE v_varybyfields || CON_EFF_DATE_VARY_BY END
                                                                );
      ELSIF pin_lookupType = CONTINUOUS_LOOKUP THEN
         V_LOOKUP_SELECT := COMPENSATION_PROCESSING.CONTINUOUS_LOOKUP(pin_InputColumns      => V_PARAMETER_TABLE || '.' || REPLACE(V_LOOKUP_INPUT_TABLE_COLS, ',', ',' || V_PARAMETER_TABLE || '.'),
                                                                      pin_InputColumnsAlias => V_LOOKUP_INPUT_TABLE_COLS_AL|| ', LOOKUP_COLUMN ' || con_eff_date_fields,
                                                                      pin_InputFrom         => V_LOOKUP_FROM_CLAUSE,
                                                                      pin_InputLookupColumn => V_PARAMETER_TABLE || '.' || pin_parameterCol,
                                                                      pin_LookupTable       => v_lookupTable,
                                                                      pin_LowerValueOption  => pin_LowerValueOption,
                                                                      pin_HigherValueOption => pin_HigherValueOption,
                                                                      pin_RosterFrom        => roster_lookup_clause,
                                                                      pin_RosterJoinClause  => roster_join_clause,
                                                                      pin_LookupJoinClause  => CON_EFF_DATE_JOIN,
                                                                      pin_varyByFields      => CASE WHEN v_varybyfields IS NULL THEN substr(CON_EFF_DATE_VARY_BY, 2) ELSE v_varybyfields || CON_EFF_DATE_VARY_BY END
                                                                      );

      ELSIF pin_lookupType = DISCRETE_LOOKUP THEN
         V_LOOKUP_SELECT := COMPENSATION_PROCESSING.DISCRETE_LOOKUP(pin_InputColumns      => V_PARAMETER_TABLE || '.' || REPLACE(V_LOOKUP_INPUT_TABLE_COLS, ',', ',' || V_PARAMETER_TABLE || '.'),
                                                                    pin_InputColumnsAlias => V_LOOKUP_INPUT_TABLE_COLS_AL || ', LOOKUP_COLUMN ' || con_eff_date_fields,
                                                                    pin_InputFrom         => V_LOOKUP_FROM_CLAUSE,
                                                                    pin_InputLookupColumn => V_PARAMETER_TABLE || '.' || pin_parameterCol,
                                                                    pin_LookupTable       => v_lookupTable,
                                                                    pin_RosterFrom        => roster_lookup_clause,
                                                                    pin_RosterJoinClause  => roster_join_clause,
                                                                    pin_LookupJoinClause  => CON_EFF_DATE_JOIN,
                                                                    pin_varyByFields      => CASE WHEN v_varybyfields IS NULL THEN substr(CON_EFF_DATE_VARY_BY, 2) ELSE v_varybyfields || CON_EFF_DATE_VARY_BY END
                                                                    );

      END IF;

      --
      V_PARAMETER_TABLE       := '(' || V_LOOKUP_SELECT || ') T' || TO_CHAR(V_MODIFIER_INDEX);
      V_PARAMETER_TABLE_ALIAS := 'T' || TO_CHAR(V_MODIFIER_INDEX);
      V_PARAMETER_COL         := 'T' || TO_CHAR(V_MODIFIER_INDEX) || '.RESULT_VALUE';
      V_PARAMETER_TABLE_TYPE  := NULL;
      IF pin_modifierType = 1 THEN
         V_LOOKUP_TABLE_TYPE     := 'accelerator';
      ELSE
         V_LOOKUP_TABLE_TYPE     := 'decelerator';

      END IF;

   ELSIF pin_parameterTable IS NOT NULL THEN -- IF PARAMETER TABLE IS USED
    V_MOD_ID := 3;
      V_PARAMETER_TABLE       := pin_parameterTable;
      V_PARAMETER_TABLE_ALIAS := NVL(pin_parameterTableAlias, pin_parameterTable);
      V_PARAMETER_COL         := NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol;
       IF pin_modifierType = 1 THEN
         V_PARAMETER_TABLE_TYPE     := 'accelerator';
      ELSE
         V_PARAMETER_TABLE_TYPE     := 'decelerator';

      END IF;

      V_LOOKUP_TABLE_TYPE  := NULL;

   END IF;

   -- ADD THE PARAMETER VALUE IN SELECT CLAUSE
   V_SELECT_CLAUSE            := V_SELECT_CLAUSE || ',' || 'CAST(' || CASE WHEN pin_lookup_result_precision IS NULL THEN '' ELSE 'CAST(' END || NVL(TO_CHAR(pin_parameterValue),V_PARAMETER_COL) || CASE WHEN pin_lookup_result_precision IS NULL THEN '' ELSE ' AS NUMBER' || FIELD_PREC_AND_SCALE(pin_lookup_result_precision) || ')' END ||' AS NUMBER' || COMMONS.FIELD_PRECISION_AND_SCALE(CON_MODIFIER) || ') ' || V_ALIAS_NAME;
   V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || V_ALIAS_NAME;
   if V_MODIFIER_INDEX =1 then
     V_PARAMETER_VALUE        := 'CAST(COALESCE(' || NVL(TO_CHAR(pin_parameterValue),V_PARAMETER_COL) || ', 1) AS NUMBER' || CASE WHEN pin_lookup_result_precision IS NULL THEN V_ACC_DEC_PRECISION ELSE FIELD_PREC_AND_SCALE(pin_lookup_result_precision) END || ')';
   else
     V_PARAMETER_VALUE        := 'COALESCE(' || V_ALIAS_NAME || ', 1)';
   end if;
   -- PROCESS PARAMETER TABLE
   IF pin_parameterTable IS NOT NULL THEN
      MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable       => V_PARAMETER_TABLE,
                                        pin_parameterTableAlias  => V_PARAMETER_TABLE_ALIAS,
                                        pin_rosterTable          => V_ROSTER_TABLE_NAME,
                                        pin_inputTable           => V_INPUT_TABLE_NAME,
                                        pin_modifierIndex        => V_MODIFIER_INDEX,
                                        pin_entitiesToLog        => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                        pin_parameterAlias       => V_ALIAS_NAME,
                                        pin_additionalParameterAlias => CASE WHEN pin_thresholdValue IS NULL THEN V_THRESHOLD_ALIAS_NAME ELSE NULL END,
                                        pin_periodFilter         => pin_parameterPeriodFilter,
                                        pin_joinWithRoster       => case when VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE and pin_lookupType IS NOT null then null else pin_rosterJoinMap(CON_ROSTER_ACC_DEC_JOIN_INDEX) end, -- For COMPONENT Lookups the join is done on ECE
                                        pin_joinWithInput        => VOBJ_PINPUT_ACC_DEC_JOIN,
                                        pin_modType              => V_MOD_TYPE,
                                        pin_modId                => V_MOD_ID,
                                        pin_parameterTableType   => case WHEN pin_thresholdTable IS NULL THEN V_PARAMETER_TABLE_TYPE ELSE 'threshold' END,
                                        pin_lookupTableType      => V_LOOKUP_TABLE_TYPE,
                                        pin_MetricComponent_id   => pin_MetricComponent_id,
                                        pin_inputCol             => 'LOOKUP_COLUMN,RESULT_VALUE,VLD_NO_LKCURVES',
                                        pin_calledFrom           => V_CALLED_FROM,
                                        pin_effective_date_cols  => NVL(pin_effective_date_cols_lookup, pin_effective_date_cols_rhs),
                                        pin_period_filter        => v_period_filter,

                                        pio_aliasIndex           => V_ALIAS_INDEX,
                                        pio_selectClause         => V_SELECT_CLAUSE,

                                        pout_joinClause          => V_JOIN_WITH_PARAM_TAB,
                                        pout_whenClause          => V_PARAMETER_WHEN_CLAUSE,
                                        pout_Rejected_Values     => V_REJECTED_VALUES,
                                        pout_lookup_column_alias => v_alias_lookup_column,
                                        pout_period_filter       => v_period_filter);
   END IF;

   IF pin_lookupType IS NOT NULL THEN -- IF LOOKUP TABLE IS USED add the lookup_column  in the VALUES clause
      V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || v_alias_lookup_column;
   END IF;
   -- CREATE ALIAS FOR MODIFIER OPERATION
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   -- COMPLETE MODIFIER OPERATION AND ADD IT TO SELECT CLAUSE AND VALUES CLAUSE
   V_OPERATOR := V_OPERATOR || V_PARAMETER_VALUE || ') AS NUMBER' || V_PRECISION || ') ELSE CAST((' || V_OPERAND || ') AS NUMBER' || V_PRECISION || ') END) ' || V_ALIAS_NAME;
   V_SELECT_CLAUSE := V_SELECT_CLAUSE || V_OPERATOR;
   -- ADD ALIAS TO BE USED IN VALUES CLAUSE WHEN INSERTING IN MODIFIER RESULT TABLE
   -- REMOVE FIRST COMMA
   V_MODIFIER_VALUES_CLAUSE := SUBSTR(V_MODIFIER_VALUES_CLAUSE,2) || ',' || V_ALIAS_NAME;
   --
   /*IF pin_inputTableFilter IS NOT NULL THEN
      V_WHERE_CLAUSE := pin_inputTableFilter;
   END IF;*/

   --
   V_JOIN_CLAUSE := V_JOIN_WITH_ROSTER || V_JOIN_WITH_INPUT_METRIC || V_JOIN_WITH_THRESHOLD || V_JOIN_WITH_PARAM_TAB;
   V_WHEN_CLAUSE := V_INPUT_METRIC_WHEN_CLAUSE || V_THRESHOLD_WHEN_CLAUSE || V_PARAMETER_WHEN_CLAUSE;
   --
   MODIFIERS.LOG_AND_RETURN_PARAMETERS(pin_stamp               => V_STAMP,
                                       pin_Select_Clause       => V_SELECT_CLAUSE,
                                       pin_From_Clause         => V_JOIN_CLAUSE,
                                       pin_Where_Clause        => V_WHERE_CLAUSE,
                                       pin_When_Clause         => V_WHEN_CLAUSE,
                                       pin_Modifier_Operations => V_MODIFIER_VALUES_CLAUSE,
                                       pin_Module              => VOBJ_AUX_CLAUSE.MODULE,
                                       pout_Aux_Clause         => VOBJ_AUX_CLAUSE);
   --
   VCOL_CLAUSES.EXTEND;
   VCOL_CLAUSES(V_MODIFIER_INDEX+1) := VOBJ_AUX_CLAUSE;
   --

   RETURN VCOL_CLAUSES;
END MODIFIER_ACC_DEC;

------------------------

FUNCTION MODIFIER_FAC_ADD_SUB_MUL_DIV(pin_clauses                    IN       tabletype_modifier_clauses
                                     ,pin_modifierType               IN       NUMBER
                                     ,pin_lookupType                 IN       NUMBER
                                     ,pin_lookupTable                IN       VARCHAR2
                                     ,pin_LowerValueOption           IN       NUMBER
                                     ,pin_HigherValueOption          IN       NUMBER
                                     ,pin_parameterValue             IN       NUMBER
                                     ,pin_parameterTable             IN       VARCHAR2
                                     ,pin_parameterTableAlias        IN       VARCHAR2
                                     ,pin_parameterCol               IN       VARCHAR2
                                     ,pin_parameterPeriodFilter      IN       CLOB
                                     ,pin_inputJoinMap               IN       tabletype_name_join_map
                                     ,pin_rosterJoinMap              IN       tabletype_name_join_map
                                     ,pin_parameterTableFilter       IN       varchar2
                                     ,pin_MetricComponent_id         IN       NUMBER default null
                                     ,pin_LookupInputJoinMap         IN       tabletype_name_join_map default null
                                     ,pin_LookupJoinClause           in       varchar2 default null
                                     ,pin_LookupVaryByFields         in       varchar2 default null
                                     ,pin_LookupInputEE              in       varchar2 default null
                                     ,pin_LookupRosterFilter         in       varchar2 default null --
                                     ,pin_LookupPeriodFilter         in       clob default null --
                                     ,pin_effective_date_cols_lhs    IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL
                                     ,pin_effective_date_cols_lookup IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL
                                     ,pin_lookup_date_field          IN       VARCHAR2 DEFAULT NULL
                                     ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                                     ,pin_lookup_value_precision     IN       VARCHAR2 DEFAULT NULL
                                     ,pin_lookup_result_precision    IN       VARCHAR2 DEFAULT NULL
                                     ,pin_metricInputTable           IN       varchar2           default null
                                     ,pin_metricInputSequence        in       varchar2           default null
                                     ,pin_lookupInputFields          IN       tabletype_name_map default null
                                     ,pin_lookupFilterFields         IN       tabletype_name_map default null
                                     ,pin_lookupConstants            IN       tabletype_name_map default null
                                     )
RETURN TABLETYPE_MODIFIER_CLAUSES
IS

   CON_EFF_DATE_FIELDS           CONSTANT VARCHAR2(70) := CASE WHEN pin_effective_date_cols_lookup IS NULL THEN '' ELSE ', LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 END;
   CON_EFF_DATE_VARY_BY          CONSTANT VARCHAR2(70) := CASE WHEN pin_effective_date_cols_lookup IS NULL THEN '' ELSE ', ' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', ' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 END;
   CON_EFF_DATE_JOIN             CONSTANT VARCHAR2(2000) :=
                        CASE WHEN pin_LookupJoinClause IS NULL THEN
                          CASE WHEN pin_effective_date_cols_lookup IS NOT NULL THEN
                          ' LOOKUP ON ' || CASE WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS = 'R' THEN
                                  'R.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS IN ('I', 'TAB') THEN
                                   'TAB.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  ELSE NULL
                                  END
                           ELSE NULL
                           END
                        ELSE
                          pin_LookupJoinClause || CASE WHEN pin_effective_date_cols_lookup IS NOT NULL THEN
                             CASE WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS = 'R' THEN
                                  ' AND R.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  WHEN pin_effective_date_cols_lookup.RELATIONSHIP_TABLE_ALIAS IN ('I', 'TAB') THEN
                                   ' AND TAB.' || NVL(pin_lookup_date_field, pin_effective_date_cols_lookup.ENTITY_COLUMN_NAME) || ' BETWEEN
                                    NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(' || CON_START_DATE || ', ' || CON_DATE_FORMAT || '))
                                  AND NVL(LOOKUP.' || pin_effective_date_cols_lookup.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(' || CON_END_DATE || ', ' || CON_DATE_FORMAT || ')) '
                                  ELSE NULL
                                  END
                           ELSE NULL
                           END
                        END;

   V_LOOKUP_SELECT               CLOB;
   V_LOOKUP_FROM_CLAUSE          CLOB;
   VCOL_CLAUSES                  TABLETYPE_MODIFIER_CLAUSES;
   VOBJ_AUX_CLAUSE               OBJTYPE_MODIFIER_CLAUSES;
   V_MODIFIER_VALUES_CLAUSE      CLOB;
   --
   V_SELECT_CLAUSE               CLOB;
   V_JOIN_CLAUSE                 CLOB;
   V_WHEN_CLAUSE                 CLOB;
   --
   V_JOIN_WITH_ROSTER            CLOB;
   V_JOIN_WITH_PARAM_TAB         CLOB;
   --
   V_PARAMETER_WHEN_CLAUSE       CLOB;
   --
   V_OPERATOR                    VARCHAR2(30);
   V_OPERAND                     CLOB;
   V_MODIFIER_OPERATION          VARCHAR2(2000);
   V_LOOKUP_INPUT_TABLE_COLS     CLOB;
   V_ALIAS_INDEX                 PLS_INTEGER := 0;
   V_ALIAS_NAME                  VARCHAR2(30);
   V_MODIFIER_INDEX              PLS_INTEGER;
   V_INPUT_TABLE_NAME            CLOB;
   V_ROSTER_TABLE_NAME           CLOB;
   --
   CON_FACTOR                    CONSTANT VARCHAR2(50) := 'FACTOR';
   CON_MODIFIER_VALUE            CONSTANT VARCHAR2(50) := 'MODIFIER_VALUE';
   CON_MODIFIER                  CONSTANT VARCHAR2(50) := 'MODIFIER';
   --
   V_PRECISION                   VARCHAR2(30);
   V_PARAMETER_PRECISION         VARCHAR2(30);
   V_UNMODIFIED_PRECISION        VARCHAR2(30);
   --
   V_PARAMETER_VALUE             CLOB;
   V_PARAMETER_TABLE             CLOB;
   V_PARAMETER_TABLE_ALIAS       VARCHAR2(30);
   V_PARAMETER_COL               CLOB;
   VOBJ_PINPUT_PARAM_JOIN        objtype_name_join_map;
   --
   CON_PINPUT_ROSTER_JOIN_INDEX          CONSTANT PLS_INTEGER := 1;
   CON_PINPUT_PARAM_JOIN_INDEX           CONSTANT PLS_INTEGER := 2;
   CON_ROSTER_PARAM_JOIN_INDEX           CONSTANT PLS_INTEGER := 1;
   --
   V_AUX_VAR                     PLS_INTEGER;   -- USED FOR VARIOUS VALUES LIKE INSTR(STR1,STR2)
   V_MOD_TYPE                    VARCHAR2(30);
   V_MOD_ID                      PLS_INTEGER;
   V_AUX_WHEN_1310               CLOB;
   V_REJECTED_VALUES             CLOB;
   V_PARAMETER_TABLE_TYPE        VARCHAR2(30);
   V_LOOKUP_TABLE_TYPE           VARCHAR2(30);
-- FUNCTION/PROCEDURE NR 1
    v_stamp            VARCHAR2(250);
   V_CALLED_FROM PLS_INTEGER;
   V_ALIAS_LOOKUP_COLUMN VARCHAR2(30);

   -- Lookups that varyby
   V_LOOKUP_INPUT_TABLE_COLS_AL  CLOB;
   roster_lookup_clause   VARCHAR2(4000 CHAR);
   roster_join_clause      VARCHAR2(4000 CHAR);
   v_varybyfields VARCHAR2(4000 CHAR);
   v_lookupTable clob;

   v_period_filter BOOLEAN;

BEGIN

  v_stamp := 'MODIFIERS.MODIFIER_FAC_ADD_SUB_MUL_DIV - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_CLAUSES),           ',PIN_CLAUSES                 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERTYPE),          ',PIN_MODIFIERTYPE            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LOOKUPTYPE),            ',PIN_LOOKUPTYPE              => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LOOKUPTABLE),         ',PIN_LOOKUPTABLE             => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LOWERVALUEOPTION),      ',PIN_LOWERVALUEOPTION        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_HIGHERVALUEOPTION),     ',PIN_HIGHERVALUEOPTION       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_PARAMETERVALUE),        ',PIN_PARAMETERVALUE          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLE),      ',PIN_PARAMETERTABLE          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEALIAS), ',PIN_PARAMETERTABLEALIAS     => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERCOL),        ',PIN_PARAMETERCOL            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_PARAMETERPERIODFILTER),   ',PIN_PARAMETERPERIODFILTER   => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_INPUTJOINMAP),      ',PIN_INPUTJOINMAP            => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_ROSTERJOINMAP),     ',PIN_ROSTERJOINMAP           => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEFILTER),',PIN_PARAMETERTABLEFILTER    => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),    ',PIN_METRICCOMPONENT_ID      => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_LookupInputJoinMap),      ',pin_LookupInputJoinMap                => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupJoinClause),',pin_LookupJoinClause        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupVaryByFields),',pin_LookupVaryByFields        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupInputEE),',pin_LookupInputEE        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupRosterFilter),',pin_LookupRosterFilter        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_LookupPeriodFilter),   ',pin_LookupPeriodFilter       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols_lhs),     ',pin_effective_date_cols_lhs => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols_lookup),  ',pin_effective_date_cols_lookup => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_precision),     ',pin_lookup_precision    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_value_precision),',pin_lookup_value_precision    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_result_precision),',pin_lookup_result_precision    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metricInputTable),        ',pin_metricInputTable          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupFilterFields),    ',pin_lookupFilterFields        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupInputFields),     ',pin_lookupInputFields         => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookupConstants),       ',pin_lookupConstants           => <value>', v_stamp);
 END;

   -- VALIDATIONS
   IF pin_modifierType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_modifierType parameter can not be null');
   END IF;

   --
   IF pin_parameterValue IS NOT NULL AND pin_parameterTable IS NOT NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_parameterValue and pin_parameterTable parameters can not be both not null');
   END IF;

   --
   IF pin_modifierType NOT IN (1,2,3,4,5) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid value for pin_modifierType parameter');
   END IF;

   --
   VCOL_CLAUSES            := pin_clauses;
   VOBJ_AUX_CLAUSE         := VCOL_CLAUSES(1);
   -- GET MODIFIER INDEX
   V_MODIFIER_INDEX     := VCOL_CLAUSES.COUNT;
   -- GET THE ROSTER TABLE NAME
   V_ROSTER_TABLE_NAME := pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME3;
   -- GET THE PROCESSING INPUT TABLE NAME
   V_INPUT_TABLE_NAME := VOBJ_AUX_CLAUSE.FROM_CLAUSE;
   -- GET THE PRECISION OF THE MODIFIED VALUE AND UNMODIFIED VALUE
   IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
      V_PRECISION                := GET_PRECISION_AND_SCALE(MODIFIERS.METRIC, pin_lookup_precision);
      V_UNMODIFIED_PRECISION     := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.UNMODIFIED_METRIC);
      V_CALLED_FROM := 1;
   ELSIF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
      V_PRECISION                := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.MODIFIED_EARNINGS);
      V_UNMODIFIED_PRECISION     := COMMONS.FIELD_PRECISION_AND_SCALE(MODIFIERS.UNMODIFIED_EARNINGS);
      V_CALLED_FROM :=2;
   END IF;

    -- GET THE JOIN BETWEEN PROCESS INPUT AND THRESHOLD TABLE AND PROCESS INPUT AND ACCELERATOR/DECELERATOR TABLE
    VOBJ_PINPUT_PARAM_JOIN        := pin_inputJoinMap(CON_PINPUT_PARAM_JOIN_INDEX);

   -- JOIN PROCESS INPUT TABLE WITH ROSTER TABLE
   IF pin_inputJoinMap IS NOT NULL AND
      pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME1 IS NOT NULL AND
      pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME2 IS NOT NULL
   THEN
      V_JOIN_WITH_ROSTER := ' LEFT JOIN ' || V_ROSTER_TABLE_NAME || ' ON ' || V_ROSTER_TABLE_NAME || '.' || pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME1 || '=' || V_INPUT_TABLE_NAME || '.' || pin_inputJoinMap(CON_PINPUT_ROSTER_JOIN_INDEX).NAME2;
   END IF;

   --
   IF V_MODIFIER_INDEX = 1 THEN -- IF FIRST MODIFIER,OPERATOR IS THE RESULT FIELD
      V_OPERAND := SUBSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,1,INSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,',',1,1) - 1);
      -- ADD THE ALIAS OF THE FIRST UNMODIFIED VALUE
      V_MODIFIER_VALUES_CLAUSE := V_MODIFIER_VALUES_CLAUSE || ',' || MODIFIERS.UNMODIFIED_VALUE_ALIAS;
   ELSE -- IF NOT THE FIRST MODIFIER,GET THE OPERATION OF THE LAST MODIFIER
      V_OPERAND := SUBSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,
                          INSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,';',-1)+1);
      -- DUPLICATE IN THE VALUES CLAUSE OF THE MODIFIER RESULT TABLE THE ALIAS OF THE PRECEDING MODIFIER OPERATION
      -- AS THIS IS THE UNMODIFIED VALUE FOR THE CURRENT MODIFIER
      V_MODIFIER_VALUES_CLAUSE := V_MODIFIER_VALUES_CLAUSE || ',' || SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1) + 1);
      -- REMOVE ALIAS FROM OPERAND IF IT IS THE CASE
      --FC Fix 7Mod --V_OPERAND := SUBSTR(V_OPERAND,1,INSTR(V_OPERAND,' ',-1) - 1);
      V_OPERAND := SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1)); --FC Fix 7Mod --
   END IF;

   -- CAST THE UNMODIFIED VALUE
   V_OPERAND := 'CAST(' || V_OPERAND || ' AS NUMBER' || V_UNMODIFIED_PRECISION || ')';
   -- GET PRECISION OF THE PARAMETER VALUE AND BEGIN CREATION OF MODIFIER OPERATION
   IF pin_modifierType = 1 THEN -- IF FACTOR MODIFIER
      V_PARAMETER_PRECISION  := GET_PRECISION_AND_SCALE(CON_FACTOR, pin_lookup_result_precision);
      V_OPERATOR := '*';
      V_MOD_TYPE := 'factor';

   ELSE -- IF ADD,SUBTRACT,MULTIPLY OR DIVIDE
      V_PARAMETER_PRECISION  := GET_PRECISION_AND_SCALE(CON_MODIFIER_VALUE, pin_lookup_result_precision);
      IF pin_modifierType = 2 THEN -- ADD MODIFIER
         V_OPERATOR := '+';
         IF V_CALLED_FROM = 1 THEN -- METRICS
            V_MOD_TYPE := 'add';
         ELSE -- COMPONENTS
            V_MOD_TYPE := 'adjustment';
         END IF;
      ELSIF pin_modifierType = 3 THEN -- SUBTRACT MODIFIER
         V_OPERATOR := '-';
         V_MOD_TYPE := 'subtract';

      ELSIF pin_modifierType = 4 THEN -- MULTIPLY MODIFIER
         V_OPERATOR := '*';
         V_MOD_TYPE := 'multiplier';

      ELSIF pin_modifierType = 5 THEN -- DIVIDE MODIFIER
         V_OPERATOR := '/';
         V_MOD_TYPE := 'divide';

      END IF;

   END IF;

   -- CREATE THE ALIAS OF THE PARAMETER VALUE USED IN MODIFIERS PROCESSING
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   --
   IF pin_lookupType IS NOT NULL THEN -- IF LOOKUP TABLE IS USED
      --
      V_LOOKUP_FROM_CLAUSE := pin_parameterTable;
      IF pin_parameterTableFilter IS NOT NULL THEN
         V_LOOKUP_FROM_CLAUSE := V_LOOKUP_FROM_CLAUSE || ' WHERE ' || pin_parameterTableFilter;
      END IF;

      -- GET THE INPUT LOOKUP TABLE NAME TO PREFIX THE COLUMNS USED IN LOOKUP
      V_AUX_VAR := INSTR(pin_parameterTable,' INNER JOIN',1,1);
      IF V_AUX_VAR > 0 THEN -- IF JOIN IS NEEDED (ONLY IN METRIC MODIFIER PROCESSING), GET THE INPUT LOOKUP TABLE ALIAS BETWEEN FIRST AND SECOND OCCURRENCE OF SPACE CHAR
         V_PARAMETER_TABLE := SUBSTR(pin_parameterTable,INSTR(pin_parameterTable,' ',1,1)+1,INSTR(pin_parameterTable,' ',1,2)-INSTR(pin_parameterTable,' ',1,1)-1);
      ELSE
         V_AUX_VAR := INSTR(pin_parameterTable,' ',1,1);
         IF V_AUX_VAR > 0 THEN -- IF NO JOIN IS PROVIDED BUT CONTAINS SPACE CHAR, THIS MEANS THE PARAMETER CONTAINS THE INPUT LOOKUP TABLE NAME AND ALIAS
            V_PARAMETER_TABLE := SUBSTR(pin_parameterTable,V_AUX_VAR + 1);
         ELSE
            V_PARAMETER_TABLE := pin_parameterTable;

         END IF;

      END IF;

      if pin_LookupInputEE is not null then -- Null when lookup does not vary
          -- For Metrics, the MCE might have Entity and the Lookup Input the BK duality or viceversa
          -- The SP below transforms the Lookup input in order to be able to acces the fields exactly as they are selected on the MCE
          -- this way the pin_LookupJoinClause and roster_join_clause will have the same fields in TAB./R. and LOOKUP. tables
          -- Returns a list of columns to be selected
          -- Returns an Input joined with all needed entity tables
        IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
          PROCESS_INPUT_LOOKUP(pin_input            => V_LOOKUP_FROM_CLAUSE
                              ,pin_input_alias      => V_PARAMETER_TABLE
                              ,pin_input_fields     => pin_LookupInputJoinMap(1).NAME1 -- The fields as they are on the Input
                              ,pin_MCE_fields       => pin_LookupInputJoinMap(1).NAME2 -- The Fields as they are on Lookup / MCE
                              ,pin_aditional_fields => pin_LookupInputJoinMap(1).NAME1 || ',' || pin_parameterCol
                              ,pout_select_list     => V_LOOKUP_INPUT_TABLE_COLS
                              ,pout_new_input       => V_LOOKUP_FROM_CLAUSE);

          V_LOOKUP_INPUT_TABLE_COLS_AL := 'TAB.' || REGEXP_REPLACE(pin_LookupInputJoinMap(1).NAME1,',',',TAB.',1,0,'i');
        end if;

        --for components there is no duality issue, so just select the input join fields
        IF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
          V_LOOKUP_INPUT_TABLE_COLS    := pin_inputJoinMap(CON_PINPUT_PARAM_JOIN_INDEX).NAME1;
          V_LOOKUP_INPUT_TABLE_COLS_AL := 'TAB.' || REGEXP_REPLACE(pin_inputJoinMap(CON_PINPUT_PARAM_JOIN_INDEX).NAME1,',',',TAB.',1,0,'i');
        end if;


        roster_lookup_clause := ' FROM (SELECT ' || V_ROSTER_TABLE_NAME || '.* FROM ' || V_ROSTER_TABLE_NAME
                                || case when pin_LookupRosterFilter is not null then ' WHERE ' || pin_LookupRosterFilter end || ' ) R ';
        roster_join_clause   := ' ON R.' || pin_LookupInputEE || ' = TAB.' || pin_LookupInputEE;

      else
         V_LOOKUP_INPUT_TABLE_COLS    := pin_inputJoinMap(CON_PINPUT_PARAM_JOIN_INDEX).NAME1;
         V_LOOKUP_INPUT_TABLE_COLS_AL := V_LOOKUP_INPUT_TABLE_COLS;
      end if;


      --
      v_varybyfields := replace(replace(pin_LookupVaryByFields,'TAB.'),'R.');

      -- Add period filter
      if pin_LookupPeriodFilter is not null then
        v_lookupTable := ' (SELECT * FROM ' || pin_lookupTable || ' WHERE ' || pin_LookupPeriodFilter || ') ' /*|| pin_lookupTable*/;
      else
        v_lookupTable := pin_lookupTable;
      end if;

      IF pin_lookupType = STEP_LOOKUP THEN
         V_LOOKUP_SELECT := COMPENSATION_PROCESSING.STEP_LOOKUP(pin_InputColumns => V_PARAMETER_TABLE || '.' || REPLACE(V_LOOKUP_INPUT_TABLE_COLS, ',', ',' || V_PARAMETER_TABLE || '.'),
                                                                pin_InputColumnsAlias => V_LOOKUP_INPUT_TABLE_COLS_AL|| ', LOOKUP_COLUMN ' || CON_EFF_DATE_FIELDS,
                                                                pin_InputFrom => V_LOOKUP_FROM_CLAUSE,
                                                                pin_InputLookupColumn => V_PARAMETER_TABLE || '.' || pin_parameterCol,
                                                                pin_LookupTable => v_lookupTable,
                                                                pin_LowerValueOption => pin_LowerValueOption,
                                                                pin_HigherValueOption => pin_HigherValueOption,
                                                                pin_RosterFrom        => roster_lookup_clause,
                                                                pin_RosterJoinClause  => roster_join_clause,
                                                                pin_LookupJoinClause  => CON_EFF_DATE_JOIN,
                                                                pin_varyByFields      => CASE WHEN v_varybyfields IS NULL THEN substr(CON_EFF_DATE_VARY_BY, 2) ELSE v_varybyfields || CON_EFF_DATE_VARY_BY END);
      ELSIF pin_lookupType = CONTINUOUS_LOOKUP THEN
         V_LOOKUP_SELECT := COMPENSATION_PROCESSING.CONTINUOUS_LOOKUP(pin_InputColumns => V_PARAMETER_TABLE || '.' || REPLACE(V_LOOKUP_INPUT_TABLE_COLS, ',', ',' || V_PARAMETER_TABLE || '.'),
                                                                      pin_InputColumnsAlias => V_LOOKUP_INPUT_TABLE_COLS_AL|| ', LOOKUP_COLUMN ' || CON_EFF_DATE_FIELDS,
                                                                      pin_InputFrom => V_LOOKUP_FROM_CLAUSE,
                                                                      pin_InputLookupColumn => V_PARAMETER_TABLE || '.' || pin_parameterCol,
                                                                      pin_LookupTable => v_lookupTable,
                                                                      pin_LowerValueOption => pin_LowerValueOption,
                                                                      pin_HigherValueOption => pin_HigherValueOption,
                                                                      pin_RosterFrom        => roster_lookup_clause,
                                                                      pin_RosterJoinClause  => roster_join_clause,
                                                                      pin_LookupJoinClause  => CON_EFF_DATE_JOIN,
                                                                      pin_varyByFields      => CASE WHEN v_varybyfields IS NULL THEN substr(CON_EFF_DATE_VARY_BY, 2) ELSE v_varybyfields || CON_EFF_DATE_VARY_BY END);

      ELSIF pin_lookupType = DISCRETE_LOOKUP THEN
         V_LOOKUP_SELECT := COMPENSATION_PROCESSING.DISCRETE_LOOKUP(pin_InputColumns => V_PARAMETER_TABLE || '.' || REPLACE(V_LOOKUP_INPUT_TABLE_COLS, ',', ',' || V_PARAMETER_TABLE || '.'),
                                                                    pin_InputColumnsAlias => V_LOOKUP_INPUT_TABLE_COLS_AL|| ', LOOKUP_COLUMN ' || CON_EFF_DATE_FIELDS,
                                                                    pin_InputFrom => V_LOOKUP_FROM_CLAUSE,
                                                                    pin_InputLookupColumn => V_PARAMETER_TABLE || '.' || pin_parameterCol,
                                                                    pin_LookupTable => v_lookupTable,
                                                                    pin_RosterFrom        => roster_lookup_clause,
                                                                    pin_RosterJoinClause  => roster_join_clause,
                                                                    pin_LookupJoinClause  => CON_EFF_DATE_JOIN,
                                                                    pin_varyByFields      => CASE WHEN v_varybyfields IS NULL THEN substr(CON_EFF_DATE_VARY_BY, 2) ELSE v_varybyfields || CON_EFF_DATE_VARY_BY END);

      END IF;

      --
      V_PARAMETER_TABLE       := '(' || V_LOOKUP_SELECT || ') T' || TO_CHAR(V_MODIFIER_INDEX);
      V_PARAMETER_TABLE_ALIAS := 'T' || TO_CHAR(V_MODIFIER_INDEX);
      V_PARAMETER_COL         := 'T' || TO_CHAR(V_MODIFIER_INDEX) || '.RESULT_VALUE';

      -- ADD LOOKUP COLUMN IN THE SELECT CLAUSE
     --V_SELECT_CLAUSE            :=  V_PARAMETER_TABLE_ALIAS ||'.LOOKUP_COLUMN AS '|| V_ALIAS_NAME ||',';
     --V_MODIFIER_VALUES_CLAUSE   :=  V_MODIFIER_VALUES_CLAUSE || ',' || V_ALIAS_NAME;

     V_MOD_ID := 1;
     V_PARAMETER_TABLE_TYPE := NULL;
     V_LOOKUP_TABLE_TYPE := 'value';
     --V_AUX_WHEN_1310 := ' WHEN ' || V_ALIAS_NAME || ' IS NOT NULL AND ';
   --  V_PARAMETER_VALUE          := 'CAST(' || NVL(TO_CHAR(pin_parameterValue),V_PARAMETER_COL) || ' AS NUMBER' || V_PARAMETER_PRECISION || ')';
   ELSIF pin_parameterTable IS NOT NULL THEN -- IF PARAMETER TABLE IS USED
      V_PARAMETER_TABLE       := pin_parameterTable;
      V_PARAMETER_TABLE_ALIAS := NVL(pin_parameterTableAlias, pin_parameterTable);
      V_PARAMETER_COL         := NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol;
      V_MOD_ID                := 3;
      V_PARAMETER_TABLE_TYPE := 'value';
      V_LOOKUP_TABLE_TYPE := NULL;

   END IF;

   -- ADD THE PARAMETER VALUE IN SELECT CLAUSE
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   V_SELECT_CLAUSE            := V_SELECT_CLAUSE || 'CAST(' || CASE WHEN pin_lookup_result_precision IS NULL THEN '' ELSE 'CAST(' END || NVL(TO_CHAR(pin_parameterValue),V_PARAMETER_COL) || CASE WHEN pin_lookup_result_precision IS NULL THEN '' ELSE ' AS NUMBER' || FIELD_PREC_AND_SCALE(pin_lookup_result_precision) || ')' END ||' AS NUMBER' || COMMONS.FIELD_PRECISION_AND_SCALE(CON_MODIFIER) || ') ' || V_ALIAS_NAME;
   V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || V_ALIAS_NAME;
   if V_MODIFIER_INDEX = 1 then --FVC
     V_PARAMETER_VALUE          := 'CAST(' || NVL(TO_CHAR(pin_parameterValue),V_PARAMETER_COL) || ' AS NUMBER' || CASE WHEN pin_lookup_result_precision IS NULL THEN V_PARAMETER_PRECISION ELSE FIELD_PREC_AND_SCALE(pin_lookup_result_precision) END || ')';
   else
     V_PARAMETER_VALUE := V_ALIAS_NAME;
   end if;                        --FVC

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_parameter_value),',v_parameter_value    => <value>' , v_stamp);

   -- PROCESS PARAMETER TABLE
   IF pin_parameterTable IS NOT NULL THEN
      MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable        => V_PARAMETER_TABLE,
                                        pin_parameterTableAlias   => V_PARAMETER_TABLE_ALIAS,
                                        pin_rosterTable           => V_ROSTER_TABLE_NAME,
                                        pin_inputTable            => V_INPUT_TABLE_NAME,
                                        pin_modifierIndex         => V_MODIFIER_INDEX,
                                        pin_entitiesToLog         => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                        pin_parameterAlias        => V_ALIAS_NAME,
                                        pin_additionalParameterAlias => NULL,
                                        pin_periodFilter          => pin_parameterPeriodFilter,
                                        pin_joinWithRoster        => case when VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE and pin_lookupType IS NOT null then null else pin_rosterJoinMap(CON_ROSTER_PARAM_JOIN_INDEX) end, -- For COMPONENT Lookups the join is done on ECE Before Aggregation and EE + Aditional After
                                        pin_joinWithInput         => VOBJ_PINPUT_PARAM_JOIN,
                                        pin_modType               => V_MOD_TYPE,
                                        pin_modId                 => V_MOD_ID,
                                        pin_parameterTableType    => V_PARAMETER_TABLE_TYPE,
                                        pin_lookupTableType       => V_LOOKUP_TABLE_TYPE,
                                        pin_MetricComponent_id    => pin_MetricComponent_id,
                                        pin_inputCol              => 'LOOKUP_COLUMN,RESULT_VALUE,VLD_NO_LKCURVES',
                                        pin_calledFrom            => V_CALLED_FROM,
                                        pin_effective_date_cols   => nvl(pin_effective_date_cols_lhs, pin_effective_date_cols_lookup),
                                        pin_period_filter         => NULL,

                                        pio_aliasIndex            => V_ALIAS_INDEX,
                                        pio_selectClause          => V_SELECT_CLAUSE,

                                        pout_joinClause           => V_JOIN_WITH_PARAM_TAB,
                                        pout_whenClause           => V_PARAMETER_WHEN_CLAUSE,
                                        pout_Rejected_Values      => V_REJECTED_VALUES,
                                        pout_lookup_column_alias  => v_alias_lookup_column,
                                        pout_period_filter        => v_period_filter);
   END IF;


   IF pin_lookupType IS NOT NULL THEN -- IF LOOKUP TABLE IS USED
      V_MODIFIER_VALUES_CLAUSE   := V_MODIFIER_VALUES_CLAUSE || ',' || v_alias_lookup_column;
   END IF;

   -- CREATE ALIAS FOR MODIFIER OPERATION
   V_ALIAS_INDEX  := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME   := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   -- CREATE MODIFIER OPERATION AND ADD IT TO SELECT CLAUSE AND VALUES CLAUSE
   CASE
     WHEN (V_MOD_TYPE IN ('add', 'subtract', 'adjustment')) THEN
       V_MODIFIER_OPERATION := ';(CAST((' || V_OPERAND || V_OPERATOR || 'COALESCE(' || V_PARAMETER_VALUE || ', 0)) AS NUMBER' || V_PRECISION || ')) ' || V_ALIAS_NAME;
     ELSE
       V_MODIFIER_OPERATION := ';(CAST((' || V_OPERAND || V_OPERATOR || 'COALESCE(' || V_PARAMETER_VALUE || ', 1)) AS NUMBER' || V_PRECISION || ')) ' || V_ALIAS_NAME;
   END CASE;
   V_SELECT_CLAUSE := V_SELECT_CLAUSE || V_MODIFIER_OPERATION;
   -- ADD ALIAS TO BE USED IN VALUES CLAUSE WHEN INSERTING IN MODIFIER RESULT TABLE
   -- REMOVE FIRST COMMA
   V_MODIFIER_VALUES_CLAUSE := SUBSTR(V_MODIFIER_VALUES_CLAUSE,2) || ',' || V_ALIAS_NAME;
   --
   V_JOIN_CLAUSE := V_JOIN_WITH_ROSTER || V_JOIN_WITH_PARAM_TAB;
   V_WHEN_CLAUSE := V_PARAMETER_WHEN_CLAUSE || V_AUX_WHEN_1310;
   --
   MODIFIERS.LOG_AND_RETURN_PARAMETERS(pin_stamp               => V_STAMP,
                                       pin_Select_Clause       => V_SELECT_CLAUSE,
                                       pin_From_Clause         => V_JOIN_CLAUSE,
                                       pin_Where_Clause        => NULL,
                                       pin_When_Clause         => V_WHEN_CLAUSE,
                                       pin_Modifier_Operations => V_MODIFIER_VALUES_CLAUSE,
                                       pin_Module              => VOBJ_AUX_CLAUSE.MODULE,
                                       pout_Aux_Clause         => VOBJ_AUX_CLAUSE);
   --
   VCOL_CLAUSES.EXTEND;
   VCOL_CLAUSES(V_MODIFIER_INDEX+1) := VOBJ_AUX_CLAUSE;
   --

   RETURN VCOL_CLAUSES;
END MODIFIER_FAC_ADD_SUB_MUL_DIV;

------------------------

FUNCTION MODIFIER_ROUND_UP_DOWN(pin_clauses            IN       TABLETYPE_MODIFIER_CLAUSES
                               ,pin_modifierType       IN       NUMBER
                               ,pin_value              IN       NUMBER
                               ,pin_inputJoinMap       IN       TABLETYPE_NAME_JOIN_MAP
                               ,pin_MetricComponent_id IN       NUMBER default NULL
                               ,pin_lookup_precision   IN       VARCHAR2 DEFAULT NULL
                               )
RETURN TABLETYPE_MODIFIER_CLAUSES
IS
   VCOL_CLAUSES            TABLETYPE_MODIFIER_CLAUSES;
   VOBJ_AUX_CLAUSE         OBJTYPE_MODIFIER_CLAUSES;
   V_JOIN_WITH_ROSTER      CLOB;
   V_MODIFIER_INDEX        PLS_INTEGER;
   V_MODIFIER_OPERATION    VARCHAR2(2000);
   V_SELECT_CLAUSE         CLOB;
   V_ALIAS_INDEX           PLS_INTEGER := 0;
   V_ALIAS_NAME            VARCHAR2(30);
   V_INPUT_TABLE_NAME      CLOB;
   V_OPERAND               CLOB;
   CON_METRIC              CONSTANT VARCHAR2(30) := 'METRIC';
   CON_MODIFIED_EARNINGS   CONSTANT VARCHAR2(30) := 'MODIFIED_EARNINGS';
   V_PRECISION             VARCHAR2(30);
-- FUNCTION/PROCEDURE NR 1
    v_stamp            VARCHAR2(250);

BEGIN

  v_stamp := 'MODIFIERS.MODIFIER_ROUND_UP_DOWN - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

/*   begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
   end;
*/

  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_CLAUSES),         ',PIN_CLAUSES             => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERTYPE),        ',PIN_MODIFIERTYPE        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_VALUE),               ',PIN_VALUE               => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_INPUTJOINMAP),    ',PIN_INPUTJOINMAP        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),  ',PIN_METRICCOMPONENT_ID  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_precision),  ',pin_lookup_precision    => <value>' , v_stamp);

  END;

   IF pin_modifierType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_modifierType parameter can not be null');
   END IF;

   --
   IF pin_value IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_value parameter can not be null');
   END IF;

   --
   IF pin_modifierType NOT IN (1,2) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid value for pin_modifierType parameter');
   END IF;

   --
   VCOL_CLAUSES         := pin_clauses;
   VOBJ_AUX_CLAUSE      := VCOL_CLAUSES(1);
   V_MODIFIER_INDEX  := VCOL_CLAUSES.COUNT;
   -- GET THE PROCESSING INPUT TABLE NAME
   V_INPUT_TABLE_NAME := VOBJ_AUX_CLAUSE.FROM_CLAUSE;
   -- GET THE PRECISION OF THE MODIFIED VALUE
   IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
      V_PRECISION := GET_PRECISION_AND_SCALE(CON_METRIC, pin_lookup_precision);
   ELSIF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
      V_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_MODIFIED_EARNINGS);

   END IF;

   --
   IF V_MODIFIER_INDEX = 1 THEN -- IF FIRST MODIFIER,OPERATOR IS THE RESULT FIELD
      V_OPERAND := SUBSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,1,INSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,',',1,1) - 1);
      -- ADD THE ALIAS OF THE FIRST UNMODIFIED VALUE
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || MODIFIERS.UNMODIFIED_VALUE_ALIAS;
   ELSE -- IF NOT THE FIRST MODIFIER,GET THE OPERATION OF THE LAST MODIFIER
      V_OPERAND := SUBSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,
                          INSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,';',-1)+1);
      -- DUPLICATE IN THE VALUES CLAUSE OF THE MODIFIER RESULT TABLE THE ALIAS OF THE PRECEDING MODIFIER OPERATION
      -- AS THIS IS THE UNMODIFIED VALUE FOR THE CURRENT MODIFIER
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1) + 1);
      -- REMOVE ALIAS FROM OPERAND
      --FC Fix 7Mod --V_OPERAND := SUBSTR(V_OPERAND,1,INSTR(V_OPERAND,' ',-1) - 1);
      V_OPERAND := SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1)); --FC Fix 7Mod --
   END IF;

   -- CREATE THE ALIAS OF THE PARAMETER VALUE USED IN MODIFIERS PROCESSING
   V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   -- ADD PARAMETER VALUE TO SELECT CLAUSE
   V_SELECT_CLAUSE := TO_CHAR(pin_value) || ' ' || V_ALIAS_NAME;
   -- CREATE THE ALIAS OF THE MODIFIER VALUE AND REMOVE THE FIRST COMMA
   V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || V_ALIAS_NAME;
   IF pin_modifierType = 1 THEN -- IF ROUND UP MODIFIER
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ';CAST((CEIL(' || V_OPERAND || ' * 1E+' || TO_CHAR(pin_value) || ') * 1E-' || TO_CHAR(pin_value) || ') AS NUMBER' || V_PRECISION || ') ' || V_ALIAS_NAME;
   ELSE -- IF ROUND DOWN MODIFIER
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ';CAST((FLOOR(' || V_OPERAND || ' * 1E+' || TO_CHAR(pin_value) || ') * 1E-' || TO_CHAR(pin_value) || ') AS NUMBER' || V_PRECISION || ') ' || V_ALIAS_NAME;

   END IF;

   -- JOIN INPUT TABLE WITH ROSTER
   IF pin_inputJoinMap IS NOT NULL AND
      pin_inputJoinMap(1).NAME1 IS NOT NULL AND
      pin_inputJoinMap(1).NAME2 IS NOT NULL
   THEN
      V_JOIN_WITH_ROSTER := ' LEFT JOIN ' || pin_inputJoinMap(1).NAME3 || ' ON ' || pin_inputJoinMap(1).NAME3 || '.' || pin_inputJoinMap(1).NAME1 || '=' || V_INPUT_TABLE_NAME || '.' || pin_inputJoinMap(1).NAME2;
   END IF;

   --
   MODIFIERS.LOG_AND_RETURN_PARAMETERS(pin_stamp               => V_STAMP,
                                       pin_Select_Clause       => V_SELECT_CLAUSE,
                                       pin_From_Clause         => V_JOIN_WITH_ROSTER,
                                       pin_Where_Clause        => NULL,
                                       pin_When_Clause         => NULL,
                                       pin_Modifier_Operations => SUBSTR(V_MODIFIER_OPERATION,2),
                                       pin_Module              => VOBJ_AUX_CLAUSE.MODULE,
                                       pout_Aux_Clause         => VOBJ_AUX_CLAUSE);
   --
   VCOL_CLAUSES.EXTEND;
   VCOL_CLAUSES(VCOL_CLAUSES.COUNT) := VOBJ_AUX_CLAUSE;

   RETURN VCOL_CLAUSES;
END MODIFIER_ROUND_UP_DOWN;

------------------------


FUNCTION MODIFIER_SPLIT_ROUND(pin_clauses                    IN       TABLETYPE_MODIFIER_CLAUSES
                             ,pin_modifierType               IN       NUMBER
                             ,pin_value                      IN       NUMBER
                             ,pin_parameterTable             IN       VARCHAR2
                             ,pin_parameterTableAlias        IN       VARCHAR2
                             ,pin_parameterCol               IN       VARCHAR2
                             ,pin_inputJoinMap               IN       tabletype_name_join_map
                             ,pin_rosterCols                 IN       tabletype_name_join_map
                             ,pin_paramPeriodFilter          IN       clob
                             ,pin_MetricComponent_id         IN       NUMBER default NULL
                             ,pin_effective_date_cols        IN       OBJTYPE_DATE_RANGE_INTERNAL DEFAULT NULL -- parameter effective dated
                             ,pin_lookup_precision           IN       VARCHAR2 DEFAULT NULL
                             )
RETURN TABLETYPE_MODIFIER_CLAUSES
IS
   VCOL_CLAUSES            TABLETYPE_MODIFIER_CLAUSES;
   VOBJ_AUX_CLAUSE         OBJTYPE_MODIFIER_CLAUSES;
   V_MODIFIER_OPERATION    CLOB;
   V_SELECT_CLAUSE         CLOB;
   V_JOIN_WITH_ROSTER      CLOB;
   V_JOIN_WITH_PARAM_TAB   CLOB;
   V_JOIN_CLAUSE           CLOB;
   V_OPERAND               CLOB;
   V_WHEN_CLAUSE           CLOB;
   V_ALIAS_INDEX           PLS_INTEGER := 0;
   V_ALIAS_NAME            VARCHAR2(30);
   V_MODIFIER_INDEX        PLS_INTEGER;
   V_INPUT_TABLE_NAME      CLOB;
   V_ROSTER_TABLE_NAME     CLOB;
   CON_METRIC              CONSTANT CLOB := 'METRIC';
   CON_MODIFIED_EARNINGS   CONSTANT CLOB := 'MODIFIED_EARNINGS';
   CON_SPLIT_FACTOR        CONSTANT CLOB := 'SPLIT_FACTOR';
   V_PRECISION             VARCHAR2(30);
   V_SPLIT_PRECISION       VARCHAR2(30);
   V_PARAMETER_VALUE       VARCHAR2(2000);
   V_REJECTED_VALUES       CLOB;
-- FUNCTION/PROCEDURE NR 1
   v_stamp            VARCHAR2(250);
   V_CALLED_FROM PLS_INTEGER;
   v_alias_lookup_column VARCHAR2(30);
   v_period_filter BOOLEAN;

BEGIN

  v_stamp := 'MODIFIERS.MODIFIER_SPLIT_ROUND - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
/*  begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
  end;
*/
  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_CLAUSES),        ',PIN_CLAUSES             => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_MODIFIERTYPE),       ',PIN_MODIFIERTYPE        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_VALUE),              ',PIN_VALUE               => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLE),   ',PIN_PARAMETERTABLE      => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERTABLEALIAS),',PIN_PARAMETERTABLEALIAS   => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_PARAMETERCOL),     ',PIN_PARAMETERCOL        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_INPUTJOINMAP),   ',PIN_INPUTJOINMAP        => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PIN_ROSTERCOLS),     ',PIN_ROSTERCOLS          => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_PARAMPERIODFILTER),    ',PIN_PARAMPERIODFILTER   => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id), ',PIN_METRICCOMPONENT_ID  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pin_effective_date_cols),',pin_effective_date_cols_lhs => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_lookup_precision), ',pin_lookup_precision    => <value>' , v_stamp);
  END;

   -- VALIDATIONS
   IF pin_clauses IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_clauses parameter can not be null');
   END IF;

   --
   IF pin_modifierType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_modifierType parameter can not be null');
   END IF;

   --
   IF pin_parameterTable IS NOT NULL AND pin_inputJoinMap IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputJoinMap parameter can not be null');
   END IF;

   --
   IF pin_value IS NULL AND pin_parameterTable IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_value and pin_parameterTable parameters can not be both null');
   END IF;

   --
   IF pin_value IS NOT NULL AND pin_parameterTable IS NOT NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_value and pin_parameterTable parameters can not be both not null');
   END IF;

   --
   IF pin_modifierType NOT IN (1,2) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid value for pin_modifierType parameter');
   END IF;

   --
   VCOL_CLAUSES         := pin_clauses;
   VOBJ_AUX_CLAUSE      := VCOL_CLAUSES(1);
   V_MODIFIER_INDEX  := VCOL_CLAUSES.COUNT;
   --
   -- GET THE PRECISION OF THE MODIFIED VALUE
   IF VOBJ_AUX_CLAUSE.MODULE = METRICS_MODULE THEN
      V_PRECISION := GET_PRECISION_AND_SCALE(CON_METRIC, pin_lookup_precision);
      V_CALLED_FROM := 1;
   ELSIF VOBJ_AUX_CLAUSE.MODULE = COMPONENTS_MODULE THEN
      V_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_MODIFIED_EARNINGS);
      V_CALLED_FROM := 2;

   END IF;

   -- GET THE PROCESSING INPUT TABLE NAME
   V_INPUT_TABLE_NAME := VOBJ_AUX_CLAUSE.FROM_CLAUSE;
   -- GET ROSTER TABLE NAME
   V_ROSTER_TABLE_NAME := pin_inputJoinMap(1).NAME3;
   --
   IF V_MODIFIER_INDEX = 1 THEN -- IF FIRST MODIFIER,OPERATOR IS THE RESULT FIELD
      V_OPERAND := SUBSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,1,INSTR(VOBJ_AUX_CLAUSE.SELECT_CLAUSE,',',1,1) - 1);
      -- ADD THE ALIAS OF THE FIRST UNMODIFIED VALUE
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || MODIFIERS.UNMODIFIED_VALUE_ALIAS;
   ELSE -- IF NOT THE FIRST MODIFIER,GET THE OPERATION OF THE LAST MODIFIER
      V_OPERAND := SUBSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,
                          INSTR(VCOL_CLAUSES(V_MODIFIER_INDEX).SELECT_CLAUSE,';',-1)+1);
      -- DUPLICATE IN THE VALUES CLAUSE OF THE MODIFIER RESULT TABLE THE ALIAS OF THE PRECEDING MODIFIER OPERATION
      -- AS THIS IS THE UNMODIFIED VALUE FOR THE CURRENT MODIFIER
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1) + 1);
      -- REMOVE ALIAS FROM OPERAND IF IT IS THE CASE
      --FC Fix 7Mod --V_OPERAND := SUBSTR(V_OPERAND,1,INSTR(V_OPERAND,' ',-1) - 1);
      V_OPERAND := SUBSTR(V_OPERAND,INSTR(V_OPERAND,' ',-1)); --FC Fix 7Mod --
   END IF;

   -- JOIN INPUT TABLE WITH ROSTER
   IF pin_inputJoinMap IS NOT NULL AND
      pin_inputJoinMap(1).NAME1 IS NOT NULL AND
      pin_inputJoinMap(1).NAME2 IS NOT NULL
   THEN
      V_JOIN_WITH_ROSTER := ' LEFT JOIN ' || V_ROSTER_TABLE_NAME || ' ON ' || V_ROSTER_TABLE_NAME || '.' || pin_inputJoinMap(1).NAME1 || '=' || V_INPUT_TABLE_NAME || '.' || pin_inputJoinMap(1).NAME2;
   END IF;

   -- CREATE ALIAS NAME FOR THE PARAMETER VALUE
   V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
   V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
   --
   IF pin_modifierType = 1 THEN -- IF SPLIT MODIFIER
      -- APPEND SPLIT FACTOR TO SELECT AND VALUES CLAUSE OF THE INSERT STATEMENT
      V_SPLIT_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE(CON_SPLIT_FACTOR);
      V_PARAMETER_VALUE := 'CAST(' || NVL(TO_CHAR(pin_value),NVL(pin_parameterTableAlias, pin_parameterTable) || '.' || pin_parameterCol) || ' AS NUMBER' || V_SPLIT_PRECISION || ')';
      V_SELECT_CLAUSE := V_PARAMETER_VALUE || ' ' || V_ALIAS_NAME;
      if V_MODIFIER_INDEX > 1 then --FVC
        V_PARAMETER_VALUE := V_ALIAS_NAME;
      end if;--FVC

      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || V_ALIAS_NAME;
      -- PROCESS SPLIT FACTOR PARAMETER TABLE
      IF pin_parameterTable IS NOT NULL THEN
         MODIFIERS.PROCESS_PARAMETER_TABLE(pin_parameterTable           => pin_parameterTable,
                                           pin_parameterTableAlias      => NVL(pin_parameterTableAlias, pin_parameterTable),
                                           pin_rosterTable              => V_ROSTER_TABLE_NAME,
                                           pin_inputTable               => V_INPUT_TABLE_NAME,
                                           pin_modifierIndex            => V_MODIFIER_INDEX,
                                           pin_entitiesToLog            => VOBJ_AUX_CLAUSE.SELECT_CLAUSE,
                                           pin_parameterAlias           => V_ALIAS_NAME,
                                           pin_additionalParameterAlias => NULL,
                                           pin_periodFilter             => pin_paramPeriodFilter,
                                           pin_joinWithRoster           => pin_rosterCols(1),
                                           pin_joinWithInput            => pin_inputJoinMap(2),
                                           pin_modType                  => 'split',
                                           pin_modId                    => 3,
                                           pin_parameterTableType       => 'split factor',
                                           pin_lookupTableType          => NULL,
                                           pin_MetricComponent_id       => pin_MetricComponent_id,
                                           pin_calledFrom               => V_CALLED_FROM,
                                           pin_effective_date_cols      => pin_effective_date_cols,
                                           pin_period_filter           => v_period_filter,

                                           pio_aliasIndex               => V_ALIAS_INDEX,
                                           pio_selectClause             => V_SELECT_CLAUSE,

                                           pout_joinClause              => V_JOIN_WITH_PARAM_TAB,
                                           pout_whenClause              => V_WHEN_CLAUSE,
                                           pout_Rejected_Values         => V_REJECTED_VALUES,
                                           pout_lookup_column_alias     => v_alias_lookup_column,
                                           pout_period_filter           => v_period_filter);
      END IF;

      -- CREATE ALIAS FOR MODIFIER OPERATION
      V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
      V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
      -- APPEND MODIFIER OPERATION TO SELECT CLAUSE
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ';CAST((' || V_OPERAND || '*COALESCE(' || V_PARAMETER_VALUE || ', 1)) AS NUMBER' || V_PRECISION || ') ' || V_ALIAS_NAME;
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || V_ALIAS_NAME;
   ELSE -- IF ROUND MODIFIER
      -- ADD PARAMETER VALUE TO THE SELECT CLAUSE
      V_SELECT_CLAUSE := TO_CHAR(pin_value) || ' ' || V_ALIAS_NAME;
      -- CREATE ALIAS NAME
      V_ALIAS_INDEX := V_ALIAS_INDEX + 1;
      V_ALIAS_NAME := 'F' || TO_CHAR(V_MODIFIER_INDEX) || TO_CHAR(V_ALIAS_INDEX);
      -- ADD MODIFIER OPERATION TO THE SELECT CLAUSE
      V_SELECT_CLAUSE := V_SELECT_CLAUSE || ';CAST((ROUND(' || V_OPERAND || ',' || TO_CHAR(pin_value) || ')) AS NUMBER' || V_PRECISION || ') ' || V_ALIAS_NAME;
      V_MODIFIER_OPERATION := V_MODIFIER_OPERATION || ',' || V_ALIAS_NAME;

   END IF;

   --
   V_JOIN_CLAUSE := V_JOIN_WITH_ROSTER || V_JOIN_WITH_PARAM_TAB;
   --
   MODIFIERS.LOG_AND_RETURN_PARAMETERS(pin_stamp               => V_STAMP,
                                       pin_Select_Clause       => V_SELECT_CLAUSE,
                                       pin_From_Clause         => V_JOIN_CLAUSE,
                                       pin_Where_Clause        => NULL,
                                       pin_When_Clause         => V_WHEN_CLAUSE,
                                       pin_Modifier_Operations => SUBSTR(V_MODIFIER_OPERATION,2),
                                       pin_Module              => VOBJ_AUX_CLAUSE.MODULE,
                                       pout_Aux_Clause         => VOBJ_AUX_CLAUSE);
   --
   VCOL_CLAUSES.EXTEND;
   VCOL_CLAUSES(VCOL_CLAUSES.COUNT) := VOBJ_AUX_CLAUSE;
   --

   RETURN VCOL_CLAUSES;
END MODIFIER_SPLIT_ROUND;

------------------------

PROCEDURE CALL_MODIFIERS(pin_modifierResultTable   IN VARCHAR2
                        ,pin_modifierCalls         IN CLOB
                        ,pin_modifierResultCols    IN VARCHAR2
                        ,pin_inputCols             IN VARCHAR2
                        ,pin_EarningEntity         IN VARCHAR2
                        ,pout_insertStatement      OUT CLOB
                        ,pout_whenClause           OUT CLOB
                        ,pout_selectClause         OUT CLOB
                        ,pout_fromClause           OUT CLOB
                        ,pout_whereClause          OUT clob
                        ,pin_MetricComponent_id    IN NUMBER default null)
IS
   VCOL_CLAUSES                        TABLETYPE_MODIFIER_CLAUSES;
   V_SELECT_CLAUSE                  CLOB;
   V_FROM_CLAUSE                    CLOB;
   V_WHEN_CLAUSE                    CLOB;
   V_MODIFIER_VALUES_ALIASES        CLOB;
   V_SELECT_STATEMENT               CLOB;
   VCOL_SELECT_FIELDS               NT_STRING_TABLE; --DBMS_UTILITY.uncl_array;
   VCOL_INPUT_FIELDS                NT_STRING_TABLE; --DBMS_UTILITY.uncl_array;
   V_MODIFIER_RESULT_COLS_ALIASES   CLOB;
   CON_RESULT_TABLE_SEQ             CONSTANT VARCHAR2(50) := commons_appframework.get_row_identifier_sequence(pin_modifierResultTable, NULL) || '.NEXTVAL';
   V_LAST_MODIFIER_ALIAS            CLOB;
   -- FUNCTION/PROCEDURE NR 1
   v_stamp                          VARCHAR2(250);
   V_NOT_EXISTS_CLAUSE              CLOB;
   V_EARNING_ENTITY                 CLOB;
   V_REJECTED_TABLE                 CLOB;
   --FVC ADD HINTS
   v_hint_loc_sel_valid             VARCHAR2(4000 CHAR);
   v_hint_sel_valid                 VARCHAR2(4000 CHAR);
   v_hint_loc_sel_rej               VARCHAR2(4000 CHAR);
   v_hint_sel_rej                   VARCHAR2(4000 CHAR);
   v_hint_loc_ins_all               VARCHAR2(4000 CHAR);
   v_hint_ins_all                   VARCHAR2(4000 CHAR);
   v_hint_loc_sel1                  VARCHAR2(4000 CHAR);
   v_hint_sel1                      VARCHAR2(4000 CHAR);
   v_card_hint_metric               VARCHAR2(4000 CHAR);
   v_card_hint_rejected             VARCHAR2(4000 CHAR);
   v_card_hint_validations          VARCHAR2(4000 CHAR);
   V_SEL_FLD                        VARCHAR2(4000 CHAR);

   V_JOIN_EE                        VARCHAR2(4000 CHAR);
   V_ENTITY                         VARCHAR2(250  CHAR);

   --============================================================================ START LOGG_ENTITIES PROCEDURE====================================================================--
   --Input:
     -- For MM: TEMP_METRIC_VALUES.MV_FINAL_VALUE,TEMP_METRIC_VALUES.MV_EARNINGS_ENTITY,TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_ID_3,TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_ID_4,TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_1,TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_2
     -- For EM: T1621741.AGGREGATED_EARNINGS,T1621741.E1300347
    procedure LOGG_ENTITIES is

    begin
       -- Add aliases to the select clause of the first Modifier
       SELECT NEW_STR BULK COLLECT INTO VCOL_SELECT_FIELDS FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(VCOL_CLAUSES(1).SELECT_CLAUSE,',','</C><C>') || '</C></R>')  COLUMNS NEW_STR VARCHAR2(100) PATH '.');
       VCOL_CLAUSES(1).SELECT_CLAUSE := '';

       for I in 1 .. VCOL_SELECT_FIELDS.COUNT loop


          IF I = 1 AND pin_EarningEntity is null THEN
             --For 1 adjusting precission for UNMODIFIED EARNINGS to the system specified precission
              V_SEL_FLD:= 'CAST('|| VCOL_SELECT_FIELDS(I) ||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('UNMODIFIED_EARNINGS')||') F0' || TO_CHAR(I);
           ELSE
              V_SEL_FLD:= VCOL_SELECT_FIELDS(I) || ' F0' || TO_CHAR(I);
           END IF;

         VCOL_CLAUSES(1).SELECT_CLAUSE := VCOL_CLAUSES(1).SELECT_CLAUSE || ',' || V_SEL_FLD;

         case
           --1. For Metric Modifiers (I already have the BKs in the TEMP_METRIC_* table and only have to select them. Select clause has: FinalValue,EE,MCE1,MCE2)
           when I = 2 and pin_EarningEntity is not null then -- For Earning Entity the fields are like mv_earnings_entity / mv_earnings_entity_BK (must only concat _BK)
             V_SEL_FLD                  := VCOL_SELECT_FIELDS(I) || '_BK F0' || TO_CHAR(I) || '_BK';
             VCOL_CLAUSES(1).SELECT_CLAUSE := VCOL_CLAUSES(1).SELECT_CLAUSE || ',' || V_SEL_FLD;
           when I > 2 and pin_EarningEntity is not null then -- For The rest of the MCE the fields are like mv_metric_calc_entity_id_1 / mv_metric_calc_entity_name_1 (Must replace 'ID' with 'NAME')
             V_SEL_FLD                  := REGEXP_REPLACE(VCOL_SELECT_FIELDS(I),'_ID_','_NAME_',1,1,'i') || ' F0' || TO_CHAR(I) || '_BK';
             VCOL_CLAUSES(1).SELECT_CLAUSE := VCOL_CLAUSES(1).SELECT_CLAUSE || ',' || V_SEL_FLD;

           --2. For Earnings Modifiers
           when I >= 2 and pin_EarningEntity is null then-- EE1, etc
             V_ENTITY                   := SUBSTR(VCOL_SELECT_FIELDS(I),instr(VCOL_SELECT_FIELDS(I),'.')+1);
             if REGEXP_LIKE(V_ENTITY ,'E[0-9]') then -- If aditional entity, then logg the BK
               V_SEL_FLD                  := COMMONS.FIND_ENT_TABLE_NAME(V_ENTITY) || '.' || COMMONS.FIND_ENT_BUSINESS_KEY_BY_NAME(V_ENTITY) ||' F0' || TO_CHAR(I) || '_BK';
               --In order to be able to select the BK, the INPUT must be joined with the EntityTable
               V_JOIN_EE := V_JOIN_EE || ' LEFT JOIN ' || COMMONS.FIND_ENT_TABLE_NAME(V_ENTITY) || ' ON '|| VCOL_CLAUSES(1).FROM_CLAUSE /*INPUT*/ || '.' || V_ENTITY || '=' || COMMONS.FIND_ENT_TABLE_NAME(V_ENTITY) || '.E_INTERNAL_ID';
             else                                    -- If aditional field, then logg the field itself
               V_SEL_FLD                  := SUBSTR(VCOL_SELECT_FIELDS(I),1,instr(VCOL_SELECT_FIELDS(I),'.')-1) || '.' || V_ENTITY ||' F0' || TO_CHAR(I) || '_BK';
             end if;
             VCOL_CLAUSES(1).SELECT_CLAUSE := VCOL_CLAUSES(1).SELECT_CLAUSE || ',' || V_SEL_FLD;
           else null;
         end case;
       end loop;
       --Add the join with the EE (for metrics this will be null)
       VCOL_CLAUSES(1).FROM_CLAUSE := VCOL_CLAUSES(1).FROM_CLAUSE || V_JOIN_EE;
       VCOL_CLAUSES(1).SELECT_CLAUSE := SUBSTR(VCOL_CLAUSES(1).SELECT_CLAUSE,2);
    end LOGG_ENTITIES;
   --Output:
   /*-- For MM:  select          TEMP_METRIC_VALUES.MV_FINAL_VALUE F01,
                                 TEMP_METRIC_VALUES.MV_EARNINGS_ENTITY F02,
                                 TEMP_METRIC_VALUES.MV_EARNINGS_ENTITY_BK F02_BK,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_ID_3 F03,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_3 F03_BK,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_ID_4 F04,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_4 F04_BK,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_1 F05,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_1 F05_BK,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_2 F06,
                                 TEMP_METRIC_VALUES.MV_METRIC_CALC_ENTITY_NAME_2 F06_BK,  */


     -- For EM:

   --============================================================================ START CREATE_SELECT_CLAUSE PROCEDURE====================================================================--

    procedure CREATE_SELECT_CLAUSE is
    begin




      VCOL_CLAUSES(1).SELECT_CLAUSE :=  case when VCOL_CLAUSES.COUNT > 2 then 'SELECT ' else null end || pin_inputCols || ', ' || VCOL_CLAUSES(1).SELECT_CLAUSE;

      FOR I in reverse 1..VCOL_CLAUSES.COUNT loop
       -- Replace The Last Modifier Alias
       if i=VCOL_CLAUSES.COUNT then
         VCOL_CLAUSES(I).SELECT_CLAUSE := SUBSTR(VCOL_CLAUSES(I).SELECT_CLAUSE,1,INSTR(VCOL_CLAUSES(I).SELECT_CLAUSE,' ',-1)) || V_LAST_MODIFIER_ALIAS;
       end if;

       if i in (1,2) then
         continue; -- Add in the outer query all the modifiers starting with the second one (1 = The pin_inputCols and ECE, 2=  The Parameter fields and the First Modifier)
       end if;
        -- Do not create outer query for the inputCols and the first modifier
        V_SELECT_CLAUSE            := V_SELECT_CLAUSE || ' ' || case when i=VCOL_CLAUSES.COUNT then 'Q.*, ' else 'SELECT Q.*, ' end || substr(VCOL_CLAUSES(I).SELECT_CLAUSE,instr(VCOL_CLAUSES(I).SELECT_CLAUSE,';')+1)  || ' FROM( ';
        VCOL_CLAUSES(2).SELECT_CLAUSE := VCOL_CLAUSES(2).SELECT_CLAUSE || ',' || substr(VCOL_CLAUSES(I).SELECT_CLAUSE,1,instr(VCOL_CLAUSES(I).SELECT_CLAUSE,';')-1);
        if V_NOT_EXISTS_CLAUSE IS NOT NULL then
          V_NOT_EXISTS_CLAUSE := V_NOT_EXISTS_CLAUSE || ') Q';
        else
          V_FROM_CLAUSE  := V_FROM_CLAUSE  || ') Q';

        end if;
      END LOOP;

      -- Add to select clause:  1 = The pin_inputCols and ECE  2 =  The Parameter fields and the First Modifier)
        V_SELECT_CLAUSE := replace(V_SELECT_CLAUSE || ' ' || VCOL_CLAUSES(1).SELECT_CLAUSE
                                                   || ',' || VCOL_CLAUSES(2).SELECT_CLAUSE,';',',');





    end CREATE_SELECT_CLAUSE;


   --============================================================================ START CREATE_PERIOD_JOINS PROCEDURE====================================================================--

    PROCEDURE CREATE_PERIOD_JOINS
    AS
    BEGIN
      -- get the list of all the period fields
      FOR i IN (SELECT CASE WHEN INSTR(TEMP_NAMES.TABLE_FIELD, '.') > 0 THEN '' ELSE substr(PIN_EARNINGENTITY, 1, instr(PIN_EARNINGENTITY, '.') - 1) || '.' END || TEMP_NAMES.TABLE_FIELD table_field, rownum rowno
                FROM
                  (SELECT regexp_substr(PIN_INPUTCOLS, '[^ ,]+', 1, LEVEL) TABLE_FIELD, LEVEL AS LVL FROM dual /* in metrics the temporary table fields */
                  CONNECT BY regexp_substr(PIN_INPUTCOLS, '[^ ,]+', 1, LEVEL) IS NOT NULL) TEMP_NAMES
                JOIN
                  (SELECT regexp_substr(PIN_MODIFIERRESULTCOLS, '[^ ,]+', 1, LEVEL) FIELD_NAME, LEVEL AS LVL FROM dual /* the actual entity/fields names */
                  CONNECT BY regexp_substr(PIN_MODIFIERRESULTCOLS, '[^ ,]+', 1, LEVEL) IS NOT NULL) FIELD_NAMES
                ON TEMP_NAMES.LVL = FIELD_NAMES.LVL
                JOIN fields f
                  ON FIELD_NAMES.FIELD_NAME = f.fld_column_name
                WHERE f.fld_data_type = 8 /* period type */ AND NOT regexp_like(TEMP_NAMES.TABLE_FIELD, '^[0-9]+$') /* check if a period id is given instead of a field name */
                ORDER BY TEMP_NAMES.LVL)
      LOOP
        -- concatenate the joins for each period field
        VCOL_CLAUSES(1).FROM_CLAUSE := VCOL_CLAUSES(1).FROM_CLAUSE || ' LEFT JOIN TU_PERIODS_RANGE TUPR' || i.rowno ||
        ' ON TUPR' || i.rowno || '.TUPR_ID = ' || i.table_field;
      END LOOP;
    END CREATE_PERIOD_JOINS;

   --============================================================================ START CREATE_PERIOD_JOINS PROCEDURE====================================================================--

    PROCEDURE CREATE_PERIOD_SELECT
    AS
    BEGIN
      -- get the list of all the period fields
      FOR i IN (SELECT CASE WHEN INSTR(TEMP_NAMES.TABLE_FIELD, '.') > 0 THEN '' ELSE substr(PIN_EARNINGENTITY, 1, instr(PIN_EARNINGENTITY, '.') - 1) || '.' END || TEMP_NAMES.TABLE_FIELD table_field, rownum rowno
                FROM
                  (SELECT regexp_substr(PIN_INPUTCOLS, '[^ ,]+', 1, LEVEL) TABLE_FIELD, LEVEL AS LVL FROM dual /* in metrics the temporary table fields */
                  CONNECT BY regexp_substr(PIN_INPUTCOLS, '[^ ,]+', 1, LEVEL) IS NOT NULL) TEMP_NAMES
                JOIN
                  (SELECT regexp_substr(PIN_MODIFIERRESULTCOLS, '[^ ,]+', 1, LEVEL) FIELD_NAME, LEVEL AS LVL FROM dual /* the actual entity/fields names */
                  CONNECT BY regexp_substr(PIN_MODIFIERRESULTCOLS, '[^ ,]+', 1, LEVEL) IS NOT NULL) FIELD_NAMES
                ON TEMP_NAMES.LVL = FIELD_NAMES.LVL
                JOIN fields f
                  ON FIELD_NAMES.FIELD_NAME = f.fld_column_name
                WHERE f.fld_data_type = 8 /* period type */ AND NOT regexp_like(TEMP_NAMES.TABLE_FIELD, '^[0-9]+$') /* check if a period id is given instead of a field name */
                ORDER BY TEMP_NAMES.LVL)
      LOOP
        -- replace the select clause to use the new period names
        V_SELECT_CLAUSE := REPLACE(V_SELECT_CLAUSE, i.table_field || ' ', 'TUPR' || i.rowno || '.TUPR_PERIOD_RANGE_NAME ');
      END LOOP;
    END CREATE_PERIOD_SELECT;

--=============================================================================== START MAIN BLOCK ====================================================================--
BEGIN

  v_stamp := 'MODIFIERS.CALL_MODIFIERS - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

  --========================================================================== Log the input parameters ===============================================================--
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_SELECT_CLAUSE),               ',V_SELECT_CLAUSE       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_MODIFIERRESULTTABLE),     ',PIN_MODIFIERRESULTTABLE => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PIN_MODIFIERCALLS),               ',PIN_MODIFIERCALLS       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_MODIFIERRESULTCOLS),      ',PIN_MODIFIERRESULTCOLS  => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLS),               ',PIN_INPUTCOLS           => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_EarningEntity),           ',PIN_EARNINGENTITY       => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricComponent_id),        ',PIN_METRICCOMPONENT_ID  => <value>', v_stamp);
  END;

  --========================================================================== Get the Rejected values table ===============================================================--

  --This is done only when the (pin_EarningEntity is not null), therefore only for metric modifiers
  IF pin_EarningEntity IS NOT NULL then

    IF pin_EarningEntity LIKE '%VALUES%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_VALUES_REJECTED';

    ELSIF pin_EarningEntity LIKE '%AGGREGATIONS%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_AGG_REJECTED';

    ELSIF pin_EarningEntity LIKE '%GOAL%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_GA_REJECTED';

    ELSIF pin_EarningEntity LIKE '%LOOKUPS%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_LOOKUP_REJECTED';

    ELSIF pin_EarningEntity LIKE '%RANKS%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_RANKS_REJECTED';

    ELSIF pin_EarningEntity LIKE '%RATIO%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_RATIO_REJECTED';

    ELSIF pin_EarningEntity LIKE '%STATISTICS%' THEN
       V_REJECTED_TABLE := 'TEMP_METRIC_STATS_REJECTED';

    END IF;

    V_EARNING_ENTITY   := SUBSTR(pin_EarningEntity, INSTR(pin_EarningEntity,'.')+1);
  END IF;

  --=========================================================================== Set Hints ===================================================================================--

  --set cardinality hints for the temp tables
  v_card_hint_validations := 'CARDINALITY (T2 ' || COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES') || ')';
  v_card_hint_rejected    := 'CARDINALITY (T3 ' || COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY(V_REJECTED_TABLE) || ')';

  --set hint variables
  v_hint_loc_sel_valid := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'SEL_VALIDATIONS' ,pi_proc_id => pin_MetricComponent_id) || CHR(10);
  v_hint_sel_valid     := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'SEL_VALIDATIONS' ,pi_proc_id => pin_MetricComponent_id, pi_other_hints => v_card_hint_validations) || CHR(10);

  v_hint_loc_sel_rej   := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'SEL_REJECTED'    ,pi_proc_id => pin_MetricComponent_id) || CHR(10);
  v_hint_sel_rej       := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'SEL_REJECTED'    ,pi_proc_id => pin_MetricComponent_id, pi_other_hints => v_card_hint_rejected) || CHR(10);

  v_hint_loc_ins_all   := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'INS_ALL'         ,pi_proc_id => pin_MetricComponent_id) || CHR(10);
  v_hint_ins_all       := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'INS_ALL'         ,pi_proc_id => pin_MetricComponent_id) || CHR(10);
  --set hint variables

  --=========================================================================== Execute the call for modifiers ================================================================================--
  EXECUTE IMMEDIATE 'BEGIN :X:=' || pin_modifierCalls || '; END;' USING OUT VCOL_CLAUSES;

  --=========================================================================== Create Select Clause + Add Logging ===================================================================================--

  LOGG_ENTITIES;

  --=========================================================================== Add hints ===================================================================================--
  -- FVC ADD HINTS / Add cardinality hint only for Metrics because metrics modifiers use as input a TEMP table
  IF pin_EarningEntity IS NOT NULL THEN
    V_NOT_EXISTS_CLAUSE := ' WHERE COALESCE(' || PIN_EARNINGENTITY || ',1E38) ' || ' NOT IN ('|| v_hint_loc_sel_valid ||'SELECT '|| v_hint_sel_valid ||'COALESCE(T2.EARNING_ENTITY_ID,1E38)         FROM TEMP_PROC_VALIDATION_VALUES T2)
                      AND '|| 'COALESCE(' || PIN_EARNINGENTITY || ',1E38) ' || ' NOT IN ('|| v_hint_loc_sel_rej   ||'SELECT '|| v_hint_sel_rej   ||'COALESCE(T3.'|| V_EARNING_ENTITY || ',1E38) FROM '  || V_REJECTED_TABLE || ' T3)';
    -- Set the hint here in order for it to be set only for metric and to have a  value in VCOL_CLAUSES(1).FROM_CLAUSE
    v_card_hint_metric  := 'CARDINALITY (' || VCOL_CLAUSES(1).FROM_CLAUSE || ' ' || COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY(VCOL_CLAUSES(1).FROM_CLAUSE) || ')';
  END IF;

  --=========================================================================== Create Period Joins ===================================================================================--

  CREATE_PERIOD_JOINS;

  --=========================================================================== Create Rejected Result Values ===================================================================================--
  -- Create the first part of the ModifierRestultTable Values clause using the column names from pin_modifierResultCols
  SELECT NEW_STR BULK COLLECT INTO VCOL_INPUT_FIELDS FROM XMLTABLE('R/C' PASSING XMLTYPE('<R><C>' || REPLACE(pin_inputCols,',','</C><C>') || '</C></R>') COLUMNS NEW_STR VARCHAR2(100) PATH '.');

  FOR I IN 1..VCOL_INPUT_FIELDS.COUNT LOOP
    V_MODIFIER_RESULT_COLS_ALIASES := V_MODIFIER_RESULT_COLS_ALIASES || ',' || SUBSTR(VCOL_INPUT_FIELDS(I),INSTR(VCOL_INPUT_FIELDS(I),'.') + 1);
  END LOOP;
  V_MODIFIER_RESULT_COLS_ALIASES := SUBSTR(V_MODIFIER_RESULT_COLS_ALIASES,2);

  --=========================================================================== Create FROM/WHERE/WHEN clauses ===================================================================================--
  -- Each object in the collection represents the result of a modifier
  FOR I IN 1..VCOL_CLAUSES.COUNT LOOP
    V_FROM_CLAUSE           := V_FROM_CLAUSE              || VCOL_CLAUSES(I).FROM_CLAUSE;
    V_WHEN_CLAUSE           := V_WHEN_CLAUSE              || VCOL_CLAUSES(I).WHEN_CLAUSE;
    V_MODIFIER_VALUES_ALIASES   := V_MODIFIER_VALUES_ALIASES || ',' || VCOL_CLAUSES(I).MODIFIER_OPERATIONS;
  END LOOP;

  v_hint_loc_sel1     := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'SEL1'  ,pi_proc_id => pin_MetricComponent_id) || CHR(10);
  v_hint_sel1         := COMMONS_PROCESSING.GET_HINTS(             pi_module_id => 'MODIFIERS.CALL_MODIFIERS' ,pi_hint_id=> 'SEL1'  ,pi_proc_id => pin_MetricComponent_id, pi_other_hints => v_card_hint_metric) || CHR(10);

  -- Get the alias of the last Modifier based on the modifier type
  IF VCOL_CLAUSES(1).MODULE = METRICS_MODULE THEN
     V_LAST_MODIFIER_ALIAS := 'METRIC';
  ELSIF VCOL_CLAUSES(1).MODULE = COMPONENTS_MODULE THEN
     V_LAST_MODIFIER_ALIAS := 'MODIFIED_EARNINGS';
  END IF;

  -- FIRST MODIFIER VALUES ALIAS IS NULL AND THE EXTRA COMMA MUST BE REMOVED
  V_MODIFIER_VALUES_ALIASES :=  SUBSTR(V_MODIFIER_VALUES_ALIASES,2,INSTR(V_MODIFIER_VALUES_ALIASES,',',-1)-1) || V_LAST_MODIFIER_ALIAS;
  --
  IF V_WHEN_CLAUSE IS NULL OR TRIM(V_WHEN_CLAUSE) = 'WHEN' THEN
    V_WHEN_CLAUSE := 'WHEN 1=1 THEN INTO ' || pin_modifierResultTable || ' (' || pin_modifierResultCols || ') VALUES (' || V_MODIFIER_RESULT_COLS_ALIASES || V_MODIFIER_VALUES_ALIASES ||',SYS_EXTRACT_UTC(systimestamp),'|| CON_RESULT_TABLE_SEQ || ',0 )';
  ELSE
    IF VCOL_CLAUSES(1).MODULE = METRICS_MODULE THEN
      V_WHEN_CLAUSE := V_WHEN_CLAUSE || ' ELSE INTO '          || pin_modifierResultTable || ' (' || pin_modifierResultCols || ')  VALUES (' || V_MODIFIER_RESULT_COLS_ALIASES || V_MODIFIER_VALUES_ALIASES ||',SYS_EXTRACT_UTC(systimestamp),'|| CON_RESULT_TABLE_SEQ || ',0 )';
    ELSIF VCOL_CLAUSES(1).MODULE = COMPONENTS_MODULE THEN
      V_WHEN_CLAUSE := V_WHEN_CLAUSE || ' WHEN 1=1 THEN INTO ' || pin_modifierResultTable || ' (' || pin_modifierResultCols || ')  VALUES (' || V_MODIFIER_RESULT_COLS_ALIASES || V_MODIFIER_VALUES_ALIASES ||',SYS_EXTRACT_UTC(systimestamp),'|| CON_RESULT_TABLE_SEQ || ',0 )';
    END IF;
  END IF;

  --=========================================================================== Create SELECT clause ===================================================================================--

  CREATE_SELECT_CLAUSE;

  --=========================================================================== Create Period SELECT clause ===================================================================================--

  CREATE_PERIOD_SELECT;

  --=========================================================================== Set output variables ===================================================================================--
  -- the pout_insertStatement variable is only used by MetricModifiers, the EarningsModifiers concatenate the clauses,
  -- therefore only for the MetricModifiers the hint variables should be added, for EarningModifiers they will be added when the clauses will be concatenated
  V_SELECT_STATEMENT := v_hint_loc_ins_all ||
                        ' INSERT ' || v_hint_ins_all  ||
                        ' ALL    ' || V_WHEN_CLAUSE   || v_hint_loc_sel1 ||
                        ' SELECT ' || v_hint_sel1     || V_SELECT_CLAUSE ||
                        ' FROM   ' || V_FROM_CLAUSE   ||     ' '         ||
            case when V_NOT_EXISTS_CLAUSE is not null
            then V_NOT_EXISTS_CLAUSE
            else '' end;

  pout_insertStatement := V_SELECT_STATEMENT;
  pout_whenClause      := V_WHEN_CLAUSE;
  pout_selectClause    := V_SELECT_CLAUSE;
  pout_fromClause      := V_FROM_CLAUSE;
  pout_whereClause     := V_NOT_EXISTS_CLAUSE;

  --=========================================================================== Log output variables ===================================================================================--

  v_stamp := replace(v_stamp, 'input', 'output');
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_INSERTSTATEMENT), ',POUT_INSERTSTATEMENT => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_WHENCLAUSE),      ',POUT_WHENCLAUSE      => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_SELECTCLAUSE),    ',POUT_SELECTCLAUSE    => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_FROMCLAUSE),      ',POUT_FROMCLAUSE      => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(POUT_WHERECLAUSE),     ',POUT_WHERECLAUSE     => <value>', v_stamp);
  END;

END CALL_MODIFIERS;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************


END MODIFIERS;
/
