CREATE PACKAGE BODY HIERARCHY_OPTIONS AS

  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2015 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : PORTAL
  -- Module   : HIERARCHY
  -- Description    :
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

 FUNCTION RETURN_PERIOD(
    PIN_DATE DATE,
    PIN_PIN_TIME_UNIT_ID NUMBER)

RETURN VARCHAR2

AS

VAR_PERIOD NUMBER;

BEGIN

      SELECT TUPR_ID INTO VAR_PERIOD
      FROM TU_PERIODS_RANGE
      WHERE TUPR_TU_ID = PIN_PIN_TIME_UNIT_ID AND (TUPR_START_DATE = PIN_DATE
      OR TUPR_END_DATE = PIN_DATE);

      RETURN TO_CHAR(VAR_PERIOD);


EXCEPTION

  WHEN NO_DATA_FOUND
    THEN RETURN 'NULL';


END RETURN_PERIOD;




     FUNCTION RETURN_HIERARCHY_SELECT_PERIOD(

PIN_UPPER_ENTITY_VALUE NUMBER,
pin_upper_entity_id    NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
pin_upper_end_period_column VARCHAR2,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES

)


RETURN CLOB

IS

V_SELECT CLOB;
V_START_DATE_OF_DELETE VARCHAR2(50);
V_END_DATE_OF_DELETE VARCHAR2(50);

BEGIN

      IF (PIN_START_DATE_OF_DELETE IS NULL) THEN
          V_START_DATE_OF_DELETE := '= TO_DATE(''01/01/1900'', ''mm/dd/yyyy'') ';
      ELSE
          V_START_DATE_OF_DELETE := ' = ''' || PIN_START_DATE_OF_DELETE || '''';
      END IF;

      IF (PIN_END_DATE_OF_DELETE IS NULL) THEN
          V_END_DATE_OF_DELETE := ' = TO_DATE(''12/31/9999'', ''mm/dd/yyyy'') ';
      ELSE
          V_END_DATE_OF_DELETE := ' = ''' || PIN_END_DATE_OF_DELETE || '''';
      END IF;

      -- for periods

      -- inner select

      -- first select

      V_SELECT := '(SELECT ''' || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_TABLES(1).ENTITY_LOWER ||
            ' AS "ENTITY_TYPE_LOWER", '
            || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", '
            || PIN_RELATIONSHIP_TABLES(1).ENTITY_UPPER ||
            ' AS "ENTITY_TYPE_UPPER", '
            || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
            ' AS "ENTITY_ID_UPPER", '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME;

      --iterate rest of the selects

      FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST
        LOOP

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_TABLES(I).ENTITY_LOWER ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).ENTITY_UPPER ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
            ', '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME;

        END LOOP;


  -- outer select

  V_SELECT := 'SELECT TABLE_NAME, COL_LOWER, COL_UPPER, ENTITY_TYPE_LOWER, ENTITY_ID_LOWER, ENTITY_TYPE_UPPER, ENTITY_ID_UPPER, STARTDATE, ENDDATE, '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ', LEVEL FROM ( SELECT TABLE_NAME, COL_LOWER, COL_UPPER, ENTITY_TYPE_LOWER, ENTITY_ID_LOWER, ENTITY_TYPE_UPPER, ENTITY_ID_UPPER, NVL(TP.TUPR_START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AS "STARTDATE", NVL(TP2.TUPR_END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) AS "ENDDATE", '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || V_SELECT ||
            ') LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
            || PIN_UPPER_END_PERIOD_COLUMN;



  -- connect by

  V_SELECT := V_SELECT ||
            ') START WITH ENTITY_ID_LOWER = '
            || PIN_UPPER_ENTITY_VALUE ||
            ' AND ENTITY_TYPE_LOWER = '
            || PIN_UPPER_ENTITY_ID ||
            ' AND STARTDATE'
            || V_START_DATE_OF_DELETE ||
            ' AND ENDDATE'
            || V_END_DATE_OF_DELETE ||
            ' CONNECT BY PRIOR ENTITY_ID_LOWER = ENTITY_ID_UPPER AND PRIOR ENTITY_TYPE_LOWER = ENTITY_TYPE_UPPER ORDER BY LEVEL';

  RETURN V_SELECT;

END RETURN_HIERARCHY_SELECT_PERIOD;





     FUNCTION RETURN_HIERARCHY_SELECT_DATE(

PIN_UPPER_ENTITY_VALUE NUMBER,
pin_upper_entity_id    NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES

)

RETURN CLOB

IS

V_SELECT CLOB;
V_START_DATE_OF_DELETE VARCHAR2(50);
V_END_DATE_OF_DELETE VARCHAR2(50);

BEGIN

      IF (PIN_START_DATE_OF_DELETE IS NULL) THEN
          V_START_DATE_OF_DELETE := '= TO_DATE(''01/01/1900'', ''mm/dd/yyyy'') ';
      ELSE
          V_START_DATE_OF_DELETE := ' = TO_DATE(''' || TO_CHAR(PIN_START_DATE_OF_DELETE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
      END IF;

      IF (PIN_END_DATE_OF_DELETE IS NULL) THEN
          V_END_DATE_OF_DELETE := ' = TO_DATE(''12/31/9999'', ''mm/dd/yyyy'') ';
      ELSE
          V_END_DATE_OF_DELETE := ' = TO_DATE(''' || TO_CHAR(PIN_END_DATE_OF_DELETE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
      END IF;

      -- for dates

     -- inner select

      -- first select

      V_SELECT := '(SELECT ''' || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_TABLES(1).ENTITY_LOWER ||
            ' AS "ENTITY_TYPE_LOWER", '
            || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", '
            || PIN_RELATIONSHIP_TABLES(1).ENTITY_UPPER ||
            ' AS "ENTITY_TYPE_UPPER", '
            || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
            ' AS "ENTITY_ID_UPPER", NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AS "TUPR_START_DATE", NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) AS "TUPR_END_DATE" FROM '
            || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME;

      --iterate rest of the selects

      FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST
        LOOP

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_TABLES(I).ENTITY_LOWER ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).ENTITY_UPPER ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
            ', NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')), NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) FROM '
            || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME;

        END LOOP;


  -- outer select

  V_SELECT := 'SELECT TABLE_NAME, COL_LOWER, COL_UPPER, ENTITY_TYPE_LOWER, ENTITY_ID_LOWER, ENTITY_TYPE_UPPER, ENTITY_ID_UPPER, TUPR_START_DATE, TUPR_END_DATE, LEVEL FROM ('
            || V_SELECT ||
            ')';


  -- connect by

  V_SELECT := V_SELECT ||
            ') START WITH ENTITY_ID_LOWER = '
            || PIN_UPPER_ENTITY_VALUE ||
            ' AND ENTITY_TYPE_LOWER = '
            || PIN_UPPER_ENTITY_ID ||
            ' AND TUPR_START_DATE'
            || V_START_DATE_OF_DELETE ||
            ' AND TUPR_END_DATE'
            || V_END_DATE_OF_DELETE ||
            ' CONNECT BY PRIOR ENTITY_ID_LOWER = ENTITY_ID_UPPER AND PRIOR ENTITY_TYPE_LOWER = ENTITY_TYPE_UPPER ORDER BY LEVEL';


  RETURN V_SELECT;

END RETURN_HIERARCHY_SELECT_DATE;




PROCEDURE DELETE_DATE_PERIOD_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
pin_upper_entity_id    NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER

)


IS

TYPE LOOP_RECORD_TYPE IS RECORD(
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_TYPE_LOWER NUMERIC(10),
ENTITY_ID_LOWER NUMERIC(10),
ENTITY_TYPE_UPPER NUMERIC(10),
ENTITY_ID_UPPER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE,
START_PERIOD NUMERIC(10),
END_PERIOD NUMERIC(10),
LEVEL NUMERIC(10)
);

LOOP_RECORD LOOP_RECORD_TYPE;

TYPE DATE_REC IS RECORD (
STARTDATE DATE,
enddate DATE);

TYPE DATE_TABLE IS TABLE OF date_rec INDEX BY VARCHAR2(100);

V_DATE_LIST DATE_TABLE;
V_DATE_LIST2 DATE_TABLE;

var_cursor sys_refcursor;

VAR_TEST BOOLEAN :=TRUE;
var_level number := 2;

VAR_NUMBER_OF_OC NUMBER;
V_TO_COMPARE VARCHAR2(250);
V_TO_ADD VARCHAR2(250);
VAR_SEARCH_OF_OC NUMBER;

TYPE TABLE_REC IS RECORD (
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ID_LOWER NUMERIC(10,0),
ID_UPPER NUMERIC(10,0),
STARTDATE DATE,
ENDDATE DATE,
OLD_STARTDATE DATE,
OLD_ENDDATE DATE,
START_PERIOD NUMBER,
END_PERIOD NUMBER);

TYPE TABLE_MOD IS TABLE OF TABLE_REC;

VAR_INSERT_TABLE TABLE_MOD := TABLE_MOD();

VAR_UPDATE_TABLE TABLE_MOD := TABLE_MOD();

VAR_DELETE_TABLE TABLE_MOD := TABLE_MOD();

VAR_INSERT TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_UPDATE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_DELETE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

V_INSERT_TABLES VARCHAR2(32767) := '';

V_UPD_DEL_TABLES VARCHAR2(32767) := '';

VAR_ROW_IDENTIFIER NUMBER;

VAR_START_DATE VARCHAR2(100);
VAR_END_DATE VARCHAR2(100);
VAR_OLD_START_DATE VARCHAR2(100);
VAR_OLD_END_DATE VARCHAR2(100);


BEGIN

-- get select for cursor

-- open the cursor

  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN

-- for date

      open var_cursor for RETURN_HIERARCHY_SELECT_DATE(
      PIN_UPPER_ENTITY_VALUE,
      pin_upper_entity_id,
      PIN_START_DATE_OF_DELETE,
      PIN_END_DATE_OF_DELETE,
      PIN_RELATIONSHIP_TABLES);

  ELSE

-- for period

      open var_cursor for RETURN_HIERARCHY_SELECT_PERIOD(
      PIN_UPPER_ENTITY_VALUE,
      pin_upper_entity_id,
      PIN_START_DATE_OF_DELETE,
      PIN_END_DATE_OF_DELETE,
      PIN_UPPER_START_PERIOD_COLUMN,
      PIN_UPPER_END_PERIOD_COLUMN,
      PIN_RELATIONSHIP_TABLES);

    END IF;

-- initialize start dates of the first delete

      V_DATE_LIST('0+' || PIN_UPPER_ENTITY_VALUE || '+' || PIN_UPPER_ENTITY_ID).STARTDATE:= NVL(PIN_START_DATE_OF_DELETE, TO_DATE('01/01/1900', 'mm/dd/yyyy'));
      V_DATE_LIST('0+' || PIN_UPPER_ENTITY_VALUE || '+' || pin_upper_entity_id).ENDDATE:= NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'));

-- add the start of hierarchy in the delete table (fetch the first record)

IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
      FETCH VAR_CURSOR
      INTO  LOOP_RECORD.TABLE_NAME,
        LOOP_RECORD.COL_LOWER,
        LOOP_RECORD.COL_UPPER,
        LOOP_RECORD.ENTITY_TYPE_LOWER,
        LOOP_RECORD.ENTITY_ID_LOWER,
        LOOP_RECORD.ENTITY_TYPE_UPPER,
        LOOP_RECORD.ENTITY_ID_UPPER,
        LOOP_RECORD.STARTDATE,
        LOOP_RECORD.ENDDATE,
        LOOP_RECORD.LEVEL;

        VAR_DELETE_TABLE.EXTEND;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;

        V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

    ELSE
      FETCH VAR_CURSOR
        INTO  LOOP_RECORD.TABLE_NAME,
          LOOP_RECORD.COL_LOWER,
          LOOP_RECORD.COL_UPPER,
          LOOP_RECORD.ENTITY_TYPE_LOWER,
          LOOP_RECORD.ENTITY_ID_LOWER,
          LOOP_RECORD.ENTITY_TYPE_UPPER,
          LOOP_RECORD.ENTITY_ID_UPPER,
          LOOP_RECORD.STARTDATE,
          LOOP_RECORD.ENDDATE,
          LOOP_RECORD.START_PERIOD,
          LOOP_RECORD.END_PERIOD,
          LOOP_RECORD.LEVEL;

        VAR_DELETE_TABLE.EXTEND;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
        VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;

        V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

END IF;


-- start loop for cursor

LOOP
    IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN

    -- the fetch for dates

      FETCH VAR_CURSOR
      INTO  LOOP_RECORD.TABLE_NAME,
        LOOP_RECORD.COL_LOWER,
        LOOP_RECORD.COL_UPPER,
        LOOP_RECORD.ENTITY_TYPE_LOWER,
        LOOP_RECORD.ENTITY_ID_LOWER,
        LOOP_RECORD.ENTITY_TYPE_UPPER,
        LOOP_RECORD.ENTITY_ID_UPPER,
        LOOP_RECORD.STARTDATE,
        LOOP_RECORD.ENDDATE,
        LOOP_RECORD.LEVEL;
        EXIT WHEN VAR_CURSOR%NOTFOUND;

    ELSE

    -- the fetch for periods

      FETCH VAR_CURSOR
        INTO  LOOP_RECORD.TABLE_NAME,
          LOOP_RECORD.COL_LOWER,
          LOOP_RECORD.COL_UPPER,
          LOOP_RECORD.ENTITY_TYPE_LOWER,
          LOOP_RECORD.ENTITY_ID_LOWER,
          LOOP_RECORD.ENTITY_TYPE_UPPER,
          LOOP_RECORD.ENTITY_ID_UPPER,
          LOOP_RECORD.STARTDATE,
          LOOP_RECORD.ENDDATE,
          LOOP_RECORD.START_PERIOD,
          LOOP_RECORD.END_PERIOD,
          LOOP_RECORD.LEVEL;
          EXIT WHEN VAR_CURSOR%NOTFOUND;


    END IF;
      -- the entity id and type of the current record and of the parent to search for

      VAR_NUMBER_OF_OC := 0;
      V_TO_COMPARE := LOOP_RECORD.ENTITY_ID_UPPER || '+' || LOOP_RECORD.ENTITY_TYPE_UPPER;
      V_TO_ADD := LOOP_RECORD.ENTITY_ID_LOWER || '+' || LOOP_RECORD.ENTITY_TYPE_LOWER;

      -- check if level has been changed

      IF (LOOP_RECORD.LEVEL <> VAR_LEVEL) THEN
        IF (VAR_TEST) THEN
          VAR_TEST := NOT VAR_TEST;
          V_DATE_LIST.DELETE;
          VAR_LEVEL := LOOP_RECORD.level;
        ELSE
          VAR_TEST := NOT VAR_TEST;
          V_DATE_LIST2.DELETE;
          VAR_LEVEL := LOOP_RECORD.level;
        END IF;
      END IF;


-- if the level is odd

        IF (VAR_TEST) THEN

-- if for the first value

          WHILE (V_DATE_LIST.EXISTS(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE))
            LOOP

                            IF (V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).STARTDATE <= LOOP_RECORD.STARTDATE) THEN
                              IF (V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).ENDDATE >= LOOP_RECORD.ENDDATE) THEN

-- if the record is between start date and end date of the parent

                               VAR_SEARCH_OF_OC := 0;

                               WHILE (V_DATE_LIST2.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                               LOOP
                                 VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                               END LOOP;

                                V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE := LOOP_RECORD.STARTDATE;
                                V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE := LOOP_RECORD.ENDDATE;

                                  VAR_DELETE_TABLE.EXTEND;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                  ELSE
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                  END IF;

                                  V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

                              ELSE

                                IF (V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate >= LOOP_RECORD.startdate) THEN

-- if the record and parent dates intersect

                                   VAR_SEARCH_OF_OC := 0;

                                   WHILE (V_DATE_LIST2.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                   LOOP
                                     VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                   END LOOP;

                                  V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE := LOOP_RECORD.STARTDATE;
                                  V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate;

                                  VAR_UPDATE_TABLE.EXTEND;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).STARTDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate+1;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ENDDATE := LOOP_RECORD.ENDDATE;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                  ELSE
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                  END IF;

                                  V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

                                END IF;

                                END IF;

                            ELSIF (V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate < LOOP_RECORD.enddate) THEN

-- if the parent dates are between the record dates


                                VAR_SEARCH_OF_OC := 0;

                                WHILE (V_DATE_LIST2.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                LOOP
                                   VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                END LOOP;

                                V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate;
                                V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate;

                                  VAR_UPDATE_TABLE.EXTEND;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).STARTDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate+1;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ENDDATE := LOOP_RECORD.ENDDATE;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                  ELSE
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                  END IF;

                                  V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

-- insert second parent

                                    VAR_INSERT_TABLE.EXTEND;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).STARTDATE := LOOP_RECORD.startdate;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).ENDDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate-1;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                    V_INSERT_TABLES := V_INSERT_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;


                              ELSE

                                  IF (V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate <= LOOP_RECORD.enddate) THEN

-- if the record and parent dates intersect

                                    VAR_SEARCH_OF_OC := 0;

                                    WHILE (V_DATE_LIST2.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                    LOOP
                                       VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                    END LOOP;

                                    V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE:=V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate;
                                    V_DATE_LIST2(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE:=LOOP_RECORD.ENDDATE;

                                    VAR_UPDATE_TABLE.EXTEND;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ENDDATE := V_DATE_LIST(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate-1;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                    IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                    ELSE
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                    END IF;

                                    V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

                                END IF;

                            end if;


                   VAR_NUMBER_OF_OC := VAR_NUMBER_OF_OC + 1;

               END LOOP;

          ELSE


                  WHILE (V_DATE_LIST2.EXISTS(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE))
                    LOOP
          -- if the level number is even


                          -- if for the first value

                             IF (V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).STARTDATE <= LOOP_RECORD.STARTDATE) THEN
                              IF (V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate >= LOOP_RECORD.enddate) THEN

-- if the record is between start date and end date of the parent

                                    VAR_SEARCH_OF_OC := 0;

                                    WHILE (V_DATE_LIST.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                    LOOP
                                       VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                    END LOOP;

                                V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE:=LOOP_RECORD.STARTDATE;
                                V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).enddate:=LOOP_RECORD.enddate;

                                  VAR_DELETE_TABLE.EXTEND;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                  VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                  ELSE
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                    VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                  END IF;

                                  V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;
                              ELSE

                                IF (V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate >= LOOP_RECORD.startdate) THEN

-- if the record and parent dates intersect

                                    VAR_SEARCH_OF_OC := 0;

                                    WHILE (V_DATE_LIST.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                    LOOP
                                       VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                    END LOOP;

                                  V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE := LOOP_RECORD.STARTDATE;
                                  V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate;

                                  VAR_UPDATE_TABLE.EXTEND;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).STARTDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate+1;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ENDDATE := LOOP_RECORD.ENDDATE;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                  ELSE
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                  END IF;

                                  V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

                                END IF;
                                END IF;

                            ELSIF (V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate < LOOP_RECORD.enddate) THEN

-- if the parent dates are between the record dates

                                    VAR_SEARCH_OF_OC := 0;

                                    WHILE (V_DATE_LIST.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                    LOOP
                                       VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                    END LOOP;

                                V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate;
                                V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate;

                                  VAR_UPDATE_TABLE.EXTEND;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).STARTDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).enddate+1;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ENDDATE := LOOP_RECORD.ENDDATE;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                  VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                  IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                  ELSE
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                  END IF;

                                  V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

-- add the second child

                                    VAR_INSERT_TABLE.EXTEND;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).STARTDATE := LOOP_RECORD.startdate;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).ENDDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate-1;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                    VAR_INSERT_TABLE(VAR_INSERT_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                    V_INSERT_TABLES := V_INSERT_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;


                              ELSE

                                  IF (V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate <= LOOP_RECORD.enddate) THEN

-- if the record and parent dates intersect

                                    VAR_SEARCH_OF_OC := 0;

                                    WHILE (V_DATE_LIST.EXISTS(VAR_SEARCH_OF_OC || '+' || V_TO_ADD))
                                    LOOP
                                       VAR_SEARCH_OF_OC := VAR_SEARCH_OF_OC + 1;
                                    END LOOP;

                                  V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).STARTDATE := LOOP_RECORD.ENDDATE;
                                  V_DATE_LIST(VAR_SEARCH_OF_OC || '+' || V_TO_ADD).ENDDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate;

                                    VAR_UPDATE_TABLE.EXTEND;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).STARTDATE := LOOP_RECORD.STARTDATE;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ENDDATE := V_DATE_LIST2(VAR_NUMBER_OF_OC || '+' || V_TO_COMPARE).startdate-1;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                                    VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                                    IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_STARTDATE := LOOP_RECORD.STARTDATE;
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).OLD_ENDDATE := LOOP_RECORD.ENDDATE;
                                    ELSE
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).START_PERIOD := LOOP_RECORD.START_PERIOD;
                                      VAR_UPDATE_TABLE(VAR_UPDATE_TABLE.LAST).END_PERIOD := LOOP_RECORD.END_PERIOD;
                                    END IF;

                                    V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

                                END IF;

                            END IF;

                    VAR_NUMBER_OF_OC := VAR_NUMBER_OF_OC + 1;

              END LOOP;

        END IF;

--end of cursor loop

    END LOOP;

--close the cursor

CLOSE VAR_CURSOR;


-- making the changes in the tables

  V_UPD_DEL_TABLES := SUBSTR(V_UPD_DEL_TABLES, 3);
  POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

  IF (VAR_UPDATE_TABLE.FIRST IS NOT NULL) THEN

-- update for dates

    IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN

        FOR I IN VAR_UPDATE_TABLE.FIRST .. VAR_UPDATE_TABLE.LAST
        LOOP
              VAR_UPDATE.EXTEND;
              VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, VAR_UPDATE_TABLE(I).TABLE_NAME);

              IF (VAR_UPDATE_TABLE(I).STARTDATE = TO_DATE('01/01/1900', 'mm/dd/yyyy')) THEN
                VAR_START_DATE := 'NULL';
              ELSE
                VAR_START_DATE := 'TO_DATE(''' || TO_CHAR(VAR_UPDATE_TABLE(I).STARTDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
              END IF;

              IF (VAR_UPDATE_TABLE(I).ENDDATE = TO_DATE('12/31/9999', 'mm/dd/yyyy')) THEN
                VAR_END_DATE := 'NULL';
              ELSE
                VAR_END_DATE := 'TO_DATE(''' || TO_CHAR(VAR_UPDATE_TABLE(I).ENDDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
              END IF;

              VAR_OLD_START_DATE := ' = TO_DATE(''' || TO_CHAR(NVL(VAR_UPDATE_TABLE(I).OLD_STARTDATE, TO_DATE('01/01/1900', 'mm/dd/yyyy')), 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
              VAR_OLD_END_DATE := ' = TO_DATE(''' || TO_CHAR(NVL(VAR_UPDATE_TABLE(I).OLD_ENDDATE, TO_DATE('12/31/9999', 'mm/dd/yyyy')), 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';


              EXECUTE IMMEDIATE 'UPDATE ' || VAR_UPDATE_TABLE(I).TABLE_NAME ||
                                ' SET START_DATE = ' || VAR_START_DATE || ', END_DATE = ' || VAR_END_DATE ||
                                ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                || VAR_UPDATE_TABLE(I).COL_LOWER ||
                                ' = '
                                || VAR_UPDATE_TABLE(I).ID_LOWER ||
                                ' AND '
                                || VAR_UPDATE_TABLE(I).COL_UPPER ||
                                ' = '
                                || VAR_UPDATE_TABLE(I).ID_UPPER ||
                                ' AND COALESCE(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) '
                                || VAR_OLD_START_DATE ||
                                ' AND COALESCE(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) '
                                || VAR_OLD_END_DATE ||
                                ' RETURNING ROW_IDENTIFIER INTO :1'
              RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

        END LOOP;

--update for periods

    ELSE
        FOR I IN VAR_UPDATE_TABLE.FIRST .. VAR_UPDATE_TABLE.LAST
        LOOP
              VAR_UPDATE.EXTEND;
              VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, VAR_UPDATE_TABLE(I).TABLE_NAME);

              VAR_START_DATE := RETURN_PERIOD(VAR_UPDATE_TABLE(I).STARTDATE, PIN_TIME_UNIT_ID);

              VAR_END_DATE := RETURN_PERIOD(VAR_UPDATE_TABLE(I).ENDDATE, PIN_TIME_UNIT_ID);

              IF (VAR_UPDATE_TABLE(I).START_PERIOD IS NULL) THEN
                VAR_OLD_START_DATE := 'IS NULL';
              ELSE
                VAR_OLD_START_DATE := '= ' || TO_CHAR(VAR_UPDATE_TABLE(I).START_PERIOD);
              END IF;

              IF (VAR_UPDATE_TABLE(I).END_PERIOD IS NULL) THEN
                VAR_OLD_END_DATE := 'IS NULL';
              ELSE
                VAR_OLD_END_DATE := '= ' || TO_CHAR(VAR_UPDATE_TABLE(I).END_PERIOD);
              END IF;



              EXECUTE IMMEDIATE 'UPDATE ' || VAR_UPDATE_TABLE(I).TABLE_NAME ||
                                ' SET '
                                || pin_upper_START_period_column ||
                                ' = '
                                || VAR_START_DATE ||
                                ', '
                                || pin_upper_END_period_column ||
                                ' = '
                                || VAR_END_DATE ||
                                ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                || VAR_UPDATE_TABLE(I).COL_LOWER ||
                                ' = '
                                || VAR_UPDATE_TABLE(I).ID_LOWER ||
                                ' AND '
                                || VAR_UPDATE_TABLE(I).COL_UPPER ||
                                ' = '
                                || VAR_UPDATE_TABLE(I).ID_UPPER ||
                                ' AND '
                                || PIN_UPPER_START_PERIOD_COLUMN ||
                                ' '
                                || VAR_OLD_START_DATE ||
                                ' AND '
                                || PIN_UPPER_END_PERIOD_COLUMN ||
                                ' '
                                || VAR_OLD_END_DATE ||
                                ' RETURNING ROW_IDENTIFIER INTO :1'
              RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

        END loop;


    END IF;

    END IF;

-- deleting rows from the table


IF (PIN_IS_EFFECTIVE_PERIOD = 1) THEN

-- delete for periods

    IF (VAR_DELETE_TABLE.FIRST IS NOT NULL) THEN

        FOR I IN VAR_DELETE_TABLE.FIRST .. VAR_DELETE_TABLE.LAST
        LOOP
              VAR_DELETE.EXTEND;
              VAR_DELETE(VAR_DELETE.LAST) := OBJTYPE_ID_NAME(1, VAR_DELETE_TABLE(I).TABLE_NAME);

              IF (VAR_DELETE_TABLE(I).START_PERIOD IS NULL) THEN
                  VAR_OLD_START_DATE := ' IS NULL';
              ELSE
                  VAR_OLD_START_DATE := ' = ' || VAR_DELETE_TABLE(I).START_PERIOD;
              END IF;

              IF (VAR_DELETE_TABLE(I).END_PERIOD IS NULL) THEN
                  VAR_OLD_END_DATE := ' IS NULL';
              ELSE
                  VAR_OLD_END_DATE := ' = ' || VAR_DELETE_TABLE(I).END_PERIOD;
              END IF;

              EXECUTE IMMEDIATE 'DELETE FROM ' || VAR_DELETE_TABLE(I).TABLE_NAME ||
                                ' WHERE '
                                || VAR_DELETE_TABLE(I).COL_LOWER ||
                                ' = '
                                || VAR_DELETE_TABLE(I).ID_LOWER ||
                                ' AND '
                                || VAR_DELETE_TABLE(I).COL_UPPER ||
                                ' = '
                                || VAR_DELETE_TABLE(I).ID_UPPER ||
                                ' AND '
                                || PIN_UPPER_START_PERIOD_COLUMN ||
                                VAR_OLD_START_DATE ||
                                ' AND '
                                || PIN_UPPER_END_PERIOD_COLUMN
                                || VAR_OLD_END_DATE ||
                                ' RETURNING ROW_IDENTIFIER INTO :1'
              RETURNING INTO VAR_DELETE(VAR_DELETE.LAST).ID;

        END loop;

    END IF;


  ELSE

-- delete for dates


    IF (VAR_DELETE_TABLE.FIRST IS NOT NULL) THEN

        FOR I IN VAR_DELETE_TABLE.FIRST .. VAR_DELETE_TABLE.LAST
        LOOP
              VAR_DELETE.EXTEND;
              VAR_DELETE(VAR_DELETE.LAST) := OBJTYPE_ID_NAME(1, VAR_DELETE_TABLE(I).TABLE_NAME);

              VAR_OLD_START_DATE := '= TO_DATE(''' || TO_CHAR(NVL(VAR_DELETE_TABLE(I).OLD_STARTDATE, TO_DATE('01/01/1900', 'mm/dd/yyyy')), 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
              VAR_OLD_END_DATE := '= TO_DATE(''' || TO_CHAR(NVL(VAR_DELETE_TABLE(I).OLD_ENDDATE, TO_DATE('12/31/9999', 'mm/dd/yyyy')), 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';

              EXECUTE IMMEDIATE 'DELETE FROM ' || VAR_DELETE_TABLE(I).TABLE_NAME ||
                                ' WHERE '
                                || VAR_DELETE_TABLE(I).COL_LOWER ||
                                ' = '
                                || VAR_DELETE_TABLE(I).ID_LOWER ||
                                ' AND '
                                || VAR_DELETE_TABLE(I).COL_UPPER ||
                                ' = '
                                || VAR_DELETE_TABLE(I).ID_UPPER ||
                                ' AND NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) '
                                || VAR_OLD_START_DATE ||
                                ' AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) '
                                || VAR_OLD_END_DATE ||
                                ' RETURNING ROW_IDENTIFIER INTO :1'
              RETURNING INTO VAR_DELETE(VAR_DELETE.LAST).ID;

        END loop;

    END IF;

END IF;

-- inserting the new rows for dates

      IF (VAR_INSERT_TABLE.FIRST IS NOT NULL) THEN

        IF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN

        FOR I IN VAR_INSERT_TABLE.FIRST .. VAR_INSERT_TABLE.LAST
        LOOP
              VAR_INSERT.EXTEND;
              VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, VAR_INSERT_TABLE(I).TABLE_NAME);



             EXECUTE IMMEDIATE 'SELECT '
                              || VAR_INSERT_TABLE(I).TABLE_NAME ||
                              '_ROW_IDENTIFIER_SEQ.NEXTVAL FROM DUAL'
              INTO VAR_ROW_IDENTIFIER;

              IF (VAR_INSERT_TABLE(I).STARTDATE = TO_DATE('01/01/1900', 'mm/dd/yyyy')) THEN
                VAR_START_DATE := 'NULL';
              ELSE
                VAR_START_DATE := 'TO_DATE(''' || TO_CHAR(VAR_INSERT_TABLE(I).STARTDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
              END IF;

              IF (VAR_INSERT_TABLE(I).ENDDATE = TO_DATE('12/31/9999', 'mm/dd/yyyy')) THEN
                VAR_END_DATE := 'NULL';
              ELSE
                VAR_END_DATE := 'TO_DATE(''' || TO_CHAR(VAR_INSERT_TABLE(I).ENDDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
              END IF;

              EXECUTE IMMEDIATE 'INSERT INTO ' || VAR_INSERT_TABLE(I).TABLE_NAME ||
                                '( '
                                || VAR_INSERT_TABLE(I).COL_LOWER ||
                                ', '
                                || VAR_INSERT_TABLE(I).COL_UPPER ||
                                ', START_DATE, END_DATE, ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                || VAR_INSERT_TABLE(I).ID_LOWER ||
                                ', '
                                || VAR_INSERT_TABLE(I).ID_UPPER ||
                                ', '
                                || VAR_START_DATE ||
                                ', '
                                || VAR_END_DATE ||
                                ', '
                                || VAR_ROW_IDENTIFIER ||
                                ', 0)';
              VAR_INSERT(VAR_INSERT.LAST).ID:=VAR_ROW_IDENTIFIER;

        END LOOP;

      ELSE

-- insert for periods

         FOR I IN VAR_INSERT_TABLE.FIRST .. VAR_INSERT_TABLE.LAST
        LOOP
              VAR_INSERT.EXTEND;
              VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, VAR_INSERT_TABLE(I).TABLE_NAME);

              EXECUTE IMMEDIATE 'SELECT '
                              || VAR_INSERT_TABLE(I).TABLE_NAME ||
                              '_ROW_IDENTIFIER_SEQ.NEXTVAL FROM DUAL'
              INTO VAR_ROW_IDENTIFIER;


              VAR_START_DATE := RETURN_PERIOD(VAR_INSERT_TABLE(I).STARTDATE, PIN_TIME_UNIT_ID);

              VAR_END_DATE := RETURN_PERIOD(VAR_INSERT_TABLE(I).ENDDATE, PIN_TIME_UNIT_ID);

              EXECUTE IMMEDIATE 'INSERT INTO ' || VAR_INSERT_TABLE(I).TABLE_NAME ||
                                '( '
                                || VAR_INSERT_TABLE(I).COL_LOWER ||
                                ', '
                                || VAR_INSERT_TABLE(I).COL_UPPER ||
                                ', '
                                || PIN_UPPER_START_PERIOD_COLUMN ||
                                ', '
                                || PIN_UPPER_END_PERIOD_COLUMN ||
                                ', ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                || VAR_INSERT_TABLE(I).ID_LOWER ||
                                ', '
                                || VAR_INSERT_TABLE(I).ID_UPPER ||
                                ', '
                                || VAR_START_DATE ||
                                ', '
                                || VAR_END_DATE ||
                                ', '
                                || VAR_ROW_IDENTIFIER ||
                                ', 0)';
              VAR_INSERT(VAR_INSERT.LAST).ID:=VAR_ROW_IDENTIFIER;

        END LOOP;

    END IF;



  END IF;



--  assigning the values for the output variables

        POUT_INSERTED_ROWS := VAR_INSERT;
        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;




END DELETE_DATE_PERIOD_HIERARCHY;


PROCEDURE DELETE_ONLY_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
pin_upper_entity_id    NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER

)

IS

V_SELECT CLOB;

VAR_CURSOR SYS_REFCURSOR;

TYPE LOOP_RECORD_TYPE IS RECORD(
TABLE_NAME VARCHAR2(250),
COL_LOWER VARCHAR2(250),
COL_UPPER VARCHAR2(250),
ENTITY_ID_LOWER NUMBER(10),
ENTITY_ID_UPPER NUMBER(10)
);

LOOP_RECORD LOOP_RECORD_TYPE;

TYPE TABLE_REC IS RECORD (
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ID_LOWER NUMBER(10,0),
ID_UPPER NUMBER(10,0));

TYPE TABLE_MOD IS TABLE OF TABLE_REC;

VAR_DELETE_TABLE TABLE_MOD := TABLE_MOD();

VAR_DELETE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

V_DELETE_TABLES VARCHAR2(32767) := '';

BEGIN

  IF (PIN_IS_EFFECTIVE_PERIOD IS NOT NULL) THEN

  --cal procedure to delete for periods and dates

    DELETE_DATE_PERIOD_HIERARCHY(

      PIN_UPPER_ENTITY_VALUE,
      pin_upper_entity_id,
      PIN_START_DATE_OF_DELETE,
      PIN_END_DATE_OF_DELETE,
      PIN_IS_EFFECTIVE_PERIOD,
      PIN_UPPER_START_PERIOD_COLUMN,
      PIN_UPPER_END_PERIOD_COLUMN,
      PIN_TIME_UNIT_ID,
      pin_relationship_tables,

      POUT_INSERTED_ROWS,
      POUT_UPDATED_ROWS,
      POUT_DELETED_ROWS,
      POUT_SCN);




    ELSE

            V_SELECT := 'SELECT ''' || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_TABLES(1).ENTITY_LOWER ||
            ' AS "ENTITY_TYPE_LOWER", '
            || PIN_RELATIONSHIP_TABLES(1).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", '
            || PIN_RELATIONSHIP_TABLES(1).ENTITY_UPPER ||
            ' AS "ENTITY_TYPE_UPPER", '
            || PIN_RELATIONSHIP_TABLES(1).VALUE_UPPER_COL ||
            ' AS "ENTITY_ID_UPPER" FROM '
            || PIN_RELATIONSHIP_TABLES(1).TABLE_NAME;

      --iterate rest of the selects

      FOR I IN pin_relationship_tables.FIRST+1 .. pin_relationship_tables.LAST
        LOOP

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_TABLES(I).ENTITY_LOWER ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).VALUE_LOWER_COL ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).ENTITY_UPPER ||
            ', '
            || PIN_RELATIONSHIP_TABLES(I).VALUE_UPPER_COL ||
            ' FROM '
            || PIN_RELATIONSHIP_TABLES(I).TABLE_NAME;

        END LOOP;

  -- outer select

  V_SELECT := 'SELECT TABLE_NAME, COL_LOWER, COL_UPPER, ENTITY_ID_LOWER, ENTITY_ID_UPPER FROM ('
            || V_SELECT ||
            ')';

  -- connect by

  V_SELECT := V_SELECT ||
            ' START WITH ENTITY_ID_LOWER = '
            || PIN_UPPER_ENTITY_VALUE ||
            ' AND ENTITY_TYPE_LOWER = '
            || PIN_UPPER_ENTITY_ID ||
            ' CONNECT BY PRIOR ENTITY_ID_LOWER = ENTITY_ID_UPPER AND PRIOR ENTITY_TYPE_LOWER = ENTITY_TYPE_UPPER';

-- open cursor

    open var_cursor for V_SELECT;

-- start loop for cursor

LOOP
    FETCH VAR_CURSOR
    INTO  LOOP_RECORD.TABLE_NAME,
      LOOP_RECORD.COL_LOWER,
      LOOP_RECORD.COL_UPPER,
      LOOP_RECORD.ENTITY_ID_LOWER,
      LOOP_RECORD.ENTITY_ID_UPPER;
    EXIT WHEN var_cursor%NOTFOUND;

                 VAR_DELETE_TABLE.EXTEND;
                 VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).TABLE_NAME := LOOP_RECORD.TABLE_NAME;
                 VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_LOWER := LOOP_RECORD.COL_LOWER;
                 VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).COL_UPPER := LOOP_RECORD.COL_UPPER;
                 VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_LOWER := LOOP_RECORD.ENTITY_ID_LOWER;
                 VAR_DELETE_TABLE(VAR_DELETE_TABLE.LAST).ID_UPPER := LOOP_RECORD.ENTITY_ID_UPPER;

                V_DELETE_TABLES := V_DELETE_TABLES || ', ' || LOOP_RECORD.TABLE_NAME;

END LOOP;

-- close cursor

	close var_cursor;

-- delete all the nodes

    IF (VAR_DELETE_TABLE.FIRST IS NOT NULL) THEN

    V_DELETE_TABLES := substr( V_DELETE_TABLES, 3);
      POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_DELETE_TABLES);

      FOR I IN VAR_DELETE_TABLE.FIRST .. VAR_DELETE_TABLE.LAST
        LOOP
              VAR_DELETE.EXTEND;
              VAR_DELETE(VAR_DELETE.LAST) := OBJTYPE_ID_NAME(1, VAR_DELETE_TABLE(I).TABLE_NAME);

              EXECUTE IMMEDIATE 'DELETE FROM ' || VAR_DELETE_TABLE(I).TABLE_NAME ||
                                ' WHERE '
                                || VAR_DELETE_TABLE(I).COL_LOWER ||
                                ' = '
                                || VAR_DELETE_TABLE(I).ID_LOWER ||
                                ' AND '
                                || VAR_DELETE_TABLE(I).COL_UPPER ||
                                ' = '
                                || VAR_DELETE_TABLE(I).ID_UPPER ||
                                ' RETURNING ROW_IDENTIFIER INTO :1'
              RETURNING INTO VAR_DELETE(VAR_DELETE.LAST).ID;

        END loop;

    END IF;

    POUT_DELETED_ROWS := VAR_DELETE;

  END IF;




END DELETE_ONLY_HIERARCHY;

  -- ############################# DELETE_AND_MOVE_HIERARCHY START #############################
  -- Author     :
  -- Create date:
  -- Reviewer :
  -- Review date:
  -- Description: Function for Delete and Move Hierarchy
   -----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Deletes and Moves in Portal Hierarchy
      -- Input Parameters:
      --    ->> INPUT
--pin_upper_entity_value (internal id)
--pin_upper_entity_id
--pin_start_date_of_delete (date, even if it is period)
--pin_end_date_of_delete
--pin_is_effective_period (1 for period, 0 for date, null for not effective dated)
--pin_upper_start_period_column (for period, the columns' name from fields, ex 'start quarter')
--pin_upper_end_period_column
--pin_time_unit_id (for period, time unit to use)
--PIN_NEW_PARENT_ENTITY_VALUE (the internal id of the new parent)
--PIN_RELATIONSHIP_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES)
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name

--->> OUTPUT
--pout_inserted_rows (TYPE TABLETYPE_ID_NAME)
--                - row_id
--                - table name
--pout_updated_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_deleted_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_scn (number)
--pout_update_validation - Returns 0 if the validations pass, 1 if there are cycles or 2 if there is an entity with more than one parent

   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      DECLARE
      POUT_INSERTED_ROWS TABLETYPE_ID_NAME;
      POUT_UPDATED_ROWS TABLETYPE_ID_NAME;
      POUT_DELETED_ROWS TABLETYPE_ID_NAME;
      POUT_SCN NUMBER;
    POUT_UPDATE_VALIDATION NUMBER;
      BEGIN
      DELETE_FROM_HIERARCHY.DELETE_HIERARCHY(PIN_UPPER_ENTITY_VALUE => 100,
                                  pin_upper_entity_id    => 2,
                                  PIN_START_DATE_OF_DELETE => TO_DATE('2013/05/20', 'yyyy/mm/dd'),
                                  PIN_END_DATE_OF_DELETE => TO_DATE('2012/05/20', 'yyyy/mm/dd'),
                                  PIN_IS_EFFECTIVE_PERIOD => 0,
                                  PIN_UPPER_START_PERIOD_COLUMN => NULL,
                                  PIN_UPPER_END_PERIOD_COLUMN => NULL,
                                  PIN_TIME_UNIT_ID => 214,
                                  PIN_NEW_PARENT_ENTITY_VALUE => 50,
                                  pin_relationship_tables => TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE('hierarchy1',100,100,'ENTITY_ID_UPPER','ENTITY_ID_LOWER'),
                                                                                            OBJTYPE_RELATIONSHIP_TABLE('hierarchy2',100,100,'ENTITY_ID_UPPER','ENTITY_ID_LOWER')),

                                  POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                                  POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                                  POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                                  POUT_SCN => POUT_SCN,
                                  POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION)

      END;
         */
   -----------------------------------------------------------------------------------------------

PROCEDURE DELETE_AND_MOVE_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

)

AS

V_UPD_DEL_TABLES CLOB;

V_SELECT VARCHAR2(32767);
TYPE number_table IS TABLE OF NUMBER;
v_updated_rows number_table;
V_DELETED_ROW NUMBER;

VAR_UPDATE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_DELETE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_INSERT TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

V_START_DATE VARCHAR2(32767);
V_END_DATE VARCHAR2(32767);

VAR_OLD_START_PERIOD VARCHAR2(100);
VAR_OLD_END_PERIOD VARCHAR2(100);

v_cursor sys_refcursor;

TYPE LOOP_RECORD_TYPE IS RECORD (
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE
);

TYPE INSERT_RECORD_TYPE IS RECORD(
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
ENTITY_ID_UPPER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE
);

TYPE V_LOOP_PERIODS_TYPE IS RECORD (
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE,
STARTPERIOD NUMBER,
ENDPERIOD NUMBER
);


TYPE V_LOOP_PERIODS_TABLE_TYPE IS TABLE OF V_LOOP_PERIODS_TYPE;

V_LOOP_PERIODS_TABLE V_LOOP_PERIODS_TABLE_TYPE := V_LOOP_PERIODS_TABLE_TYPE();

TYPE V_INSERT_RECORDS_TABLE_TYPE IS TABLE OF INSERT_RECORD_TYPE;

V_INSERT_RECORDS_TABLE V_INSERT_RECORDS_TABLE_TYPE := V_INSERT_RECORDS_TABLE_TYPE();

TYPE V_LOOP_TABLE_TYPE IS TABLE OF LOOP_RECORD_TYPE;

V_LOOP_TABLE V_LOOP_TABLE_TYPE := V_LOOP_TABLE_TYPE();

BEGIN

     IF (PIN_IS_EFFECTIVE_PERIOD IS NULL) THEN

-- if the procedure is not for dates or periods

      IF (pin_relationship_MOVE_tables.LAST = 1) THEN
-- if the procedure is for delete only

-- get the table to delete from
          V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;
-- get the scn
         POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- delete the row

                   EXECUTE IMMEDIATE 'DELETE FROM '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                                    ' WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO V_DELETED_ROW;

        VAR_DELETE.EXTEND;
        VAR_DELETE(1) := OBJTYPE_ID_NAME(V_DELETED_ROW, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

        -- enter the values for the output variable

        POUT_DELETED_ROWS := VAR_DELETE;

      ELSE

-- get the tables for the SCN

        V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME;

        FOR I IN pin_relationship_MOVE_tables.FIRST + 2 .. pin_relationship_MOVE_tables.LAST
        LOOP
            V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME;
        END LOOP;

-- set the value for the SCN

       POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);


        FOR I IN pin_relationship_MOVE_tables.FIRST +1 .. pin_relationship_MOVE_tables.LAST
        LOOP

        -- loop in all the tables and update when necesarry



                  EXECUTE IMMEDIATE 'UPDATE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
                                    ' SET '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
                                    ' = '
                                    || PIN_NEW_PARENT_ENTITY_VALUE ||
                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING BULK COLLECT INTO V_UPDATED_ROWS;

                  IF (V_UPDATED_ROWS.FIRST IS NOT NULL) THEN

                      FOR J IN V_UPDATED_ROWS.FIRST .. V_UPDATED_ROWS.LAST
                      LOOP
                        VAR_UPDATE.EXTEND;
                        VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(V_UPDATED_ROWS(J), PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME);
                      END LOOP;

                  END IF;


        END LOOP;

        --delete the given relationship

        EXECUTE IMMEDIATE 'DELETE FROM '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                                    ' WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO V_DELETED_ROW;

        VAR_DELETE.EXTEND;
        VAR_DELETE(1) := OBJTYPE_ID_NAME(V_DELETED_ROW, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

        -- enter the values for the output variables

        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;

        POUT_UPDATE_VALIDATION := COMMONS_TABLES.HIERARCHY_VALIDATIONS(

             pin_RelationshipTables => PIN_RELATIONSHIP_TABLES,
             pin_TimeUnit => NULL,
             pin_StartTimeUnitCol => NULL,
             pin_EndTimeUnitCol => NULL

        );

     END IF;



  ELSIF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN


-- for DATES

      IF (pin_relationship_MOVE_tables.LAST = 1) THEN
-- if the procedure is for delete only

-- get the table to delete from
          V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;
-- get the scn
         POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- delete the row

                  IF (PIN_START_DATE_OF_DELETE IS NULL) THEN
                    V_START_DATE := 'NULL';
                  ELSE
                    V_START_DATE := 'TO_DATE(''' || TO_CHAR(PIN_START_DATE_OF_DELETE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy''';
                  END IF;

                  IF (PIN_END_DATE_OF_DELETE IS NULL) THEN
                    V_END_DATE := 'NULL';
                  ELSE
                    V_END_DATE := 'TO_DATE(''' || TO_CHAR(PIN_END_DATE_OF_DELETE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy''';
                  END IF;

                          EXECUTE IMMEDIATE 'DELETE FROM '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                                    ' WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' AND NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = NVL('
                                    || V_START_DATE ||
                                    ', TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = NVL('
                                    || V_END_DATE ||
                                    ', TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) RETURNING ROW_IDENTIFIER INTO :1'
                          RETURNING INTO V_DELETED_ROW;

        VAR_DELETE.EXTEND;
        VAR_DELETE(1) := OBJTYPE_ID_NAME(V_DELETED_ROW, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

        -- enter the values for the output variable

        POUT_DELETED_ROWS := VAR_DELETE;

      ELSE


-- generating the select and tables list for the SCN and the tables list for the delete

       V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME;


       V_SELECT := 'SELECT ''' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AS "STARTDATE", NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) AS "ENDDATE" FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;


      -- iterate the rest of the selects

      FOR I IN pin_relationship_MOVE_tables.FIRST+2 .. pin_relationship_MOVE_tables.LAST
        LOOP

          V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME;

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ', NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')), NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;

        END LOOP;

-- set the value for the SCN

        POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- delete the first row

                  IF (PIN_START_DATE_OF_DELETE IS NULL) THEN
                    V_START_DATE := 'NULL';
                  ELSE
                    V_START_DATE := 'TO_DATE(''' || TO_CHAR(PIN_START_DATE_OF_DELETE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                  END IF;

                  IF (PIN_END_DATE_OF_DELETE IS NULL) THEN
                    V_END_DATE := 'NULL';
                  ELSE
                    V_END_DATE := 'TO_DATE(''' || TO_CHAR(PIN_END_DATE_OF_DELETE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                  END IF;

                          EXECUTE IMMEDIATE 'DELETE FROM '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                                    ' WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' AND NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = NVL('
                                    || V_START_DATE ||
                                    ', TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = NVL('
                                    || V_END_DATE ||
                                    ', TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) RETURNING ROW_IDENTIFIER INTO :1'
                          RETURNING INTO V_DELETED_ROW;

        VAR_DELETE.EXTEND;
        VAR_DELETE(1) := OBJTYPE_ID_NAME(V_DELETED_ROW, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

-- fetch the records


        open v_cursor for V_SELECT;

        FETCH V_CURSOR
        BULK COLLECT INTO V_LOOP_TABLE;

		close v_cursor;

        FOR I IN V_LOOP_TABLE.FIRST .. V_LOOP_TABLE.LAST
        LOOP

          IF ((NVL(PIN_START_DATE_OF_DELETE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_TABLE(I).STARTDATE) THEN
                  IF ((NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_TABLE(I).ENDDATE) THEN

-- if the record is between start date and end date of the parent
-- update the record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_NEW_PARENT_ENTITY_VALUE ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'')  AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                              ELSE

                                IF ((NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_TABLE(I).startdate) THEN

-- if the record and parent dates intersect at the end
-- update the existing record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_TABLE(I).TABLE_NAME ||
                                                    ' SET START_DATE = '''
                                                    || (PIN_END_DATE_OF_DELETE + 1) ||
                                                    ''', ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the record which needs to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_NEW_PARENT_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_END_DATE_OF_DELETE;


                                END IF;

                          END IF;

                                ELSIF ((NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) < V_LOOP_TABLE(I).enddate) THEN

-- if the parent dates are between the record dates
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_TABLE(I).TABLE_NAME ||
                                                    ' SET START_DATE = '''
                                                    || (PIN_END_DATE_OF_DELETE + 1) ||
                                                    ''', ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the records which need to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_UPPER_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_START_DATE_OF_DELETE - 1;

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_NEW_PARENT_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_START_DATE_OF_DELETE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_END_DATE_OF_DELETE;



                                  ELSIF ((NVL(PIN_START_DATE_OF_DELETE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_TABLE(I).enddate) THEN

-- if the record and parent dates intersect at the start
                                    -- update the existing record
                                    VAR_UPDATE.EXTEND;
                                    VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                    EXECUTE IMMEDIATE 'UPDATE '
                                                      || V_LOOP_TABLE(I).TABLE_NAME ||
                                                      ' SET END_DATE = '''
                                                      || (PIN_START_DATE_OF_DELETE - 1) ||
                                                      ''', ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                      || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                      ''', ''mm/dd/yyyy'') AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                      || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                      ''', ''mm/dd/yyyy'') AND '
                                                      || V_LOOP_TABLE(I).COL_UPPER ||
                                                      ' = '
                                                      || PIN_UPPER_ENTITY_VALUE ||
                                                      ' AND '
                                                      || V_LOOP_TABLE(I).COL_LOWER ||
                                                      ' = '
                                                      || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                      ' RETURNING ROW_IDENTIFIER INTO :1'
                                     RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                     -- add into a nested table the record which needs to be inserted later

                                     V_INSERT_RECORDS_TABLE.EXTEND;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_NEW_PARENT_ENTITY_VALUE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_START_DATE_OF_DELETE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := V_LOOP_TABLE(I).ENDDATE;



                            end if;


        END LOOP;

        IF (V_INSERT_RECORDS_TABLE.FIRST IS NOT NULL) THEN
-- loop the nested table and insert the records in the table

            FOR I IN V_INSERT_RECORDS_TABLE.FIRST .. V_INSERT_RECORDS_TABLE.LAST
            LOOP
                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, V_INSERT_RECORDS_TABLE(I).TABLE_NAME);


                  IF (V_INSERT_RECORDS_TABLE(I).STARTDATE = TO_DATE('01/01/1900', 'mm/dd/yyyy')) THEN
                    V_START_DATE := 'NULL';
                  ELSE
                    V_START_DATE := 'TO_DATE(''' || TO_CHAR(V_INSERT_RECORDS_TABLE(I).STARTDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                  END IF;

                  IF (V_INSERT_RECORDS_TABLE(I).ENDDATE = TO_DATE('12/31/9999', 'mm/dd/yyyy')) THEN
                    V_END_DATE := 'NULL';
                  ELSE
                    V_END_DATE := 'TO_DATE(''' || TO_CHAR(V_INSERT_RECORDS_TABLE(I).ENDDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                  END IF;

                  EXECUTE IMMEDIATE 'INSERT INTO ' || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '( '
                                    || V_INSERT_RECORDS_TABLE(I).COL_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).COL_UPPER ||
                                    ', START_DATE, END_DATE, ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_UPPER ||
                                    ', '
                                    || V_START_DATE ||
                                    ', '
                                    || V_END_DATE ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

            END LOOP;

-- insert the values into the output variables

        END IF;

        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;
        POUT_INSERTED_ROWS := VAR_INSERT;


        POUT_UPDATE_VALIDATION := COMMONS_TABLES.HIERARCHY_VALIDATIONS(

             pin_RelationshipTables => PIN_RELATIONSHIP_TABLES,
             pin_TimeUnit => PIN_IS_EFFECTIVE_PERIOD,
             pin_StartTimeUnitCol => 'START_DATE',
             pin_EndTimeUnitCol => 'END_DATE'

        );


     END IF;

  ELSE

--for periods






     IF (pin_relationship_MOVE_tables.LAST = 1) THEN
-- if the procedure is for delete only

-- get the table to delete from
         V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;
-- get the scn
         POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- delete the row

              IF (PIN_START_DATE_OF_DELETE IS NULL) THEN
                  VAR_OLD_START_PERIOD := ' IS NULL';
              ELSE
                  VAR_OLD_START_PERIOD := ' = ' || RETURN_PERIOD(PIN_START_DATE_OF_DELETE, PIN_TIME_UNIT_ID);
              END IF;

              IF (PIN_END_DATE_OF_DELETE IS NULL) THEN
                  VAR_OLD_END_PERIOD := ' IS NULL';
              ELSE
                  VAR_OLD_END_PERIOD := ' = ' || RETURN_PERIOD(PIN_END_DATE_OF_DELETE, PIN_TIME_UNIT_ID);
              END IF;

                          EXECUTE IMMEDIATE 'DELETE FROM '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                                    ' WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' AND '
                                    || PIN_UPPER_START_PERIOD_COLUMN
                                    || VAR_OLD_START_PERIOD ||
                                    ' AND '
                                    || PIN_UPPER_END_PERIOD_COLUMN
                                    || VAR_OLD_END_PERIOD ||
                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                          RETURNING INTO V_DELETED_ROW;

        VAR_DELETE.EXTEND;
        VAR_DELETE(1) := OBJTYPE_ID_NAME(V_DELETED_ROW, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

        -- enter the values for the output variable

        POUT_DELETED_ROWS := VAR_DELETE;

      ELSE


-- generating the select and tables list for the SCN and the tables list for the delete

       V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME;


       V_SELECT := 'SELECT ''' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ' AS "ENTITY_ID_UPPER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).ENTITY_UPPER ||
            ' AS "ENTITY_TYPE_UPPER", '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;


      -- iterate the rest of the selects

      FOR I IN PIN_RELATIONSHIP_MOVE_TABLES.FIRST+2 .. PIN_RELATIONSHIP_MOVE_TABLES.LAST
        LOOP

          V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME;

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).ENTITY_UPPER ||
            ', '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;

        END LOOP;

        -- outer join with the time units table
        V_SELECT := 'SELECT TABLE_NAME, COL_LOWER, COL_UPPER, ENTITY_ID_LOWER, NVL(TP.TUPR_START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AS "STARTDATE", NVL(TP2.TUPR_END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) AS "ENDDATE", '
                    || PIN_UPPER_START_PERIOD_COLUMN ||
                    ', '
                    || PIN_UPPER_END_PERIOD_COLUMN ||
                    ' FROM ('
                    || V_SELECT ||
                    ') LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                    || PIN_UPPER_START_PERIOD_COLUMN ||
                    ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                    || PIN_UPPER_END_PERIOD_COLUMN;


-- set the value for the SCN

    POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- delete the first row

              IF (PIN_START_DATE_OF_DELETE IS NULL) THEN
                  VAR_OLD_START_PERIOD := ' IS NULL';
              ELSE
                  VAR_OLD_START_PERIOD := ' = ' || RETURN_PERIOD(PIN_START_DATE_OF_DELETE, PIN_TIME_UNIT_ID);
              END IF;

              IF (PIN_END_DATE_OF_DELETE IS NULL) THEN
                  VAR_OLD_END_PERIOD := ' IS NULL';
              ELSE
                  VAR_OLD_END_PERIOD := ' = ' || RETURN_PERIOD(PIN_END_DATE_OF_DELETE, PIN_TIME_UNIT_ID);
              END IF;

                          EXECUTE IMMEDIATE 'DELETE FROM '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                                    ' WHERE '
                                    || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                                    ' = '
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ' AND '
                                    || PIN_UPPER_START_PERIOD_COLUMN
                                    || VAR_OLD_START_PERIOD ||
                                    ' AND '
                                    || PIN_UPPER_END_PERIOD_COLUMN
                                    || VAR_OLD_END_PERIOD ||
                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                          RETURNING INTO V_DELETED_ROW;

        VAR_DELETE.EXTEND;
        VAR_DELETE(1) := OBJTYPE_ID_NAME(V_DELETED_ROW, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

-- fetch the records


        open v_cursor for V_SELECT;

        FETCH V_CURSOR
        BULK COLLECT INTO V_LOOP_PERIODS_TABLE;

		close v_cursor;

        FOR I IN V_LOOP_PERIODS_TABLE.FIRST .. V_LOOP_PERIODS_TABLE.LAST
        LOOP

          IF ((NVL(PIN_START_DATE_OF_DELETE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_PERIODS_TABLE(I).STARTDATE) THEN
                  IF ((NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_PERIODS_TABLE(I).ENDDATE) THEN

-- if the record is between start date and end date of the parent
-- update the record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                  IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                      VAR_OLD_START_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                  END IF;

                                  IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                      VAR_OLD_END_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                  END IF;

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_NEW_PARENT_ENTITY_VALUE ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                    || PIN_UPPER_START_PERIOD_COLUMN
                                                    || VAR_OLD_START_PERIOD ||
                                                    ' AND '
                                                    || PIN_UPPER_END_PERIOD_COLUMN
                                                    || VAR_OLD_END_PERIOD ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                              ELSE

                                IF ((NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_PERIODS_TABLE(I).startdate) THEN

-- if the record and parent dates intersect at the end
-- update the existing record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                  IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                      VAR_OLD_START_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                  END IF;

                                  IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                      VAR_OLD_END_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                  END IF;

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                                    ' = '
                                                    || RETURN_PERIOD((PIN_END_DATE_OF_DELETE + 1), PIN_TIME_UNIT_ID) ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                    || PIN_UPPER_START_PERIOD_COLUMN
                                                    || VAR_OLD_START_PERIOD ||
                                                    ' AND '
                                                    || PIN_UPPER_END_PERIOD_COLUMN
                                                    || VAR_OLD_END_PERIOD ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the record which needs to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_NEW_PARENT_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_PERIODS_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_END_DATE_OF_DELETE;


                                END IF;

                          END IF;

                                ELSIF ((NVL(PIN_END_DATE_OF_DELETE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) < V_LOOP_PERIODS_TABLE(I).enddate) THEN

-- if the parent dates are between the record dates
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                  IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                      VAR_OLD_START_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                  END IF;

                                  IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                      VAR_OLD_END_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                  END IF;

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                                    ' = '
                                                    || RETURN_PERIOD((PIN_END_DATE_OF_DELETE + 1), PIN_TIME_UNIT_ID) ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                    || PIN_UPPER_START_PERIOD_COLUMN
                                                    || VAR_OLD_START_PERIOD ||
                                                    ' AND '
                                                    || PIN_UPPER_END_PERIOD_COLUMN
                                                    || VAR_OLD_END_PERIOD ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the records which need to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_UPPER_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_PERIODS_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_START_DATE_OF_DELETE - 1;

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_NEW_PARENT_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_START_DATE_OF_DELETE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_END_DATE_OF_DELETE;



                                  ELSIF ((NVL(PIN_START_DATE_OF_DELETE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_PERIODS_TABLE(I).enddate) THEN

-- if the record and parent dates intersect at the start
                                    -- update the existing record
                                    VAR_UPDATE.EXTEND;
                                    VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                    IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                        VAR_OLD_START_PERIOD := ' IS NULL';
                                    ELSE
                                        VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                    END IF;

                                    IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                        VAR_OLD_END_PERIOD := ' IS NULL';
                                    ELSE
                                        VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                    END IF;

                                    EXECUTE IMMEDIATE 'UPDATE '
                                                      || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                      ' SET '
                                                      || PIN_UPPER_END_PERIOD_COLUMN ||
                                                      ' = '
                                                      || RETURN_PERIOD((PIN_START_DATE_OF_DELETE - 1), PIN_TIME_UNIT_ID) ||
                                                      ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                      || PIN_UPPER_START_PERIOD_COLUMN
                                                      || VAR_OLD_START_PERIOD ||
                                                      ' AND '
                                                      || PIN_UPPER_END_PERIOD_COLUMN
                                                      || VAR_OLD_END_PERIOD ||
                                                      ' AND '
                                                      || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                      ' = '
                                                      || PIN_UPPER_ENTITY_VALUE ||
                                                      ' AND '
                                                      || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                      ' = '
                                                      || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                      ' RETURNING ROW_IDENTIFIER INTO :1'
                                     RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                     -- add into a nested table the record which needs to be inserted later

                                     V_INSERT_RECORDS_TABLE.EXTEND;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_NEW_PARENT_ENTITY_VALUE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_START_DATE_OF_DELETE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := V_LOOP_PERIODS_TABLE(I).ENDDATE;



                            end if;


        END LOOP;

        IF (V_INSERT_RECORDS_TABLE.FIRST IS NOT NULL) THEN
-- loop the nested table and insert the records in the table

            FOR I IN V_INSERT_RECORDS_TABLE.FIRST .. V_INSERT_RECORDS_TABLE.LAST
            LOOP
                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, V_INSERT_RECORDS_TABLE(I).TABLE_NAME);

                  EXECUTE IMMEDIATE 'INSERT INTO ' || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '( '
                                    || V_INSERT_RECORDS_TABLE(I).COL_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).COL_UPPER ||
                                    ', '
                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                    ', '
                                    || PIN_UPPER_END_PERIOD_COLUMN ||
                                    ', ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_UPPER ||
                                    ', '
                                    || RETURN_PERIOD(V_INSERT_RECORDS_TABLE(I).STARTDATE, PIN_TIME_UNIT_ID) ||
                                    ', '
                                    || RETURN_PERIOD(V_INSERT_RECORDS_TABLE(I).ENDDATE, PIN_TIME_UNIT_ID) ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

            END LOOP;

        END IF;
-- insert the values into the output variables


        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;
        POUT_INSERTED_ROWS := VAR_INSERT;

        POUT_UPDATE_VALIDATION := COMMONS_TABLES.HIERARCHY_VALIDATIONS(

             pin_RelationshipTables => PIN_RELATIONSHIP_TABLES,
             pin_TimeUnit => PIN_IS_EFFECTIVE_PERIOD,
             pin_StartTimeUnitCol => PIN_UPPER_START_PERIOD_COLUMN,
             pin_EndTimeUnitCol => PIN_UPPER_END_PERIOD_COLUMN

        );

   END IF;


 END IF;

EXCEPTION

  WHEN DUP_VAL_ON_INDEX THEN
    POUT_UPDATE_VALIDATION := 2;

END DELETE_AND_MOVE_HIERARCHY;





PROCEDURE MOVE_HIERARCHY_NOT_EFFECTIVE(

PIN_UPPER_ENTITY_VALUE NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
PIN_SUBORDINATE_PARENT_VALUE NUMBER,
PIN_RELATIONSHIP_MOVE_TABLE OBJTYPE_RELATIONSHIP_TABLE,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

)

AS

V_UPD_DEL_TABLES CLOB;

VAR_UPDATE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_DELETE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_INSERT TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

TYPE number_table IS TABLE OF NUMBER;

v_updated_rows number_table;

BEGIN

-- get the tables for the SCN

        V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;

        FOR I IN pin_relationship_MOVE_tables.FIRST + 1 .. pin_relationship_MOVE_tables.LAST
        LOOP
            V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME;
        END LOOP;


        IF (PIN_RELATIONSHIP_MOVE_TABLE IS NOT NULL) THEN

-- add the table in which the entity will be moved
          V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME;


        END IF;

-- get the scn
      POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- delete the old relationship

       VAR_DELETE.EXTEND;
       VAR_DELETE(1) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

       EXECUTE IMMEDIATE 'DELETE FROM '
                         || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                         ' WHERE '
                         || PIN_RELATIONSHIP_MOVE_TABLES(1).VALUE_LOWER_COL ||
                         ' = '
                         || pin_upper_entity_value ||
                         ' RETURNING ROW_IDENTIFIER INTO :1'
       RETURNING INTO VAR_DELETE(1).ID;


       IF (PIN_SUBORDINATE_PARENT_VALUE IS NOT NULL) THEN

-- update the new parent for the children

          FOR I IN PIN_RELATIONSHIP_MOVE_TABLES.FIRST+1 .. PIN_RELATIONSHIP_MOVE_TABLES.LAST
            LOOP

              EXECUTE IMMEDIATE 'UPDATE '
                                || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
                                ' SET '
                                || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
                                ' = '
                                || PIN_SUBORDINATE_PARENT_VALUE ||
                                ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
                                ' = '
                                || pin_upper_entity_value ||
                                ' RETURNING ROW_IDENTIFIER INTO :1'
              RETURNING BULK COLLECT INTO V_UPDATED_ROWS;

              IF (V_UPDATED_ROWS.FIRST IS NOT NULL) THEN

                      FOR J IN V_UPDATED_ROWS.FIRST .. V_UPDATED_ROWS.LAST
                      LOOP
                        VAR_UPDATE.EXTEND;
                        VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(V_UPDATED_ROWS(J), PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME);
                      END LOOP;

              END IF;

            END LOOP;


       END IF;

       IF (PIN_RELATIONSHIP_MOVE_TABLE IS NOT NULL) THEN

-- insert the given node into a new table

                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME);

                  EXECUTE IMMEDIATE 'INSERT INTO ' || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME ||
                                    '( '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.VALUE_LOWER_COL ||
                                    ', '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.VALUE_UPPER_COL ||
                                    ', ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ', '
                                    || PIN_NEW_PARENT_ENTITY_VALUE ||
                                    ', '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

       END IF;


-- insert the values into the output variables


        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;
        POUT_INSERTED_ROWS := VAR_INSERT;

        POUT_UPDATE_VALIDATION := COMMONS_TABLES.HIERARCHY_VALIDATIONS(

             pin_RelationshipTables => PIN_RELATIONSHIP_TABLES,
             pin_TimeUnit => NULL,
             pin_StartTimeUnitCol => NULL,
             pin_EndTimeUnitCol => NULL

        );


END MOVE_HIERARCHY_NOT_EFFECTIVE;

PROCEDURE MOVE_HIERARCHY_DATE(

PIN_UPPER_ENTITY_VALUE NUMBER,
PIN_upper_entity_rowid NUMBER,
PIN_OLD_REL_START_DATE DATE,
PIN_OLD_REL_END_DATE DATE,
PIN_NEW_REL_START_DATE DATE,
PIN_NEW_REL_END_DATE DATE,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
PIN_OLD_RELATIONSHIP NUMBER,
PIN_SUBORDINATE_PARENT_VALUE NUMBER,
PIN_RELATIONSHIP_MOVE_TABLE OBJTYPE_RELATIONSHIP_TABLE,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

)

AS

V_UPD_DEL_TABLES CLOB;

V_SELECT VARCHAR2(32767);


VAR_UPDATE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_DELETE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_INSERT TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

V_START_DATE VARCHAR2(32767);
V_END_DATE VARCHAR2(32767);

v_cursor sys_refcursor;

TYPE LOOP_RECORD_TYPE IS RECORD (
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE
);

TYPE INSERT_RECORD_TYPE IS RECORD(
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
ENTITY_ID_UPPER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE
);

TYPE V_INSERT_RECORDS_TABLE_TYPE IS TABLE OF INSERT_RECORD_TYPE;

V_INSERT_RECORDS_TABLE V_INSERT_RECORDS_TABLE_TYPE := V_INSERT_RECORDS_TABLE_TYPE();

TYPE V_LOOP_TABLE_TYPE IS TABLE OF LOOP_RECORD_TYPE;

V_LOOP_TABLE V_LOOP_TABLE_TYPE := V_LOOP_TABLE_TYPE();


BEGIN

      IF (pin_relationship_MOVE_tables.LAST = 1) THEN
-- if the procedure is for move only

-- get the table to move from
          V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;
-- get the scn
          POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);


      ELSE

        -- get the tables for the SCN

        V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;


        IF (PIN_SUBORDINATE_PARENT_VALUE IS NOT NULL) THEN
-- add the table in which the entity will be moved

            -- generating the select and tables list for the SCN and the tables list for the delete

       V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME;


       V_SELECT := 'SELECT ''' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AS "STARTDATE", NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) AS "ENDDATE" FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;


      -- iterate the rest of the selects

      FOR I IN pin_relationship_MOVE_tables.FIRST+2 .. pin_relationship_MOVE_tables.LAST
        LOOP

          V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME;

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ', NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')), NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;

        END LOOP;

-- set the value for the SCN

    POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- fetch the records

        open v_cursor for V_SELECT;

        FETCH V_CURSOR
        BULK COLLECT INTO V_LOOP_TABLE;

		close v_cursor;

        FOR I IN V_LOOP_TABLE.FIRST .. V_LOOP_TABLE.LAST
        LOOP

          IF ((NVL(PIN_NEW_REL_START_DATE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_TABLE(I).STARTDATE) THEN
                  IF ((NVL(PIN_NEW_REL_END_DATE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_TABLE(I).ENDDATE) THEN

-- if the record is between start date and end date of the parent
-- update the record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_SUBORDINATE_PARENT_VALUE ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'')  AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                              ELSE

                                IF (PIN_NEW_REL_END_DATE >= V_LOOP_TABLE(I).startdate) THEN

-- if the record and parent dates intersect at the end
-- update the existing record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_TABLE(I).TABLE_NAME ||
                                                    ' SET START_DATE = TO_DATE('''
                                                    || TO_CHAR((PIN_NEW_REL_END_DATE + 1), 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy''), ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the record which needs to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_SUBORDINATE_PARENT_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_NEW_REL_END_DATE;


                                END IF;

                          END IF;

                                ELSIF ((NVL(PIN_NEW_REL_END_DATE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) < V_LOOP_TABLE(I).enddate) THEN

-- if the parent dates are between the record dates
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_TABLE(I).TABLE_NAME ||
                                                    ' SET START_DATE = TO_DATE('''
                                                    || TO_CHAR((PIN_NEW_REL_END_DATE + 1), 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy''), ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                    || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                    ''', ''mm/dd/yyyy'') AND '
                                                    || V_LOOP_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the records which need to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_UPPER_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_NEW_REL_START_DATE - 1;

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_SUBORDINATE_PARENT_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_NEW_REL_START_DATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_NEW_REL_END_DATE;



                                  ELSIF ((NVL(PIN_NEW_REL_START_DATE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_TABLE(I).enddate) THEN

-- if the record and parent dates intersect at the start
                                    -- update the existing record
                                    VAR_UPDATE.EXTEND;
                                    VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_TABLE(I).TABLE_NAME);

                                    EXECUTE IMMEDIATE 'UPDATE '
                                                      || V_LOOP_TABLE(I).TABLE_NAME ||
                                                      ' SET END_DATE = TO_DATE('''
                                                      || TO_CHAR((PIN_NEW_REL_START_DATE - 1), 'mm/dd/yyyy') ||
                                                      ''', ''mm/dd/yyyy''), ROW_VERSION = ROW_VERSION + 1 WHERE NVL(START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                      || TO_CHAR(V_LOOP_TABLE(I).STARTDATE, 'mm/dd/yyyy') ||
                                                      ''', ''mm/dd/yyyy'') AND NVL(END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) = TO_DATE('''
                                                      || TO_CHAR(V_LOOP_TABLE(I).ENDDATE, 'mm/dd/yyyy') ||
                                                      ''', ''mm/dd/yyyy'') AND '
                                                      || V_LOOP_TABLE(I).COL_UPPER ||
                                                      ' = '
                                                      || PIN_UPPER_ENTITY_VALUE ||
                                                      ' AND '
                                                      || V_LOOP_TABLE(I).COL_LOWER ||
                                                      ' = '
                                                      || V_LOOP_TABLE(I).ENTITY_ID_LOWER ||
                                                      ' RETURNING ROW_IDENTIFIER INTO :1'
                                     RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                     -- add into a nested table the record which needs to be inserted later

                                     V_INSERT_RECORDS_TABLE.EXTEND;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_TABLE(I).TABLE_NAME;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_TABLE(I).COL_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_TABLE(I).COL_UPPER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_TABLE(I).ENTITY_ID_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_SUBORDINATE_PARENT_VALUE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_NEW_REL_START_DATE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := V_LOOP_TABLE(I).ENDDATE;



                            end if;


        END LOOP;




        ELSE
-- get the scn
                 POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);




       END IF;






      END IF;

       IF (PIN_OLD_RELATIONSHIP = 2) THEN
-- delete the old relationship

       VAR_DELETE.EXTEND;
       VAR_DELETE(1) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

           EXECUTE IMMEDIATE 'DELETE FROM '
                             || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                             ' WHERE ROW_IDENTIFIER = '
                             || PIN_upper_entity_rowid ||
                             ' RETURNING ROW_IDENTIFIER INTO :1'
           RETURNING INTO VAR_DELETE(1).ID;

       ELSIF (PIN_OLD_RELATIONSHIP = 3) THEN
-- update the start date and end date for the old relationship

           IF (PIN_OLD_REL_START_DATE IS NULL) THEN
             V_START_DATE := 'NULL';
           ELSE
             V_START_DATE := 'TO_DATE(''' || TO_CHAR(PIN_OLD_REL_START_DATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
           END IF;

           IF (PIN_OLD_REL_END_DATE IS NULL) THEN
             V_END_DATE := 'NULL';
           ELSE
             V_END_DATE := 'TO_DATE(''' || TO_CHAR(PIN_OLD_REL_END_DATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
           END IF;

           VAR_UPDATE.EXTEND;
           VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

           EXECUTE IMMEDIATE 'UPDATE '
                             || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                             ' SET START_DATE = '
                             || V_START_DATE ||
                             ', END_DATE = '
                             || V_END_DATE ||
                             ', ROW_VERSION = ROW_VERSION + 1 WHERE ROW_IDENTIFIER = '
                             || PIN_upper_entity_rowid ||
                             ' RETURNING ROW_IDENTIFIER INTO :1'
           RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

       END IF;



        IF (V_INSERT_RECORDS_TABLE.FIRST IS NOT NULL) THEN
-- loop the nested table and insert the records in the table

            FOR I IN V_INSERT_RECORDS_TABLE.FIRST .. V_INSERT_RECORDS_TABLE.LAST
            LOOP
                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, V_INSERT_RECORDS_TABLE(I).TABLE_NAME);


                  IF (V_INSERT_RECORDS_TABLE(I).STARTDATE = TO_DATE('01/01/1900', 'mm/dd/yyyy')) THEN
                    V_START_DATE := 'NULL';
                  ELSE
                    V_START_DATE := 'TO_DATE(''' || TO_CHAR(V_INSERT_RECORDS_TABLE(I).STARTDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                  END IF;

                  IF (V_INSERT_RECORDS_TABLE(I).ENDDATE = TO_DATE('12/31/9999', 'mm/dd/yyyy')) THEN
                    V_END_DATE := 'NULL';
                  ELSE
                    V_END_DATE := 'TO_DATE(''' || TO_CHAR(V_INSERT_RECORDS_TABLE(I).ENDDATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                  END IF;

                  EXECUTE IMMEDIATE 'INSERT INTO ' || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '( '
                                    || V_INSERT_RECORDS_TABLE(I).COL_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).COL_UPPER ||
                                    ', START_DATE, END_DATE, ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_UPPER ||
                                    ', '
                                    || V_START_DATE ||
                                    ', '
                                    || V_END_DATE ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

            END LOOP;

         END IF;



       IF (PIN_RELATIONSHIP_MOVE_TABLE IS NOT NULL) THEN

-- insert the given node into a new table
                 IF (PIN_NEW_REL_START_DATE IS NULL) THEN
                   V_START_DATE := 'NULL';
                 ELSE
                    V_START_DATE := 'TO_DATE(''' || TO_CHAR(PIN_NEW_REL_START_DATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                 END IF;

                 IF (PIN_NEW_REL_END_DATE IS NULL) THEN
                   V_END_DATE := 'NULL';
                 ELSE
                    V_END_DATE := 'TO_DATE(''' || TO_CHAR(PIN_NEW_REL_END_DATE, 'mm/dd/yyyy') || ''', ''mm/dd/yyyy'')';
                 END IF;


                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME);

                  EXECUTE IMMEDIATE 'INSERT INTO ' || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME ||
                                    '( '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.VALUE_LOWER_COL ||
                                    ', '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.VALUE_UPPER_COL ||
                                    ', START_DATE, END_DATE, ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ', '
                                    || PIN_NEW_PARENT_ENTITY_VALUE ||
                                    ', '
                                    || V_START_DATE ||
                                    ', '
                                    || V_END_DATE ||
                                    ', '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

       END IF;

        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;
        POUT_INSERTED_ROWS := VAR_INSERT;

        POUT_UPDATE_VALIDATION := COMMONS_TABLES.HIERARCHY_VALIDATIONS(

             pin_RelationshipTables => PIN_RELATIONSHIP_TABLES,
             pin_TimeUnit => 0,
             pin_StartTimeUnitCol => 'START_DATE',
             pin_EndTimeUnitCol => 'END_DATE'

        );

EXCEPTION

  WHEN DUP_VAL_ON_INDEX THEN
    POUT_UPDATE_VALIDATION := 2;

END MOVE_HIERARCHY_DATE;








PROCEDURE MOVE_HIERARCHY_PERIOD(

PIN_UPPER_ENTITY_VALUE NUMBER,
PIN_upper_entity_rowid NUMBER,
PIN_OLD_REL_START_DATE DATE,
PIN_OLD_REL_END_DATE DATE,
PIN_NEW_REL_START_DATE DATE,
PIN_NEW_REL_END_DATE DATE,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
PIN_OLD_RELATIONSHIP NUMBER,
PIN_SUBORDINATE_PARENT_VALUE NUMBER,
PIN_RELATIONSHIP_MOVE_TABLE OBJTYPE_RELATIONSHIP_TABLE,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

)

AS

V_UPD_DEL_TABLES CLOB;

V_SELECT VARCHAR2(32767);

VAR_UPDATE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_DELETE TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

VAR_INSERT TABLETYPE_ID_NAME := TABLETYPE_ID_NAME();

V_START_PERIOD VARCHAR2(32767);
V_END_PERIOD VARCHAR2(32767);

VAR_OLD_START_PERIOD VARCHAR2(100);
VAR_OLD_END_PERIOD VARCHAR2(100);

v_cursor sys_refcursor;


TYPE INSERT_RECORD_TYPE IS RECORD(
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
ENTITY_ID_UPPER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE
);

TYPE V_LOOP_PERIODS_TYPE IS RECORD (
TABLE_NAME VARCHAR2(100),
COL_LOWER VARCHAR2(100),
COL_UPPER VARCHAR2(100),
ENTITY_ID_LOWER NUMERIC(10),
STARTDATE DATE,
ENDDATE DATE,
STARTPERIOD NUMBER,
ENDPERIOD NUMBER
);


TYPE V_LOOP_PERIODS_TABLE_TYPE IS TABLE OF V_LOOP_PERIODS_TYPE;

V_LOOP_PERIODS_TABLE V_LOOP_PERIODS_TABLE_TYPE := V_LOOP_PERIODS_TABLE_TYPE();

TYPE V_INSERT_RECORDS_TABLE_TYPE IS TABLE OF INSERT_RECORD_TYPE;

V_INSERT_RECORDS_TABLE V_INSERT_RECORDS_TABLE_TYPE := V_INSERT_RECORDS_TABLE_TYPE();


BEGIN


      IF (pin_relationship_MOVE_tables.LAST = 1) THEN
-- if the procedure is for move only

-- get the table to move from
          V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;
-- get the scn
          POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);


      ELSE

        -- get the tables for the SCN

        V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME;


        IF (PIN_SUBORDINATE_PARENT_VALUE IS NOT NULL) THEN

-- generating the select and tables list for the SCN and the tables list for the delete

       V_UPD_DEL_TABLES := PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME;


       V_SELECT := 'SELECT ''' || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ''' AS "TABLE_NAME", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ''' AS "COL_LOWER", '''
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ''' AS "COL_UPPER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_LOWER_COL ||
            ' AS "ENTITY_ID_LOWER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ' AS "ENTITY_ID_UPPER", '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).ENTITY_UPPER ||
            ' AS "ENTITY_TYPE_UPPER", '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(2).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;


      -- iterate the rest of the selects

      FOR I IN PIN_RELATIONSHIP_MOVE_TABLES.FIRST+2 .. PIN_RELATIONSHIP_MOVE_TABLES.LAST
        LOOP

          V_UPD_DEL_TABLES := V_UPD_DEL_TABLES || ', ' || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME;

          V_SELECT := V_SELECT ||
            ' UNION SELECT '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ''', '''
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ''', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_LOWER_COL ||
            ', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ', '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).ENTITY_UPPER ||
            ', '
            || PIN_UPPER_START_PERIOD_COLUMN ||
            ', '
            || PIN_UPPER_END_PERIOD_COLUMN ||
            ' FROM '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).TABLE_NAME ||
            ' WHERE '
            || PIN_RELATIONSHIP_MOVE_TABLES(I).VALUE_UPPER_COL ||
            ' = '
            || PIN_UPPER_ENTITY_VALUE;

        END LOOP;

        -- outer join with the time units table
        V_SELECT := 'SELECT TABLE_NAME, COL_LOWER, COL_UPPER, ENTITY_ID_LOWER, NVL(TP.TUPR_START_DATE, TO_DATE(''01/01/1900'', ''mm/dd/yyyy'')) AS "STARTDATE", NVL(TP2.TUPR_END_DATE, TO_DATE(''12/31/9999'', ''mm/dd/yyyy'')) AS "ENDDATE", '
                    || PIN_UPPER_START_PERIOD_COLUMN ||
                    ', '
                    || PIN_UPPER_END_PERIOD_COLUMN ||
                    ' FROM ('
                    || V_SELECT ||
                    ') LEFT OUTER JOIN TU_PERIODS_RANGE TP ON TP.TUPR_ID = '
                    || PIN_UPPER_START_PERIOD_COLUMN ||
                    ' LEFT OUTER JOIN TU_PERIODS_RANGE TP2 ON TP2.TUPR_ID = '
                    || PIN_UPPER_END_PERIOD_COLUMN;


-- set the value for the SCN

    POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

-- fetch the records

        open v_cursor for V_SELECT;

        FETCH V_CURSOR
        BULK COLLECT INTO V_LOOP_PERIODS_TABLE;

		close v_cursor;

        FOR I IN V_LOOP_PERIODS_TABLE.FIRST .. V_LOOP_PERIODS_TABLE.LAST
        LOOP

          IF ((NVL(PIN_NEW_REL_START_DATE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_PERIODS_TABLE(I).STARTDATE) THEN
                IF ((NVL(PIN_NEW_REL_END_DATE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_PERIODS_TABLE(I).ENDDATE) THEN

-- if the record is between start date and end date of the parent
-- update the record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                  IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                      VAR_OLD_START_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                  END IF;

                                  IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                      VAR_OLD_END_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                  END IF;

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_SUBORDINATE_PARENT_VALUE ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                    || PIN_UPPER_START_PERIOD_COLUMN
                                                    || VAR_OLD_START_PERIOD ||
                                                    ' AND '
                                                    || PIN_UPPER_END_PERIOD_COLUMN
                                                    || VAR_OLD_END_PERIOD ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                              ELSE

                                IF ((NVL(PIN_NEW_REL_END_DATE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) >= V_LOOP_PERIODS_TABLE(I).startdate) THEN

-- if the record and parent dates intersect at the end
-- update the existing record
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                  IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                      VAR_OLD_START_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                  END IF;

                                  IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                      VAR_OLD_END_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                  END IF;

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                                    ' = '
                                                    || RETURN_PERIOD((PIN_NEW_REL_END_DATE + 1), PIN_TIME_UNIT_ID) ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                    || PIN_UPPER_START_PERIOD_COLUMN
                                                    || VAR_OLD_START_PERIOD ||
                                                    ' AND '
                                                    || PIN_UPPER_END_PERIOD_COLUMN
                                                    || VAR_OLD_END_PERIOD ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the record which needs to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_SUBORDINATE_PARENT_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_PERIODS_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_NEW_REL_END_DATE;


                                END IF;

                          END IF;

                                ELSIF ((NVL(PIN_NEW_REL_END_DATE, TO_DATE('12/31/9999', 'mm/dd/yyyy'))) < V_LOOP_PERIODS_TABLE(I).enddate) THEN

-- if the parent dates are between the record dates
                                  VAR_UPDATE.EXTEND;
                                  VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                  IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                      VAR_OLD_START_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                  END IF;

                                  IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                      VAR_OLD_END_PERIOD := ' IS NULL';
                                  ELSE
                                      VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                  END IF;

                                  EXECUTE IMMEDIATE 'UPDATE '
                                                    || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                    ' SET '
                                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                                    ' = '
                                                    || RETURN_PERIOD((PIN_NEW_REL_END_DATE + 1), PIN_TIME_UNIT_ID) ||
                                                    ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                    || PIN_UPPER_START_PERIOD_COLUMN
                                                    || VAR_OLD_START_PERIOD ||
                                                    ' AND '
                                                    || PIN_UPPER_END_PERIOD_COLUMN
                                                    || VAR_OLD_END_PERIOD ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                    ' = '
                                                    || PIN_UPPER_ENTITY_VALUE ||
                                                    ' AND '
                                                    || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                    ' = '
                                                    || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                    ' RETURNING ROW_IDENTIFIER INTO :1'
                                   RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                   -- add into a nested table the records which need to be inserted later

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_UPPER_ENTITY_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := V_LOOP_PERIODS_TABLE(I).STARTDATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_NEW_REL_START_DATE - 1;

                                   V_INSERT_RECORDS_TABLE.EXTEND;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_SUBORDINATE_PARENT_VALUE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_NEW_REL_START_DATE;
                                   V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := PIN_NEW_REL_END_DATE;



                                  ELSIF ((NVL(PIN_NEW_REL_START_DATE, TO_DATE('01/01/1900', 'mm/dd/yyyy'))) <= V_LOOP_PERIODS_TABLE(I).enddate) THEN

-- if the record and parent dates intersect at the start
                                    -- update the existing record
                                    VAR_UPDATE.EXTEND;
                                    VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, V_LOOP_PERIODS_TABLE(I).TABLE_NAME);

                                    IF (V_LOOP_PERIODS_TABLE(I).STARTPERIOD IS NULL) THEN
                                        VAR_OLD_START_PERIOD := ' IS NULL';
                                    ELSE
                                        VAR_OLD_START_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).STARTPERIOD;
                                    END IF;

                                    IF (V_LOOP_PERIODS_TABLE(I).ENDPERIOD IS NULL) THEN
                                        VAR_OLD_END_PERIOD := ' IS NULL';
                                    ELSE
                                        VAR_OLD_END_PERIOD := ' = ' || V_LOOP_PERIODS_TABLE(I).ENDPERIOD;
                                    END IF;

                                    EXECUTE IMMEDIATE 'UPDATE '
                                                      || V_LOOP_PERIODS_TABLE(I).TABLE_NAME ||
                                                      ' SET '
                                                      || PIN_UPPER_END_PERIOD_COLUMN ||
                                                      ' = '
                                                      || RETURN_PERIOD((PIN_NEW_REL_START_DATE - 1), PIN_TIME_UNIT_ID) ||
                                                      ', ROW_VERSION = ROW_VERSION + 1 WHERE '
                                                      || PIN_UPPER_START_PERIOD_COLUMN
                                                      || VAR_OLD_START_PERIOD ||
                                                      ' AND '
                                                      || PIN_UPPER_END_PERIOD_COLUMN
                                                      || VAR_OLD_END_PERIOD ||
                                                      ' AND '
                                                      || V_LOOP_PERIODS_TABLE(I).COL_UPPER ||
                                                      ' = '
                                                      || PIN_UPPER_ENTITY_VALUE ||
                                                      ' AND '
                                                      || V_LOOP_PERIODS_TABLE(I).COL_LOWER ||
                                                      ' = '
                                                      || V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER ||
                                                      ' RETURNING ROW_IDENTIFIER INTO :1'
                                     RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

                                     -- add into a nested table the record which needs to be inserted later

                                     V_INSERT_RECORDS_TABLE.EXTEND;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).TABLE_NAME := V_LOOP_PERIODS_TABLE(I).TABLE_NAME;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_LOWER := V_LOOP_PERIODS_TABLE(I).COL_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).COL_UPPER := V_LOOP_PERIODS_TABLE(I).COL_UPPER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_LOWER := V_LOOP_PERIODS_TABLE(I).ENTITY_ID_LOWER;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENTITY_ID_UPPER := PIN_SUBORDINATE_PARENT_VALUE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).STARTDATE := PIN_NEW_REL_START_DATE;
                                     V_INSERT_RECORDS_TABLE(V_INSERT_RECORDS_TABLE.LAST).ENDDATE := V_LOOP_PERIODS_TABLE(I).ENDDATE;



                            end if;


        END LOOP;


        ELSE
-- get the scn
                 POUT_SCN := COMMONS_APPFRAMEWORK.GET_VALID_SCN(PIN_TABLE_LIST => V_UPD_DEL_TABLES);

       END IF;


      END IF;

       IF (PIN_OLD_RELATIONSHIP = 2) THEN
-- delete the old relationship

       VAR_DELETE.EXTEND;
       VAR_DELETE(1) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

           EXECUTE IMMEDIATE 'DELETE FROM '
                             || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                             ' WHERE ROW_IDENTIFIER = '
                             || PIN_upper_entity_rowid ||
                             ' RETURNING ROW_IDENTIFIER INTO :1'
           RETURNING INTO VAR_DELETE(1).ID;

       ELSIF (PIN_OLD_RELATIONSHIP = 3) THEN
-- update the start date and end date for the old relationship

           IF (PIN_OLD_REL_START_DATE IS NULL) THEN
             V_START_PERIOD := 'NULL';
           ELSE
             V_START_PERIOD := '''' || TO_CHAR(RETURN_PERIOD(PIN_OLD_REL_START_DATE, PIN_TIME_UNIT_ID)) || '''';
           END IF;

           IF (PIN_OLD_REL_END_DATE IS NULL) THEN
             V_END_PERIOD := 'NULL';
           ELSE
             V_END_PERIOD := '''' || TO_CHAR(RETURN_PERIOD(PIN_OLD_REL_END_DATE, PIN_TIME_UNIT_ID)) || '''';
           END IF;

           VAR_UPDATE.EXTEND;
           VAR_UPDATE(VAR_UPDATE.LAST) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME);

           EXECUTE IMMEDIATE 'UPDATE '
                             || PIN_RELATIONSHIP_MOVE_TABLES(1).TABLE_NAME ||
                             ' SET '
                             || PIN_UPPER_START_PERIOD_COLUMN ||
                             ' = '
                             || V_START_PERIOD ||
                             ', '
                             || PIN_UPPER_END_PERIOD_COLUMN ||
                             ' = '
                             || V_END_PERIOD ||
                             ', ROW_VERSION = ROW_VERSION + 1  WHERE ROW_IDENTIFIER = '
                             || PIN_upper_entity_rowid ||
                             ' RETURNING ROW_IDENTIFIER INTO :1'
           RETURNING INTO VAR_UPDATE(VAR_UPDATE.LAST).ID;

       END IF;



        IF (V_INSERT_RECORDS_TABLE.FIRST IS NOT NULL) THEN
-- loop the nested table and insert the records in the table

            FOR I IN V_INSERT_RECORDS_TABLE.FIRST .. V_INSERT_RECORDS_TABLE.LAST
            LOOP
                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, V_INSERT_RECORDS_TABLE(I).TABLE_NAME);


                  IF (V_INSERT_RECORDS_TABLE(I).STARTDATE = TO_DATE('01/01/1900', 'mm/dd/yyyy')) THEN
                    V_START_PERIOD := 'NULL';
                  ELSE
                    V_START_PERIOD := '''' || TO_CHAR(RETURN_PERIOD(V_INSERT_RECORDS_TABLE(I).STARTDATE, PIN_TIME_UNIT_ID)) || '''';
                  END IF;

                  IF (V_INSERT_RECORDS_TABLE(I).ENDDATE = TO_DATE('12/31/9999', 'mm/dd/yyyy')) THEN
                    V_END_PERIOD := 'NULL';
                  ELSE
                    V_END_PERIOD := '''' || TO_CHAR(RETURN_PERIOD(V_INSERT_RECORDS_TABLE(I).ENDDATE, PIN_TIME_UNIT_ID)) || '''';
                  END IF;

                  EXECUTE IMMEDIATE 'INSERT INTO ' || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '( '
                                    || V_INSERT_RECORDS_TABLE(I).COL_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).COL_UPPER ||
                                    ', '
                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                    ', '
                                    || PIN_UPPER_END_PERIOD_COLUMN ||
                                    ', ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_LOWER ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).ENTITY_ID_UPPER ||
                                    ', '
                                    || V_START_PERIOD ||
                                    ', '
                                    || V_END_PERIOD ||
                                    ', '
                                    || V_INSERT_RECORDS_TABLE(I).TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

            END LOOP;

         END IF;



       IF (PIN_RELATIONSHIP_MOVE_TABLE IS NOT NULL) THEN

-- insert the given node into a new table
                 IF (PIN_NEW_REL_START_DATE IS NULL) THEN
                   V_START_PERIOD := 'NULL';
                 ELSE
                   V_START_PERIOD := '''' || TO_CHAR(RETURN_PERIOD(PIN_NEW_REL_START_DATE, PIN_TIME_UNIT_ID)) || '''';
                 END IF;

                 IF (PIN_NEW_REL_END_DATE IS NULL) THEN
                   V_END_PERIOD := 'NULL';
                 ELSE
                   V_END_PERIOD := '''' || TO_CHAR(RETURN_PERIOD(PIN_NEW_REL_END_DATE, PIN_TIME_UNIT_ID)) || '''';
                 END IF;


                  VAR_INSERT.EXTEND;
                  VAR_INSERT(VAR_INSERT.LAST) := OBJTYPE_ID_NAME(1, PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME);

                  EXECUTE IMMEDIATE 'INSERT INTO ' || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME ||
                                    '( '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.VALUE_LOWER_COL ||
                                    ', '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.VALUE_UPPER_COL ||
                                    ', '
                                    || PIN_UPPER_START_PERIOD_COLUMN ||
                                    ', '
                                    || PIN_UPPER_END_PERIOD_COLUMN ||
                                    ', ROW_IDENTIFIER, ROW_VERSION) VALUES ('
                                    || PIN_UPPER_ENTITY_VALUE ||
                                    ', '
                                    || PIN_NEW_PARENT_ENTITY_VALUE ||
                                    ', '
                                    || V_START_PERIOD ||
                                    ', '
                                    || V_END_PERIOD ||
                                    ', '
                                    || PIN_RELATIONSHIP_MOVE_TABLE.TABLE_NAME ||
                                    '_ROW_IDENTIFIER_SEQ.NEXTVAL, 0) RETURNING ROW_IDENTIFIER INTO :1'
                  RETURNING INTO VAR_INSERT(VAR_INSERT.LAST).ID;

       END IF;

        POUT_UPDATED_ROWS := VAR_UPDATE;
        POUT_DELETED_ROWS := VAR_DELETE;
        POUT_INSERTED_ROWS := VAR_INSERT;

        POUT_UPDATE_VALIDATION := COMMONS_TABLES.HIERARCHY_VALIDATIONS(

             pin_RelationshipTables => PIN_RELATIONSHIP_TABLES,
             pin_TimeUnit => 1,
             pin_StartTimeUnitCol => PIN_UPPER_START_PERIOD_COLUMN,
             pin_EndTimeUnitCol => PIN_UPPER_END_PERIOD_COLUMN

        );


EXCEPTION

  WHEN DUP_VAL_ON_INDEX THEN
    POUT_UPDATE_VALIDATION := 2;

END MOVE_HIERARCHY_PERIOD;

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  -- ############################# DELETE_HIERARCHY START #############################
  -- Author     :
  -- Create date:
  -- Reviewer :
  -- Review date:
  -- Description: Functions for Delete Hierarchy
   -----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Deletes from Portal Hierarchy
      -- Input Parameters:
      --    ->> INPUT
--pin_upper_entity_value (internal id)
--pin_upper_entity_id
--pin_start_date_of_delete (date, even if it is period)
--pin_end_date_of_delete
--pin_is_effective_period (1 for period, 0 for date, null for not effective dated)
--pin_current_date (date of the delete)
--pin_upper_start_period_column (for period, the columns' name from fields, ex 'start quarter')
--pin_upper_end_period_column
--pin_time_unit_id (for period, time unit to use)
--PIN_RELATIONSHIP_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES)
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name
--PIN_RELATIONSHIP_MOVE_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES) - only the tabels used at move
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name

--->> OUTPUT
--pout_inserted_rows (TYPE TABLETYPE_ID_NAME)
--                - row_id
--                - table name
--pout_updated_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_deleted_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_scn_inserted (number)
--pout_scn_upd_deleted (number)

   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      DECLARE
      POUT_INSERTED_ROWS TABLETYPE_ID_NAME;
      POUT_UPDATED_ROWS TABLETYPE_ID_NAME;
      POUT_DELETED_ROWS TABLETYPE_ID_NAME;
      POUT_SCN_INSERTED NUMBER;
      POUT_SCN_UPD_DELETED NUMBER;
      BEGIN
      DELETE_FROM_HIERARCHY.DELETE_HIERARCHY(PIN_UPPER_ENTITY_VALUE => 100,
                                  pin_upper_entity_id    => 2,
                                  PIN_START_DATE_OF_DELETE => TO_DATE('2013/05/20', 'yyyy/mm/dd'),
                                  PIN_END_DATE_OF_DELETE => TO_DATE('2012/05/20', 'yyyy/mm/dd'),
                                  PIN_IS_EFFECTIVE_PERIOD => 0,
                                  PIN_CURRENT_DATE => '02-May-2013',
                                  PIN_UPPER_START_PERIOD_COLUMN => NULL,
                                  PIN_UPPER_END_PERIOD_COLUMN => NULL,
                                  PIN_TIME_UNIT_ID => 214,
                                  pin_relationship_tables => TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE('hierarchy1',100,100,'ENTITY_ID_UPPER','ENTITY_ID_LOWER'),
                                                                                            OBJTYPE_RELATIONSHIP_TABLE('hierarchy2',100,100,'ENTITY_ID_UPPER','ENTITY_ID_LOWER')),
                                  PIN_TIME_UNIT_ID => 214,
                                  pin_relationship_move_tables => TABLETYPE_RELATIONSHIP_TABLES(OBJTYPE_RELATIONSHIP_TABLE('hierarchy1',100,100,'ENTITY_ID_UPPER','ENTITY_ID_LOWER'),
                                                                                            OBJTYPE_RELATIONSHIP_TABLE('hierarchy2',100,100,'ENTITY_ID_UPPER','ENTITY_ID_LOWER')),

                                  POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                                  POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                                  POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                                  POUT_SCN_INSERTED => POUT_SCN_INSERTED,
                                  POUT_SCN_UPD_DELETED => POUT_SCN_UPD_DELETED)

      END;
         */
   -----------------------------------------------------------------------------------------------
PROCEDURE DELETE_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
pin_upper_entity_id    NUMBER,
PIN_START_DATE_OF_DELETE DATE,
PIN_END_DATE_OF_DELETE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

)

AS

	v_stamp						VARCHAR2(250);

BEGIN

	v_stamp := 'HIERARCHY_OPTIONS.DELETE_HIERARCHY - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

	-- log the input parameters
	BEGIN
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_UPPER_ENTITY_VALUE),		',PIN_UPPER_ENTITY_VALUE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_upper_entity_id),		',PIN_upper_entity_id => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_START_DATE_OF_DELETE),	',PIN_START_DATE_OF_DELETE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_END_DATE_OF_DELETE),			',PIN_END_DATE_OF_DELETE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_IS_EFFECTIVE_PERIOD),		',PIN_IS_EFFECTIVE_PERIOD => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_UPPER_START_PERIOD_COLUMN),		',PIN_UPPER_START_PERIOD_COLUMN => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_UPPER_END_PERIOD_COLUMN),		',PIN_UPPER_END_PERIOD_COLUMN => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_TIME_UNIT_ID),		',PIN_TIME_UNIT_ID => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_NEW_PARENT_ENTITY_VALUE),		',PIN_NEW_PARENT_ENTITY_VALUE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_relationship_move_tables),	',pin_relationship_move_tables => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_relationship_tables),	',pin_relationship_tables => <value>', v_stamp);
	END;

  IF (PIN_NEW_PARENT_ENTITY_VALUE IS NULL) THEN

      DELETE_ONLY_HIERARCHY(PIN_UPPER_ENTITY_VALUE => PIN_UPPER_ENTITY_VALUE,
             PIN_UPPER_ENTITY_ID => PIN_UPPER_ENTITY_ID,
             PIN_START_DATE_OF_DELETE => PIN_START_DATE_OF_DELETE,
             PIN_END_DATE_OF_DELETE => PIN_END_DATE_OF_DELETE,
             PIN_IS_EFFECTIVE_PERIOD => PIN_IS_EFFECTIVE_PERIOD,
             PIN_TIME_UNIT_ID => PIN_TIME_UNIT_ID,
             PIN_UPPER_START_PERIOD_COLUMN => PIN_UPPER_START_PERIOD_COLUMN,
             PIN_UPPER_END_PERIOD_COLUMN => PIN_UPPER_END_PERIOD_COLUMN,
             PIN_RELATIONSHIP_TABLES => PIN_RELATIONSHIP_TABLES,
             POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
             POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
             POUT_DELETED_ROWS => POUT_DELETED_ROWS,
             POUT_SCN => POUT_SCN);

  ELSE

      DELETE_AND_MOVE_HIERARCHY(PIN_UPPER_ENTITY_VALUE => PIN_UPPER_ENTITY_VALUE,
             PIN_START_DATE_OF_DELETE => PIN_START_DATE_OF_DELETE,
             PIN_END_DATE_OF_DELETE => PIN_END_DATE_OF_DELETE,
             PIN_IS_EFFECTIVE_PERIOD => PIN_IS_EFFECTIVE_PERIOD,
             PIN_TIME_UNIT_ID => PIN_TIME_UNIT_ID,
             PIN_NEW_PARENT_ENTITY_VALUE => PIN_NEW_PARENT_ENTITY_VALUE,
             PIN_UPPER_START_PERIOD_COLUMN => PIN_UPPER_START_PERIOD_COLUMN,
             PIN_UPPER_END_PERIOD_COLUMN => PIN_UPPER_END_PERIOD_COLUMN,
             PIN_RELATIONSHIP_TABLES => PIN_RELATIONSHIP_TABLES,
             PIN_RELATIONSHIP_MOVE_TABLES => PIN_RELATIONSHIP_MOVE_TABLES,
             POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
             POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
             POUT_DELETED_ROWS => POUT_DELETED_ROWS,
             POUT_SCN => POUT_SCN,
       POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION);

  END IF;

	v_stamp := replace(v_stamp, 'input', 'output');
	-- log the output parameters
	BEGIN

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(POUT_INSERTED_ROWS),			',POUT_INSERTED_ROWS => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(POUT_UPDATED_ROWS),	',POUT_UPDATED_ROWS => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(POUT_DELETED_ROWS),	',POUT_DELETED_ROWS => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(POUT_SCN),		',POUT_SCN => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(POUT_UPDATE_VALIDATION),		',POUT_UPDATE_VALIDATION => <value>', v_stamp);
	END;


END DELETE_HIERARCHY;


  -- ############################# MOVE_HIERARCHY START #############################
  -- Author     :
  -- Create date:
  -- Reviewer :
  -- Review date:
  -- Description: Functions for Move Hierarchy
   -----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process:  Moves in Portal Hierarchy
      -- Input Parameters:
      --    ->> INPUT
-- PIN_upper_entity_rowid the row id of the record to be moved
-- PIN_OLD_REL_START_DATE the start date entered for the old relationship of the moved entity (date, even if it is period)
-- PIN_OLD_REL_END_DATE
-- PIN_NEW_REL_START_DATE the end date entered for the new relationship of the moved entity (date, even if it is period)
-- PIN_NEW_REL_END_DATE
-- PIN_OLD_RELATIONSHIP the action for the old relationship (1 for retain, 2 for delete, 3 for update)
-- PIN_NEW_PARENT_ENTITY_VALUE the new parent's internal id
-- PIN_SUBORDINATE_PARENT_VALUE the new parent's internal id (for the record's childs)
-- PIN_RELATIONSHIP_MOVE_TABLE the tabel for the new relationship
--pin_upper_entity_value (internal id)
--pin_start_date_of_delete (date, even if it is period)
--pin_end_date_of_delete
--pin_is_effective_period (1 for period, 0 for date, null for not effective dated)
--pin_current_date (date of the delete)
--pin_upper_start_period_column (for period, the columns' name from fields, ex 'start quarter')
--pin_upper_end_period_column
--pin_time_unit_id (for period, time unit to use)
--PIN_RELATIONSHIP_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES)
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name
--PIN_RELATIONSHIP_MOVE_TABLES (TYPE TABLETYPE_RELATIONSHIP_TABLES) - only the tabels used at move
--                - relationship table name
--                - upper entity id
--                - lower entity id
--                - upper column name
--                - lower column name

--->> OUTPUT
--pout_inserted_rows (TYPE TABLETYPE_ID_NAME)
--                - row_id
--                - table name
--pout_updated_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_deleted_rows (TYPE TABLETYPE_ID_NAME)
-- row_id
--                - table name
--pout_scn_inserted (number)
--pout_scn_upd_deleted (number)

   -----------------------------------------------------------------------------------------------
      --    Call statement:
      /*
      DECLARE
      POUT_INSERTED_ROWS TABLETYPE_ID_NAME;
      POUT_UPDATED_ROWS TABLETYPE_ID_NAME;
      POUT_DELETED_ROWS TABLETYPE_ID_NAME;
      POUT_SCN_INSERTED NUMBER;
      POUT_SCN_UPD_DELETED NUMBER;
      BEGIN
            MOVE_IN_HIERARCHY.MOVE_HIERARCHY(
                        PIN_upper_entity_rowid => NULL,
                        PIN_OLD_REL_START_DATE => NULL,
                        PIN_OLD_REL_END_DATE => NULL,
                        PIN_NEW_REL_START_DATE => NULL,
                        PIN_NEW_REL_END_DATE => NULL,
                        PIN_IS_EFFECTIVE_PERIOD => NULL,
                        PIN_UPPER_START_PERIOD_COLUMN => NULL,
                        PIN_UPPER_END_PERIOD_COLUMN => NULL,
                        PIN_TIME_UNIT_ID => NULL,
                        PIN_OLD_RELATIONSHIP => NULL,
                        PIN_UPPER_ENTITY_VALUE => 1,
                        PIN_NEW_PARENT_ENTITY_VALUE => 5,
                        PIN_SUBORDINATE_PARENT_VALUE => 6,
                        PIN_RELATIONSHIP_MOVE_TABLE => OBJTYPE_RELATIONSHIP_TABLE('T200002', 190647, 190647, 'E190711', 'E190713'),
                        pin_relationship_move_tables => TABLETYPE_RELATIONSHIP_TABLES(
                           OBJTYPE_RELATIONSHIP_TABLE('T200000', 190647, 190647, 'E190714', 'E190713'),
                           OBJTYPE_RELATIONSHIP_TABLE('T200001', 190647, 190647, 'E190713', 'E190712')),
                         pin_relationship_tables => TABLETYPE_RELATIONSHIP_TABLES(
                           OBJTYPE_RELATIONSHIP_TABLE('T200000', 190647, 190647, 'E190714', 'E190713'),
                           OBJTYPE_RELATIONSHIP_TABLE('T200002', 190647, 190647, 'E190711', 'E190713'),
                           OBJTYPE_RELATIONSHIP_TABLE('T200001', 190647, 190647, 'E190713', 'E190712')),

                        POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                        POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                        POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                        POUT_SCN => POUT_SCN,
                        POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION);

      END;
         */
   -----------------------------------------------------------------------------------------------


PROCEDURE MOVE_HIERARCHY(

PIN_UPPER_ENTITY_VALUE NUMBER,
PIN_upper_entity_rowid NUMBER,
PIN_OLD_REL_START_DATE DATE,
PIN_OLD_REL_END_DATE DATE,
PIN_NEW_REL_START_DATE DATE,
PIN_NEW_REL_END_DATE DATE,
PIN_IS_EFFECTIVE_PERIOD NUMBER,
PIN_UPPER_START_PERIOD_COLUMN VARCHAR2,
PIN_UPPER_END_PERIOD_COLUMN VARCHAR2,
PIN_TIME_UNIT_ID NUMBER,
PIN_NEW_PARENT_ENTITY_VALUE NUMBER,
PIN_OLD_RELATIONSHIP NUMBER,
PIN_SUBORDINATE_PARENT_VALUE NUMBER,
PIN_RELATIONSHIP_MOVE_TABLE OBJTYPE_RELATIONSHIP_TABLE,
pin_relationship_move_tables TABLETYPE_RELATIONSHIP_TABLES,
pin_relationship_tables TABLETYPE_RELATIONSHIP_TABLES,

POUT_INSERTED_ROWS OUT TABLETYPE_ID_NAME,
POUT_UPDATED_ROWS OUT TABLETYPE_ID_NAME,
POUT_DELETED_ROWS OUT TABLETYPE_ID_NAME,
POUT_SCN OUT NUMBER,
POUT_UPDATE_VALIDATION OUT NUMBER

)

AS

	v_stamp						VARCHAR2(250);

BEGIN

	v_stamp := 'HIERARCHY_OPTIONS.MOVE_HIERARCHY - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

	-- log the input parameters
	BEGIN
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_UPPER_ENTITY_VALUE),		',PIN_UPPER_ENTITY_VALUE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_upper_entity_rowid),		',PIN_upper_entity_rowid => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_OLD_REL_START_DATE),	',PIN_OLD_REL_START_DATE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_OLD_REL_END_DATE),			',PIN_OLD_REL_END_DATE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_NEW_REL_START_DATE),	',PIN_NEW_REL_START_DATE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTDATE(PIN_NEW_REL_END_DATE),			',PIN_NEW_REL_END_DATE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_IS_EFFECTIVE_PERIOD),		',PIN_IS_EFFECTIVE_PERIOD => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_UPPER_START_PERIOD_COLUMN),		',PIN_UPPER_START_PERIOD_COLUMN => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_UPPER_END_PERIOD_COLUMN),		',PIN_UPPER_END_PERIOD_COLUMN => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_TIME_UNIT_ID),		',PIN_TIME_UNIT_ID => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_NEW_PARENT_ENTITY_VALUE),		',PIN_NEW_PARENT_ENTITY_VALUE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_OLD_RELATIONSHIP),		',PIN_OLD_RELATIONSHIP => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_SUBORDINATE_PARENT_VALUE),		',PIN_SUBORDINATE_PARENT_VALUE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(PIN_RELATIONSHIP_MOVE_TABLE),			',PIN_RELATIONSHIP_MOVE_TABLE => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_relationship_move_tables),	',pin_relationship_move_tables => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_relationship_tables),	',pin_relationship_tables => <value>', v_stamp);
	END;

    IF (PIN_IS_EFFECTIVE_PERIOD IS NULL) THEN
      MOVE_HIERARCHY_NOT_EFFECTIVE(
                        PIN_UPPER_ENTITY_VALUE => PIN_UPPER_ENTITY_VALUE,
                        PIN_NEW_PARENT_ENTITY_VALUE => PIN_NEW_PARENT_ENTITY_VALUE,
                        PIN_SUBORDINATE_PARENT_VALUE => PIN_SUBORDINATE_PARENT_VALUE,
                        PIN_RELATIONSHIP_MOVE_TABLE => PIN_RELATIONSHIP_MOVE_TABLE,
                        pin_relationship_move_tables => pin_relationship_move_tables,
                        pin_relationship_tables => pin_relationship_tables,

                        POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                        POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                        POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                        POUT_SCN => POUT_SCN,
                        POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION
                        );

      ELSIF (PIN_IS_EFFECTIVE_PERIOD = 0) THEN

        MOVE_HIERARCHY_DATE(
                          PIN_UPPER_ENTITY_VALUE => PIN_UPPER_ENTITY_VALUE,
                          PIN_upper_entity_rowid => PIN_upper_entity_rowid,
                          PIN_NEW_REL_START_DATE => PIN_NEW_REL_START_DATE,
                          PIN_NEW_REL_END_DATE => PIN_NEW_REL_END_DATE,
                          PIN_OLD_REL_START_DATE => PIN_OLD_REL_START_DATE,
                          PIN_OLD_REL_END_DATE => PIN_OLD_REL_END_DATE,
                          PIN_NEW_PARENT_ENTITY_VALUE => PIN_NEW_PARENT_ENTITY_VALUE,
                          PIN_OLD_RELATIONSHIP => PIN_OLD_RELATIONSHIP,
                          PIN_SUBORDINATE_PARENT_VALUE => PIN_SUBORDINATE_PARENT_VALUE,
                          pin_relationship_move_table => pin_relationship_move_table,
                          pin_relationship_move_tables => pin_relationship_move_tables,
                          pin_relationship_tables => pin_relationship_tables,

                          POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                          POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                          POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                          POUT_SCN => POUT_SCN,
                          POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION
                          );


        ELSE

        MOVE_HIERARCHY_PERIOD(
                          PIN_UPPER_ENTITY_VALUE => PIN_UPPER_ENTITY_VALUE,
                          PIN_upper_entity_rowid => PIN_upper_entity_rowid,
                          PIN_NEW_REL_START_DATE => PIN_NEW_REL_START_DATE,
                          PIN_NEW_REL_END_DATE => PIN_NEW_REL_END_DATE,
                          PIN_OLD_REL_START_DATE => PIN_OLD_REL_START_DATE,
                          PIN_OLD_REL_END_DATE => PIN_OLD_REL_END_DATE,
                          PIN_UPPER_START_PERIOD_COLUMN => PIN_UPPER_START_PERIOD_COLUMN,
                          PIN_UPPER_END_PERIOD_COLUMN => PIN_UPPER_END_PERIOD_COLUMN,
                          PIN_TIME_UNIT_ID => PIN_TIME_UNIT_ID,
                          PIN_NEW_PARENT_ENTITY_VALUE => PIN_NEW_PARENT_ENTITY_VALUE,
                          PIN_OLD_RELATIONSHIP => PIN_OLD_RELATIONSHIP,
                          PIN_SUBORDINATE_PARENT_VALUE => PIN_SUBORDINATE_PARENT_VALUE,
                          pin_relationship_move_table => pin_relationship_move_table,
                          pin_relationship_move_tables => pin_relationship_move_tables,
                          pin_relationship_tables => pin_relationship_tables,

                          POUT_INSERTED_ROWS => POUT_INSERTED_ROWS,
                          POUT_UPDATED_ROWS => POUT_UPDATED_ROWS,
                          POUT_DELETED_ROWS => POUT_DELETED_ROWS,
                          POUT_SCN => POUT_SCN,
                          POUT_UPDATE_VALIDATION => POUT_UPDATE_VALIDATION
                          );


        END IF;

	v_stamp := replace(v_stamp, 'input', 'output');
	-- log the output parameters
	BEGIN

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(POUT_INSERTED_ROWS),			',POUT_INSERTED_ROWS => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(POUT_UPDATED_ROWS),	',POUT_UPDATED_ROWS => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(POUT_DELETED_ROWS),	',POUT_DELETED_ROWS => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(POUT_SCN),		',POUT_SCN => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(POUT_UPDATE_VALIDATION),		',POUT_UPDATE_VALIDATION => <value>', v_stamp);
	END;

END MOVE_HIERARCHY;

 -- Assumptions:
    -- Input Parameters are built using valid column names
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_hierarchy_list         The hierarchy build from Java; NOT NULL
    --    pin_tables_list            The entity tables list (and the ID of each entity); NOT NULL
    --    pin_fields_list            The display fields and their tables; NOT NULL
    --    pin_start_list             The entity IDs and entity VALUEs of the not yet expanded nodes; NOT NULL
    --    pin_search_string          The string used in the search; NOT NULL
    --    pin_field_to_search_in     The field in which the search is done (it may differ from entity to entity);NOT NULL
    -----------------------------------------------------------------------------------------
    -- Output :
    -----------------------------------------------------------------------------------------
    -- Return :
    --    pout_cursor                A sys_refcursor used to return the result to the Java
    --    pout_id_path               The id path used to get to the first node (nodes are separated by ',')
    --    pout_value_path            The value path used to get to the first node (nodes are separated by ',')
    ----------------------------------------------------------------------------------------
    /*

    -- Example : where_clause_vals and orderby_clause
        variable rc refcursor;
        declare
        c sys_refcursor;
        i varchar2(200);
        v varchar2(200);

          begin
            v_test := HIERARCHY_OPTIONS.SEARCH_IN_HIERARCHY(pin_hierarchy_list        => 'SELECT 2303    UPPER_ENTITY_ID,
                                                                                2303    LOWER_ENTITY_ID,
                                                                                e800328 UPPER_VALUE,
                                                                                e800308 LOWER_VALUE
                                                                          FROM   T800329',
                                          pin_table_list             => TABLETYPE_ID_NAME(OBJTYPE_ID_NAME('451', 'T800329')),
                                          pin_fields_list           => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T800329r', 'e800308'))
                                          pin_start_list            => TABLETYPE_ID_ID(OBJTYPE_ID_ID(2303,1)),
                                          pin_search_string         => 'asd',
                                          pin_field_to_search_in    => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T800329r', 'e800308')),
                                          pout_cursor               => c,
                                          pout_id_path              => i,
                                          pout_value_path           => v);
          :rc := c;
          dbms_output.put_line(i);
          dbms_output.put_line(v);
        end;
        print rc;
    */

PROCEDURE SEARCH_IN_HIERARCHY(pin_hierarchy_list      IN  VARCHAR2,
                              pin_tables_list         IN  TABLETYPE_ID_NAME,
                              pin_fields_list         IN  TABLETYPE_NAME_MAP,
                              pin_start_list          IN  TABLETYPE_ID_ID,
                              pin_search_string       IN  VARCHAR2,
                              pin_fields_to_search_in IN  TABLETYPE_DT_CHAR,
                              pin_search_field_type   IN  VARCHAR2,
                              pout_cursor             OUT SYS_REFCURSOR,
                              pout_id_path            OUT VARCHAR2,
                              pout_value_path         OUT VARCHAR2)
IS

   v_select          CLOB;
   v_sql             CLOB;

   v_connect_by      VARCHAR2(2000);
   v_search          VARCHAR2(2000);
   v_left_join       VARCHAR2(2000);
   v_path            VARCHAR2(4000);

   v_search_String   VARCHAR2(2000);

   v_return_cursor   SYS_REFCURSOR;

   v_cur             NUMBER;
   v_exec            NUMBER;

   v_stamp           L4O_LOGS.L4OL_IDENTIFIER%TYPE := 'HIERARCHY_OPTIONS.SEARCH_IN_HIERARCHY - query - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

BEGIN

   CASE WHEN pin_search_field_type = 'PERIOD'
     THEN

       -- 'PERIOD'
       -- join with the entity tables from the display fields
       FOR i IN pin_tables_list.FIRST .. pin_tables_list.LAST
         LOOP
           v_left_join := v_left_join || ' LEFT OUTER JOIN ' || pin_tables_list(i).name || ' ON ' || pin_tables_list(i).name || '.e_internal_id = TAB.lower_value AND TAB.lower_id = ' || pin_tables_list(i).id;
       END LOOP;


       FOR i IN pin_fields_to_search_in.FIRST .. pin_fields_to_search_in.LAST
         LOOP
           /* search condition */
           v_search := v_search || 'TUPR' || i || '.TUPR_PERIOD_RANGE_NAME_UPPER LIKE :search_string OR ';
           -- join with the periods_table
           v_left_join := v_left_join || ' LEFT OUTER JOIN TU_PERIODS_RANGE TUPR' || i || ' ON ' || pin_fields_to_search_in(i) || ' = TUPR' || i || '.TUPR_ID ';
       END LOOP;

     ELSE

       -- not 'PERIOD'
       FOR i IN pin_fields_to_search_in.FIRST .. pin_fields_to_search_in.LAST
         LOOP
           /* search condition */
           v_search := v_search || 'UPPER(' || pin_fields_to_search_in(i) || ') LIKE :search_string OR ';
       END LOOP;

       -- join with the entity tables from the display fields
       FOR i IN pin_tables_list.FIRST .. pin_tables_list.LAST
         LOOP
           v_left_join := v_left_join || ' LEFT OUTER JOIN ' || pin_tables_list(i).name || ' ON ' || pin_tables_list(i).name || '.e_internal_id = TAB.lower_value AND TAB.lower_id = ' || pin_tables_list(i).id;
       END LOOP;
   END CASE;

   v_search := substr(v_search, 1, length(v_search)-4);

   -- get the main select
   v_select := 'SELECT SUBSTR(PATH_VALUE, 2) PATH_VALUE, SUBSTR(PATH_ID, 2) PATH_ID, SUBSTR(PATH_VALUE_ID, 2) PATH_VALUE_ID FROM (
                    SELECT SYS_CONNECT_BY_PATH(UPPER_VALUE, '','') || '','' || LOWER_VALUE PATH_VALUE,
                           SYS_CONNECT_BY_PATH(UPPER_ID, '','') || '','' || LOWER_ID PATH_ID,
                           SYS_CONNECT_BY_PATH(''('' || UPPER_VALUE || '', '' || UPPER_ID || '')'', ''/ '') PATH_VALUE_ID
                      FROM ';

   -- get the hierarchy list
   v_select := v_select || '(' || pin_hierarchy_list || ') TAB ' || v_left_join;

   -- add the where clause
   v_select := v_select || ' WHERE ' || v_search;

   v_connect_by := 'CONNECT BY NOCYCLE PRIOR TAB.lower_id = TAB.upper_id
                         AND PRIOR TAB.lower_value = TAB.upper_value
                   ORDER SIBLINGS BY TAB.lower_id, TAB.lower_value)
                   UNION ALL' || chr(10);

   <<FETCH_loop>>
   FOR i IN pin_start_list.FIRST .. pin_start_list.LAST
     LOOP
       v_sql := 'SELECT /*+ first_rows(1) */ *
             FROM (' || v_select || ' START WITH (TAB.upper_id = ' || TO_CHAR(pin_start_list(i).ID1) || '
                                              AND TAB.upper_value = ' || TO_CHAR(pin_start_list(i).ID2) || ')'
                || v_connect_by;

       v_sql := substr(v_sql, 1, length(v_sql)-10) || ') WHERE ROWNUM = 1';


        v_cur := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(v_cur, v_sql, DBMS_SQL.NATIVE);

        v_search_string := '%' || UPPER(pin_search_string) || '%';
        -- input variables
        DBMS_SQL.BIND_VARIABLE(v_cur, 'search_string', v_search_string);

        -- output variables
        DBMS_SQL.DEFINE_COLUMN(v_cur, 1, pout_value_path, 2000);
        DBMS_SQL.DEFINE_COLUMN(v_cur, 2, pout_id_path, 2000);
        DBMS_SQL.DEFINE_COLUMN(v_cur, 3, V_PATH, 2000);
       -- execute query
        v_exec := DBMS_SQL.EXECUTE_AND_FETCH(v_cur);

        -- check if there are values fetched
        exit FETCH_loop when v_exec > 0;

        DBMS_SQL.CLOSE_CURSOR(v_cur);
   END LOOP;

   -- log the last query
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_sql),    ',V_SQL => <value>', v_stamp);

   IF (v_exec = 0) THEN
      RAISE NO_DATA_FOUND;
   END IF;


    -- get the values returned
    DBMS_SQL.column_value(v_cur, 1, pout_value_path);
    DBMS_SQL.column_value(v_cur, 2, pout_id_path);
    DBMS_SQL.column_value(v_cur, 3, V_PATH);

    DBMS_SQL.CLOSE_CURSOR(v_cur);

   /* from here starts the second query */

   -- get the main selected columns
   v_sql :=' SELECT TAB.upper_id                 UPPER_ID,
                    TAB.lower_id                 LOWER_ID,
                    TAB.upper_value              UPPER_VALUE,
                    TAB.lower_value              LOWER_VALUE';

   -- select the fields to display
   FOR i IN pin_fields_list.FIRST .. pin_fields_list.LAST
     LOOP
       v_sql := v_sql || '
       ,' || pin_fields_list(i).name2 || '.' || pin_fields_list(i).name1;
   END LOOP;

   -- add the level if it's necessary
   v_sql := v_sql || '
       ,1                                   "LEVEL"';
   -- add the hierarchies from to the query
   v_sql := v_sql || '
       ,CASE WHEN (lower_id, lower_value) NOT IN
       (SELECT upper_id, upper_value FROM
       (' || pin_hierarchy_list || ')) THEN 1 ELSE 0 END IS_LEAF
       FROM ' || '(' || pin_hierarchy_list || ')  TAB ' || v_left_join;

   -- add the where and order by

   v_sql := v_sql || '
        WHERE (TAB.upper_value, TAB.upper_id) IN (' || replace(v_path, '/', ',') || ')
        ORDER BY lower_id,
          lower_value';

   -- log the sql
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),    ',V_SQL2 => <value>', v_stamp);

   OPEN v_return_cursor FOR v_sql;

   -- return results
   pout_cursor := v_return_cursor;

EXCEPTION
  when OTHERS THEN
    IF DBMS_SQL.IS_OPEN(v_cur) THEN
         DBMS_SQL.CLOSE_CURSOR(v_cur);
    END IF;
    RAISE;

end SEARCH_IN_HIERARCHY;


-- *******************************    PUBLIC PROCEDURES END         *******************************
END HIERARCHY_OPTIONS;
/
