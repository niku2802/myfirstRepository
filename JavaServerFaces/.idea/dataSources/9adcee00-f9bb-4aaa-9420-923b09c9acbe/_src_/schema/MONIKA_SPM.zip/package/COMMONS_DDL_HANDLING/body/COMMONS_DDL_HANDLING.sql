CREATE package body commons_ddl_handling is
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  appframework
  -- Requester    :  Lazar, Lucian
  -- Author    :  Lazar, Lucian
  -- Reviewer    :  Sharma, Pooja
  -- Review date    :  20110202
  -- Description    :  Used for executing and rollbacking DDL statements
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

  function get_transaction_id return varchar2 as
    v_transaction_id varchar2(30);
  begin
	  v_transaction_id := dbms_transaction.local_transaction_id(true);
	  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'TX_ID:'||v_transaction_id, NULL, NULL, 'COMMONS_DDL_HANDLING.GET_TRANSACTION_ID');
    return v_transaction_id;
  end get_transaction_id;

  procedure execute_ddl_internal(pi_ddl in clob) is
    v_index integer := 0;
    v_max_retries integer;
    v_wait_between_retries integer;
    v_resource_busy exception;
    pragma exception_init(v_resource_busy,-54);
  begin
  	begin
      select PR_VALUE
        into v_max_retries
        from PROPERTIES
       where PR_NAME = 'RETRY_EXECUTE_DDL';
    exception
      when no_data_found then v_max_retries := 3;
    end;
  	begin
      select PR_VALUE
        into v_wait_between_retries
        from PROPERTIES
       where PR_NAME = 'WAIT_TIME_EXECUTE_DDL';
    exception
      when no_data_found then v_wait_between_retries := 1;
    end;
    -- retry to execute the statement a given number of times with a given number of seconds between retries
    while v_index < v_max_retries loop
      begin

        execute immediate pi_ddl;
        v_index := v_max_retries;
      exception
        when v_resource_busy then
          if v_index = v_max_retries - 1 then
            raise;
          end if;
          v_index := v_index + 1;
          dbms_lock.sleep(v_wait_between_retries);
        when others then
          raise;
      end;
    end loop;
  end execute_ddl_internal;

  procedure log_ddl_history(pi_transaction_id in varchar2) is
  begin
    insert into UNDO_DDL_HISTORY(UD_ID,
                                 UD_TRANSACTION_ID,
                                 UD_INDEX,
                                 UD_DDL_STATEMENT,
                                 UD_UNDO_DDL_STATEMENT,
                                 UD_STATUS,
                                 UD_ERROR_DESCRIPTION,
                                 UD_CALLER_DESCRIPTION,
                                 UD_CALLER_TIMESTAMP,
                                 UD_RUN_ID,
                                 UD_TRANSACTION_INDEX,
                                 UD_RESOURCE_ID,
                                 UD_TRANSACTION_XID,
                                 UD_ROLLBACK_ORPHAN_TIMESTAMP)
    select UD_ID,
           UD_TRANSACTION_ID,
           UD_INDEX,
           UD_DDL_STATEMENT,
           UD_UNDO_DDL_STATEMENT,
           UD_STATUS,
           UD_ERROR_DESCRIPTION,
           UD_CALLER_DESCRIPTION,
           UD_CALLER_TIMESTAMP,
           UD_RUN_ID,
           UD_TRANSACTION_INDEX,
           UD_RESOURCE_ID,
           UD_TRANSACTION_XID,
           UD_ROLLBACK_ORPHAN_TIMESTAMP
      from UNDO_DDL ud
     where UD_TRANSACTION_ID = pi_transaction_id
       and not exists(select 1
                        from UNDO_DDL_HISTORY udh
                       where ud.UD_ID = udh.UD_ID);
  end log_ddl_history;

  procedure execute_ddl(pi_transaction_id  in varchar2,
                        pi_description     in varchar2,
                        pi_ddl             in clob,
                        pi_undo_ddl        in clob,
                        pi_run_id          in number default null,
                        pi_resource_id     in varchar2 default null) is
    pragma autonomous_transaction;
    v_ud_id UNDO_DDL.UD_ID%type;
    v_status integer := 0;
    v_ddl_index integer;
	  v_tx_index integer;
	  v_stamp	L4O_LOGS.L4OL_IDENTIFIER%TYPE;
    v_error varchar2(500);
    v_transaction_xid varchar2(30);
    v_undo_ddl UNDO_DDL.UD_UNDO_DDL_STATEMENT%type;
  begin
    v_stamp := 'COMMONS_DDL_HANDLING.EXECUTE_DDL - TX_ID:'||pi_transaction_id||' RUN_ID:'||TO_CHAR(pi_run_id)||' - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
	  v_ud_id := UNDO_DDL_SEQ.nextval;
    -- set index of the DDL inside the transaction id and get the transaction XID
    select nvl(max(UD_INDEX),0)+1, max(UD_TRANSACTION_XID) into V_DDL_INDEX, v_transaction_xid from UNDO_DDL where UD_TRANSACTION_ID = pi_transaction_id;
    -- get transaction XID from the transactions view exposed by optymyze admin schema if this is the first DDL in the transaction
    if V_DDL_INDEX = 1 then
      select max(xid) into v_transaction_xid from optmz$user_transactions where transaction_id = pi_transaction_id;
    end if;
	  -- set index of the transaction id inside the run id
    IF (pi_run_id IS NOT NULL)
      THEN
        SELECT CASE WHEN TX_INDEX = 0 THEN RUN_INDEX + 1 ELSE TX_INDEX END
          INTO v_tx_index
          FROM (SELECT	(SELECT NVL(MAX(UD_TRANSACTION_INDEX), 0) FROM UNDO_DDL WHERE UD_TRANSACTION_ID = pi_transaction_id) TX_INDEX
                       ,(SELECT NVL(MAX(UD_TRANSACTION_INDEX), 0) FROM UNDO_DDL WHERE UD_RUN_ID = pi_run_id) RUN_INDEX
                  FROM dual);
    END IF;
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_DDL:'||pi_ddl, NULL, NULL, v_stamp);
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_UNDO_DDL:'||pi_undo_ddl, NULL, NULL, v_stamp);
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_INDEX:'||v_ddl_index, NULL, NULL, v_stamp);
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_TRANSACTION_INDEX:'||v_tx_index, NULL, NULL, v_stamp);
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:0', NULL, NULL, v_stamp);
    -- replace empty string with begin null; end; to avoid errors during rollback
    if pi_undo_ddl is null then
      v_undo_ddl := 'begin null; end;';
    else
      v_undo_ddl := pi_undo_ddl;
    end if;
    -- register the DDL in the UNDO_DDL table with status 0 (to be executed)
    insert into UNDO_DDL(UD_ID,
                         UD_TRANSACTION_ID,
                         UD_INDEX,
                         UD_CALLER_DESCRIPTION,
                         UD_CALLER_TIMESTAMP,
                         UD_DDL_STATEMENT,
                         UD_UNDO_DDL_STATEMENT,
                         UD_STATUS,
                         UD_RUN_ID,
                         UD_TRANSACTION_INDEX,
                         UD_RESOURCE_ID,
                         UD_TRANSACTION_XID)
    values(v_ud_id,
           pi_transaction_id,
           v_ddl_index,
           pi_description,
           sysdate,
           pi_ddl,
           v_undo_ddl,
           0,
           pi_run_id,
           v_tx_index,
           pi_resource_id,
           v_transaction_xid);
    commit;
    v_status := 1;
    execute_ddl_internal(pi_ddl);
    v_status := 2;
    -- update the status in the UNDO_DDL table to 1 (executed successfully)
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:1', NULL, NULL, v_stamp);
    update UNDO_DDL
       set UD_STATUS = 1
     where UD_ID = v_ud_id;
    commit;
  exception
    when others then
      v_error := substr(SQLERRM, 1, 500);
      -- if v_status is 1 there was an error in executing the DDL itself - catch the exception and update the status in the UNDO_DDL table to 2 (error while executing the DDL)
      if v_status = 1 THEN
	      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:2', NULL, NULL, v_stamp);
        update UNDO_DDL
           set UD_STATUS = 2,
               UD_ERROR_DESCRIPTION = UD_ERROR_DESCRIPTION || ' Exception while executing: ' || v_error,
               UD_ERROR_TIMESTAMP = sysdate
         where UD_ID = v_ud_id;
        log_ddl_history(pi_transaction_id);
        commit;
        raise;
      -- if v_status is 2 there was an error in registering or updating the DDL status - catch the exception and update the status in the UNDO_DDL table to 3 (other error while executing the DDL)
      elsif v_status in (0,2) then
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:3', NULL, NULL, v_stamp);
        update UNDO_DDL
           set UD_STATUS = 3,
               UD_ERROR_DESCRIPTION = UD_ERROR_DESCRIPTION || ' Exception while registering: ' || v_error,
               UD_ERROR_TIMESTAMP = sysdate
         where UD_ID = v_ud_id;
        log_ddl_history(pi_transaction_id);
        commit;
        raise;
      end if;
  end execute_ddl;

  procedure execute_ddl_nolog(pi_ddl in clob,
							  pi_to_trace in number default 0)
	is
    pragma autonomous_transaction;
  begin
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'DDL:'||pi_ddl, NULL, NULL, 'COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG');
    execute immediate pi_ddl;
	if pi_to_trace <> 0
	then
		COMMONS_PROCESSING.SAVE_EXEC_PLAN( pi_run_id              => NULL
										  ,pi_query_identifier    => NULL
										  ,pi_bind_variables      => NULL);
	end if;
    commit;
  end execute_ddl_nolog;

  procedure execute_ddl_nolog_binds
  (pi_ddl      IN CLOB
  ,pi_bindvar1 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar2 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar3 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar4 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar5 IN VARCHAR2 DEFAULT NULL
  ,pi_log_id   IN VARCHAR2 DEFAULT NULL
  ) is
    pragma autonomous_transaction;
  begin
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG'||CHR(10)
                                                 ||'BV1:'||pi_bindvar1||CHR(10)
                                                 ||'BV2:'||pi_bindvar2||CHR(10)
                                                 ||'BV3:'||pi_bindvar3||CHR(10)
                                                 ||'BV4:'||pi_bindvar4||CHR(10)
                                                 ||'BV5:'||pi_bindvar5||CHR(10)
                                                 ||'DDL:'||pi_ddl, NULL, NULL, NVL(pi_log_id, 'COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG'));

    IF    (pi_bindvar5 IS NOT NULL) THEN EXECUTE IMMEDIATE pi_ddl USING pi_bindvar1, pi_bindvar2, pi_bindvar3, pi_bindvar4, pi_bindvar5;
    ELSIF (pi_bindvar4 IS NOT NULL) THEN EXECUTE IMMEDIATE pi_ddl USING pi_bindvar1, pi_bindvar2, pi_bindvar3, pi_bindvar4;
    ELSIF (pi_bindvar3 IS NOT NULL) THEN EXECUTE IMMEDIATE pi_ddl USING pi_bindvar1, pi_bindvar2, pi_bindvar3;
    ELSIF (pi_bindvar2 IS NOT NULL) THEN EXECUTE IMMEDIATE pi_ddl USING pi_bindvar1, pi_bindvar2;
    ELSIF (pi_bindvar1 IS NOT NULL) THEN EXECUTE IMMEDIATE pi_ddl USING pi_bindvar1;
    ELSE                                 EXECUTE IMMEDIATE pi_ddl;
    END IF;

    commit;
  end execute_ddl_nolog_binds;

  procedure execute_ddl_nolog_rowcount(pi_ddl in clob,
									   pi_to_trace in number default 0,
									   po_rowcount out number) is
    pragma autonomous_transaction;
  begin
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'DDL:'||pi_ddl, NULL, NULL, 'COMMONS_DDL_HANDLING.EXECUTE_DDL_ROWCOUNT');
    execute immediate pi_ddl;
    po_rowcount := sql%rowcount;
	if pi_to_trace <> 0
	then
		COMMONS_PROCESSING.SAVE_EXEC_PLAN( pi_run_id              => NULL
										  ,pi_query_identifier    => NULL
										  ,pi_bind_variables      => NULL);
	end if;
    commit;
  end execute_ddl_nolog_rowcount;

  procedure clean_ddl_log(pi_transaction_id in VARCHAR2,
  							          pi_run_id         in number default NULL)
  is
  begin
  	L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'TX_ID:'||pi_transaction_id||' RUN_ID:'||TO_CHAR(pi_run_id), NULL, NULL, 'COMMONS_DDL_HANDLING.CLEAN_DDL_LOG');
    if pi_run_id is null then
		  delete UNDO_DDL
       where UD_TRANSACTION_ID = pi_transaction_id;
	  else
		  delete UNDO_DDL
       where UD_RUN_ID = pi_run_id;
	  end if;
  end clean_ddl_log;

  procedure execute_rollback_ddl(pi_undo_ddl_statement in clob,
                                 pi_resource_id        in varchar2,
                                 pi_views              in out clob) is
    v_compilation_error exception;
    pragma exception_init(v_compilation_error,-24344);
  begin
    execute_ddl_internal(pi_undo_ddl_statement);
  exception
    -- when a create view with FORCE option throws "ORA-24344: success with compilation error" we do not stop the rollback
    -- this is a workaround to allow the rollback of ICM views created with FORCE option
    -- the views created with FORCE option are a workaround for not handling the proper order of the DDLs in the caller
    -- all this framework is a giant workaround as Oracle does not have the feature to "rollback" DDLs in a transaction
    when v_compilation_error then
      pi_views := pi_views || ',''' || pi_resource_id || '''';
  end execute_rollback_ddl;

  procedure recompile_views(pi_views in clob) is
  begin
    execute_ddl_nolog('begin
                         for c in (select view_name from user_views where view_name in (' || pi_views || ')) loop
                           execute immediate ''alter view '' || c.view_name || '' compile'';
                         end loop;
                       end;');
  end recompile_views;

  procedure rollback_ddl(pi_transaction_id in varchar2,
                         pi_run_id         in number default null,
                         pi_orphan_job     in number default 0) is
    pragma autonomous_transaction;
    v_undo_ddl UNDO_DDL.UD_UNDO_DDL_STATEMENT%type;
    v_ud_transaction_id UNDO_DDL.UD_TRANSACTION_ID%type;
    v_ud_run_id UNDO_DDL.UD_RUN_ID%type;
    v_ud_id UNDO_DDL.UD_ID%type;
    v_resource_id UNDO_DDL.UD_RESOURCE_ID%type;
	  v_stamp L4O_LOGS.L4OL_IDENTIFIER%TYPE;
    v_error varchar2(500);
    v_views clob;
    v_compilation_error exception;
    pragma exception_init(v_compilation_error,-24344);
  begin
  	v_stamp := 'COMMONS_DDL_HANDLING.ROLLBACK_DDL - TX_ID:'||pi_transaction_id||' RUN_ID:'||TO_CHAR(pi_run_id)||' - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    if pi_transaction_id is not null and pi_run_id is not null then
      raise_application_error(commons_exceptions.e_NotNullParams_code,commons_exceptions.error_text(commons_exceptions.e_NotNullParams_msg,'Transaction id' || ';' || 'run id'));
    end if;
    if pi_run_id is null then
      -- get all the DDLs from the transaction with status 0 (to be executed), 1 (executed successfully), 3 (error while logging) and 4 (to be rolled back)
      for transaction_ddls_ass in (select UD_UNDO_DDL_STATEMENT,
                                          UD_RUN_ID,
                                          UD_TRANSACTION_INDEX,
                                          UD_TRANSACTION_ID,
                                          UD_INDEX,
                                          UD_ID,
                                          UD_RESOURCE_ID
                                     from UNDO_DDL
                                    where UD_TRANSACTION_ID = pi_transaction_id
                                      and UD_STATUS in (0,1,3,4,6)
                                    order by UD_INDEX desc) loop
        v_undo_ddl := transaction_ddls_ass.UD_UNDO_DDL_STATEMENT;
        v_ud_transaction_id := transaction_ddls_ass.UD_TRANSACTION_ID;
        v_ud_run_id := transaction_ddls_ass.UD_RUN_ID;
        v_ud_id := transaction_ddls_ass.UD_ID;
        v_resource_id := transaction_ddls_ass.UD_RESOURCE_ID;
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_UNDO_DDL:'||transaction_ddls_ass.UD_UNDO_DDL_STATEMENT, NULL, NULL, v_stamp);
        -- update the status in the UNDO_DDL table to 4 (to be rolled back)
        update UNDO_DDL
           set UD_STATUS = 4
         where UD_ID = transaction_ddls_ass.ud_id;
        -- execute undo DDLs in the reverse order of index
        execute_rollback_ddl(v_undo_ddl,v_resource_id,v_views);
		    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:4', NULL, NULL, v_stamp);
        -- update the status in the UNDO_DDL table to 5 (rolled back successfully)
        update UNDO_DDL
           set UD_STATUS = 5
         where UD_ID = transaction_ddls_ass.ud_id;
        -- mark the DDL as rolled back from the rollback orphan transactions job
        if pi_orphan_job = 1 then
          update UNDO_DDL
             set UD_ROLLBACK_ORPHAN_TIMESTAMP = systimestamp
           where UD_ID = transaction_ddls_ass.ud_id;
        end if;
        commit;
      end loop;
    else
      -- get all the DDLs from transactions with status 0 (to be executed), 1 (executed successfully), 3 (error while logging) and 4 (to be rolled back)
      -- belonging to a certain run id
      for run_transaction_ddls_ass in (select UD_UNDO_DDL_STATEMENT,
                                              UD_RUN_ID,
                                              UD_TRANSACTION_INDEX,
                                              UD_TRANSACTION_ID,
                                              UD_INDEX,
                                              UD_ID,
                                              UD_RESOURCE_ID
                                         from UNDO_DDL
                                        where UD_TRANSACTION_ID in (select UD_TRANSACTION_ID
                                                                      from UNDO_DDL
                                                                     where UD_RUN_ID = pi_run_id)
                                          and UD_STATUS in (0,1,3,4,6)
                                        order by UD_TRANSACTION_INDEX desc, UD_INDEX desc) loop
        v_undo_ddl := run_transaction_ddls_ass.UD_UNDO_DDL_STATEMENT;
        v_ud_transaction_id := run_transaction_ddls_ass.UD_TRANSACTION_ID;
        v_ud_run_id := run_transaction_ddls_ass.UD_RUN_ID;
        v_ud_id := run_transaction_ddls_ass.UD_ID;
        v_resource_id := run_transaction_ddls_ass.UD_RESOURCE_ID;
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_UNDO_DDL:'||run_transaction_ddls_ass.UD_UNDO_DDL_STATEMENT, NULL, NULL, v_stamp);
        -- update the status in the UNDO_DDL table to 4 (to be rolled back)
        update UNDO_DDL
           set UD_STATUS = 4
         where UD_ID = run_transaction_ddls_ass.ud_id;
        -- execute undo DDLs in the reverse order of index
        execute_rollback_ddl(v_undo_ddl,v_resource_id,v_views);
        -- update the status in the UNDO_DDL table to 5 (rolled back successfully)
        L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:4', NULL, NULL, v_stamp);
        update UNDO_DDL
           set UD_STATUS = 5
         where UD_ID = run_transaction_ddls_ass.ud_id;
        -- mark the DDL as rolled back from the rollback orphan transactions job
        if pi_orphan_job = 1 then
          update UNDO_DDL
             set UD_ROLLBACK_ORPHAN_TIMESTAMP = systimestamp
           where UD_ID = run_transaction_ddls_ass.ud_id;
        end if;
        commit;
      end loop;
      -- recompile the views created with FORCE option to avoid future errors when using them
      if v_views is not null then
        v_views := substr(v_views,2);
        recompile_views(v_views);
      end if;
    end if;
  exception
    when others then
      v_error := substr(SQLERRM, 1, 500);
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'UD_STATUS:5', NULL, NULL, v_stamp);
      -- catch the exception and update the status in the UNDO_DDL table to 6 (rollback failed)
      update UNDO_DDL
         set UD_STATUS = 6,
             UD_ERROR_DESCRIPTION = ' Exception while rollback : ' || v_error,
             UD_ERROR_TIMESTAMP = sysdate
       where UD_ID = v_ud_id;
      -- mark the DDL as rolled back from the rollback orphan transactions job
      if pi_orphan_job = 1 then
        update UNDO_DDL
           set UD_ROLLBACK_ORPHAN_TIMESTAMP = systimestamp
         where UD_ID = v_ud_id;
      end if;
      commit;
      raise_application_error(commons_exceptions.e_DDLRolbackFailed_code,commons_exceptions.error_text(commons_exceptions.e_DDLRolbackFailed_msg,nvl(to_char(v_ud_run_id),'null') || ';' || nvl(v_ud_transaction_id,'null') || ';' || nvl(to_char(v_ud_id),'null') || ';' || nvl(v_error,'null')));
  end rollback_ddl;

  procedure rollback_orphan_item(pi_item_id   in varchar2,
                                 pi_item_type in number) as
    v_check integer := 0;
  begin
    begin
      rollback_ddl(case when pi_item_type = 1 then null when pi_item_type = 2 then pi_item_id end,
                   case when pi_item_type = 1 then pi_item_id when pi_item_type = 2 then null end);
      v_check := 1;
    exception
      -- we catch all the exceptions as we want to auto rollback everything that can be rolled back
      -- and leave for the DBA intervention only the really fucked up processes
      when others then null;
    end;
    if v_check = 1 then
      -- we clean the log only if the process was successfully rolled back
      clean_ddl_log(case when pi_item_type = 1 then null when pi_item_type = 2 then pi_item_id end,
                   case when pi_item_type = 1 then pi_item_id when pi_item_type = 2 then null end);
    end if;
    commit;
  end rollback_orphan_item;

  procedure rollback_orphan_ddl_trans as
  begin
    -- rollback orphan processes
    for orphan_processes in (select distinct UD_RUN_ID
                               from UNDO_DDL
                              where UD_STATUS in (0, 1, 4, 5, 6)
                                and UD_RUN_ID is not null
                                and not exists (with TEMP_USER_TRANS as (select TRANSACTION_ID from OPTMZ$USER_TRANSACTIONS)
                                                select 1
                                                  from TEMP_USER_TRANS
                                                 where TRANSACTION_ID = UD_TRANSACTION_ID)) loop
      rollback_orphan_item(orphan_processes.UD_RUN_ID,1);
    end loop;
    -- rollback orphan transactions
    for orphan_transactions in (select distinct UD_TRANSACTION_ID
                                  from UNDO_DDL
                                 where UD_RUN_ID is null
                                   and UD_STATUS in (0, 1, 4, 5, 6)
                                   and not exists (with TEMP_USER_TRANS as (select TRANSACTION_ID from OPTMZ$USER_TRANSACTIONS)
                                                   select 1
                                                     from TEMP_USER_TRANS
                                                    where TRANSACTION_ID = UD_TRANSACTION_ID)) loop
      rollback_orphan_item(to_char(orphan_transactions.UD_TRANSACTION_ID),2);
    end loop;
  end rollback_orphan_ddl_trans;

  procedure check_locks(pi_run_id        in number,
                        pi_definition_id in number,
                        pi_mode          in number,
                        po_locks         out number) is
    v_rollbacks integer;
    v_run_id number(10);
    v_rollback_count integer;
    v_rollback_state_count integer;
    v_locked_objects_count integer;
  	v_not_wait_for_rollback integer;
    v_period_type number(10);
    v_day_to_run date;
    v_period_id number(10);
  begin

    -- first, check if there are any db rollbacks running in background for any process or if there are transactions in rollback state or if there are locked objects

    -- insert the transaction into a GTT to avoid ORA-600 due to changes in v$transaction
    insert into TRANSACTION_INFO (TI_TRANSACTION_ID, TI_TRANSACTION_XID)
    select TRANSACTION_ID, XID
      from OPTMZ$USER_TRANSACTIONS;

    -- we check based on transactions XID because that remains unchanged while the transaction id changes

    -- check if transactions in rollback state are at the schema level
    select count(*)
           into v_rollbacks
      from (select *
              from table(dba_utils.getTransactionInRollbackState)
             where rownum = 1
            );

    if v_rollbacks = 0 then
       begin
           po_locks := 0;
           delete TRANSACTION_INFO;
           return;
       end;
    else
       begin
           -- check if there are locked objects at schema level
           select count(*)
             into v_rollbacks
             from (select *
                     from table(dba_utils.getUserLockedObjects)
                    where rownum = 1
                   )
            where rownum = 1;

           if v_rollbacks = 0 then
              begin
                  po_locks := 0;
                  delete TRANSACTION_INFO;
                  return;
              end;
           else
              begin
                  select count(*)
                    into v_rollbacks
                    from (select rownum
                            from UNDO_DDL
                           where exists (select 1
                                           from TRANSACTION_INFO
                                          where UD_TRANSACTION_XID = TI_TRANSACTION_XID
                                         )
                          )
                   where rownum = 1;
              end;
           end if;
        end;
    end if;

    if v_rollbacks = 0 then
      -- there are no locks and the run/rollback can be started immediatly
      po_locks := 0;
    else
      -- there is at least a rollback or a lock in a system and we check if the specific definition has a lock or a rollback running
      if pi_mode = 1 then
        -- if the sp is called before a new run then check the previous run on the same period
        select rd_period_type, rd_day_to_run, rd_tupr_id
          into v_period_type, v_day_to_run, v_period_id
          from run_data
         where rd_id = pi_run_id;
        select max(rd_id)
          into v_run_id
          from run_data
          join run_status_data on rd_id = rs_id
         where rd_definition_id = pi_definition_id
           and rs_status in (2, 3, 4, 5)
           and rd_id < pi_run_id
           and rd_period_type = v_period_type
           and case when v_period_type = 1 and rd_day_to_run = v_day_to_run then 1 else 0 end = 1
           and case when v_period_type = 2 and rd_tupr_id = v_period_id then 1 else 0 end = 1;
      elsif pi_mode = 2 then
        -- if the sp is called before a rollback then check the current run
        v_run_id := pi_run_id;
      end if;

      -- check if the process needs to wait for the rollback of a previous instance before starting
      select count(*)
        into v_not_wait_for_rollback
        from (select rownum
                from run_data
                join run_status_data on rd_id = rs_id
                join utl_process_type on rd_type = process_type_id
               where rd_id = v_run_id
                 and rs_abort_request_time is not null
                 and rs_abort_request_time < rs_post_execution_start_time
                 and process_type_rollback = 0
              )
       where rownum = 1;

      -- if it does not need to wait we skip checking the locks
      if v_not_wait_for_rollback > 0 then
        po_locks := 0;
      else
        -- check if there are db rollbacks running in background for the transactions belonging to the input run
        -- we check based on transactions XID because that remains unchanged while the transaction id changes
        select count(*)
          into v_rollback_count
          from (select rownum
                  from UNDO_DDL
                 where UD_RUN_ID = v_run_id
                   and exists (select 1
                                 from TRANSACTION_INFO
                                where UD_TRANSACTION_XID = TI_TRANSACTION_XID)
                )
         where rownum = 1;
        if v_rollback_count = 0 then
          -- check if there are transactions in rollback state
          select count(*)
            into v_rollback_state_count
            from (select rownum
                    from UNDO_DDL
                   where UD_RUN_ID = v_run_id
                     and exists (select 1
                                 from table(dba_utils.getTransactionInRollbackState)
                                where UD_TRANSACTION_XID = XID)
                  )
           where rownum = 1;
          -- check if there are locked objects
          select count(*)
            into v_locked_objects_count
            from (select rownum
                    from UNDO_DDL
                   where UD_RUN_ID = v_run_id
                     and exists (select 1
                                 from table(dba_utils.getUserLockedObjects)
                                where UD_TRANSACTION_XID = XID)
                  )
           where rownum = 1;
        end if;
        if v_rollback_count > 0 or v_rollback_state_count > 0 or v_locked_objects_count > 0 then
          -- there are locks and the run/rollback cannot start
          po_locks := 1;
        else
          -- there are no locks and the run/rollback can be started immediatly
          po_locks := 0;
        end if;
      end if;
    end if;

    delete TRANSACTION_INFO;

  end check_locks;

  procedure check_multiple_locks(pi_run_id_set in coltype_id,
                                 pi_mode       in number,
                                 po_run_id     out number) is
    v_locks integer;
    v_runs tabletype_id_id;
  begin
    select objtype_id_id(RD_ID, RD_DEFINITION_ID) bulk collect into v_runs from RUN_DATA where RD_ID in (select * from table(pi_run_id_set));
    for c in (select ID1 RD_ID, ID2 RD_DEFINITION_ID from table(v_runs)) loop
      if c.RD_DEFINITION_ID is not null then
        check_locks(pi_run_id        => c.RD_ID,
                    pi_definition_id => c.RD_DEFINITION_ID,
                    pi_mode          => pi_mode,
                    po_locks         => v_locks);
        if v_locks = 0 then
          po_run_id := c.RD_ID;
          -- return the first run id can be started immediatly
          exit;
        end if;
      end if;
    end loop;
  end check_multiple_locks;

  function check_rollback(pi_run_id in number) return number is
    v_rollback_status number;
  begin
    -- return 5 for ddl rollback in progress
    -- return 6 for ddl rollback failed
    -- return 7 for no activity
    select decode(max(UD_STATUS),6,6,5,5,4,5,7)
      into v_rollback_status
      from UNDO_DDL
     where UD_RUN_ID = pi_run_id;
    return v_rollback_status;
  end check_rollback;

  procedure process_activity_status(pi_run_id         in number,
                                    po_process_status out tabletype_process_db_activity) is
    v_count integer;
  begin
    -- check if the input process run id is in status STARTED or POST-EXECUTION
    select count(*) into v_count from (select rownum from RUN_STATUS_DATA where RS_ID = pi_run_id and RS_STATUS in (2,3,4)) where rownum = 1;
    if v_count = 0 then
      raise_application_error(-20001,'There is no process in progress or in post-execution with the provided run id.');
    end if;
    -- check processes
    with PROCESSES as
     (select RD_ID, RD_PARENT_ID, RD_NAME, RD_LOG_ID, PROCESS_TYPE_ID, PROCESS_TYPE_NAME, RS_STATUS
        from RUN_DATA
        join RUN_STATUS_DATA on RD_ID = RS_ID
        join UTL_PROCESS_TYPE on RD_TYPE = PROCESS_TYPE_ID
       start with RD_ID = pi_run_id
      connect by prior RD_ID = RD_PARENT_ID)
    select objtype_process_db_activity(RD_ID,
                                       RD_NAME,
                                       RD_LOG_ID,
                                       PROCESS_TYPE_ID,
                                       PROCESS_TYPE_NAME,
                                       RS_STATUS,
                                       case when check_rollback(x.RD_ID) < 7
                                            then check_rollback(x.RD_ID)
                                            else optymyze_admin.dba_utils.getProcessStatus(user,'%R:' || x.RD_ID)
                                        end)

      bulk collect into po_process_status
      from PROCESSES x
     where (x.RS_STATUS in (2,4) and not exists (select 1 from PROCESSES where x.RD_ID = RD_PARENT_ID))
        or RD_ID = pi_run_id
     order by RD_ID;
  end process_activity_status;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END       *******************************

end commons_ddl_handling;
/
