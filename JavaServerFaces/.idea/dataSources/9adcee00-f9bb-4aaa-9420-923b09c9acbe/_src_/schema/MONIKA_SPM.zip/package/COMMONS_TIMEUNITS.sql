CREATE PACKAGE commons_timeunits AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    :  SPM
-- Product            :  commons
-- Module              :  timeunits-commons
-- Requester          :  Katti, Anuja
-- Author              :  Rohit, Maxim
-- Reviewer            :  Sharma, Pooja
-- Review date        :  13-Apr-2011
-- Description        :  This package adds and modify system Time Unit and their correspondance
-- ---------------------------------------------------------------------------

-- *******************************    PUBLIC PROCEDURES START       *******************************

/* ADD_SYSTEM_TIME_UNIT
=============================================

-- Author     : Maxim Rohit
-- Create date: 8 April 2011
-- Module     : timeunits-commons
-- Description: This procedure adds system Time Unit and their correspondance
-- =============================================
-- Assumptions:The Time unit being added is not existing in the system
--             The Time unit name is case sensitive
--             The time unit correspondances are always add with the small time unit being the primary and the bigger being the secondary.
--             The time unit correspondances in order of the primary time unit

-- Return : NA
-- =============================================

-- Parameters:-
-- IN Parameters

-- PI_TU_NAME                VARCHAR2:- TU Name that needs to be added
-- PI_START_YEAR             NUMBER:- Start Year in yyyy format
-- PI_END_YEAR               NUMBER:- end Year in yyyy format


-- OUT Parameters
-- PO_TU_ID
-- =============================================
--Example

PKG_TIME_UNIT.ADD_SYSTEM_TIME_UNIT(PI_TU_NAME => 'Month',
PI_START_YEAR => '2010',
PI_END_YEAR => '2011');

-- =============================================*/
procedure ADD_SYSTEM_TIME_UNIT(PI_TU_NAME    in VARCHAR2,
PI_START_YEAR in NUMBER,
PI_END_YEAR   in NUMBER,
PO_TU_ID      out NUMBER);


/* UPDATE_SYSTEM_TIME_UNIT
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 8 April 2011
-- Module     : timeunits-commons
-- Description: This procedure modifies system Time Unit and creates new correspondance
-- =============================================
-- Assumptions:The Time unit being added is existing in the system
--             The Time unit name is case sensitive
--             The time unit correspondances are always added with the small time unit being the primary and the bigger being the secondary.
--             The time unit correspondances in order of the primary time unit

-- Return : NA
-- =============================================
-- Parameters:-
-- IN Parameters

-- PI_TU_NAME                     VARCHAR2:- TU Name that needs to be updated
-- PI_FISCAL_OFFSET               NUMBER:- Fiscal Offset- 4,7,10
-- PI_FISCAL_CHANGE               NUMBER:- Is the fiscal year start changing
-- PI_FORMAT_CHANGE               NUMBER:- Is the fiscal display fromat changing
-- PI_FORMAT_TYPE                 NUMBER:-
-- =============================================
--Example

PKG_TIME_UNIT.UPDATE_SYSTEM_TIME_UNIT(PI_TU_NAME => 'Month',
PI_FISCAL_OFFSET=>4);
-- =============================================*/
/*procedure UPDATE_SYSTEM_TIME_UNIT(PI_TU_NAME       in VARCHAR2,
PI_FISCAL_OFFSET in NUMBER,
PI_FISCAL_CHANGE in number,
PI_FORMAT_CHANGE IN NUMBER,
PI_FORMAT_TYPE   in NUMBER);*/


/* GET_PERIOD_YEAR_RANGE_ID
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 20 April 2011
-- Module     : timeunits-commons
-- Description: Public function that returns the period range id for a specific year of TU.
-- =============================================
-- Assumptions:NA

-- Return : Period_range ID(Number) if found else returns null
-- =============================================
-- Parameters:-
-- IN Parameters

-- PI_PERIOD_STRING                       NUMBER:- Period Name
-- PI_TU_ID                               NUMBER:- tu_id of the TU
-- PI_TU_YEAR_FORMAT                      NUMBER:- Display type for year format YYYY(1), FY_YY(2), PY_YY(3)
-- =============================================*/
FUNCTION GET_PERIOD_YEAR_RANGE_ID(PI_PERIOD_STRING  in VARCHAR2,
PI_TU_ID          in NUMBER,
PI_TU_YEAR_FORMAT in NUMBER)
RETURN NUMBER;


/* GET_PERIOD_RANGE_ID_WITHIN
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 23 May 2011
-- Module     : timeunits-commons
-- Description: Public function that returns collection of the period range id's falling in between the start and end period range ID's.
-- =============================================
-- Assumptions:NA

-- Return : COLTYPE_ID type
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tu_id                       NUMBER:- tu_id of the TU
-- pi_tupr_id_start               NUMBER:- Start tupr_id
-- pi_tupr_id_start               NUMBER:- End tupr_id
-- =============================================

declare
-- Non-scalar parameters require additional processing
result coltype_id;
begin
-- Call the function
result := commons_timeunits.get_period_range_id_within(pi_tu_id => 241,
pi_tupr_id_start => 262,
pi_tupr_id_end => 276);

for i in 1..result.count loop
dbms_output.put_line(result(i));
end loop;

end;

-- =============================================*/
function get_period_range_id_within(pi_tu_id        in NUMBER,
pi_tupr_id_start in NUMBER,
pi_tupr_id_end   in NUMBER)  return COLTYPE_ID deterministic;


/* GET_PERIOD_START_END_DATE
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 26 May 2011
-- Module     : timeunits-commons
-- Description: Public function that returns start and end dates of the tupr_id passed.
-- =============================================
-- Assumptions:NA

-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tupr_id                     NUMBER:- tupr_id for which start date and end date needs to be caculated

--OUT Parameter
-- po_start_date                  date:- start date for the tupr_id passed
-- po_end_date                    date:- end date for the tupr_id passed

-- =============================================
example

declare
po_end_date date;
po_start_date date;

begin
-- Call the procedure
commons_timeunits.get_period_start_end_date(pi_tupr_id => 461,
po_start_date => po_start_date,
po_end_date => po_end_date);
end;

-- =============================================*/
procedure get_period_start_end_date(pi_tupr_id    in NUMBER,
po_start_date OUT DATE,
po_end_date   OUT DATE);


/* GET_CORRESPONDENCE
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 1 june 2011
-- Module     : timeunits-commons
-- Description: Public procedure that returns collection of TUPR ID's that correspond to the tupr_id passed.
-- =============================================
-- Assumptions:NA

-- Return : COLTYPE_ID type
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_base_tupr_id                 NUMBER:- tupr_id for which correspondence is to be found
-- pi_base_tu_id                   NUMBER:- TU of tupr_id passed
-- pi_corr_tu_id                   NUMBER:- tu_id of the TU to which TU of tupr_id passed correspondaces
-- PI_START_YEAR                   NUMBER:- Start Year for the search
-- PI_END_YEAR                     NUMBER:- End Year for the search
-- po_error_code                   NUMBER:- 100 - The period does not have a corresponding period defined
--                                          200 - The year determined for the corresponding period is outside of the defined range of years in the system
--                                          300 - The year determined for the corresponding period has not had periods specified for the time unit of the corresponding period
--                                          400 - For the year determined for the corresponding period, the corresponding period does not have a start date defined
--                                          0 - For successful execution

-- Out Parameters

-- po_list_tupr_id                 NUMBER:- collection of type COLTYPE_ID containing the list of all correspondiong TUPR_ID'd

-- =============================================
Example:-
declare
-- Non-scalar parameters require additional processing
po_list_tupr_id coltype_id;
po_error_code   number;
begin
-- Call the procedure
COMMONS_TIMEUNITS.GET_CORRESPONDENCE(PI_BASE_TUPR_ID => 2039,
PI_BASE_TU_ID   => 2023,
PI_CORR_TU_ID   => 2028,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => po_error_code,
po_list_tupr_id => po_list_tupr_id);

dbms_output.put_line(po_error_code);

for i in 1 .. po_list_tupr_id.count loop
dbms_output.put_line(po_list_tupr_id(i));
end LOOP;
end;

-- =============================================*/
procedure get_Correspondence(pi_base_tupr_id in NUMBER,
pi_base_tu_id   in NUMBER,
pi_corr_tu_id   in NUMBER,
PI_START_YEAR   in NUMBER,
PI_END_YEAR     in NUMBER,
po_error_code   OUT NUMBER,
po_list_tupr_id OUT COLTYPE_ID);


/* GET_REVERSE_CORRESPONDENCE
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 1 june 2011
-- Module     : timeunits-commons
-- Description: Public procedure that returns collection of TUPR ID's that reverse correspond to the tupr_id passed.
-- =============================================
-- Assumptions:NA

-- Return : COLTYPE_ID type
-- =============================================

-- Parameters:-
-- IN Parameters

-- pi_corr_tupr_id                 NUMBER:- tupr_id for which reverse correspondence is to be found
-- pi_base_tu_id                   NUMBER:- tu_id of the TU which correspondace to TU of tupr_id passed
-- pi_corr_tu_id                   NUMBER:-  TU of tupr_id passed
-- PI_START_YEAR                   NUMBER:- Start Year for the search
-- PI_END_YEAR                     NUMBER:- End Year for the search
-- po_error_code                   NUMBER:- 100 - The period does not have a corresponding period defined
--                                          200 - The year determined for the corresponding period is outside of the defined range of years in the system
--                                          300 - The year determined for the corresponding period has not had periods specified for the time unit of the corresponding period
--                                          400 - For the year determined for the corresponding period, the corresponding period does not have a start date defined
--                                          0 - For successful execution

--Out Parameters
-- po_list_tupr_id                 NUMBER:- collection of type COLTYPE_ID containing the list of all reverse correspondiong TUPR_ID'd

-- =============================================
Exanmple:-
declare
-- Non-scalar parameters require additional processing
po_list_tupr_id coltype_id;
po_error_code   number;
begin
-- Call the procedure
commons_timeunits.get_reverse_correspondance(pi_corr_tupr_id => 2043,
PI_BASE_TU_ID   => 2023,
pi_corr_tu_id   => 2028,
pi_start_year   => 2010,
pi_end_year     => 2025,
po_error_code   => po_error_code,
po_list_tupr_id => po_list_tupr_id);
dbms_output.put_line(po_error_code);

for i in 1 .. po_list_tupr_id.count loop
dbms_output.put_line(po_list_tupr_id(i));
end LOOP;
end;

-- =============================================*/
procedure get_reverse_Correspondence(pi_corr_tupr_id in NUMBER,
pi_base_tu_id   in NUMBER,
pi_corr_tu_id   in NUMBER,
PI_START_YEAR   in NUMBER,
PI_END_YEAR     in NUMBER,
po_error_code   OUT NUMBER,
po_list_tupr_id OUT COLTYPE_ID);


/* GET_TUPR_CORRESPONDENCE
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 1 june 2011
-- Module     : timeunits-commons
-- Description: Public function that returns number 1 if the period/period range passed correspond to pi_corr_tupr_id  else 0
-- =============================================
-- Assumptions:NA

-- Return : number type
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_base_tupr_id_start         NUMBER:- Starting Base tupr_id
-- pi_corr_tupr_id_start         NUMBER:- Starting corr tupr_id
-- pi_base_tupr_id_end           NUMBER:- Ending base tupr_id
-- pi_corr_tupr_id_end           NUMBER:- Ending corr tupr_id
-- pi_corr_tu_id                 NUMBER:- Corr tu_id
-- pi_base_tu_id                 NUMBER:- Base tu_id
-- pi_type                       NUMBER:- 1-  pi_base_tupr_id_start corresponds to pi_corr_tupr_id_start
--                                        2-  Any one TUPR ID between pi_base_tupr_id_start and pi_base_tupr_id_end corresponds to pi_corr_tupr_id_start
--                                        3-  pi_base_tupr_id_start correspondance to any one of the tupr_id between pi_corr_tupr_id_start to pi_corr_tupr_id_end

-- =============================================
Example:-
declare

result number;

begin
-- Call the function
result := commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => TEST_PERF.effective_start_field,
pi_corr_tupr_id_start => 471,
pi_base_tupr_id_end   => null,
pi_corr_tupr_id_end   => null,
pi_type               => 1,
pi_corr_tu_id         => 465,
pi_base_tu_id         => 241) = 1);

dbms_output.put_line(result);
end;

-- =============================================*/
function get_tupr_Correspondence(pi_base_tupr_id_start in NUMBER,
pi_corr_tupr_id_start in NUMBER,
pi_base_tupr_id_end   in NUMBER default null,
pi_corr_tupr_id_end   in NUMBER default null,
pi_base_tu_id         in NUMBER,
pi_corr_tu_id         in NUMBER,
pi_type               NUMBER -- 1 = single period correspondence, 2 = single period to a range of period correspondence---3 range of period to single period correspondence
) return NUMBER deterministic;


/* GET_TUPR_REV_CORRESPONDENCE
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 1 june 2011
-- Module     : timeunits-commons
-- Description: Public function that returns number 1 if the pi_corr_tupr_id period/period range passed reverse correspond to pi_corr_tupr_id  else 0
-- =============================================
-- Assumptions:NA

-- Return : number type
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_base_tupr_id_start         NUMBER:- Starting Base tupr_id
-- pi_corr_tupr_id_start         NUMBER:- Starting corr tupr_id
-- pi_base_tupr_id_end           NUMBER:- Ending base tupr_id
-- pi_corr_tupr_id_end           NUMBER:- Ending corr tupr_id
-- pi_corr_tu_id                 NUMBER:- Corr tu_id
-- pi_base_tu_id                 NUMBER:- Base tu_id
-- pi_type                       NUMBER:- 1-  pi_corr_tupr_id_start reverse corresponds to pi_base_tupr_id_start
--                                        2-  Any one TUPR ID between pi_corr_tupr_id_start and pi_corr_tupr_id_end reverse corresponds to pi_base_tupr_id_start
--                                        3-  pi_corr_tupr_id_start reverse correspondance to any one of the tupr_id between pi_base_tupr_id_start to pi_base_tupr_id_end

-- =============================================
Example:-
declare

result number;

begin
-- Call the function
result:=commons_timeunits.get_tupr_correspondence(pi_base_tupr_id_start => 471,
pi_corr_tupr_id_start => TEST_PERF.effective_start_field,
pi_base_tupr_id_end   => null,
pi_corr_tupr_id_end   => null,
pi_type               => 1,
pi_corr_tu_id         => 241,
pi_base_tu_id         => 465) = 1)

dbms_output.put_line(result);
end;

-- =============================================*/
function get_tupr_rev_Correspondence(pi_base_tupr_id_start in NUMBER,
pi_corr_tupr_id_start in NUMBER,
pi_base_tupr_id_end in NUMBER default null,
pi_corr_tupr_id_end in NUMBER default null,
pi_base_tu_id  in NUMBER,
pi_corr_tu_id  in NUMBER,
pi_type  NUMBER -- 1 = single period correspondence, 2 = single period to a range of period correspondence
) return NUMBER;


/* GET_PRIOR_PERIOD
-- =============================================*/
procedure get_prior_period(pi_tu_id     in NUMBER,
pi_tupr_id    in NUMBER,
pi_offset     in NUMBER,
pi_start_year in NUMBER,
pi_end_year   in NUMBER,
po_error_code OUT NUMBER,
po_tupr_id    OUT NUMBER) ;


/* GET_NTH_PRIOR_PERIOD
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 30 Dec 2011
-- Module     : timeunits-commons
-- Description: Procedure to return Period range id 'n' periods prior to a given period range id.
-- =============================================
-- Assumptions:NA
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tu_id         NUMBER:- Time Unit Id
-- pi_tupr_id       NUMBER:- Reference Period range
-- pi_offset        NUMBER:- No of periods to move back
-- pi_start_year    NUMBER:- Start year for the system
-- pi_end_year      NUMBER:- End year for the system

--Out Parameters
-- po_error_code    NUMBER:- 500 implies success, 200 implies the year is out of system range, 300 implies the TU doesn't have the Year defined for it.
-- po_tupr_id       NUMBER:- Resulting Period Id in case of success

-- =============================================
Example:-
declare

      v_tupr_id          number;
      v_tu_id            number;
      v_error_code       number;
      v_tupr_id_res      number;
      v_tupr_id_expected number;


begin
  select tu_id into v_tu_id from time_units where TU_NAME = 'Semester';
  select tupr_id
      into v_tupr_id
      from tu_periods_range
     where TUPR_PERIOD_RANGE_NAME = 'Semester 1 2015';
-- Call the function
commons_timeunits.Get_nth_prior_period(pi_tu_id      => v_tu_id,
                                             pi_tupr_id    => v_tupr_id,
                                             pi_offset     => 1,
                                             pi_start_year => 2010,
                                             pi_end_year   => 2025,
                                             po_error_code => v_error_code,
                                             po_tupr_id    => v_tupr_id_res);

dbms_output.put_line(v_tupr_id_res);
dbms_output.put_line(v_error_code);
end;

-- =============================================*/
procedure Get_nth_prior_period(pi_tu_id     in number,
pi_tupr_id    in number,
pi_offset     in number,
pi_start_year in NUMBER,
pi_end_year   in NUMBER,
po_error_code OUT number,
po_tupr_id    OUT number) ;


/* GET_N_PRIOR_PERIODS
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 30 Dec 2011
-- Module     : timeunits-commons
-- Description: Procedure to return list of 'n' Period range id prior to a given period range id.
-- =============================================
-- Assumptions:NA
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tu_id         NUMBER:- Time Unit Id
-- pi_tupr_id       NUMBER:- Reference Period range
-- pi_offset        NUMBER:- No of periods to move back

--Out Parameters
-- po_tupr_id       coltype_id:- Resulting Period Id in case of success

-- =============================================
Example:-


declare

  v_tupr_id   number;
  v_tu_id     number;
  check_this2 COLTYPE_ID;


begin

  select tu_id into v_tu_id from time_units where TU_NAME = 'Semester';

  select tupr_id
    into v_tupr_id
    from tu_periods_range
   where TUPR_PERIOD_RANGE_NAME = 'Semester 1 2015';
  -- Call the function

  commons_timeunits.Get_n_prior_periods(pi_tu_id   => v_tu_id,
                                        pi_tupr_id => v_tupr_id,
                                        pi_offset  => 2,
                                        po_tupr_id => check_this2);

  for i in 1 .. check_this2.count loop

    dbms_output.put_line(check_this2(i));
  end loop;

end;

-- =============================================*/
/*procedure Get_n_prior_periods(pi_tu_id      in number,
                               pi_tupr_id    in number,
                               pi_offset     in number,
                               po_tupr_id    OUT coltype_id);*/


/* GET_RANGE_OF_PERIODS_BOUNDS
-- =============================================
-- Author     : Dumitriu Cosmin
-- Create date: 14.03.2012
-- Module     : timeunits-commons
-- Description: Procedure to return the bounds (start and end periods) of a range of periods
        based on a date that falls within the last period and the period that is N periods ago from the last.
-- =============================================
Example:

DECLARE
  v_fst_tupr_id     NUMBER;
  v_fst_start_date    DATE;
  v_fst_end_date      DATE;
  v_fst_year        NUMBER;
  v_fst_period_number   NUMBER;
  v_lst_tupr_id     NUMBER;
  v_lst_start_date    DATE;
  v_lst_end_date      DATE;
  v_lst_year        NUMBER;
  v_lst_period_number   NUMBER;
BEGIN
  --get first and last month for the range: 3 quarters ago <> current quarter (09-03-2012)
  GET_RANGE_OF_PERIODS_BOUNDS
  (  pi_large_base_tu_id  => 465 --quarter
    ,pi_small_corr_tu_id  => 241 --month
    ,pi_date        => TO_DATE('09-03-2012','DD-MM-YYYY')
    ,pi_range_size      => 3
    ,po_fst_tupr_id     => v_fst_tupr_id
    ,po_fst_start_date    => v_fst_start_date
    ,po_fst_end_date    => v_fst_end_date
    ,po_fst_year      => v_fst_year
    ,po_fst_period_number => v_fst_period_number
    ,po_lst_tupr_id     => v_lst_tupr_id
    ,po_lst_start_date    => v_lst_start_date
    ,po_lst_end_date    => v_lst_end_date
    ,po_lst_year      => v_lst_year
    ,po_lst_period_number => v_lst_period_number
  );

  DBMS_OUTPUT.PUT_LINE(v_fst_tupr_id);
  DBMS_OUTPUT.PUT_LINE(v_fst_start_date);
  DBMS_OUTPUT.PUT_LINE(v_fst_end_date);
  DBMS_OUTPUT.PUT_LINE(v_fst_year);
  DBMS_OUTPUT.PUT_LINE(v_fst_period_number);
  DBMS_OUTPUT.PUT_LINE('---');
  DBMS_OUTPUT.PUT_LINE(v_lst_tupr_id);
  DBMS_OUTPUT.PUT_LINE(v_lst_start_date);
  DBMS_OUTPUT.PUT_LINE(v_lst_end_date);
  DBMS_OUTPUT.PUT_LINE(v_lst_year);
  DBMS_OUTPUT.PUT_LINE(v_lst_period_number);
END;
-- =============================================*/
PROCEDURE GET_RANGE_OF_PERIODS_BOUNDS
(  pi_large_base_tu_id  NUMBER
  ,pi_small_corr_tu_id  NUMBER
  ,pi_date        DATE
  ,pi_range_size      NUMBER
  ,po_fst_tupr_id     OUT NUMBER
  ,po_fst_start_date    OUT DATE
  ,po_fst_end_date    OUT DATE
  ,po_fst_year      OUT NUMBER
  ,po_fst_period_number OUT NUMBER
  ,po_lst_tupr_id     OUT NUMBER
  ,po_lst_start_date    OUT DATE
  ,po_lst_end_date    OUT DATE
  ,po_lst_year      OUT NUMBER
  ,po_lst_period_number OUT NUMBER
);


/* Get_nth_post_period
-- =============================================
-- Author     : Maxim Rohit
-- Create date:  18 Apr 2012
-- Module     : timeunits-commons
-- Description: function to return nth Period range id prior to a given period range id.
-- =============================================
-- Assumptions:NA
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tupr_id       NUMBER:- Reference Period range
-- pi_offset        NUMBER:- No of periods to move forward
-- pi_start_year    NUMBER:- Start year of the application
-- pi_end_year      NUMBER:- End year of the application
              po_error_code OUT number,

-- return number:- Resulting Period Id in case of success else null

-- =============================================
Example:-

select commons_dataimport.Get_nth_prior_period(pi_tu_id      => 3450,
                                               pi_tupr_id    => 3454,
                                               pi_offset     => 1,
                                               pi_start_year => 2010,
                                               pi_end_year   => 2025,)

  from dual;

*/



function Get_nth_prior_period(pi_tu_id      in NUMBER,
                              pi_tupr_id    in NUMBER,
                              pi_offset     in NUMBER,
                              pi_start_year in NUMBER,
                              pi_end_year   in NUMBER) return number;


/* Get_nth_post_period
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 20 Jan 2012
-- Module     : timeunits-commons
-- Description: Procedure to return n Period range id prior to a given period range id.
-- =============================================
-- Assumptions:NA
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tu_id`        NUMBER:- Reference TU ID
-- pi_tupr_id       NUMBER:- Reference Period range
-- pi_offset        NUMBER:- No of periods to move forward

              po_error_code OUT number,

--Out Parameters
-- po_tupr_id       coltype_id:- Resulting list of Period Id

-- =============================================
Example:-

declare

  v_tupr_id     number;
  v_tu_id       number;
  v_error_code  number;
  v_tupr_id_res coltype_id;

begin
  -- Execute test code

  select tupr_id, tupr_tu_id
    into v_tupr_id, v_tu_id
    from tu_periods_range
   where TUPR_PERIOD_RANGE_NAME = 'Quarter 2 2025';

  commons_timeunits.Get_n_prior_periods(pi_tu_id      => v_tu_id,
                                        pi_tupr_id    => v_tupr_id,
                                        pi_offset     => 1,
                                        po_tupr_id    => v_tupr_id_res);

end;

*/

procedure Get_n_prior_periods(pi_tu_id      in NUMBER,
              pi_tupr_id    in NUMBER,
              pi_offset     in NUMBER,
              po_tupr_id    OUT coltype_id) ;



/* Get_nth_post_period
-- =============================================
-- Author     : Maxim Rohit
-- Create date: 15 Feb 2013
-- Module     : timeunits-commons
-- Description: Procedure to return nth Period range id post to a given period range id.
-- =============================================
-- Assumptions:NA
-- =============================================
-- Parameters:-
-- IN Parameters

-- pi_tupr_id       NUMBER:- Reference Period range
-- pi_offset        NUMBER:- No of periods to move forward
-- pi_start_year    NUMBER:- Start year of the application
-- pi_end_year      NUMBER:- End year of the application
              po_error_code OUT number,

--Out Parameters
-- po_tupr_id       NUMBER:- Resulting Period Id in case of success
-- po_error_code    NUMBER:- Standard TU erroe code
-- =============================================
Example:-

declare

  v_tupr_id     number;
  v_tu_id       number;
  v_error_code  number;
  v_tupr_id_res number;

begin
  -- Execute test code

  select tupr_id, tupr_tu_id
    into v_tupr_id, v_tu_id
    from tu_periods_range
   where TUPR_PERIOD_RANGE_NAME = 'Quarter 2 2025';

  commons_timeunits.Get_nth_post_period(pi_tupr_id    => v_tupr_id,
                                        pi_offset     => 1,
                                        pi_start_year => 2010,
                                        pi_end_year   => 2025,
                                        po_error_code => v_error_code,
                                        po_tupr_id    => v_tupr_id_res);

end;

*/


procedure Get_nth_post_period(pi_tupr_id    in NUMBER,
              pi_offset     in NUMBER,
              pi_start_year in NUMBER,
              pi_end_year   in NUMBER,
              po_error_code OUT NUMBER,
              po_tupr_id    OUT NUMBER);

/* GET_CORRESPONDENCE_BULK
-- =============================================
-- Author              : Sagar Thorat
-- Create date         : 12th July 2012
-- Module              : timeunits-commons
-- Description         : Public procedure that returns resultset of input base TUPR IDs of base TU,
--                      the TUPR IDs of corresponding TU and error code depicting the correspondence
--                      between base and corresponding TU is valid or not.
-- =============================================
-- Assumptions: Valid TUPR IDs of base Time Unit, valid base TU and corresponding TU

-- Return : sys_refcursor
-- =============================================

-- Parameters:-
-- IN Parameters

-- pi_base_tupr_ids                COLTYPE_ID :- tupr_ids of base TU for which correspondence is to be found
-- pi_base_tu_id                   NUMBER     :- tu_id of the base Time Unit
-- pi_corr_tu_id                   NUMBER     :- tu_id of corresponding Time Unit


--Out Parameters
-- po_resultset                    sys_refcursor:- resultset of
--                                                 input base TUPR IDs of base TU,
--                                                 the TUPR IDs of corresponding TU and
--                                                 following error code depicting the correspondence
--                                                 between base and corresponding TU is valid or not:
--                                                 100 - The period does not have a corresponding period defined
--                                                 200 - The year determined for the corresponding period is outside of the defined range of years in the system
--                                                 300 - The year determined for the corresponding period has not had periods specified for the time unit of the corresponding period
--                                                 400 - For the year determined for the corresponding period, the corresponding period does not have a start date defined
--                                                 0   - For successful execution

-- =============================================
Exanmple:-

variable x refcursor;
begin
  -- Call the procedure
  commons_timeunits.get_correspondence_bulk(pi_base_tupr_ids => coltype_id(94936, 94938, 94939),
                                            pi_base_tu_id => 94921,
                                            pi_corr_tu_id => 94926,
                                            po_resultset => :x);
end;

print x

-- =============================================*/

PROCEDURE GET_CORRESPONDENCE_BULK(pi_base_tupr_ids in COLTYPE_ID,
                                  pi_base_tu_id    in NUMBER,
                                  pi_corr_tu_id    in NUMBER,
                                  po_resultset    out sys_refcursor) ;


FUNCTION GET_CORR_PERIOD_FROM_SMALL_PER
(  pi_small_period_id   IN NUMBER
  ,pi_large_corr_tu_id  IN NUMBER
) RETURN NUMBER;


FUNCTION GET_LAST_PERIOD_FROM_CORR_PER
(  pi_large_corr_period_id  IN NUMBER
  ,pi_small_tu_id       IN NUMBER
) RETURN NUMBER DETERMINISTIC;

FUNCTION GET_FIRST_PERIOD_FROM_CORR_PER
(  pi_large_corr_period_id  IN NUMBER
  ,pi_small_tu_id       IN NUMBER
) RETURN NUMBER DETERMINISTIC;
--
   /*
    -- Author     : Kristo Robert
    -- Create date: 20130821
    -- Description: FUNCTION returns time unit name for a specific time unit id
    -- Parameters:
    -- IN Parameters

    -- pin_Time_Unit_id          time unit id for which time unit name is required
    Example:-
    declare
       v_result varchar2(36);

    begin
       -- Call the function
       v_result := commons_timeunits.GET_TIME_UNIT_NAME_FROM_ID(pin_Time_Unit_Id=>241);
       dbms_output.put_line(v_result);
    end;
  */
FUNCTION GET_TIME_UNIT_NAME_FROM_ID(pin_time_unit_id in NUMBER)
RETURN VARCHAR2;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130821
    -- Description: FUNCTION returns period name for a specific period id
    -- Parameters:
    -- IN Parameters

    -- pin_period_id          period id for which period name is required
    Example:-
    declare
       v_result varchar2(36);

    begin
       -- Call the function
       v_result := commons_timeunits.GET_PERIOD_NAME_FROM_ID(pin_period_id => 241);
       dbms_output.put_line(v_result);
    end;
  */
FUNCTION GET_PERIOD_NAME_FROM_ID(pin_period_id in NUMBER)
RETURN VARCHAR2;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130821
    -- Description: FUNCTION returns period name for a specific period id
    -- Parameters:
    -- IN Parameters

    -- pin_period_id          period id for which period name is required
    Example:-
    declare
       v_result varchar2(36);

    begin
       -- Call the function
       v_result := commons_timeunits.GET_TIME_UNIT_NAME_FROM_PERIOD(pin_period_Id=>241);
       dbms_output.put_line(v_result);
    end;
  */
FUNCTION GET_TIME_UNIT_NAME_FROM_PERIOD(pin_period_id in NUMBER)
RETURN VARCHAR2;


function get_period_start_date (PI_TUPR_ID number) return date;
function get_period_end_date (PI_TUPR_ID number) return date;
-- *******************************    PUBLIC PROCEDURES END       *******************************

END commons_timeunits;
/
