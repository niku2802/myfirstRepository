CREATE PACKAGE BODY COMPENSATION_PROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : COMPENSATION
  -- Module   : COMPENSATION-PROCESSING
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************

  TYPE RTYPE_TABLE_LIST IS RECORD
    (    TABLE_NAME     VARCHAR2(30)
        ,FROM_CLAUSE   CLOB
        ,WHERE_CLAUSE  CLOB
        ,TABLE_TYPE    NUMERIC(2)
        ,INPUT_NUMBER  NUMERIC(10));

  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

  PROCEDURE ALTER_SESSION_NLS_BINARY
  IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''BINARY''';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''BINARY''';
  END ALTER_SESSION_NLS_BINARY;


  PROCEDURE ALTER_SESSION_PROJ_NLS_SETTING
  IS
    V_NLS_SORT   VARCHAR2 (160 CHAR);
    V_NLS_COMP   VARCHAR2 (160 CHAR);
  BEGIN
    SELECT NVL (MAX ( VALUE), 'LINGUISTIC')
      INTO V_NLS_COMP
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_COMP';

    SELECT NVL (MAX ( VALUE), 'BINARY_CI')
      INTO V_NLS_SORT
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_SORT';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''' || V_NLS_COMP || '''';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''' || V_NLS_SORT || '''';
  END ALTER_SESSION_PROJ_NLS_SETTING;

  -- TODO: this should be removed after moving the below functions to commons_tables
  function NVL_CHECK(v_col_name varchar2, v_data_type number)
  return varchar2
  is
      nvl_value varchar2(4000 );
  begin

                            if v_data_type in (1,4) THEN
                                 nvl_value :=  ' NVL(UPPER(a.' || v_COL_NAME ||
                                   '), CHR(0))= NVL(UPPER(b.' || v_COL_NAME ||
                                   '), CHR(0)) ';

                                --end of addition by pramod
                            elsif v_data_type in (2,6,8) THEN
                                   nvl_value :=  ' NVL(a.' || v_COL_NAME || ', 1E38)= NVL(b.' || v_COL_NAME|| ', 1E38) ';

                                  elsif v_data_type in (3) THEN
                                    nvl_value := ' NVL(a.' || v_COL_NAME ||
                                   ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD''))= NVL(b.' || v_COL_NAME|| ', TO_DATE(''1800-01-01'', ''YYYY-MM-DD'')) ';

                                  elsif v_data_type =(5) THEN
                                   nvl_value :=  ' NVL(a.' || v_COL_NAME ||
                                   ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD''))= NVL(b.' || v_COL_NAME|| ', TO_TIMESTAMP(''1800-01-01'', ''YYYY-MM-DD'')) ';

                                  ELSE
                                    nvl_value := '((a.' || v_COL_NAME || '= b.' || v_COL_NAME||') or (a.' || v_COL_NAME || ' IS NULL AND b.' ||
                                   v_COL_NAME || ' IS NULL ) )';
                                END if;

                                return nvl_value;
  end NVL_CHECK;

  -- TODO: this should be moved to COMMONS_TABLES
  -- Procedure similar to COMMON_UNIQUE_CHECK (Created in COMMONS_TABLE, checks unique at record level), added in order to check unique over distinct LOOKUP CURVES
  -- Ex: when removing one varyby column, the already defined curves might overlap the valiues, therefore the values from differen curves will be combined for only one curve.
  procedure LOOKUP_UNIQUE_CHECK (PIN_TABLE           IN  VARCHAR2,
                                 PIN_NEW_KEY_FIELDS  IN  VARCHAR2,
                                 PIN_OLD_KEY_FIELDS  IN  VARCHAR2,
                                 PIN_TABLE_COUNT     IN  NUMBER DEFAULT NULL,
                                 POUT_UNIQUE_CHK_RES OUT NUMBER) IS

    v_sql              CLOB;
    v_input_sql        CLOB;
    v_cardinality_hint VARCHAR2(2000 char);
    v_duplicate_count  NUMBER(10);
    v_new_key_fields   VARCHAR2(32767);
    v_stamp            VARCHAR2(250 char):= 'COMPENSATION_PROCESSING.LOOKUP_UNIQUE_CHECK - OUTPUT'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  begin

    v_cardinality_hint := case
                            when PIN_TABLE_COUNT is not null
                              then '/*+  CARDINALITY( '|| PIN_TABLE ||' '||PIN_TABLE_COUNT||') */ '
                              else null
                          end;

    v_input_sql        := case
                            when PIN_OLD_KEY_FIELDS is not null
                              then '(SELECT ' || v_cardinality_hint || ' DISTINCT '|| PIN_OLD_KEY_FIELDS || ' FROM ' || PIN_TABLE || ')'
                              else PIN_TABLE
                          end;

    v_new_key_fields := commons_tables.UPPER_VARCHAR2_COL_LIST(PI_TABLE_NAME => PIN_TABLE,
                                                PI_COL_LIST   => PIN_NEW_KEY_FIELDS);

    v_sql := 'select count(*) from dual where exists( select '
                                                        || v_cardinality_hint
                                                        || ' 1 from '
                                                        || v_input_sql
                                                        || ' GROUP BY '
                                                        || v_new_key_fields
                                                        || ' having count(*)>1 )';
    --dbms_output.put_line(v_sql);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(v_sql),',v_sql  => <value>', v_stamp);

    EXECUTE IMMEDIATE v_sql INTO v_duplicate_count;

    IF v_duplicate_count = 0 THEN
      POUT_UNIQUE_CHK_RES := 1;
    ELSE
      POUT_UNIQUE_CHK_RES := 0;
    END IF;

  end LOOKUP_UNIQUE_CHECK;

  -- TODO: this should be moved to COMMONS_TABLES
  -- Procedure similar to COMMON_OVERLAP_CHECK (Created in COMMONS_TABLE, checks overlap at record level), added in order to check overlap over distinct LOOKUP CURVES
  -- Ex: when removing one varyby column, the already defined curves might overlap.
  procedure LOOKUP_OVERLAP_CHECK(PI_TABLE          in varchar2,
                 PI_TABLE_CLOB      in varchar2,
                 PI_NEW_KEY_FIELDS  in clob,
                 PI_OLD_KEY_FIELDS  in clob,
                 PI_EFFECTIVE_START in varchar2,
                 PI_EFFECTIVE_END   in varchar2,
                 PI_IS_PERIOD       in number,
                 PI_ID_COLUMN       in varchar2,
                 PO_OVERLAP_CHK_RES out number,
                 PI_INPUT_COUNT     in number default null) is

  V_KEY_COLS       clob := PI_NEW_KEY_FIELDS || ',';
  V_JOIN_CONDITION clob := '';
  V_FIELDS         varchar2(30) := '';
  V_OVERLAP_STR    clob := '';
  V_OVERLAP_RESULT number;
  V_COL_NAME       varchar2(30 char);
  V_IS_NULLABLE    number(1);
  CV_SQL           sys_refcursor;
  V_KEY_FIELDS     clob := '''' || replace(PI_NEW_KEY_FIELDS, ',', ''',''') || '''';
  V_TABLE          varchar2(4000);
  --Checking the Columns data type
  V_DATA_TYPE     number;
  V_FLD_DATA_TYPE number;
  V_CHECK         number;
  v_cardinality_hint VARCHAR2(2000 char);
  v_input_sql        CLOB;
  v_with_clause      clob;
  begin

    declare
      v_stamp varchar2(2000 char):= 'COMPENSATION_PROCESSING.LOOKUP_OVERLAP_CHECK - '||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    -- <<0.>> Log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_TABLE),           ',pi_TABLE           => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_TABLE_CLOB),      ',pi_TABLE_CLOB      => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(PI_NEW_KEY_FIELDS),      ',PI_NEW_KEY_FIELDS  => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(PI_OLD_KEY_FIELDS),      ',PI_OLD_KEY_FIELDS  => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PI_effective_start), ',PI_effective_start => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PI_effective_end),   ',PI_effective_end   => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(PI_is_Period),         ',PI_is_Period       => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PI_ID_COLUMN),       ',PI_ID_COLUMN       => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(PI_INPUT_COUNT),       ',PI_INPUT_COUNT     => <value>', v_stamp);
    END;

    if (PI_TABLE_CLOB is null) then
      V_TABLE := PI_TABLE;
    else
      V_TABLE := PI_TABLE_CLOB;
    end if;

    v_cardinality_hint := case
                when PI_INPUT_COUNT is not null
                  then '/*+  CARDINALITY( '|| V_TABLE ||' '||PI_INPUT_COUNT||') */ '
                  else null

                end;

    v_with_clause := case
                           when PI_OLD_KEY_FIELDS is not null
                             then 'WITH DISTINCT_LK_CURVES as (SELECT '|| PI_OLD_KEY_FIELDS  || ','
                                                                       || PI_EFFECTIVE_START || ','
                                                                       || PI_EFFECTIVE_END   ||
                                                                       ', ROWNUM as ROW_IDENTIFIER FROM
                                                                           (SELECT ' || v_cardinality_hint || ' DISTINCT '|| PI_OLD_KEY_FIELDS  || ','
                                                                            || PI_EFFECTIVE_START || ','
                                                                            || PI_EFFECTIVE_END
                                                                            || ' FROM '
                                                                            || V_TABLE || '))'
                             else null
                         end;
    v_input_sql := case
                     when PI_OLD_KEY_FIELDS is not null
                       then 'DISTINCT_LK_CURVES'
                       else V_TABLE
                   end;

    if (PI_NEW_KEY_FIELDS is null)
        then
      V_JOIN_CONDITION := null;
    else
      V_JOIN_CONDITION := ' and ';

            -- Create the string v_JOIN_CONDITION (logic to parse comma separated PI_NEW_KEY_FIELDS)
            open CV_SQL for 'select t.COLUMN_NAME  COLUMN_NAME, t.IS_NULLABLE IS_NULLABLE, t.DATA_TYPE DATA_TYPE
                              from table(commons_tables.GET_COLUMN_CHARACTERISTICS(pi_table =>''' || PI_TABLE || ''')) t
                              where t.COLUMN_NAME in (' || V_KEY_FIELDS || ')';
            loop
              fetch CV_SQL
                into V_COL_NAME, V_IS_NULLABLE, V_DATA_TYPE;
              exit when CV_SQL%notfound;

                  V_JOIN_CONDITION := V_JOIN_CONDITION || case
                                        when V_IS_NULLABLE = 0 then --required column
                                         case
                                           when V_DATA_TYPE in (1, 4) then --note or chracter
                                            ' UPPER(a.' || V_COL_NAME || ') = UPPER(b.' || V_COL_NAME || ')'
                                           else
                                            '  a.' || V_COL_NAME || ' = b.' || V_COL_NAME
                                         end
                                        else NVL_CHECK(V_COL_NAME, V_DATA_TYPE)
                                      end || ' and ';
            end loop;

            CLOSE CV_SQL;

      V_JOIN_CONDITION := SUBSTR(V_JOIN_CONDITION, 1,LENGTH(V_JOIN_CONDITION) - 4);
    end if;

    -- Overlap and date check
    if (PI_IS_PERIOD = 0) then
      V_OVERLAP_STR := v_with_clause ||chr(10)||chr(32) ||
                        'SELECT COUNT(*) FROM DUAL WHERE EXISTS(
                            select ' || '/*+ USE_HASH(a,b) ' || case when PI_INPUT_COUNT is not null then ' CARDINALITY(a ' || PI_INPUT_COUNT || ') CARDINALITY(b ' || PI_INPUT_COUNT || ') ' end  || ' */ ' || ' a.*
                            from '|| v_input_sql ||' a,
                                 '|| v_input_sql ||' b
                            where (((nvl(a.' || PI_EFFECTIVE_START || ', to_date(''01/01/0001'', ''dd/mm/yyyy'')) between nvl(b.' || PI_EFFECTIVE_START ||', to_date(''01/01/0001'', ''dd/mm/yyyy'')) and nvl(b.' || PI_EFFECTIVE_END || ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) or
                                 nvl(a.' || PI_EFFECTIVE_END   || ', to_date(''31/12/9999'', ''dd/mm/yyyy'')) between nvl(b.' || PI_EFFECTIVE_START ||', to_date(''01/01/0001'', ''dd/mm/yyyy'')) and nvl(b.' || PI_EFFECTIVE_END || ', to_date(''31/12/9999'', ''dd/mm/yyyy''))) and '
                                || ' a.' || PI_ID_COLUMN || ' <> b.' || PI_ID_COLUMN ||')  )  ' || V_JOIN_CONDITION || ')';

    elsif (PI_IS_PERIOD = 1) then

      V_OVERLAP_STR := v_with_clause ||chr(10)||chr(32) ||
                  'SELECT  COUNT(*)  FROM DUAL WHERE EXISTS(
                      select ' ||'/*+ USE_HASH(a,b) ' || case when PI_INPUT_COUNT is not null then ' CARDINALITY(a ' || PI_INPUT_COUNT || ') CARDINALITY(b ' || PI_INPUT_COUNT || ') ' end || ' */ ' || '  a.*
                      from ' || v_input_sql ||' a,
                           ' || v_input_sql ||' b,
                           tu_periods_range a_tupr_start,
                           tu_periods_range a_tupr_end,
                           tu_periods_range b_tupr_start,
                           tu_periods_range b_tupr_end
                     where (((nvl(a_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy'')) between nvl(b_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy'')) and nvl(b_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy''))
                      or    nvl(a_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy''))     between nvl(b_tupr_start.tupr_start_date,to_date(''01/01/0001'', ''dd/mm/yyyy'')) and nvl(b_tupr_end.tupr_end_date,to_date(''31/12/9999'', ''dd/mm/yyyy'')))
                      and
                         a.' || PI_ID_COLUMN || ' <> b.' || PI_ID_COLUMN || ') and
                         a.' || PI_EFFECTIVE_START || ' = a_tupr_start.tupr_id(+) and
                         a.' || PI_EFFECTIVE_END   || ' = a_tupr_end.tupr_id(+) and
                         b.' || PI_EFFECTIVE_START || ' = b_tupr_start.tupr_id(+) and
                         b.' || PI_EFFECTIVE_END   || ' = b_tupr_end.tupr_id(+) )
                         ' || V_JOIN_CONDITION || ')';
    end if;

    declare
      V_STAMP varchar2(2000 char) := 'COMPENSATION_PROCESSING.LOOKUP_OVERLAP_CHECK - output - ' || TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- <<0.>> Log the output parameters
    begin
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PO_OVERLAP_CHK_RES),',po_OVERLAP_CHK_RES => <value>', V_STAMP);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,ANYDATA.CONVERTCLOB(V_OVERLAP_STR),',v_OVERLAP_STR => <value>',V_STAMP);
    end;

    execute immediate V_OVERLAP_STR into V_OVERLAP_RESULT;

    -- Overlap check
    if V_OVERLAP_RESULT = 1 then
    PO_OVERLAP_CHK_RES := 0;
    else
    PO_OVERLAP_CHK_RES := 1;
    end if;

  end LOOKUP_OVERLAP_CHECK;

   -- ############################# STEP_LOOKUP START #############################
  FUNCTION STEP_LOOKUP(pin_InputColumns        VARCHAR2,
                        pin_InputColumnsAlias   VARCHAR2,
                        pin_InputFrom           VARCHAR2,
                        pin_InputLookupColumn   VARCHAR2,
                        pin_LookupTable         VARCHAR2,
                        pin_LowerValueOption    NUMBER,
                        pin_HigherValueOption   NUMBER,
                        pin_RosterFrom          varchar2,
                        pin_RosterJoinClause    varchar2,
                        pin_LookupJoinClause    varchar2,
                        pin_varyByFields        varchar2,
                        pin_comp_filter         varchar2
                        )
  RETURN CLOB
  IS
    RETURN_SELECT_SQL       CLOB;
    RETURN_FROM_SQL         VARCHAR2(32767);
    INPUT_SELECT_SQL        VARCHAR2(32767);
    ROSTER_SELECT_SQL       VARCHAR2(32767);
    LOOKUP_SELECT_SQL       VARCHAR2(32767);
    MIN_MAX_SELECT_SQL      VARCHAR2(32767);
    INPUT_COLUMNS           VARCHAR2(32767);
    INPUT_LOOKUP_COLUMN     VARCHAR2(32767);
    PARTITION_BY_CLAUSE     VARCHAR2(32767);
    v_stamp                 VARCHAR2(250);

  BEGIN

    v_stamp := 'COMPENSATION_PROCESSING.STEP_LOOKUP - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- <<0.>> Log the input parameters
    BEGIN
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLUMNS),          ',PIN_INPUTCOLUMNS => <value>'      , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLUMNSALIAS),     ',PIN_INPUTCOLUMNSALIAS => <value>' , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTFROM),             ',PIN_INPUTFROM => <value>'         , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTLOOKUPCOLUMN),     ',PIN_INPUTLOOKUPCOLUMN => <value>' , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LOOKUPTABLE),           ',PIN_LOOKUPTABLE => <value>'       , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LOWERVALUEOPTION),        ',PIN_LOWERVALUEOPTION => <value>'  , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_HIGHERVALUEOPTION),       ',PIN_HIGHERVALUEOPTION => <value>' , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_RosterFrom),            ',pin_RosterFrom => <value>'        , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_RosterJoinClause),      ',pin_RosterJoinClause => <value>'  , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupJoinClause),      ',pin_LookupJoinClause => <value>'  , v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_varyByFields),          ',pin_varyByFields => <value>'      , v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_comp_filter),          ',pin_comp_filter => <value>'      , v_stamp);
   END;

    INPUT_COLUMNS        := pin_InputColumns;
    INPUT_LOOKUP_COLUMN  := pin_InputLookupColumn;
    PARTITION_BY_CLAUSE  := case when pin_varyByFields is not null then 'PARTITION BY ' || pin_varyByFields  else null end;

    -- If called from UI
    IF INPUT_LOOKUP_COLUMN IS NULL THEN
       INPUT_LOOKUP_COLUMN :=  pin_InputColumnsAlias;
    ELSE
       INPUT_COLUMNS := INPUT_COLUMNS || ',' || INPUT_LOOKUP_COLUMN || ' LOOKUP_COLUMN';
    END IF;

    INPUT_SELECT_SQL  := '(SELECT ' || INPUT_COLUMNS || ' FROM ' || pin_InputFrom || ') TAB ';
    ROSTER_SELECT_SQL  := case when pin_RosterFrom is not null then pin_RosterFrom || ' INNER JOIN ' else 'FROM' end;

    LOOKUP_SELECT_SQL := '(SELECT ' ||
                                  case when pin_varyByFields is not null then pin_varyByFields || ','  else null end || '
                                  LAG(LOOKUP_VALUE,1,LOOKUP_VALUE) OVER ('|| PARTITION_BY_CLAUSE || ' ORDER BY LOOKUP_VALUE) AS LOW_LOOKUP_VALUE,
                                  LOOKUP_VALUE AS HIGH_LOOKUP_VALUE,
                                  LAG(RESULT_VALUE,1,RESULT_VALUE) OVER ('|| PARTITION_BY_CLAUSE || ' ORDER BY LOOKUP_VALUE) AS LOW_RESULT_VALUE,
                                  RESULT_VALUE AS HIGH_RESULT_VALUE
                            FROM ' || pin_LookupTable || ')';
    -- Group by used instead of Analytical functions
    MIN_MAX_SELECT_SQL := '(SELECT ' ||
                                   case when pin_varyByFields is not null then pin_varyByFields || ',' else null end || '
                                   min(LOOKUP_VALUE) MIN_LOOKUP_VALUE, -- lowest  LOOKUP
                                   max(LOOKUP_VALUE) MAX_LOOKUP_VALUE, -- highest LOOKUP
                                   min(RESULT_VALUE) KEEP(DENSE_RANK first order by LOOKUP_VALUE asc) MIN_RESULT_VALUE, -- lowest  RESULT
                                   max(RESULT_VALUE) KEEP(DENSE_RANK last  order by LOOKUP_VALUE asc) MAX_RESULT_VALUE  -- highest RESULT
                              FROM ' || pin_LookupTable || case when pin_varyByFields is not null then ' group by ' || pin_varyByFields else null end || ') ';

    RETURN_FROM_SQL :=  ROSTER_SELECT_SQL  || chr(10) ||
                        INPUT_SELECT_SQL   || chr(10) ||
                        case when pin_RosterFrom is not null then pin_RosterJoinClause else null end ||
                        pin_comp_filter    ||
                      ' LEFT JOIN '        ||
                        MIN_MAX_SELECT_SQL || case when pin_LookupJoinClause is not null then ' ' || replace(pin_LookupJoinClause,'LOOKUP','LK_MIN_MAX') else ' LK_MIN_MAX ON 1=1 ' end ||
                      ' LEFT JOIN '        ||
                        LOOKUP_SELECT_SQL  ||
                        case
                          when pin_LookupJoinClause is null
                            then
                              'LOOKUP ON TAB.LOOKUP_COLUMN > LOOKUP.LOW_LOOKUP_VALUE AND TAB.LOOKUP_COLUMN <= LOOKUP.HIGH_LOOKUP_VALUE'
                            else
                              ' ' || pin_LookupJoinClause || ' AND TAB.LOOKUP_COLUMN > LOOKUP.LOW_LOOKUP_VALUE AND TAB.LOOKUP_COLUMN <= LOOKUP.HIGH_LOOKUP_VALUE' end;

    RETURN_SELECT_SQL := 'SELECT ' || pin_InputColumnsAlias || ','                                                    ||
                         'CASE WHEN MIN_LOOKUP_VALUE is NULL            THEN 0 ELSE 1 END as VLD_NO_LKCURVES, '       ||
                         'CASE WHEN MIN_LOOKUP_VALUE = MAX_LOOKUP_VALUE THEN 0 ELSE 1 END as VLD_TWO_RECORDS, '       ||
                         'CASE WHEN TAB.LOOKUP_COLUMN = LOOKUP.HIGH_LOOKUP_VALUE '                                    ||
                                'THEN LOOKUP.HIGH_RESULT_VALUE '                                                      ||
                              'WHEN TAB.LOOKUP_COLUMN < LOOKUP.HIGH_LOOKUP_VALUE '                                    ||
                                'THEN LOOKUP.LOW_RESULT_VALUE '                                                       ||
                              'WHEN TAB.LOOKUP_COLUMN = MIN_LOOKUP_VALUE '                                            ||
                                'THEN MIN_RESULT_VALUE '                                                              ||
                              'WHEN TAB.LOOKUP_COLUMN < MIN_LOOKUP_VALUE '                                            ||
                                'THEN CASE ' || TO_CHAR(pin_LowerValueOption) || ' WHEN 1 THEN MIN_RESULT_VALUE '     ||
                                                                                 ' WHEN 5 THEN 0 '                    ||
                                                                                 ' WHEN 6 THEN NULL END '             ||
                              'WHEN TAB.LOOKUP_COLUMN > MAX_LOOKUP_VALUE '                                            ||
                                'THEN CASE ' || TO_CHAR(pin_HigherValueOption)|| ' WHEN 3 THEN MAX_RESULT_VALUE '     ||
                                                                                 ' WHEN 6 THEN NULL END '             ||
                         'END AS RESULT_VALUE ' || RETURN_FROM_SQL;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(RETURN_SELECT_SQL),',RETURN_SELECT_SQL         => <value>', replace(v_stamp,'input','output'));

    --DBMS_OUTPUT.PUT_LINE(RETURN_SELECT_SQL);
    RETURN RETURN_SELECT_SQL;
  END STEP_LOOKUP;
   -- ############################# STEP_LOOKUP END #############################

   -- ############################# CONTINUOUS_LOOKUP START #############################
   FUNCTION CONTINUOUS_LOOKUP(pin_InputColumns        VARCHAR2,
                              pin_InputColumnsAlias   VARCHAR2,
                              pin_InputFrom           VARCHAR2,
                              pin_InputLookupColumn   VARCHAR2,
                              pin_LookupTable         VARCHAR2,
                              pin_LowerValueOption    NUMBER,
                              pin_HigherValueOption   number,
                              pin_RosterFrom          varchar2,
                              pin_RosterJoinClause    varchar2,
                              pin_LookupJoinClause    varchar2,
                              pin_varyByFields        varchar2,
                              pin_comp_filter         varchar2)
   RETURN CLOB
   IS
      TYPE REC_MIN_MAX_LOOKUP  IS RECORD
      (LOOKUP_VALUE NUMBER,
       RESULT_VALUE NUMBER);
      TYPE NT_MIN_MAX_LOOKUP        IS TABLE OF REC_MIN_MAX_LOOKUP;
      MIN_MAX_LOOKUP                NT_MIN_MAX_LOOKUP;
      COLLECTION_COUNT              PLS_INTEGER;
      RETURN_SELECT_SQL             CLOB;
      SMALLEST_SLOPE                VARCHAR2(2000);
      LARGEST_SLOPE                 VARCHAR2(2000);
      LOOKUP_LESS_THAN_SMALLEST     VARCHAR2(2000);
      LOOKUP_GREATER_THAN_LARGEST   VARCHAR2(2000);
      RETURN_FROM_SQL               VARCHAR2(32767);
      INPUT_SELECT_SQL              VARCHAR2(32767);
      ROSTER_SELECT_SQL             VARCHAR2(32767);
      MIN_MAX_SELECT_SQL            VARCHAR2(32767);
      LOOKUP_SELECT_SQL             VARCHAR2(32767);
      INPUT_COLUMNS                 VARCHAR2(32767);
      INPUT_LOOKUP_COLUMN           VARCHAR2(32767);
      PARTITION_BY_CLAUSE           VARCHAR2(32767);
      v_stamp                       VARCHAR2(250);
   BEGIN

     v_stamp := 'COMPENSATION_PROCESSING.CONTINUOUS_LOOKUP - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

     -- <<0.>> Log the input parameters
     BEGIN
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLUMNS),          ',PIN_INPUTCOLUMNS => <value>'       , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLUMNSALIAS),     ',PIN_INPUTCOLUMNSALIAS => <value>'  , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTFROM),             ',PIN_INPUTFROM => <value>'          , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTLOOKUPCOLUMN),     ',PIN_INPUTLOOKUPCOLUMN => <value>'  , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LOOKUPTABLE),           ',PIN_LOOKUPTABLE => <value>'        , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_LOWERVALUEOPTION),        ',PIN_LOWERVALUEOPTION => <value>'   , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PIN_HIGHERVALUEOPTION),       ',PIN_HIGHERVALUEOPTION => <value>'  , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_RosterFrom),            ',pin_RosterFrom => <value>'         , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_RosterJoinClause),      ',pin_RosterJoinClause => <value>'   , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupJoinClause),      ',pin_LookupJoinClause => <value>'   , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_varyByFields),          ',pin_varyByFields => <value>'       , v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_comp_filter),          ',pin_comp_filter => <value>'      , v_stamp);

     END;

      INPUT_COLUMNS        := pin_InputColumns;
      INPUT_LOOKUP_COLUMN  := pin_InputLookupColumn;
      PARTITION_BY_CLAUSE  := case when pin_varyByFields is not null then 'PARTITION BY ' || pin_varyByFields else null end;

      -- If called from UI
      IF INPUT_LOOKUP_COLUMN IS NULL THEN
         INPUT_LOOKUP_COLUMN :=  pin_InputColumnsAlias;
      ELSE
         INPUT_COLUMNS := INPUT_COLUMNS || ',' || INPUT_LOOKUP_COLUMN || ' LOOKUP_COLUMN';
      END IF;
      --
      INPUT_SELECT_SQL := '(SELECT ' || INPUT_COLUMNS || ' FROM ' || pin_InputFrom || ') TAB';
      ROSTER_SELECT_SQL  := case when pin_RosterFrom is not null then pin_RosterFrom || ' INNER JOIN ' else 'FROM' end;
      --

      LOOKUP_SELECT_SQL := '(SELECT ' ||
                                  case when pin_varyByFields is not null then pin_varyByFields || ',' else null end || '
                                  LAG(LOOKUP_VALUE,1,LOOKUP_VALUE) OVER ('|| PARTITION_BY_CLAUSE || ' ORDER BY LOOKUP_VALUE) AS LOW_LOOKUP_VALUE,
                                  LOOKUP_VALUE AS HIGH_LOOKUP_VALUE,
                                  LAG(RESULT_VALUE,1,RESULT_VALUE) OVER ('|| PARTITION_BY_CLAUSE || ' ORDER BY LOOKUP_VALUE) AS LOW_RESULT_VALUE,
                                  RESULT_VALUE AS HIGH_RESULT_VALUE
                            FROM ' || pin_LookupTable || ') ';
      --
      --  Analytical functions used - only one view sort, group by added in order to avoid expanding Input
      MIN_MAX_SELECT_SQL := '(SELECT '                                                                                                                                                          || chr(10) ||
                                    case when pin_varyByFields is not null then pin_varyByFields || ',' else null end                                                                                  || chr(10) ||
                            '       min(MIN_LOOKUP_VALUE)         as MIN_LOOKUP_VALUE,'                                                                                                         || chr(10) ||
                            '       min(MAX_LOOKUP_VALUE)         as MAX_LOOKUP_VALUE,'                                                                                                         || chr(10) ||
                            '       min(MIN_RESULT_VALUE)         as MIN_RESULT_VALUE,'                                                                                                         || chr(10) ||
                            '       min(MAX_RESULT_VALUE)         as MAX_RESULT_VALUE,'                                                                                                         || chr(10) ||
                            '       min(SECOND_MIN_LOOKUP_VALUE)  as SECOND_MIN_LOOKUP_VALUE,'                                                                                                  || chr(10) ||
                            '       min(SECOND_MAX_LOOKUP_VALUE)  as SECOND_MAX_LOOKUP_VALUE,'                                                                                                  || chr(10) ||
                            '       min(SECOND_MIN_RESULT_VALUE)  as SECOND_MIN_RESULT_VALUE,'                                                                                                  || chr(10) ||
                            '       min(SECOND_MAX_RESULT_VALUE)  as SECOND_MAX_RESULT_VALUE'                                                                                                   || chr(10) ||
                            'FROM'                                                                                                                                                              || chr(10) ||
                            '    (SELECT '                                                                                                                                                      || chr(10) ||
                                        case when pin_varyByFields is not null then pin_varyByFields || ',' else null end                                                                              || chr(10) ||
                            '           MIN_LOOKUP_VALUE,'                                                                                                                                      || chr(10) ||
                            '           MAX_LOOKUP_VALUE,'                                                                                                                                      || chr(10) ||
                            '           MIN_RESULT_VALUE,'                                                                                                                                      || chr(10) ||
                            '           MAX_RESULT_VALUE,'                                                                                                                                      || chr(10) ||
                            '           min(LOOKUP_VALUE) KEEP(DENSE_RANK first order by case when LOOKUP_VALUE = MIN_LOOKUP_VALUE then  1e38 else LOOKUP_VALUE end asc) OVER('|| PARTITION_BY_CLAUSE || ') SECOND_MIN_LOOKUP_VALUE,' || chr(10) ||
                            '           max(LOOKUP_VALUE) KEEP(DENSE_RANK last  order by case when LOOKUP_VALUE = MAX_LOOKUP_VALUE then -1e38 else LOOKUP_VALUE end asc) OVER('|| PARTITION_BY_CLAUSE || ') SECOND_MAX_LOOKUP_VALUE,' || chr(10) ||
                            '           min(RESULT_VALUE) KEEP(DENSE_RANK first order by case when LOOKUP_VALUE = MIN_LOOKUP_VALUE then  1e38 else LOOKUP_VALUE end asc) OVER('|| PARTITION_BY_CLAUSE || ') SECOND_MIN_RESULT_VALUE,' || chr(10) ||
                            '           max(RESULT_VALUE) KEEP(DENSE_RANK last  order by case when LOOKUP_VALUE = MAX_LOOKUP_VALUE then -1e38 else LOOKUP_VALUE end asc) OVER('|| PARTITION_BY_CLAUSE || ') SECOND_MAX_RESULT_VALUE'  || chr(10) ||
                            '    FROM'                                                                                                                                                          || chr(10) ||
                            '      (SELECT '                                                                                                                                                    || chr(10) ||
                                         case when pin_varyByFields is not null then pin_varyByFields || ',' else null end                                                                             || chr(10) ||
                            '                     LOOKUP_VALUE,'                                                                                                                                || chr(10) ||
                            '                     RESULT_VALUE,'                                                                                                                                || chr(10) ||
                            '                     min(LOOKUP_VALUE) OVER('|| PARTITION_BY_CLAUSE || ') MIN_LOOKUP_VALUE,                                                     -- lowest  LOOKUP' || chr(10) ||
                            '                     max(LOOKUP_VALUE) OVER('|| PARTITION_BY_CLAUSE || ') MAX_LOOKUP_VALUE,                                                     -- highest LOOKUP' || chr(10) ||
                            '                     min(RESULT_VALUE) KEEP(DENSE_RANK first order by LOOKUP_VALUE asc) OVER('|| PARTITION_BY_CLAUSE || ') MIN_RESULT_VALUE,    -- lowest  RESULT' || chr(10) ||
                            '                     max(RESULT_VALUE) KEEP(DENSE_RANK last  order by LOOKUP_VALUE asc) OVER('|| PARTITION_BY_CLAUSE || ') MAX_RESULT_VALUE     -- highest RESULT' || chr(10) ||
                            '              FROM ' || pin_LookupTable || '))'                                                                                                                    || chr(10) ||
                                          case when pin_varyByFields is not null then ' GROUP BY ' || pin_varyByFields else null end || ' ) ';

      RETURN_FROM_SQL :=  ROSTER_SELECT_SQL    || chr(10) ||
                          INPUT_SELECT_SQL     || chr(10) ||
                          case when pin_RosterJoinClause is not null then pin_RosterJoinClause else null end ||
                            pin_comp_filter    ||
                          ' LEFT JOIN '        ||
                            MIN_MAX_SELECT_SQL || case when pin_LookupJoinClause is not null then ' ' || replace(replace(pin_LookupJoinClause,'LOOKUP','LK_MIN_MAX'),'LOOKUP') else ' LK_MIN_MAX ON 1=1 ' end ||
                          ' LEFT JOIN '        ||
                            LOOKUP_SELECT_SQL  ||
                            case
                              when pin_LookupJoinClause is null
                                then
                                  'LOOKUP ON TAB.LOOKUP_COLUMN > LOOKUP.LOW_LOOKUP_VALUE AND TAB.LOOKUP_COLUMN <= LOOKUP.HIGH_LOOKUP_VALUE'
                                else
                                  ' ' || pin_LookupJoinClause || ' AND TAB.LOOKUP_COLUMN > LOOKUP.LOW_LOOKUP_VALUE AND TAB.LOOKUP_COLUMN <= LOOKUP.HIGH_LOOKUP_VALUE' end;

      /*(((SECOND_MIN_RESULT_VALUE)-(MIN_RESULT_VALUE))/((SECOND_MIN_LOOKUP_VALUE)-(MIN_LOOKUP_VALUE))))                                                                           SMALLEST_SLOPE
      MIN_RESULT_VALUE + (((SECOND_MIN_RESULT_VALUE)-(MIN_RESULT_VALUE))/((SECOND_MIN_LOOKUP_VALUE)-(MIN_LOOKUP_VALUE)))) * (TAB.LOOKUP_COLUMN -(MIN_LOOKUP_VALUE))              LOOKUP_LESS_THAN_SMALLEST
      (((MAX_RESULT_VALUE)-(SECOND_MAX_RESULT_VALUE))/((MAX_LOOKUP_VALUE)-(SECOND_MAX_LOOKUP_VALUE)))                                                                            LARGEST_SLOPE
      SECOND_MAX_RESULT_VALUE + (((MAX_RESULT_VALUE)-(SECOND_MAX_RESULT_VALUE))/((MAX_LOOKUP_VALUE)-(SECOND_MAX_LOOKUP_VALUE))) * (TAB.LOOKUP_COLUMN -(SECOND_MAX_LOOKUP_VALUE)) LOOKUP_GREATER_THAN_LARGEST */

      RETURN_SELECT_SQL :=
              'SELECT ' || pin_InputColumnsAlias || ','                                                                                                                  || chr(10) ||
              '      CASE WHEN MIN_LOOKUP_VALUE is null            THEN 0 else 1 end as VLD_NO_LKCURVES, '                                                               || chr(10) ||
              '      CASE WHEN MIN_LOOKUP_VALUE = MAX_LOOKUP_VALUE THEN 0 else 1 end as VLD_TWO_RECORDS, '                                                               || chr(10) ||
              '      CASE '                                                                                                                                              || chr(10) ||
              '        WHEN TAB.LOOKUP_COLUMN = LOOKUP.HIGH_LOOKUP_VALUE'                                                                                                || chr(10) ||
              '          THEN LOOKUP.HIGH_RESULT_VALUE'                                                                                                                  || chr(10) ||
              '        WHEN TAB.LOOKUP_COLUMN < LOOKUP.HIGH_LOOKUP_VALUE'                                                                                                || chr(10) ||
              '          THEN LOW_RESULT_VALUE + ((HIGH_RESULT_VALUE - LOW_RESULT_VALUE)/(HIGH_LOOKUP_VALUE - LOW_LOOKUP_VALUE))*(TAB.LOOKUP_COLUMN-LOW_LOOKUP_VALUE)'   || chr(10) ||
              '        WHEN TAB.LOOKUP_COLUMN = MIN_LOOKUP_VALUE '                                                                                                       || chr(10) ||
              '          THEN MIN_RESULT_VALUE'                                                                                                                          || chr(10) ||
              '        WHEN TAB.LOOKUP_COLUMN < MIN_LOOKUP_VALUE '                                                                                                       || chr(10) ||
              '          THEN CASE '                                                                                                                                     || chr(10) ||
              '                 WHEN '||TO_CHAR(pin_LowerValueOption)||' = 1'                                                                                            || chr(10) ||
              '                   THEN  MIN_RESULT_VALUE'                                                                                                                || chr(10) ||
              '                 WHEN '||TO_CHAR(pin_LowerValueOption)||' = 2 AND MIN_LOOKUP_VALUE = MAX_LOOKUP_VALUE'                                                    || chr(10) ||
              '                    THEN  MIN_RESULT_VALUE'                                                                                                               || chr(10) ||
              '                 WHEN '||TO_CHAR(pin_LowerValueOption)||' = 2'                                                                                            || chr(10) ||
              '                    THEN  MIN_RESULT_VALUE + (((SECOND_MIN_RESULT_VALUE)-(MIN_RESULT_VALUE))/((SECOND_MIN_LOOKUP_VALUE)-(MIN_LOOKUP_VALUE))) * (TAB.LOOKUP_COLUMN -(MIN_LOOKUP_VALUE))' || chr(10) ||
              '                 WHEN '||TO_CHAR(pin_LowerValueOption)||' = 5'                                                                                            || chr(10) ||
              '                    THEN 0'                                                                                                                               || chr(10) ||
              '                 WHEN '||TO_CHAR(pin_LowerValueOption)||' = 6'                                                                                            || chr(10) ||
              '                    THEN NULL END'                                                                                                                        || chr(10) ||
              '         WHEN TAB.LOOKUP_COLUMN > MAX_LOOKUP_VALUE'                                                                                                       || chr(10) ||
              '           THEN CASE '                                                                                                                                    || chr(10) ||
              '                  WHEN '||TO_CHAR(pin_HigherValueOption)||' = 3'                                                                                          || chr(10) ||
              '                    THEN MAX_RESULT_VALUE'                                                                                                                || chr(10) ||
              '                  WHEN '||TO_CHAR(pin_HigherValueOption)||' = 4 AND MIN_LOOKUP_VALUE = MAX_LOOKUP_VALUE'                                                  || chr(10) ||
              '                    THEN MAX_RESULT_VALUE'                                                                                                                || chr(10) ||
              '                  WHEN '||TO_CHAR(pin_HigherValueOption)||' = 4'                                                                                          || chr(10) ||
              '                    THEN SECOND_MAX_RESULT_VALUE + (((MAX_RESULT_VALUE)-(SECOND_MAX_RESULT_VALUE))/((MAX_LOOKUP_VALUE)-(SECOND_MAX_LOOKUP_VALUE))) * (TAB.LOOKUP_COLUMN -(SECOND_MAX_LOOKUP_VALUE))' || chr(10) ||
              '                  WHEN '||TO_CHAR(pin_HigherValueOption)||' = 6'                                                                                          || chr(10) ||
              '                    THEN NULL END'                                                                                                                        || chr(10) ||
              '      END AS RESULT_VALUE'                                                                                                                                || chr(10) ||
               RETURN_FROM_SQL;

      --DBMS_OUTPUT.PUT_LINE(RETURN_SELECT_SQL);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(RETURN_SELECT_SQL),',RETURN_SELECT_SQL         => <value>', replace(v_stamp,'input','output'));
      RETURN RETURN_SELECT_SQL;
   END CONTINUOUS_LOOKUP;
   -- ############################# CONTINUOUS_LOOKUP END #############################

   -- ############################# DISCRETE_LOOKUP START #############################
   FUNCTION DISCRETE_LOOKUP(pin_InputColumns        VARCHAR2,
                            pin_InputColumnsAlias   VARCHAR2,
                            pin_InputFrom           VARCHAR2,
                            pin_InputLookupColumn   VARCHAR2,
                            pin_LookupTable         VARCHAR2,
                            pin_RosterFrom          varchar2,
                            pin_RosterJoinClause    varchar2,
                            pin_LookupJoinClause    varchar2,
                            pin_varyByFields        varchar2,
                            pin_comp_filter         varchar2) -- #ADDED The join clause for Lookup, I - Input, R - Roster, LOOKUP - lookup table Ex: LOOKUP ON I.E12312 = LOOKUP.E12312 and R.F12311 = LOOKUP.F12311
   RETURN CLOB
   IS
      RETURN_SELECT_SQL       CLOB;
      RETURN_FROM_SQL         VARCHAR2(32767);
      INPUT_SELECT_SQL        VARCHAR2(32767);
      ROSTER_SELECT_SQL       VARCHAR2(32767);
      LOOKUP_JOIN_CLAUSE      VARCHAR2(32767);
      INPUT_COLUMNS           VARCHAR2(32767);
      INPUT_LOOKUP_COLUMN     VARCHAR2(32767);
      v_stamp                 VARCHAR2(250);
   begin

     v_stamp := 'COMPENSATION_PROCESSING.DISCRETE_LOOKUP - input - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

     -- <<0.>> Log the input parameters
     BEGIN
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLUMNS),          ',PIN_INPUTCOLUMNS => <value>'     , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTCOLUMNSALIAS),     ',PIN_INPUTCOLUMNSALIAS => <value>', v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTFROM),             ',PIN_INPUTFROM => <value>'        , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_ROSTERFROM),            ',PIN_ROSTERFROM => <value>'       , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_INPUTLOOKUPCOLUMN),     ',PIN_INPUTLOOKUPCOLUMN => <value>', v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(PIN_LOOKUPTABLE),           ',PIN_LOOKUPTABLE => <value>'      , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_RosterFrom),            ',pin_RosterFrom => <value>'       , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_RosterJoinClause),      ',pin_RosterJoinClause => <value>' , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupJoinClause),      ',pin_LookupJoinClause => <value>' , v_stamp);
       L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_varyByFields),          ',pin_varyByFields => <value>'     , v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_comp_filter),          ',pin_comp_filter => <value>'      , v_stamp);

    END;
     --
     INPUT_COLUMNS        := pin_InputColumns;
     INPUT_LOOKUP_COLUMN  := pin_InputLookupColumn;
     -- If called from UI
     IF INPUT_LOOKUP_COLUMN IS NULL THEN
        INPUT_LOOKUP_COLUMN :=  pin_InputColumnsAlias;
     ELSE
        INPUT_COLUMNS := INPUT_COLUMNS || ',' || INPUT_LOOKUP_COLUMN || ' LOOKUP_COLUMN';
     END IF;
     --
     INPUT_SELECT_SQL   := '(SELECT ' || INPUT_COLUMNS || ' FROM ' || pin_InputFrom || ') TAB';
     ROSTER_SELECT_SQL  := case when pin_RosterFrom is not null then pin_RosterFrom || ' INNER JOIN ' else 'FROM' end;


     --
     RETURN_FROM_SQL := ROSTER_SELECT_SQL  || chr(10) ||
                        INPUT_SELECT_SQL   || chr(10) ||
                        case when pin_RosterJoinClause is not null then pin_RosterJoinClause else null end ||
                        pin_comp_filter    ||
                        ' LEFT JOIN  '
                        || pin_LookupTable || chr(10) ||
                          case when pin_LookupJoinClause is not null
                                 then pin_LookupJoinClause || ' AND TAB.LOOKUP_COLUMN = LOOKUP.LOOKUP_VALUE '
                                 else                   ' LOOKUP ON TAB.LOOKUP_COLUMN = LOOKUP.LOOKUP_VALUE ' end;
     --
     -- TODO: For Discrete Lookup VLD_NO_LKCURVES is not yet implemented. 2520 is raised instead of 2510
     RETURN_SELECT_SQL := 'SELECT '
                          || pin_InputColumnsAlias
                          || ',1 as VLD_TWO_RECORDS'
                          || ',nvl((select 1 from dual where exists (select 1 from '|| pin_LookupTable ||
                                                                      case
                                                                        when pin_LookupJoinClause is not null
                                                                          then regexp_replace(pin_LookupJoinClause,'LOOKUP on', ' LOOKUP where ',1,0,'i') end || ')),0) as VLD_NO_LKCURVES'
                          || ', LOOKUP.RESULT_VALUE AS RESULT_VALUE '
                          || RETURN_FROM_SQL;
     --
     -- DBMS_OUTPUT.PUT_LINE(RETURN_SELECT_SQL);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(RETURN_SELECT_SQL),',RETURN_SELECT_SQL => <value>', replace(v_stamp,'input','output'));
     RETURN RETURN_SELECT_SQL;
   END DISCRETE_LOOKUP;
 -- ############################# DISCRETE_LOOKUP END #############################


 -- ############################# TIERED_LOOKUP START #############################
   function TIERED_LOOKUP(pin_TiersTable          varchar2,
                          pin_NumberOfTiers       NUMBER,
                          pin_varyByFields        varchar2,
                          pin_table_prefix        varchar2)
   RETURN TABLETYPE_LOOKUP_CLAUSES
   IS
     TIERED_CASE_SQL        clob;
     TIERS_TABLE_SQL        clob;
     TIERS_SQL              clob;
     RETURN_CLAUSES         TABLETYPE_LOOKUP_CLAUSES := TABLETYPE_LOOKUP_CLAUSES(OBJTYPE_LOOKUP_CLAUSES(LOOKUP_SQL => null,CASE_SQL => null,TIERS_TABLE_SQL => null));
     v_stamp                VARCHAR2(250 char):= 'COMPENSATION_PROCESSING.TIERED_LOOKUP - input'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
   BEGIN

     --0. Add Logging
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_TiersTable)         ,',pin_TiersTable        => <value>', v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_NumberOfTiers)        ,',pin_NumberOfTiers     => <value>', v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_varyByFields)       ,',pin_varyByFields      => <value>', v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_table_prefix)       ,',pin_table_prefix      => <value>', v_stamp);

     --1. Create CASE statement for getting the total Earnings
     for i in 1..pin_NumberOfTiers loop
       TIERED_CASE_SQL  := TIERED_CASE_SQL || 'CASE WHEN METRIC > TIER_'||to_char(i)||'_LV'                                                             ||chr(10)||chr(32)
                                           || '           then (CASE WHEN METRIC > NVL(TIER_'||to_char(i)||'_UV,1E38)'                                  ||chr(10)||chr(32)
                                           || '                        then greatest(TIER_'||to_char(i)||'_UV - TIER_'||to_char(i)||'_LV,0)'                            ||chr(10)||chr(32)
                                           || '                       else greatest(METRIC - TIER_'||to_char(i)||'_LV,0) END * TIER_'||to_char(i)||'_COMMISSION_RATE)'  ||chr(10)||chr(32)
                                           || '          else 0 end +';
       TIERS_SQL := TIERS_SQL || ','''||to_char(i)||''' AS TIER_' || case when pin_table_prefix is not null then pin_table_prefix else null end ||to_char(i)||'';
     end loop;

     TIERED_CASE_SQL := substr(TIERED_CASE_SQL,0,length(TIERED_CASE_SQL)-1);
     TIERS_SQL       := substr(TIERS_SQL,2);

    --2. Create TIERS inline view
     TIERS_TABLE_SQL := '(SELECT * FROM(SELECT
                                         TIER_START as LOWER_VALUE
                                        ,LEAD(TIER_START,1,1E38) OVER('|| case when pin_varyByFields is not null then ' partition by ' || pin_varyByFields else null end  || ' ORDER BY TIER_START) as UPPER_VALUE
                                        ,COMMISSION_RATE
                                        ,COUNT(*)     OVER (' || case when pin_varyByFields is not null then ' partition by ' || pin_varyByFields else null end  || ' ) NRT
                                        ,ROW_NUMBER() OVER (' || case when pin_varyByFields is not null then ' partition by ' || pin_varyByFields else null end  || ' ORDER BY TIER_START) TIER_NO '||
                                         case when pin_varyByFields is not null then ',' || pin_varyByFields else null end || '
                               FROM '|| pin_TiersTable || ') PIVOT
                           ( SUM(LOWER_VALUE)     AS LV
                            ,SUM(UPPER_VALUE)     AS UV
                            ,SUM(COMMISSION_RATE) AS COMMISSION_RATE
                            ,SUM(NRT)             AS NRT
                           FOR TIER_NO IN ('|| TIERS_SQL ||')))';

     RETURN_CLAUSES(1).CASE_SQL        :=  TIERED_CASE_SQL;
     RETURN_CLAUSES(1).TIERS_TABLE_SQL :=  TIERS_TABLE_SQL;
     RETURN_CLAUSES(1).LOOKUP_SQL      :=  null;

     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(RETURN_CLAUSES),',RETURN_CLAUSES         => <value>', replace(v_stamp,'input','output'));

     RETURN RETURN_CLAUSES;

   END TIERED_LOOKUP;
 -- ############################# TIERED_LOOKUP END #############################


 -- ############################# F_COMPONENT_INPUTS START #############################
 FUNCTION F_COMPONENT_INPUTS
    RETURN tabletype_id_id PIPELINED IS
    v_pos NUMBER;
    v_idx NUMBER;
   BEGIN
    for c in (Select PCD_ID, OD_DEFINITION FROM PLAN_COMPONENT_DEFINITIONS
    JOIN PLAN_COMP_EARNING_CALC_TAB
      ON PCECT_PCD_ID = PCD_ID
    JOIN PLAN_COMP_EARNING_CALC_CUSTOM
      ON PCECT_ID = PCECC_PCECT_ID
    JOIN OBJECT_DEFINITIONS
      ON OD_ID = PCECC_EXP_ID
    WHERE OD_DEFINITION is  not null) LOOP
         v_pos :=1;
         v_idx := 1;
         WHILE v_idx > 0
          LOOP
            pipe row(OBJTYPE_ID_ID(c.PCD_ID, REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_SUBSTR (TO_CHAR(c.OD_DEFINITION),'\[Metric\.(.*?)\].*?',v_pos) , '\[Metric.'), '\]') ));
            v_pos := v_pos+1;
            v_idx := INSTR( TO_CHAR(c.OD_DEFINITION), '[Metric.' , v_pos );
          END LOOP;
    END LOOP;
  END F_COMPONENT_INPUTS;
-- ############################# F_COMPONENT_INPUTS END #############################


  -- ############################# DATING_FILTER START #############################
  PROCEDURE DATING_FILTER(PI_PERIOD_TUPR_ID        in NUMBER,
                        PI_INPUT_TABLE_NAME      in VARCHAR2,
                        PI_EFFECTIVE_START_FIELD IN VARCHAR2,
                        PI_EFFECTIVE_END_FIELD   IN VARCHAR2,
                        PI_TU_ID                 IN NUMBER,
                        PI_RECORD_DATING_OPTION  IN NUMBER,
                        PI_CORR_DIR              IN NUMBER,
                        PI_CORR_TYPE             IN NUMBER,
                        PO_WHERE_CLAUSE          OUT VARCHAR2) is

  v_start_date       date;
  v_end_date         date;
  v_tup_tu_id        number(10);
  v_tu_id            number(10);
  v_input_table_name VARCHAR2(31);
begin

  if (PI_PERIOD_TUPR_ID is null or PI_EFFECTIVE_START_FIELD is null or
     PI_RECORD_DATING_OPTION is null or
     PI_CORR_DIR is null or PI_CORR_TYPE is null) then

    raise_application_error(-20001,
                            'PI_PERIOD_TUPR_ID or PI_EFFECTIVE_START_FIELD or PI_RECORD_DATING_OPTION can not be passed as null');

  else

    v_input_Table_name := CASE WHEN PI_INPUT_TABLE_NAME IS NULL THEN '' ELSE PI_INPUT_TABLE_NAME || '.' END;

    select TUP_TU_id
      into v_tu_id
      from tu_periods
     where tup_id in (select tupr_tup_id
                        from tu_periods_range tupr_id
                       where tupr_id = PI_PERIOD_TUPR_ID);

    -- if the i/p table is not effective date
    IF (PI_RECORD_DATING_OPTION = 1) THEN

      PO_WHERE_CLAUSE := null;

      --if the i/p table is effective by date
    ELSIF (PI_RECORD_DATING_OPTION = 2) THEN

      commons_timeunits.get_period_start_end_date(pi_tupr_id    => PI_PERIOD_TUPR_ID,
                                                  po_start_date => v_start_date,
                                                  po_end_date   => v_end_date);

      PO_WHERE_CLAUSE := '( ';

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || v_input_table_name ||
                         PI_EFFECTIVE_START_FIELD || ' <= ''' || v_end_date ||
                         ''' AND ' || v_input_table_name ||
                         PI_EFFECTIVE_START_FIELD || ' >= ''' ||
                         v_start_date || '''';

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' )';
      --if the i/p table is effective for a range of date
    ELSIF (PI_RECORD_DATING_OPTION = 4) THEN

      if (PI_EFFECTIVE_END_FIELD is null) then

        raise_application_error(-20001,
                                '   PI_EFFECTIVE_END_FIELD can not be passed as null for a table effective by range of dates');
      end if;

      commons_timeunits.get_period_start_end_date(pi_tupr_id    => PI_PERIOD_TUPR_ID,
                                                  po_start_date => v_start_date,
                                                  po_end_date   => v_end_date);

      PO_WHERE_CLAUSE := '( ';

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || '( ' || v_input_table_name ||
                         PI_EFFECTIVE_START_FIELD || ' <= ''' || v_end_date ||
                         ''' or ' || v_input_table_name ||
                         PI_EFFECTIVE_START_FIELD || ' is null)' ||
                         ' AND (' || v_input_table_name ||
                         PI_EFFECTIVE_END_FIELD || ' >= ''' || v_start_date ||
                         ''' or ' || v_input_table_name ||
                         PI_EFFECTIVE_END_FIELD || ' is null)';

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' )';

      --if the i/p table is effective by period
    ELSIF (PI_RECORD_DATING_OPTION = 3) THEN

      PO_WHERE_CLAUSE := '( ';

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || v_input_table_name ||
                         PI_EFFECTIVE_START_FIELD || ' = ' ||
                         PI_PERIOD_TUPR_ID;

      if (PI_CORR_TYPE in (1, 3)) then

        IF (PI_CORR_DIR in (2, 1)) THEN

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_correspondence
                                      (pi_base_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ' , pi_corr_tupr_id_start =>' ||
                             PI_PERIOD_TUPR_ID ||
                             ',  pi_base_tupr_id_end => null,pi_corr_tupr_id_end => null,
                                            pi_type => 1,  pi_corr_tu_id=>' ||
                             v_tu_id || ',  pi_base_tu_id=>' || PI_TU_ID ||
                             ' )=1)';
        END IF;

        IF (PI_CORR_DIR = 2) THEN
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_correspondence
                                      (pi_base_tupr_id_start => ' ||
                             PI_PERIOD_TUPR_ID ||
                             ' , pi_corr_tupr_id_start =>' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ',  pi_base_tupr_id_end => null,pi_corr_tupr_id_end => null,
                                            pi_type => 1,  pi_corr_tu_id=>' ||
                             PI_tu_id || ',  pi_base_tu_id=>' || v_TU_ID ||
                             ')=1)';
        END IF;

      end if;
      if (PI_CORR_TYPE in (2, 3)) then

        IF (PI_CORR_DIR in (1, 2)) THEN
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_rev_correspondence
                                     (pi_base_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ' , pi_corr_tupr_id_start => ' ||
                             PI_PERIOD_TUPR_ID ||
                             ',  pi_base_tupr_id_end => null,pi_corr_tupr_id_end => null,
                                        pi_type => 1,  pi_corr_tu_id=>' ||
                             v_tu_id || ',  pi_base_tu_id=>' || PI_TU_ID ||
                             ')=1)';
        END IF;

        IF (PI_CORR_DIR = 2) THEN
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_rev_correspondence
                                     (pi_base_tupr_id_start => ' ||
                             PI_PERIOD_TUPR_ID ||
                             ' , pi_corr_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ',  pi_base_tupr_id_end => null,pi_corr_tupr_id_end => null,
                                        pi_type => 1,  pi_corr_tu_id=>' ||
                             pi_tu_id || ',  pi_base_tu_id=>' || v_TU_ID ||
                             ')=1)';
        END IF;

      end if;

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' )';

      --if the i/p table is effective by a range of period
    ELSIF (PI_RECORD_DATING_OPTION = 5) THEN

      if (PI_EFFECTIVE_END_FIELD is null or PI_TU_ID is null) then

        raise_application_error(-20001,
                                '  v_end_date or v_start_date or PI_EFFECTIVE_END_FIELD or PI_TU_ID can not be passed as null for a table effective by range of periods');
      end if;

      PO_WHERE_CLAUSE := '( ';

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || PI_PERIOD_TUPR_ID ||
                         ' in (
      select column_value from table( commons_timeunits.get_period_range_id_within(PI_TU_ID => ' ||
                         PI_TU_ID || ' ,
                   pi_tupr_id_start => ' ||
                         v_input_table_name ||
                         PI_EFFECTIVE_START_FIELD || ' ,
                   pi_tupr_id_end => ' ||
                         v_input_table_name ||
                         PI_EFFECTIVE_END_FIELD || ' ) ) )';

      if (PI_CORR_TYPE in (1, 3)) then

        IF (PI_CORR_DIR in (1, 2)) THEN

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_correspondence
                                  (pi_base_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ' , pi_corr_tupr_id_start =>' ||
                             PI_PERIOD_TUPR_ID ||
                             ',  pi_base_tupr_id_end => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_END_FIELD ||
                             ',pi_corr_tupr_id_end => null,  pi_type => 2,  pi_corr_tu_id=>' ||
                             v_tu_id || ',  pi_base_tu_id=>' || pi_TU_ID ||
                             ')=1)';

        end if;
        IF (PI_CORR_DIR in (2)) THEN
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_correspondence
                                  (pi_corr_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ' , pi_base_tupr_id_start =>' ||
                             PI_PERIOD_TUPR_ID ||
                             ',  pi_corr_tupr_id_end => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_END_FIELD ||
                             ', pi_base_tupr_id_end => null, pi_type => 3,  pi_corr_tu_id=>' ||
                             pi_tu_id || ',  pi_base_tu_id=>' || v_TU_ID ||
                             ')=1)';
        end if;
      end if;
      if (PI_CORR_TYPE in (2, 3)) then

        IF (PI_CORR_DIR in (1, 2)) THEN
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_rev_correspondence
                        (pi_base_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ' , pi_corr_tupr_id_start => ' ||
                             PI_PERIOD_TUPR_ID ||
                             ' ,pi_base_tupr_id_end => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_END_FIELD ||
                             ', pi_corr_tupr_id_end => null,pi_type => 2)=1 )';

        end if;

        IF (PI_CORR_DIR in (2)) THEN
          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' or ';

          PO_WHERE_CLAUSE := PO_WHERE_CLAUSE ||
                             '(commons_timeunits.get_tupr_rev_correspondence
                        (pi_corr_tupr_id_start => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_START_FIELD ||
                             ' , pi_base_tupr_id_start => ' ||
                             PI_PERIOD_TUPR_ID ||
                             ' ,pi_corr_tupr_id_end => ' ||
                             v_input_table_name ||
                             PI_EFFECTIVE_END_FIELD ||
                             ', pi_base_tupr_id_end => null,pi_type => 3)=1 )';

        end if;

      end if;

      PO_WHERE_CLAUSE := PO_WHERE_CLAUSE || ' )';

    END IF;

    --dbms_output.put_line(PO_WHERE_CLAUSE);
  end if;

end DATING_FILTER;
  -- ############################# DATING_FILTER END #############################

  -- ############################# TO_STRING START #############################
FUNCTION TO_STRING
(  pi_collection  IN TABLETYPE_CHARMAX
  ,pi_delimiter IN VARCHAR2 DEFAULT ','
) RETURN CLOB IS
  v_idx PLS_INTEGER;
  v_str CLOB;
BEGIN
  v_idx := pi_collection.FIRST;
  WHILE v_idx IS NOT NULL
  LOOP
    v_str := v_str || pi_delimiter || pi_collection(v_idx);
    v_idx := pi_collection.NEXT(v_idx);
  END LOOP;

  v_str := LTRIM(v_str, pi_delimiter);
  RETURN v_str;
END TO_STRING;
  -- ############################# TO_STRING END #############################

  -- ############################# TO_STRING START #############################
PROCEDURE GROUP_PERIODS_FOR_INPUT
(  pin_input_table_list         IN TABLETYPE_INPUT_TABLE_LIST
    ,pin_earning_calc_ent         IN TABLETYPE_CPM_ENTITIES
    ,pin_input_values_columns       IN TABLETYPE_ID_NAME
    ,pout_dups_found                OUT TABLETYPE_NUMBER
  ,pout_input_table_list          OUT NOCOPY TABLETYPE_INPUT_TABLE_LIST
) IS
    v_unique_tables TABLETYPE_INPUT_TABLE_LIST := TABLETYPE_INPUT_TABLE_LIST();
    v_unique_table  OBJTYPE_INPUT_TABLE_LIST;
    v_ece_list      VARCHAR2(32000 CHAR);
    v_table_name    VARCHAR2(30 CHAR);
    v_from_sql      CLOB;
BEGIN
    pout_dups_found := TABLETYPE_NUMBER();

    -- building the list of ECE columns to group by
    FOR cv_calc_ent IN (SELECT * FROM TABLE(pin_earning_calc_ent) P ORDER BY P.ENTITY_ORDER)
    LOOP
        v_ece_list := v_ece_list
            ||CASE WHEN v_ece_list IS NOT NULL THEN ', ' ELSE NULL END
            ||'<PREFIX>'||cv_calc_ent.ENTITY_NAME;
    END LOOP;

    -- for each distinct input that has more than one period of data aggregate the query into a single record in v_unique_tables
    FOR c IN (  SELECT T.TABLE_TYPE, T.INPUT_NUMBER, CL.NAME
                FROM TABLE(pin_input_table_list) T
                     LEFT JOIN TABLE(pin_input_values_columns) CL ON T.INPUT_NUMBER = CL.ID
                WHERE T.TABLE_TYPE IN (2, 12)
                GROUP BY T.TABLE_TYPE, T.INPUT_NUMBER, CL.NAME
                HAVING COUNT(*) > 1)
    LOOP
        v_from_sql := NULL;

        FOR c2 IN (SELECT * FROM TABLE(pin_input_table_list) T
                    WHERE T.TABLE_TYPE = c.TABLE_TYPE AND T.INPUT_NUMBER = c.INPUT_NUMBER)
        LOOP
            v_from_sql := v_from_sql
                ||CASE WHEN v_from_sql IS NOT NULL THEN 'UNION ALL'||CHR(10) ELSE NULL END
                ||'SELECT '||REGEXP_REPLACE(v_ece_list, '<PREFIX>', '')
                ||CASE WHEN pin_input_values_columns IS NOT NULL THEN ', '||NVL(c.NAME , 'METRIC') ELSE NULL END
                ||' FROM '||c2.TABLE_NAME
                ||CASE WHEN c2.WHERE_CLAUSE IS NOT NULL AND pin_input_values_columns IS NOT NULL THEN ' WHERE '||REGEXP_REPLACE(c2.WHERE_CLAUSE, 'I.', c2.TABLE_NAME||'.')
                       WHEN c2.WHERE_CLAUSE IS NOT NULL AND pin_input_values_columns IS NULL THEN ' WHERE '||c2.WHERE_CLAUSE
                       ELSE NULL END
                ||CHR(10);

            v_table_name := c2.TABLE_NAME;
        END LOOP;

        IF (pin_input_values_columns IS NOT NULL)
        THEN
            v_from_sql := '(SELECT '||REGEXP_REPLACE(v_ece_list, '<PREFIX>', '')||', '||c.NAME||', ROWNUM AS ROW_IDENTIFIER'||CHR(10)
                ||'FROM (SELECT '||REGEXP_REPLACE(v_ece_list, '<PREFIX>', '')||', SUM('||c.NAME||') AS '||c.NAME||CHR(10)
                ||'FROM ('||CHR(10)
                ||v_from_sql
                ||')'||CHR(10)
                ||'GROUP BY '||REGEXP_REPLACE(v_ece_list, '<PREFIX>', '')||'))';
        ELSE
            v_from_sql := '('||v_from_sql||') '||v_table_name;
        END IF;

        pout_dups_found.extend;
        pout_dups_found(pout_dups_found.last) := c.INPUT_NUMBER;

        v_unique_table := OBJTYPE_INPUT_TABLE_LIST(v_table_name, v_from_sql, NULL, c.TABLE_TYPE, c.INPUT_NUMBER);
        v_unique_tables.extend;
        v_unique_tables(v_unique_tables.last) := v_unique_table;
    END LOOP;

    -- build back final list of input tables
    SELECT OBJTYPE_INPUT_TABLE_LIST(TABLE_NAME, FROM_CLAUSE, WHERE_CLAUSE, TABLE_TYPE, INPUT_NUMBER)
    BULK COLLECT INTO pout_input_table_list
    FROM (SELECT TABLE_NAME, FROM_CLAUSE, WHERE_CLAUSE, TABLE_TYPE, INPUT_NUMBER
          FROM TABLE(pin_input_table_list)
          WHERE (TABLE_TYPE, INPUT_NUMBER) NOT IN (SELECT TABLE_TYPE, INPUT_NUMBER FROM TABLE(v_unique_tables))

          UNION ALL
          SELECT TABLE_NAME, FROM_CLAUSE, WHERE_CLAUSE, TABLE_TYPE, INPUT_NUMBER
          FROM TABLE(v_unique_tables)
         ) T;
END GROUP_PERIODS_FOR_INPUT;
  -- ############################# TO_STRING END #############################

  -- ############################# BUILD_HELPFUL_CLAUSES START #############################
PROCEDURE BUILD_HELPFUL_CLAUSES
(    pin_input_table_list   IN TABLETYPE_INPUT_TABLE_LIST
    ,pin_validation_list    IN NUMBER
    ,pin_earning_entity     IN VARCHAR2
    ,pin_payment_entity     IN VARCHAR2
    ,pin_metric_calc_ent    IN TABLETYPE_CPM_ENTITIES
    ,pin_earning_calc_ent   IN TABLETYPE_CPM_ENTITIES
    ,pin_payment_calc_ent   IN TABLETYPE_CPM_ENTITIES
    ,pin_metric_check_dups  IN NUMBER
    ,pin_comp_no_dup_check  IN TABLETYPE_NUMBER
    ,po_list_ee_values      OUT CLOB
    ,po_list_ee_cols        OUT CLOB
    ,po_list_all_values     OUT CLOB
    ,po_list_all_cols       OUT CLOB
    ,po_list_all_vld_sel    OUT CLOB
    ,po_list_all_vld_grp    OUT CLOB
    ,po_entity_join         OUT CLOB
    ,po_input_selection     OUT CLOB
    ,po_sum_sql             OUT CLOB
    ,po_when_sql            OUT CLOB
    ,po_max_sql             OUT CLOB
) IS
    v_in_cnt        NUMBER;
    v_calc_ent_cnt  NUMBER := 0;
BEGIN
    IF (pin_validation_list = 1)
    THEN
        po_list_ee_values := '<PREFIX>'||pin_earning_entity;
        po_list_ee_cols := 'EARNING_ENTITY_ID';
        po_entity_join := 'R.'||pin_earning_entity||' = <INPUT>.'||pin_earning_entity;

        FOR cv_calc_ent IN (SELECT   P.ENTITY_NAME, P.ENTITY_ORDER, P.ENTITY_TYPE, P.COLUMN_TYPE
                                    ,ROW_NUMBER() OVER (PARTITION BY CASE WHEN P.ENTITY_TYPE IN (3, 4) THEN 1 ELSE 0 END
                                                        ORDER BY P.ENTITY_ORDER) CALC_ENTITY_ORDER
                                    ,F.FLD_DATA_TYPE
                            FROM    (SELECT ENTITY_NAME, ENTITY_ORDER, ENTITY_TYPE, COLUMN_TYPE
                                     FROM TABLE(pin_metric_calc_ent)
                                     GROUP BY ENTITY_NAME, ENTITY_ORDER, ENTITY_TYPE, COLUMN_TYPE
                                    ) P
                                    LEFT JOIN ENTITIES E ON P.COLUMN_TYPE = 1 AND 'E'||TO_CHAR(E.ENTITY_ID) = P.ENTITY_NAME
                                    LEFT JOIN TABLE_COLUMNS TC ON E.ENTITY_TABLES_ID = TC.TC_TABLES_ID AND TC.TC_LOGIC_TYPE IN (1,5)
                                    LEFT JOIN FIELDS F ON (P.COLUMN_TYPE = 1 AND TC.TC_FLD_ID = F.FLD_ID)
                                                        OR (P.COLUMN_TYPE = 2 AND P.ENTITY_NAME = F.FLD_COLUMN_NAME)
                            ORDER BY P.ENTITY_ORDER)
        LOOP
            po_list_all_values := po_list_all_values
                ||CASE WHEN po_list_all_values IS NOT NULL THEN ', ' ELSE NULL END
                ||'<PREFIX>'||cv_calc_ent.ENTITY_NAME;

            po_list_all_cols := po_list_all_cols
                ||CASE  WHEN po_list_all_cols IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
                        WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4) THEN 'CALC_ENTITY_'||TO_CHAR(cv_calc_ent.CALC_ENTITY_ORDER)||'_VALUE'
                        ELSE NULL END;

            po_list_all_vld_sel := po_list_all_vld_sel
                ||CASE  WHEN po_list_all_vld_sel IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4)
                            AND (  (cv_calc_ent.COLUMN_TYPE = 1 AND cv_calc_ent.FLD_DATA_TYPE = 1)
                                OR (cv_calc_ent.COLUMN_TYPE = 2 AND cv_calc_ent.FLD_DATA_TYPE = 1))
                        THEN 'MAX('||cv_calc_ent.ENTITY_NAME||') KEEP (DENSE_RANK FIRST ORDER BY '||pin_earning_entity||') '||cv_calc_ent.ENTITY_NAME
                        ELSE cv_calc_ent.ENTITY_NAME END;

            po_list_all_vld_grp := po_list_all_vld_grp
                ||CASE  WHEN po_list_all_vld_grp IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4)
                            AND (  (cv_calc_ent.COLUMN_TYPE = 1 AND cv_calc_ent.FLD_DATA_TYPE = 1)
                                OR (cv_calc_ent.COLUMN_TYPE = 2 AND cv_calc_ent.FLD_DATA_TYPE = 1))
                        THEN 'UPPER('||cv_calc_ent.ENTITY_NAME||')'
                        ELSE cv_calc_ent.ENTITY_NAME END;

            IF (cv_calc_ent.ENTITY_TYPE IN (3, 4))
            THEN
                v_calc_ent_cnt := v_calc_ent_cnt + 1;
            END IF;
        END LOOP;
    ELSIF (pin_validation_list = 2)
    THEN
        po_list_ee_values := '<PREFIX>'||pin_earning_entity;
        po_list_ee_cols := 'EARNING_ENTITY_ID';
        po_entity_join := 'R.'||pin_earning_entity||' = <INPUT>.'||pin_earning_entity;

        FOR cv_calc_ent IN (SELECT  P.ENTITY_NAME, P.ENTITY_ORDER, P.ENTITY_TYPE, P.COLUMN_TYPE
                                   ,ROW_NUMBER() OVER (PARTITION BY CASE WHEN P.ENTITY_TYPE IN (3, 4) THEN 1 ELSE 0 END
                                                        ORDER BY P.ENTITY_ORDER) CALC_ENTITY_ORDER
                                   ,F.FLD_DATA_TYPE
                            FROM   TABLE(pin_earning_calc_ent) P
                                   LEFT JOIN FIELDS F ON P.COLUMN_TYPE = 2 AND P.ENTITY_NAME = F.FLD_COLUMN_NAME
                            ORDER BY P.ENTITY_ORDER)
        LOOP
            po_list_all_values := po_list_all_values
                ||CASE WHEN po_list_all_values IS NOT NULL THEN ', ' ELSE NULL END
                ||'<PREFIX>'||cv_calc_ent.ENTITY_NAME;

            po_list_all_cols := po_list_all_cols
                ||CASE  WHEN po_list_all_cols IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
                        WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4) AND cv_calc_ent.COLUMN_TYPE = 1 THEN 'CALC_ENTITY_'||TO_CHAR(cv_calc_ent.CALC_ENTITY_ORDER)||'_ID'
                        WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4) AND cv_calc_ent.COLUMN_TYPE = 2 THEN 'CALC_ENTITY_'||TO_CHAR(cv_calc_ent.CALC_ENTITY_ORDER)||'_VALUE'
                        ELSE NULL END;

            po_list_all_vld_sel := po_list_all_vld_sel
                ||CASE  WHEN po_list_all_vld_sel IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4)
                            AND cv_calc_ent.COLUMN_TYPE = 2
                            AND cv_calc_ent.FLD_DATA_TYPE = 1
                        THEN 'MAX('||cv_calc_ent.ENTITY_NAME||') KEEP (DENSE_RANK FIRST ORDER BY '||pin_earning_entity||') '||cv_calc_ent.ENTITY_NAME
                        ELSE cv_calc_ent.ENTITY_NAME END;

            po_list_all_vld_grp := po_list_all_vld_grp
                ||CASE  WHEN po_list_all_vld_grp IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE IN (3, 4)
                            AND cv_calc_ent.COLUMN_TYPE = 2
                            AND cv_calc_ent.FLD_DATA_TYPE = 1
                        THEN 'UPPER('||cv_calc_ent.ENTITY_NAME||')'
                        ELSE cv_calc_ent.ENTITY_NAME END;

            IF (cv_calc_ent.ENTITY_TYPE IN (3, 4))
            THEN
                v_calc_ent_cnt := v_calc_ent_cnt + 1;
            END IF;
        END LOOP;
    ELSIF (pin_validation_list = 3)
    THEN
        po_list_ee_values := '<PREFIX>'||pin_payment_entity
            ||CASE WHEN pin_payment_entity <> pin_earning_entity THEN ', <PREFIX>'||pin_earning_entity ELSE NULL END;
        po_list_ee_cols := 'PAYMENT_ENTITY_ID'
            ||CASE WHEN pin_payment_entity <> pin_earning_entity THEN ', EARNING_ENTITY_ID' ELSE NULL END;
        po_entity_join := 'R.'||pin_payment_entity||' = <INPUT>.'||pin_payment_entity
            ||CASE WHEN pin_payment_entity <> pin_earning_entity THEN ' AND R.'||pin_earning_entity||' = <INPUT>.'||pin_earning_entity ELSE NULL END;

        FOR cv_calc_ent IN (SELECT  P.ENTITY_NAME, P.ENTITY_ORDER, P.ENTITY_TYPE, P.COLUMN_TYPE
                                   ,ROW_NUMBER() OVER (PARTITION BY P.ENTITY_TYPE ORDER BY P.ENTITY_ORDER) CALC_ENTITY_ORDER
                                   ,F.FLD_DATA_TYPE
                            FROM   TABLE(pin_payment_calc_ent) P
                                   LEFT JOIN FIELDS F ON P.COLUMN_TYPE = 2 AND P.ENTITY_NAME = F.FLD_COLUMN_NAME
                            WHERE  (P.ENTITY_TYPE <> 1
                                   OR (P.ENTITY_TYPE = 1 AND pin_payment_entity <> pin_earning_entity))
                            ORDER BY P.ENTITY_ORDER)
        LOOP
            po_list_all_values := po_list_all_values
                ||CASE WHEN po_list_all_values IS NOT NULL THEN ', ' ELSE NULL END
                ||'<PREFIX>'||cv_calc_ent.ENTITY_NAME;

            po_list_all_cols := po_list_all_cols
                ||CASE  WHEN po_list_all_cols IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE  WHEN cv_calc_ent.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
                        WHEN cv_calc_ent.ENTITY_TYPE = 2 THEN 'PAYMENT_ENTITY_ID'
                        WHEN cv_calc_ent.ENTITY_TYPE = 4 AND cv_calc_ent.COLUMN_TYPE = 1 THEN 'CALC_ENTITY_'||TO_CHAR(cv_calc_ent.CALC_ENTITY_ORDER)||'_ID'
                        WHEN cv_calc_ent.ENTITY_TYPE = 4 AND cv_calc_ent.COLUMN_TYPE = 2 THEN 'CALC_ENTITY_'||TO_CHAR(cv_calc_ent.CALC_ENTITY_ORDER)||'_VALUE'
                        ELSE NULL END;

            po_list_all_vld_sel := po_list_all_vld_sel
                ||CASE    WHEN po_list_all_vld_sel IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE    WHEN cv_calc_ent.ENTITY_TYPE = 4
                            AND cv_calc_ent.COLUMN_TYPE = 2
                            AND cv_calc_ent.FLD_DATA_TYPE = 1
                        THEN 'MAX('||cv_calc_ent.ENTITY_NAME||') KEEP (DENSE_RANK FIRST ORDER BY '||pin_earning_entity||') '||cv_calc_ent.ENTITY_NAME
                        ELSE cv_calc_ent.ENTITY_NAME END;

            po_list_all_vld_grp := po_list_all_vld_grp
                ||CASE    WHEN po_list_all_vld_grp IS NOT NULL THEN ', ' ELSE NULL END
                ||CASE    WHEN cv_calc_ent.ENTITY_TYPE = 4
                            AND cv_calc_ent.COLUMN_TYPE = 2
                            AND cv_calc_ent.FLD_DATA_TYPE = 1
                        THEN 'UPPER('||cv_calc_ent.ENTITY_NAME||')'
                        ELSE cv_calc_ent.ENTITY_NAME END;

            IF (cv_calc_ent.ENTITY_TYPE = 4)
            THEN
                v_calc_ent_cnt := v_calc_ent_cnt + 1;
            END IF;
        END LOOP;
    END IF;

    -- payments do not have any validations to check for duplicate records
    -- this means the 3040 validation is done for payments only if more than one inputs exist
    IF (pin_validation_list = 3)
    THEN
        SELECT COUNT(*) INTO v_in_cnt
        FROM TABLE(pin_input_table_list)
        WHERE TABLE_TYPE NOT IN (0,1,14,15,30);
    END IF;

    po_input_selection := ',';

    FOR cv_input IN (SELECT T.*, DUP.COLUMN_VALUE AS NO_CHECK_DUP
                    FROM TABLE(pin_input_table_list) T
                         LEFT JOIN TABLE(pin_comp_no_dup_check) DUP ON T.INPUT_NUMBER = DUP.COLUMN_VALUE
                    WHERE T.TABLE_TYPE NOT IN (0,1,14,15,30))
    LOOP
        -- in this case we should always have a coma at the end - to help determine the input number
        -- in order to properly replace "0 I1," with "1 I1," but not also for "0 I10,"
        po_input_selection := po_input_selection||'0 I'||TO_CHAR(cv_input.INPUT_NUMBER)||',';

        po_sum_sql := po_sum_sql
            ||CASE WHEN po_sum_sql IS NOT NULL THEN ', ' ELSE NULL END
            ||'SUM(I'||TO_CHAR(cv_input.INPUT_NUMBER)||') SUM_I'||TO_CHAR(cv_input.INPUT_NUMBER);

        -- 2030 validation is done for components only if the inputs are not other components with a lower frequency
        -- which require aggregation on multiple periods
        IF (   (pin_validation_list = 1 AND (  (cv_input.TABLE_TYPE = 2 AND pin_metric_check_dups = 1)
                                            OR  cv_input.TABLE_TYPE <> 2))
            OR (pin_validation_list = 2 AND cv_input.NO_CHECK_DUP IS NULL))
        THEN
            po_when_sql := po_when_sql
                ||CASE WHEN po_when_sql IS NOT NULL THEN CHR(10) ELSE NULL END
                ||'WHEN SUM_I'||TO_CHAR(cv_input.INPUT_NUMBER)||' > 1'||CASE WHEN cv_input.TABLE_TYPE NOT IN (2, 12) THEN ' AND MAX_I > 0' ELSE NULL END
                ||' THEN INTO TEMP_PROC_VALIDATION_VALUES ('||po_list_all_cols||', VALIDATION_ID, INPUT_NUMBER)'
                ||' VALUES ('||REGEXP_REPLACE(po_list_all_values, '<PREFIX>', '')
                ||', '||CASE WHEN cv_input.TABLE_TYPE = 2 AND pin_validation_list = 1 THEN '1030'
                             WHEN cv_input.TABLE_TYPE = 2 AND pin_validation_list = 2 THEN '2030'
                             WHEN cv_input.TABLE_TYPE = 12 THEN '2030'
                             WHEN cv_input.TABLE_TYPE = 25 THEN '1230'
                             WHEN cv_input.TABLE_TYPE = 26 THEN '1280'
                             WHEN cv_input.TABLE_TYPE = 27 THEN '1340'
                             ELSE NULL END
                ||', '||TO_CHAR(cv_input.INPUT_NUMBER)||')';
        END IF;

        -- 3040 validation is done for payments only if more than one inputs exist
        -- and if the payment has to be done at an additional level of entities (plan calc entities)
        -- otherwise validations 3010/3015 are sufficient
        IF (   (pin_validation_list = 1 AND cv_input.TABLE_TYPE IN (2, 12))
            OR (pin_validation_list = 2 AND cv_input.TABLE_TYPE IN (2, 12))
           --OR (pin_validation_list = 3 AND cv_input.TABLE_TYPE IN (2, 12) AND v_in_cnt > 1 AND v_calc_ent_cnt > 0) --3040 removed for OF-69902
            )
        THEN
            po_when_sql := po_when_sql
                ||CASE WHEN po_when_sql IS NOT NULL THEN CHR(10) ELSE NULL END
                ||'WHEN SUM_I'||TO_CHAR(cv_input.INPUT_NUMBER)||' = 0 AND MAX_I > 0'
                ||' THEN INTO TEMP_PROC_VALIDATION_VALUES ('||po_list_all_cols||', VALIDATION_ID, INPUT_NUMBER)'
                ||' VALUES ('||REGEXP_REPLACE(po_list_all_values, '<PREFIX>', '')
                ||', '||CASE WHEN pin_validation_list = 1 THEN '1040'
                             WHEN pin_validation_list = 2 THEN '2040'
                             WHEN pin_validation_list = 3 THEN '3040'
                             ELSE NULL END
                ||', '||TO_CHAR(cv_input.INPUT_NUMBER)||')';

            po_max_sql := po_max_sql
                ||CASE WHEN po_max_sql IS NOT NULL THEN ' + ' ELSE NULL END
                ||'MAX(I'||TO_CHAR(cv_input.INPUT_NUMBER)||')';
        END IF;
    END LOOP;
END BUILD_HELPFUL_CLAUSES;
  -- ############################# BUILD_HELPFUL_CLAUSES END #############################

  -- ############################# VALIDATE_INPUTS START #############################
FUNCTION VALIDATE_INPUTS
(  pin_input_table_list         IN TABLETYPE_INPUT_TABLE_LIST
    ,pin_validation_list          IN NUMBER
    ,pin_earning_entity           IN VARCHAR2
    ,pin_payment_entity           IN VARCHAR2
    ,pin_metric_calc_ent          IN TABLETYPE_CPM_ENTITIES
    ,pin_earning_calc_ent         IN TABLETYPE_CPM_ENTITIES
    ,pin_payment_calc_ent           IN TABLETYPE_CPM_ENTITIES
    ,pin_check_duplicates         IN NUMBER
    ,pin_definition_id              IN NUMBER
    ,pin_use_input_earn_ent_only    IN NUMBER DEFAULT 0
    ,pin_input_definitions          IN TABLETYPE_NUMBER DEFAULT NULL
    ,pin_curr_processing_period     IN NUMBER DEFAULT NULL
    ,pin_vld_table_name             IN VARCHAR2 DEFAULT NULL
) RETURN NUMBER IS
    v_stamp           VARCHAR2(250);
    v_comp_roster_table         RTYPE_TABLE_LIST;
    v_comp_roster_table_exists  NUMBER := 0;
    v_input_table_list          TABLETYPE_INPUT_TABLE_LIST;
    v_comp_no_dup_check         TABLETYPE_NUMBER;
    v_hint_loc                  VARCHAR2(2000 CHAR);
    v_hint                      VARCHAR2(2000 CHAR);
    v_hint_loc1                 VARCHAR2(2000 CHAR);
    v_hint1                     VARCHAR2(2000 CHAR);
    v_qb_name                   VARCHAR2(2000 CHAR);
    v_qb_name1                  VARCHAR2(2000 CHAR);
    v_roster_count        NUMBER(10);
    v_input_count       NUMBER(10);
    v_row_cnt         NUMBER;
    v_proc_vld_cnt              NUMBER;
    v_temp_string               VARCHAR2(32000 CHAR);
    v_sql           CLOB;
    v_dup_sql             CLOB;
    v_roster_inputs_sql     CLOB;
    v_in_entity_sql       CLOB;
    v_hlp_list_ee_cols      CLOB;
    v_hlp_list_ee_values    CLOB;
    v_hlp_list_all_cols     CLOB;
    v_hlp_list_all_values   CLOB;
    v_hlp_list_all_vld_sel    CLOB;
    v_hlp_list_all_vld_grp    CLOB;
    v_hlp_entity_join     CLOB;
    v_hlp_input_selection   CLOB;
    v_tmp_input_selection   VARCHAR2(2000 CHAR);
    v_hlp_sum_sql       CLOB;
    v_hlp_max_sql       CLOB;
    v_hlp_when_sql        CLOB;
    v_hlp_union_all_from_sql  CLOB;
BEGIN
  v_stamp := 'COMPENSATION_PROCESSING.VALIDATE_INPUTS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
  v_proc_vld_cnt := 0;

  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_input_table_list),    ',pin_input_table_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_validation_list),       ',pin_validation_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_earning_entity),      ',pin_earning_entity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_payment_entity),      ',pin_payment_entity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_metric_calc_ent),     ',pin_metric_calc_ent => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_earning_calc_ent),    ',pin_earning_calc_ent => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_payment_calc_ent),    ',pin_payment_calc_ent => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_check_duplicates),      ',pin_check_duplicates => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_definition_id),         ',pin_definition_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_use_input_earn_ent_only), ',pin_use_input_earn_ent_only => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_input_definitions),   ',pin_input_definitions => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_curr_processing_period),  ',pin_curr_processing_period => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_vld_table_name),      ',pin_vld_table_name => <value>', v_stamp);
    END;

  -- validate input parameters
  BEGIN
    SELECT COUNT(1) INTO v_roster_count
    FROM TABLE(pin_input_table_list)
    WHERE (TABLE_TYPE IN (0,14) AND pin_validation_list IN (1,2))
      OR (TABLE_TYPE IN (0,14) AND pin_validation_list IN (3) AND pin_earning_entity = pin_payment_entity)
      OR (TABLE_TYPE IN (1,15) AND pin_validation_list IN (3) AND pin_earning_entity != pin_payment_entity)
            AND ROWNUM <= 1;

    SELECT COUNT(1) INTO v_input_count
    FROM TABLE(pin_input_table_list)
    WHERE TABLE_TYPE = 2
        AND ROWNUM <= 1;

    IF    (v_roster_count = 0)          THEN raise_application_error(-20001, 'The roster table was not sent in pin_input_table_list.');
    ELSIF (v_input_count = 0)           THEN raise_application_error(-20001, 'At least one input should be sent in pin_input_table_list.');
    ELSIF (pin_validation_list NOT IN (1,2,3))  THEN raise_application_error(-20001, 'The validation set asked should be 1,2 or 3.');
    ELSIF (pin_earning_entity IS NULL)      THEN raise_application_error(-20001, 'The earning entity column was not sent pin_earning_entity.');
    ELSIF (pin_validation_list = 3 AND pin_payment_entity IS NULL) THEN raise_application_error(-20001, 'The payment entity column was not sent pin_payment_entity.');
    END IF;
  END;

    IF (pin_validation_list = 2)
    THEN
        COMPENSATION_PROCESSING.GROUP_PERIODS_FOR_INPUT(pin_input_table_list     => pin_input_table_list
                                                       ,pin_earning_calc_ent     => pin_earning_calc_ent
                                                       ,pin_input_values_columns => NULL
                                                       ,pout_dups_found          => v_comp_no_dup_check
                                                       ,pout_input_table_list    => v_input_table_list);
    ELSE
        v_input_table_list := pin_input_table_list;
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(v_input_table_list) ,'v_input_table_list => <value>', v_stamp);

    COMPENSATION_PROCESSING.BUILD_HELPFUL_CLAUSES
    (    pin_input_table_list   => v_input_table_list
        ,pin_validation_list    => pin_validation_list
        ,pin_earning_entity     => pin_earning_entity
        ,pin_payment_entity     => pin_payment_entity
        ,pin_metric_calc_ent    => pin_metric_calc_ent
        ,pin_earning_calc_ent   => pin_earning_calc_ent
        ,pin_payment_calc_ent   => pin_payment_calc_ent
        ,pin_metric_check_dups  => pin_check_duplicates
        ,pin_comp_no_dup_check  => v_comp_no_dup_check
        ,po_list_ee_values      => v_hlp_list_ee_values
        ,po_list_ee_cols        => v_hlp_list_ee_cols
        ,po_list_all_values     => v_hlp_list_all_values
        ,po_list_all_cols       => v_hlp_list_all_cols
        ,po_list_all_vld_sel    => v_hlp_list_all_vld_sel
        ,po_list_all_vld_grp    => v_hlp_list_all_vld_grp
        ,po_entity_join         => v_hlp_entity_join
        ,po_input_selection     => v_hlp_input_selection
        ,po_sum_sql             => v_hlp_sum_sql
        ,po_when_sql            => v_hlp_when_sql
        ,po_max_sql             => v_hlp_max_sql
    );

    FOR cv_comp_roster IN (SELECT * FROM TABLE(v_input_table_list) WHERE TABLE_TYPE = 30)
  LOOP
        v_comp_roster_table_exists := 1;
        v_comp_roster_table := cv_comp_roster;
  END LOOP;

  -- build the roster clause
  FOR cv_roster IN (SELECT * FROM TABLE(v_input_table_list)
          WHERE (TABLE_TYPE IN (0,14) AND pin_validation_list IN (1,2))
            OR (TABLE_TYPE IN (0,14) AND pin_validation_list IN (3) AND pin_earning_entity = pin_payment_entity)
            OR (TABLE_TYPE IN (1,15) AND pin_validation_list IN (3) AND pin_earning_entity != pin_payment_entity))
  LOOP
        v_qb_name := '/*+ QB_NAME(RST) */';

        v_temp_string := cv_roster.WHERE_CLAUSE;

        IF (cv_roster.TABLE_TYPE IN (1,15))
        THEN
            v_temp_string := v_temp_string||CASE WHEN v_temp_string IS NOT NULL THEN ' AND ' ELSE NULL END
                ||pin_payment_entity||' IS NOT NULL';
        END IF;

        IF (v_comp_roster_table_exists = 1)
        THEN
            v_temp_string := v_temp_string||CASE WHEN v_temp_string IS NOT NULL THEN ' AND ' ELSE NULL END
                ||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id);

            v_temp_string := v_temp_string||CASE WHEN v_comp_roster_table.WHERE_CLAUSE IS NOT NULL THEN ' AND '||v_comp_roster_table.WHERE_CLAUSE ELSE NULL END;
        END IF;

        v_roster_inputs_sql := 'WITH R AS'||CHR(10)
      ||'(SELECT '||v_qb_name||' '||cv_roster.TABLE_NAME||'.* FROM '||cv_roster.TABLE_NAME||CHR(10)
      ||CASE WHEN v_comp_roster_table_exists = 1
                   THEN 'INNER JOIN '||v_comp_roster_table.TABLE_NAME||' '||REPLACE(REPLACE(v_comp_roster_table.FROM_CLAUSE
                                                                                            ,'R.'
                                                                                            ,cv_roster.TABLE_NAME||'.'
                                                                                            )
                                                                                    ,'RC.'
                                                                                    ,v_comp_roster_table.TABLE_NAME||'.')||CHR(10)
                   ELSE NULL END
            ||CASE WHEN v_temp_string IS NOT NULL THEN 'WHERE '||v_temp_string||CHR(10) ELSE NULL END
      ||')'||CHR(10);
  END LOOP;

  -- build the input clauses
  FOR cv_input IN (SELECT * FROM TABLE(v_input_table_list) WHERE TABLE_TYPE NOT IN (0,1,14,15,30))
  LOOP
    -- add input clause
    BEGIN
      v_in_entity_sql := NULL;

      IF (pin_validation_list = 1)
      THEN
        FOR cv_calc_ent IN (SELECT * FROM TABLE(pin_metric_calc_ent)
                  WHERE INPUT_NUMBER = cv_input.INPUT_NUMBER
                  ORDER BY ENTITY_ORDER)
        LOOP
          v_in_entity_sql := v_in_entity_sql
            ||CASE  WHEN v_in_entity_sql IS NOT NULL THEN ', ' ELSE NULL END
            ||CASE  WHEN cv_calc_ent.MAPPING_TYPE = 0     THEN cv_input.TABLE_NAME||'.'||cv_calc_ent.ENTITY_NAME
                WHEN cv_calc_ent.MAPPING_TYPE = 1     THEN cv_calc_ent.ENTITY_TABLE_NAME||'.'||cv_calc_ent.ENTITY_NAME
                WHEN cv_calc_ent.MAPPING_TYPE = 2     THEN cv_input.TABLE_NAME||'.'||cv_calc_ent.ENTITY_FIELD_NAME
                WHEN cv_calc_ent.MAPPING_TYPE = 3     THEN cv_calc_ent.ENTITY_TABLE_NAME||'.'||cv_calc_ent.ENTITY_FIELD_NAME
                WHEN cv_calc_ent.MAPPING_TYPE = 4     THEN cv_calc_ent.ENTITY_TABLE_NAME||'.E_INTERNAL_ID'
                WHEN cv_calc_ent.MAPPING_TYPE = 5     THEN cv_input.TABLE_NAME||'.'||cv_calc_ent.ENTITY_NAME
                ELSE NULL END||' AS '||cv_calc_ent.ENTITY_NAME;
        END LOOP;
      ELSIF (pin_validation_list = 2)
      THEN
        FOR cv_calc_ent IN (SELECT * FROM TABLE(pin_earning_calc_ent)
                                    ORDER BY ENTITY_ORDER)
        LOOP
          v_in_entity_sql := v_in_entity_sql
            ||CASE WHEN v_in_entity_sql IS NOT NULL THEN ', ' ELSE NULL END
            ||cv_input.TABLE_NAME||'.'||cv_calc_ent.ENTITY_NAME;
        END LOOP;
      ELSIF (pin_validation_list = 3)
      THEN
                FOR cv_calc_ent IN (SELECT * FROM TABLE(pin_payment_calc_ent)
                                    WHERE (ENTITY_TYPE <> 1
                                          OR (ENTITY_TYPE = 1 AND pin_payment_entity <> pin_earning_entity))
                                    ORDER BY ENTITY_ORDER)
        LOOP
                    v_in_entity_sql := v_in_entity_sql
                        ||CASE WHEN v_in_entity_sql IS NOT NULL THEN ', ' ELSE NULL END
                        ||cv_input.TABLE_NAME||'.'||cv_calc_ent.ENTITY_NAME;
                END LOOP;
      END IF;

      v_qb_name := '/*+ QB_NAME(I'||cv_input.INPUT_NUMBER||') */';
            v_roster_inputs_sql := v_roster_inputs_sql||',I'||cv_input.INPUT_NUMBER||' AS'||CHR(10)
        ||'(SELECT '||v_qb_name||' '||v_in_entity_sql||CHR(10)
        ||'FROM '
        ||CASE WHEN cv_input.FROM_CLAUSE IS NOT NULL THEN cv_input.FROM_CLAUSE ELSE cv_input.TABLE_NAME END||CHR(10)
        ||CASE WHEN cv_input.WHERE_CLAUSE IS NOT NULL THEN 'WHERE '||cv_input.WHERE_CLAUSE||CHR(10) ELSE NULL END
        ||')'||CHR(10);
    END;

    -- build any helpful queries for vld 1030, 1040, 2030, 2040, 3040
        v_qb_name := '/*+ QB_NAME(VDUP_I'||cv_input.INPUT_NUMBER||') */';
        v_tmp_input_selection := REGEXP_REPLACE(v_hlp_input_selection
                                               ,',0 I'||TO_CHAR(cv_input.INPUT_NUMBER)||','
                                               ,',1 I'||TO_CHAR(cv_input.INPUT_NUMBER)||',');

        v_hlp_union_all_from_sql := v_hlp_union_all_from_sql
            ||CASE WHEN v_hlp_union_all_from_sql IS NOT NULL THEN CHR(10)||'UNION ALL'||CHR(10) ELSE NULL END
            ||'SELECT '||v_qb_name||' '||REGEXP_REPLACE(v_hlp_list_all_values, '<PREFIX>', 'I'||TO_CHAR(cv_input.INPUT_NUMBER)||'.')
            ||', '||SUBSTR(v_tmp_input_selection, 2, LENGTH(v_tmp_input_selection) - 2)
            ||' FROM R INNER JOIN I'||TO_CHAR(cv_input.INPUT_NUMBER)
            ||' ON '||REGEXP_REPLACE(v_hlp_entity_join, '<INPUT>', 'I'||TO_CHAR(cv_input.INPUT_NUMBER));
  END LOOP;

    -- build duplicate query
    IF (v_hlp_when_sql IS NOT NULL)
    THEN
        v_hint_loc :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VDUP' ,pi_proc_id => pin_definition_id);
        v_hint :=                   COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VDUP' ,pi_proc_id => pin_definition_id);
        v_hint_loc1 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VDUP' ,pi_proc_id => pin_definition_id);
        v_hint1 :=                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VDUP' ,pi_proc_id => pin_definition_id);

        v_dup_sql := v_hint_loc||CHR(10)
            ||'INSERT '||v_hint||' ALL'||CHR(10)
            ||v_hlp_when_sql||CHR(10)
            ||v_roster_inputs_sql
            ||v_hint_loc1||CHR(10)
            ||'SELECT '||v_hint1||' '||v_hlp_list_all_vld_sel
            ||', '||v_hlp_sum_sql||', '||v_hlp_max_sql||' MAX_I'||CHR(10)
            ||'FROM'||CHR(10)
            ||'('||v_hlp_union_all_from_sql||CHR(10)
            ||')'||CHR(10)
            ||'GROUP BY '||v_hlp_list_all_vld_grp||CHR(10);
    END IF;

    -- vld 1025 - roster is empty
    -- this validation is not triggered when component rostering is used
    -- we can have components that do not have EE aligned, but the Payment must be processed for other components
    IF (v_comp_roster_table_exists <> 1)
    THEN
        v_hint_loc :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VREMPTY' ,pi_proc_id => pin_definition_id);
        v_hint :=                   COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VREMPTY' ,pi_proc_id => pin_definition_id);
        v_hint_loc1 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VREMPTY' ,pi_proc_id => pin_definition_id);
        v_hint1 :=                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VREMPTY' ,pi_proc_id => pin_definition_id);
        v_qb_name := '/*+ QB_NAME(VREMPTY_RST) */';

        v_sql := v_hint_loc||CHR(10)
            ||'INSERT '||v_hint||' INTO TEMP_PROC_VALIDATION_VALUES (VALIDATION_ID)'||CHR(10)
            ||v_roster_inputs_sql
            ||v_hint_loc1||CHR(10)
            ||'SELECT '||v_hint1||' 1025 FROM DUAL WHERE NOT EXISTS (SELECT '||v_qb_name||' 1 FROM R WHERE ROWNUM = 1)';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', v_stamp);
        EXECUTE IMMEDIATE v_sql;

        v_row_cnt := SQL%ROWCOUNT;
        v_proc_vld_cnt := v_proc_vld_cnt + v_row_cnt;
        COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES',v_proc_vld_cnt);

        IF (v_row_cnt > 0)
        THEN
            RETURN 1;
        END IF;
    END IF;

    IF (pin_use_input_earn_ent_only = 0)
      THEN
        -- vld 1010,2010,3010,3015 - <earning> or <payment + earning> entities that are in roster and are missing in some of the inputs
        IF (pin_validation_list <> 3)  THEN
           FOR cv_input IN (SELECT * FROM TABLE(v_input_table_list) WHERE TABLE_TYPE IN (2, 12))
        LOOP
            v_hint_loc :=   COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VMISS_I'||cv_input.INPUT_NUMBER ,pi_proc_id => pin_definition_id);
            v_hint :=                    COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VMISS_I'||cv_input.INPUT_NUMBER ,pi_proc_id => pin_definition_id);
            v_hint_loc1 :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VMISS_I'||cv_input.INPUT_NUMBER ,pi_proc_id => pin_definition_id);
            v_hint1 :=                   COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VMISS_I'||cv_input.INPUT_NUMBER ,pi_proc_id => pin_definition_id);
            v_qb_name := '/*+ QB_NAME(VMISS_I'||cv_input.INPUT_NUMBER||') */';

            v_sql := v_hint_loc||CHR(10)
                ||'INSERT '||v_hint||' INTO TEMP_PROC_VALIDATION_VALUES ('||v_hlp_list_ee_cols||', VALIDATION_ID, INPUT_NUMBER)'||CHR(10)
                ||v_roster_inputs_sql
                ||v_hint_loc1||CHR(10)
                ||'SELECT '||v_hint1||' '||REGEXP_REPLACE(v_hlp_list_ee_values, '<PREFIX>', 'R.')
                ||', '||CASE  WHEN pin_validation_list = 1 THEN '1010'
                                WHEN pin_validation_list = 2 THEN '2010'
                                WHEN pin_validation_list = 3 AND pin_payment_entity = pin_earning_entity THEN '3010'
                                WHEN pin_validation_list = 3 AND pin_payment_entity <> pin_earning_entity THEN '3015'
                                ELSE NULL END
                ||', '||TO_CHAR(cv_input.INPUT_NUMBER)||CHR(10)
                ||'FROM R WHERE ('||REGEXP_REPLACE(v_hlp_list_ee_values, '<PREFIX>', 'R.')||')'
                ||' NOT IN (SELECT '||v_qb_name||' '||REGEXP_REPLACE(v_hlp_list_ee_values, '<PREFIX>', 'I'||TO_CHAR(cv_input.INPUT_NUMBER)||'.')
                        ||' FROM I'||TO_CHAR(cv_input.INPUT_NUMBER)
                        ||CASE WHEN pin_validation_list = 3 AND pin_payment_entity <> pin_earning_entity THEN ' WHERE '||pin_payment_entity||' IS NOT NULL' ELSE NULL END
                        ||')';

            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', v_stamp);
            EXECUTE IMMEDIATE v_sql;

            v_row_cnt := SQL%ROWCOUNT;
            v_proc_vld_cnt := v_proc_vld_cnt + v_row_cnt;
            COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES',v_proc_vld_cnt);
        END LOOP;
    END IF;



        -- vld 1011,2011,3011 - none of the <earning> or <payment + earning> entities that are in roster have values in all of the inputs

        BEGIN
            IF (pin_validation_list <> 3) THEN
              v_hint_loc :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VMISSALLR' ,pi_proc_id => pin_definition_id);
              v_hint :=                   COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VMISSALLR' ,pi_proc_id => pin_definition_id);
              v_hint_loc1 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VMISSALLR' ,pi_proc_id => pin_definition_id);
              v_hint1 :=                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VMISSALLR' ,pi_proc_id => pin_definition_id);
              v_qb_name := '/*+ QB_NAME(VMISSALLR_RST) */';
              v_qb_name1 := '/*+ QB_NAME(VMISSALLR_TMP) CARDINALITY(V '||v_proc_vld_cnt||') */';

              v_sql := v_hint_loc||CHR(10)
                  ||'INSERT '||v_hint||' INTO TEMP_PROC_VALIDATION_VALUES (VALIDATION_ID)'||CHR(10)
                  ||v_roster_inputs_sql
                  ||v_hint_loc1||CHR(10)
                  ||'SELECT '||v_hint1||' '
                  ||CASE  WHEN pin_validation_list = 1 THEN '1011'
                          WHEN pin_validation_list = 2 THEN '2011'
                          WHEN pin_validation_list = 3 THEN '3011' END
                  ||' FROM DUAL WHERE NOT EXISTS (SELECT '||v_qb_name||' 1 FROM R'
                  ||' WHERE (R.'||CASE WHEN pin_validation_list IN (1, 2) THEN pin_earning_entity
                                       WHEN pin_validation_list = 3 THEN pin_payment_entity

                                       ELSE NULL END||')'
                  ||' NOT IN (SELECT '||v_qb_name1||' '||CASE WHEN pin_validation_list IN (1, 2) THEN 'EARNING_ENTITY_ID'
                                                                             WHEN pin_validation_list = 3 THEN 'PAYMENT_ENTITY_ID'

                                                                             ELSE NULL END
                            ||' FROM TEMP_PROC_VALIDATION_VALUES V) AND ROWNUM = 1)';

              L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', v_stamp);
              EXECUTE IMMEDIATE v_sql;

              v_row_cnt := SQL%ROWCOUNT;
              v_proc_vld_cnt := v_proc_vld_cnt + v_row_cnt;
              COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES',v_proc_vld_cnt);

              IF (v_row_cnt > 0)


              THEN
                  RETURN 1;
              END IF;
            END IF;
        END;

        -- missing or duplicate metric / earning calculation entities
        -- vld 1030, 1040 - metric inputs
        -- vld 2030, 2040 - component inputs
        -- vld 1230, 1280, 1340 - modifier inputs
        -- vld 3040 - payment inputs
        IF (v_dup_sql IS NOT NULL)
        THEN
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_dup_sql),'v_dup_sql := <value>', v_stamp);
            EXECUTE IMMEDIATE v_dup_sql;

            v_row_cnt := SQL%ROWCOUNT;
            v_proc_vld_cnt := v_proc_vld_cnt + v_row_cnt;
            COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES',v_proc_vld_cnt);
        END IF;
    ELSIF (pin_use_input_earn_ent_only = 1
           OR v_comp_roster_table_exists = 1)
    THEN
        -- missing or duplicate metric / earning calculation entities
        -- vld 1030, 1040 - metric inputs
        -- vld 2030, 2040 - component inputs
        -- vld 1230, 1280, 1340 - modifier inputs
        IF (pin_validation_list IN (1, 2) AND v_dup_sql IS NOT NULL)
        THEN
            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_dup_sql),'v_dup_sql := <value>', v_stamp);
            EXECUTE IMMEDIATE v_dup_sql;

            v_row_cnt := SQL%ROWCOUNT;
            v_proc_vld_cnt := v_proc_vld_cnt + v_row_cnt;
            COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES',v_proc_vld_cnt);
        END IF;

        -- 2850, 3850, 3855 take values from input definitions
        IF (pin_validation_list = 2)
        THEN
            v_hint_loc :=  COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VTAKEPRE' ,pi_proc_id => pin_definition_id);
            v_hint :=                   COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'INS_VTAKEPRE' ,pi_proc_id => pin_definition_id);
            v_hint_loc1 := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VTAKEPRE' ,pi_proc_id => pin_definition_id);
            v_hint1 :=                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.VALIDATE_INPUTS' ,pi_hint_id => 'SEL_VTAKEPRE' ,pi_proc_id => pin_definition_id);

            v_sql := v_hint_loc||CHR(10)
                ||'INSERT '||v_hint||' INTO TEMP_PROC_VALIDATION_VALUES ('||v_hlp_list_ee_cols||', VALIDATION_ID, VALIDATION_DETAILS)'||CHR(10)
                ||v_roster_inputs_sql
                ||v_hint_loc1||CHR(10)
                ||'SELECT '||v_hint1||' '||REGEXP_REPLACE(v_hlp_list_ee_values, '<PREFIX>', 'R.')
                ||', '||CASE  WHEN pin_validation_list = 2 THEN '2850'
                                WHEN pin_validation_list = 3 AND pin_payment_entity = pin_earning_entity THEN '3850'
                                WHEN pin_validation_list = 3 AND pin_payment_entity <> pin_earning_entity THEN '3855'
                                ELSE NULL END
                ||', TO_CHAR(V.DEFINITION_ID)'||CHR(10)
                ||'FROM R INNER JOIN '||pin_vld_table_name||' V ON V.PERIOD_ID = :INPUT_PERIOD AND V.EARNING_ENTITY_ID = R.'||pin_earning_entity||CHR(10)
                ||'INNER JOIN (SELECT COLUMN_VALUE AS DEFINITION_ID FROM TABLE(:INPUT_DEFINITIONS)) D ON V.DEFINITION_ID = D.DEFINITION_ID';

            L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', v_stamp);
            EXECUTE IMMEDIATE v_sql USING pin_curr_processing_period, pin_input_definitions;

            v_row_cnt := SQL%ROWCOUNT;
            v_proc_vld_cnt := v_proc_vld_cnt + v_row_cnt;
            COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES',v_proc_vld_cnt);
        END IF;
    END IF;

    RETURN 0;
EXCEPTION
WHEN OTHERS THEN
  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
  RAISE;
END VALIDATE_INPUTS;
  -- ############################# VALIDATE_INPUTS END #############################

  -- ############################# GET_PROC_VALIDATIONS_RESULTS START #############################
FUNCTION GET_PROC_VALIDATIONS_RESULTS
(  pin_values_returned    IN NUMBER
  ,pin_validation_list    IN NUMBER
  ,pin_metric_rejected_table  IN VARCHAR2
  ,pin_ece_ent        IN TABLETYPE_CPM_ENTITIES
    ,pin_payment_include_ee     IN NUMBER
    ,pin_definition_id          IN NUMBER
    ,pin_mod_apply_option   IN NUMBER DEFAULT 2
) RETURN SYS_REFCURSOR
IS
  c_error_count       NUMBER(10) := 200;
  v_stamp           VARCHAR2(200);
    v_mod_apply_option    NUMBER;
    v_proc_vld_cnt          NUMBER;
    v_proc_hint_loc         VARCHAR2(2000 CHAR);
  v_proc_hint             VARCHAR2(2000 CHAR);
    v_metric_vld_cnt        NUMBER;
    v_metric_hint_loc       VARCHAR2(2000 CHAR);
  v_metric_hint           VARCHAR2(2000 CHAR);
    v_mod_vld_cnt           NUMBER;
    v_mod_hint_loc          VARCHAR2(2000 CHAR);
  v_mod_hint              VARCHAR2(2000 CHAR);
    v_pay_vld_cnt           NUMBER;
    v_pay_hint_loc          VARCHAR2(2000 CHAR);
  v_pay_hint              VARCHAR2(2000 CHAR);
    v_metric_prefix       VARCHAR2(50 CHAR);
  v_metric_cols       VARCHAR2(2000 CHAR);
  v_modifier_mce_cols     VARCHAR2(2000 CHAR);
    v_modifier_comp_cols    VARCHAR2(2000 CHAR);
  v_ee_col          VARCHAR2(2000 CHAR);
  v_pe_col          VARCHAR2(2000 CHAR);
  v_pece_cols             VARCHAR2(2000 CHAR);
    v_ppce_cols             VARCHAR2(2000 CHAR);
  v_cols            VARCHAR2(2000 CHAR);
  v_ee_from         VARCHAR2(32000 CHAR);
  v_pe_from         VARCHAR2(32000 CHAR);
  v_pe_from_2         VARCHAR2(32000 CHAR);
    v_from            VARCHAR2(32000 CHAR);
  v_input_rec_vld_sql     CLOB;
  v_metric_vld_sql      CLOB;
  v_payment_vld_sql     CLOB;
  v_modifier_vld_sql      CLOB;
  v_sql           CLOB;
  v_vld_results       SYS_REFCURSOR;
BEGIN
  v_stamp := 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_values_returned),     ',pin_values_returned => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_validation_list),     ',pin_validation_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metric_rejected_table), ',pin_metric_rejected_table => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ece_ent),       ',pin_ece_ent => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_payment_include_ee),      ',pin_payment_include_ee => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_mod_apply_option),      ',pin_mod_apply_option => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_definition_id),     ',pin_definition_id => <value>', v_stamp);
  END;

    v_mod_apply_option := NVL(pin_mod_apply_option, 2);

  -- depending on the table used in metrics, find out the prefix of it's columns
  IF (pin_validation_list = 1)
  THEN
    v_metric_prefix := CASE pin_metric_rejected_table
                WHEN 'TEMP_METRIC_VALUES_REJECTED'  THEN 'MV'
                WHEN 'TEMP_METRIC_AGG_REJECTED'   THEN 'MA'
                WHEN 'TEMP_METRIC_LOOKUP_REJECTED'  THEN 'ML'
                WHEN 'TEMP_METRIC_RANKS_REJECTED' THEN 'MRA'
                WHEN 'TEMP_METRIC_RATIO_REJECTED' THEN 'MR'
                WHEN 'TEMP_METRIC_STATS_REJECTED' THEN 'MS'
                WHEN 'TEMP_METRIC_GA_REJECTED'    THEN 'MGA'
                ELSE NULL END;
  END IF;

    --==LEGEND=========================================
    --<EE>      - the validation should log a list of distinct earning entities
    --<PECE>    - the validation should log a list of distinct plan calculation entities - includes earning entity + additional plan calculation fields/ent
    --<MCE>     - the validation should log a list of distinct metric calculation entities - includes earning entity + additional plan calculation fields/ent + metric specific fields/ent
    --<ECE>     - the validation should log a list of distinct earning calculation entities - includes earning entity + additional plan calculation fields/ent + component specific fields/ent
    --<PE>      - the validation should log a list of distinct payment entities
    --<EE+PE>   - the validation should log a list of distinct pairs of earning entities + payment entities
    --<PECE+PE> - the validation should log a list of distinct pairs of plan calculation entities + payment entities
    --<PPCE>    - the validation should log a list of distinct payment calculation entities - includes payment entity + additional plan calculation fields/ent + earning entity if selected
    --=================================================

  -- first determine the EE and the PE (if exists) entities
  -- depending on the validation, we must either log:
    -- 1. only the EE / EE+PE
  -- 2. the entire list of MCE/ECE sent (which is calculated in the next block)
    -- 3. only PECE - plan calculation entities - see on confluence the list of compensation validations
  FOR c IN (SELECT * FROM TABLE(pin_ece_ent) WHERE ENTITY_TYPE IN (1, 2))
  LOOP
    IF (c.ENTITY_TYPE = 1)
    THEN
      v_ee_col := 'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';
      v_ee_from := ' INNER JOIN '||c.ENTITY_TABLE_NAME||' ON I.EARNING_ENTITY_ID = '||c.ENTITY_TABLE_NAME||'.E_INTERNAL_ID';
    ELSIF (c.ENTITY_TYPE = 2)
    THEN
      v_pe_col := 'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';
      v_pe_from := ' INNER JOIN '||c.ENTITY_TABLE_NAME||' ON I.PAYMENT_ENTITY_ID = '||c.ENTITY_TABLE_NAME||'.E_INTERNAL_ID';
      v_pe_from_2 := ' INNER JOIN '||c.ENTITY_TABLE_NAME||' ON I.PAYMENT_ENTITY = '||c.ENTITY_TABLE_NAME||'.E_INTERNAL_ID';
    END IF;
  END LOOP;

    IF (pin_validation_list = 1)
    THEN
        FOR c IN (SELECT ENTITY_NAME,ENTITY_ORDER,ENTITY_TYPE,COLUMN_TYPE,ENTITY_TABLE_NAME,ENTITY_FIELD_NAME
              ,ROW_NUMBER() OVER (PARTITION BY CASE WHEN ENTITY_TYPE IN (3, 4) THEN 1 ELSE 0 END
                                        ORDER BY ENTITY_ORDER) CALC_ENTITY_ORDER
              FROM TABLE(pin_ece_ent)
                    ORDER BY ENTITY_ORDER)
      LOOP
            -- metric columns (all MCE) that will be taken from TEMP_PROC_VALIDATION_VALUES
            IF (c.ENTITY_TYPE = 1)
      THEN
        v_cols := v_cols||CASE WHEN v_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';

        v_from := v_from||' INNER JOIN '||c.ENTITY_TABLE_NAME||' ON I.EARNING_ENTITY_ID = '||c.ENTITY_TABLE_NAME||'.E_INTERNAL_ID';
      ELSE
        v_cols := v_cols||CASE WHEN v_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'I.CALC_ENTITY_'||TO_CHAR(c.CALC_ENTITY_ORDER)||'_VALUE';
      END IF;

            -- metric columns (all MCE) stored in the appropriate TEMP_METRIC_...._REJECTED table
            v_metric_cols := v_metric_cols||CASE WHEN v_metric_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
                ||CASE  WHEN c.ENTITY_TYPE = 1 THEN 'I.'||v_metric_prefix||'_EARNINGS_ENTITY_BK'
                        WHEN c.ENTITY_TYPE IN (3, 4) THEN 'I.'||v_metric_prefix||'_METRIC_CALC_ENTITY_NAME_'||TO_CHAR(c.CALC_ENTITY_ORDER)
                        ELSE NULL END;

            -- metric modifiers columns (all MCE) stored in TEMP_MODIFIERS_REJECTED_TABLE
            v_modifier_mce_cols := v_modifier_mce_cols||CASE WHEN v_modifier_mce_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
                ||'I.ENTITY_'||TO_CHAR(c.ENTITY_ORDER);
        END LOOP;
    ELSIF (pin_validation_list = 2)
    THEN
        FOR c IN (SELECT ENTITY_NAME,ENTITY_ORDER,ENTITY_TYPE,COLUMN_TYPE,ENTITY_TABLE_NAME,ENTITY_FIELD_NAME
              ,ROW_NUMBER() OVER (PARTITION BY CASE WHEN ENTITY_TYPE IN (3, 4) THEN 1 ELSE 0 END
                                        ORDER BY ENTITY_ORDER) CALC_ENTITY_ORDER
                  FROM TABLE(pin_ece_ent)
                  ORDER BY ENTITY_ORDER)
      LOOP
            -- component columns (all ECE) that will be taken from TEMP_PROC_VALIDATION_VALUES
            IF (c.ENTITY_TYPE = 1
        OR (c.ENTITY_TYPE IN (3, 4) AND c.COLUMN_TYPE = 1))
      THEN
        v_cols := v_cols||CASE WHEN v_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';

        v_from := v_from||CASE  WHEN c.ENTITY_TYPE = 1 THEN ' INNER'
                    ELSE ' LEFT' END
          ||' JOIN '||c.ENTITY_TABLE_NAME
          ||' ON I.'||CASE  WHEN c.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
                    ELSE 'CALC_ENTITY_'||TO_CHAR(c.CALC_ENTITY_ORDER)||'_ID' END
          ||' = '||c.ENTITY_TABLE_NAME||'.E_INTERNAL_ID';
      ELSE
        v_cols := v_cols||CASE WHEN v_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'I.CALC_ENTITY_'||TO_CHAR(c.CALC_ENTITY_ORDER)||'_VALUE';
      END IF;

            -- some of the validations (other than modifiers) are done after aggregating records at the PECE level
            IF (c.ENTITY_TYPE IN (1, 4))
            THEN
                -- component columns (only PECE) that will be taken from TEMP_PROC_VALIDATION_VALUES
                IF (c.COLUMN_TYPE = 1)
                THEN
                    v_pece_cols := v_pece_cols||CASE WHEN v_pece_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
              ||'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';
                ELSE
                    v_pece_cols := v_pece_cols||CASE WHEN v_pece_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
              ||'I.CALC_ENTITY_'||TO_CHAR(c.CALC_ENTITY_ORDER)||'_VALUE';
                END IF;
            END IF;

            -- if modifiers are applied before aggregation take all ECE columns from TEMP_MODIFIERS_REJECTED_TABLE
            -- if modifiers are applied after aggregation take only PECE columns from TEMP_MODIFIERS_REJECTED_TABLE
            IF (    v_mod_apply_option = 1
                OR (v_mod_apply_option = 2 AND c.ENTITY_TYPE IN (1, 4)))
            THEN
                v_modifier_comp_cols := v_modifier_comp_cols||CASE WHEN v_modifier_comp_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
                    ||'I.ENTITY_'||TO_CHAR(c.ENTITY_ORDER);
            END IF;
        END LOOP;
    ELSIF (pin_validation_list = 3)
    THEN
        FOR c IN (SELECT ENTITY_NAME,ENTITY_ORDER,ENTITY_TYPE,COLUMN_TYPE,ENTITY_TABLE_NAME,ENTITY_FIELD_NAME
              ,ROW_NUMBER() OVER (PARTITION BY CASE WHEN ENTITY_TYPE = 4 THEN 1 ELSE 0 END
                                            ORDER BY ENTITY_ORDER) CALC_ENTITY_ORDER
                        ,ROW_NUMBER() OVER (PARTITION BY CASE WHEN ENTITY_TYPE = 4 THEN 1
                                                              WHEN ENTITY_TYPE = 1 AND pin_payment_include_ee = 1 THEN 1 ELSE 0 END
                                            ORDER BY CASE WHEN ENTITY_TYPE = 1 THEN 0
                                                          ELSE ENTITY_ORDER END) PAY_VLD_ENTITY_ORDER
                  FROM TABLE(pin_ece_ent)
                  ORDER BY ENTITY_ORDER)
      LOOP
            -- for validations stored in TEMP_PROC_VALIDATION_VALUES at all PECE + PE level
            IF (c.ENTITY_TYPE = 2
                OR (c.ENTITY_TYPE = 1 AND v_ee_col <> v_pe_col)
        OR (c.ENTITY_TYPE = 4 AND c.COLUMN_TYPE = 1))
      THEN
        v_cols := v_cols||CASE WHEN v_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';

        v_from := v_from||CASE  WHEN c.ENTITY_TYPE = 2 THEN ' INNER'
                    ELSE ' LEFT' END
          ||' JOIN '||c.ENTITY_TABLE_NAME
          ||' ON I.'||CASE  WHEN c.ENTITY_TYPE = 2 THEN 'PAYMENT_ENTITY_ID'
                                        WHEN c.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
                    ELSE 'CALC_ENTITY_'||TO_CHAR(c.CALC_ENTITY_ORDER)||'_ID' END
          ||' = '||c.ENTITY_TABLE_NAME||'.E_INTERNAL_ID';
      ELSE
        v_cols := v_cols||CASE WHEN v_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'I.CALC_ENTITY_'||TO_CHAR(c.CALC_ENTITY_ORDER)||'_VALUE';
      END IF;

            -- for validations stored in TEMP_PAYMENT_VALIDATIONS at PPCE level
            IF (c.ENTITY_TYPE = 2)
            THEN
                v_ppce_cols := v_ppce_cols||CASE WHEN v_ppce_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'TO_CHAR('||c.ENTITY_TABLE_NAME||'.'||c.ENTITY_FIELD_NAME||')';
            ELSIF (c.ENTITY_TYPE = 4
                   OR (c.ENTITY_TYPE = 1 AND pin_payment_include_ee = 1))
            THEN
                v_ppce_cols := v_ppce_cols||CASE WHEN v_ppce_cols IS NOT NULL THEN '||'',''||' ELSE NULL END
          ||'I.C'||TO_CHAR(c.PAY_VLD_ENTITY_ORDER);
            END IF;
        END LOOP;
    END IF;

    v_proc_vld_cnt      := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES');
    v_metric_vld_cnt    := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY(pin_metric_rejected_table);
    v_mod_vld_cnt       := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_MODIFIERS_REJECTED_TABLE');
    v_pay_vld_cnt       := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PAYMENT_VALIDATIONS');

  IF (pin_values_returned = 1)
  THEN
        v_proc_hint_loc     := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_PROC' ,pi_proc_id => pin_definition_id);
        v_proc_hint         :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_PROC' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(O '||v_proc_vld_cnt||')');

        v_metric_hint_loc   := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_MTR' ,pi_proc_id => pin_definition_id);
        v_metric_hint       :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_MTR' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(O '||v_metric_vld_cnt||')');

        v_mod_hint_loc      := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_MOD' ,pi_proc_id => pin_definition_id);
        v_mod_hint          :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_MOD' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(O '||v_mod_vld_cnt||')');

        v_pay_hint_loc      := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_PAY' ,pi_proc_id => pin_definition_id);
        v_pay_hint          :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V1_PAY' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(O '||v_pay_vld_cnt||')');

        v_input_rec_vld_sql := CHR(10)||v_proc_hint_loc||' SELECT '||v_proc_hint||'
         VALIDATION_ID
        ,INPUT_NUMBER
        ,VALIDATION_DETAILS
        ,COUNT(*) TOTAL_ROW_CNT
        ,CAST(MULTISET(SELECT /*+ QB_NAME(PROC_AGG) CARDINALITY(I '||v_proc_vld_cnt||') */ <SELECT_CLAUSE>
                FROM TEMP_PROC_VALIDATION_VALUES I'||v_from||'
                WHERE I.VALIDATION_ID = O.VALIDATION_ID
                  AND NVL(I.INPUT_NUMBER, -1) = NVL(O.INPUT_NUMBER, -1)
                  AND NVL(I.VALIDATION_DETAILS, CHR(0)) = NVL(O.VALIDATION_DETAILS, CHR(0))
                  AND ROWNUM <= '||TO_CHAR(c_error_count)||'
                ) AS TABLETYPE_CHARMAX) VALIDATION_LOGS
      FROM TEMP_PROC_VALIDATION_VALUES O
      GROUP BY VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS';

        v_modifier_vld_sql := CHR(10)||v_mod_hint_loc||' SELECT '||v_mod_hint||'
         VALIDATION_ID
        ,INPUT_NUMBER
        ,VALIDATION_DETAILS
        ,COUNT(*) TOTAL_ROW_CNT
        ,CAST(MULTISET(SELECT /*+ QB_NAME(MOD_AGG) CARDINALITY(I '||v_mod_vld_cnt||') */ <SELECT_CLAUSE>
                FROM TEMP_MODIFIERS_REJECTED_TABLE I
                WHERE I.VALIDATION_ID = O.VALIDATION_ID
                  AND NVL(I.INPUT_NUMBER, -1) = NVL(O.INPUT_NUMBER, -1)
                  AND NVL(I.VALIDATION_DETAILS, CHR(0)) = NVL(O.VALIDATION_DETAILS, CHR(0))
                  AND ROWNUM <= '||TO_CHAR(c_error_count)||'
                ) AS TABLETYPE_CHARMAX) VALIDATION_LOGS
      FROM TEMP_MODIFIERS_REJECTED_TABLE O
      GROUP BY VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS';

        v_metric_vld_sql := CHR(10)||v_metric_hint_loc||' SELECT '||v_metric_hint||'
         VALIDATION_ID
        ,INPUT_NUMBER
        ,VALIDATION_DETAILS
        ,COUNT(*) TOTAL_ROW_CNT
        ,CAST(MULTISET(SELECT /*+ QB_NAME(MTR_AGG) CARDINALITY(I '||v_metric_vld_cnt||') */ CASE WHEN I.VALIDATION_ID IN (1081, 1120) THEN I.'||v_metric_prefix||'_EARNINGS_ENTITY_BK ELSE '||v_metric_cols||' END
                FROM '||pin_metric_rejected_table||' I
                WHERE I.VALIDATION_ID = O.VALIDATION_ID
                  AND NVL(I.INPUT_NUMBER, -1) = NVL(O.INPUT_NUMBER, -1)
                  AND NVL(I.VALIDATION_DETAILS, CHR(0)) = NVL(O.VALIDATION_DETAILS, CHR(0))
                  AND ROWNUM <= '||TO_CHAR(c_error_count)||'
                ) AS TABLETYPE_CHARMAX) VALIDATION_LOGS
      FROM '||pin_metric_rejected_table||' O
      GROUP BY VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS';

        v_payment_vld_sql := CHR(10)||v_pay_hint_loc||' SELECT '||v_pay_hint||'
         VALIDATION_TYPE VALIDATION_ID
        ,NULL INPUT_NUMBER
        ,NULL VALIDATION_DETAILS
        ,COUNT(*) TOTAL_ROW_CNT
        ,CAST(MULTISET(SELECT /*+ QB_NAME(PAY_AGG) CARDINALITY(I '||v_pay_vld_cnt||') */ '||v_ppce_cols||'
                FROM TEMP_PAYMENT_VALIDATIONS I'||v_pe_from_2||'
                WHERE I.VALIDATION_TYPE = O.VALIDATION_TYPE
                  AND ROWNUM <= '||TO_CHAR(c_error_count)||'
                ) AS TABLETYPE_CHARMAX) VALIDATION_LOGS
      FROM TEMP_PAYMENT_VALIDATIONS O
      GROUP BY VALIDATION_TYPE';

    IF (pin_validation_list = 1)
    THEN
      v_input_rec_vld_sql := REGEXP_REPLACE(v_input_rec_vld_sql
                      ,'<SELECT_CLAUSE>'
                      ,'DISTINCT CASE WHEN I.VALIDATION_ID IN (1010) THEN '||v_ee_col||' ELSE '||v_cols||' END');

      v_modifier_vld_sql := REGEXP_REPLACE(v_modifier_vld_sql
                      ,'<SELECT_CLAUSE>'
                      ,v_modifier_mce_cols);

      -- take the logged entities from the input records validations
      -- + the logged entities from the validations performed during processing
      -- + the logged entities from the modifiers processing
      v_sql := v_input_rec_vld_sql
          ||CHR(10)||'UNION ALL'||v_metric_vld_sql
          ||CHR(10)||'UNION ALL'||v_modifier_vld_sql;

    ELSIF (pin_validation_list = 2)
    THEN
      v_input_rec_vld_sql := REGEXP_REPLACE(v_input_rec_vld_sql
                      ,'<SELECT_CLAUSE>'
                      ,'DISTINCT CASE WHEN I.VALIDATION_ID IN (2010, 2850) THEN '||v_ee_col
                                                        ||' WHEN I.VALIDATION_ID IN (2610, 2630, 2650, 2670) THEN '||v_pece_cols
                                                        ||' ELSE '||v_cols||' END');

      v_modifier_vld_sql := REGEXP_REPLACE(v_modifier_vld_sql
                      ,'<SELECT_CLAUSE>'
                      ,v_modifier_comp_cols);

      -- take the logged entities from the input records validations
      -- + the logged entities from the validations performed during processing (for components they are saved in the same place as for input recs)
      -- + the logged entities from the modifiers processing
      v_sql := v_input_rec_vld_sql
          ||CHR(10)||'UNION ALL'||v_modifier_vld_sql;

    ELSIF (pin_validation_list = 3)
    THEN
      v_input_rec_vld_sql := REGEXP_REPLACE(v_input_rec_vld_sql
                      ,'<SELECT_CLAUSE>'
                      ,'DISTINCT CASE WHEN I.VALIDATION_ID IN (3010, 3850, 3860) THEN '||v_pe_col
                                                        ||' WHEN I.VALIDATION_ID IN (3015, 3855, 3865) THEN '||v_ee_col||'||'',''||'||v_pe_col
                                                        ||' ELSE '||v_cols||' END');

      -- take the logged entities from the input records validations
      -- + the logged entities from the validations performed during processing
      v_sql := v_input_rec_vld_sql
          ||CHR(10)||'UNION ALL'||v_payment_vld_sql;
    END IF;
  ELSIF (pin_values_returned = 2)
  THEN
    v_proc_hint_loc     := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_PROC' ,pi_proc_id => pin_definition_id);
        v_proc_hint         :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_PROC' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_proc_vld_cnt||')');

        v_metric_hint_loc   := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_MTR' ,pi_proc_id => pin_definition_id);
        v_metric_hint       :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_MTR' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_metric_vld_cnt||')');

        v_mod_hint_loc      := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_MOD' ,pi_proc_id => pin_definition_id);
        v_mod_hint          :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_MOD' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_mod_vld_cnt||')');

        v_pay_hint_loc      := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_PAY' ,pi_proc_id => pin_definition_id);
        v_pay_hint          :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.GET_PROC_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_V2_PAY' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_pay_vld_cnt||')');

        IF (pin_validation_list = 1)
    THEN
      -- take the logged earning entities from the input records validations
      -- + the logged earning entities from the validations performed during processing
      -- + the logged earning entities from the modifiers processing
      v_sql :=                 v_proc_hint_loc  ||CHR(10)||' SELECT '||v_proc_hint  ||' DISTINCT '||v_ee_col||' AS ENTITY FROM TEMP_PROC_VALIDATION_VALUES I'||v_ee_from
        ||CHR(10)||'UNION '||v_metric_hint_loc||CHR(10)||' SELECT '||v_metric_hint||' DISTINCT I.'||v_metric_prefix||'_EARNINGS_ENTITY_BK AS ENTITY FROM '||pin_metric_rejected_table||' I'
        ||CHR(10)||'UNION '||v_mod_hint_loc   ||CHR(10)||' SELECT '||v_mod_hint   ||' DISTINCT I.ENTITY_1 AS ENTITY FROM TEMP_MODIFIERS_REJECTED_TABLE I';

    ELSIF (pin_validation_list = 2)
    THEN
      -- take the logged earning entities from the input records validations
      -- + the logged earning entities from the validations performed during processing (for components they are saved in the same place as for input recs)
      -- + the logged earning entities from the modifiers processing
      v_sql :=                 v_proc_hint_loc||CHR(10)||' SELECT '||v_proc_hint||' DISTINCT '||v_ee_col||' AS ENTITY FROM TEMP_PROC_VALIDATION_VALUES I'||v_ee_from
        ||CHR(10)||'UNION '||v_mod_hint_loc ||CHR(10)||' SELECT '||v_mod_hint ||' DISTINCT I.ENTITY_1 AS ENTITY FROM TEMP_MODIFIERS_REJECTED_TABLE I';

    ELSIF (pin_validation_list = 3)
    THEN
      -- take the logged entities from the input records validations
      -- + the logged entities from the validations performed during processing
      v_sql :=                 v_proc_hint_loc||CHR(10)||' SELECT '||v_proc_hint||' DISTINCT '||v_pe_col||' AS ENTITY FROM TEMP_PROC_VALIDATION_VALUES I'||v_pe_from
        ||CHR(10)||'UNION '||v_pay_hint_loc ||CHR(10)||' SELECT '||v_pay_hint ||' DISTINCT '||v_pe_col||' AS ENTITY FROM TEMP_PAYMENT_VALIDATIONS I'||v_pe_from_2;
    END IF;

        v_sql := 'SELECT * FROM ('||CHR(10)
        ||v_sql||CHR(10)
    --||') WHERE ROWNUM <= '||TO_CHAR(c_error_count);
        ||') ';
        v_sql := 'with T as
      (' ||  v_sql || ')
      SELECT ENTITY, (select count(*) from T) TOTAL_ROW_CNT FROM T WHERE ROWNUM <= 200';

  END IF;

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,'v_sql := <value>;', v_stamp);
  OPEN v_vld_results FOR v_sql;
  RETURN v_vld_results;
EXCEPTION
WHEN OTHERS THEN
  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
  RAISE;
END GET_PROC_VALIDATIONS_RESULTS;
  -- ############################# GET_PROC_VALIDATIONS_RESULTS END #############################

    -- ############################# SAVE_EE_VALIDATIONS_RESULTS START #############################
PROCEDURE SAVE_EE_VALIDATIONS_RESULTS
(  pin_definition_id              IN NUMBER
    ,pin_validation_list            IN NUMBER
    ,pin_metric_rejected_table      IN VARCHAR2
    ,pin_earning_entity         IN VARCHAR2
    ,pin_curr_processing_period     IN NUMBER
    ,pin_input_table_list           IN TABLETYPE_INPUT_TABLE_LIST
    ,pin_vld_table_name             IN VARCHAR2
) IS
    v_stamp           VARCHAR2(200);
    v_metric_prefix       VARCHAR2(50 CHAR);
    v_proc_vld_cnt          NUMBER;
    v_proc_hint_loc         VARCHAR2(2000 CHAR);
  v_proc_hint             VARCHAR2(2000 CHAR);
    v_metric_vld_cnt        NUMBER;
    v_metric_hint_loc       VARCHAR2(2000 CHAR);
  v_metric_hint           VARCHAR2(2000 CHAR);
    v_mod_vld_cnt           NUMBER;
    v_mod_hint_loc          VARCHAR2(2000 CHAR);
  v_mod_hint              VARCHAR2(2000 CHAR);
    v_del_hint_loc          VARCHAR2(2000 CHAR);
  v_del_hint              VARCHAR2(2000 CHAR);
    v_ins_hint_loc          VARCHAR2(2000 CHAR);
  v_ins_hint              VARCHAR2(2000 CHAR);
    v_sel_hint_loc          VARCHAR2(2000 CHAR);
  v_sel_hint              VARCHAR2(2000 CHAR);
    v_roster_sql            CLOB;
  v_sql           CLOB;
BEGIN
  v_stamp := 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

  -- log the input parameters
  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_definition_id),     ',pin_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_validation_list),     ',pin_validation_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_metric_rejected_table), ',pin_metric_rejected_table => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_earning_entity),      ',pin_earning_entity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_curr_processing_period),  ',pin_curr_processing_period => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_input_table_list),  ',pin_input_table_list => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_vld_table_name),      ',pin_vld_table_name => <value>', v_stamp);
  END;

    -- depending on the table used in metrics, find out the prefix of it's columns
  IF (pin_validation_list = 1)
  THEN
    v_metric_prefix := CASE pin_metric_rejected_table
                WHEN 'TEMP_METRIC_VALUES_REJECTED'  THEN 'MV'
                WHEN 'TEMP_METRIC_AGG_REJECTED'   THEN 'MA'
                WHEN 'TEMP_METRIC_LOOKUP_REJECTED'  THEN 'ML'
                WHEN 'TEMP_METRIC_RANKS_REJECTED' THEN 'MRA'
                WHEN 'TEMP_METRIC_RATIO_REJECTED' THEN 'MR'
                WHEN 'TEMP_METRIC_STATS_REJECTED' THEN 'MS'
                WHEN 'TEMP_METRIC_GA_REJECTED'    THEN 'MGA'
                ELSE NULL END;
  END IF;

    -- build the roster clause if necessary
    -- if roster is built with selected records only, we need to delete only those invalid EEs
    FOR cv_roster IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE = 14)
  LOOP
        v_roster_sql := 'SELECT /*+ QB_NAME(RST) */ '||pin_earning_entity||' FROM '||cv_roster.TABLE_NAME
      ||CASE WHEN cv_roster.WHERE_CLAUSE IS NOT NULL THEN ' WHERE '||cv_roster.WHERE_CLAUSE ELSE NULL END;
  END LOOP;

    -- build the validation list
    BEGIN
        v_proc_vld_cnt      := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES');
        v_metric_vld_cnt    := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY(pin_metric_rejected_table);
        v_mod_vld_cnt       := COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_MODIFIERS_REJECTED_TABLE');

        v_proc_hint_loc     := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_PROC' ,pi_proc_id => pin_definition_id);
        v_proc_hint         :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_PROC' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_proc_vld_cnt||')');

        v_metric_hint_loc   := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_MTR' ,pi_proc_id => pin_definition_id);
        v_metric_hint       :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_MTR' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_metric_vld_cnt||')');

        v_mod_hint_loc      := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_MOD' ,pi_proc_id => pin_definition_id);
        v_mod_hint          :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL_MOD' ,pi_proc_id => pin_definition_id ,pi_other_hints => 'CARDINALITY(I '||v_mod_vld_cnt||')');

        IF (pin_validation_list = 1)
        THEN
            -- take the logged earning entities from the input records validations
            -- + the logged earning entities from the validations performed during processing
            -- + the logged earning entities from the modifiers processing
            v_sql :=                 v_proc_hint_loc  ||CHR(10)||' SELECT '||v_proc_hint  ||' DISTINCT EARNING_ENTITY_ID AS ENTITY FROM TEMP_PROC_VALIDATION_VALUES I'
                ||CHR(10)||'UNION '||v_metric_hint_loc||CHR(10)||' SELECT '||v_metric_hint||' DISTINCT '||v_metric_prefix||'_EARNINGS_ENTITY AS ENTITY FROM '||pin_metric_rejected_table||' I'
                ||CHR(10)||'UNION '||v_mod_hint_loc   ||CHR(10)||' SELECT '||v_mod_hint   ||' DISTINCT TO_NUMBER(EARNING_ENTITY_ID) AS ENTITY FROM TEMP_MODIFIERS_REJECTED_TABLE I';

        ELSIF (pin_validation_list = 2)
        THEN
            -- take the logged earning entities from the input records validations
            -- + the logged earning entities from the validations performed during processing (for components they are saved in the same place as for input recs)
            -- + the logged earning entities from the modifiers processing
            v_sql :=                 v_proc_hint_loc||CHR(10)||' SELECT '||v_proc_hint||' DISTINCT EARNING_ENTITY_ID AS ENTITY FROM TEMP_PROC_VALIDATION_VALUES I'
                ||CHR(10)||'UNION '||v_mod_hint_loc ||CHR(10)||' SELECT '||v_mod_hint ||' DISTINCT TO_NUMBER(EARNING_ENTITY_ID) AS ENTITY FROM TEMP_MODIFIERS_REJECTED_TABLE I';
        END IF;
  END;

    v_del_hint_loc := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'DEL' ,pi_proc_id => pin_definition_id);
    v_del_hint     :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'DEL' ,pi_proc_id => pin_definition_id);

    v_ins_hint_loc := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'INS' ,pi_proc_id => pin_definition_id);
    v_ins_hint     :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'INS' ,pi_proc_id => pin_definition_id);

    v_sel_hint_loc := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL' ,pi_proc_id => pin_definition_id);
    v_sel_hint     :=              COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPENSATION_PROCESSING.SAVE_EE_VALIDATIONS_RESULTS' ,pi_hint_id => 'SEL' ,pi_proc_id => pin_definition_id);

    v_sql := '
    DECLARE
        v_def_id        NUMBER(10);
        v_period_id     NUMBER(10);
    BEGIN
        v_def_id := :DEF_ID;
        v_period_id := :PERIOD_ID;

        '||v_del_hint_loc||'
        DELETE '||v_del_hint
        ||' FROM '||pin_vld_table_name||' WHERE DEFINITION_ID = v_def_id AND PERIOD_ID = v_period_id'
        ||CASE WHEN v_roster_sql IS NOT NULL THEN ' AND EARNING_ENTITY_ID IN ('||v_roster_sql||')' ELSE NULL END||';

        '||v_ins_hint_loc||'
        INSERT '||v_ins_hint
        ||' INTO '||pin_vld_table_name||'(DEFINITION_ID, PERIOD_ID, EARNING_ENTITY_ID, ROW_IDENTIFIER, ROW_VERSION)

        '||v_sel_hint_loc||'
        SELECT '||v_sel_hint
              ||' v_def_id as DEFINITION_ID'
              ||',v_period_id AS PERIOD_ID'
              ||',ENTITY AS EARNING_ENTITY_ID'
              ||','||pin_vld_table_name||'_ROW_IDENTIFIER_SEQ.NEXTVAL AS ROW_IDENTIFIER'
              ||',0 AS ROW_VERSION
        FROM (
        '||v_sql||'
        );
    END;';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,'v_sql := <value>;', v_stamp);
    EXECUTE IMMEDIATE v_sql USING pin_definition_id, pin_curr_processing_period;
EXCEPTION
WHEN OTHERS THEN
  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
  RAISE;
END SAVE_EE_VALIDATIONS_RESULTS;
  -- ############################# SAVE_EE_PROC_VALIDATIONS_RESULTS END #############################


  -- ############################# CREATE_TEMPORARY_ROSTER_TABLE #############################
  procedure create_temporary_roster_table(pi_roster_table            in varchar2,
                                          pi_roster_type             in number,
                                          pi_earning_entity_column   in varchar2,
                                          pi_payment_entity_column   in varchar2,
                                          pi_payment_timeunit_column in varchar2,
                                          pi_payment_period_id       in number,
                                          pi_run_id                  in number,
                                          pi_temporary_roster_table  in varchar2,
                                          po_missing_records         out sys_refcursor)
  as
    v_count integer;
  begin
    -- check for records that no longer meet the filter conditions to be in the roster
    if pi_roster_type = 1 then
      execute immediate 'select count(prdd_earning_entity_id) from plan_run_data_details where prdd_prd_id in (select prd_id from plan_run_data where prd_run_id = ' || pi_run_id || ') and not exists (select 1 from ' || pi_roster_table || ' where ' || pi_payment_timeunit_column || ' = ' || pi_payment_period_id || ' and ' || pi_earning_entity_column || ' = prdd_earning_entity_id)  AND ROWNUM <= 1' into v_count;
    elsif pi_roster_type = 2 then
      execute immediate 'select count(prdd_earning_entity_id) from plan_run_data_details where prdd_prd_id in (select prd_id from plan_run_data where prd_run_id = ' || pi_run_id || ') and not exists (select 1 from ' || pi_roster_table || ' where ' || pi_payment_timeunit_column || ' = ' || pi_payment_period_id || ' and ' || pi_earning_entity_column || ' = prdd_earning_entity_id and nvl(' || pi_payment_entity_column || ',0) = nvl(prdd_payment_entity_id,0)) AND ROWNUM <= 1' into v_count;
    end if;
    if v_count = 0 then
      -- create temporary roster table as select all records that meet the filter conditions
      recreate_temp_roster_table(pi_roster_table, pi_roster_type, pi_earning_entity_column, pi_payment_entity_column, pi_payment_timeunit_column, pi_payment_period_id, pi_run_id, pi_temporary_roster_table);
      open po_missing_records for select 1 from dual where 0 = 1;
    else
      -- return records that no longer meet the filter conditions to be in the roster
      if pi_roster_type = 1 then
        open po_missing_records for 'select prdd_earning_business_id from plan_run_data_details where prdd_prd_id in (select prd_id from plan_run_data where prd_run_id = ' || pi_run_id || ') and not exists (select 1 from ' || pi_roster_table || ' where ' || pi_payment_timeunit_column || ' = ' || pi_payment_period_id || ' and ' || pi_earning_entity_column || ' = prdd_earning_entity_id)';
      elsif pi_roster_type = 2 then
        open po_missing_records for 'select prdd_earning_business_id, prdd_payment_business_id from plan_run_data_details where prdd_prd_id in (select prd_id from plan_run_data where prd_run_id = ' || pi_run_id || ') and not exists (select 1 from ' || pi_roster_table || ' where ' || pi_payment_timeunit_column || ' = ' || pi_payment_period_id || ' and ' || pi_earning_entity_column || ' = prdd_earning_entity_id and nvl(' || pi_payment_entity_column || ',0) = nvl(prdd_payment_entity_id,0))';
      end if;
    end if;
  end create_temporary_roster_table;
  -- ############################# CREATE_TEMPORARY_ROSTER_TABLE END #############################

  -- ############################# RECREATE_TEMP_ROSTER_TABLE #############################
  procedure recreate_temp_roster_table(pi_roster_table            in varchar2,
                                       pi_roster_type             in number,
                                       pi_earning_entity_column   in varchar2,
                                       pi_payment_entity_column   in varchar2,
                                       pi_payment_timeunit_column in varchar2,
                                       pi_payment_period_id       in number,
                                       pi_run_id                  in number,
                                       pi_temporary_roster_table  in varchar2)
  as
  begin
    if pi_roster_type = 1 then
      execute immediate 'create table ' || pi_temporary_roster_table || ' as select * from ' || pi_roster_table || ' where ' || pi_payment_timeunit_column || ' = ' || pi_payment_period_id || ' and ' || pi_earning_entity_column || ' in (select prdd_earning_entity_id from plan_run_data_details where prdd_prd_id in (select prd_id from plan_run_data where prd_run_id = ' || pi_run_id || '))';
    elsif pi_roster_type = 2 then
      execute immediate 'create table ' || pi_temporary_roster_table || ' as select * from ' || pi_roster_table || ' where ' || pi_payment_timeunit_column || ' = ' || pi_payment_period_id || ' and (' || pi_earning_entity_column || ', nvl(' || pi_payment_entity_column || ',0)) in (select prdd_earning_entity_id, nvl(prdd_payment_entity_id,0) from plan_run_data_details where prdd_prd_id in (select prd_id from plan_run_data where prd_run_id = ' || pi_run_id || '))';
    end if;
  end recreate_temp_roster_table;
  -- ############################# RECREATE_TEMP_ROSTER_TABLE END #############################

/*-------------------------------------------------------------------------------------
Author     : Dumitriu, Cosmin
Create date: 20140926
---------------------------------------------------------------------------------------*/
FUNCTION GET_TABLE_CARDINALITY
(   pi_table_name VARCHAR2
) RETURN NUMBER AS
    v_rec_cnt NUMBER;
BEGIN
    BEGIN
        SELECT NVL(RECORD_COUNT, 0)
        INTO v_rec_cnt
        FROM TEMP_TABLE_CARDINALITY
        WHERE TABLE_NAME = UPPER(pi_table_name);
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        v_rec_cnt := 0;
        INSERT INTO TEMP_TABLE_CARDINALITY(TABLE_NAME, RECORD_COUNT) VALUES (UPPER(pi_table_name), v_rec_cnt);
    END;

    RETURN v_rec_cnt;
END GET_TABLE_CARDINALITY;

/*-------------------------------------------------------------------------------------
Author     : Dumitriu, Cosmin
Create date: 20140926
---------------------------------------------------------------------------------------*/
PROCEDURE SET_TABLE_CARDINALITY
(    pi_table_name      VARCHAR2
    ,pi_record_count    NUMBER
) AS
BEGIN
    MERGE INTO TEMP_TABLE_CARDINALITY D
    USING (SELECT UPPER(pi_table_name) TABLE_NAME
                 ,NVL(pi_record_count, 0) RECORD_COUNT
           FROM dual) S
    ON (D.TABLE_NAME = S.TABLE_NAME)
    WHEN MATCHED THEN UPDATE SET D.RECORD_COUNT = S.RECORD_COUNT
    WHEN NOT MATCHED THEN INSERT (TABLE_NAME, RECORD_COUNT) VALUES (S.TABLE_NAME, S.RECORD_COUNT);
END SET_TABLE_CARDINALITY;

/*-------------------------------------------------------------------------------------
Author     : Kristo, Robert
Create date: 20150302
---------------------------------------------------------------------------------------*/

PROCEDURE CHECK_PCD_VERNAME_TABLE(pin_input_table  IN CLOB,

                                  pout_return_list OUT NOCOPY TABLETYPE_DT_CHAR)
AS
BEGIN
  EXECUTE IMMEDIATE '
  SELECT CASE
           WHEN SUM(CASE WHEN TAB.PCD_NAME = TT.PCD_NAME AND TAB.VERSIONNAME = TT.VERSIONNAME THEN 1 ELSE 0 END) > 0  THEN
           ''22''
           WHEN SUM(CASE WHEN TAB.PCD_NAME = TT.PCD_NAME THEN 1 ELSE 0 END) > 0 AND SUM(CASE WHEN TAB.VERSIONNAME = TT.VERSIONNAME THEN 1 ELSE 0 END) > 0 THEN
           ''11''
           WHEN SUM(CASE WHEN TAB.PCD_NAME = TT.PCD_NAME THEN 1 ELSE 0 END) > 0 THEN
           ''10''
           WHEN SUM(CASE WHEN TAB.VERSIONNAME = TT.VERSIONNAME THEN 1 ELSE 0 END) > 0 THEN
           ''01''
           ELSE
           ''00''
         END VALIDATE_RESULT
    FROM ' || PIN_INPUT_TABLE || ' TT
    LEFT JOIN (SELECT PCD.PCD_NAME,
                      PD.PD_NAME || CASE
                        WHEN TUPR_START.TUPR_ID IS NULL THEN
                         ''''
                        ELSE
                         '' ('' || TUPR_START.TUPR_PERIOD_RANGE_NAME || '' - '' || CASE
                           WHEN TUPR_END.TUPR_ID IS NULL THEN
                            ''No End Version)''
                           ELSE
                            TUPR_END.TUPR_PERIOD_RANGE_NAME || '')''
                         END
                      END VERSIONNAME
                 FROM PLAN_COMPONENT_DEFINITIONS PCD
                INNER JOIN VERSIONS V
                   ON PCD.PCD_VER_OBJECT_ID = V.VER_OBJECT_ID
                INNER JOIN PLAN_DEFINITIONS PD
                   ON V.VER_BASE_OBJECT_ID = PD.PD_ID
                 LEFT JOIN TU_PERIODS_RANGE TUPR_START
                   ON V.VER_START_TUPR_ID = TUPR_START.TUPR_ID
                 LEFT JOIN TU_PERIODS_RANGE TUPR_END
                   ON V.VER_END_TUPR_ID = TUPR_END.TUPR_ID) TAB
      ON (TT.PCD_NAME = TAB.PCD_NAME
     AND TT.VERSIONNAME = TAB.VERSIONNAME)
      OR (TT.PCD_NAME = TAB.PCD_NAME)
      OR (TT.VERSIONNAME = TAB.VERSIONNAME)
   GROUP BY TT.ROW_IDENTIFIER
   ORDER BY TT.ROW_IDENTIFIER'
 BULK COLLECT INTO pout_return_list;
END;

/*-------------------------------------------------------------------------------------
Author     : Kristo, Robert
Create date: 20150302
---------------------------------------------------------------------------------------*/
PROCEDURE CHECK_PCD_VERNAME_UNION(pin_pcd_version_id IN tabletype_pcd_version_id,

                  pout_validations   OUT NOCOPY TABLETYPE_DT_CHAR)
AS
  v_input_union CLOB;
BEGIN
  -- create select
  FOR i IN 1 .. pin_pcd_version_id.count
  LOOP
    v_input_union := v_input_union || ' UNION ALL
                                        SELECT ''' || pin_pcd_version_id(i).PCD_NAME || ''' AS PCD_NAME,
                                               ''' || pin_pcd_version_id(i).VERSIONNAME || ''' AS VERSIONNAME,
                                               ' || pin_pcd_version_id(i).ROW_IDENTIFIER || ' AS ROW_IDENTIFIER
                                           FROM DUAL ';
  END LOOP;

  -- remove first union all
  v_input_union := '(' || SUBSTR(v_input_union, 11) || ')';

  CHECK_PCD_VERNAME_TABLE(pin_input_Table => v_input_union
                         ,pout_return_list => pout_validations);

END;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END COMPENSATION_PROCESSING;
/
