CREATE package agreements as

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20130130
  -- Description: Display agreements that need to be accepted
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_agreement_type  number  not null  Acceptance agreement type: 1 - logs into portal, 2 - accesses specific views, 3 - accesses specific reports
     pi_user_id         number  not null  Id of the user subject to acceptance
     pi_object_id       number  null      Id of the view subject to acceptance if pi_agreement_type is 2 or of the report list if pi_agreement_type is 3
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_agreements  sys_refcursor  not null  Agreements that need to be accepted
                                             Columns:
                                              - AA_ID   - number - not null - Id of the acceptance agreement
                                              - AA_NAME - varchar2 - not null - Name of the acceptance agreement
                                              - X       - expression - not null - Techinical column used for ordering
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  declare
    l_agreements sys_refcursor;
  begin
    agreements.display_agreements(pi_agreement_type => 1,
                                  pi_user_id        => 8,
                                  pi_object_id      => null,
                                  po_agreements     => l_agreements);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure display_agreements(pi_agreement_type in number,
                               pi_user_id        in number,
                               pi_object_id      in number,
                               po_agreements     out sys_refcursor);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20130222
  -- Description: Filter agreements on report list
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_agreements  TABLETYPE_ID_CONDITION  not null  Collection with the agreements that need to be filtered
                                                      Columns
                                                       - ID                           - NUMBER - not null - id of the agreements
                                                       - CONDITION                    - CLOB   - null     - filter condition
                                                                                                          - we use a hardcoded alias for the report table: "reportTable" || <agreement id>
                                                                                                          - we use a hardcoded alias for the report table: "entityTable" || <agreement id>
                                                       - REPORT_LIST_ENTITY_CONDITION - CLOB   - null     - join conditions with report list entity tables
                                                       - USER_ENTITY_CONDITION        - CLOB   - null     - filter condition for user entities
                                                       - PERIOD_JOIN_CLAUSE           - CLOB   - null     - join condition with period range table
     pi_report_id   number                  not null  Id of the report selected by the user
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_agreements  sys_refcursor  not null  Agreements that need to be accepted
                                             Columns:
                                              - AA_ID   - number - not null - Id of the acceptance agreement
                                              - AA_NAME - varchar2 - not null - Name of the acceptance agreement
                                              - X       - expression - not null - Techinical column used for ordering
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  declare
    l_agreements sys_refcursor;
  begin
    agreements.filter_agreements(pi_agreements => TABLETYPE_ID_CONDITION(OBJTYPE_ID_CONDITION(203529,'reportTable203529.ATTACHMENT_NAME = ''constant''',0,null),
                                                                         OBJTYPE_ID_CONDITION(203639,null,1,null,null,null),
                                                                         OBJTYPE_ID_CONDITION(204454,null,0,null,null,null),
                                                                         OBJTYPE_ID_CONDITION(204564,'ue.email='mymail'',0,null,'(select 'mymail' EMAIL,NULL FULL_NAME from dual) ue',null),
                                                                         OBJTYPE_ID_CONDITION(204674,null,0,null,null,'LEFT OUTER JOIN TU_PERIODS_RANGE Filters_PR_406950354 ON(reportTable5175901.F462 = Filters_PR_406950354.TUPR_ID)')
                                                                         ),
                                 pi_report_id  => 9981,
                                 po_agreements => l_agreements);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure filter_agreements(pi_agreements in TABLETYPE_ID_CONDITION,
                              pi_report_id  in number,
                              po_agreements out sys_refcursor);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20130308
  -- Description: Display reports that need to be accepted
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_agreement_id             number  not null  Id of the acceptance agreement type
     pi_user_id                  number  not null  Id of the user subject to acceptance
     pi_report_list_id           number  null      Id of the report list subject to acceptance
     pi_report_id                number  null      Id of the report subject to acceptance
     pi_filter_condition         clob    null      Filter condition for the report
                                                    - conditions on fields from the attachment report table will use the alias <ATTACHMENTTABLE>
                                                    - conditions on fields from the accessed report table will use the alias <ACCESSEDTABLE>
     pi_user_entity_condition    clob    null      Join condition with user entity tables
     pi_report_entity_condition  clob    null      Join condition with report list entity tables
     pi_attachment_date_filter   date    null      Date used for filtering the attachments
     pi_current_login_filter     number  null      Current month when the user logs in: null - not used, 1 - date, 2 - month
     pi_effective_field_filter   number  null      Filter on the effective field from the report: null - not used, 1 - date, 2 - period
     pi_ass_hierarchy_condition  clob    null      Filter condition for assignments and hierarchies
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_reports  sys_refcursor  not null  Reports that need to be displayed
                                          Columns:
                                           - REPORT_ID          - number   - not null - Id of the report
                                           - REPORT_NAME        - varchar2 - not null - Name of the report
                                           - PHYSICAL_FILE_NAME - varchar2 - not null - Physical name of the report
                                           - X                  - expression - not null - Techinical column used for ordering
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  declare
    l_reports sys_refcursor;
  begin
    agreements.filter_attachments(pi_agreement_id            => 233582,
                                  pi_user_id                 => 262,
                                  pi_report_list_id          => null,
                                  pi_report_id               => null,
                                  pi_filter_condition        => '(ue.email=''mymail'') and (T227881.file_name is not null)',
                                  pi_user_entity_condition   => '(select ''mymail'' EMAIL,NULL FULL_NAME from dual) ue',
                                  pi_report_entity_condition => null,
                                  pi_attachment_date_filter  => null,
                                  pi_current_login_filter    => null,
                                  pi_effective_field_filter  => null,
                                  pi_ass_hierarchy_condition => null,
                                  po_reports                 => l_reports);
  end;
  */
  -----------------------------------------------------------------------------------------
  procedure filter_attachments(pi_agreement_id            in number,
                               pi_user_id                 in number,
                               pi_report_list_id          in number,
                               pi_report_id               in number,
                               pi_filter_condition        in clob,
                               pi_user_entity_condition   in clob,
                               pi_report_entity_condition in clob,
                               pi_attachment_date_filter  in date,
                               pi_period_range_id_filter  in number,
                               pi_current_login_filter    in number,
                               pi_current_login_date      in date,
                               pi_effective_field_filter  in number,
                               pi_ass_hierarchy_condition in clob,
                               po_reports                 out sys_refcursor);
  -- ========================================================

end agreements;
/
