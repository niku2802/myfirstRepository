CREATE PACKAGE BODY COMMONS_PROCESSING AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: commons
-- Module			: processing-commons
-- Requester		: Cozac, Tudor
-- Author			: Dumitriu, Cosmin
-- Reviewer			: Cozac, Tudor
-- Review date		: 2012.03.19
-- Description		: This package contains utilities related to processing commons
-- ---------------------------------------------------------------------------
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

/* EXECUTE_PROCESSING_HOOK
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2012.03.14
-----------------------------------------------------------
History:
	- 2012.04.17 - Dumitriu, Cosmin
		* added calls to the logging framework.
		* changed table column names
    - 2014.05.10 - Dumitriu, Cosmin
        * added parameter pi_process_type_id for any ICM processes
    - 2014.06.26 - Dumitriu, Cosmin
        * changed pi_hook_type (NUMBER) into a more flexible VARCHAR2 pi_hook_location
        * added pi_run_id and pi_run_completion_status
-- ===============================================*/
PROCEDURE EXECUTE_PROCESSING_HOOK
(	 pi_process_def_id          NUMBER
    ,pi_process_type_id         NUMBER
	,pi_hook_location           VARCHAR2
    ,pi_run_id                  NUMBER
    ,pi_run_completion_status   NUMBER
) AS
	v_log_id        VARCHAR2(1300 CHAR);
    v_sql           CLOB;
BEGIN
	v_log_id := 'COMMONS_PROCESSING.EXECUTE_PROCESSING_HOOK:DEF_ID-'||TO_CHAR(pi_process_def_id)
                                                        ||',DEF_TYPE-'||TO_CHAR(pi_process_type_id)
                                                        ||',HOOK-'||pi_hook_location;
	L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG
                           ,'Start for RUN_ID-'||TO_CHAR(pi_run_id)
                             ||CASE WHEN pi_hook_location = 'AFTER'
                                    THEN ',RUN_STATUS-'||TO_CHAR(pi_run_completion_status)
                                        ||'('||CASE pi_run_completion_status
                                                    WHEN 0 THEN 'NOT_RUN_SUCCESSFUL'
                                                    WHEN 1 THEN 'SUCCESSFUL'
                                                    WHEN 2 THEN 'WITH_WARNINGS'
                                                    WHEN 3 THEN 'WITH_ERRORS'
                                                    WHEN 4 THEN 'FAILED'
                                                    WHEN 5 THEN 'ABORTED'
                                                    WHEN 6 THEN 'CANCELLED'
                                                    WHEN 7 THEN 'NOT_RUN_FAILED'
                                                    ELSE 'NOT_KNOWN' END||')'
                                    ELSE NULL END
                           ,NULL,NULL,v_log_id);

	FOR C IN (  SELECT PRH_HOOK_PLSQL_BLOCK
                FROM (SELECT PRH_ID
                            ,PRH_PROCESS_DEF_ID
                            ,PRH_PROCESS_TYPE_ID
                            ,PRH_HOOK_LOCATION
                            ,'"'||REPLACE(PRH_RUN_COMPLETION_STATUSES, ',', '","')||'"' PRH_RUN_COMPLETION_STATUSES
                            ,PRH_ORDER
                            ,PRH_HOOK_PLSQL_BLOCK
                      FROM PROCESSING_DBA_HOOKS)
                WHERE PRH_PROCESS_TYPE_ID = pi_process_type_id
                    AND PRH_HOOK_LOCATION = pi_hook_location
                    AND (   PRH_PROCESS_DEF_ID = pi_process_def_id
                         OR (PRH_PROCESS_DEF_ID IS NULL AND NOT EXISTS (SELECT 1 FROM PROCESSING_DBA_HOOKS I
                                                                        WHERE I.PRH_PROCESS_TYPE_ID = pi_process_type_id
                                                                              AND I.PRH_HOOK_LOCATION = pi_hook_location
                                                                              AND I.PRH_PROCESS_DEF_ID = pi_process_def_id)
                            )
                        )
                    AND (  PRH_HOOK_LOCATION <> 'AFTER'
                        OR (    PRH_HOOK_LOCATION = 'AFTER'
                            AND (   pi_run_completion_status IS NULL
                                OR  PRH_RUN_COMPLETION_STATUSES IS NULL
                                OR  TO_CHAR(pi_run_completion_status) IN (SELECT (column_value).getstringval() FROM xmltable(PRH_RUN_COMPLETION_STATUSES))
                                )
                           )
                        )
                ORDER BY PRH_ORDER)
	LOOP
		BEGIN
            v_sql := 'DECLARE v_run_id NUMBER := TO_NUMBER(:1);'||CHR(10)
            ||'BEGIN'||CHR(10)
            ||C.PRH_HOOK_PLSQL_BLOCK||CHR(10)
            ||'END;';

			COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG_BINDS(pi_ddl      => v_sql
                                                        ,pi_bindvar1 => TO_CHAR(pi_run_id)
                                                        ,pi_log_id   => v_log_id);
		EXCEPTION
		WHEN OTHERS THEN
			L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_WARN, 'A hook for process ID '||TO_CHAR(pi_process_def_id)||' failed to execute.',SQLCODE,SQLERRM,v_log_id);
		END;
	END LOOP;
END EXECUTE_PROCESSING_HOOK;


/* GET_HINT_LOCATION_NAME
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2012.05.10
-----------------------------------------------------------
History:
	- YYYY.MM.DD - User
		* comments
-- ===============================================*/
FUNCTION GET_HINT_LOCATION_NAME
(	 pi_module_id	    VARCHAR2
	,pi_hint_id		    VARCHAR2
	,pi_proc_id		    NUMBER
    ,pi_hint_id_list    TABLETYPE_CHARMAX DEFAULT NULL
) RETURN VARCHAR2
AS
    v_hint_list VARCHAR2(2000 CHAR);
BEGIN
    IF (pi_hint_id_list IS NOT NULL)
    THEN
        SELECT LISTAGG('<hint>'||COLUMN_VALUE||'</>', '') WITHIN GROUP (ORDER BY NULL)
        INTO v_hint_list FROM TABLE(pi_hint_id_list);
    ELSE
        v_hint_list := '<hint>'||pi_hint_id||'</>';
    END IF;

    RETURN '/*<module>'||pi_module_id||'</>'||v_hint_list||'<proc>'||TO_CHAR(pi_proc_id)||'</>*/';
END GET_HINT_LOCATION_NAME;


/* GET_HINTS
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2012.05.10
-----------------------------------------------------------
History:
	- YYYY.MM.DD - User
		* comments
-- ===============================================*/
FUNCTION GET_HINTS
(	 pi_module_id	    VARCHAR2
	,pi_hint_id		    VARCHAR2
	,pi_proc_id		    NUMBER
    ,pi_other_hints     VARCHAR2 DEFAULT NULL
    ,pi_hint_id_list    TABLETYPE_CHARMAX DEFAULT NULL
) RETURN VARCHAR2
AS
	v_hint VARCHAR2(4000 CHAR);
BEGIN
	FOR C IN (	SELECT PQH_HINT, PQH_HINT_COMMENT
				FROM PROCESSING_QUERY_HINTS
				WHERE PQH_MODULE_IDENTIFIER = pi_module_id
					AND (   (pi_hint_id IS NOT NULL AND PQH_HINT_IDENTIFIER = pi_hint_id)
                        OR  (pi_hint_id_list IS NOT NULL AND PQH_HINT_IDENTIFIER IN (SELECT COLUMN_VALUE FROM TABLE(pi_hint_id_list))))
					AND (	(pi_proc_id IS NULL AND PQH_PROCESS_DEF_ID IS NULL)
						OR	(pi_proc_id IS NOT NULL AND PQH_PROCESS_DEF_ID = pi_proc_id)
						OR	(pi_proc_id IS NOT NULL AND PQH_PROCESS_DEF_ID IS NULL
							AND NOT EXISTS (SELECT 1 FROM PROCESSING_QUERY_HINTS I
											WHERE I.PQH_MODULE_IDENTIFIER = pi_module_id
												AND (   (pi_hint_id IS NOT NULL AND I.PQH_HINT_IDENTIFIER = pi_hint_id)
                                                    OR  (pi_hint_id_list IS NOT NULL AND PQH_HINT_IDENTIFIER IN (SELECT COLUMN_VALUE FROM TABLE(pi_hint_id_list))))
												AND I.PQH_PROCESS_DEF_ID = pi_proc_id)))
				ORDER BY PQH_ORDER)
	LOOP
		v_hint := v_hint||' '||C.PQH_HINT ;
	END LOOP;

    IF (pi_other_hints IS NOT NULL)
    THEN
        v_hint := v_hint||' '||pi_other_hints;
    END IF;

    IF (v_hint IS NOT NULL)
    THEN
        v_hint := '/*+'||v_hint||' */';
    END IF;

	RETURN v_hint;
END GET_HINTS;


/* SAVE_EXEC_PLAN
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2015.01.22
-- ===============================================*/
PROCEDURE save_exec_plan(pi_run_id           IN NUMBER DEFAULT NULL,
                         pi_query_identifier IN VARCHAR2 DEFAULT NULL,
                         pi_bind_variables   IN coltype_name_value DEFAULT NULL) AS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_run_id       NUMBER(10);
  v_client_id    VARCHAR2(200 CHAR);
  v_sql_id       VARCHAR2(13 CHAR);
  v_child_number NUMBER;
  v_plan_hash    NUMBER;
  v_sql_fulltext CLOB;
  v_stamp        VARCHAR2(200 CHAR);
  v_sql          CLOB;
  v_flag         NUMBER(1) := '2';
BEGIN

  --    IF (NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('PROC_EXEC_PLAN_ENABLED'), 'FALSE') = 'TRUE')
  --    THEN
  /*     dba_utils.saveLastRawExecPlan
  (   pin_save_query       => 'TRUE',
      pout_client_id       => v_client_id,

      pout_plan_hash_value => v_plan_hash,
      pout_sql_fulltext    => v_sql_fulltext
  );*/
  dba_utils.get_sql_id(pout_sql_id       => v_sql_id,
                       pout_child_number => v_child_number);
  FOR i IN (SELECT 1
              FROM properties
             WHERE pr_name = 'DISABLE_SQL_STATS_PROCESSING'
               AND pr_value = '0') LOOP
    /*        v_run_id := CASE WHEN pi_run_id IS NOT NULL THEN pi_run_id
    WHEN REGEXP_LIKE(v_client_id,'*:R:[0-9]') THEN TO_NUMBER(SUBSTR(v_client_id, INSTR(v_client_id, ':R:')+3))
    ELSE NULL END;*/

    /*  IF (v_run_id IS NOT NULL)
    THEN*/
    IF v_sql_id IS NOT NULL THEN

      v_sql := 'declare
                v_sqlerrm VARCHAR2(500 CHAR);
                v_sqlcode NUMBER;

                BEGIN
                  dba_utils.saveRawExecPlans(PI_SQL_ID       => ''' ||v_sql_id || ''',
                                             PI_CHILD_NUMBER => ' ||v_child_number || ');
                  COMMONS_UTILS.PERSIST_EXEC_PLAN(' || CASE WHEN pi_run_id IS NOT NULL THEN ' pi_run_id => ' || pi_run_id END || ');
                  COMMIT;
               EXCEPTION
                WHEN OTHERS THEN
                  v_sqlcode := SQLCODE;
                  v_sqlerrm := substr(SQLERRM, 1, 500);
                  begin
                  INSERT INTO sql_stats_error_log
                    (ssel_id,
                     ssel_error_code,
                     ssel_error_msg,
                     ssel_run_id,
                     ssel_object_id,
                     ssel_create_date,
                     ssel_flag)
                  VALUES
                    (sql_stats_error_log_seq.nextval,
                     v_sqlcode,
                     v_sqlerrm,';

      IF pi_run_id IS NOT NULL THEN
        v_sql := v_sql || ' '||pi_run_id ||' ,
                        ';
      ELSE
        v_sql := v_sql || ' null,
                      ';
      END IF;

      v_sql := v_sql || ' null,
                          SYSDATE,
                     ' || v_flag || ');
                   exception
                     when others then
                   null;
                   end;
                  COMMIT;
                   end;';
                   --dbms_output.put_line(v_sql);
   commons_utils.async_plsql_run(pi_plsql_code     => v_sql,
                                  pi_comment        => 'Stats gather',
                                  pi_differentiator => v_flag);
    ELSE
      BEGIN
        INSERT INTO sql_stats_error_log
          (ssel_id,
           ssel_error_code,
           ssel_error_msg,
           ssel_run_id,
           ssel_object_id,
           ssel_create_date,
           ssel_flag)
        VALUES
          (sql_stats_error_log_seq.nextval,
           NULL,
           NULL,
           pi_run_id,
           NULL,
           SYSDATE,
           v_flag);
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;

  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    v_stamp := 'COMMONS_PROCESSING.SAVE_EXEC_PLAN - ' ||
               to_char(current_timestamp, 'YYYY-MM-DD HH24:MI:SSxFF');
    l4o_logging.log_message(l4o_logging.lvl_error,
                            dbms_utility.format_error_stack ||
                            dbms_utility.format_error_backtrace,
                            SQLCODE,
                            SQLERRM,
                            v_stamp);
END;

/* SAVE_EXEC_PLAN_FOR_ABORT
-- ===============================================
-- Author		: Kristo, Robert
-- Create date	: 2015.02.20
-- ===============================================*/
PROCEDURE SAVE_EXEC_PLAN_FOR_ABORT
(    pi_run_id IN NUMBER DEFAULT NULL
) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_plan_ids  TABLETYPE_SQL_PLAN_IDENTIFIER;
    v_stamp     VARCHAR2(200 CHAR);
BEGIN
--    IF (NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('PROC_EXEC_PLAN_ENABLED'), 'FALSE') = 'TRUE')
--    THEN
        -- get the plans
        dba_utils.saveAbortRawExecPlans
        (    pi_run_id      => pi_run_id
            ,po_plan_ids    => v_plan_ids
        );

        -- save the exec plans
        INSERT INTO RUN_PROFILE_QUERY_PLANS (RQP_ID, RQP_RD_ID, RQP_SQL_IDENTIFIER, RQP_SQL_ID, RQP_CHILD_NUMBER, RQP_SQL_FULLTEXT)
        SELECT   RUN_PROFILE_QUERY_PLANS_SEQ.NEXTVAL
                ,pi_run_id
                ,'Aborted'
                ,SQL_ID
                ,CHILD_NUMBER
                ,SQL_FULLTEXT
        FROM TABLE(v_plan_ids);

        COMMONS_UTILS.PERSIST_EXEC_PLAN;

        COMMIT;
--    END IF;
EXCEPTION
    WHEN OTHERS THEN
	ROLLBACK;
    v_stamp := 'COMMONS_PROCESSING.SAVE_EXEC_PLAN_FOR_ABORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
END;


/* SAVE_SESS_STATS
  ========================================================
  Description and usage details: please see the SPEC comments
  ========================================================
  History:
  2015.01.28 - Andries, Adriana - created
  ========================================================*/
PROCEDURE SAVE_SESS_STATS
(    pin_sesstat_type   IN VARCHAR2
    ,pin_run_id         IN NUMBER
    ,pin_definition_id  IN NUMBER DEFAULT NULL
) IS
    PRAGMA AUTONOMOUS_TRANSACTION;

    v_statistic_names   TABLETYPE_STATISTIC_NAMES;
    v_statistics        TABLETYPE_STATISTICS;
    v_spm_statistics    TABLETYPE_SPM_STATISTICS;
    v_stamp             VARCHAR2(200 CHAR);
BEGIN
    IF (NVL(COMMONS_APPFRAMEWORK.GET_CONTEXT_VALUE('PROC_SESSION_STATS_ENABLED'), 'FALSE') = 'TRUE'
        AND pin_run_id IS NOT NULL)
    THEN
        SELECT RSP_STATISTIC_NAME
        BULK COLLECT INTO v_statistic_names
        FROM RUNTIME_STATISTICS_PROPERTIES
        WHERE RSP_STATISTIC_ENABLED = 1;

        DBA_UTILS.GET_SESSION_STATISTICS(pin_statistic_names => v_statistic_names
                                        ,pout_data           => v_statistics);

        SELECT OBJTYPE_SPM_STATISTICS(STATISTIC_NAME, STATISTIC_VALUE)
        BULK COLLECT INTO v_spm_statistics
        FROM TABLE(v_statistics);

        IF (pin_sesstat_type = 'BEFORE')
        THEN
            INSERT INTO RUNTIME_STATISTICS_INFO(RSI_DEF_ID, RSI_RUN_ID, RSI_START_TIMESTAMP, RSI_BEGIN_VALUES)
            VALUES (pin_definition_id, pin_run_id, SYSTIMESTAMP, v_spm_statistics);
        ELSIF (pin_sesstat_type = 'AFTER')
        THEN
            UPDATE  RUNTIME_STATISTICS_INFO
            SET  RSI_END_TIMESTAMP = SYSTIMESTAMP ,
               RSI_END_VALUES    = v_spm_statistics
            WHERE RSI_RUN_ID  = pin_run_id;
        END IF;

        COMMIT;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
    v_stamp := 'COMMONS_PROCESSING.SAVE_SESS_STATS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
END SAVE_SESS_STATS;


/* EXEC_START_PROC_TRANSACTION
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2015.07.14
-- ===============================================*/
PROCEDURE EXEC_START_PROC_TRANSACTION
(    pin_run_id         IN NUMBER DEFAULT NULL
    ,pin_definition_id  IN NUMBER DEFAULT NULL
) IS
    v_run_id            NUMBER(10);
    v_client_id         VARCHAR2(250);
BEGIN
    v_client_id := SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER');
    v_run_id := CASE WHEN pin_run_id IS NOT NULL THEN pin_run_id
                     WHEN REGEXP_LIKE(v_client_id,'*:R:[0-9]') THEN TO_NUMBER(SUBSTR(v_client_id, INSTR(v_client_id, ':R:')+3))
                     ELSE NULL END;

    COMMONS_PROCESSING.SAVE_SESS_STATS(pin_sesstat_type => 'BEFORE'
                                      ,pin_run_id => v_run_id
                                      ,pin_definition_id => pin_definition_id);
END EXEC_START_PROC_TRANSACTION;


/* EXEC_END_PROC_TRANSACTION
-- ===============================================
-- Author		: Dumitriu, Cosmin
-- Create date	: 2015.07.14
-- ===============================================*/
PROCEDURE EXEC_END_PROC_TRANSACTION
(    pin_run_id         IN NUMBER DEFAULT NULL
    ,pin_definition_id  IN NUMBER DEFAULT NULL
) IS
    v_run_id            NUMBER(10);
    v_client_id         VARCHAR2(250);
BEGIN
    v_client_id := SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER');
    v_run_id := CASE WHEN pin_run_id IS NOT NULL THEN pin_run_id
                     WHEN REGEXP_LIKE(v_client_id,'*:R:[0-9]') THEN TO_NUMBER(SUBSTR(v_client_id, INSTR(v_client_id, ':R:')+3))
                     ELSE NULL END;

    COMMONS_PROCESSING.SAVE_SESS_STATS(pin_sesstat_type => 'AFTER'
                                      ,pin_run_id => v_run_id
                                      ,pin_definition_id => pin_definition_id);
END EXEC_END_PROC_TRANSACTION;

  procedure remove_hints(pin_process_def_id in number)
    is
    begin
      delete from PROCESSING_QUERY_HINTS where PQH_PROCESS_DEF_ID = pin_process_def_id;
    end remove_hints;

  procedure add_autotune_hints(pin_process_def_id in number, pin_autotune_option in number)
    is
    begin
      -- option 1: NO_MERGE
      if pin_autotune_option = 1 then
        for i in (select DTIN_ORDER from DT_INPUTS where DTIN_DTO_ID = pin_process_def_id)
        loop
          insert into PROCESSING_QUERY_HINTS
            (PQH_ID,
             PQH_MODULE_IDENTIFIER,
             PQH_HINT_IDENTIFIER,
             PQH_PROCESS_DEF_ID,
             PQH_PROCESS_TYPE_ID,
             PQH_ORDER,
             PQH_HINT,
             PQH_HINT_COMMENT)
          values
            (uid_sequence.nextval,
             'MERGEFIELDS',
             'MERGE_FIELDS_<' || i.DTIN_ORDER || '>_JOIN',
             pin_process_def_id,
             null,
             i.DTIN_ORDER,
             'NO_MERGE(<' || i.DTIN_ORDER || '>)',
             null);
         end loop;
      -- option 2: NO_MERGE + opt_param('optimizer_dynamic_sampling' 4)
      elsif pin_autotune_option = 2 then
      for i in (select DTIN_ORDER from DT_INPUTS where DTIN_DTO_ID = pin_process_def_id)
      loop
        insert into PROCESSING_QUERY_HINTS
          (PQH_ID,
           PQH_MODULE_IDENTIFIER,
           PQH_HINT_IDENTIFIER,
           PQH_PROCESS_DEF_ID,
           PQH_PROCESS_TYPE_ID,
           PQH_ORDER,
           PQH_HINT,
           PQH_HINT_COMMENT)
        values
          (uid_sequence.nextval,
           'MERGEFIELDS',
           'MERGE_FIELDS_<' || i.DTIN_ORDER || '>_JOIN',
           pin_process_def_id,
           null,
           i.DTIN_ORDER,
           'NO_MERGE(<' || i.DTIN_ORDER || '>)',
           null);
       end loop;
       insert into PROCESSING_QUERY_HINTS
         (PQH_ID,
          PQH_MODULE_IDENTIFIER,
          PQH_HINT_IDENTIFIER,
          PQH_PROCESS_DEF_ID,
          PQH_PROCESS_TYPE_ID,
          PQH_ORDER,
          PQH_HINT,
          PQH_HINT_COMMENT)
       values
         (uid_sequence.nextval,
          'MERGEFIELDS',
          'MERGE_FIELDS_INITIAL_INPUT',
          pin_process_def_id,
          null,
          8,
          'opt_param(''optimizer_dynamic_sampling'' 4)',
          null);
      -- option 3: opt_param('optimizer_dynamic_sampling' 4)
      elsif pin_autotune_option = 3 then
       insert into PROCESSING_QUERY_HINTS
         (PQH_ID,
          PQH_MODULE_IDENTIFIER,
          PQH_HINT_IDENTIFIER,
          PQH_PROCESS_DEF_ID,
          PQH_PROCESS_TYPE_ID,
          PQH_ORDER,
          PQH_HINT,
          PQH_HINT_COMMENT)
       values
         (uid_sequence.nextval,
          'MERGEFIELDS',
          'MERGE_FIELDS_INITIAL_INPUT',
          pin_process_def_id,
          null,
          0,
          'opt_param(''optimizer_dynamic_sampling'' 4)',
          null);
      -- option 4: opt_param('optimizer_dynamic_sampling' 11)
      elsif pin_autotune_option = 4 then
       insert into PROCESSING_QUERY_HINTS
         (PQH_ID,
          PQH_MODULE_IDENTIFIER,
          PQH_HINT_IDENTIFIER,
          PQH_PROCESS_DEF_ID,
          PQH_PROCESS_TYPE_ID,
          PQH_ORDER,
          PQH_HINT,
          PQH_HINT_COMMENT)
       values
         (uid_sequence.nextval,
          'MERGEFIELDS',
          'MERGE_FIELDS_INITIAL_INPUT',
          pin_process_def_id,
          null,
          0,
          'opt_param(''optimizer_dynamic_sampling'' 11)',
          null);
      -- option 5: USE_HASH
      elsif pin_autotune_option = 5 then
      for i in (select DTIN_ORDER from DT_INPUTS where DTIN_DTO_ID = pin_process_def_id)
      loop
        insert into PROCESSING_QUERY_HINTS
          (PQH_ID,
           PQH_MODULE_IDENTIFIER,
           PQH_HINT_IDENTIFIER,
           PQH_PROCESS_DEF_ID,
           PQH_PROCESS_TYPE_ID,
           PQH_ORDER,
           PQH_HINT,
           PQH_HINT_COMMENT)
        values
          (uid_sequence.nextval,
           'MERGEFIELDS',
           'MERGE_FIELDS_<' || i.DTIN_ORDER || '>_JOIN',
           pin_process_def_id,
           null,
           i.DTIN_ORDER,
           'USE_HASH(<' || i.DTIN_ORDER || '>)',
           null);
       end loop;
      -- option 6: ORDERED
      elsif pin_autotune_option = 6 then
       insert into PROCESSING_QUERY_HINTS
         (PQH_ID,
          PQH_MODULE_IDENTIFIER,
          PQH_HINT_IDENTIFIER,
          PQH_PROCESS_DEF_ID,
          PQH_PROCESS_TYPE_ID,
          PQH_ORDER,
          PQH_HINT,
          PQH_HINT_COMMENT)
       values
         (uid_sequence.nextval,
          'MERGEFIELDS',
          'MERGE_FIELDS_INITIAL_INPUT',
          pin_process_def_id,
          null,
          0,
          'ORDERED',
          null);
      end if;
    end add_autotune_hints;

  procedure log_autotune_run(pin_run_data_id in number, pin_autotune_option in number)
    is
    begin
      insert into RUN_DATA_AUTOTUNE(RDA_ID,RDA_ATO_ID) values(pin_run_data_id,pin_autotune_option);
    end log_autotune_run;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END COMMONS_PROCESSING;
/
