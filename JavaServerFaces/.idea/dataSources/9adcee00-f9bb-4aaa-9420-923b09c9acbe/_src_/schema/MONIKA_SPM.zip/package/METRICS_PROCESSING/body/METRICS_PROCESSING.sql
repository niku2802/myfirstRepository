CREATE PACKAGE BODY METRICS_PROCESSING AS
   -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type      : SPM
  -- Product            : compensation
  -- Module             : compensation-processing
  -- Requester          : Homeuca, Victor
  -- Authors            : Hrubaru, Ionut; Rohit, Maxim; Popescu, Mircea; Homeuca, Victor
  -- Create date        : 20110415
  -- Reviewer           : Homeuca, Victor
  -- Review date        : 20110517
  -- Description        : package used to handle all operations for metrics processing
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

  PROCEDURE ALTER_SESSION_TIMESTAMP
  IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TIMESTAMP_FORMAT =''DD-MON-RRRR HH.MI.SSXFF AM''';
  END ALTER_SESSION_TIMESTAMP;

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  PROCEDURE METRIC_INPUTS (
                           pin_inputTable                 IN VARCHAR2
                           ,pin_JoinedInput               IN VARCHAR2
                           ,pin_EarningEntity             IN TABLETYPE_NAME_MAP
                           ,pin_ColumnMapping             IN TABLETYPE_NAME_MAP
                           ,pin_EntityMapping             IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_MetricInputFields         in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable          in VARCHAR2 default null
                           ,pin_MetricInputSequence       in VARCHAR2 default null
                           ,pin_additional_clause         IN VARCHAR2
                           ,pin_projectedFlag             IN NUMBER
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
    )
  as
     v_metric_input_fields varchar2(32767);
     v_metric_input_tablefields varchar2(32767);
     V_SELECT_MI clob;
     V_SELECT_FIELDS_MI clob;
     V_INSERT_FIELDS_MI clob;
     V_INSERT_MI clob;
     V_SQL_MI clob;
     v_input_constant_fields varchar2(32767);
     v_input_constant_values varchar2(32767);
     V_INPUT_CATEGORY CATEGORY_DEFINITIONS.CD_NAME_SINGULAR%TYPE;
     V_INPUT_NAME OBJECT_REGISTRATION.OR_NAME%TYPE;
     V_INPUT_CATEGORY_DEFINITION DEFINITION_TYPES.DEF_TYPE_NAME_SINGULAR%TYPE;
     v_stamp  VARCHAR2(250);
     v_mi_periodfields varchar2(32767);
     v_mi_periodtablefields varchar2(32767);
     v_metric_input number(1) := 0;
     v_roster_table varchar2(30);
  begin
    v_stamp := 'METRICS_PROCESSING.METRIC_INPUTS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    begin
            compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;

          V_SELECT_FIELDS_MI := pin_EarningEntity(1).NAME1;
          V_INSERT_FIELDS_MI := substr(pin_EarningEntity(1).NAME1, instr(pin_EarningEntity(1).NAME1, '.') + 1);
          -- Create joins and map columns
          IF PIN_ENTITYMAPPING IS NOT NULL THEN
            FOR I IN 1..PIN_ENTITYMAPPING.COUNT LOOP
              V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_entityMapping(I).NAME5;
              --IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
                V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_EntityMapping(i).NAME1 || '.E_INTERNAL_ID';
              --ELSE
                --V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_inputTable || '.' || pin_entityMapping(I).NAME2;
              --END IF;
            END LOOP;
          END IF;
          -- Create additional fields
          IF PIN_COLUMNMAPPING IS NOT NULL THEN
            FOR I IN 1..PIN_COLUMNMAPPING.COUNT LOOP
                  V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_columnMapping(I).NAME1;
                  V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_inputTable || '.' || pin_columnMapping(I).NAME1;
            END LOOP;
          END IF;
          -- create period fields
          v_mi_periodfields := v_mi_periodfields || ',' || pin_MetricPeriodField;
          v_mi_periodtablefields := v_mi_periodtablefields || ',' || pin_MetricPeriodValue;
          if pin_projectedFlag = 1 then
            v_roster_table := substr(pin_EarningEntity(1).NAME1,1,instr(pin_EarningEntity(1).NAME1, '.')-1);
            v_mi_periodfields := v_mi_periodfields || ',PROJECTED,' || pin_MetricProjectedPeriodField;
            v_mi_periodtablefields := v_mi_periodtablefields || ',' || v_roster_table || '.PROJECTED,' || pin_MetricProjectedPeriodValue;
          end if;
          v_mi_periodfields := v_mi_periodfields || ',PROCESSED_DATE_TIME';
          v_mi_periodtablefields := v_mi_periodtablefields || ',SYSTIMESTAMP';

         -- set fields for metric inputs result table
         for c in (select NAME1, NAME2 from table(pin_MetricInputFields)        /*where NAME1 = pin_inputTable*/ union all
                    select NAME1, NAME2 from table(pin_MetricFilterInputFields)  /*where NAME1 = pin_inputTable*/ order by NAME2) loop
                v_metric_input_fields := v_metric_input_fields || ',' || c.NAME2;
                v_metric_input_tablefields := v_metric_input_tablefields || ',' || c.NAME1 || '.' || c.NAME2;
         end loop;

         for c in (select NAME1, NAME2 from table(pin_MetricInputConstants)) loop
             v_input_constant_fields := v_input_constant_fields || ',' || c.NAME1;
             if c.NAME1 = 'INPUT_CATEGORY' then
                 if c.NAME2 = 'Metric' then
                   V_INPUT_CATEGORY := c.NAME2;
                   v_metric_input := 1;
                 else
                   select CD_NAME_SINGULAR into V_INPUT_CATEGORY from CATEGORY_DEFINITIONS where CD_ID = c.NAME2;
                 end if;
                 v_input_constant_values := v_input_constant_values || ',''' || V_INPUT_CATEGORY || '''';
             elsif c.NAME1 = 'INPUT_NAME' then
                 if v_metric_input = 1 then
                   V_INPUT_NAME := c.NAME2;
                 else
                   select OR_NAME into V_INPUT_NAME from TABLE_REFERENCES join OBJECT_REGISTRATION on TREF_DEFINITION_ID = OR_ID or TREF_PARENT_DEFINITION_ID = OR_ID where TREF_ID = c.NAME2;
                 end if;
                 v_input_constant_values := v_input_constant_values || ',''' || V_INPUT_NAME || '''';
             elsif c.NAME1 = 'INPUT_CATEGORY_DEFINITION' then
                 if c.NAME2 is not null then
                    select DEF_TYPE_NAME_SINGULAR into V_INPUT_CATEGORY_DEFINITION from object_registration join definition_types on or_type = def_type_id where or_id = c.NAME2;
                    v_input_constant_values := v_input_constant_values || ',''' || V_INPUT_CATEGORY_DEFINITION || '''';
                 else
                    v_input_constant_values := v_input_constant_values || ',''' || c.NAME2 || '''';
                 end if;
             else
                 v_input_constant_values := v_input_constant_values || ',''' || c.NAME2 || '''';
             end if;
         end loop;

         V_SELECT_MI := 'SELECT ' || V_SELECT_FIELDS_MI || v_mi_periodtablefields ||
                           v_metric_input_tablefields ||
                           v_input_constant_values ||
                           ',' || pin_MetricInputSequence || '.NEXTVAL,0';

         V_INSERT_MI := 'INSERT INTO ' || pin_MetricInputTable || '(' ||
                          V_INSERT_FIELDS_MI ||
                          v_mi_periodfields ||
                          v_metric_input_fields ||
                          v_input_constant_fields ||
                          ',ROW_IDENTIFIER,ROW_VERSION) ';

         V_SQL_MI := V_INSERT_MI || V_SELECT_MI || ' FROM ' || pin_joinedInput || pin_additional_clause;
         L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_SQL_MI), 'V_SQL_MI := <value>;', v_stamp);

         execute immediate V_SQL_MI;

    begin
            compensation_processing.ALTER_SESSION_NLS_BINARY;
    end;
    EXCEPTION
        WHEN CANNOT_INSERT_NULL THEN
             RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
  END METRIC_INPUTS;

  PROCEDURE METRIC_INPUTS_AGG (
                           pin_inputTable                 IN VARCHAR2
                           ,pin_JoinedInput               IN VARCHAR2
                           ,pin_EarningEntity             IN TABLETYPE_NAME_MAP
                           ,pin_ColumnMapping             IN TABLETYPE_NAME_MAP
                           ,pin_EntityMapping             IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_MetricInputFields         in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable          in VARCHAR2 default null
                           ,pin_MetricInputSequence       in VARCHAR2 default null
                           ,pin_additional_clause         IN VARCHAR2
                           ,pin_projectedFlag             IN NUMBER
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                           ,pin_operationType              in number default null
    )
  as
     v_metric_input_fields varchar2(32767);
     v_metric_input_tablefields varchar2(32767);
     v_metric_input_groupfields varchar2(32767);
     V_SELECT_MI clob;
     V_INSIDE_SELECT_FIELDS_MI clob;
     V_SELECT_FIELDS_MI clob;
     V_INSERT_FIELDS_MI clob;
     V_INSERT_MI clob;
     V_SQL_MI clob;
     v_input_constant_fields varchar2(32767);
     v_input_constant_values varchar2(32767);
     V_INPUT_CATEGORY CATEGORY_DEFINITIONS.CD_NAME_SINGULAR%TYPE;
     V_INPUT_NAME OBJECT_REGISTRATION.OR_NAME%TYPE;
     V_INPUT_CATEGORY_DEFINITION DEFINITION_TYPES.DEF_TYPE_NAME_SINGULAR%TYPE;
     v_stamp  VARCHAR2(250);
     v_mi_periodfields varchar2(32767);
     v_mi_periodtablefields varchar2(32767);
     v_metric_input number(1) := 0;
     v_roster_table varchar2(30);
     v_type_sql varchar2(30);
     v_fld_data_type FIELDS.FLD_DATA_TYPE%type;
  begin
    v_stamp := 'METRICS_PROCESSING.METRIC_INPUTS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    begin
            compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;

          V_SELECT_FIELDS_MI := substr(pin_EarningEntity(1).NAME1, instr(pin_EarningEntity(1).NAME1, '.') + 1);
          V_INSIDE_SELECT_FIELDS_MI := pin_EarningEntity(1).NAME1;
          V_INSERT_FIELDS_MI := substr(pin_EarningEntity(1).NAME1, instr(pin_EarningEntity(1).NAME1, '.') + 1);
          -- Create joins and map columns
          IF PIN_ENTITYMAPPING IS NOT NULL THEN
            FOR I IN 1..PIN_ENTITYMAPPING.COUNT LOOP
              V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_entityMapping(I).NAME5;
              --IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
                V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',E_INTERNAL_ID';
                V_INSIDE_SELECT_FIELDS_MI := V_INSIDE_SELECT_FIELDS_MI || ',' || pin_EntityMapping(i).NAME1 || '.E_INTERNAL_ID';
              --ELSE
                --V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_entityMapping(I).NAME2;
                --V_INSIDE_SELECT_FIELDS_MI := V_INSIDE_SELECT_FIELDS_MI || ',' || pin_inputTable || '.' || pin_entityMapping(I).NAME2;
              --END IF;
            END LOOP;
          END IF;
          -- Create additional fields
          IF PIN_COLUMNMAPPING IS NOT NULL THEN
            FOR I IN 1..PIN_COLUMNMAPPING.COUNT LOOP
                  V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_columnMapping(I).NAME1;
                  V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_columnMapping(I).NAME1;
                  V_INSIDE_SELECT_FIELDS_MI := V_INSIDE_SELECT_FIELDS_MI || ',' || pin_inputTable || '.' || pin_columnMapping(I).NAME1;
            END LOOP;
          END IF;
          -- create period fields
          v_mi_periodfields := v_mi_periodfields || ',' || pin_MetricPeriodField;
          v_mi_periodtablefields := v_mi_periodtablefields || ',' || pin_MetricPeriodValue;
          if pin_projectedFlag = 1 then
            v_roster_table := substr(pin_EarningEntity(1).NAME1,1,instr(pin_EarningEntity(1).NAME1, '.')-1);
            v_mi_periodfields := v_mi_periodfields || ',PROJECTED,' || pin_MetricProjectedPeriodField;
            v_mi_periodtablefields := v_mi_periodtablefields || ',PROJECTED,' || pin_MetricProjectedPeriodValue;
          end if;
          v_mi_periodfields := v_mi_periodfields || ',PROCESSED_DATE_TIME';
          v_mi_periodtablefields := v_mi_periodtablefields || ',SYSTIMESTAMP';
         -- set fields for metric inputs result table
         for c in (select NAME1, NAME2 from table(pin_MetricInputFields)        where NAME1 = pin_inputTable union all
                    select NAME1, NAME2 from table(pin_MetricFilterInputFields)  where NAME1 = pin_inputTable order by NAME2) loop
                v_metric_input_fields := v_metric_input_fields || ',' || c.NAME2;
                v_metric_input_tablefields := v_metric_input_tablefields || ',' || c.NAME1 || '.' || c.NAME2;
         end loop;
         -- set group by fields
         for c in (select NAME1, NAME2 from table(pin_MetricFilterInputFields) where NAME1 = pin_inputTable order by NAME2) loop
                V_INSIDE_SELECT_FIELDS_MI := V_INSIDE_SELECT_FIELDS_MI || ',' || c.NAME1 || '.' || c.NAME2;
         end loop;
         if pin_projectedFlag = 1 then
           V_INSIDE_SELECT_FIELDS_MI := V_INSIDE_SELECT_FIELDS_MI || ',' || v_roster_table || '.PROJECTED';
         end if;
         -- set fields to be aggregated
         if pin_operationType = 6 then
           v_type_sql := 'SUM(';
         elsif pin_operationType = 7 then
           v_type_sql := 'AVG(';
         elsif pin_operationType = 8 then
           v_type_sql := 'MIN(';
         elsif pin_operationType = 9 then
           v_type_sql := 'MAX(';
         elsif pin_operationType = 14 then
           v_type_sql := 'COUNT(';
         elsif pin_operationType = 15 then
           v_type_sql := 'COUNT (DISTINCT ';
         else
           v_type_sql := 'SUM(';
         end if;

         for c in (select NAME1, NAME2 from table(pin_MetricInputFields) where NAME1 = pin_inputTable order by NAME2) loop
            -- if the field is not numeric, set the function to max -- will redesign this aspect in a future sprint
             select nvl(max(FLD_DATA_TYPE),-1) into v_fld_data_type from FIELDS where FLD_COLUMN_NAME = c.NAME2;
             if v_fld_data_type != 6 then
               v_type_sql := 'MAX(';
             end if;
             v_metric_input_groupfields := v_metric_input_groupfields || ',' || v_type_sql || c.NAME1 || '.' || c.NAME2 || ') ' || c.NAME2;
         end loop;

         for c in (select NAME1, NAME2 from table(pin_MetricInputConstants)) loop
             v_input_constant_fields := v_input_constant_fields || ',' || c.NAME1;
             if c.NAME1 = 'INPUT_CATEGORY' then
                 if c.NAME2 = 'Metric' then
                   V_INPUT_CATEGORY := c.NAME2;
                   v_metric_input := 1;
                 else
                   select CD_NAME_SINGULAR into V_INPUT_CATEGORY from CATEGORY_DEFINITIONS where CD_ID = c.NAME2;
                 end if;
                 v_input_constant_values := v_input_constant_values || ',''' || V_INPUT_CATEGORY || '''';
             elsif c.NAME1 = 'INPUT_NAME' then
                 if v_metric_input = 1 then
                   V_INPUT_NAME := c.NAME2;
                 else
                   select OR_NAME into V_INPUT_NAME from TABLE_REFERENCES join OBJECT_REGISTRATION on TREF_DEFINITION_ID = OR_ID or TREF_PARENT_DEFINITION_ID = OR_ID where TREF_ID = c.NAME2;
                 end if;
                 v_input_constant_values := v_input_constant_values || ',''' || V_INPUT_NAME || '''';
             elsif c.NAME1 = 'INPUT_CATEGORY_DEFINITION' then
                 if c.NAME2 is not null then
                    select DEF_TYPE_NAME_SINGULAR into V_INPUT_CATEGORY_DEFINITION from object_registration join definition_types on or_type = def_type_id where or_id = c.NAME2;
                    v_input_constant_values := v_input_constant_values || ',''' || V_INPUT_CATEGORY_DEFINITION || '''';
                 else
                    v_input_constant_values := v_input_constant_values || ',''' || c.NAME2 || '''';
                 end if;
             else
                 v_input_constant_values := v_input_constant_values || ',''' || c.NAME2 || '''';
             end if;
         end loop;

         V_SELECT_MI := 'SELECT ' || V_SELECT_FIELDS_MI || v_mi_periodtablefields ||
                           v_metric_input_fields ||
                           v_input_constant_values ||
                           ',' || pin_MetricInputSequence || '.NEXTVAL,0';

         V_INSERT_MI := 'INSERT INTO ' || pin_MetricInputTable || '(' ||
                          V_INSERT_FIELDS_MI ||
                          v_mi_periodfields ||
                          v_metric_input_fields ||
                          v_input_constant_fields ||
                          ',ROW_IDENTIFIER,ROW_VERSION) ';

         V_SQL_MI := V_INSERT_MI ||
                     V_SELECT_MI ||
                     ' FROM (SELECT ' ||
                     V_INSIDE_SELECT_FIELDS_MI ||
                     v_metric_input_groupfields ||
                     ' FROM ' ||
                     pin_joinedInput ||
                     pin_additional_clause ||
                     ' GROUP BY ' ||
                     V_INSIDE_SELECT_FIELDS_MI ||
                     ')';
         L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_SQL_MI), 'V_SQL_MI_AGG := <value>;', v_stamp);
         execute immediate V_SQL_MI;

    begin
        compensation_processing.ALTER_SESSION_NLS_BINARY;
    end;
    EXCEPTION
        WHEN CANNOT_INSERT_NULL THEN
             RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
  END METRIC_INPUTS_AGG;
------------------------
------------------------


  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
  PROCEDURE Metric_Aggregates(pin_inputTable          in varchar2
                             ,pin_JoinedInput         in varchar2
                             ,pin_WhereClause         in varchar2
                             ,pin_EarningEntity       in TABLETYPE_NAME_MAP
                             ,pin_ColumnMapping       in TABLETYPE_NAME_MAP
                             ,pin_EntityMapping       in TABLETYPE_NAME_JOIN_MAP
                             ,pin_operationType       in number
                             ,pin_priorPeriodTable    IN VARCHAR2
                             ,pin_priorPeriodColumn   IN VARCHAR2
                             ,pin_projectedFlag       IN NUMBER
                             ,pin_baseLineTable       IN VARCHAR2
                             ,pin_priorPeriod         IN NUMBER
                             ,pin_calculationType     IN NUMBER
                             ,pin_PriorPeriodFlag     IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                             ,pin_AggregatedField     in varchar2
                             )
   -- Assumptions:
    -- Input Parameters are built using valid column names
    -- when WHERE_CLAUSE parameter is passed it should have "WHERE" clause in it.
    -- when ORDERBY_CLAUSE parameter is passed it should have "ORDER" clause in it.
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_inputTable         the actual input table
    --    pin_JoinedInput        the join condition between the input and periods/entity/roster (coming from inputs processing)
    --    pin_WhereClause        the filter from input processing (Separate because we have extra joins)
    --    pin_EarningEntity      earning entity column from the input and also the name of the business key from the
    --    pin_ColumnMapping      column mapping for additional fields (an array of elements like (F1,MA_EARNINGS_ENTITY), (F2,MA_METRIC_CALC_ENTITY_NAME_1)
    --                                        ,(T123.e_entity_id, MA_METRIC_CALC_ENTITY_ID_1 )
    --    pin_EntityMapping      entity mapping containing  an 4 dimensional array of elements as 'T123', F3 - F3 is the business key name from the input table
    --    pin_operationType      (6-sum, 7-average, 8-min, 9-max)
    --    pin_AggregatedField    field on which sum/avg/min/max is calculated
    -----------------------------------------------------------------------------------------
    -- Output : None
    -----------------------------------------------------------------------------------------

   /*examples:
   I)
 begin
    -- Call the procedure
    METRICS_PROCESSING.Metric_Aggregates(pin_inputTable   => 'T1759'
                       ,pin_JoinedInput         => 'T1759'
                       ,pin_WhereClause         => 'F1=1'
                       ,pin_EarningEntity      =>  'F2'
 ,pin_ColumnMapping     =>  TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F4','MA_METRIC_CALC_ENTITY_NAME_2'), OBJTYPE_NAME_MAP('F5','MA_METRIC_CALC_ENTITY_NAME_3'))
 ,pin_EntityMapping     =>  TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('entity_table','F3'
                        ,'MA_METRIC_CALC_ENTITY_NAME_1','MA_METRIC_CALC_ENTITY_ID_1')
                           )
                       ,pin_operationType       => 6
                       ,pin_AggregatedField     => 'F1'
                       );
  end;

II)
 begin
    -- Call the procedure
    METRICS_PROCESSING.Metric_Aggregates(pin_inputTable   => 'T1759'
                       ,pin_JoinedInput         => 'T1759'
                       ,pin_WhereClause         => 'F1=1'
                       ,pin_EarningEntity      =>  'F2'
 ,pin_ColumnMapping     =>  null
 ,pin_EntityMapping     =>  null
                       ,pin_operationType       => 6
                       ,pin_AggregatedField     => 'F1'
                       );
  end;


  */

  as
    v_insert_sql clob;
    v_type_sql varchar2(10);
    v_input_cols clob := '';
    v_GTT_cols clob :='';
    v_input_additional_cols clob := '';
    v_GTT_additional_cols clob :='';
    v_extra_join clob :='';
    v_input_cols_alias clob :='';
    v_input_additional_cols_alias clob :='';
    v_where_clause clob := '';
    v_result_null clob := '';
    v_entity_instance clob := '';
    v_entity_instance_change clob :='';
    v_flag_rejected clob :='';
    v_prior_period_value clob:='';
    v_final_value clob:='';
    v_join_condition_change clob :='';
    v_join_condition_baseline clob :='';
    v_period_filter_prior clob :='';
    v_period_filter_base clob :='';
    v_projected_filter_prior clob :='';
    v_projected_filter_base clob :='';
    v_earningEntity clob:='';
    v_earningEntityBk clob:='';
    v_entity_instance_flag clob :='';
    v_prec_scale_current clob :='';
    v_prec_scale_prior clob :='';
    v_prec_scale_final clob :='';
    v_zero_divide_change clob :='';
    v_final_value_percent clob :='';
    v_current_period_value clob :='';
    v_entity_field_join clob :='';
    v_entity_field_bk clob :='';
    v_flag_zero_one number;
    v_stamp            VARCHAR2(250);
    V_TOTAL_ROWCOUNT integer;
    V_REJECTED_ROWCOUNT integer;
    V_ACCEPTED_ROWCOUNT integer;
    v_additional_clause clob;
  begin
    v_stamp := 'METRICS.Aggregates - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');


    BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable),    ',pin_inputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput),    ',pin_JoinedInput => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause),    ',pin_WhereClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EarningEntity),    ',pin_EarningEntity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ColumnMapping),    ',pin_ColumnMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping),    ',pin_EntityMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operationType),    ',pin_operationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodTable),    ',pin_priorPeriodTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodColumn),    ',pin_priorPeriodColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projectedFlag),    ',pin_projectedFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_baseLineTable),    ',pin_baseLineTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_priorPeriod),      ',pin_priorPeriod => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calculationType),    ',pin_calculationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_PriorPeriodFlag),    ',pin_PriorPeriodFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_AggregatedField),    ',pin_AggregatedField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION   (pin_MetricInputFields),      ',pin_MetricInputFields =>          <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION   (pin_MetricFilterInputFields),',pin_MetricFilterInputFields =>    <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION   (pin_MetricInputConstants),   ',pin_MetricInputConstants =>       <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2     (pin_MetricInputTable),       ',pin_MetricInputTable =>           <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2     (pin_MetricInputSequence),    ',pin_MetricInputSequence =>        <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricPeriodField),    ',pin_MetricPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricPeriodValue),    ',pin_MetricPeriodValue => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricProjectedPeriodField),    ',pin_MetricProjectedPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricProjectedPeriodValue),    ',pin_MetricProjectedPeriodValue => <value>', v_stamp);

   END;
    begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;

    if pin_inputTable is null then
      raise_application_error(-20001, 'Input table can not be null');
    end if;

    if pin_AggregatedField is null then
      raise_application_error(-20001, 'Aggregated field can not be null');
    end if;

    if pin_EarningEntity is null then
      raise_application_error(-20001, 'Earning entity column can not be null');
    end if;

    if (pin_operationType = 6) then
       v_type_sql := 'SUM';
    elsif (pin_operationType = 7) then
       v_type_sql := 'AVG';
    elsif (pin_operationType = 8) then
       v_type_sql := 'MIN';
    elsif (pin_operationType = 9) then
       v_type_sql := 'MAX';
    end if;

    v_prec_scale_final := commons.FIELD_PRECISION_AND_SCALE('METRIC');
    v_prec_scale_current := commons.FIELD_PRECISION_AND_SCALE('CURRENT_PERIOD_AMOUNT');
    v_prec_scale_prior   := commons.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_AMOUNT');
    v_earningEntity := SUBSTR(pin_EarningEntity(1).NAME1, INSTR(pin_EarningEntity(1).NAME1,'.')+1);
    v_earningEntityBk := pin_EarningEntity(1).NAME2;
    v_gtt_cols           := ' MA_EARNINGS_ENTITY, MA_EARNINGS_ENTITY_BK ';
    v_input_cols_alias   := pin_EarningEntity(1).NAME1 || ' MA_EARNINGS_ENTITY, '||v_earningEntityBk || ' MA_EARNINGS_ENTITY_BK ';

    --this variable is for empty values validation (we should not populate the GTT with empty values in result field
    v_result_null := ' WHEN MA_CURRENT_PERIOD_AMOUNT IS NULL THEN ';
    --if we need to calculate change in value then we need to first validate that for each record in the input exists a record in the prior period table or the baseline table
    IF pin_calculationType=2 OR pin_calculationType=3 THEN
          IF pin_PriorPeriodFlag IN (1,2) THEN
             --v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON TAB.MA_EARNINGS_ENTITY='||pin_priorPeriodTable||'.'||v_earningEntity;
             v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON ' || commons_utils.get_equal_match_condition('TAB.MA_EARNINGS_ENTITY',
                                                                                                                               pin_priorPeriodTable || '.' || v_earningEntity,
                                                                                                                               1,
                                                                                                                               6);
          ELSIF pin_PriorPeriodFlag = 3 THEN
             --v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON TAB.MA_EARNINGS_ENTITY='||pin_baseLineTable||'.'||v_earningEntity;
             v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON ' || commons_utils.get_equal_match_condition('TAB.MA_EARNINGS_ENTITY',
                                                                                                                               pin_baseLineTable || '.' || v_earningEntity,
                                                                                                                               1,
                                                                                                                               6);
          END IF;
    END IF;

    if pin_projectedFlag = 1 and (pin_calculationType = 2 OR pin_calculationType=3) then --OR pin_calculationType=3
      IF pin_PriorPeriodFlag IN (1,2) THEN
       v_projected_filter_prior := ' AND '||pin_priorPeriodTable||'.PROJECTED=0 ';
      end if;
    end if;

    if pin_ColumnMapping is not null then
      begin
        FOR i IN 1..pin_ColumnMapping.COUNT LOOP
            v_input_additional_cols := v_input_additional_cols || pin_inputTable || '.' || pin_ColumnMapping(i).NAME1 ||',';
            v_input_additional_cols_alias := v_input_additional_cols_alias || ',' || pin_inputTable || '.' || pin_ColumnMapping(I).NAME1 || ' ' || pin_ColumnMapping(I).NAME2;
            v_gtt_additional_cols := v_gtt_additional_cols ||','|| pin_ColumnMapping(i).NAME2 ;

            --in case we have change in value
            IF pin_calculationType=2 OR pin_calculationType=3 THEN
              IF pin_PriorPeriodFlag IN (1,2) THEN
                 v_join_condition_change := v_join_condition_change ||  '
                         AND (TAB.'||pin_ColumnMapping(i).NAME2 ||
                         '='||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (TAB.' || pin_ColumnMapping(i).NAME2||' IS NULL AND '||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' IS NULL ))';
               ELSIF pin_PriorPeriodFlag = 3 THEN
                 v_join_condition_baseline :=  v_join_condition_baseline ||  '
                         AND (TAB.'||pin_ColumnMapping(i).NAME2 ||
                         '='||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (TAB.' || pin_ColumnMapping(i).NAME2||' IS NULL AND '||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)|| ' IS NULL ))'
                         ;
               END IF          ;
            end if;
        END LOOP;
      end;
    end if;

    if pin_EntityMapping is not null then
      begin
        FOR i IN 1..pin_EntityMapping.COUNT LOOP

            IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping(i).NAME1);
            ELSE
              v_entity_field_join:= pin_EntityMapping(i).NAME2;
              v_entity_field_bk :=pin_inputTable ||'.'||pin_EntityMapping(i).NAME2;
            END IF;

            --in case we have change in value
            IF pin_calculationType=2 OR pin_calculationType=3 THEN
              IF pin_PriorPeriodFlag IN (1,2) THEN
                 v_join_condition_change := v_join_condition_change ||  '
                         AND (TAB.'||pin_EntityMapping(i).NAME4 ||
                         '='||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (TAB.' || pin_EntityMapping(i).NAME4||' IS NULL AND '||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))';
               ELSIF pin_PriorPeriodFlag=3 THEN
                 v_join_condition_baseline :=  v_join_condition_baseline ||  '
                         AND (TAB.'||pin_EntityMapping(i).NAME4 ||
                         '='||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (TAB.' || pin_EntityMapping(i).NAME4||' IS NULL AND '||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))';
               END IF;
            end if;

            v_input_cols := v_input_cols || v_entity_field_bk ||','||pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID,';
            v_input_cols_alias   := v_input_cols_alias || ','
                                 ||v_entity_field_bk || ' ' || pin_EntityMapping(i).NAME3 ||
                               ',' || pin_EntityMapping(i).NAME1 || '.E_INTERNAL_ID ' || pin_EntityMapping(i).NAME4;
            v_gtt_cols := v_gtt_cols ||',' || pin_EntityMapping(i).NAME3 ||','|| pin_EntityMapping(i).NAME4;
--            v_entity_instance := v_entity_instance || pin_EntityMapping(i).NAME4 || ' IS NULL OR ';
        END LOOP;

      end;
    end if;

    v_input_cols := v_input_additional_cols ||  v_input_cols;
    v_input_cols_alias := v_input_cols_alias || v_input_additional_cols_alias ;
    v_gtt_cols := v_gtt_cols || v_gtt_additional_cols ;

    if pin_WhereClause is not null then
        v_where_clause := ' WHERE '||pin_WhereClause;
    end if;

    if pin_calculationType=2 OR pin_calculationType=3 then
      IF pin_PriorPeriodFlag IN (1,2) THEN
        v_period_filter_prior := ' AND '||pin_priorPeriodTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_prior;
      ELSIF pin_PriorPeriodFlag=3 THEN
        v_period_filter_base := ' AND '||pin_baseLineTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_base;
      END IF;
    end if;
    v_final_value_percent := ' MA_FINAL_VALUE ';

    if pin_EntityMapping is not null then
      begin
        FOR i IN 1..pin_EntityMapping.COUNT LOOP

            IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_flag_zero_one := 0;
            ELSE

              --validation 1020
              v_entity_instance := v_entity_instance ||' WHEN '|| pin_EntityMapping(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping(i).NAME3 || ' IS NOT NULL THEN
                         INTO TEMP_METRIC_AGG_REJECTED  ( MA_ID,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, MA_FINAL_VALUE, MA_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                        VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, NULL, 2, 1020, 1,'''||pin_EntityMapping(i).NAME1||','||pin_EntityMapping(i).NAME2||''')';
              v_entity_instance_flag := v_entity_instance_flag || ' WHEN ' || pin_EntityMapping(i).NAME4 || ' IS NULL THEN 2 ' ;

            END IF;
        END LOOP;
      end;
    end if;

    -- the flag is set to 1 for NOT NULL validation in result field, set to 2 in case of normal entity validation (done in all cases) and set to 3 in case of
    -- change in value validation (existence in prior period/baseline table-done only when the calculation type is 2 or 3)
    if pin_calculationType <> 1 then --change in value or percent change

      v_entity_instance_change := --the when part for missing entity validation (the one where entities from input need to exist in prior period/baseline table)
       ' WHEN MA_PRIOR_PERIOD_AMOUNT IS NULL THEN
                 INTO TEMP_METRIC_AGG_REJECTED  ( MA_ID,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, MA_FINAL_VALUE, MA_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
              VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, NULL, 3, 1180, 1,NULL)';
      IF pin_PriorPeriodFlag IN (1,2) THEN
            v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag ||'
             WHEN '||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT IS NULL THEN 3 END ' ;
      ELSIF  pin_PriorPeriodFlag = 3 THEN
            v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag ||'
       WHEN '||pin_baseLineTable||'.BASELINE_VALUE IS NULL THEN 3 END ' ;
      END IF;
      v_current_period_value := ' MA_CURRENT_PERIOD_AMOUNT ';
      --v_prior_period_value is the current value in the prior period table
      IF pin_PriorPeriodFlag IN (1,2) THEN
         v_prior_period_value := ','||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT AS MA_PRIOR_PERIOD_AMOUNT ';
      ELSIF pin_PriorPeriodFlag = 3 THEN
         v_prior_period_value := ','||pin_baseLineTable||'.BASELINE_VALUE AS MA_PRIOR_PERIOD_AMOUNT ';
      END IF;
      v_final_value := ' MA_CURRENT_PERIOD_AMOUNT - MA_PRIOR_PERIOD_AMOUNT ';

      if pin_calculationType = 3 then --percent change in value
        v_zero_divide_change :=  ' WHEN MA_PRIOR_PERIOD_AMOUNT = 0 THEN
                 INTO TEMP_METRIC_AGG_REJECTED  ( MA_ID,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, MA_FINAL_VALUE, MA_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
              VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, NULL, 4, 1190, 1, NULL)';
        v_final_value := '('||v_final_value ||')/ABS(MA_PRIOR_PERIOD_AMOUNT)';
      end if;
    else --normal case (value)
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || ' END ' ;
      v_prior_period_value :=',NULL AS MA_PRIOR_PERIOD_AMOUNT ';
      v_final_value := ' MA_CURRENT_PERIOD_AMOUNT ';
      v_current_period_value :=' NULL ';
    end if;

    v_insert_sql := ' INSERT ALL
                 WHEN MA_CURRENT_PERIOD_AMOUNT IS NULL THEN  --the when part for NULL validation
                 INTO TEMP_METRIC_AGG_REJECTED  ( MA_ID,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, MA_FINAL_VALUE, MA_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                      VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, NULL, 1, 1050, 1,NULL)'
                 || v_entity_instance_change ||  --the when part for missing entity validation in case of change value only (the one where entities from input need to exist in the prior period/baseline table)
                 v_entity_instance || v_zero_divide_change || '
                 ELSE INTO TEMP_METRIC_AGGREGATIONS ( MA_ID,'||v_gtt_cols||',MA_CURRENT_PERIOD_AMOUNT, MA_PRIOR_PERIOD_AMOUNT, MA_FINAL_VALUE, MA_FLAG)
                      VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',CAST('||v_current_period_value||'   AS NUMBER'||v_prec_scale_current||')
                      , CAST(MA_PRIOR_PERIOD_AMOUNT   AS NUMBER'||v_prec_scale_prior||')
                      , CAST('||v_final_value ||' AS NUMBER'||v_prec_scale_final||'), NULL)
                SELECT ' || v_gtt_cols ||',MA_CURRENT_PERIOD_AMOUNT  '
                       || v_prior_period_value || ',' ||
                  v_flag_rejected ||' MA_FLAG
                FROM (  SELECT '|| v_input_cols_alias ||','
            || v_type_sql || '(' || pin_inputTable || '.' || pin_AggregatedField || ') AS MA_CURRENT_PERIOD_AMOUNT
             FROM  ' ||pin_JoinedInput || v_extra_join || v_where_clause ||
            ' GROUP BY ' || v_input_cols ||pin_EarningEntity(1).NAME1 || ','||v_earningEntityBk ||')  tab '
            || v_join_condition_change ||v_period_filter_prior|| v_join_condition_baseline || v_period_filter_base ;

      ALTER_SESSION_TIMESTAMP;
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_insert_sql), 'v_insert_sql := <value>;', v_stamp);
      execute immediate v_insert_sql;

      -- set cardinality for temp tables
      V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;
      select count(*) into V_REJECTED_ROWCOUNT from TEMP_METRIC_AGG_REJECTED;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_AGG_REJECTED', V_REJECTED_ROWCOUNT);
      V_ACCEPTED_ROWCOUNT := V_TOTAL_ROWCOUNT - V_REJECTED_ROWCOUNT;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_AGGREGATIONS', V_ACCEPTED_ROWCOUNT);

   if pin_MetricInputTable is not null then
     v_additional_clause :=  V_EXTRA_JOIN ||  V_WHERE_CLAUSE;
      METRIC_INPUTS_AGG (
          pin_inputTable               =>pin_inputTable
          ,pin_JoinedInput             =>pin_JoinedInput
          ,pin_EarningEntity           =>pin_EarningEntity
          ,pin_ColumnMapping           =>pin_ColumnMapping
          ,pin_EntityMapping           =>pin_EntityMapping
          ,pin_MetricInputFields       =>pin_MetricInputFields
          ,pin_MetricFilterInputFields =>pin_MetricFilterInputFields
          ,pin_MetricInputConstants    =>pin_MetricInputConstants
          ,pin_MetricInputTable        =>pin_MetricInputTable
          ,pin_MetricInputSequence     =>pin_MetricInputSequence
          ,pin_additional_clause       =>v_additional_clause
          ,pin_projectedFlag           =>pin_projectedFlag
          ,pin_MetricPeriodField          =>pin_MetricPeriodField
          ,pin_MetricPeriodValue          =>pin_MetricPeriodValue
          ,pin_MetricProjectedPeriodField =>pin_MetricProjectedPeriodField
          ,pin_MetricProjectedPeriodValue =>pin_MetricProjectedPeriodValue
          ,pin_operationType              =>pin_operationType
      );
   end if;

      begin
         compensation_processing.ALTER_SESSION_NLS_BINARY;
      end;
  EXCEPTION
      WHEN CANNOT_INSERT_NULL THEN
         RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
  END Metric_Aggregates;
------------------------

  PROCEDURE METRICS_VALUES (pin_inputTable         IN VARCHAR2
                           ,pin_JoinedInput        IN VARCHAR2
                           ,pin_WhereClause        IN VARCHAR2
                           ,pin_EarningEntity      IN TABLETYPE_NAME_MAP
                           ,pin_ColumnMapping      IN TABLETYPE_NAME_MAP
                           ,pin_EntityMapping      IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_operationType      IN NUMBER
                           ,pin_priorPeriodTable   IN VARCHAR2
                           ,pin_priorPeriodColumn  IN VARCHAR2
                           ,pin_projectedFlag      IN NUMBER
                           ,pin_baseLineTable      IN VARCHAR2
                           ,pin_priorPeriod        IN NUMBER
                           ,pin_calculationType    IN NUMBER
                           ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                           ,pin_columnNames        IN VARCHAR2
)
-----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process: Execute operation indicated by pin_operationType param and insert result in global temp table
      -- Input Parameters:
      --    pin_inputTable         the actual input table
      --    pin_JoinedInput        the join condition between the input and periods/entity/roster (coming from inputs processing)
      --    pin_WhereClause        the filter from input processing (Separate because we have extra joins)
      --    pin_EarningEntity      earning entity column from the input
      --    pin_ColumnMapping      column mapping for additional fields (an array of elements like (F1,MA_EARNINGS_ENTITY), (F2,MA_METRIC_CALC_ENTITY_NAME_1)
      --                                        ,(T123.e_entity_id, MA_METRIC_CALC_ENTITY_ID_1 )
      --    pin_EntityMapping      entity mapping containing  an 4 dimensional array of elements as 'T123', F3 - F3 is the business key name from the input table
      --    pin_operationType      (1 - value, 2 - sum, 3 - avg, 4 - min, 5 - max)
      --    pin_columnNames        column names on which to execute operation
-----------------------------------------------------------------------------------------------
      --    Call statement:
      /*    begin
               METRICS_PROCESSING.METRICS_VALUES(pin_inputTable         => 'T1759'
                                                ,pin_JoinedInput        => 'T1759'
                                                ,pin_WhereClause        => 'F1=1'
                                                ,pin_EarningEntity      => 'F2'
                                                ,pin_ColumnMapping      => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F5','MV_METRIC_CALC_ENTITY_NAME_2'))
                                                ,pin_EntityMapping      => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('entity_table','F3','MV_METRIC_CALC_ENTITY_NAME_1','MV_METRIC_CALC_ENTITY_ID_1'))
                                                ,pin_operationType      => 6
                                                ,pin_AggregatedField    => 'F1');
            end;*/
-----------------------------------------------------------------------------------------------
IS
    V_DML_STATEMENT            CLOB;
    V_OPERATION                CLOB;
    V_EXTRA_JOIN               CLOB;
    V_INPUT_COLS               CLOB;
    V_GTT_COLS                 CLOB;
    V_ADDITIONAL_INPUT_COLS    CLOB;
    V_ADDITIONAL_GTT_COLS      CLOB;
    V_COLUMN_NAMES             CLOB;
    V_WHERE_CLAUSE             CLOB;
    V_COALESCE_COLUMNS         CLOB;
    V_AVG_NUMERATOR            CLOB;
    V_AVG_DENOMINATOR          CLOB;
    v_result_null              clob := '';
    v_entity_instance          clob := '';
    v_entity_instance_change   clob :='';
    v_flag_rejected            clob :='';
    v_prior_period_value       clob:='';
    v_current_period_value     clob:='';
    v_final_value              clob:='';
    v_join_condition_change    clob :='';
    v_join_condition_baseline  clob :='';
    v_period_filter_prior      clob :='';
    v_period_filter_base       clob :='';
    v_projected_filter_prior   clob :='';
    v_projected_filter_base    clob :='';
    v_earningEntity            clob:='';
    v_earningEntityBk          clob:='';
    v_entity_instance_flag     clob :='';
    v_prec_scale_current       clob :='';
    v_prec_scale_prior         clob :='';
    v_prec_scale_final         clob :='';
    v_zero_divide_change       clob :='';
    v_final_value_percent      clob :='';
    v_entity_field_join        clob :='';
    v_entity_field_bk          clob :='';
    v_flag_zero_one            number;
    v_stamp            VARCHAR2(250);
    V_TOTAL_ROWCOUNT integer;
    V_REJECTED_ROWCOUNT integer;
    V_ACCEPTED_ROWCOUNT integer;
     v_input_constant_fields varchar2(32767);
     v_additional_clause clob;
  begin
  v_stamp := 'METRICS.Values - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;
    BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable),    ',pin_inputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput),    ',pin_JoinedInput => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause),    ',pin_WhereClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EarningEntity),    ',pin_EarningEntity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ColumnMapping),    ',pin_ColumnMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping),    ',pin_EntityMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operationType),    ',pin_operationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodTable),    ',pin_priorPeriodTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodColumn),    ',pin_priorPeriodColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projectedFlag),    ',pin_projectedFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_baseLineTable),    ',pin_baseLineTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_priorPeriod),      ',pin_priorPeriod => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calculationType),    ',pin_calculationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_PriorPeriodFlag),    ',pin_PriorPeriodFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_columnNames),    ',pin_columnNames => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION   (pin_MetricInputFields),      ',pin_MetricInputFields =>          <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION   (pin_MetricFilterInputFields),',pin_MetricFilterInputFields =>    <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION   (pin_MetricInputConstants),   ',pin_MetricInputConstants =>       <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2     (pin_MetricInputTable),       ',pin_MetricInputTable =>           <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2     (pin_MetricInputSequence),    ',pin_MetricInputSequence =>        <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricPeriodField),    ',pin_MetricPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricPeriodValue),    ',pin_MetricPeriodValue => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricProjectedPeriodField),    ',pin_MetricProjectedPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricProjectedPeriodValue),    ',pin_MetricProjectedPeriodValue => <value>', v_stamp);

   END;
     -- VALIDATION PART
   IF PIN_INPUTTABLE IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_selectQuery parameter can not be null');
   ELSIF PIN_OPERATIONTYPE IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_operationType parameter can not be null');
   ELSIF PIN_COLUMNNAMES IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_columnNames parameter can not be null');
   END IF;

    v_prec_scale_final := commons.FIELD_PRECISION_AND_SCALE('METRIC');
    v_prec_scale_current := commons.FIELD_PRECISION_AND_SCALE('CURRENT_PERIOD_AMOUNT');
    v_prec_scale_prior   := commons.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_AMOUNT');

   -- Prefix column names with table name
   V_COLUMN_NAMES := PIN_INPUTTABLE || '.' || REPLACE(PIN_COLUMNNAMES, ',', ',' || PIN_INPUTTABLE || '.');
   -- For LEAST and GREATEST use NVL(COL,COALESCE).
   -- Added NULL for the case when column_names contains only one column.
   V_COALESCE_COLUMNS := 'COALESCE(' || V_COLUMN_NAMES || ',NULL)';
   --
   IF PIN_OPERATIONTYPE = 1 THEN
      -- If VALUE operation of values metric type
      V_OPERATION := V_COLUMN_NAMES;
   ELSIF PIN_OPERATIONTYPE = 2 THEN
      -- If SUM operation of values metric type
      -- Add and substract V_COALESCE_COLUMNS in order to keep null if all columns are null
      V_OPERATION := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL(' || REPLACE(V_COLUMN_NAMES, ',', ',0)+NVL(') || ',0)))';
   ELSIF PIN_OPERATIONTYPE = 3 THEN
      -- If AVG operation of values metric type
      -- Add and substract V_COALESCE_COLUMNS in order to keep null if all columns are null
      V_AVG_NUMERATOR   := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL(' || REPLACE(V_COLUMN_NAMES, ',', ',0)+NVL(') || ',0)))';
      V_AVG_DENOMINATOR := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL2(' || REPLACE(V_COLUMN_NAMES, ',', ',1,0)+NVL2(') || ',1,0)))';
      V_OPERATION := V_AVG_NUMERATOR || '/' || V_AVG_DENOMINATOR;
   ELSIF PIN_OPERATIONTYPE = 4 THEN
      -- If MIN operation of values metric type
      V_OPERATION := 'LEAST(NVL(' || REPLACE(V_COLUMN_NAMES, ',', ',' || V_COALESCE_COLUMNS || '),NVL(') || ',' || V_COALESCE_COLUMNS || '))';
   ELSIF PIN_OPERATIONTYPE = 5 THEN
      -- If MAX operation of values metric type
      V_OPERATION := 'GREATEST(NVL(' || REPLACE(V_COLUMN_NAMES, ',', ',' || V_COALESCE_COLUMNS || '),NVL(') || ',' || V_COALESCE_COLUMNS || '))';
   END IF;
   --
   v_earningEntity := SUBSTR(pin_EarningEntity(1).NAME1, INSTR(pin_EarningEntity(1).NAME1,'.')+1);
   v_earningEntityBk := pin_EarningEntity(1).NAME2;
   V_GTT_COLS     := 'MV_ID,MV_EARNINGS_ENTITY,MV_EARNINGS_ENTITY_BK';
   V_INPUT_COLS   := pin_inputTable || '.ROW_IDENTIFIER MV_ID,' || pin_EarningEntity(1).NAME1 || ' MV_EARNINGS_ENTITY,'
                  || pin_EarningEntity(1).NAME2 || ' MV_EARNINGS_ENTITY_BK';

    --this variable is for empty values validation (we should not populate the GTT with empty values in result field
    v_result_null := ' WHEN MV_CURRENT_PERIOD_AMOUNT IS NULL THEN ';
    --if we need to calculate change in value then we need to first validate that for each record in the input exists a record in the prior period table or the baseline table
    IF pin_calculationType=2 OR pin_calculationType=3 THEN
      if pin_PriorPeriodFlag IN (1,2) THEN
          --v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON '||pin_EarningEntity(1).NAME1||'='||pin_priorPeriodTable||'.'||v_earningEntity;
          v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON ' || commons_utils.get_equal_match_condition(pin_EarningEntity(1).NAME1,
                                                                                                                            pin_priorPeriodTable || '.' || v_earningEntity,
                                                                                                                            1,
                                                                                                                            6);
      elsif pin_PriorPeriodFlag = 3 THEN
          --v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON '||pin_EarningEntity(1).NAME1||'='||pin_baseLineTable||'.'||v_earningEntity;
          v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON ' || commons_utils.get_equal_match_condition(pin_EarningEntity(1).NAME1,
                                                                                                                           pin_baseLineTable || '.' || v_earningEntity,
                                                                                                                           1,
                                                                                                                           6);
      end if;
    END IF;

    if pin_projectedFlag = 1 and (pin_calculationType=2 OR pin_calculationType=3) then
      IF pin_PriorPeriodFlag IN (1,2) THEN
       v_projected_filter_prior := ' AND '||pin_priorPeriodTable||'.PROJECTED=0 ';

      END IF;
--       v_projected_filter_base :=  ' AND '||pin_baseLineTable||'.PROJECTED=0';
    end if;

   -- Create joins and map columns
   IF PIN_ENTITYMAPPING IS NOT NULL THEN
      FOR I IN 1..PIN_ENTITYMAPPING.COUNT LOOP


          IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping(i).NAME1);
            ELSE
              v_entity_field_join:= pin_EntityMapping(i).NAME2;
              v_entity_field_bk :=pin_inputTable ||'.'||pin_EntityMapping(i).NAME2;
            END IF;

         V_INPUT_COLS := V_INPUT_COLS || ',' || v_entity_field_bk || ' AS '||PIN_ENTITYMAPPING(I).NAME3 ||
                         ',' || PIN_ENTITYMAPPING(I).NAME1 || '.E_INTERNAL_ID AS '|| PIN_ENTITYMAPPING(I).NAME4;
         V_GTT_COLS := V_GTT_COLS || ',' || PIN_ENTITYMAPPING(I).NAME3 ||','|| PIN_ENTITYMAPPING(I).NAME4;

               --in case we have change in value  (need to join the prior period table with the entity (the
            IF pin_calculationType=2 OR pin_calculationType=3 THEN
              IF pin_PriorPeriodFlag IN (1,2) THEN
                 v_join_condition_change := v_join_condition_change ||  '
                         AND ('|| pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ='||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID IS NULL AND '||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
              ELSIF pin_PriorPeriodFlag =3  THEN
                 v_join_condition_baseline :=  v_join_condition_baseline ||  '
                         AND ('|| pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ='||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID IS NULL AND '||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))';
              END IF;
            end if;
      END LOOP;
   END IF;
   -- Create additional fields
   IF PIN_COLUMNMAPPING IS NOT NULL THEN
      FOR I IN 1..PIN_COLUMNMAPPING.COUNT LOOP
         V_ADDITIONAL_INPUT_COLS := V_ADDITIONAL_INPUT_COLS || ',' || pin_inputTable || '.' || PIN_COLUMNMAPPING(I).NAME1||' AS ' || PIN_COLUMNMAPPING(I).NAME2;
         V_ADDITIONAL_GTT_COLS   := V_ADDITIONAL_GTT_COLS   || ',' || PIN_COLUMNMAPPING(I).NAME2;
  --       v_entity_instance := v_entity_instance || pin_ColumnMapping(i).NAME2 || ' IS NULL OR ' ; not needed anymore since empty values are allowed in the MCE fields
            --in case we have change in value
         IF pin_calculationType=2 OR pin_calculationType=3 THEN
           IF pin_PriorPeriodFlag IN (1,2) THEN
             v_join_condition_change := v_join_condition_change ||  '
                     AND ('||pin_inputTable||'.'||pin_ColumnMapping(i).NAME1 ||'='||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (' || pin_inputTable||'.'|| pin_ColumnMapping(i).NAME1||' IS NULL AND '||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' IS NULL ))'
                     ;
           ELSIF pin_PriorPeriodFlag = 3 THEN
             v_join_condition_baseline :=  v_join_condition_baseline ||  '
                     AND ('||pin_inputTable||'.'||pin_ColumnMapping(i).NAME1 ||'='||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (' || pin_inputTable||'.'|| pin_ColumnMapping(i).NAME1||' IS NULL AND '||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)|| ' IS NULL ))'
                          ;
           END IF;
         end if;
      END LOOP;

   END IF;


   --create filters for change in value
   if pin_calculationType=2 OR pin_calculationType=3 then
     IF pin_PriorPeriodFlag IN (1,2) THEN
      v_period_filter_prior := ' AND '||pin_priorPeriodTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_prior;
     ELSIF pin_PriorPeriodFlag = 3 THEN
      v_period_filter_base  := ' AND '||pin_baseLineTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_base;
     END IF;
    end if;

     -- Create final fields
     V_INPUT_COLS   := V_INPUT_COLS   || V_ADDITIONAL_INPUT_COLS;
     V_GTT_COLS     := V_GTT_COLS     || V_ADDITIONAL_GTT_COLS;
     -- Create WHERE clause
     IF PIN_WHERECLAUSE IS NOT NULL THEN
        V_WHERE_CLAUSE := ' WHERE ' || PIN_WHERECLAUSE;
     END IF;

    v_final_value_percent := ' MV_FINAL_VALUE ';

     IF PIN_ENTITYMAPPING IS NOT NULL THEN
      FOR I IN 1..PIN_ENTITYMAPPING.COUNT LOOP
          IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_flag_zero_one := 0;
            ELSE
              --validation 1020
              v_entity_instance := v_entity_instance || ' WHEN ' || pin_EntityMapping(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping(i).NAME3 || ' IS NOT NULL THEN
              INTO TEMP_METRIC_VALUES_REJECTED  ( '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT,MV_FINAL_VALUE,MV_FLAG, MV_CURRENT_PERIOD_AMOUNT, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                              VALUES ( '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT, NULL,2, MV_CURRENT_PERIOD_AMOUNT, 1020, 1,'''||pin_EntityMapping(i).NAME1||','||pin_EntityMapping(i).NAME2||''')';

              v_entity_instance_flag := v_entity_instance_flag || ' WHEN ' || pin_EntityMapping(i).NAME4 || ' IS NULL THEN 2 ' ;

            END IF;
      END LOOP;
   END IF;


    -- the flag is set to 1 for NOT NULL validation in result field, set to 2 in case of normal entity validation (done in all cases) and set to 3 in case of
    -- change in value validation (existence in prior period/baseline table-done only when the calculation type is 2 or 3)
    if pin_calculationType <> 1 then --change in value or percent change
      v_entity_instance_change := --the when part for missing entity validation (the one where entities from input need to exist in prior period/baseline table)
       ' WHEN MV_PRIOR_PERIOD_AMOUNT IS NULL THEN
                 INTO TEMP_METRIC_VALUES_REJECTED  ( '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT,MV_FINAL_VALUE,MV_FLAG, MV_CURRENT_PERIOD_AMOUNT, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                 VALUES ( '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT, NULL,3, MV_CURRENT_PERIOD_AMOUNT, 1180, 1, NULL)';
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || ' WHEN MV_PRIOR_PERIOD_AMOUNT IS NULL THEN 3 END AS MV_FLAG' ;
      IF pin_PriorPeriodFlag IN (1,2) THEN
       v_prior_period_value := ','||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT AS MV_PRIOR_PERIOD_AMOUNT ';
      ELSIF pin_PriorPeriodFlag = 3 THEN
       v_prior_period_value := ','||pin_baseLineTable||'.BASELINE_VALUE AS MV_PRIOR_PERIOD_AMOUNT ';
      END IF;
      v_current_period_value := ' MV_CURRENT_PERIOD_AMOUNT ' ;
      --v_prior_period_value is the current value in the prior period table

      v_final_value := ' MV_CURRENT_PERIOD_AMOUNT - MV_PRIOR_PERIOD_AMOUNT ';

      if pin_calculationType = 3 then --percent change in value
        v_zero_divide_change :=  ' WHEN MV_PRIOR_PERIOD_AMOUNT = 0 THEN
                 INTO TEMP_METRIC_VALUES_REJECTED  ('||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT,MV_FINAL_VALUE,MV_FLAG, MV_CURRENT_PERIOD_AMOUNT, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
           VALUES ( '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT, NULL,4, MV_CURRENT_PERIOD_AMOUNT, 1190, 1, NULL)';
        v_final_value := ' ('||v_final_value||')/ABS(MV_PRIOR_PERIOD_AMOUNT)';
      end if;
    else --normal case (value)
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || ' END AS MV_FLAG' ;
      v_prior_period_value :=',NULL MV_PRIOR_PERIOD_AMOUNT';
      v_final_value := ' MV_CURRENT_PERIOD_AMOUNT ';
      v_current_period_value:= ' NULL ';
    end if;

      -- Create insert statement
     V_DML_STATEMENT := ' INSERT ALL
       WHEN MV_CURRENT_PERIOD_AMOUNT IS NULL THEN
         INTO TEMP_METRIC_VALUES_REJECTED  ('||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT,MV_FINAL_VALUE,MV_FLAG, MV_CURRENT_PERIOD_AMOUNT , VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
           VALUES ( '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT, NULL,1, MV_CURRENT_PERIOD_AMOUNT, 1050, 1, NULL)'
         || v_entity_instance_change   --the when part for missing entity validation in case of change value only (the one where entities from input need to exist in the prior period/baseline table)
         || v_entity_instance || v_zero_divide_change || '
       ELSE
         INTO TEMP_METRIC_VALUES  ('||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT,MV_FINAL_VALUE,MV_FLAG, MV_CURRENT_PERIOD_AMOUNT)
                 VALUES ( '||v_gtt_cols||'
              ,CAST(MV_PRIOR_PERIOD_AMOUNT AS NUMBER ' || v_prec_scale_prior || ')
              ,CAST('||v_final_value||' AS NUMBER'||v_prec_scale_final||'),NULL
              ,CAST('||v_current_period_value||' AS NUMBER' || v_prec_scale_current || '))
         SELECT  '||v_gtt_cols||',MV_PRIOR_PERIOD_AMOUNT '
         ||','||v_flag_rejected||'
         ,  MV_CURRENT_PERIOD_AMOUNT FROM (
           SELECT ' || V_INPUT_COLS ||v_prior_period_value|| ','||
                       V_OPERATION || ' AS MV_CURRENT_PERIOD_AMOUNT FROM ' || PIN_JOINEDINPUT || V_EXTRA_JOIN
                       ||v_join_condition_change||v_period_filter_prior||v_join_condition_baseline||v_period_filter_base||V_WHERE_CLAUSE|| ') TAB';

   ALTER_SESSION_TIMESTAMP;
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_DML_STATEMENT), 'V_DML_STATEMENT := <value>;', v_stamp);
   EXECUTE IMMEDIATE V_DML_STATEMENT;

      -- set cardinality for temp tables
      V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;
      select count(*) into V_REJECTED_ROWCOUNT from TEMP_METRIC_VALUES_REJECTED;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_VALUES_REJECTED', V_REJECTED_ROWCOUNT);
      V_ACCEPTED_ROWCOUNT := V_TOTAL_ROWCOUNT - V_REJECTED_ROWCOUNT;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_VALUES', V_ACCEPTED_ROWCOUNT);

   if pin_MetricInputTable is not null then
     v_additional_clause :=  V_EXTRA_JOIN ||  V_WHERE_CLAUSE;
      METRIC_INPUTS (
          pin_inputTable               =>pin_inputTable
          ,pin_JoinedInput             =>pin_JoinedInput
          ,pin_EarningEntity           =>pin_EarningEntity
          ,pin_ColumnMapping           =>pin_ColumnMapping
          ,pin_EntityMapping           =>pin_EntityMapping
          ,pin_MetricInputFields       =>pin_MetricInputFields
          ,pin_MetricFilterInputFields =>pin_MetricFilterInputFields
          ,pin_MetricInputConstants    =>pin_MetricInputConstants
          ,pin_MetricInputTable        =>pin_MetricInputTable
          ,pin_MetricInputSequence     =>pin_MetricInputSequence
          ,pin_additional_clause       =>v_additional_clause
          ,pin_projectedFlag           =>pin_projectedFlag
          ,pin_MetricPeriodField          =>pin_MetricPeriodField
          ,pin_MetricPeriodValue          =>pin_MetricPeriodValue
          ,pin_MetricProjectedPeriodField =>pin_MetricProjectedPeriodField
          ,pin_MetricProjectedPeriodValue =>pin_MetricProjectedPeriodValue
      );
   end if;

   begin
         compensation_processing.ALTER_SESSION_NLS_BINARY;
   end;
EXCEPTION
   WHEN CANNOT_INSERT_NULL THEN
      RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
END METRICS_VALUES;
------------------------
------------------------



  PROCEDURE METRIC_LOOKUP (pin_inputTable         IN VARCHAR2
                          ,pin_joinedInput        IN VARCHAR2
                          ,pin_whereClause        IN VARCHAR2
                          ,pin_earningEntity      IN TABLETYPE_NAME_MAP
                          ,pin_columnMapping      IN TABLETYPE_NAME_MAP
                          ,pin_entityMapping      IN TABLETYPE_NAME_JOIN_MAP
                          ,pin_operationType      IN NUMBER
                          ,pin_priorPeriodTable   IN VARCHAR2
                          ,pin_priorPeriodColumn  IN VARCHAR2
                          ,pin_projectedFlag      IN NUMBER
                          ,pin_baseLineTable      IN VARCHAR2
                          ,pin_priorPeriod        IN NUMBER
                          ,pin_calculationType    IN NUMBER
                          ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                          ,pin_lookupTable        IN VARCHAR2
                          ,pin_inputLookupColumn  IN VARCHAR2
                          ,pin_LessThanSmallest   IN NUMBER
                          ,pin_GreaterThanLargest IN NUMBER
                          ,pin_LookupWhereClause  in varchar2 default null
                          ,pin_LookupJoinClause   in varchar2 default null
                          ,pin_varyByFields       in varchar2 default null
                          ,pin_varyByRosterFields in varchar2 default null
                          ,pin_LookupEffProp      in TABLETYPE_DATE_RANGE_INTERNAL default null
                          ,pin_LookupPrecision    in number default null
                          )
    -----------------------------------------------------------------------------------------
    --  Input Parameters:
    --    pin_inputTable         the actual input table
    --    pin_JoinedInput        the join condition between the input and periods/entity/roster (coming from inputs processing)
    --    pin_WhereClause        the filter from input processing (Separate because we have extra joins)
    --    pin_EarningEntity      earning entity column from the input
    --                           NAME(i) - <roster_result_table>.<entity_column>
    --    pin_ColumnMapping      column mapping for additional fields
    --                           NAME(i) - <column_name>,<alias>
    --    pin_EntityMapping      entity mapping containing an 4 dimensional array of elements
    --    pin_operationType      22 - step lookup, 23 - continuous lookup, 24 - discrete lookup
    --    pin_priorPeriodTable   metric result table for prior period (can be null)
    --    pin_priorPeriodColumn  column name for prior period (can be null)
    --    pin_projectedFlag      projected: 0 - no, 1 - yes
    --    pin_baseLineTable      base line table name (can be null)
    --    pin_priorPeriod        prior period id (can be null)
    --    pin_calculationType    calculation type
    --    pin_PriorPeriodFlag    prior period flag: 0 - no, 1 - yes
    --    pin_lookupTable        the name of the lookup table
    --    pin_inputLookupColumn  the name of the lookup column from the input
    --    pin_LessThanSmallest   1-the result value from the smallest lookup value, 2-based on the slope between the two smallest lookup values, 5-zero, 6-an error
    --    pin_GreaterThanLargest 3-the result value from the largest lookup value, 5-zero, 6-an error
    --    pin_LookupWhereClause  the where clause for Lookup Vary By containing the range fields
    --    pin_LookupJoinClause   The join clause for Lookup using the aliases pin_EntityMapping(i).NAMEx prefixed with TAB for Input or Roster and LOOKUP for lookup table
    --    pin_varyByFields       List of fields comma separated
    --    pin_varyByRosterFields List of fields from Roster used for vary by comma separated
    --    pin_LookupEffProp      Collection of fields used for metric calculation if the lookup table is effective dated
    --                           ENTITY_COLUMN_NAME - processing date column from roster or input
    --                           RELATIONSHIP_TABLE_ALIAS - roster table or input table
    --                           ENTITY_DATE_RANGE_PART_1 - effective start date column from lookup
    --                           ENTITY_DATE_RANGE_PART_2 - effective end date column from lookup
    -----------------------------------------------------------------------------------------
    -- Output : pout_isError 1 - process failed, 0 - process runned with success
    -----------------------------------------------------------------------------------------
   /*call example:
     begin
     -- Call the procedure
     METRICS_PROCESSING.METRICS_LOOKUP(pin_inputTable => 'T3507545'
                                      ,pin_JoinedInput => 'T3527528_PART_255  INNER JOIN T3507526 ON T3507526.E_INTERNAL_ID = T3527528_PART_255.E3507523  INNER JOIN (SELECT * FROM T3507545 AS OF SCN 12877647623) T3507545 ON T3507526.E_INTERNAL_ID = T3507545.E3507523 '
                                      ,pin_WhereClause => ' ( T3527528_PART_255.F462 = 255 ) '
                                      ,pin_EarningEntity => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('T3527528_PART_255.E3507523','T3507526.FULL_NAME'))
                                      ,pin_ColumnMapping => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F3525672','ML_METRIC_CALC_ENTITY_NAME_1'))
                                      ,pin_EntityMapping => NULL
                                      ,pin_operationType => 22
                                      ,pin_priorPeriodTable => NULL
                                      ,pin_priorPeriodColumn => NULL
                                      ,pin_projectedFlag => 0
                                      ,pin_baseLineTable => NULL
                                      ,pin_priorPeriod => NULL
                                      ,pin_calculationType => 1
                                      ,pin_PriorPeriodFlag => 0
                                      ,pin_LookupTable => 'T3528094'
                                      ,pin_inputLookupColumn => 'ACCELERATOR'
                                      ,pin_LessThanSmallest => 1
                                      ,pin_GreaterThanLargest => 3
                                      ,pin_LookupWhereClause => NULL
                                      ,pin_LookupJoinClause => 'LOOKUP on  NVL( TAB.ML_EARNINGS_ENTITY,1E38)=NVL(LOOKUP.E3507523,1E38) '
                                      ,pin_varyByFields => 'E3507523'
                                      ,pin_varyByRosterFields => NULL
                                      ,pin_LookupEffProp => TABLETYPE_DATE_RANGE_INTERNAL(OBJTYPE_DATE_RANGE_INTERNAL('F3525672','T3507545','START_DATE','END_DATE'))
                                      );
     end;
  */

  as
    v_insert_sql CLOB;
    v_input_cols CLOB := '';
    v_GTT_cols CLOB :='';
    v_input_additional_cols CLOB := '';
    v_GTT_additional_cols CLOB :='';
    v_input_cols_alias CLOB;
    v_extra_join CLOB :='';
    v_function_sql CLOB :='';
    v_input_lookup_column  varchar2(50);
    v_where_clause CLOB :='';
    v_result_null clob := '';
    v_entity_instance clob := '';
    v_entity_instance_change clob :='';
    v_flag_rejected clob :='';
    v_prior_period_value clob:='';
    v_current_period_value clob:='';
    v_final_value clob:='';
    v_join_condition_change clob :='';
    v_join_condition_baseline clob :='';
    v_period_filter_prior clob :='';
    v_period_filter_base clob :='';
    v_projected_filter_base clob :='';
    v_projected_filter_prior clob :='';
    v_earningEntity    clob :='';
    v_earningEntityBk    clob :='';
    v_entity_instance_flag clob :='';
    v_prec_scale_current    clob :='';
    v_prec_scale_prior    clob :='';
    v_prec_scale_final    clob :='';
    v_prec_scale_lookup clob:='';
    v_zero_divide_change       clob :='';
    v_final_value_percent      clob :='';
    v_lookup_field clob := '';
    v_entity_field_join clob :='';
    v_entity_field_bk clob :='';
    v_flag_zero_one number;
    v_no_lookup_curve clob := '';
    v_no_lookup_curve_no_result clob := '';
    v_stamp            VARCHAR2(250);
    V_TOTAL_ROWCOUNT integer;
    V_REJECTED_ROWCOUNT integer;
    V_ACCEPTED_ROWCOUNT integer;
    v_LookupTable clob;
    v_EffectiveProcessingDate clob;
    v_LookupJoinClause clob;
    v_EffLookupJoinClause clob;
    v_varyByFields clob;
    v_EffvaryByFields clob;
    v_additional_clause CLOB;
    v_metric_as_input integer;
  begin
  v_stamp := 'METRICS.Lookup - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;

  BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable),    ',pin_inputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput),    ',pin_JoinedInput => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause),    ',pin_WhereClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EarningEntity),    ',pin_EarningEntity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ColumnMapping),    ',pin_ColumnMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping),    ',pin_EntityMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operationType),    ',pin_operationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodTable),    ',pin_priorPeriodTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodColumn),    ',pin_priorPeriodColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projectedFlag),    ',pin_projectedFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_baseLineTable),    ',pin_baseLineTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_priorPeriod),      ',pin_priorPeriod => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calculationType),    ',pin_calculationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_PriorPeriodFlag),    ',pin_PriorPeriodFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupTable),    ',pin_LookupTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputLookupColumn),    ',pin_inputLookupColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_LessThanSmallest),    ',pin_LessThanSmallest => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_GreaterThanLargest),    ',pin_GreaterThanLargest => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupWhereClause),    ',pin_LookupWhereClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_LookupJoinClause),    ',pin_LookupJoinClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_varyByFields),    ',pin_varyByFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_varyByRosterFields),    ',pin_varyByRosterFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_LookupEffProp),    ',pin_LookupEffProp => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_LookupPrecision),    ',pin_LookupPrecision => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputFields),    ',pin_MetricInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricFilterInputFields),    ',pin_MetricFilterInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputConstants),    ',pin_MetricInputConstants => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputTable),    ',pin_MetricInputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputSequence),    ',pin_MetricInputSequence => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricPeriodField),    ',pin_MetricPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricPeriodValue),    ',pin_MetricPeriodValue => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricProjectedPeriodField),    ',pin_MetricProjectedPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricProjectedPeriodValue),    ',pin_MetricProjectedPeriodValue => <value>', v_stamp);

  END;

    IF pin_inputTable IS NULL THEN
      raise_application_error(-20001, 'Input table can not be null');
    END IF;

    IF pin_EarningEntity IS NULL THEN
      raise_application_error(-20001, 'Earning entity column can not be null');
    END IF;

    IF pin_lookupTable IS NULL THEN
      raise_application_error(-20001, 'Lookup table can not be null');
    END IF;

    IF pin_inputLookupColumn IS NULL THEN
      raise_application_error(-20001, 'Lookup column can not be null');
    END IF;

    if pin_LookupPrecision is null or commons.FIELD_PRECISION_AND_SCALE('METRIC') <= commons.FIELD_SCALE('METRIC',pin_LookupPrecision) then
      v_prec_scale_final := commons.FIELD_PRECISION_AND_SCALE('METRIC');
    else
      v_prec_scale_final := commons.FIELD_SCALE('METRIC',pin_LookupPrecision);
    end if;

    v_prec_scale_current := commons.FIELD_PRECISION_AND_SCALE('CURRENT_PERIOD_AMOUNT');
    v_prec_scale_prior   := commons.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_AMOUNT');
    v_prec_scale_lookup   := commons.FIELD_PRECISION_AND_SCALE('LOOKUP_INPUT');

    v_lookup_field := 'CAST(LOOKUP_COLUMN AS NUMBER'||v_prec_scale_lookup||')';
    v_earningEntity := SUBSTR(pin_EarningEntity(1).NAME1, INSTR(pin_EarningEntity(1).NAME1,'.')+1);
    v_earningEntityBk := pin_EarningEntity(1).NAME2;
    --this variable is for empty values validation (we should not populate the GTT with empty values in result field
    v_result_null := ' WHEN RESULT_VALUE IS NULL THEN ';
    --if we need to calculate change in value then we need to first validate that for each record in the input exists a record in the prior period table or the baseline table
    IF pin_calculationType=2 OR pin_calculationType=3 THEN
      if pin_PriorPeriodFlag IN (1,2) then
          v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON ' || commons_utils.get_equal_match_condition(pin_EarningEntity(1).NAME1,
                                                                                                                            pin_priorPeriodTable || '.' || v_earningEntity,
                                                                                                                            1,
                                                                                                                            6);
      elsif pin_PriorPeriodFlag = 3 then
          v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON ' || commons_utils.get_equal_match_condition(pin_EarningEntity(1).NAME1,
                                                                                                                           pin_baseLineTable || '.' || v_earningEntity,
                                                                                                                           1,
                                                                                                                           6);
      end if;
    END IF;

    if pin_projectedFlag = 1 and (pin_calculationType=2 OR pin_calculationType=3) then
      if pin_PriorPeriodFlag IN (1,2) then
       v_projected_filter_prior := ' AND '||pin_priorPeriodTable||'.PROJECTED=0 ';
      END IF;
    end if;

    IF pin_ColumnMapping IS NOT NULL THEN
      BEGIN
        FOR i IN 1..pin_ColumnMapping.COUNT LOOP
            v_input_additional_cols := v_input_additional_cols || pin_inputTable || '.' || pin_ColumnMapping(i).NAME1 || ' ' || pin_ColumnMapping(i).NAME2 || ',';
            v_gtt_additional_cols := v_gtt_additional_cols || pin_ColumnMapping(i).NAME2 ||',';
            v_input_cols_alias := v_input_cols_alias || pin_ColumnMapping(i).NAME2 || ',';
            --in case we have change in value
           IF pin_calculationType=2 OR pin_calculationType=3 THEN
            if pin_PriorPeriodFlag IN (1,2) then
             v_join_condition_change := v_join_condition_change ||  '
                     AND ('||pin_inputTable||'.'||pin_ColumnMapping(i).NAME1 ||'='||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (' || pin_inputTable||'.'|| pin_ColumnMapping(i).NAME1||' IS NULL AND '||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' IS NULL ))'
                     ;
            elsif pin_PriorPeriodFlag = 3 then
             v_join_condition_baseline :=  v_join_condition_baseline ||  '
                     AND ('||pin_inputTable||'.'||pin_ColumnMapping(i).NAME1 ||'='||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (' || pin_inputTable||'.'|| pin_ColumnMapping(i).NAME1||' IS NULL AND '||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)|| ' IS NULL ))'
                          ;
            end if;
         end if;
        END LOOP;
      END;
    END IF;

      IF pin_EntityMapping IS NOT NULL THEN
        BEGIN
          FOR i IN 1..pin_EntityMapping.COUNT LOOP
             IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping(i).NAME1);
            ELSE
              v_entity_field_join:= pin_EntityMapping(i).NAME2;
              v_entity_field_bk :=pin_inputTable ||'.'||pin_EntityMapping(i).NAME2;
            END IF;

              v_input_cols := v_input_cols || v_entity_field_bk || ' ' || pin_EntityMapping(i).NAME3 ||
                                       ',' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ' ||  pin_EntityMapping(i).NAME4 ||',';
              v_gtt_cols := v_gtt_cols || pin_EntityMapping(i).NAME3 ||','|| pin_EntityMapping(i).NAME4||',';
              v_input_cols_alias := v_input_cols_alias || pin_EntityMapping(i).NAME3 ||','|| pin_EntityMapping(i).NAME4||',';

               --in case we have change in value  (need to join the prior period table with the entity (the
               IF pin_calculationType=2 OR pin_calculationType=3 THEN
                if pin_PriorPeriodFlag IN (1,2) then
                 v_join_condition_change := v_join_condition_change ||  '
                         AND ('|| pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ='||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID IS NULL AND '||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
                elsif pin_PriorPeriodFlag = 3 then
                 v_join_condition_baseline :=  v_join_condition_baseline ||  '
                         AND ('|| pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ='||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID IS NULL AND '||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
                end if;
               end if;

          END LOOP;

        END;
      END IF;

      -- prefix the lookup column
      v_input_lookup_column := pin_inputTable || '.' || pin_inputLookupColumn;
      -- create WHERE clause
      IF pin_WhereClause IS NOT NULL THEN
         v_where_clause := ' WHERE ' || pin_WhereClause;
      END IF;

      if pin_calculationType=2 OR pin_calculationType=3 then
       if pin_PriorPeriodFlag IN (1,2) then
        v_period_filter_prior := ' AND '||pin_priorPeriodTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_prior;
       elsif pin_PriorPeriodFlag = 3 then
        v_period_filter_base  := ' AND '||pin_baseLineTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_base;
       end if;
      end if;

    v_gtt_cols := v_gtt_additional_cols || v_gtt_cols || 'ML_EARNINGS_ENTITY,ML_EARNINGS_ENTITY_BK,ML_ID,ML_LOOKUP_INPUT
                 ,ML_PRIOR_PERIOD_AMOUNT, ML_FINAL_VALUE, ML_FLAG,ML_CURRENT_PERIOD_AMOUNT';
    v_input_cols_alias := v_input_cols_alias || ' ML_EARNINGS_ENTITY,ML_EARNINGS_ENTITY_BK,ML_ID,LOOKUP_COLUMN ';

    v_final_value_percent := ' ML_FINAL_VALUE ';
    -- the flag is set to 1 for NOT NULL validation in result field, set to 2 in case of normal entity validation (done in all cases) and set to 3 in case of
    -- change in value validation (existence in prior period/baseline table-done only when the calculation type is 2 or 3)

    if pin_calculationType <> 1 then --change in value or percent change
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || ' WHEN ML_PRIOR_PERIOD_AMOUNT IS NULL THEN 3 END ' ;
      v_current_period_value := ' RESULT_VALUE ';
      --v_prior_period_value is the current value in the prior period table
     if pin_PriorPeriodFlag IN (1,2) then
      v_prior_period_value := ','||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT ';
     elsif pin_PriorPeriodFlag = 3 then
      v_prior_period_value := ','||pin_baseLineTable||'.BASELINE_VALUE ';
     end if ;
      v_final_value := ' RESULT_VALUE  - ML_PRIOR_PERIOD_AMOUNT ';

      if pin_calculationType = 3 then --percent change in value
        v_zero_divide_change :=  ' WHEN ML_PRIOR_PERIOD_AMOUNT = 0 THEN
                 INTO TEMP_METRIC_LOOKUP_REJECTED  ( '||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                 VALUES ('|| v_input_cols_alias || ',NULL, NULL,4 ,RESULT_VALUE,1190,1,NULL )';
        v_final_value := ' ( RESULT_VALUE - ML_PRIOR_PERIOD_AMOUNT )
                      /ABS(ML_PRIOR_PERIOD_AMOUNT)';
      end if;

      v_entity_instance_change := --the when part for missing entity validation (the one where entities from input need to exist in prior period/baseline table)
       ' WHEN ML_PRIOR_PERIOD_AMOUNT IS NULL THEN
                 INTO TEMP_METRIC_LOOKUP_REJECTED  ( '||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                  VALUES ('|| v_input_cols_alias || ',NULL, NULL, 3,RESULT_VALUE, 1180, 1, NULL )';

    else --normal case (value)
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || ' END ' ;
      v_prior_period_value :=',NULL ';
      v_final_value := ' RESULT_VALUE ';
      v_current_period_value := 'NULL ';
    end if;

      v_no_lookup_curve  := --OF-28084 There is no lookup curve for the metric calculation for one or more metric calculation entities
       ' WHEN VLD_NO_LKCURVES = 0 THEN
                 INTO TEMP_METRIC_LOOKUP_REJECTED  ( '||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                  VALUES ('|| v_input_cols_alias || ',NULL, NULL, 3,RESULT_VALUE, 1150, 1, NULL )';

      v_no_lookup_curve_no_result  := --OF-28084 The result returned from the lookup curve for the metric calculation was an error for one or more instances of the metric calculation entity
       ' WHEN VLD_NO_LKCURVES = 1 AND RESULT_VALUE IS NULL THEN
                 INTO TEMP_METRIC_LOOKUP_REJECTED  ( '||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                  VALUES ('|| v_input_cols_alias || ',NULL, NULL, 3,RESULT_VALUE, 1160, 1, NULL )';

    IF pin_EntityMapping IS NOT NULL THEN
        BEGIN
          FOR i IN 1..pin_EntityMapping.COUNT LOOP
            IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
                  v_flag_zero_one :=1;
            ELSE
              v_entity_instance := v_entity_instance ||' WHEN '|| pin_EntityMapping(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping(i).NAME3 || ' IS NOT NULL THEN
                         INTO TEMP_METRIC_LOOKUP_REJECTED  ( '||
                         v_gtt_cols
                         ||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                    VALUES ('|| v_input_cols_alias || ',NULL, NULL , 2,RESULT_VALUE , 1020, 1,'''||pin_EntityMapping(i).NAME1||','||pin_EntityMapping(i).NAME2||''')';
              v_entity_instance_flag := v_entity_instance_flag || ' WHEN ' || pin_EntityMapping(i).NAME4 || ' IS NULL THEN 2 ' ;

            END IF;
          END LOOP;
         END;
     END IF;

    IF pin_LookupEffProp IS NOT NULL THEN
        FOR i IN 1..pin_LookupEffProp.COUNT LOOP
            v_EffectiveProcessingDate := v_EffectiveProcessingDate || ',' || pin_LookupEffProp(i).RELATIONSHIP_TABLE_ALIAS || '.' || pin_LookupEffProp(i).ENTITY_COLUMN_NAME;
            v_EffLookupJoinClause := v_EffLookupJoinClause || ' and TAB.' || pin_LookupEffProp(i).ENTITY_COLUMN_NAME || '  between nvl(LOOKUP.' ||
                                  pin_LookupEffProp(i).ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) and nvl(LOOKUP.' ||
                                  pin_LookupEffProp(i).ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))';
            v_EffvaryByFields := v_EffvaryByFields || ',' || pin_LookupEffProp(i).ENTITY_DATE_RANGE_PART_1 || ',' || pin_LookupEffProp(i).ENTITY_DATE_RANGE_PART_2;
        END LOOP;
        if pin_LookupJoinClause is not null then
          v_LookupJoinClause := pin_LookupJoinClause || v_EffLookupJoinClause;
        else
          v_LookupJoinClause := 'LOOKUP on ' || ltrim(v_EffLookupJoinClause,' and');
        end if;
        if pin_varyByFields is not null then
          v_varyByFields := pin_varyByFields || v_EffvaryByFields;
        else
          v_varyByFields := ltrim(v_EffvaryByFields,',');
        end if;
    ELSE
        v_LookupJoinClause := pin_LookupJoinClause;
        v_varyByFields := pin_varyByFields;
    END IF;

    v_input_cols := v_input_additional_cols ||  v_input_cols || pin_EarningEntity(1).NAME1
     || ' ML_EARNINGS_ENTITY,'|| pin_EarningEntity(1).NAME2 || ' ML_EARNINGS_ENTITY_BK,'|| pin_inputTable || '.ROW_IDENTIFIER ML_ID '
                 ||v_prior_period_value||' ML_PRIOR_PERIOD_AMOUNT ' || case when pin_varyByRosterFields is not null then ',' || pin_varyByRosterFields end || v_EffectiveProcessingDate || '  ' ;

    if pin_LookupWhereClause is not null then
      v_lookupTable := ' (SELECT * FROM ' || pin_lookupTable || ' WHERE ' || pin_LookupWhereClause || ') ';
    else
      v_LookupTable := pin_lookupTable;
    end if;

--call de lookup function
  IF (pin_operationType = 22) THEN
    v_function_sql := compensation_processing.STEP_LOOKUP
               (
                   v_input_cols
                 , v_input_cols_alias || ', ML_PRIOR_PERIOD_AMOUNT '
                 , pin_JoinedInput || v_extra_join || v_join_condition_change || v_period_filter_prior|| v_join_condition_baseline || v_period_filter_base|| v_where_clause
                 , v_input_lookup_column
                 , v_LookupTable
                 , pin_LessThanSmallest
                 , pin_GreaterThanLargest
                 , null
                 , null
                 , v_LookupJoinClause
                 , v_varyByFields
                   ) ;
    ELSIF (pin_operationType = 23) THEN
        v_function_sql := compensation_processing.CONTINUOUS_LOOKUP
               (
                   v_input_cols
                 , v_input_cols_alias ||', ML_PRIOR_PERIOD_AMOUNT '
                 , pin_JoinedInput || v_extra_join || v_join_condition_change ||v_period_filter_prior|| v_join_condition_baseline || v_period_filter_base|| v_where_clause
                 , v_input_lookup_column
                 , v_LookupTable
                 , pin_LessThanSmallest
                 , pin_GreaterThanLargest
                 , null
                 , null
                 , v_LookupJoinClause
                 , v_varyByFields
                   ) ;
    ELSIF (pin_operationType = 24) THEN
        v_function_sql := compensation_processing.DISCRETE_LOOKUP
               (
                   v_input_cols
                 , v_input_cols_alias ||', ML_PRIOR_PERIOD_AMOUNT '
                 , pin_JoinedInput || v_extra_join || v_join_condition_change ||v_period_filter_prior|| v_join_condition_baseline || v_period_filter_base|| v_where_clause
                 , v_input_lookup_column
                 , v_LookupTable
                 , null
                 , null
                 , v_LookupJoinClause
                 , v_varyByFields
                   ) ;
    END IF;

    -- if the lookup column is null then the metric result value is empty and it is logged with error code 1
    -- if the lookup column is not null and the result value is null, then it is the case when "Error" is returned if the lookup
    -- value is less than the smallest or greater than the largest lookup value in lookup table and the error code is 6
       v_insert_sql := ' INSERT ALL ' ||
        /*case when pin_operationType in (22,23) then 'WHEN VLD_TWO_RECORDS = 0 THEN
        INTO TEMP_METRIC_LOOKUP_REJECTED  ('||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) VALUES ('|| v_input_cols_alias ||',NULL, NULL, 1,RESULT_VALUE , 1830, 1, NULL)' end ||*/
       ' WHEN LOOKUP_COLUMN IS NULL THEN
        INTO TEMP_METRIC_LOOKUP_REJECTED  ('||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) VALUES ('|| v_input_cols_alias ||',NULL, NULL, 1,RESULT_VALUE , 1050, 1, NULL)
         WHEN LOOKUP_COLUMN IS NOT NULL AND RESULT_VALUE IS NULL AND VLD_NO_LKCURVES = 1 THEN
        INTO TEMP_METRIC_LOOKUP_REJECTED  ('||v_gtt_cols||', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) VALUES ('|| v_input_cols_alias ||',NULL, NULL, 6,RESULT_VALUE, 1160, 1, NULL )'
         || v_entity_instance_change ||  --the when part for missing entity validation in case of change value only (the one where entities from input need to exist in the prior period/baseline table)
         v_entity_instance || v_zero_divide_change || v_no_lookup_curve || v_no_lookup_curve_no_result || '
       ELSE
         INTO TEMP_METRIC_LOOKUPS  ('||v_gtt_cols||') VALUES ('|| REPLACE(v_input_cols_alias,'LOOKUP_COLUMN',v_lookup_field) ||
              ',CAST(ML_PRIOR_PERIOD_AMOUNT AS NUMBER'||v_prec_scale_prior||')
               ,CAST('||v_final_value||' AS NUMBER'||v_prec_scale_final||'),NULL
               ,CAST('||v_current_period_value||' AS NUMBER'||v_prec_scale_current||') )
          select ' || v_input_cols_alias || ', ML_PRIOR_PERIOD_AMOUNT,'|| v_flag_rejected ||
                 'ML_FLAG,RESULT_VALUE  AS RESULT_VALUE ' || /*case when pin_operationType in (22,23) then ', VLD_TWO_RECORDS' end ||*/ ',VLD_NO_LKCURVES from (' ||
     v_function_sql ||' ) tab ';

    ALTER_SESSION_TIMESTAMP;
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_insert_sql), 'v_insert_sql := <value>;', v_stamp);
    EXECUTE IMMEDIATE v_insert_sql;

      -- set cardinality for temp tables
      V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;
      select count(*) into V_REJECTED_ROWCOUNT from TEMP_METRIC_LOOKUP_REJECTED;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_LOOKUP_REJECTED', V_REJECTED_ROWCOUNT);
      V_ACCEPTED_ROWCOUNT := V_TOTAL_ROWCOUNT - V_REJECTED_ROWCOUNT;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_LOOKUPS', V_ACCEPTED_ROWCOUNT);

   if pin_MetricInputTable is not null then
     v_additional_clause :=  V_EXTRA_JOIN ||  V_WHERE_CLAUSE;

     select count(*) into v_metric_as_input from table(pin_MetricInputConstants) where NAME1 = 'INPUT_CATEGORY' and NAME2 = 'Metric';
     if v_metric_as_input = 1 then

      METRIC_INPUTS_AGG (
          pin_inputTable               =>pin_inputTable
          ,pin_JoinedInput             =>pin_JoinedInput
          ,pin_EarningEntity           =>pin_EarningEntity
          ,pin_ColumnMapping           =>pin_ColumnMapping
          ,pin_EntityMapping           =>pin_EntityMapping
          ,pin_MetricInputFields       =>pin_MetricInputFields
          ,pin_MetricFilterInputFields =>pin_MetricFilterInputFields
          ,pin_MetricInputConstants    =>pin_MetricInputConstants
          ,pin_MetricInputTable        =>pin_MetricInputTable
          ,pin_MetricInputSequence     =>pin_MetricInputSequence
          ,pin_additional_clause       =>v_additional_clause
          ,pin_projectedFlag           =>pin_projectedFlag
          ,pin_MetricPeriodField          =>pin_MetricPeriodField
          ,pin_MetricPeriodValue          =>pin_MetricPeriodValue
          ,pin_MetricProjectedPeriodField =>pin_MetricProjectedPeriodField
          ,pin_MetricProjectedPeriodValue =>pin_MetricProjectedPeriodValue
          ,pin_operationType              =>pin_operationType
      );

     else

      METRIC_INPUTS (
          pin_inputTable               =>pin_inputTable
          ,pin_JoinedInput             =>pin_JoinedInput
          ,pin_EarningEntity           =>pin_EarningEntity
          ,pin_ColumnMapping           =>pin_ColumnMapping
          ,pin_EntityMapping           =>pin_EntityMapping
          ,pin_MetricInputFields       =>pin_MetricInputFields
          ,pin_MetricFilterInputFields =>pin_MetricFilterInputFields
          ,pin_MetricInputConstants    =>pin_MetricInputConstants
          ,pin_MetricInputTable        =>pin_MetricInputTable
          ,pin_MetricInputSequence     =>pin_MetricInputSequence
          ,pin_additional_clause       =>v_additional_clause
          ,pin_projectedFlag           =>pin_projectedFlag
          ,pin_MetricPeriodField          =>pin_MetricPeriodField
          ,pin_MetricPeriodValue          =>pin_MetricPeriodValue
          ,pin_MetricProjectedPeriodField =>pin_MetricProjectedPeriodField
          ,pin_MetricProjectedPeriodValue =>pin_MetricProjectedPeriodValue
      );

     end if;

   end if;

    begin
         compensation_processing.ALTER_SESSION_NLS_BINARY;
    end;
  EXCEPTION
    WHEN CANNOT_INSERT_NULL THEN
       RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
  END Metric_Lookup;
------------------------

   PROCEDURE METRIC_STATISTICS(pin_inputTable         IN VARCHAR2
                              ,pin_JoinedInput        IN VARCHAR2
                              ,pin_WhereClause        IN VARCHAR2
                              ,pin_EarningEntity      IN TABLETYPE_NAME_MAP
                              ,pin_ColumnMapping      IN TABLETYPE_NAME_MAP
                              ,pin_EntityMapping      IN TABLETYPE_NAME_JOIN_MAP
                              ,pin_operationType      IN NUMBER
                              ,pin_priorPeriodTable   IN VARCHAR2
                              ,pin_priorPeriodColumn  IN VARCHAR2
                              ,pin_projectedFlag      IN NUMBER
                              ,pin_baseLineTable      IN VARCHAR2
                              ,pin_priorPeriod        IN NUMBER
                              ,pin_calculationType    IN NUMBER
                              ,pin_PriorPeriodFlag    IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                              ,pin_distinctField      IN VARCHAR2
                              )
-----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process: Execute operation indicated by pin_operationType param and insert result in global temp table
      -- Input Parameters:
      --    pin_inputTable         the actual input table
      --    pin_JoinedInput        the join condition between the input and periods/entity/roster (coming from inputs processing)
      --    pin_WhereClause        the filter from input processing (Separate because we have extra joins)
      --    pin_EarningEntity      earning entity column from the input
      --    pin_ColumnMapping      column mapping for additional fields (an array of elements like (F1,MA_EARNINGS_ENTITY), (F2,MA_METRIC_CALC_ENTITY_NAME_1)
      --                                        ,(T123.e_entity_id, MA_METRIC_CALC_ENTITY_ID_1 )
      --    pin_EntityMapping      entity mapping containing  an 4 dimensional array of elements as 'T123', F3 - F3 is the business key name from the input table
      --    pin_operationType      (14 - count of records; 15 - count of distinct values in records)
      --    pin_distinctField       the field to count for distinct values
-----------------------------------------------------------------------------------------------
      --    Call statement:
      /*    begin
               METRICS_PROCESSING.METRICS_STATISTICS(pin_inputTable         => 'T1759'
                                                    ,pin_JoinedInput        => 'T1759'
                                                    ,pin_WhereClause        => 'F1=1'
                                                    ,pin_EarningEntity      => 'F2'
                                                    ,pin_ColumnMapping      => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F5','MV_METRIC_CALC_ENTITY_NAME_2'))
                                                    ,pin_EntityMapping      => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('entity_table','F3','MV_METRIC_CALC_ENTITY_NAME_1','MV_METRIC_CALC_ENTITY_ID_1'))
                                                    ,pin_operationType      => 14
                                                    ,pin_distinctField      => 'F1');
            end;*/
-----------------------------------------------------------------------------------------------
IS
   V_DML_STATEMENT                  CLOB;
   V_OPERATION                      CLOB;
   V_EXTRA_JOIN                     CLOB;
   V_INPUT_COLS                     CLOB;
   V_INPUT_COLS_ALIAS               CLOB;
   V_GTT_COLS                       CLOB;
   V_ADDITIONAL_INPUT_COLS          CLOB;
   V_ADDITIONAL_INPUT_COLS_ALIAS    CLOB;
   V_ADDITIONAL_GTT_COLS            CLOB;
   V_WHERE_CLAUSE                   CLOB;
   V_CURRENT_PERIOD_VALUE           CLOB;
   v_result_null clob := '';
   v_entity_instance clob := '';
   v_entity_instance_change clob :='';
   v_flag_rejected clob :='';
   v_prior_period_value clob:='';
   v_final_value clob:='';
   v_join_condition_change clob :='';
   v_join_condition_baseline clob :='';
   v_period_filter_prior clob :='';
   v_period_filter_base clob :='';
   v_projected_filter_prior clob :='';
   v_projected_filter_base clob :='';
   v_earningEntity clob:='';
   v_earningEntityBk clob:='';
   v_entity_instance_flag clob :='';
   v_prec_scale_current   clob :='';
   v_prec_scale_prior   clob :='';
   v_prec_scale_final   clob :='';
   v_zero_divide_change       clob :='';
   v_final_value_percent      clob :='';
   V_MS_CURRENT_PERIOD_VALUE clob :='';
   v_entity_field_join   clob :='';
   v_entity_field_bk clob :='';
   v_flag_zero_one number;
   v_stamp            VARCHAR2(250);
    V_TOTAL_ROWCOUNT integer;
    V_REJECTED_ROWCOUNT integer;
    V_ACCEPTED_ROWCOUNT integer;
    v_additional_clause CLOB;
  begin

  v_stamp := 'METRICS.Statistics - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable),    ',pin_inputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput),    ',pin_JoinedInput => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause),    ',pin_WhereClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EarningEntity),    ',pin_EarningEntity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ColumnMapping),    ',pin_ColumnMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping),    ',pin_EntityMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operationType),    ',pin_operationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodTable),    ',pin_priorPeriodTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodColumn),    ',pin_priorPeriodColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projectedFlag),    ',pin_projectedFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_baseLineTable),    ',pin_baseLineTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_priorPeriod),      ',pin_priorPeriod => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calculationType),    ',pin_calculationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_PriorPeriodFlag),    ',pin_PriorPeriodFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_distinctField),    ',pin_distinctField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputFields),    ',pin_MetricInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricFilterInputFields),    ',pin_MetricFilterInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputConstants),    ',pin_MetricInputConstants => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputTable),    ',pin_MetricInputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputSequence),    ',pin_MetricInputSequence => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricPeriodField),    ',pin_MetricPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricPeriodValue),    ',pin_MetricPeriodValue => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricProjectedPeriodField),    ',pin_MetricProjectedPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricProjectedPeriodValue),    ',pin_MetricProjectedPeriodValue => <value>', v_stamp);

  END;

  begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;
   -- VALIDATION PART
   IF PIN_INPUTTABLE IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputTable parameter can not be null');
   ELSIF PIN_OPERATIONTYPE IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_operationType parameter can not be null');
   END IF;
   --

   v_prec_scale_final := commons.FIELD_PRECISION_AND_SCALE('METRIC');
   v_prec_scale_current := commons.FIELD_PRECISION_AND_SCALE('CURRENT_PERIOD_AMOUNT');
   v_prec_scale_prior   := commons.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_AMOUNT');

   v_earningEntity :=  pin_EarningEntity(1).NAME1;
   v_earningEntityBk := pin_EarningEntity(1).NAME2;

   IF pin_operationType = 14 THEN
      -- If VALUE operation of values metric type
      V_OPERATION := ' COUNT(*) ';
      V_CURRENT_PERIOD_VALUE := ' MS_CURRENT_PERIOD_AMOUNT AS MS_CURRENT_PERIOD_AMOUNT ';
   ELSIF pin_operationType = 15 THEN
       V_OPERATION := ' COUNT(DISTINCT ' || pin_inputTable || '.' || pin_distinctField || ') ';
       V_CURRENT_PERIOD_VALUE := ' NULLIF(MS_CURRENT_PERIOD_AMOUNT,0) AS MS_CURRENT_PERIOD_AMOUNT ';
   END IF;
   --
   V_GTT_COLS           := 'MS_EARNINGS_ENTITY,MS_EARNINGS_ENTITY_BK';
   V_INPUT_COLS         := v_earningEntity||','||v_earningEntityBk;
   V_INPUT_COLS_ALIAS   := v_earningEntity||' MS_EARNINGS_ENTITY,'
                        ||v_earningEntityBk || ' MS_EARNINGS_ENTITY_BK';

    --this variable is for empty values validation (we should not populate the GTT with empty values in result field
    v_result_null := ' WHEN MS_CURRENT_PERIOD_AMOUNT IS NULL THEN ';
    --if we need to calculate change in value then we need to first validate that for each record in the input exists a record in the prior period table or the baseline table
    IF pin_calculationType=2 OR pin_calculationType=3 THEN
      if pin_PriorPeriodFlag IN (1,2) then
          --v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON TAB.MS_EARNINGS_ENTITY='||pin_priorPeriodTable||'.'||SUBSTR(v_earningEntity, INSTR(v_earningEntity,'.')+1);
          v_join_condition_change := ' LEFT JOIN '||pin_priorPeriodTable||' ON ' || commons_utils.get_equal_match_condition('TAB.MS_EARNINGS_ENTITY',
                                                                                                                            pin_priorPeriodTable || '.' || SUBSTR(v_earningEntity, INSTR(v_earningEntity,'.')+1),
                                                                                                                            1,
                                                                                                                            6);
      elsif pin_PriorPeriodFlag = 3 then
          --v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON TAB.MS_EARNINGS_ENTITY='||pin_baseLineTable||'.'||SUBSTR(v_earningEntity, INSTR(v_earningEntity,'.')+1);
          v_join_condition_baseline := ' LEFT JOIN '||pin_baseLineTable||' ON ' || commons_utils.get_equal_match_condition('TAB.MS_EARNINGS_ENTITY',
                                                                                                                            pin_baseLineTable || '.' || SUBSTR(v_earningEntity, INSTR(v_earningEntity,'.')+1),
                                                                                                                            1,
                                                                                                                            6);
      end if;
    END IF;

    if pin_projectedFlag = 1 and (pin_calculationType=2 OR pin_calculationType=3) then
      if pin_PriorPeriodFlag IN (1,2) then
       v_projected_filter_prior := ' AND '||pin_priorPeriodTable||'.PROJECTED=0 ';
      end if;
--       v_projected_filter_base :=  ' AND '||pin_baseLineTable||'.PROJECTED=0';
    end if;

   -- Create joins and map columns
   IF pin_EntityMapping IS NOT NULL THEN
      FOR I IN 1..pin_EntityMapping.COUNT LOOP

         IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping(i).NAME1);
         ELSE
              v_entity_field_join:= pin_EntityMapping(i).NAME2;
              v_entity_field_bk :=pin_inputTable ||'.'||pin_EntityMapping(i).NAME2;

         END IF;

         V_INPUT_COLS         := V_INPUT_COLS || ',' || v_entity_field_bk ||
                                 ',' || pin_EntityMapping(I).NAME1 || '.E_INTERNAL_ID ';
         V_INPUT_COLS_ALIAS   := V_INPUT_COLS_ALIAS || ',' || v_entity_field_bk || ' ' || pin_EntityMapping(I).NAME3 ||
                                 ',' || pin_EntityMapping(I).NAME1 || '.E_INTERNAL_ID ' || pin_EntityMapping(I).NAME4;
         V_GTT_COLS           := V_GTT_COLS || ',' || pin_EntityMapping(I).NAME3 ||','|| pin_EntityMapping(I).NAME4;

           --in case we have change in value
         IF pin_calculationType=2 OR pin_calculationType=3 THEN
           if pin_PriorPeriodFlag IN (1,2) then
                 v_join_condition_change := v_join_condition_change ||  '
                         AND (TAB.'||pin_EntityMapping(i).NAME4 ||
                         '='||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (TAB.' || pin_EntityMapping(i).NAME4||' IS NULL AND '||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
           elsif pin_PriorPeriodFlag = 3 then
                 v_join_condition_baseline :=  v_join_condition_baseline ||  '
                         AND (TAB.'||pin_EntityMapping(i).NAME4 ||
                         '='||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (TAB.' || pin_EntityMapping(i).NAME4||' IS NULL AND '||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
           end if;
         end if;


--         v_entity_instance := v_entity_instance || pin_EntityMapping(i).NAME4 || ' IS NULL OR ' ;

      END LOOP;

   END IF;
   -- Create additional fields
   IF pin_ColumnMapping IS NOT NULL THEN
      FOR I IN 1..pin_ColumnMapping.COUNT LOOP
         V_ADDITIONAL_INPUT_COLS       := V_ADDITIONAL_INPUT_COLS || ',' || pin_inputTable || '.' || pin_ColumnMapping(I).NAME1;
         V_ADDITIONAL_INPUT_COLS_ALIAS := V_ADDITIONAL_INPUT_COLS_ALIAS || ',' || pin_inputTable || '.' || pin_ColumnMapping(I).NAME1 || ' ' || pin_ColumnMapping(I).NAME2;
         V_ADDITIONAL_GTT_COLS         := V_ADDITIONAL_GTT_COLS   || ',' || pin_ColumnMapping(I).NAME2;
         --in case we have change in value
       IF pin_calculationType=2 OR pin_calculationType=3 THEN
         if pin_PriorPeriodFlag IN (1,2) then
                 v_join_condition_change := v_join_condition_change ||  '
                         AND (TAB.'||pin_ColumnMapping(i).NAME2 ||
                         '='||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (TAB.' || pin_ColumnMapping(i).NAME2||' IS NULL AND '||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' IS NULL ))'
                         ;
         elsif pin_PriorPeriodFlag =3 then
                 v_join_condition_baseline :=  v_join_condition_baseline ||  '
                         AND (TAB.'||pin_ColumnMapping(i).NAME2 ||
                         '='||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (TAB.' || pin_ColumnMapping(i).NAME2||' IS NULL AND '||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)|| ' IS NULL ))'
                         ;
         end if;
        end if;


--  not needed since MCE fields can now take empty values
--         v_entity_instance := v_entity_instance || pin_ColumnMapping(i).NAME2 || ' IS NULL OR ';
      END LOOP;

   END IF;
   -- Create final fields
   V_INPUT_COLS         := V_INPUT_COLS || V_ADDITIONAL_INPUT_COLS;
   V_INPUT_COLS_ALIAS   := V_INPUT_COLS_ALIAS || V_ADDITIONAL_INPUT_COLS_ALIAS;
   V_GTT_COLS           := V_GTT_COLS || V_ADDITIONAL_GTT_COLS;

   -- Create WHERE clause
   IF PIN_WHERECLAUSE IS NOT NULL THEN
      V_WHERE_CLAUSE := ' WHERE ' || PIN_WHERECLAUSE;
   END IF;

   if pin_calculationType=2 OR pin_calculationType=3 then
     if pin_PriorPeriodFlag IN (1,2) then
        v_period_filter_prior := ' AND '||pin_priorPeriodTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_prior;
     elsif pin_PriorPeriodFlag =3 then
        v_period_filter_base  := ' AND '||pin_baseLineTable||'.'||pin_priorPeriodColumn||'='||pin_priorPeriod||v_projected_filter_base;
     end if;
   end if;

    v_final_value_percent := ' MS_FINAL_VALUE ';

       -- Create joins and map columns
   IF pin_EntityMapping IS NOT NULL THEN
      FOR I IN 1..pin_EntityMapping.COUNT LOOP

         IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_flag_zero_one := 0;
         ELSE

               --validation 1020
               v_entity_instance := v_entity_instance || ' WHEN '|| pin_EntityMapping(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping(i).NAME3 || ' IS NOT NULL THEN
                    INTO TEMP_METRIC_STATS_REJECTED  ( MS_ID,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, MS_FINAL_VALUE, MS_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
              VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, NULL, 2, 1020, 1,'''||pin_EntityMapping(i).NAME1||','||pin_EntityMapping(i).NAME2||''')';
              v_entity_instance_flag := v_entity_instance_flag || ' WHEN ' || pin_EntityMapping(i).NAME4 || ' IS NULL THEN 2 ' ;
         END IF;
      END LOOP;
   END IF;
    -- the flag is set to 1 for NOT NULL validation in result field, set to 2 in case of normal entity validation (done in all cases) and set to 3 in case of
    -- change in value validation (existence in prior period/baseline table-done only when the calculation type is 2 or 3)
    if pin_calculationType <> 1 then --change in value or percent change
      v_entity_instance_change := --the when part for missing entity validation (the one where entities from input need to exist in prior period/baseline table)
       ' WHEN MS_PRIOR_PERIOD_AMOUNT IS NULL THEN
                 INTO TEMP_METRIC_STATS_REJECTED  ( MS_ID,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, MS_FINAL_VALUE, MS_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
              VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, NULL, 3, 1180, 1, NULL)';
     if pin_PriorPeriodFlag IN (1,2) then
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || '
       WHEN '||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT IS NULL THEN 3 END ' ;
     --v_prior_period_value is the current value in the prior period table
      v_prior_period_value := ','||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT AS MS_PRIOR_PERIOD_AMOUNT ';
      v_final_value := ',MS_CURRENT_PERIOD_AMOUNT
                    -'||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT AS MS_FINAL_VALUE ';
     elsif pin_PriorPeriodFlag = 3 then
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || '
       WHEN '||pin_baseLineTable||'.BASELINE_VALUE IS NULL THEN 3 END ' ;
     --v_prior_period_value is the current value in the prior period table
      v_prior_period_value := ','||pin_baseLineTable||'.BASELINE_VALUE AS MS_PRIOR_PERIOD_AMOUNT ';
      v_final_value := ',MS_CURRENT_PERIOD_AMOUNT
                    -'||pin_baseLineTable||'.BASELINE_VALUE AS MS_FINAL_VALUE';
     end if;
            V_MS_CURRENT_PERIOD_VALUE := ' MS_CURRENT_PERIOD_AMOUNT ';

      if pin_calculationType = 3 then --percent change in value
        v_zero_divide_change :=  ' WHEN MS_PRIOR_PERIOD_AMOUNT = 0 THEN
                                  INTO TEMP_METRIC_STATS_REJECTED  ( MS_ID,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, MS_FINAL_VALUE, MS_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
              VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, NULL, 4, 1190, 1, NULL)';
        if pin_PriorPeriodFlag IN (1,2) then
         v_final_value := ',(MS_CURRENT_PERIOD_AMOUNT
                    -'||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT )
                    /ABS('||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT)
                     AS MS_FINAL_VALUE';
        elsif pin_PriorPeriodFlag = 3 then
                 v_final_value := ',(MS_CURRENT_PERIOD_AMOUNT
                    -'||pin_baseLineTable||'.BASELINE_VALUE )
                    /ABS('||pin_baseLineTable||'.BASELINE_VALUE)
                     AS MS_FINAL_VALUE';
        end if;
      end if;

    else --normal case (value)
      v_flag_rejected := ' CASE ' ||v_result_null || ' 1 ' || v_entity_instance_flag || ' END ' ;
      v_prior_period_value :=',NULL AS MS_PRIOR_PERIOD_AMOUNT ';
      v_final_value := ',MS_CURRENT_PERIOD_AMOUNT AS MS_FINAL_VALUE ';
--      V_CURRENT_PERIOD_VALUE :=' NULL AS MS_CURRENT_PERIOD_AMOUNT';
      V_MS_CURRENT_PERIOD_VALUE := ' NULL ';
    end if;

      -- Create insert statement
     V_DML_STATEMENT := ' INSERT ALL
                 ' || v_result_null || ' --the when part for NULL validation
                 INTO TEMP_METRIC_STATS_REJECTED  ( MS_ID,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, MS_FINAL_VALUE, MS_FLAG, VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS)
                      VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, NULL, 1, 1050, 1, NULL) '
                 || v_entity_instance_change ||  --the when part for missing entity validation in case of change value only (the one where entities from input need to exist in the prior period/baseline table)
                 v_entity_instance || v_zero_divide_change || '
                 ELSE INTO TEMP_METRIC_STATISTICS ( MS_ID,'||v_gtt_cols||',MS_CURRENT_PERIOD_AMOUNT, MS_PRIOR_PERIOD_AMOUNT, MS_FINAL_VALUE, MS_FLAG)
                      VALUES ( TEMP_METRIC_STATISTICS_seq.NEXTVAL,'||v_gtt_cols||',CAST('||V_MS_CURRENT_PERIOD_VALUE||' AS NUMBER'||v_prec_scale_current||')
                      , CAST(MS_PRIOR_PERIOD_AMOUNT AS NUMBER'||v_prec_scale_prior||')
                      , CAST(MS_FINAL_VALUE AS NUMBER'||v_prec_scale_final||') , NULL)
                SELECT ' || v_gtt_cols ||','||V_CURRENT_PERIOD_VALUE || v_prior_period_value || v_final_value || ',' ||
                  v_flag_rejected ||' MS_FLAG
                FROM (  SELECT '|| v_input_cols_alias ||','
            ||V_OPERATION || ' AS MS_CURRENT_PERIOD_AMOUNT
             FROM  ' ||pin_JoinedInput || v_extra_join || v_where_clause ||
           ' GROUP BY ' || v_input_cols || ' ) tab '
            || v_join_condition_change || v_period_filter_prior||v_join_condition_baseline || v_period_filter_base ;

   ALTER_SESSION_TIMESTAMP;
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_DML_STATEMENT), 'V_DML_STATEMENT := <value>;', v_stamp);
   EXECUTE IMMEDIATE V_DML_STATEMENT;

      -- set cardinality for temp tables
      V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;
      select count(*) into V_REJECTED_ROWCOUNT from TEMP_METRIC_STATS_REJECTED;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_STATS_REJECTED', V_REJECTED_ROWCOUNT);
      V_ACCEPTED_ROWCOUNT := V_TOTAL_ROWCOUNT - V_REJECTED_ROWCOUNT;
      COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_STATISTICS', V_ACCEPTED_ROWCOUNT);

   if pin_MetricInputTable is not null then
     v_additional_clause :=  V_EXTRA_JOIN ||  V_WHERE_CLAUSE;
      METRIC_INPUTS_AGG (
          pin_inputTable               =>pin_inputTable
          ,pin_JoinedInput             =>pin_JoinedInput
          ,pin_EarningEntity           =>pin_EarningEntity
          ,pin_ColumnMapping           =>pin_ColumnMapping
          ,pin_EntityMapping           =>pin_EntityMapping
          ,pin_MetricInputFields       =>pin_MetricInputFields
          ,pin_MetricFilterInputFields =>pin_MetricFilterInputFields
          ,pin_MetricInputConstants    =>pin_MetricInputConstants
          ,pin_MetricInputTable        =>pin_MetricInputTable
          ,pin_MetricInputSequence     =>pin_MetricInputSequence
          ,pin_additional_clause       =>v_additional_clause
          ,pin_projectedFlag           =>pin_projectedFlag
          ,pin_MetricPeriodField          =>pin_MetricPeriodField
          ,pin_MetricPeriodValue          =>pin_MetricPeriodValue
          ,pin_MetricProjectedPeriodField =>pin_MetricProjectedPeriodField
          ,pin_MetricProjectedPeriodValue =>pin_MetricProjectedPeriodValue
          ,pin_operationType              =>pin_operationType
      );
   end if;

    begin
         compensation_processing.ALTER_SESSION_NLS_BINARY;
      end;
EXCEPTION
   WHEN CANNOT_INSERT_NULL THEN
      RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
END METRIC_STATISTICS;
------------------------

   PROCEDURE METRIC_RANKS (pin_inputTable         IN VARCHAR2
                          ,pin_joinedInput        IN VARCHAR2
                          ,pin_whereClause        IN VARCHAR2
                          ,pin_earningEntity      IN TABLETYPE_NAME_MAP
                          ,pin_columnMapping      IN TABLETYPE_NAME_MAP
                          ,pin_entityMapping      IN TABLETYPE_NAME_JOIN_MAP
                          ,pin_operationType      IN NUMBER
                          ,pin_priorPeriodTable   IN VARCHAR2
                          ,pin_priorPeriodColumn  IN VARCHAR2
                          ,pin_projectedFlag      IN NUMBER
                          ,pin_baseLineTable      IN VARCHAR2
                          ,pin_priorPeriod        IN NUMBER
                          ,pin_calculationType    IN NUMBER
                          ,pin_PriorPeriodFlag    IN NUMBER
                          ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                          ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                          ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                          ,pin_MetricInputTable       in VARCHAR2 default null
                          ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
						              ,pin_rankField          IN VARCHAR2
                          ,pin_rankOrder          IN NUMBER
                          ,pin_groupByFields      IN VARCHAR2
                          ,pin_tieBreakField      IN VARCHAR2
                          ,pin_tieBreakRankOrder  IN NUMBER
                          ,pin_denseRank          IN NUMBER
                          )
-----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process: Execute operation indicated by pin_operationType param and insert result in global temp table
      -- Input Parameters:
      --    pin_inputTable         the actual input table
      --    pin_JoinedInput        the join condition between the input and periods/entity/roster (coming from inputs processing)
      --    pin_WhereClause        the filter from input processing (Separate because we have extra joins)
      --    pin_EarningEntity      earning entity column from the input
      --    pin_ColumnMapping      column mapping for additional fields (an array of elements like (F1,MA_EARNINGS_ENTITY), (F2,MA_METRIC_CALC_ENTITY_NAME_1)
      --                                        ,(T123.e_entity_id, MA_METRIC_CALC_ENTITY_ID_1 )
      --    pin_EntityMapping      entity mapping containing  an 4 dimensional array of elements as 'T123', F3 - F3 is the business key name from the input table
      --    pin_operationType      (18 - rank)
      --    pin_rankField          the field to compute rank of
      --    pin_rankOrder          the order of the values for which the rank is computed
      --                           values: 1 - descending, 2 - ascending
      --    pin_groupByFields      the groups within the rank is computed
      --    pin_tieBreakField      extra field used for breaking ties (only numeric, date and timestamp)
      --    pin_tieBreakRankOrder  the order of the extra fields
      --                           values: 1 - descending, 2 - ascending
      --    pin_denseRank          the type of ranking
      --                           values: 1 - dense ranking, 0 - normal ranking
-----------------------------------------------------------------------------------------------
      --    Call statement:
      /*    begin
               METRICS_PROCESSING.METRIC_RANKS(pin_inputTable         => 'T1759'
                                              ,pin_JoinedInput        => 'T1759'
                                              ,pin_WhereClause        => 'F1=1'
                                              ,pin_EarningEntity      => 'F2'
                                              ,pin_ColumnMapping      => TABLETYPE_NAME_MAP(OBJTYPE_NAME_MAP('F5','MV_METRIC_CALC_ENTITY_NAME_2'))
                                              ,pin_EntityMapping      => TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP('entity_table','F3','MV_METRIC_CALC_ENTITY_NAME_1','MV_METRIC_CALC_ENTITY_ID_1'))
                                              ,pin_operationType      => 18
                                              ,pin_rankField          => 'F1'
                                              ,pin_rankOrder          => 1
                                              ,pin_groupByFields      => 'F101'
                                              ,pin_tieBreakField      => 'F33'
                                              ,pin_tieBreakRankOrder  => 1
                                              ,pin_denseRank          => 0
                                                );
            end;*/
-----------------------------------------------------------------------------------------------
IS
   V_DML_STATEMENT            CLOB;
   V_OPERATION                CLOB;
   V_EXTRA_JOIN               CLOB;
   V_EXTRA_JOIN_PRIOR_PERIOD  CLOB;
   V_EXTRA_JOIN_BASELINE      CLOB;
   V_INPUT_COLS               CLOB;
   V_INPUT_COLS_ALIAS         CLOB;
   V_VALUES_COLS              CLOB;
   V_GTT_COLS                 CLOB;
   V_ADDITIONAL_INPUT_COLS    CLOB;
   V_ADDITIONAL_INPUT_COLS_ALIAS CLOB;
   V_ADDITIONAL_GTT_COLS      CLOB;
   V_ORDER_BY                 CLOB;
   V_PARTITION_BY             CLOB;
   V_RANKORDER                CLOB;
   V_TIEBREAKFIELD            CLOB;
   V_TIEBREAKRANKORDER        CLOB;
   V_GROUP_BY                 CLOB;
   V_WHERE_CLAUSE             CLOB;
   V_EARNING_ENTITY           CLOB;
   V_PRIOR_PERIOD_VALUE       CLOB;
   V_FINAL_VALUE              CLOB;
   V_FLAG_VALUE_1_CONDITION   CLOB;
   V_FLAG_VALUE_2_CONDITION   CLOB;
   V_FLAG_VALUE_3_CONDITION   CLOB;
   V_FLAG_VALUE_4_CONDITION   CLOB;
   V_FLAG_VALUE_5_CONDITION   CLOB;
   V_FLAG_VALUE_6_CONDITION   CLOB;
   V_ELSE_CONDITION           CLOB;
   V_PRECISION                CLOB;
   v_entity_field_join        CLOB :='';
   v_entity_field_bk          CLOB :='';
   v_stamp            VARCHAR2(250);
   v_flag_one_zero number ;
   V_TOTAL_ROWCOUNT integer;
   V_REJECTED_ROWCOUNT integer;
   V_ACCEPTED_ROWCOUNT integer;
   V_SELECT_FIELDS_MI clob;
   V_INSERT_FIELDS_MI clob;
   v_additional_clause CLOB;

  begin
  v_stamp := 'METRICS.Ranks - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
 begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;
    BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable),    ',pin_inputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput),    ',pin_JoinedInput => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause),    ',pin_WhereClause => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EarningEntity),    ',pin_EarningEntity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ColumnMapping),    ',pin_ColumnMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping),    ',pin_EntityMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operationType),    ',pin_operationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodTable),    ',pin_priorPeriodTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodColumn),    ',pin_priorPeriodColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projectedFlag),    ',pin_projectedFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_baseLineTable),    ',pin_baseLineTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_priorPeriod),      ',pin_priorPeriod => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calculationType),    ',pin_calculationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_PriorPeriodFlag),    ',pin_PriorPeriodFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_rankField),      ',pin_rankField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_rankOrder),      ',pin_rankOrder => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_groupByFields),    ',pin_groupByFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_tieBreakField),    ',pin_tieBreakField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_tieBreakRankOrder),    ',pin_tieBreakRankOrder => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_denseRank),    ',pin_denseRank => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputFields),    ',pin_MetricInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricFilterInputFields),    ',pin_MetricFilterInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputConstants),    ',pin_MetricInputConstants => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputTable),    ',pin_MetricInputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputSequence),    ',pin_MetricInputSequence => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricPeriodField),    ',pin_MetricPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricPeriodValue),    ',pin_MetricPeriodValue => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricProjectedPeriodField),    ',pin_MetricProjectedPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricProjectedPeriodValue),    ',pin_MetricProjectedPeriodValue => <value>', v_stamp);

  END;

   -- VALIDATION PART
   IF pin_inputTable IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputTable parameter can not be null');
   END IF;
   --
   IF pin_joinedInput IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_joinedInput parameter can not be null');
   END IF;
   --
   IF pin_earningEntity IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_earningEntity parameter can not be null');
   END IF;
   --
   IF pin_operationType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_operationType parameter can not be null');
   END IF;
   --
   IF pin_rankField IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_rankField parameter can not be null');
   END IF;
   --
   IF pin_rankOrder IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_rankOrder parameter can not be null');
   END IF;
   --
   IF pin_rankOrder NOT IN (1,2) THEN
      RAISE_APPLICATION_ERROR(-20001,'Invalid pin_rankOrder parameter');
   END IF;
   --
   V_GTT_COLS     := 'MRA_ID,MRA_EARNINGS_ENTITY,MRA_EARNINGS_ENTITY_BK';
   V_INPUT_COLS   := pin_inputTable || '.ROW_IDENTIFIER,' ||pin_EarningEntity(1).NAME1||','||pin_EarningEntity(1).NAME2;
   IF pin_tieBreakField IS NOT NULL THEN
           V_INPUT_COLS_ALIAS   := pin_inputTable || '.ROW_IDENTIFIER AS MRA_ID,' || pin_EarningEntity(1).NAME1 || ' AS MRA_EARNINGS_ENTITY, '
      || pin_EarningEntity(1).NAME2 || ' AS MRA_EARNINGS_ENTITY_BK, ' || pin_inputTable ||'.' ||pin_rankField || ' AS RANK_FIELD , ' || pin_inputTable ||'.' ||pin_tieBreakField || ' AS BREAK_TIES_FIELD ' ;
   ELSE
      V_INPUT_COLS_ALIAS   := pin_inputTable || '.ROW_IDENTIFIER AS MRA_ID,' || pin_EarningEntity(1).NAME1 || ' AS MRA_EARNINGS_ENTITY, '
      || pin_EarningEntity(1).NAME2 || ' AS MRA_EARNINGS_ENTITY_BK, ' || pin_inputTable ||'.' ||pin_rankField || ' AS RANK_FIELD ';
   END IF;
   V_INSERT_FIELDS_MI := substr(pin_EarningEntity(1).NAME1, instr(pin_EarningEntity(1).NAME1, '.') + 1);
   V_SELECT_FIELDS_MI := pin_EarningEntity(1).NAME1;
   -- GET PRECISION FOR CURRENT_PERIOD_AMOUNT AND FINAL_VALUE
   V_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE('METRIC');
   -- ADD
   IF pin_groupByFields IS NOT NULL THEN
      V_GROUP_BY := pin_inputTable || '.' || REPLACE(pin_groupByFields, ',', ',' || pin_inputTable || '.');
      V_PARTITION_BY := 'PARTITION BY ' || V_GROUP_BY;
   END IF;
   --
   IF pin_rankOrder = 1 THEN
      V_RANKORDER := ' DESC';
   ELSIF pin_rankOrder = 2 THEN
      V_RANKORDER := ' ASC';
   END IF;
   V_ORDER_BY := ' ORDER BY ' || pin_inputTable || '.' || pin_rankField || V_RANKORDER;
   --
   IF pin_tieBreakField IS NOT NULL AND pin_tieBreakRankOrder IS NOT NULL THEN
      IF pin_tieBreakRankOrder = 1 THEN
         V_TIEBREAKRANKORDER := ' DESC';
      ELSIF  pin_tieBreakRankOrder = 2 THEN
         V_TIEBREAKRANKORDER := ' ASC';
      END IF;
      V_TIEBREAKFIELD := ',' || pin_inputTable || '.' || pin_tieBreakField ||  V_TIEBREAKRANKORDER;
   END IF;
   --
   IF pin_operationType = 18 THEN
      -- IF VALUE OPERATION OF VALUES METRIC TYPE
      V_OPERATION := case when pin_denseRank = 1 then 'DENSE_' end || 'RANK() OVER (' || V_PARTITION_BY || V_ORDER_BY || V_TIEBREAKFIELD || ')';
   END IF;
   -- JOIN WITH PRIOR PERIOD TABLE AND BASELINE TABLE IN CASE OF CHANGE IN VALUE OR PERCENT CHANGE
   IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
      V_EARNING_ENTITY := SUBSTR(pin_EarningEntity(1).NAME1, INSTR(pin_EarningEntity(1).NAME1,'.')+1);
      if pin_PriorPeriodFlag IN (1,2) then
         V_EXTRA_JOIN_PRIOR_PERIOD := ' LEFT JOIN ' || pin_priorPeriodTable || ' ON ' || commons_utils.get_equal_match_condition(pin_EarningEntity(1).NAME1,
                                                                                                                                 pin_priorPeriodTable || '.' || V_EARNING_ENTITY,
                                                                                                                                 1,
                                                                                                                                 6);
      elsif pin_PriorPeriodFlag = 3 then
         V_EXTRA_JOIN_BASELINE := ' LEFT JOIN ' || pin_baseLineTable || ' ON ' || commons_utils.get_equal_match_condition(pin_EarningEntity(1).NAME1,
                                                                                                                          pin_baseLineTable || '.' || V_EARNING_ENTITY,
                                                                                                                          1,
                                                                                                                          6);
      end if;
   END IF;
   -- CREATE JOINS AND MAP COLUMNS
   IF pin_entityMapping IS NOT NULL THEN
      FOR I IN 1..pin_entityMapping.COUNT LOOP
         IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping(i).NAME1);
         ELSE
              v_entity_field_join:= pin_EntityMapping(i).NAME2;
              v_entity_field_bk :=pin_inputTable ||'.'||pin_EntityMapping(i).NAME2;

         END IF;

         V_INPUT_COLS := V_INPUT_COLS || ',' || v_entity_field_bk ||
                         ',' || pin_entityMapping(I).NAME1 || '.E_INTERNAL_ID';
         V_INPUT_COLS_ALIAS := V_INPUT_COLS_ALIAS || ',' || v_entity_field_bk ||
                         ' AS '|| pin_entityMapping(I).NAME3|| ',' || pin_entityMapping(I).NAME1 || '.E_INTERNAL_ID AS '|| pin_entityMapping(I).NAME4 ;
         V_GTT_COLS := V_GTT_COLS || ',' || pin_entityMapping(I).NAME3 ||','|| pin_entityMapping(I).NAME4;

         V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_entityMapping(I).NAME2;
         if pin_EntityMapping(i).NAME1 = pin_inputTable then
           V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_EntityMapping(i).NAME1 || '.' || pin_entityMapping(I).NAME2;
         else
           V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',null';
         end if;

         --
         IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
           if pin_PriorPeriodFlag IN (1,2) then
            V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ('|| pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ='||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID IS NULL AND '||pin_priorPeriodTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
            /*V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ' || commons_utils.get_equal_match_condition(pin_EntityMapping(i).NAME1 || '.E_INTERNAL_ID',
                                                                                                                         pin_priorPeriodTable || '.' || pin_EntityMapping(i).NAME5,
                                                                                                                         1,
                                                                                                                         6);*/
           elsif  pin_PriorPeriodFlag = 3 then
            V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || '   AND ('|| pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID ='||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5
                         || ' OR (' || pin_EntityMapping(i).NAME1||'.E_INTERNAL_ID IS NULL AND '||pin_baseLineTable||'.'||pin_EntityMapping(i).NAME5 || ' IS NULL ))'
                         ;
            /*V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || '   AND ' || commons_utils.get_equal_match_condition(pin_EntityMapping(i).NAME1 || '.E_INTERNAL_ID',
                                                                                                                   pin_baseLineTable || '.' || pin_EntityMapping(i).NAME5,
                                                                                                                   1,
                                                                                                                   6);*/
           end if;
         END IF;

      END LOOP;
   END IF;
   -- CREATE ADDITIONAL FIELDS
   IF pin_columnMapping IS NOT NULL THEN
      FOR I IN 1..pin_columnMapping.COUNT LOOP
         V_ADDITIONAL_INPUT_COLS := V_ADDITIONAL_INPUT_COLS || ',' || pin_inputTable || '.' || pin_columnMapping(I).NAME1;
         V_ADDITIONAL_INPUT_COLS_ALIAS := V_ADDITIONAL_INPUT_COLS_ALIAS || ',' || pin_inputTable || '.' || pin_columnMapping(I).NAME1 || ' AS ' || pin_columnMapping(I).NAME2;
         V_ADDITIONAL_GTT_COLS   := V_ADDITIONAL_GTT_COLS   || ',' || pin_columnMapping(I).NAME2;

         V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_columnMapping(I).NAME2;
         if pin_columnMapping(i).NAME1 = pin_inputTable then
           V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',' || pin_columnMapping(i).NAME1 || '.' || pin_columnMapping(I).NAME2;
         else
           V_SELECT_FIELDS_MI := V_SELECT_FIELDS_MI || ',null';
         end if;

         --
         IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
           if pin_PriorPeriodFlag IN (1,2) then
              V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD ||
              ' AND ('||pin_inputTable||'.'||pin_ColumnMapping(i).NAME1 ||'='||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                           || ' OR (' || pin_inputTable||'.'|| pin_ColumnMapping(i).NAME1||' IS NULL AND '||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' IS NULL ))'
                       ;
              /*V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ' || commons_utils.get_equal_match_condition(pin_inputTable || '.' || pin_ColumnMapping(i).NAME1,
                                                                                                                           pin_priorPeriodTable || '.' || SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1),
                                                                                                                           1,
                                                                                                                           6);*/
            elsif pin_PriorPeriodFlag =3 then
            V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE ||
            ' AND ('||pin_inputTable||'.'||pin_ColumnMapping(i).NAME1 ||'='||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)
                         || ' OR (' || pin_inputTable||'.'|| pin_ColumnMapping(i).NAME1||' IS NULL AND '||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)|| ' IS NULL ))'
                          ;
            /*V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || ' AND ' || commons_utils.get_equal_match_condition(pin_inputTable || '.' || pin_ColumnMapping(i).NAME1,
                                                                                                                 pin_baseLineTable || '.' || SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1),
                                                                                                                 1,
                                                                                                                 6);*/
            end if;
         END IF;

      END LOOP;
   END IF;

   -- ADD PERIOD AND PROJECTED FILTER IN THE JOIN CONDITION IN CASE OF CHANGE IN VALUE AND PERCENTAGE CHANGE
   IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
     if pin_PriorPeriodFlag IN (1,2) then
      V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ' || pin_priorPeriodTable || '.' || pin_priorPeriodColumn || '=' || pin_priorPeriod;
     elsif  pin_PriorPeriodFlag = 3 then
      V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || ' AND ' || pin_baseLineTable || '.' || pin_priorPeriodColumn || '=' || pin_priorPeriod;
     end if;
      --
      IF pin_projectedFlag = 1 THEN
        if pin_PriorPeriodFlag IN (1,2) then
         V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ' || pin_priorPeriodTable || '.PROJECTED = 0';
         V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE; --|| ' AND ' || pin_baseLineTable || '.PROJECTED = 0';
        end if;
      END IF;
   END IF;
   -- CREATE FINAL FIELDS
   IF pin_calculationType <> 1 THEN
      -- CREATE PRIOR PERIOD VALUE FIELD
      if pin_PriorPeriodFlag IN (1,2) then
         V_PRIOR_PERIOD_VALUE := ''||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT';
      elsif pin_PriorPeriodFlag = 3 then
         V_PRIOR_PERIOD_VALUE := ''||pin_baseLineTable||'.BASELINE_VALUE';
      end if;
      -- CREATE FINAL VALUE FIELD
      IF pin_calculationType = 2 THEN -- IF CHANGE IN VALUE
         V_FINAL_VALUE := '(MRA_CURRENT_PERIOD_AMOUNT-MRA_PRIOR_PERIOD_AMOUNT)';
      ELSIF pin_calculationType = 3 THEN -- IF PERCENTAGE CHANGE
         V_FINAL_VALUE := 'CAST((MRA_CURRENT_PERIOD_AMOUNT-MRA_PRIOR_PERIOD_AMOUNT)/(ABS(MRA_PRIOR_PERIOD_AMOUNT)) AS NUMBER' || V_PRECISION || ')';
      END IF;
   ELSE
      V_PRIOR_PERIOD_VALUE := 'NULL';
      V_FINAL_VALUE        := 'MRA_CURRENT_PERIOD_AMOUNT';
   END IF;
   V_VALUES_COLS  := V_GTT_COLS     || V_ADDITIONAL_GTT_COLS;
   V_INPUT_COLS   := V_INPUT_COLS   || V_ADDITIONAL_INPUT_COLS || ',' || V_OPERATION || ' AS MRA_CURRENT_PERIOD_AMOUNT,' ||
                     V_PRIOR_PERIOD_VALUE || ' AS MRA_PRIOR_PERIOD_AMOUNT';
   V_INPUT_COLS_ALIAS   := V_INPUT_COLS_ALIAS   || V_ADDITIONAL_INPUT_COLS_ALIAS || ',' || V_OPERATION || ' AS MRA_CURRENT_PERIOD_AMOUNT,' ||
                     V_PRIOR_PERIOD_VALUE || ' AS MRA_PRIOR_PERIOD_AMOUNT';
   V_GTT_COLS     := V_GTT_COLS     || V_ADDITIONAL_GTT_COLS   || ',MRA_CURRENT_PERIOD_AMOUNT,MRA_PRIOR_PERIOD_AMOUNT,MRA_FINAL_VALUE,MRA_FLAG';
   -- CREATE WHERE CLAUSE
   IF pin_whereClause IS NOT NULL THEN
      V_WHERE_CLAUSE := ' WHERE ' || pin_whereClause;
   END IF;

    IF pin_entityMapping IS NOT NULL THEN
      FOR I IN 1..pin_entityMapping.COUNT LOOP
         IF REGEXP_LIKE(pin_EntityMapping(i).NAME2 ,'E[0-9]' ) THEN
             v_flag_one_zero :=1;
         ELSE

              --validation 1020
              V_FLAG_VALUE_2_CONDITION := V_FLAG_VALUE_2_CONDITION || ' WHEN ' || pin_EntityMapping(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping(i).NAME3 || ' IS NOT NULL THEN INTO TEMP_METRIC_RANKS_REJECTED
              (' || V_GTT_COLS || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,2, 1020, 1,'''||pin_EntityMapping(i).NAME1||','||pin_EntityMapping(i).NAME2||''')';

         END IF;

      END LOOP;
   END IF;
   -- CREATE INSERT CONDITIONS
   V_FLAG_VALUE_1_CONDITION := ' WHEN MRA_CURRENT_PERIOD_AMOUNT IS NULL THEN INTO TEMP_METRIC_RANKS_REJECTED (' || V_GTT_COLS || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                               'VALUES (' ||V_VALUES_COLS || ',NULL,NULL,NULL,1, 1050, 1, NULL)';
   IF pin_calculationType <> 1 THEN
      V_FLAG_VALUE_3_CONDITION := ' WHEN MRA_PRIOR_PERIOD_AMOUNT IS NULL THEN INTO TEMP_METRIC_RANKS_REJECTED (' || V_GTT_COLS || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                               'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,3, 1180, 1 , NULL)';
   END IF;

   IF pin_calculationType = 3 THEN
      V_FLAG_VALUE_4_CONDITION := ' WHEN MRA_PRIOR_PERIOD_AMOUNT = 0 THEN INTO TEMP_METRIC_RANKS_REJECTED (' || V_GTT_COLS || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,4, 1190, 1, NULL)';
   END IF;
   V_FLAG_VALUE_5_CONDITION := ' WHEN RANK_FIELD IS NULL THEN INTO TEMP_METRIC_RANKS_REJECTED (' || V_GTT_COLS || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,5, 1100, 1, NULL)';
   IF pin_tieBreakField IS NOT NULL  THEN
      V_FLAG_VALUE_6_CONDITION := ' WHEN BREAK_TIES_FIELD  IS NULL THEN INTO TEMP_METRIC_RANKS_REJECTED (' || V_GTT_COLS || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,7, 1110, 1, NULL)';
   END IF;

   V_ELSE_CONDITION := ' ELSE INTO TEMP_METRIC_RANKS (' || V_GTT_COLS || ') ' ||
                       'VALUES (' || V_VALUES_COLS || ',MRA_CURRENT_PERIOD_AMOUNT,MRA_PRIOR_PERIOD_AMOUNT,' || V_FINAL_VALUE || ',NULL)';

   -- CREATE INSERT STATEMENT
   V_DML_STATEMENT := 'INSERT ALL ' || V_FLAG_VALUE_1_CONDITION || V_FLAG_VALUE_2_CONDITION || V_FLAG_VALUE_3_CONDITION || V_FLAG_VALUE_4_CONDITION || V_FLAG_VALUE_5_CONDITION || V_FLAG_VALUE_6_CONDITION || V_ELSE_CONDITION ||
                      ' SELECT ' || V_INPUT_COLS_ALIAS ||
                      ' FROM ' || pin_joinedInput || V_EXTRA_JOIN || V_EXTRA_JOIN_PRIOR_PERIOD || V_EXTRA_JOIN_BASELINE || V_WHERE_CLAUSE;

   ALTER_SESSION_TIMESTAMP;
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_DML_STATEMENT), 'V_DML_STATEMENT := <value>;', v_stamp);
   EXECUTE IMMEDIATE V_DML_STATEMENT;

    -- set cardinality for temp tables
    V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;
    select count(*) into V_REJECTED_ROWCOUNT from TEMP_METRIC_RANKS_REJECTED;
    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_RANKS_REJECTED', V_REJECTED_ROWCOUNT);
    V_ACCEPTED_ROWCOUNT := V_TOTAL_ROWCOUNT - V_REJECTED_ROWCOUNT;
    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_RANKS', V_ACCEPTED_ROWCOUNT);

   if pin_MetricInputTable is not null then
     v_additional_clause :=  V_EXTRA_JOIN ||  V_WHERE_CLAUSE;
      METRIC_INPUTS (
          pin_inputTable               =>pin_inputTable
          ,pin_JoinedInput             =>pin_JoinedInput
          ,pin_EarningEntity           =>pin_EarningEntity
          ,pin_ColumnMapping           =>pin_ColumnMapping
          ,pin_EntityMapping           =>pin_EntityMapping
          ,pin_MetricInputFields       =>pin_MetricInputFields
          ,pin_MetricFilterInputFields =>pin_MetricFilterInputFields
          ,pin_MetricInputConstants    =>pin_MetricInputConstants
          ,pin_MetricInputTable        =>pin_MetricInputTable
          ,pin_MetricInputSequence     =>pin_MetricInputSequence
          ,pin_additional_clause       =>v_additional_clause
          ,pin_projectedFlag           =>pin_projectedFlag
          ,pin_MetricPeriodField          =>pin_MetricPeriodField
          ,pin_MetricPeriodValue          =>pin_MetricPeriodValue
          ,pin_MetricProjectedPeriodField =>pin_MetricProjectedPeriodField
          ,pin_MetricProjectedPeriodValue =>pin_MetricProjectedPeriodValue
      );
   end if;

   begin
       compensation_processing.ALTER_SESSION_NLS_BINARY;
    end;

EXCEPTION
   WHEN CANNOT_INSERT_NULL THEN
      RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
END METRIC_RANKS;
------------------------


   PROCEDURE METRIC_RATIOS (pin_inputTable1            IN VARCHAR2
                           ,pin_inputTable2            IN VARCHAR2
                           ,pin_joinedInput1           IN VARCHAR2
                           ,pin_joinedInput2           IN VARCHAR2
                           ,pin_whereClause1           IN VARCHAR2
                           ,pin_whereClause2           IN VARCHAR2
                           ,pin_earningEntity          IN TABLETYPE_NAME_MAP
                           ,pin_columnMapping          IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_entityMapping1         IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_entityMapping2         IN TABLETYPE_NAME_JOIN_MAP
                           ,pin_operationType          IN NUMBER
                           ,pin_priorPeriodTable       IN VARCHAR2
                           ,pin_priorPeriodColumn      IN VARCHAR2
                           ,pin_projectedFlag          IN NUMBER
                           ,pin_baseLineTable          IN VARCHAR2
                           ,pin_priorPeriod            IN NUMBER
                           ,pin_calculationType        IN NUMBER
                           ,pin_PriorPeriodFlag        IN NUMBER
                           ,pin_BroaderFrequency       IN NUMBER
                           ,pin_BroaderFrequency2      IN NUMBER
                           ,pin_MetricInputFields      in TABLETYPE_NAME_MAP default null
                           ,pin_MetricFilterInputFields in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputConstants   in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInput2Constants  in TABLETYPE_NAME_MAP default null
                           ,pin_MetricInputTable       in VARCHAR2 default null
                           ,pin_MetricInputSequence    in VARCHAR2 default null
                           ,pin_MetricPeriodField          in VARCHAR2 default null
                           ,pin_MetricPeriodValue          in NUMBER default null
                           ,pin_MetricProjectedPeriodField in VARCHAR2 default null
                           ,pin_MetricProjectedPeriodValue in NUMBER default null
                           ,pin_numerator              IN VARCHAR2
                           ,pin_denominator            IN VARCHAR2
                           ,pin_numOperationType       IN NUMBER
                           ,pin_denOperationType       IN NUMBER
                           ,pin_plan_time_unit_id      IN NUMBER
                           ,pin_input1_time_unit_id    IN NUMBER
                           ,pin_input2_time_unit_id    IN NUMBER
                           ,pin_input1_period_field    IN VARCHAR2
                           ,pin_input2_period_field    IN VARCHAR2
                           ,pin_zero_attainment        IN NUMBER
                           )
-----------------------------------------------------------------------------------------------
      -- Assumptions:
      -- Input Parameters are built using valid table names and column names
      -- Process: Execute operation indicated by pin_operationType param and insert result in global temp table
      -- Input Parameters:
      --    pin_inputTable         the actual input table
      --    pin_JoinedInput        the join condition between the input and periods/entity/roster (coming from inputs processing)
      --    pin_WhereClause        the filter from input processing (Separate because we have extra joins)
      --    pin_EarningEntity      earning entity column from the input
      --    pin_ColumnMapping      column mapping for additional fields (an array of elements like (F1,MA_EARNINGS_ENTITY), (F2,MA_METRIC_CALC_ENTITY_NAME_1)
      --                                        ,(T123.e_entity_id, MA_METRIC_CALC_ENTITY_ID_1 )
      --    pin_EntityMapping      entity mapping containing  an 4 dimensional array of elements as 'T123', F3 - F3 is the business key name from the input table
      --    pin_operationType      (10 - GOAL ATTAINMENT; 11 - RATIO)
      --    pin_numerator          the numerator of the ratio
      --    pin_denominator        the denominator of the ratio
      --    pin_numOperationType   the operation over columns in numerator
      --    pin_denOperationType   the operation over columns in denominator
      --    pin_BroaderFrequency   the broad frequency of the first input
      --    pin_BroaderFrequency2  the broad frequency of the second input
-----------------------------------------------------------------------------------------------
      --    Call statement:
      /*    begin
               METRICS_PROCESSING.METRICS_RATIOS (pin_inputTable1        => 'T1759'
                                                 ,pin_inputTable2        => 'T1759'
                                                 ,pin_JoinedInput        => 'T1759'
                                                 ,pin_WhereClause1       => 'F12=10'
                                                 ,pin_WhereClause2       => 'F10=1'
                                                 ,pin_EarningEntity      => 'F2'
                                                 ,pin_ColumnMapping      => TABLETYPE_ID_NAME(OBJTYPE_NAME_MAP('F5','MV_METRIC_CALC_ENTITY_NAME_2'))
                                                 ,pin_EntityMapping      => TABLETYPE_ID_NAME_JOIN(OBJTYPE_NAME_JOIN_MAP('entity_table','F3','MV_METRIC_CALC_ENTITY_NAME_1','MV_METRIC_CALC_ENTITY_ID_1'))
                                                 ,pin_operationType      => 10
                                                 ,pin_numerator          => 'F1'
                                                 ,pin_denominator        => 'F14'
                                                 ,pin_numOperationType   => NULL
                                                 ,pin_denOperationType   => NULL);
            end;
            OR
             begin
               METRICS_PROCESSING.METRICS_RATIOS (pin_inputTable1        => 'T1759'
                                                 ,pin_inputTable2        => 'T1759'
                                                 ,pin_JoinedInput        => 'T1759'
                                                 ,pin_WhereClause1       => 'F12=10'
                                                 ,pin_WhereClause2       => 'F10=1'
                                                 ,pin_EarningEntity      => 'F2'
                                                 ,pin_ColumnMapping      => TABLETYPE_ID_NAME(OBJTYPE_NAME_MAP('F5','MV_METRIC_CALC_ENTITY_NAME_2'))
                                                 ,pin_EntityMapping      => TABLETYPE_ID_NAME_JOIN(OBJTYPE_NAME_JOIN_MAP('entity_table','F3','MV_METRIC_CALC_ENTITY_NAME_1','MV_METRIC_CALC_ENTITY_ID_1'))
                                                 ,pin_operationType      => 11
                                                 ,pin_numerator          => 'F1,F55,F10'
                                                 ,pin_denominator        => 'F14,F100'
                                                 ,pin_numOperationType   => 1
                                                 ,pin_denOperationType   => 3);
            end;*/
-----------------------------------------------------------------------------------------------
IS
   V_DML_STATEMENT            CLOB;
   V_EXTRA_JOIN1              CLOB;
   V_EXTRA_JOIN2              CLOB;
   V_EXTRA_JOIN_PRIOR_PERIOD  CLOB;
   V_EXTRA_JOIN_BASELINE      CLOB;
   V_INPUT_COLS               CLOB;
   V_VALUES_COLS              CLOB;
   V_INPUT_COLS1              CLOB;
   V_INPUT_COLS2              CLOB;
   V_GTT_COLS                 CLOB;
   V_MAIN_JOIN                CLOB;
   V_NUMERATOR                CLOB;
   V_DENOMINATOR              CLOB;
   V_TAB1                     CLOB;
   V_TAB2                     CLOB;
   V_GTT_NAME                 VARCHAR2(100);
   V_GTT_NAME_REJECTED        VARCHAR2(100);
   V_WHERE_CLAUSE1            CLOB;
   V_WHERE_CLAUSE2            CLOB;
   V_COALESCE_COLUMNS         CLOB;
   V_AVG_NUMERATOR            CLOB;
   V_AVG_DENOMINATOR          CLOB;
   V_EARNING_ENTITY           CLOB;
   V_CURRENT_PERIOD_VALUE     CLOB;
   V_PRIOR_PERIOD_VALUE       CLOB;
   V_FINAL_VALUE              CLOB;
   V_FLAG_VALUE_1_CONDITION   CLOB;
   V_FLAG_VALUE_2_CONDITION   CLOB;
   V_FLAG_VALUE_3_CONDITION   CLOB;
   V_FLAG_VALUE_4_CONDITION   CLOB;
   V_FLAG_VALUE_5_CONDITION   CLOB;
   V_ELSE_CONDITION           CLOB;
   V_CURRENT_PERIOD_NAME      CLOB;
   V_PRIOR_PERIOD_NAME        CLOB;
   V_FINAL_PERIOD_NAME        CLOB;
   V_FLAG_NAME                CLOB;
   V_PREC_SCALE_FINAL         CLOB;
   V_PREC_SCALE_CURRENT       CLOB;
   V_PREC_SCALE_PRIOR         CLOB;
   V_NUMERATOR_PRECISION      CLOB;
   V_DENOMINATOR_PRECISION    CLOB;
   v_entity_field_join        CLOB :='';
   v_entity_field_bk          CLOB :='';
   v_error_denominator_goal   number;
   v_flag_zero_one number ;
   v_stamp            VARCHAR2(250);
   V_TOTAL_ROWCOUNT integer;
   V_REJECTED_ROWCOUNT integer;
   V_ACCEPTED_ROWCOUNT integer;
   v_aggregate_inputs1 number;
   v_aggregate_inputs2 number;
   V_INPUT_COLS1_AGG clob;
   V_INPUT_COLS2_AGG clob;
   V_CORR1_JOIN clob;
   V_CORR2_JOIN clob;
   V_START_OUTSIDE_SQL1 clob;
   V_END_OUTSIDE_SQL1 clob;
   V_START_OUTSIDE_SQL2 clob;
   V_END_OUTSIDE_SQL2 clob;
   V_OUTSIDE_INPUT_COLS1 clob;
   V_OUTSIDE_INPUT_COLS2 clob;
   V_GROUPBY_COLS1 clob;
   V_GROUPBY_COLS2 clob;
   v_zero_attainment number(1) := pin_zero_attainment;
   V_ZERO_CONDITION clob;
   v_input1_frequency integer;
   v_input2_frequency integer;
   v_metric_input_fields varchar2(32767);
   v_metric_input1_fields varchar2(32767);
   v_metric_input1_insfields varchar2(32767);
   v_metric_input1_tabfields varchar2(32767);
   v_metric_input1_nullfields varchar2(32767);
   v_metric_input1_tablefields varchar2(32767);
   v_metric_input1_infields varchar2(32767);
   v_metric_input2_fields varchar2(32767);
   v_metric_input2_insfields varchar2(32767);
   v_metric_input2_tabfields varchar2(32767);
   v_metric_input2_nullfields varchar2(32767);
   v_metric_input2_tablefields varchar2(32767);
   v_metric_input2_infields varchar2(32767);
   V_INPUT_COLS1_MI clob;
   V_INPUT_COLS2_MI clob;
   V_GROUPBY_COLS1_MI clob;
   V_GROUPBY_COLS2_MI clob;
   V_OUTSIDE_INPUT_COLS1_MI clob;
   V_OUTSIDE_INPUT_COLS2_MI clob;
   V_START_OUTSIDE_SQL1_MI clob;
   V_START_OUTSIDE_SQL2_MI clob;
   V_END_OUTSIDE_SQL1_MI clob;
   V_END_OUTSIDE_SQL2_MI clob;
   V_TAB1_MI clob;
   V_TAB2_MI clob;
   V_SELECT1_MI clob;
   V_SELECT2_MI clob;
   V_INSERT_FIELDS_MI clob;
   V_SELECT1_FIELDS_MI clob;
   V_SELECT2_FIELDS_MI clob;
   V_INSERT1_MI clob;
   V_INSERT2_MI clob;
   V_SQL1_MI clob;
   V_SQL2_MI clob;
   v_input1_constant_fields varchar2(32767);
   v_input1_constant_values varchar2(32767);
   v_input2_constant_fields varchar2(32767);
   v_input2_constant_values varchar2(32767);
   V_INPUT_CATEGORY CATEGORY_DEFINITIONS.CD_NAME_SINGULAR%TYPE;
   V_INPUT_NAME OBJECT_REGISTRATION.OR_NAME%TYPE;
   V_INPUT_CATEGORY_DEFINITION DEFINITION_TYPES.DEF_TYPE_NAME_SINGULAR%TYPE;
   v_roster_table varchar2(30);
   v_mi_periodfields varchar2(32767);
   v_mi_periodtablefields varchar2(32767);
   v_metric_input number(1) := 0;
   v_check_mi_field integer := 0;
  begin

  v_stamp := 'METRICS.Ratios - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable1),    ',pin_inputTable1 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput1),    ',pin_JoinedInput1 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause1),    ',pin_WhereClause1 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_inputTable2),    ',pin_inputTable2 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_JoinedInput2),    ',pin_JoinedInput2 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_WhereClause2),    ',pin_WhereClause2 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EarningEntity),    ',pin_EarningEntity => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_ColumnMapping),    ',pin_ColumnMapping => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping1),    ',pin_EntityMapping1 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_EntityMapping2),    ',pin_EntityMapping2 => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_operationType),    ',pin_operationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodTable),    ',pin_priorPeriodTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_priorPeriodColumn),    ',pin_priorPeriodColumn => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projectedFlag),    ',pin_projectedFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_baseLineTable),    ',pin_baseLineTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_priorPeriod),      ',pin_priorPeriod => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_calculationType),    ',pin_calculationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_PriorPeriodFlag),    ',pin_PriorPeriodFlag => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_numerator),      ',pin_numerator => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_denominator),    ',pin_denominator => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_numOperationType),    ',pin_numOperationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_denOperationType),    ',pin_denOperationType => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_plan_time_unit_id),    ',pin_plan_time_unit_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_input1_time_unit_id),    ',pin_input1_time_unit_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_input2_time_unit_id),    ',pin_input2_time_unit_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_input1_period_field),      ',pin_input1_period_field => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_input2_period_field),      ',pin_input2_period_field => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_BroaderFrequency),    ',pin_BroaderFrequency => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_BroaderFrequency2),    ',pin_BroaderFrequency2 => <value>', v_stamp);
	  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_zero_attainment),    ',pin_zero_attainment => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputFields),    ',pin_MetricInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricFilterInputFields),    ',pin_MetricFilterInputFields => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInputConstants),    ',pin_MetricInputConstants => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_MetricInput2Constants),    ',pin_MetricInput2Constants => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputTable),    ',pin_MetricInputTable => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricInputSequence),    ',pin_MetricInputSequence => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricPeriodField),    ',pin_MetricPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricPeriodValue),    ',pin_MetricPeriodValue => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_MetricProjectedPeriodField),    ',pin_MetricProjectedPeriodField => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_MetricProjectedPeriodValue),    ',pin_MetricProjectedPeriodValue => <value>', v_stamp);

  END;

  begin
      compensation_processing.ALTER_SESSION_PROJ_NLS_SETTING;
    end;
   -- VALIDATION PART
   IF pin_inputTable1 IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputTable1 parameter can not be null');
   END IF;
   --
   IF pin_inputTable2 IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_inputTable2 parameter can not be null');
   END IF;
   --
   IF pin_joinedInput1 IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_joinedInput1 parameter can not be null');
   END IF;
   --
   IF pin_joinedInput2 IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_joinedInput2 parameter can not be null');
   END IF;
   --
   IF pin_earningEntity IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_earningEntity parameter can not be null');
   END IF;
   --
   IF pin_operationType IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_operationType parameter can not be null');
   END IF;
   --
   IF pin_numerator IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_numerator parameter can not be null');
   END IF;
   --
   IF pin_denominator IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'pin_denominator parameter can not be null');
   END IF;
   --
   V_NUMERATOR    := pin_inputTable1 || '.' || REPLACE(pin_numerator, ',', ',' || pin_inputTable1 || '.');
   V_DENOMINATOR  := pin_inputTable2 || '.' || REPLACE(pin_denominator, ',', ',' || pin_inputTable2 || '.');
   -- GET PRECISION FOR CURRENT_PERIOD_AMOUNT AND FINAL_VALUE
   V_PREC_SCALE_FINAL := commons.FIELD_PRECISION_AND_SCALE('METRIC');
   V_PREC_SCALE_CURRENT := commons.FIELD_PRECISION_AND_SCALE('CURRENT_PERIOD_AMOUNT');
   V_PREC_SCALE_PRIOR   := commons.FIELD_PRECISION_AND_SCALE('PRIOR_PERIOD_AMOUNT');
   --
   IF pin_operationType = 10 THEN
      -- GOAL ATTAINMENT
      V_GTT_NAME  := 'TEMP_METRIC_GOAL_ATTAINMENT';
      V_GTT_NAME_REJECTED := 'TEMP_METRIC_GA_REJECTED';
      V_GTT_COLS  := 'MGA_ID,MGA_EARNINGS_ENTITY,MGA_EARNINGS_ENTITY_BK,MGA_ACTUAL_INPUT,MGA_GOAL_INPUT';
      V_CURRENT_PERIOD_NAME := 'MGA_CURRENT_PERIOD_AMOUNT';
      V_PRIOR_PERIOD_NAME := 'MGA_PRIOR_PERIOD_AMOUNT';
      V_FINAL_PERIOD_NAME := 'MGA_FINAL_VALUE';
      V_FLAG_NAME := 'MGA_FLAG';
      V_NUMERATOR_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE('ACTUAL_INPUT');
      V_DENOMINATOR_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE('GOAL_INPUT');
      v_error_denominator_goal := 1060;
   ELSIF pin_operationType = 11 THEN
      -- RATIO
      IF pin_numOperationType IS NULL THEN
         RAISE_APPLICATION_ERROR(-20001,'pin_numOperationType parameter can not be null');
      END IF;
      IF pin_denOperationType IS NULL THEN
         RAISE_APPLICATION_ERROR(-20001,'pin_denOperationType parameter can not be null');
      END IF;
      -- FOR LEAST AND GREATEST USE NVL(COL,COALESCE).
      -- ADDED NULL FOR THE CASE WHEN COLUMN_NAMES CONTAINS ONLY ONE COLUMN.
      V_COALESCE_COLUMNS := 'COALESCE(' || V_NUMERATOR || ',NULL)';
      --
      -- ADD AND SUBSTRACT V_COALESCE_COLUMNS IN ORDER TO KEEP NULL IF ALL COLUMNS ARE NULL
      CASE pin_numOperationType WHEN 1 THEN V_NUMERATOR := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL(' || REPLACE(V_NUMERATOR, ',', ',0)+NVL(') || ',0)))';
                                WHEN 2 THEN
                                             V_AVG_NUMERATOR   := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL(' || REPLACE(V_NUMERATOR, ',', ',0)+NVL(') || ',0)))';
                                             V_AVG_DENOMINATOR := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL2(' || REPLACE(V_NUMERATOR, ',', ',1,0)+NVL2(') || ',1,0)))';
                                             V_NUMERATOR := V_AVG_NUMERATOR || '/' || V_AVG_DENOMINATOR;
                                WHEN 3 THEN V_NUMERATOR := 'LEAST(NVL(' || REPLACE(V_NUMERATOR, ',', ',' || V_COALESCE_COLUMNS || '),NVL(') || ',' || V_COALESCE_COLUMNS || '))';
                                WHEN 4 THEN V_NUMERATOR := 'GREATEST(NVL(' || REPLACE(V_NUMERATOR, ',', ',' || V_COALESCE_COLUMNS || '),NVL(') || ',' || V_COALESCE_COLUMNS || '))';
      END CASE;
      -- FOR LEAST AND GREATEST USE NVL(COL,COALESCE).
      -- ADDED NULL FOR THE CASE WHEN COLUMN_NAMES CONTAINS ONLY ONE COLUMN.
      V_COALESCE_COLUMNS := 'COALESCE(' || V_DENOMINATOR || ',NULL)';
      --
      -- ADD AND SUBSTRACT V_COALESCE_COLUMNS IN ORDER TO KEEP NULL IF ALL COLUMNS ARE NULL
      CASE pin_denOperationType WHEN 1 THEN V_DENOMINATOR := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL(' || REPLACE(V_DENOMINATOR, ',', ',0)+NVL(') || ',0)))';
                                WHEN 2 THEN
                                             V_AVG_NUMERATOR   := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL(' || REPLACE(V_DENOMINATOR, ',', ',0)+NVL(') || ',0)))';
                                             V_AVG_DENOMINATOR := '(' || V_COALESCE_COLUMNS || '-' || V_COALESCE_COLUMNS || '+(NVL2(' || REPLACE(V_DENOMINATOR, ',', ',1,0)+NVL2(') || ',1,0)))';
                                             V_DENOMINATOR := V_AVG_NUMERATOR || '/' || V_AVG_DENOMINATOR;
                                WHEN 3 THEN V_DENOMINATOR := 'LEAST(NVL(' || REPLACE(V_DENOMINATOR, ',', ',' || V_COALESCE_COLUMNS || '),NVL(') || ',' || V_COALESCE_COLUMNS || '))';
                                WHEN 4 THEN V_DENOMINATOR := 'GREATEST(NVL(' || REPLACE(V_DENOMINATOR, ',', ',' || V_COALESCE_COLUMNS || '),NVL(') || ',' || V_COALESCE_COLUMNS || '))';
      END CASE;
      V_GTT_NAME := 'TEMP_METRIC_RATIO';
      V_GTT_NAME_REJECTED := 'TEMP_METRIC_RATIO_REJECTED';
      V_GTT_COLS := 'MR_ID,MR_EARNINGS_ENTITY,MR_EARNINGS_ENTITY_BK,MR_NUMERATOR,MR_DENOMINATOR';
      V_CURRENT_PERIOD_NAME := 'MR_CURRENT_PERIOD_AMOUNT';
      V_PRIOR_PERIOD_NAME := 'MR_PRIOR_PERIOD_AMOUNT';
      V_FINAL_PERIOD_NAME := 'MR_FINAL_VALUE';
      V_FLAG_NAME := 'MR_FLAG';
      V_NUMERATOR_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE('NUMERATOR');
      V_DENOMINATOR_PRECISION := COMMONS.FIELD_PRECISION_AND_SCALE('DENOMINATOR');
      v_error_denominator_goal := 1070;
   END IF;

   -- JOIN WITH PRIOR PERIOD TABLE AND BASELINE TABLE IN CASE OF CHANGE IN VALUE OR PERCENT CHANGE
   IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
      V_EARNING_ENTITY := SUBSTR(pin_EarningEntity(1).NAME1, INSTR(pin_EarningEntity(1).NAME1,'.')+1);
      if pin_PriorPeriodFlag IN (1,2) then
         V_EXTRA_JOIN_PRIOR_PERIOD := ' LEFT JOIN ' || pin_priorPeriodTable || ' ON ' || commons_utils.get_equal_match_condition('TAB1.EARNINGENTITY',
                                                                                                                                 pin_priorPeriodTable || '.' || V_EARNING_ENTITY,
                                                                                                                                 1,
                                                                                                                                 6);
      elsif pin_PriorPeriodFlag = 3 then
         V_EXTRA_JOIN_BASELINE := ' LEFT JOIN ' || pin_baseLineTable || ' ON ' || commons_utils.get_equal_match_condition('TAB1.EARNINGENTITY',
                                                                                                                           pin_baseLineTable || '.' || V_EARNING_ENTITY,
                                                                                                                           1,
                                                                                                                           6);
      end if;
   END IF;
   --
   IF pin_calculationType <> 1 THEN
      -- CREATE PRIOR PERIOD VALUE FIELD
      if pin_PriorPeriodFlag IN (1,2) then
         V_PRIOR_PERIOD_VALUE := ''||pin_priorPeriodTable||'.CURRENT_PERIOD_AMOUNT ';
      elsif pin_PriorPeriodFlag = 3 then
         V_PRIOR_PERIOD_VALUE := ''||pin_baseLineTable||'.BASELINE_VALUE ';
      end if;
      -- CREATE FINAL VALUE FIELD
      IF pin_calculationType = 2 THEN -- IF CHANGE IN VALUE
         if v_zero_attainment = 1 then
           V_FINAL_VALUE := 'CAST(nvl(NUMERATOR / DENOMINATOR,0) -(' || V_PRIOR_PERIOD_NAME || ') AS NUMBER' || V_PREC_SCALE_FINAL || ') ';
         else
           V_FINAL_VALUE := 'case when DENOMINATOR = 0 then 0 else CAST((NUMERATOR/DENOMINATOR) -(' || V_PRIOR_PERIOD_NAME || ') AS NUMBER' || V_PREC_SCALE_FINAL || ') end ';
         end if;
      ELSIF pin_calculationType = 3 THEN -- IF PERCENTAGE CHANGE
         if v_zero_attainment = 1 then
           V_FINAL_VALUE := 'CAST( ( nvl(NUMERATOR / DENOMINATOR,0) -' || V_PRIOR_PERIOD_NAME || ')/(ABS(' || V_PRIOR_PERIOD_NAME || ') ) AS NUMBER' || V_PREC_SCALE_FINAL || ') ';
         else
           V_FINAL_VALUE := 'case when DENOMINATOR = 0 then 0 else CAST( ( (NUMERATOR/DENOMINATOR) -' || V_PRIOR_PERIOD_NAME || ')/(ABS(' || V_PRIOR_PERIOD_NAME || ') ) AS NUMBER' || V_PREC_SCALE_FINAL || ') end ';
         end if;
      END IF;
      if v_zero_attainment = 1 then
        V_CURRENT_PERIOD_VALUE := ' CAST(nvl(NUMERATOR / DENOMINATOR,0) AS NUMBER' || V_PREC_SCALE_CURRENT || '),';
      else
        V_CURRENT_PERIOD_VALUE := ' case when DENOMINATOR = 0 then 0 else CAST(NUMERATOR/DENOMINATOR AS NUMBER' || V_PREC_SCALE_CURRENT || ') end,';
      end if;
   ELSE
      V_PRIOR_PERIOD_VALUE := ' NULL ';
      V_CURRENT_PERIOD_VALUE := 'NULL, ';
      if v_zero_attainment = 1 then
        V_FINAL_VALUE        := 'CAST(nvl(NUMERATOR / DENOMINATOR,0) AS NUMBER' || V_PREC_SCALE_FINAL || ') ';
      else
        V_FINAL_VALUE        := 'case when DENOMINATOR = 0 then 0 else CAST(NUMERATOR/DENOMINATOR AS NUMBER' || V_PREC_SCALE_FINAL || ') end ';
      end if;
   END IF;
   --
    v_aggregate_inputs1 := 1;
    v_aggregate_inputs2 := 1;

    if pin_BroaderFrequency is not null then
      v_input1_frequency := pin_BroaderFrequency;
    else
      v_input1_frequency := pin_plan_time_unit_id;
    end if;
    if pin_BroaderFrequency2 is not null then
      v_input2_frequency := pin_BroaderFrequency2;
    else
      v_input2_frequency := pin_plan_time_unit_id;
    end if;

    if pin_plan_time_unit_id != pin_input1_time_unit_id and pin_input1_period_field is not null then
      if pin_input1_time_unit_id != v_input1_frequency then
      V_CORR1_JOIN := 'JOIN TU_CORR_MAT_VIEW ON (' || pin_inputTable1 || '.' || pin_input1_period_field || ' = TUPR_ID AND TUC_TU_ID = ' || pin_input1_time_unit_id || ' AND TUC_TU_ID_CORR = ' || v_input1_frequency ||
                      ') OR (' || pin_inputTable1 || '.' || pin_input1_period_field || ' = TUPR_ID_CORR AND TUC_TU_ID = ' || v_input1_frequency || ' AND TUC_TU_ID_CORR = ' || pin_input1_time_unit_id || ')';
      end if;
    end if;
    if pin_plan_time_unit_id != pin_input2_time_unit_id and pin_input2_period_field is not null then
      if pin_input2_time_unit_id != v_input2_frequency then
      V_CORR2_JOIN := 'JOIN TU_CORR_MAT_VIEW ON (' || pin_inputTable2 || '.' || pin_input2_period_field || ' = TUPR_ID AND TUC_TU_ID = ' || pin_input2_time_unit_id || ' AND TUC_TU_ID_CORR = ' || v_input2_frequency ||
                      ') OR (' || pin_inputTable2 || '.' || pin_input2_period_field || ' = TUPR_ID_CORR AND TUC_TU_ID = ' || v_input2_frequency || ' AND TUC_TU_ID_CORR = ' || pin_input2_time_unit_id || ')';
      end if;
    end if;

   -- set fields for metric inputs result table
   for c in (select NAME2,
                    max(INPUT1) INPUT1,
                    max(INPUT2) INPUT2
               from (select NAME2,
                            case when NAME1 = pin_inputTable1 then NAME1 end INPUT1,
                            case when NAME1 = pin_inputTable2 then NAME1 end INPUT2
                       from (select NAME1, NAME2 from table(pin_MetricInputFields)
                              union
                             select NAME1, NAME2 from table(pin_MetricFilterInputFields)
                             )
                     )
              group by NAME2
              order by NAME2
             ) loop
     select count(*) into v_check_mi_field from table(pin_EntityMapping1) where NAME2 = c.NAME2;
     v_metric_input1_fields := v_metric_input1_fields || case when c.INPUT1 is not null and v_check_mi_field = 0 and c.NAME2 != pin_numerator then ',' || c.NAME2 end;
     v_metric_input1_tabfields := v_metric_input1_tabfields || case when c.INPUT1 is not null then ',TAB1.' || case when c.NAME2 = pin_numerator then 'NUMERATOR' else c.NAME2 end end;
     v_metric_input1_tablefields := v_metric_input1_tablefields || case when c.INPUT1 is not null and v_check_mi_field = 0 and c.NAME2 != pin_numerator then ',' || c.INPUT1 || '.' || c.NAME2 end;
     v_metric_input2_nullfields := v_metric_input2_nullfields || case when c.INPUT1 is not null then ',null' end;
     v_metric_input2_fields := v_metric_input2_fields || case when c.INPUT2 is not null and v_check_mi_field = 0 and c.NAME2 != pin_denominator then ',' || c.NAME2 end;
     v_metric_input2_tabfields := v_metric_input2_tabfields || case when c.INPUT2 is not null then ',TAB2.' || case when c.NAME2 = pin_denominator then 'DENOMINATOR' else c.NAME2 end end;
     v_metric_input2_tablefields := v_metric_input2_tablefields || case when c.INPUT2 is not null and v_check_mi_field = 0 and c.NAME2 != pin_denominator then ',' || c.INPUT2 || '.' || c.NAME2 end;
     v_metric_input1_nullfields := v_metric_input1_nullfields || case when c.INPUT2 is not null then ',null' end;
     v_metric_input_fields := v_metric_input_fields || case when c.INPUT1 is not null or c.INPUT2 is not null then ',' || c.NAME2 end;
     v_metric_input1_insfields := v_metric_input1_insfields || case when c.INPUT1 is not null then ',' || c.NAME2 end;
     v_metric_input2_insfields := v_metric_input2_insfields || case when c.INPUT2 is not null then ',' || c.NAME2 end;
   end loop;

   for c in (select NAME1, NAME2 from table(pin_MetricInputConstants)) loop
     v_input1_constant_fields := v_input1_constant_fields || ',' || c.NAME1;
     if c.NAME1 = 'INPUT_CATEGORY' then
       if c.NAME2 = 'Metric' then
         V_INPUT_CATEGORY := c.NAME2;
         v_metric_input := 1;
       else
         select CD_NAME_SINGULAR into V_INPUT_CATEGORY from CATEGORY_DEFINITIONS where CD_ID = c.NAME2;
         v_metric_input := 0;
       end if;
       v_input1_constant_values := v_input1_constant_values || ',''' || V_INPUT_CATEGORY || '''';
     elsif c.NAME1 = 'INPUT_NAME' then
       if v_metric_input = 1 then
         V_INPUT_NAME := c.NAME2;
       else
         select OR_NAME into V_INPUT_NAME from TABLE_REFERENCES join OBJECT_REGISTRATION on TREF_DEFINITION_ID = OR_ID or TREF_PARENT_DEFINITION_ID = OR_ID where TREF_ID = c.NAME2;
       end if;
       v_input1_constant_values := v_input1_constant_values || ',''' || V_INPUT_NAME || '''';
     elsif c.NAME1 = 'INPUT_CATEGORY_DEFINITION' then
         if c.NAME2 is not null then
            select DEF_TYPE_NAME_SINGULAR into V_INPUT_CATEGORY_DEFINITION from object_registration join definition_types on or_type = def_type_id where or_id = c.NAME2;
            v_input1_constant_values := v_input1_constant_values || ',''' || V_INPUT_CATEGORY_DEFINITION || '''';
         else
            v_input1_constant_values := v_input1_constant_values || ',''' || c.NAME2 || '''';
         end if;
     else
       v_input1_constant_values := v_input1_constant_values || ',''' || c.NAME2 || '''';
     end if;
   end loop;
   for c in (select NAME1, NAME2 from table(pin_MetricInput2Constants)) loop
     v_input2_constant_fields := v_input2_constant_fields || ',' || c.NAME1;
     if c.NAME1 = 'INPUT_CATEGORY' then
       if c.NAME2 = 'Metric' then
         V_INPUT_CATEGORY := c.NAME2;
         v_metric_input := 1;
       else
         select CD_NAME_SINGULAR into V_INPUT_CATEGORY from CATEGORY_DEFINITIONS where CD_ID = c.NAME2;
         v_metric_input := 0;
       end if;
       v_input2_constant_values := v_input2_constant_values || ',''' || V_INPUT_CATEGORY || '''';
     elsif c.NAME1 = 'INPUT_NAME' then
       if v_metric_input = 1 then
         V_INPUT_NAME := c.NAME2;
       else
         select OR_NAME into V_INPUT_NAME from TABLE_REFERENCES join OBJECT_REGISTRATION on TREF_DEFINITION_ID = OR_ID or TREF_PARENT_DEFINITION_ID = OR_ID where TREF_ID = c.NAME2;
       end if;
       v_input2_constant_values := v_input2_constant_values || ',''' || V_INPUT_NAME || '''';
     elsif c.NAME1 = 'INPUT_CATEGORY_DEFINITION' then
         if c.NAME2 is not null then
            select DEF_TYPE_NAME_SINGULAR into V_INPUT_CATEGORY_DEFINITION from object_registration join definition_types on or_type = def_type_id where or_id = c.NAME2;
            v_input2_constant_values := v_input2_constant_values || ',''' || V_INPUT_CATEGORY_DEFINITION || '''';
         else
            v_input2_constant_values := v_input2_constant_values || ',''' || c.NAME2 || '''';
         end if;
     else
       v_input2_constant_values := v_input2_constant_values || ',''' || c.NAME2 || '''';
     end if;
   end loop;

    -- create period fields
    v_mi_periodfields := v_mi_periodfields || ',' || pin_MetricPeriodField;
    v_mi_periodtablefields := v_mi_periodtablefields || ',' || pin_MetricPeriodValue;
    if pin_projectedFlag = 1 then
      v_mi_periodfields := v_mi_periodfields || ',PROJECTED,' || pin_MetricProjectedPeriodField;
      v_mi_periodtablefields := v_mi_periodtablefields || ',PROJECTED,' || pin_MetricProjectedPeriodValue;
    end if;
    v_mi_periodfields := v_mi_periodfields || ',PROCESSED_DATE_TIME';
    v_mi_periodtablefields := v_mi_periodtablefields || ',SYSTIMESTAMP';

   --
   V_INPUT_COLS1  := pin_inputTable1 || '.ROW_IDENTIFIER' || ' ROW_IDENTIFIER,' || pin_EarningEntity(1).NAME1 || ' EARNINGENTITY,' ||
                  pin_EarningEntity(1).NAME2 || ' EARNINGENTITY_BK,'|| V_NUMERATOR || ' NUMERATOR';
   V_INPUT_COLS1_AGG := pin_EarningEntity(1).NAME1 || ',' || pin_EarningEntity(1).NAME2;
   V_INPUT_COLS2  := pin_EarningEntity(1).NAME1 || ' EARNINGENTITY,' ||pin_EarningEntity(1).NAME2 || ' EARNINGENTITY_BK,'|| V_DENOMINATOR || ' DENOMINATOR';
   V_INPUT_COLS2_AGG := pin_EarningEntity(1).NAME1 || ',' || pin_EarningEntity(1).NAME2;
   V_OUTSIDE_INPUT_COLS1 := 'min(ROW_IDENTIFIER) ROW_IDENTIFIER,EARNINGENTITY,EARNINGENTITY_BK,sum(NUMERATOR) NUMERATOR';
   V_OUTSIDE_INPUT_COLS2 := 'EARNINGENTITY,EARNINGENTITY_BK,sum(DENOMINATOR) DENOMINATOR';
   V_GROUPBY_COLS1 := 'EARNINGENTITY,EARNINGENTITY_BK';
   V_GROUPBY_COLS2 := 'EARNINGENTITY,EARNINGENTITY_BK';
   V_VALUES_COLS  := '0,coalesce(EARNINGENTITY,EARNINGENTITY2),coalesce(EARNINGENTITY_BK,EARNINGENTITY_BK2),' || 'CAST(' ||
                     case when v_zero_attainment = 1 then 'nvl(NUMERATOR,0)' else 'NUMERATOR' end ||
                     ' AS NUMBER' || V_NUMERATOR_PRECISION || '),CAST(' ||
                     case when v_zero_attainment = 1 then 'nvl(DENOMINATOR,0)' else 'DENOMINATOR' end ||
                     ' AS NUMBER' || V_DENOMINATOR_PRECISION || ')';
   V_INPUT_COLS   := 'TAB1.ROW_IDENTIFIER,TAB1.EARNINGENTITY,TAB1.EARNINGENTITY_BK,TAB1.NUMERATOR,TAB2.DENOMINATOR,TAB2.EARNINGENTITY EARNINGENTITY2,TAB2.EARNINGENTITY_BK EARNINGENTITY_BK2,' || V_PRIOR_PERIOD_VALUE || ' AS ' || V_PRIOR_PERIOD_NAME;
   V_MAIN_JOIN    := 'TAB1.EARNINGENTITY = TAB2.EARNINGENTITY';
   V_INSERT_FIELDS_MI := substr(pin_EarningEntity(1).NAME1, instr(pin_EarningEntity(1).NAME1, '.') + 1);
   V_SELECT1_FIELDS_MI := 'TAB1.EARNINGENTITY';
   V_SELECT2_FIELDS_MI := 'TAB2.EARNINGENTITY';
   -- CREATE JOINS AND MAP COLUMNS
   IF pin_entityMapping1 IS NOT NULL THEN
      FOR I IN 1..pin_entityMapping1.COUNT LOOP
         IF SUBSTR(pin_EntityMapping1(i).NAME2,1,1) = 'E' THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping1(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping1(i).NAME1);
         ELSE
              v_entity_field_join:= pin_EntityMapping1(i).NAME2;
              v_entity_field_bk :=pin_inputTable1 ||'.'||pin_EntityMapping1(i).NAME2;
         END IF;

         V_MAIN_JOIN    := V_MAIN_JOIN || ' AND (TAB1.' || pin_entityMapping1(I).NAME3 || '=TAB2.' || pin_entityMapping1(I).NAME3
         || ' OR (TAB1.' || pin_entityMapping1(I).NAME3 || ' IS NULL AND TAB2.' || pin_entityMapping1(I).NAME3 || ' IS NULL)) '
         ;
         V_INPUT_COLS1  := V_INPUT_COLS1 || ',' || v_entity_field_bk || ' ' || pin_entityMapping1(I).NAME3 ||
                           ',' || pin_entityMapping1(I).NAME1 || '.E_INTERNAL_ID ' ||  pin_entityMapping1(I).NAME4;
         V_INPUT_COLS1_AGG := V_INPUT_COLS1_AGG || ',' || v_entity_field_bk || ',' || pin_entityMapping1(I).NAME1 || '.E_INTERNAL_ID ';
         V_OUTSIDE_INPUT_COLS1 := V_OUTSIDE_INPUT_COLS1 || ',' || pin_entityMapping1(I).NAME3 || ',' || pin_entityMapping1(I).NAME4;
         V_GROUPBY_COLS1 := V_GROUPBY_COLS1 || ',' || pin_entityMapping1(I).NAME3 || ',' || pin_entityMapping1(I).NAME4;
         V_INPUT_COLS   := V_INPUT_COLS || ',TAB1.' || pin_entityMapping1(I).NAME3 || ',TAB1.' || pin_entityMapping1(I).NAME4;
         if v_zero_attainment = 1 then
           V_INPUT_COLS   := V_INPUT_COLS || ',TAB2.' || pin_entityMapping1(I).NAME3 || ' ' || pin_entityMapping1(I).NAME3 || '2,TAB2.' || pin_entityMapping1(I).NAME4 || ' ' || pin_entityMapping1(I).NAME4 || '2';
         end if;
         V_VALUES_COLS  := V_VALUES_COLS || ',' ||
                           case when v_zero_attainment = 1 then 'coalesce(' || pin_entityMapping1(I).NAME3 || ',' || pin_entityMapping1(I).NAME3 || '2)' else pin_entityMapping1(I).NAME3 end || ',' ||
                           case when v_zero_attainment = 1 then 'coalesce(' || pin_entityMapping1(I).NAME4 || ',' || pin_entityMapping1(I).NAME4 || '2)' else pin_entityMapping1(I).NAME4 end;
         V_GTT_COLS     := V_GTT_COLS || ',' || pin_entityMapping1(I).NAME3 ||','|| pin_entityMapping1(I).NAME4;
         V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_entityMapping1(I).NAME5;

         IF SUBSTR(pin_EntityMapping1(i).NAME2,1,1) = 'E' THEN
           -- use entitity id here for OF-80623 (use alias from NAME4 instead of pin_EntityMapping(i).NAME1 || '.E_INTERNAL_ID'
           V_SELECT1_FIELDS_MI := V_SELECT1_FIELDS_MI || ',TAB1.' || pin_entityMapping1(I).NAME4;
         else
           V_SELECT1_FIELDS_MI := V_SELECT1_FIELDS_MI || ',TAB1.' || pin_entityMapping1(I).NAME2;
         end if;

         v_metric_input1_tablefields := v_metric_input1_tablefields || ',' || pin_inputTable1 || '.' || pin_entityMapping1(I).NAME2;
         v_metric_input1_infields := v_metric_input1_infields || ',' || pin_entityMapping1(I).NAME2;

         --
         IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
           if pin_PriorPeriodFlag IN (1,2) then
            V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND (TAB1.' || pin_entityMapping1(I).NAME4 || '=' || pin_priorPeriodTable || '.' || pin_entityMapping1(I).NAME5
            || ' OR (TAB1.' || pin_EntityMapping1(i).NAME4||' IS NULL AND '||pin_priorPeriodTable||'.'||pin_EntityMapping1(i).NAME5 || ' IS NULL ))'
            ;
           elsif pin_PriorPeriodFlag = 3 then
            V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || ' AND (TAB1.' || pin_entityMapping1(I).NAME4 || '=' || pin_baseLineTable || '.' || pin_entityMapping1(I).NAME5
            || ' OR (TAB1.' || pin_EntityMapping1(i).NAME4||' IS NULL AND '||pin_baseLineTable||'.'||pin_EntityMapping1(i).NAME5 || ' IS NULL ))'
            ;
           end if;
         END IF;

         --
      END LOOP;
   END IF;
     IF pin_entityMapping2 IS NOT NULL THEN
      FOR I IN 1..pin_entityMapping2.COUNT LOOP
         IF SUBSTR(pin_EntityMapping2(i).NAME2,1,1) = 'E' THEN
              v_entity_field_join:= 'E_INTERNAL_ID';
              --we also need to find out the business id of the entity (to populate the GTT)
              v_entity_field_bk := pin_EntityMapping2(i).NAME1||'.'||COMMONS.FIND_ENITY_BUSINESS_KEY(pin_EntityMapping2(i).NAME1);
         ELSE
              v_entity_field_join:= pin_EntityMapping2(i).NAME2;
              v_entity_field_bk :=pin_inputTable2 ||'.'||pin_EntityMapping2(i).NAME2;

         END IF;

         V_INPUT_COLS2  := V_INPUT_COLS2 || ',' || v_entity_field_bk || ' ' || pin_entityMapping2(I).NAME3 ||
                           ',' || pin_entityMapping2(I).NAME1 || '.E_INTERNAL_ID ' ||  pin_entityMapping2(I).NAME4;
         V_INPUT_COLS2_AGG := V_INPUT_COLS2_AGG || ',' || v_entity_field_bk || ',' || pin_entityMapping2(I).NAME1 || '.E_INTERNAL_ID ';
         V_OUTSIDE_INPUT_COLS2 := V_OUTSIDE_INPUT_COLS2 || ',' || pin_entityMapping2(I).NAME3 || ',' || pin_entityMapping2(I).NAME4;
         V_GROUPBY_COLS2 := V_GROUPBY_COLS2 || ',' || pin_entityMapping2(I).NAME3 || ',' || pin_entityMapping2(I).NAME4;

         IF SUBSTR(pin_EntityMapping1(i).NAME2,1,1) = 'E' THEN
           V_SELECT2_FIELDS_MI := V_SELECT2_FIELDS_MI || ',TAB2.' || pin_entityMapping2(I).NAME4;
         else
           V_SELECT2_FIELDS_MI := V_SELECT2_FIELDS_MI || ',TAB2.' || pin_entityMapping2(I).NAME2;
         end if;

         v_metric_input2_tablefields := v_metric_input2_tablefields || ',' || pin_inputTable2 || '.' || pin_entityMapping2(I).NAME2;
         v_metric_input2_infields := v_metric_input2_infields || ',' || pin_entityMapping2(I).NAME2;

      END LOOP;
   END IF;
   -- CREATE FINAL FIELDS
  IF pin_columnMapping IS NOT NULL THEN
      FOR I IN 1..pin_columnMapping.COUNT LOOP
         V_MAIN_JOIN    := V_MAIN_JOIN || ' AND (TAB1.' || pin_columnMapping(I).NAME5 || '=TAB2.' || pin_columnMapping(I).NAME5
         || ' OR (TAB1.' || pin_columnMapping(I).NAME5 || ' IS NULL AND TAB2.' || pin_columnMapping(I).NAME5 || ' IS NULL)) '
         ;
         V_INPUT_COLS1  := V_INPUT_COLS1  || ',' || pin_columnMapping(I).NAME2 || '.' || pin_columnMapping(I).NAME1 || ' ' || pin_columnMapping(I).NAME5;
         V_INPUT_COLS1_AGG := V_INPUT_COLS1_AGG || ',' || pin_columnMapping(I).NAME2 || '.' || pin_columnMapping(I).NAME1;
         V_OUTSIDE_INPUT_COLS1 := V_OUTSIDE_INPUT_COLS1 || ',' || pin_columnMapping(I).NAME5;
         V_INPUT_COLS2  := V_INPUT_COLS2  || ',' || pin_columnMapping(I).NAME4 || '.' || pin_columnMapping(I).NAME3 || ' ' || pin_columnMapping(I).NAME5;
         V_INPUT_COLS2_AGG := V_INPUT_COLS2_AGG || ',' || pin_columnMapping(I).NAME4 || '.' || pin_columnMapping(I).NAME3;
         V_OUTSIDE_INPUT_COLS2 := V_OUTSIDE_INPUT_COLS2 || ',' || pin_columnMapping(I).NAME5;
         V_GROUPBY_COLS1 := V_GROUPBY_COLS1 || ',' || pin_columnMapping(I).NAME5;
         V_GROUPBY_COLS2 := V_GROUPBY_COLS2 || ',' || pin_columnMapping(I).NAME5;
         V_INPUT_COLS   := V_INPUT_COLS   || ',TAB1.' || pin_columnMapping(I).NAME5;
         if v_zero_attainment = 1 then
           V_INPUT_COLS   := V_INPUT_COLS   || ',TAB2.' || pin_columnMapping(I).NAME5 || ' ' || pin_columnMapping(I).NAME5 || '2';
         end if;
         V_VALUES_COLS  := V_VALUES_COLS  || ',' || case when v_zero_attainment = 1 then 'coalesce(' || pin_columnMapping(I).NAME5 || ',' || pin_columnMapping(I).NAME5 || '2)' else pin_columnMapping(I).NAME5 end;
         V_GTT_COLS     := V_GTT_COLS     || ',' || pin_columnMapping(I).NAME5;

         V_INSERT_FIELDS_MI := V_INSERT_FIELDS_MI || ',' || pin_columnMapping(I).NAME1;

         V_SELECT1_FIELDS_MI := V_SELECT1_FIELDS_MI || ',TAB1.' || pin_columnMapping(I).NAME5;
         V_SELECT2_FIELDS_MI := V_SELECT2_FIELDS_MI || ',TAB2.' || pin_columnMapping(I).NAME5;

         --
         IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
           if pin_PriorPeriodFlag IN (1,2) then
            V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND (TAB1.' || pin_columnMapping(I).NAME5 || '=' || pin_priorPeriodTable || '.' || SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)  || ' '
            || ' OR (TAB1.' || pin_ColumnMapping(i).NAME5||' IS NULL AND '||pin_priorPeriodTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' IS NULL ))'
            ;
           elsif pin_PriorPeriodFlag = 3 then
            V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || ' AND (TAB1.' || pin_columnMapping(I).NAME5 || '=' || pin_baseLineTable || '.' || SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1) || ' '
            || ' OR (TAB1.' || pin_ColumnMapping(i).NAME5||' IS NULL AND '||pin_baseLineTable||'.'||SUBSTR(pin_ColumnMapping(i).NAME1, INSTR(pin_ColumnMapping(i).NAME1,'.')+1)|| ' IS NULL ))'
            ;
           end if;
         END IF;

      END LOOP;
   END IF;

   V_INPUT_COLS1 := V_INPUT_COLS1 || ',rank() over(partition by ' || pin_inputTable1 || '.ROW_IDENTIFIER order by ' || case when V_CORR1_JOIN is not null then 'TUPR_ID, TUPR_ID_CORR' else '1' end || ') rnk';
   V_INPUT_COLS2 := V_INPUT_COLS2 || ',rank() over(partition by ' || pin_inputTable2 || '.ROW_IDENTIFIER order by ' || case when V_CORR2_JOIN is not null then 'TUPR_ID, TUPR_ID_CORR' else '1' end || ') rnk';

   V_INPUT_COLS1_MI := V_INPUT_COLS1 || v_metric_input1_tablefields;
   V_INPUT_COLS2_MI := V_INPUT_COLS2 || v_metric_input2_tablefields;
   V_GROUPBY_COLS1_MI := V_GROUPBY_COLS1 || v_metric_input1_fields || v_metric_input1_infields;
   V_GROUPBY_COLS2_MI := V_GROUPBY_COLS2 || v_metric_input2_fields || v_metric_input2_infields;
   V_OUTSIDE_INPUT_COLS1_MI := V_OUTSIDE_INPUT_COLS1 || v_metric_input1_fields || v_metric_input1_infields;
   V_OUTSIDE_INPUT_COLS2_MI := V_OUTSIDE_INPUT_COLS2 || v_metric_input2_fields || v_metric_input2_infields;

   if pin_projectedFlag = 1 then
     v_roster_table := substr(pin_EarningEntity(1).NAME1,1,instr(pin_EarningEntity(1).NAME1, '.')-1);
     V_INPUT_COLS1_MI := V_INPUT_COLS1_MI || ',' || v_roster_table || '.PROJECTED';
     V_INPUT_COLS2_MI := V_INPUT_COLS2_MI || ',' || v_roster_table || '.PROJECTED';
     V_GROUPBY_COLS1_MI := V_GROUPBY_COLS1_MI || ',PROJECTED';
     V_GROUPBY_COLS2_MI := V_GROUPBY_COLS2_MI || ',PROJECTED';
     V_OUTSIDE_INPUT_COLS1_MI := V_OUTSIDE_INPUT_COLS1_MI || ',PROJECTED';
     V_OUTSIDE_INPUT_COLS2_MI := V_OUTSIDE_INPUT_COLS2_MI || ',PROJECTED';
   end if;

   -- ADD PERIOD AND PROJECTED FILTER IN THE JOIN CONDITION IN CASE OF CHANGE IN VALUE AND PERCENTAGE CHANGE
   IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
     if pin_PriorPeriodFlag IN (1,2) then
      V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ' || pin_priorPeriodTable || '.' || pin_priorPeriodColumn || '=' || pin_priorPeriod;
     elsif pin_PriorPeriodFlag = 3  then
      V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE || ' AND ' || pin_baseLineTable || '.' || pin_priorPeriodColumn || '=' || pin_priorPeriod;
     end if;
      --
      IF pin_projectedFlag = 1 THEN
        if pin_PriorPeriodFlag IN (1,2) then
         V_EXTRA_JOIN_PRIOR_PERIOD := V_EXTRA_JOIN_PRIOR_PERIOD || ' AND ' || pin_priorPeriodTable || '.PROJECTED = 0';
         V_EXTRA_JOIN_BASELINE := V_EXTRA_JOIN_BASELINE; --|| ' AND ' || pin_baseLineTable || '.PROJECTED = 0';
       end if;
      END IF;
   END IF;
   -- CREATE WHERE CLAUSE
   IF pin_whereClause1 IS NOT NULL THEN
      V_WHERE_CLAUSE1 := ' WHERE ' || pin_whereClause1;
   END IF;
   IF pin_whereClause2 IS NOT NULL THEN
      V_WHERE_CLAUSE2 := ' WHERE ' || pin_whereClause2;
   END IF;
   -- CREATE OUTSIDE QUERIES
   V_START_OUTSIDE_SQL1 := '(select ' || V_OUTSIDE_INPUT_COLS1 || ' from ';
   V_START_OUTSIDE_SQL2 := '(select ' || V_OUTSIDE_INPUT_COLS2 || ' from ';
   V_END_OUTSIDE_SQL1 := ') where rnk = 1 group by ' || V_GROUPBY_COLS1;
   V_END_OUTSIDE_SQL2 := ') where rnk = 1 group by ' || V_GROUPBY_COLS2;
   -- CREATE INLINE VIEWS
   V_TAB1 := case when v_aggregate_inputs1 = 1 then V_START_OUTSIDE_SQL1 end ||
             '(SELECT ' || V_INPUT_COLS1 || ' FROM ' || pin_joinedInput1 || V_EXTRA_JOIN1 || case when v_aggregate_inputs1 = 1 then V_CORR1_JOIN end || V_WHERE_CLAUSE1 ||
             case when v_aggregate_inputs1 = 1 then V_END_OUTSIDE_SQL1 end ||
             ') TAB1 ';
   V_TAB2 := case when v_aggregate_inputs2 = 1 then V_START_OUTSIDE_SQL2 end ||
             '(SELECT ' || V_INPUT_COLS2 || ' FROM ' || pin_joinedInput2 || V_EXTRA_JOIN2 || case when v_aggregate_inputs2 = 1 then V_CORR2_JOIN end || V_WHERE_CLAUSE2 ||
             case when v_aggregate_inputs2 = 1 then V_END_OUTSIDE_SQL2 end ||
             ') TAB2 ';

   -- create queries for metric inputs
   V_START_OUTSIDE_SQL1_MI := '(select ' || V_OUTSIDE_INPUT_COLS1_MI || ' from ';
   V_START_OUTSIDE_SQL2_MI := '(select ' || V_OUTSIDE_INPUT_COLS2_MI || ' from ';
   V_END_OUTSIDE_SQL1_MI := ') where rnk = 1 group by ' || V_GROUPBY_COLS1_MI;
   V_END_OUTSIDE_SQL2_MI := ') where rnk = 1 group by ' || V_GROUPBY_COLS2_MI;
   V_TAB1_MI := case when v_aggregate_inputs1 = 1 then V_START_OUTSIDE_SQL1_MI end ||
                '(SELECT ' || V_INPUT_COLS1_MI || ' FROM ' || pin_joinedInput1 || V_EXTRA_JOIN1 || case when v_aggregate_inputs1 = 1 then V_CORR1_JOIN end || V_WHERE_CLAUSE1 ||
                case when v_aggregate_inputs1 = 1 then V_END_OUTSIDE_SQL1_MI end ||
                ') TAB1 ';
   V_TAB2_MI := case when v_aggregate_inputs2 = 1 then V_START_OUTSIDE_SQL2_MI end ||
                '(SELECT ' || V_INPUT_COLS2_MI || ' FROM ' || pin_joinedInput2 || V_EXTRA_JOIN2 || case when v_aggregate_inputs2 = 1 then V_CORR2_JOIN end || V_WHERE_CLAUSE2 ||
                case when v_aggregate_inputs2 = 1 then V_END_OUTSIDE_SQL2_MI end ||
                ') TAB2 ';

   -- CREATE INSERT CONDITIONS
   IF pin_entityMapping1 IS NOT NULL THEN
      FOR I IN 1..pin_entityMapping1.COUNT LOOP
         IF SUBSTR(pin_EntityMapping1(i).NAME2,1,1) = 'E' THEN
              v_flag_zero_one := 0;
         ELSE
               --validation 1020
               V_FLAG_VALUE_2_CONDITION := V_FLAG_VALUE_2_CONDITION || ' WHEN ' || pin_EntityMapping1(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping1(i).NAME3 || ' IS NOT NULL THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,2, 1020, 1,'''||pin_EntityMapping1(i).NAME1||','||pin_EntityMapping1(i).NAME2||''')';
         V_FLAG_VALUE_2_CONDITION := V_FLAG_VALUE_2_CONDITION || ' WHEN ' || pin_EntityMapping1(i).NAME4 || ' IS NULL AND '|| pin_EntityMapping1(i).NAME3 || ' IS NOT NULL THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,2, 1020, 2,'''||pin_EntityMapping1(i).NAME1||','||pin_EntityMapping1(i).NAME2||''')';
         END IF;
      END LOOP;
   END IF;

   if v_zero_attainment = 1 then
     V_FLAG_VALUE_1_CONDITION := ' WHEN (NUMERATOR IS NULL OR DENOMINATOR IS NULL) AND EARNINGENTITY IS NOT NULL AND EARNINGENTITY2 IS NOT NULL THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                 'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,1, 1050, 1, NULL)';
   else
     V_FLAG_VALUE_1_CONDITION := ' WHEN NUMERATOR IS NULL OR DENOMINATOR IS NULL THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                 'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,1, 1050, 1, NULL)';
   end if;

   IF pin_calculationType = 2 OR pin_calculationType = 3 THEN
      V_FLAG_VALUE_3_CONDITION := ' WHEN ' || V_PRIOR_PERIOD_NAME || ' IS NULL THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                               'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,3, 1180, 1, NULL)';
   END IF;

   -- we reject the records with denominator 0 only for ratios; for goals they will be included in the result with value 0
   if pin_operationType = 11 then
   V_FLAG_VALUE_5_CONDITION := ' WHEN DENOMINATOR = 0 THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                               'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,5, '||v_error_denominator_goal||', 1, NULL)';
   end if;

   IF pin_calculationType = 3 THEN
      V_FLAG_VALUE_4_CONDITION := ' WHEN ' || V_PRIOR_PERIOD_NAME || ' = 0 THEN INTO '||V_GTT_NAME_REJECTED||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ', VALIDATION_ID, INPUT_NUMBER, VALIDATION_DETAILS) ' ||
                                  'VALUES (' || V_VALUES_COLS || ',NULL,NULL,NULL,4, 1190, 1, NULL)';
   END IF;

   if v_zero_attainment = 1 then
     V_ZERO_CONDITION := ' WHEN NUMERATOR IS NULL OR DENOMINATOR IS NULL THEN INTO '||V_GTT_NAME||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ') ' ||
                         'VALUES (' || V_VALUES_COLS || ','|| V_CURRENT_PERIOD_VALUE ||
                          'CAST(' || V_PRIOR_PERIOD_NAME || ' AS NUMBER ' || V_PREC_SCALE_PRIOR || '),' || V_FINAL_VALUE || ',NULL)';
   end if;

   V_ELSE_CONDITION := ' ELSE INTO '||V_GTT_NAME||' (' || V_GTT_COLS || ',' || V_CURRENT_PERIOD_NAME || ',' || V_PRIOR_PERIOD_NAME || ',' || V_FINAL_PERIOD_NAME || ',' || V_FLAG_NAME || ') ' ||
                       'VALUES (' || V_VALUES_COLS || ','|| V_CURRENT_PERIOD_VALUE ||
                        'CAST(' || V_PRIOR_PERIOD_NAME || ' AS NUMBER ' || V_PREC_SCALE_PRIOR || '),' || V_FINAL_VALUE || ',NULL)';
   -- CREATE INSERT STATEMENT
   V_DML_STATEMENT := 'INSERT ALL' || V_FLAG_VALUE_1_CONDITION || V_FLAG_VALUE_2_CONDITION || V_FLAG_VALUE_3_CONDITION || V_FLAG_VALUE_4_CONDITION || V_FLAG_VALUE_5_CONDITION || V_ZERO_CONDITION || V_ELSE_CONDITION ||
                      ' SELECT ' || V_INPUT_COLS || ' FROM ' ||
                      V_TAB1 || case when v_zero_attainment = 1 then ' FULL OUTER JOIN ' else ' INNER JOIN ' end || V_TAB2 || ' ON ' || V_MAIN_JOIN || V_EXTRA_JOIN_PRIOR_PERIOD || V_EXTRA_JOIN_BASELINE;

   ALTER_SESSION_TIMESTAMP;
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_DML_STATEMENT), 'V_DML_STATEMENT := <value>;', v_stamp);
   EXECUTE IMMEDIATE V_DML_STATEMENT;

    -- set cardinality for temp tables
    V_TOTAL_ROWCOUNT := SQL%ROWCOUNT;
    select count(*) into V_REJECTED_ROWCOUNT from TEMP_METRIC_RATIO_REJECTED;
    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_RATIO_REJECTED', V_REJECTED_ROWCOUNT);
    V_ACCEPTED_ROWCOUNT := V_TOTAL_ROWCOUNT - V_REJECTED_ROWCOUNT;
    COMPENSATION_PROCESSING.SET_TABLE_CARDINALITY('TEMP_METRIC_RATIO', V_ACCEPTED_ROWCOUNT);

   if pin_MetricInputTable is not null then

     V_SELECT1_MI := 'SELECT ' || V_SELECT1_FIELDS_MI || v_mi_periodtablefields ||
                     v_metric_input1_tabfields ||
                     v_input1_constant_values ||
                     ',' || pin_MetricInputSequence || '.NEXTVAL,0';
     V_SELECT2_MI := 'SELECT ' || V_SELECT2_FIELDS_MI || v_mi_periodtablefields ||
                     v_metric_input2_tabfields ||
                     v_input2_constant_values ||
                     ',' || pin_MetricInputSequence || '.NEXTVAL,0';

     --select FLD_COLUMN_NAME into V_MI_PERIOD_FIELD from FIELDS where FLD_ID = (select min(FLD_ID) from FIELDS where FLD_TIMEUNIT = pin_plan_time_unit_id);

     V_INSERT1_MI := 'INSERT INTO ' || pin_MetricInputTable || '(' ||
                     V_INSERT_FIELDS_MI || v_mi_periodfields ||
                     v_metric_input1_insfields ||
                     v_input1_constant_fields ||
                     ',ROW_IDENTIFIER,ROW_VERSION) ';
     V_INSERT2_MI := 'INSERT INTO ' || pin_MetricInputTable || '(' ||
                     V_INSERT_FIELDS_MI || v_mi_periodfields ||
                     v_metric_input2_insfields ||
                     v_input1_constant_fields ||
                     ',ROW_IDENTIFIER,ROW_VERSION) ';

     V_SQL1_MI := V_INSERT1_MI || V_SELECT1_MI || ' from ' || V_TAB1_MI;
     V_SQL2_MI := V_INSERT2_MI || V_SELECT2_MI || ' from ' || V_TAB2_MI;

     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_SQL1_MI), 'V_MI1_STATEMENT := <value>;', v_stamp);
     L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_SQL2_MI), 'V_MI2_STATEMENT := <value>;', v_stamp);

     execute immediate V_SQL1_MI;
     begin
       execute immediate V_SQL2_MI;
     exception
       when dup_val_on_index then null;
     end;

   end if;

   begin
       compensation_processing.ALTER_SESSION_NLS_BINARY;
    end;

EXCEPTION
   WHEN CANNOT_INSERT_NULL THEN
      RAISE_APPLICATION_ERROR(-20002,'Metric system field value can not be NULL.');
END METRIC_RATIOS;


-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END METRICS_PROCESSING;
/
