CREATE PACKAGE TABLE_CALCULATIONS IS

  PROCEDURE ADD_CALCULATION(PIN_INPUT_TBL_ID    NUMBER,
                            PIN_INPUT_FLD_ID    CLOB,
                            PIN_OUTPUT_TBL      NUMBER,
                            PIN_OUTPUT_FLD_ID   NUMBER,
                            PIN_ROWBASED_CALC   NUMBER,
                            PIN_EXP_ID          NUMBER,
                            PIN_EXP_RESOLVED    CLOB,
                            PIN_ORDER           NUMBER,
                            PIN_TBL_REL_KEYS    TABLETYPE_TBL_CALC_REL,
                            PIN_JOIN_ENTITIES   TABLETYPE_NUMBER,
                            PIN_JOIN_PERIODS    CLOB,
                            PIN_ENTITIES_FIELDS TABLETYPE_CLOB,
                            PIN_CROSSREC_DATA   TABLETYPE_CROSSREC DEFAULT NULL,
                            PIN_NULL_CALCS      NUMBER);

  PROCEDURE GET_CALC_ROWBASED_SQL(PIN_TBL_ID       NUMBER,
                                  PIN_INPUT_FLD_ID TABLETYPE_NUMBER,
                                  PIN_HAS_ROW_IDS  NUMBER,
                                  PIN_UPDATE_MODE  NUMBER,
                                  POUT_UPDATE_SQL  IN OUT CLOB);

  PROCEDURE GET_CALCULATE_SQL(PIN_TBL_ID       NUMBER,
                              PIN_INPUT_FLD_ID TABLETYPE_NUMBER,
                              PIN_HAS_ROW_IDS  NUMBER DEFAULT NULL,
                              PIN_UPDATE_MODE  NUMBER,
                              POUT_UPDATE_SQL  IN OUT CLOB);

  PROCEDURE EXECUTE_CALCULATE(PIN_ROW_IDS    TABLETYPE_NUMBER,
                              PIN_UPDATE_SQL CLOB);

  PROCEDURE GET_CALCULATE_INDEPENDENT_SQL(PIN_TBL_ID      NUMBER,
                                          POUT_UPDATE_SQL IN OUT CLOB);

  PROCEDURE GET_FIRST_CALCULATIONS_SQL(PIN_TBL_ID           NUMBER,
                                       PIN_DIMENSION_FLD_ID TABLETYPE_NUMBER,
                                       POUT_UPDATE_SQL      IN OUT CLOB);

  PROCEDURE EXECUTE_FIRST_CALCULATIONS(PIN_UPDATE_SQL IN CLOB);

  PROCEDURE GET_RECALCULATE_ENTITY_CHANGE(PIN_TBL_ID         IN NUMBER,
                                          PIN_ENTITY_ID      IN NUMBER,
                                          PIN_HAS_ENTITY_IDS IN NUMBER,
                                          POUT_UPDATE_SQL    IN OUT CLOB) ;


  -- Author     : Kristo, Robert
  -- Description: get the queries needed by the top down adjustments in model tables
  /*
  PARAMETER LIST:
   pi_view_id         NUMBER                      - the view's id
   pi_from_clause     CLOB                        - the query also containing the AnH filtering
   pi_field_id        NUMBER                      - the updated field
   PI_WEIGHT_FIELD_ID NUMBER                      - weight field id (only for adjustments on weighted average aggregation columns)
   pi_row_path        TABLETYPE_MDL_DIM_PATH      - the path for the row dimension
   pi_col_path        TABLETYPE_MDL_DIM_PATH      - the path for the column dimension
   pi_old_sum         NUMBER                      - the sum which was before the calculation
   pi_new_sum         VARCHAR2                    - the updated value
   pi_td_type         NUMBER                      - the top down calculation type (0 - sum, 1 - avg, 2 - constant/drivers, 3 - weighted average)
   pi_td_distribution_type NUMBER 				  - the top down distribution type (1 - proportionally, 2 - equally)
   pi_proportion_fld_id	   NUMBER				  - the field used for calculating the proportion (in case of proportional distribution)
   pi_proportion_fld_value NUMBER 				  - the value of the proportion field

  OUTPUT PARAMETER LIST:
  pout_sql_td         CLOB                        - the query created for the top down adjustment
  pout_td_difference_sql CLOB                     - the query which makes the sum exact
  pout_sql_calc       CLOB                        - the query which updates the outputs for those records
call:
    declare
      v_sql_td            CLOB;
      v_sql_calc          CLOB;
      v_td_difference_sql CLOB;
    begin
      TABLE_CALCULATIONS.GET_SQLS_FOR_TD_QUERIES(pi_view_id             => 234,
                                                 pi_from_clause         => 'T123',
                                                 pi_field_id            => 454,
												 PI_WEIGHT_FIELD_ID     => null,
                                                 pi_row_path            => TABLETYPE_MDL_DIM_PATH(OBJTYPE_MDL_DIM_PATH('Entity',2831,1)),
                                                 pi_col_path            => TABLETYPE_MDL_DIM_PATH(OBJTYPE_MDL_DIM_PATH('Entity',3507,3)),
                                                 pi_old_sum             => 2354,
                                                 pi_new_sum             => 46543,
                                                 pi_td_type             => 0,
												 pi_td_distribution_type => 1,
												 pi_proportion_fld_id	=> 454,
												 pi_proportion_fld_value => 2354,

                                                 pout_sql_td            => v_sql_td,
                                                 pout_td_difference_sql => v_td_difference_sql
                                                 pout_sql_calc          => v_sql_calc);
    end;
  */
  --------------------------------------------------------------------------------------------------------------------
PROCEDURE GET_SQLS_FOR_TD_QUERIES(PI_VIEW_ID       NUMBER,
                                  PI_FROM_CLAUSE   CLOB,
                                  PI_FIELD_ID      NUMBER,
								  PI_WEIGHT_FIELD_ID NUMBER,
                                  PI_ROW_PATH      TABLETYPE_MDL_DIM_PATH_EXP,
                                  PI_COL_PATH      TABLETYPE_MDL_DIM_PATH_EXP,
                                  PI_OLD_SUM       NUMBER,
                                  PI_NEW_SUM       VARCHAR2,
                                  PI_TD_TYPE       NUMBER,
                                  PI_TD_DISTRIBUTION_TYPE  NUMBER,
								  PI_PROPORTION_FLD_ID     NUMBER,
                                  PI_PROPORTION_FLD_VALUE  NUMBER,

                                  POUT_SQL_TD            OUT NOCOPY CLOB,
                                  POUT_TD_DIFFERENCE_SQL OUT NOCOPY CLOB,
                                  POUT_SQL_CALC          OUT NOCOPY CLOB);


  -- Author     : Tudose, Alexandra
  -- Description: get the queries needed by the zero sum adjustments in model tables
  /*
  PARAMETER LIST:
   PI_VIEW_ID           NUMBER                      - the view's id
   PI_FROM_CLAUSE       CLOB                        - the query also containing the AnH filtering
   PI_FIELD_ID          NUMBER                      - the updated field
   PI_COL_PATH          TABLETYPE_MDL_DIM_PATH      - the path for the column dimension

   PI_SIBLINGS_ROW_INFO TABLETYPE_PIVOT_ROW_INFO    - adjusted row + siblings info
                                  - ROW_PATH           TABLETYPE_MDL_DIM_PATH_EXP    - the path for the row dimension
                                  - OLD_SUM            NUMBER
                                  - NEW_SUM            NUMBER
                                  - ROW_COUNT          NUMBER
                                  - ROW_VERSION_SUM    NUMBER

   PI_TD_TYPE                  NUMBER               - the top down calculation type (0 - sum)
   PI_TD_DISTRIBUTION_TYPE     NUMBER               - the top down distribution type (1 - proportionally, 2 - equally)
   PI_SL_DISTRIBUTION_TYPE     NUMBER               - the distribution type on the same level (1 - proportionally, 2 - equally)
   PI_PROPORTION_FLD_ID        NUMBER               - the field used for calculating the proportion (in case of proportional distribution)

  OUTPUT PARAMETER LIST:
   POUT_QUERIES                TABLETYPE_ADJUSTMENT_QUERIES - the list of queries needed to update the model table

                                   - SQL_TD            CLOB   - the query created for the top down adjustment
                                   - TD_DIFFERENCE_SQL CLOB   - the query which makes the sum exact
                                   - SQL_CALC          CLOB   - the query which updates the outputs for those records
								   - NEW_SUM_SQL	   CLOB   - the query which returns the new aggregated sum for the updated records
                                   - NEW_SUM           NUMBER - the new aggregated sum for the updated records
                                   - ROW_COUNT         NUMBER - the row count of the updated records
                                   - ROW_VERSION_SUM   NUMBER - the sum of row version of the updated records
  */
  --------------------------------------------------------------------------------------------------------------------
PROCEDURE GET_SQLS_FOR_ZERO_SUM(PI_VIEW_ID              NUMBER,
                                PI_FROM_CLAUSE          CLOB,
                                PI_FIELD_ID             NUMBER,
                                PI_COL_PATH             TABLETYPE_MDL_DIM_PATH_EXP,
                                PI_SIBLINGS_ROW_INFO    TABLETYPE_PIVOT_ROW_INFO,
                                PI_TD_TYPE              NUMBER,
                                PI_TD_DISTRIBUTION_TYPE NUMBER, -- top down distribution type
                                PI_SL_DISTRIBUTION_TYPE NUMBER, -- same level distribution type
								PI_PROPORTION_FLD_ID    NUMBER, -- for both TD and SL adjustment

                                POUT_QUERIES            OUT TABLETYPE_ADJUSTMENT_QUERIES);

END TABLE_CALCULATIONS;
/
