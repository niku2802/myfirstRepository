CREATE PACKAGE BODY COMMONS_INDEXING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : commons-tables
  -- Requester      : Pooja Sharma
  -- Authors        : Hardika Bhate, Shriniket Pimparkar
  -- Create date    : 20130115
  -- Reviewer       : Maxim Rohit
  -- Review date    : 20130225
  -- Description    : Package used to handle all operations for application indexes

  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************

  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

  -- OF-33540
  PROCEDURE MERGE_AIR(PI_DEFINITION_ID              IN NUMBER,
                      PI_INDEX_NAME                 IN VARCHAR2,
                      PI_TABLE_NAME                 IN VARCHAR2,
                      PI_COLUMN_LIST                IN VARCHAR2,
                      PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                      PI_BUSINESS_NAME              IN VARCHAR2,
                      PI_IS_UNIQUE                  IN NUMBER,
                      PI_INDEX_TYPE                 IN NUMBER,
                      PI_STATUS                     IN NUMBER) IS
    V_COLUMN_LIST VARCHAR2(1300 CHAR);
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- INSERT_LOGS('MERGE_AIR started');
    V_COLUMN_LIST := REPLACE(PI_COLUMN_LIST, '''', '');
    MERGE INTO APPLICATION_INDEX_REQUESTS AIR
    USING (SELECT PI_DEFINITION_ID PI_DEFINITION_ID,
                  PI_BUSINESS_NAME PI_BUSINESS_NAME,
                  PI_INDEX_NAME PI_INDEX_NAME,
                  PI_TABLE_NAME PI_TABLE_NAME,
                  PI_RECREATE_INDEX_ON_COL_DROP PI_RECREATE_INDEX_ON_COL_DROP,
                  V_COLUMN_LIST PI_COLUMN_LIST2,
                  PI_IS_UNIQUE PI_IS_UNIQUE,
                  PI_INDEX_TYPE PI_INDEX_TYPE,
                  CASE
                    WHEN PI_STATUS = 2 THEN
                     1
                    ELSE
                     0
                  END IS_ENABLED,
                  SYSTIMESTAMP CREATION_DATE,
                  SYSTIMESTAMP LAST_UPDATE_DATE,
                  PI_STATUS PI_STATUS
             FROM DUAL) IN_PARAM
    ON (AIR.AIR_TABLE_NAME = IN_PARAM.PI_TABLE_NAME
    /*      AND AIR.AIR_INDEXED_COLUMNS=IN_PARAM.PI_COLUMN_LIST2 --OF-35060 */
    AND NVL(AIR.AIR_BUSINESS_NAME, 'BN_NULL') = NVL(IN_PARAM.PI_BUSINESS_NAME, 'BN_NULL') AND NVL(AIR.AIR_DEF_ID, -1) = NVL(IN_PARAM.PI_DEFINITION_ID, -1))
    WHEN MATCHED THEN
      UPDATE
         SET AIR.AIR_LAST_UPDATE_DATE = IN_PARAM.LAST_UPDATE_DATE,
             AIR.AIR_STATUS           = IN_PARAM.PI_STATUS,
             AIR.AIR_INDEX_TYPE       = PI_INDEX_TYPE,
             AIR.AIR_IS_ENABLED       = IN_PARAM.IS_ENABLED,
             AIR.AIR_INDEXED_COLUMNS  = IN_PARAM.PI_COLUMN_LIST2 --OF-35060


    WHEN NOT MATCHED THEN
      INSERT
        (AIR.AIR_ID,
         AIR.AIR_DEF_ID,
         AIR.AIR_BUSINESS_NAME,
         AIR.AIR_INDEX_NAME,
         AIR.AIR_TABLE_NAME,
         AIR.AIR_IS_INDEX_TO_BE_RECREATED,
         AIR.AIR_INDEXED_COLUMNS,
         AIR.AIR_INDEX_IS_UNIQUE,
         AIR.AIR_INDEX_TYPE,
         AIR.AIR_IS_ENABLED,
         AIR.AIR_CREATION_DATE,
         AIR.AIR_LAST_UPDATE_DATE,
         AIR_STATUS)
      VALUES
        (AIR_SEQ.NEXTVAL,
         IN_PARAM.PI_DEFINITION_ID,
         IN_PARAM.PI_BUSINESS_NAME,
         IN_PARAM.PI_INDEX_NAME,
         IN_PARAM.PI_TABLE_NAME,
         IN_PARAM.PI_RECREATE_INDEX_ON_COL_DROP,
         IN_PARAM.PI_COLUMN_LIST2,
         IN_PARAM.PI_IS_UNIQUE,
         IN_PARAM.PI_INDEX_TYPE,
         IN_PARAM.IS_ENABLED,
         IN_PARAM.CREATION_DATE,
         IN_PARAM.LAST_UPDATE_DATE,
         IN_PARAM.PI_STATUS);
    -- INSERT_LOGS('MERGE_AIR ended');
    COMMIT;
  exception
    when others then
      null;
      -- INSERT_LOGS(SQLERRM||'--- PI_DEFINITION_ID=>'||PI_DEFINITION_ID||' PI_INDEX_NAME=>'||PI_INDEX_NAME||' PI_BUSINESS_NAME=>'||PI_BUSINESS_NAME||' PI_COLUMN_LIST=>'||PI_COLUMN_LIST);

  END MERGE_AIR;

  -- OF-32673 STARTED
  PROCEDURE SAVE_EXCEPTIONS(PI_EXCEPTION IN CLOB,
                            PI_RUN_ID    NUMBER DEFAULT NULL) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO INDEXING_EXCEPTIONS
      (IE_ID, IE_RUN_ID, IE_EXCEPTION, IE_CREATE_TIME)
    VALUES
      (IE_ID_SEQ.NEXTVAL, PI_RUN_ID, PI_EXCEPTION, SYSTIMESTAMP);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  --OF-32673 ENDED
  procedure Async_Plsql_Run(pi_plsql_code in varchar2,
                            PI_IDENTIFIER in varchar2,
                            pi_comment    in varchar2,
                            PI_START_DATE DATE DEFAULT NULL) as
    v_job_name varchar2(30 char) := substr(('ACIP_' || PI_IDENTIFIER || '_' ||
                                           ACIP_SEQ.nextval),
                                           1,
                                           30);
    pragma autonomous_transaction;
  begin
    dbms_scheduler.create_job(job_name            => v_job_name,
                              job_type            => 'PLSQL_BLOCK',
                              job_action          => pi_plsql_code,
                              number_of_arguments => 0,
                              start_date          => PI_START_DATE,
                              enabled             => TRUE,
                              auto_drop           => TRUE,
                              comments            => pi_comment);

    --DBMS_SCHEDULER.run_job (job_name            => v_job_name,
    --                          use_current_session => FALSE);

  exception
    when others then
      null;

  end Async_Plsql_Run;

  -- OF-30537 start
  PROCEDURE GET_INDEX_DETAILS_I_META(PI_AIM_COL_LIST  IN COLTYPE_INDEXED_COLUMNS_LIST := COLTYPE_INDEXED_COLUMNS_LIST(),
                                     PI_ASIM_COL_LIST IN COLTYPE_INDEXED_COLUMNS_LIST1 := COLTYPE_INDEXED_COLUMNS_LIST1(),
                                     PI_TABLE_NAME    IN VARCHAR2,
                                     PO_INDEX_NAME    OUT VARCHAR2,
                                     PO_INDEX_EXISTS  OUT NUMBER,
                                     PO_IS_UNIQUE     OUT VARCHAR2) IS

  BEGIN
    -- INSERT_LOGS('GET_INDEX_DETAILS_I_META started');
    PO_INDEX_EXISTS := 0;
    IF PI_ASIM_COL_LIST.COUNT = 0 AND PI_AIM_COL_LIST.COUNT = 0 THEN
      -- INSERT_LOGS('PI_ASIM_COL_LIST and PI_AIM_COL_LIST is null');
      PO_INDEX_NAME   := NULL;
      PO_INDEX_EXISTS := NULL;
    ELSE
      -- INSERT_LOGS('PI_ASIM_COL_LIST or PI_AIM_COL_LIST is not null');
      IF PI_AIM_COL_LIST.COUNT > 0 THEN
        --outer loop
        -- INSERT_LOGS('IF PI_AIM_COL_LIST.COUNT>0 THEN');
        FOR i IN (SELECT AIM_INDEX_NAME,
                         AIM_INDEXED_COLUMNS,
                         AIM_INDEX_IS_UNIQUE
                    FROM APPLICATION_INDEXES_METADATA
                   WHERE AIM_TABLE_NAME = PI_TABLE_NAME) LOOP
          PO_INDEX_NAME := i.AIM_INDEX_NAME;
          PO_IS_UNIQUE  := case i.AIM_INDEX_IS_UNIQUE
                             when 1 then
                              'UNIQUE'
                             when 0 then
                              'NONUNIQUE'
                             else
                              null
                           end;
          --check if we need to execute inner loop
          IF PI_AIM_COL_LIST.COUNT = I.AIM_INDEXED_COLUMNS.COUNT THEN
            -- INSERT_LOGS('IF PI_AIM_COL_LIST.COUNT=I.AIM_INDEXED_COLUMNS.COUNT THEN');
            --inner loop for matching collections
            FOR c IN i.AIM_INDEXED_COLUMNS.first .. i.AIM_INDEXED_COLUMNS.last loop
              -- if both are equal then keep checking else break the loop and return control to outer loop
              -- INSERT_LOGS('PI_AIM_COL_LIST(c) = ' || PI_AIM_COL_LIST(c));
              -- INSERT_LOGS('i.AIM_INDEXED_COLUMNS(c) = ' || i.AIM_INDEXED_COLUMNS(c));
              IF PI_AIM_COL_LIST(c) = i.AIM_INDEXED_COLUMNS(c) THEN
                -- INSERT_LOGS('IF PI_AIM_COL_LIST(c)=i.AIM_INDEXED_COLUMNS(c) THEN -- PO_INDEX_EXISTS := 1');
                PO_INDEX_EXISTS := 1;
              ELSE
                -- INSERT_LOGS('IF PI_AIM_COL_LIST(c)=i.AIM_INDEXED_COLUMNS(c) -- ELSE -- PO_INDEX_EXISTS := null -- PO_IS_UNIQUE := NULL -- PO_INDEX_EXISTS := 0 -- exit loop');
                PO_INDEX_NAME   := NULL;
                PO_IS_UNIQUE    := NULL;
                PO_INDEX_EXISTS := 0;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          -- IF index exist then exit and return the control to proc caller module
          IF PO_INDEX_EXISTS = 1 THEN
            -- INSERT_LOGS('GET_INDEX_DETAILS_I_META -- FROM AIM -- IF PO_INDEX_EXISTS=1 THEN -- return');
            RETURN;
          END IF;
        END LOOP;
      END IF;
      IF PI_ASIM_COL_LIST.COUNT > 0 THEN
        -- INSERT_LOGS('IF PI_ASIM_COL_LIST.COUNT>0 THEN');
        --outer loop
        FOR i IN (SELECT ASIM_INDEX_NAME,
                         ASIM_INDEXED_COLUMNS,
                         ASIM_INDEX_IS_UNIQUE
                    FROM APP_SPECIFIC_INDEXES_METADATA
                   WHERE ASIM_TABLE_NAME = PI_TABLE_NAME) LOOP
          PO_INDEX_NAME := i.ASIM_INDEX_NAME;
          PO_IS_UNIQUE  := case i.ASIM_INDEX_IS_UNIQUE
                             when 1 then
                              'UNIQUE'
                             when 0 then
                              'NONUNIQUE'
                             else
                              null
                           end;
          --check if we need to execute inner loop
          IF PI_ASIM_COL_LIST.COUNT = I.ASIM_INDEXED_COLUMNS.COUNT THEN
            -- INSERT_LOGS('IF PI_ASIM_COL_LIST.COUNT=I.AIM_INDEXED_COLUMNS.COUNT THEN');
            --inner loop for matching collections
            FOR c IN i.ASIM_INDEXED_COLUMNS.first .. i.ASIM_INDEXED_COLUMNS.last loop
              -- if both are equal then keep checking else break the loop and return control to outer loop
              IF PI_ASIM_COL_LIST(c) = i.ASIM_INDEXED_COLUMNS(c) THEN
                -- INSERT_LOGS('IF PI_ASIM_COL_LIST(c)=i.ASIM_INDEXED_COLUMNS(c) THEN -- PO_INDEX_EXISTS := 1');
                PO_INDEX_EXISTS := 1;
              ELSE
                -- INSERT_LOGS('IF PI_ASIM_COL_LIST(c)=i.ASIM_INDEXED_COLUMNS(c) -- ELSE -- PO_INDEX_EXISTS := null -- PO_IS_UNIQUE := NULL -- PO_INDEX_EXISTS := 0 -- exit loop');
                PO_INDEX_NAME   := NULL;
                PO_IS_UNIQUE    := NULL;
                PO_INDEX_EXISTS := 0;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          -- IF index exist then exit and return the control to proc caller module
          IF PO_INDEX_EXISTS = 1 then
            -- INSERT_LOGS('GET_INDEX_DETAILS_I_META -- FROM ASIM -- IF PO_INDEX_EXISTS=1 THEN -- return');
            RETURN;
          END IF;
        END LOOP;
      END IF;
    END IF;
    -- INSERT_LOGS('GET_INDEX_DETAILS ended');
  END GET_INDEX_DETAILS_I_META;

  -- OF-30537 START
  PROCEDURE CREATE_INDEX2(PI_TABLE_NAME        IN VARCHAR2,
                          PI_INDEX_NAME        IN VARCHAR2,
                          PI_COLUMN_LIST       IN SYS.HSBLKNAMLST,
                          PI_UNIQUENESS        IN NUMBER,
                          PI_COL_IS_PRIMARYKEY IN NUMBER,
                          PI_INITRANS          IN NUMBER DEFAULT 5,
                          PI_INDEX_TABLESPACE  IN VARCHAR2, /*OF-11821*/
                          PI_TRANSACTION_ID    IN VARCHAR2,
                          PI_RUN_ID            IN NUMBER DEFAULT NULL,
                          PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded, 5 - Invalid Identifier
                          PO_INDEX_NAME        OUT VARCHAR2,
                          PO_IS_UNIQUE         OUT VARCHAR2,
                          PO_CREATE_DDL        OUT CLOB) IS
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    V_COL            VARCHAR2(1300 CHAR);
    V_DDL            CLOB;
    V_UNDO_DDL       CLOB;
    V_INDEXNAME      VARCHAR2(30) := UPPER(PI_INDEX_NAME);
    V_TABLE_NAME     VARCHAR2(30) := UPPER(PI_TABLE_NAME);
    V_DATA_TYPE      VARCHAR2(106);
    V_NLS_SORT       VARCHAR2(160 CHAR);
    V_INDEX_EXISTS   NUMBER;
    E_MAXIMUM_KEY_LENGTH_EXCEEDED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_MAXIMUM_KEY_LENGTH_EXCEEDED, -1450);

    E_PRIMARY_KEY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_PRIMARY_KEY_EXISTS, -2260);

    E_NAME_ALREADY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_NAME_ALREADY_EXISTS, -955);

    E_COLUMN_LIST_ALREADY_INDEXED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_COLUMN_LIST_ALREADY_INDEXED, -1408);
    V_INDEXED_COLUMNS_LIST COLTYPE_INDEXED_COLUMNS_LIST1 := COLTYPE_INDEXED_COLUMNS_LIST1();
    V_PO_FLAG              NUMBER(1);
    V_IS_EXEC              BOOLEAN;
    V_PR_VALUE             VARCHAR2(1300 char);
    V_SQL                  VARCHAR2(32767 char);
    v_col_name_list        COLTYPE_INDEXED_COLUMNS_LIST := COLTYPE_INDEXED_COLUMNS_LIST();
  BEGIN
    -- INSERT_LOGS('CREATE_INDEX2 started');
    --sales planning change; get env name
    SELECT nvl(max(PR_VALUE), 'SPM')
      INTO V_PR_VALUE
      FROM PROPERTIES
     WHERE PR_NAME = 'ENV_NAME';

    CASE V_PR_VALUE
      WHEN 'SPM' THEN
        V_IS_EXEC := TRUE;
      ELSE
        V_IS_EXEC := FALSE;
    END CASE;

    -- 1. Alter Session to BINARY
    IF PI_COLUMN_LIST IS NOT NULL THEN
      -- Get the transaction id
      --commented as we need to log SPM transaction_id which will get from JAVA
      --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

      -- Create primary key constraint and index
      IF (PI_COL_IS_PRIMARYKEY = 1) THEN
        -- IF_1 START

        -- Create Primary Key on the table
        V_DDL := ' ALTER TABLE ' || V_TABLE_NAME || ' ADD CONSTRAINT ' ||
                 V_INDEXNAME || ' PRIMARY KEY (' || PI_COLUMN_LIST(1) ||
                 ') USING INDEX  INITRANS ' || PI_INITRANS ||
                 ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        V_UNDO_DDL := '
            BEGIN
              FOR C IN (
                  SELECT NULL
                  FROM USER_CONSTRAINTS UC
                  WHERE UC.TABLE_NAME = ''' ||
                      V_TABLE_NAME || '''
                    AND UC.CONSTRAINT_TYPE = ''P''
                    AND (UC.CONSTRAINT_NAME = ''' ||
                      V_INDEXNAME ||
                      '''))
              LOOP
                EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                      V_TABLE_NAME || ' DROP PRIMARY KEY DROP INDEX'';
              END LOOP;
            END;';

        -- Create the primary key index, only if v_count is increased to 1 from the above loop code
        <<CREATE_PRIMARY_KEY>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATES PRIMARY KEY CONSTRAINT AND INDEX ON TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          --If Primary key creation is done set v_primary_key_existence to 1
          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_CREATE_DDL   := V_DDL;
        EXCEPTION
          WHEN E_PRIMARY_KEY_EXISTS THEN
            -- Return the index and constraint name
            SELECT CONSTRAINT_NAME
              INTO PO_INDEX_NAME
              FROM USER_CONSTRAINTS
             WHERE CONSTRAINT_TYPE = 'P'
               AND TABLE_NAME = V_TABLE_NAME;

            PO_INDEX_STATUS := 2;
            PO_CREATE_DDL   := V_DDL;
        END;
        --Single column index
      ELSIF PI_COLUMN_LIST.COUNT = 1 THEN
        --Check the data type of the column
        SELECT DATA_TYPE
          INTO V_DATA_TYPE
          FROM USER_TAB_COLUMNS
         WHERE TABLE_NAME = V_TABLE_NAME /* OF-5973 */
           AND COLUMN_NAME = UPPER(PI_COLUMN_LIST(1));
        V_INDEXED_COLUMNS_LIST.extend;
        --if data type is VARCHAR2
        IF V_DATA_TYPE = 'VARCHAR2' THEN
          --IF_4 START
          -- /* OF-5973 */ APPLY UPPER function
          V_COL := 'UPPER("' || PI_COLUMN_LIST(1) || '")';
          V_INDEXED_COLUMNS_LIST(1) := 'UPPER("' || PI_COLUMN_LIST(1) || '")';
          --ELSE it is non-varchar column
        ELSE
          V_COL := PI_COLUMN_LIST(1);
          V_INDEXED_COLUMNS_LIST(1) := PI_COLUMN_LIST(1);
        END IF; -- IF_4 END
        BEGIN
          --PI_IDENTIFIER  0 APP INDEX, 1 DBA INDEX, (CORE TYPES START HERE)2- BUSINESS, 3-PK, 4 ENTITY, 5- PERIOD
          IF V_INDEXNAME LIKE 'APP_%' THEN
            --sales planning change; skip executing index_uasge in sales
            IF V_IS_EXEC THEN
              v_sql := '
              BEGIN
                INDEX_USAGE.IS_CREATE(PI_TABLE_NAME               => ''' ||
                       V_TABLE_NAME || ''',
                                        PI_INDEX_NAME           => ''' ||
                       V_INDEXNAME || ''',
                                        PI_COLUMN_NAME_LIST     => :1,
                                        PI_COLUMN_LIST_FUNCTION => :2,
                                        PI_IDENTIFIER           => 0,
                                        PO_FLAG                 => :V_PO_FLAG);
              END;';

              EXECUTE IMMEDIATE v_sql
                using in v_col_name_list, V_INDEXED_COLUMNS_LIST, out V_PO_FLAG;
              IF V_PO_FLAG = 0 THEN
                RETURN;
              END IF;
            END IF;
          END IF;
        END;
        V_DDL := ' CREATE ';

        -- Create DDL statements based on uniqueness

        IF PI_UNIQUENESS = 1 THEN
          --IF_5 START
          V_DDL := V_DDL || 'UNIQUE';
        END IF; --IF_5 END

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        BEGIN
          COMMONS_INDEXING.GET_INDEX_DETAILS(PI_TABLE_NAME   => V_TABLE_NAME,
                                             PI_COL_LIST     => PI_COLUMN_LIST,
                                             PO_INDEX_NAME   => PO_INDEX_NAME,
                                             PO_INDEX_EXISTS => V_INDEX_EXISTS,
                                             PO_IS_UNIQUE    => PO_IS_UNIQUE);

        END;
        IF V_INDEX_EXISTS = 1 THEN
          PO_INDEX_STATUS := 2;
          PO_CREATE_DDL   := V_DDL;
        ELSE
          -- Execute the Create DDl through COMMONS DDL Handling service
          <<CREATE_SINGLE_COLUMN_INDEX>>
          BEGIN
            COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                             PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                  V_INDEXNAME ||
                                                                  ' ON COLUMN ' ||
                                                                  PI_COLUMN_LIST(1) ||
                                                                  ' OF TABLE ' ||
                                                                  V_TABLE_NAME,
                                             PI_DDL            => V_DDL,
                                             PI_UNDO_DDL       => V_UNDO_DDL,
                                             PI_RUN_ID         => PI_RUN_ID);

            -- INSERT_LOGS('CREATE_INDEX2 -- CREATE_SINGLE_COLUMN_INDEX -- PO_INDEX_STATUS := 1 -- PO_INDEX_NAME = ' || V_INDEXNAME || ' -- PO_IS_UNIQUE = ' || PI_UNIQUENESS || ' -- PO_CREATE_DDL = ' || V_DDL);
            PO_INDEX_STATUS := 1;
            PO_INDEX_NAME   := V_INDEXNAME;
            PO_IS_UNIQUE    := PI_UNIQUENESS;
            PO_CREATE_DDL   := V_DDL;
          EXCEPTION
            WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
              --Get the index name for the given column
              -- OF-30537 START
              -- PO_INDEX_NAME   := get_already_present_index_name(pi_table_name => V_TABLE_NAME, pi_col_list => TO_CHAR(V_COL));
              -- INSERT_LOGS('CREATE_INDEX2 GET_INDEX_DETAILS started');
              COMMONS_INDEXING.GET_INDEX_DETAILS(PI_TABLE_NAME   => PI_TABLE_NAME,
                                                 PI_COL_LIST     => PI_COLUMN_LIST,
                                                 PO_INDEX_NAME   => PO_INDEX_NAME,
                                                 PO_INDEX_EXISTS => V_INDEX_EXISTS,
                                                 PO_IS_UNIQUE    => PO_IS_UNIQUE);

              -- INSERT_LOGS('CREATE_INDEX2 GET_INDEX_DETAILS ended');
              --Get uniqueness property
              /*SELECT UNIQUENESS
               INTO PO_IS_UNIQUE
               FROM USER_INDEXES
              WHERE INDEX_NAME = PO_INDEX_NAME;*/
              -- OF-30537 END
              PO_INDEX_STATUS := 2;
              PO_CREATE_DDL   := V_DDL;
            WHEN E_NAME_ALREADY_EXISTS THEN
              PO_INDEX_STATUS := 3;
              --RAISE E_NAME_ALREADY_EXISTS;
              PO_CREATE_DDL := V_DDL;
          END;
        END IF;
        --Multi columns to be indexed
      ELSIF PI_COLUMN_LIST.COUNT > 1 THEN
        FOR C IN 1 .. PI_COLUMN_LIST.COUNT LOOP
          --Check the data type of the column
          SELECT DATA_TYPE
            INTO V_DATA_TYPE
            FROM USER_TAB_COLUMNS
           WHERE TABLE_NAME = V_TABLE_NAME
             AND COLUMN_NAME = UPPER(PI_COLUMN_LIST(C));
          V_INDEXED_COLUMNS_LIST.extend;
          --if data type is VARCHAR2
          IF V_DATA_TYPE = 'VARCHAR2' THEN
            --IF_4 START
            -- /* OF-5973 */ APPLY UPPER function
            V_COL := V_COL || 'UPPER("' || PI_COLUMN_LIST(C) || '")';
            V_INDEXED_COLUMNS_LIST(C) := 'UPPER("' || PI_COLUMN_LIST(C) || '")';
            --ELSE it is non-varchar column
          ELSE
            V_COL := V_COL || PI_COLUMN_LIST(C);
            V_INDEXED_COLUMNS_LIST(C) := PI_COLUMN_LIST(C);
          END IF; -- IF_4 END
          V_COL := V_COL || ',';
        END LOOP;
        BEGIN
          IF V_INDEXNAME LIKE 'APP_%' THEN
            --sales planning change; skip executing index_uasge in sales
            IF V_IS_EXEC THEN
              v_sql := '
              BEGIN
                INDEX_USAGE.IS_CREATE(PI_TABLE_NAME               => ''' ||
                       V_TABLE_NAME || ''',
                                      PI_INDEX_NAME           => ''' ||
                       V_INDEXNAME || ''',
                                      PI_COLUMN_NAME_LIST     => :1,
                                      PI_COLUMN_LIST_FUNCTION => :2,
                                      PI_IDENTIFIER           => 0,
                                      PO_FLAG                 => :V_PO_FLAG);
               END;';

              EXECUTE IMMEDIATE v_sql
                using in v_col_name_list, V_INDEXED_COLUMNS_LIST, out V_PO_FLAG;

              IF V_PO_FLAG = 0 THEN
                RETURN;
              END IF;
            END IF;
          END IF;
        END;

        V_COL := SUBSTR(V_COL, 1, LENGTH(V_COL) - 1);

        V_DDL := ' CREATE ';

        -- Create DDL statements based on uniqueness

        IF PI_UNIQUENESS = 1 THEN
          --IF_5 START
          V_DDL := V_DDL || 'UNIQUE';
        END IF; --IF_5 END

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        <<CREATE_COMPOSITE_COLUMN_INDEX>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMN ' ||
                                                                PI_COLUMN_LIST(1) ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
          PO_CREATE_DDL   := V_DDL;
        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            --Get the index name for the given column list
            -- OF-30537 START
            -- PO_INDEX_NAME   := get_already_present_index_name(pi_table_name => V_TABLE_NAME, V_COL_COLUMN_LIST => V_COL);
            -- INSERT_LOGS('CREATE_INDEX2 GET_INDEX_DETAILS started 2');
            COMMONS_INDEXING.GET_INDEX_DETAILS(PI_TABLE_NAME   => PI_TABLE_NAME,
                                               PI_COL_LIST     => PI_COLUMN_LIST,
                                               PO_INDEX_NAME   => PO_INDEX_NAME,
                                               PO_INDEX_EXISTS => V_INDEX_EXISTS,
                                               PO_IS_UNIQUE    => PO_IS_UNIQUE);
            -- INSERT_LOGS('CREATE_INDEX2 GET_INDEX_DETAILS ended 2');
            --Get uniqueness property
            /* SELECT UNIQUENESS
             INTO PO_IS_UNIQUE
             FROM USER_INDEXES
            WHERE INDEX_NAME = PO_INDEX_NAME;*/
            -- OF-30537 END
            PO_INDEX_STATUS := 2;
            PO_CREATE_DDL   := V_DDL;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;
            PO_CREATE_DDL := V_DDL;
          WHEN E_MAXIMUM_KEY_LENGTH_EXCEEDED THEN
            PO_INDEX_STATUS := 4;
            --PO_CREATE_DDL := V_DDL;
        END;
      END IF;
    END IF;
    -- INSERT_LOGS('CREATE_INDEX2 ended');
  END CREATE_INDEX2;
  -- OF-30537 END

  FUNCTION GET_INDEX_TABLESPACE(PI_TABLES_ID IN NUMBER) RETURN VARCHAR2 IS
    V_INDEX_TABLESPACE VARCHAR2(30 CHAR);
  BEGIN
    IF LENGTH(USER) < 27 THEN
      SELECT USER ||
             DECODE(TABLES_TABLESPACE, 1, '_IND', 2, '_IND', 3, '_OUT')
        INTO V_INDEX_TABLESPACE
        FROM TABLES
       WHERE TABLES_ID = PI_TABLES_ID;
    END IF;
    RETURN V_INDEX_TABLESPACE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN null;
  END GET_INDEX_TABLESPACE;

  PROCEDURE ALTER_SESSION_NLS_BINARY IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''BINARY''';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''BINARY''';
  END ALTER_SESSION_NLS_BINARY;

  PROCEDURE ALTER_SESSION_PROJ_NLS_SETTING IS
    V_NLS_SORT VARCHAR2(160 CHAR);
    V_NLS_COMP VARCHAR2(160 CHAR);
  BEGIN
    SELECT NVL(MAX(VALUE), 'LINGUISTIC')
      INTO V_NLS_COMP
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_COMP';

    SELECT NVL(MAX(VALUE), 'BINARY_CI')
      INTO V_NLS_SORT
      FROM NLS_PARAMETERS
     WHERE PARAMETER = 'NLS_SORT';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP =''' || V_NLS_COMP || '''';

    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT =''' || V_NLS_SORT || '''';
  END ALTER_SESSION_PROJ_NLS_SETTING;

  PROCEDURE DISABLE_PRIMARY_KEY_CONS(PI_TABLE_NAME     IN VARCHAR2,
                                     PI_TRANSACTION_ID IN VARCHAR2,
                                     PI_RUN_ID         IN NUMBER DEFAULT NULL) IS
    V_DDL_QUERY      CLOB;
    V_UNDO_DDL_QUERY CLOB;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    V_DDL_QUERY      := 'ALTER TABLE ' || PI_TABLE_NAME ||
                        ' DISABLE PRIMARY KEY';
    V_UNDO_DDL_QUERY := 'ALTER TABLE ' || PI_TABLE_NAME ||
                        ' ENABLE  PRIMARY KEY';
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PI_TRANSACTION_ID,
                                     PI_DESCRIPTION    => 'Disable Primary key',
                                     PI_DDL            => V_DDL_QUERY,
                                     PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                     -- PI_INDEX           => NULL,   /*No OF-id, removed this parameter as per the latest DDL changes by Lucian: Dt: 7.Apr.2014 */
                                     PI_RUN_ID => PI_RUN_ID);
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END DISABLE_PRIMARY_KEY_CONS;

  PROCEDURE ENABLE_PRIMARY_KEY_CONS(PI_TABLE_NAME     IN VARCHAR2,
                                    PI_TRANSACTION_ID IN VARCHAR2,
                                    PI_RUN_ID         IN NUMBER DEFAULT NULL) IS
    V_DDL_QUERY      CLOB;
    V_UNDO_DDL_QUERY CLOB;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    V_DDL_QUERY      := 'ALTER TABLE ' || PI_TABLE_NAME ||
                        ' ENABLE PRIMARY KEY';
    V_UNDO_DDL_QUERY := 'ALTER TABLE ' || PI_TABLE_NAME ||
                        ' DISABLE PRIMARY KEY';
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PI_TRANSACTION_ID,
                                     PI_DESCRIPTION    => 'Enable Primary key',
                                     PI_DDL            => V_DDL_QUERY,
                                     PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                     -- PI_INDEX           => NULL,   /*No OF-id, removed this parameter as per the latest DDL changes by Lucian: Dt: 7.Apr.2014 */
                                     PI_RUN_ID => PI_RUN_ID);
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END ENABLE_PRIMARY_KEY_CONS;

  PROCEDURE DISABLE_NONUNIQUE_INDEXES(PI_TABLE_NAME     IN VARCHAR2,
                                      PI_TRANSACTION_ID IN VARCHAR2,
                                      PI_RUN_ID         IN NUMBER DEFAULT NULL) IS
    V_DDL_QUERY      CLOB;
    V_UNDO_DDL_QUERY CLOB;
    V_GET_INDEX_NAME COMMONS_INDEXING.TYPE_INDEX_NAME;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    ------MARK INDEXES AS UNUSABLE-------------------------
    -- GET INDEX NAMES
    SELECT INDEX_NAME
      BULK COLLECT
      INTO V_GET_INDEX_NAME
      FROM USER_INDEXES
     WHERE TABLE_NAME = PI_TABLE_NAME
       AND UNIQUENESS = 'NONUNIQUE';

    -- CALL TO EXECUTE DDL
    FOR C IN 1 .. V_GET_INDEX_NAME.COUNT LOOP
      V_DDL_QUERY      := 'ALTER INDEX ' || V_GET_INDEX_NAME(C) ||
                          ' UNUSABLE';
      V_UNDO_DDL_QUERY := 'ALTER INDEX ' || V_GET_INDEX_NAME(C) ||
                          ' REBUILD';
      COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PI_TRANSACTION_ID,
                                       PI_DESCRIPTION    => 'Disable NonUnique Index: ' ||
                                                            V_GET_INDEX_NAME(C),
                                       PI_DDL            => V_DDL_QUERY,
                                       PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                       -- PI_INDEX           => NULL,   /*No OF-id, removed this parameter as per the latest DDL changes by Lucian: Dt: 7.Apr.2014 */
                                       PI_RUN_ID => PI_RUN_ID);
    END LOOP;
    -- Alter Session to 'LINGUISTIC' and 'BINARY_CI'
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DISABLE_NONUNIQUE_INDEXES;

  PROCEDURE REBUILD_NONUNIQUE_INDEXES(PI_TABLE_NAME     IN VARCHAR2,
                                      PI_TRANSACTION_ID IN VARCHAR2,
                                      PI_RUN_ID         IN NUMBER DEFAULT NULL) IS
    V_DDL_QUERY      CLOB;
    V_UNDO_DDL_QUERY CLOB;
    V_GET_INDEX_NAME TYPE_INDEX_NAME;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    ------MARK INDEXES AS REBUILD-------------------------
    -- GET INDEX NAMES
    SELECT INDEX_NAME
      BULK COLLECT
      INTO V_GET_INDEX_NAME
      FROM USER_INDEXES
     WHERE TABLE_NAME = PI_TABLE_NAME
       AND UNIQUENESS = 'NONUNIQUE';

    -- CALL TO EXECUTE DDL
    FOR C IN 1 .. V_GET_INDEX_NAME.COUNT LOOP
      V_DDL_QUERY      := 'ALTER INDEX ' || V_GET_INDEX_NAME(C) ||
                          ' REBUILD';
      V_UNDO_DDL_QUERY := 'ALTER INDEX ' || V_GET_INDEX_NAME(C) ||
                          ' UNUSABLE';
      COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PI_TRANSACTION_ID,
                                       PI_DESCRIPTION    => 'Enable NonUnique Index: ' ||
                                                            V_GET_INDEX_NAME(C),
                                       PI_DDL            => V_DDL_QUERY,
                                       PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                       -- PI_INDEX           => NULL,   /*No OF-id, removed this parameter as per the latest DDL changes by Lucian: Dt: 7.Apr.2014 */
                                       PI_RUN_ID => PI_RUN_ID);
    END LOOP;
    -- Alter Session to 'LINGUISTIC' and 'BINARY_CI'
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END REBUILD_NONUNIQUE_INDEXES;

  FUNCTION GET_ALREADY_PRESENT_INDEX_NAME(pi_table_name IN VARCHAR2,
                                          pi_col_list   IN VARCHAR2)
    RETURN VARCHAR2 IS
    V_INDEX_NAME VARCHAR2(30);
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    WITH RESULT_1 AS
     (SELECT UIC.INDEX_NAME,
             UIC.COLUMN_POSITION,
             CASE
               WHEN T.COLUMN_EXPRESSION IS NOT NULL THEN
                T.COLUMN_EXPRESSION
               ELSE
                UIC.COLUMN_NAME
             END AS COLUMN_LIST
        FROM USER_IND_COLUMNS UIC
        FULL OUTER JOIN (SELECT EXTRACTVALUE(XS.OBJECT_VALUE,
                                            '/ROW/INDEX_NAME') AS INDEX_NAME,
                               EXTRACTVALUE(XS.OBJECT_VALUE,
                                            '/ROW/TABLE_NAME') AS TABLE_NAME,
                               EXTRACTVALUE(XS.OBJECT_VALUE,
                                            '/ROW/COLUMN_EXPRESSION') AS COLUMN_EXPRESSION,
                               EXTRACTVALUE(XS.OBJECT_VALUE,
                                            '/ROW/COLUMN_POSITION') AS COLUMN_POSITION
                          FROM (SELECT XMLTYPE.CREATEXML(DBMS_XMLGEN.GETXML('
                          SELECT * FROM USER_IND_EXPRESSIONS WHERE TABLE_NAME = ''' ||
                                                                            PI_TABLE_NAME || '''')) AS XML
                                  FROM DUAL) X,
                               TABLE(XMLSEQUENCE(EXTRACT(x.xml,
                                                         '/ROWSET/ROW'))) XS) T
          ON (T.INDEX_NAME = UIC.INDEX_NAME AND
             T.TABLE_NAME = UIC.TABLE_NAME AND
             T.COLUMN_POSITION = UIC.COLUMN_POSITION)
       WHERE UIC.TABLE_NAME = PI_TABLE_NAME),
    RESULT_2 AS
     (SELECT RESULT_1.INDEX_NAME,
             LISTAGG(RESULT_1.COLUMN_LIST, ',') WITHIN GROUP(ORDER BY RESULT_1.COLUMN_POSITION) COL_LIST
        FROM RESULT_1
       GROUP BY RESULT_1.INDEX_NAME)
    SELECT INDEX_NAME
      INTO V_INDEX_NAME
      FROM RESULT_2
     WHERE COL_LIST = pi_col_list;

    RETURN V_INDEX_NAME;
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END GET_ALREADY_PRESENT_INDEX_NAME;

  FUNCTION GET_COVERING_INDEX(PI_TABLE_NAME  IN VARCHAR2,
                              PI_COLUMN_LIST IN VARCHAR2) RETURN VARCHAR2 IS
    V_INDEX_NAME VARCHAR2(30);
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    WITH INDEXED_COLUMN_LIST AS
     (SELECT uic.INDEX_NAME,
             LISTAGG(CASE
                       WHEN t.column_expression IS NOT NULL THEN
                        SUBSTR(REGEXP_SUBSTR(t.column_expression, '"[^"]+'), 2)
                       ELSE
                        uic.COLUMN_NAME
                     END,
                     ',') WITHIN GROUP(ORDER BY uic.COLUMN_POSITION) AS COLUMN_LIST
        FROM user_ind_columns uic
        FULL OUTER JOIN (SELECT EXTRACTVALUE(xs.object_value,
                                            '/ROW/INDEX_NAME') AS INDEX_NAME,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/TABLE_NAME') AS TABLE_NAME,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/COLUMN_EXPRESSION') AS COLUMN_EXPRESSION,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/COLUMN_POSITION') AS COLUMN_POSITION
                          FROM (SELECT XMLTYPE.CREATEXML(DBMS_XMLGEN.GETXML('SELECT * FROM USER_IND_EXPRESSIONS WHERE TABLE_NAME = ''' ||
                                                                            PI_TABLE_NAME || '''')) AS xml
                                  FROM DUAL) x,
                               TABLE(XMLSEQUENCE(EXTRACT(x.xml,
                                                         '/ROWSET/ROW'))) xs) t
          ON t.index_name = uic.INDEX_NAME
         AND t.table_name = uic.TABLE_NAME
         AND t.column_position = uic.COLUMN_POSITION
       WHERE uic.table_name = PI_TABLE_NAME
       GROUP BY uic.INDEX_NAME)
    SELECT MIN(INDEX_NAME)
      INTO V_INDEX_NAME
      FROM INDEXED_COLUMN_LIST
     WHERE COLUMN_LIST LIKE PI_COLUMN_LIST
       AND ROWNUM < 2;

    RETURN V_INDEX_NAME;
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END GET_COVERING_INDEX;

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : GET_INDEX_DDLS_FROM_ORA_META
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : PI_INDEX_LIST
  * OUTPUT PARAMETERS : PO_INDEX_DDL
  * DESCRIPTION       : Get the DDLs of ALL the Indexes from Oracle Meta, which match the input Index List.
  * Example           :
  BEGIN
    COMMONS_INDEXING.GET_INDEX_DDLS_FROM_ORA_META(
      PI_INDEX_LIST => PI_INDEX_LIST,
      PO_INDEX_DDL  => PO_INDEX_DDL);
  END;

  Gets DDLs for All Indexes as per the input Index list.
  *********************************************************************************************************************/
  PROCEDURE GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST IN COMMONS_INDEXING.TYPE_CONSTRAINT_NAME,
                                   PO_INDEX_DDL  OUT COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE) IS
    V_INDEX_HANDLE NUMBER;
    V_TRANS_HANDLE NUMBER;

  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    FOR C IN 1 .. PI_INDEX_LIST.COUNT LOOP
      V_INDEX_HANDLE := NULL;
      V_TRANS_HANDLE := NULL;

      V_INDEX_HANDLE := DBMS_METADATA.OPEN('INDEX');
      DBMS_METADATA.SET_FILTER(V_INDEX_HANDLE, 'NAME', PI_INDEX_LIST(C));

      V_TRANS_HANDLE := DBMS_METADATA.ADD_TRANSFORM(V_INDEX_HANDLE, 'DDL');
      DBMS_METADATA.SET_TRANSFORM_PARAM(V_TRANS_HANDLE, 'TABLESPACE', TRUE);
      DBMS_METADATA.SET_TRANSFORM_PARAM(V_TRANS_HANDLE, 'STORAGE', FALSE);
      DBMS_METADATA.SET_TRANSFORM_PARAM(V_TRANS_HANDLE, 'PRETTY', FALSE);

      PO_INDEX_DDL(C).DDL_STMT := DBMS_METADATA.FETCH_CLOB(V_INDEX_HANDLE);

      DBMS_METADATA.CLOSE(V_INDEX_HANDLE);

      PO_INDEX_DDL(C).INDEX_NAME := PI_INDEX_LIST(C);
    END LOOP;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END GET_INDEX_DDLS_FOR_APP;

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : GET_INDEX_DDLS_FROM_ORA_META
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : PI_INDEX_LIST
  * OUTPUT PARAMETERS : PO_INDEX_DDL
  * DESCRIPTION       : Get the DDLs of ALL the Indexes from Oracle Meta, which match the input Index List.
  * Example           :
  BEGIN
    COMMONS_INDEXING.GET_INDEX_DDLS_FROM_ORA_META(
      PI_INDEX_LIST => PI_INDEX_LIST,
      PO_INDEX_DDL  => PO_INDEX_DDL);
  END;

  Gets DDLs for All Indexes as per the input Index list.
  *********************************************************************************************************************/
  PROCEDURE GET_INDEX_DDLS_FROM_ORA_META(PI_INDEX_LIST IN COMMONS_INDEXING.TYPE_CONSTRAINT_NAME,
                                         PO_INDEX_DDL  OUT COMMONS_INDEXING.TYPE_INDEX_DDL_INFO) IS
    V_INDEX_HANDLE NUMBER;
    V_TRANS_HANDLE NUMBER;
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    PO_INDEX_DDL := COMMONS_INDEXING.TYPE_INDEX_DDL_INFO();

    FOR C IN 1 .. PI_INDEX_LIST.COUNT LOOP
      PO_INDEX_DDL.EXTEND;
      V_INDEX_HANDLE := NULL;
      V_TRANS_HANDLE := NULL;

      V_INDEX_HANDLE := DBMS_METADATA.OPEN('INDEX');
      DBMS_METADATA.SET_FILTER(V_INDEX_HANDLE, 'NAME', PI_INDEX_LIST(C));

      V_TRANS_HANDLE := DBMS_METADATA.ADD_TRANSFORM(V_INDEX_HANDLE, 'DDL');
      DBMS_METADATA.SET_TRANSFORM_PARAM(V_TRANS_HANDLE, 'TABLESPACE', TRUE);
      DBMS_METADATA.SET_TRANSFORM_PARAM(V_TRANS_HANDLE, 'STORAGE', FALSE);
      DBMS_METADATA.SET_TRANSFORM_PARAM(V_TRANS_HANDLE, 'PRETTY', FALSE);

      PO_INDEX_DDL(C).DDL_STMT := DBMS_METADATA.FETCH_CLOB(V_INDEX_HANDLE);

      DBMS_METADATA.CLOSE(V_INDEX_HANDLE);

      PO_INDEX_DDL(C).INDEX_NAME := PI_INDEX_LIST(C);
    END LOOP;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END GET_INDEX_DDLS_FROM_ORA_META;

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : GET_INDEX_DDLS
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : PI_TABLE_NAME, PI_ONLY_UNIQUE (0 = ALL, i.e. Unique and Non-Unique Both; 1 = Only Unique)
  * OUTPUT PARAMETERS : PO_INDEX_INFO
  * DESCRIPTION       : Get the DDLs of ALL the Indexes, for a given table.
  * Example           :
  BEGIN
    GET_INDEX_DDLS(
      PI_TABLE_NAME  => PI_TABLE_NAME,
      PI_ONLY_UNIQUE => PI_ONLY_UNIQUE,
      PO_INDEX_INFO  => PO_INDEX_INFO);
  END;

  Gets DDLs for All Indexes for a given table..
  *********************************************************************************************************************/
  PROCEDURE GET_INDEX_DDLS(PI_TABLE_NAME      IN VARCHAR2,
                           PI_ONLY_UNIQUE     IN NUMBER,
                           PI_TABLESPACE_NAME IN VARCHAR2, /* 0 = ALL, i.e. Unique and Non-Unique Both; 1 = Only Unique */
                           PO_INDEX_INFO      OUT COMMONS_INDEXING.TYPE_INDEX_DDL_INFO) IS
    V_TABLE_NAME      VARCHAR2(30 CHAR) := UPPER(PI_TABLE_NAME);
    V_UNIQUENESS_UI   VARCHAR2(100 CHAR) := NULL;
    V_UNIQUENESS_AIDS VARCHAR2(100 CHAR) := NULL;
    V_TABLESPACE_LEN  NUMBER := LENGTH('TABLESPACE');

    V_INDEX_LIST          COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_INFO_ORA  COMMONS_INDEXING.TYPE_INDEX_DDL_INFO := COMMONS_INDEXING.TYPE_INDEX_DDL_INFO();
    V_OUT_INDEX_INFO_AIDS COMMONS_INDEXING.TYPE_INDEX_DDL_INFO := COMMONS_INDEXING.TYPE_INDEX_DDL_INFO();

  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- 1. Fetch DDLs for Indexes which are not Core/Feature  (i.e. Indexes not created through application like DBA Indexes, etc.)
    -- 1.a. GET INDEX NAMES (EXCEPT the PRIMARY and UNIQUE constraints)
    IF PI_ONLY_UNIQUE = 1 THEN
      V_UNIQUENESS_UI   := '  AND UNIQUENESS = ''UNIQUE''';
      V_UNIQUENESS_AIDS := '  AND AIDS.AIDS_INDEX_IS_UNIQUE = 1';
    END IF;

    EXECUTE IMMEDIATE '
    WITH
    I AS (
      SELECT /*+ materialize cardinality(ui 10) */
       INDEX_NAME II
        FROM USER_INDEXES ui
       WHERE  index_type<>''LOB'' and TABLE_NAME = ''' ||
                      V_TABLE_NAME || '''' || V_UNIQUENESS_UI || '),
    C AS (
      SELECT /*+ materialize cardinality(uc 2) */
       INDEX_NAME IC
        FROM USER_CONSTRAINTS uc
       WHERE TABLE_NAME = ''' || V_TABLE_NAME ||
                      ''' AND CONSTRAINT_TYPE IN (''P'',''U'')),
    D AS (
      SELECT /* +materialize cardinality(aids 10) */
       AIDS_INDEX_NAME ID
        FROM AIM_INDEX_DDL_STORAGE aids
       WHERE AIDS.AIDS_TABLE_NAME = ''' ||
                      V_TABLE_NAME || '''
         AND AIDS.AIDS_INDEX_IS_PRIMARY = 0 ' ||
                      V_UNIQUENESS_AIDS || ')

    SELECT II FROM I
    MINUS
    SELECT IC FROM C
    MINUS
    SELECT ID FROM D' BULK COLLECT
      INTO V_INDEX_LIST;

    -- 1.b. Call GET_INDEX_DDL for above indexes from Oracle.
    COMMONS_INDEXING.GET_INDEX_DDLS_FROM_ORA_META(PI_INDEX_LIST => V_INDEX_LIST,
                                                  PO_INDEX_DDL  => V_OUT_INDEX_INFO_ORA);

    -- 2. Fetch DDLs for Core and Feature Indexes (i.e. Indexes created through application)
    -- Since Table: AIM_INDEX_DDL_STORAGE does not contain any UNIQUE constraints, we'll filter out Primary Key and get the rest.
    -- Defect #16995 Fix
    -- Defect #17210 Fix
    EXECUTE IMMEDIATE '
    SELECT /* +materialize cardinality(aids 10) */
           TO_CLOB(SUBSTR(TO_CHAR(AIDS_INDEX_DDL), 1, INSTR(TO_CHAR(AIDS_INDEX_DDL), ''TABLESPACE'') + ' ||
                      V_TABLESPACE_LEN || ') || ''' || PI_TABLESPACE_NAME ||
                      '''),
           AIDS.AIDS_INDEX_NAME ID
      FROM AIM_INDEX_DDL_STORAGE AIDS
     WHERE AIDS.AIDS_TABLE_NAME = ''' || V_TABLE_NAME || '''
       AND AIDS.AIDS_INDEX_IS_PRIMARY = 0 ' ||
                      V_UNIQUENESS_AIDS BULK COLLECT
      INTO V_OUT_INDEX_INFO_AIDS;

    -- 3. Combine the above 2 DDLs collection into 1 and pass it as an output.
    PO_INDEX_INFO := V_OUT_INDEX_INFO_ORA MULTISET UNION
                     V_OUT_INDEX_INFO_AIDS;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END GET_INDEX_DDLS;

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DROP_ALL_UNIQUE_INDEXES
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_id, Transaction Id, Process Id (Optional), Run Id (Optional)
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Recreate ALL the Unique Indexes, previously Dropped in DISABLE_ALL_INDEXES flow.
  * Example           :
  BEGIN
    COMMONS_INDEXING.DROP_ALL_UNIQUE_INDEXES('T3126');
  END;

  Drops All Unique Indexes on table with table_name = 'T3126'.
  *********************************************************************************************************************/
  PROCEDURE DROP_ALL_UNIQUE_INDEXES(PI_TABLE_NAME       IN VARCHAR2,
                                    PI_TRANSACTION_ID   IN VARCHAR2,
                                    PI_PROCESS_ID       IN NUMBER DEFAULT NULL,
                                    PI_INDEX_TABLESPACE IN VARCHAR2,
                                    PI_RUN_ID           IN NUMBER DEFAULT NULL) IS
    V_DDL_DROP_INDEX         CLOB := NULL;
    V_DDL_CREATE_INDEX       CLOB := NULL;
    V_DDL_CREATE_INDEX_BLOCK CLOB := NULL;
    V_DDL_DROP_INDEX_BLOCK   CLOB := NULL;
    V_TABLE_NAME             VARCHAR2(30 CHAR) := UPPER(PI_TABLE_NAME);
    V_FLOW_IDENTIFIER        VARCHAR2(30 CHAR) := 'DROP_ALL_UNIQUE_INDEXES';

    V_INDEX_LIST     COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_INFO COMMONS_INDEXING.TYPE_INDEX_DDL_INFO;
    --Defect 13382 to take care of single quote in NLSSORT function applied to VARCHAR2 columns
    V_LENGTH                NUMBER;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- 1. GET INDEX DDLS -- UNIQUE -- UPDATED: 10.JUL.2013 (EXCEPT the PRIMARY and UNIQUE constraints).

    GET_INDEX_DDLS(PI_TABLE_NAME      => V_TABLE_NAME,
                   PI_ONLY_UNIQUE     => 1,
                   PI_TABLESPACE_NAME => PI_INDEX_TABLESPACE,
                   PO_INDEX_INFO      => V_OUT_INDEX_INFO);

    -- 2. Iterate through indexes fetched above.
    FOR C IN 1 .. V_OUT_INDEX_INFO.COUNT LOOP
      -- 2.a.i) Set the V_DDL_DROP_INDEX variable with the Drop Index DDL.
      V_DDL_DROP_INDEX := 'DROP INDEX ' || V_OUT_INDEX_INFO(C).INDEX_NAME;

      -- 2.a.ii) Set another CLOB variable with the execution block of Drop Index DDL.
      -- This would be passed as the PI_DDL parameter to the proc: COMMONS_DDL_HANDLING.EXECUTE_DDL.
      V_DDL_DROP_INDEX_BLOCK := TO_CLOB('
        BEGIN
          FOR D IN (SELECT 1 FROM DUAL WHERE EXISTS(
            SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = ''' || V_OUT_INDEX_INFO(C)
                                        .INDEX_NAME ||
                                        '''))
          LOOP
            EXECUTE IMMEDIATE ''') ||
                                V_DDL_DROP_INDEX || TO_CLOB(''';
          END LOOP;
        END;');

      -- 2.b.i) Set the V_DDL_CREATE_INDEX variable with the Create Index DDL in CLOB variable.
      V_DDL_CREATE_INDEX := V_OUT_INDEX_INFO(C).DDL_STMT;

      /* OF-5973 */
      -- Removed NLSSORT handling wrt QC Defect 13382
      -- 2.b.ii) DEFECT 13382 Resolution
      --Replace single quote with TWO single quotes
      SELECT REGEXP_REPLACE(V_DDL_CREATE_INDEX, '\''', '''''')
        INTO V_DDL_CREATE_INDEX
        FROM DUAL;

      -- 2.b.iii) DEFECT 13382 Resolution
      --Get the length of statement created
      SELECT LENGTH(V_DDL_CREATE_INDEX) INTO V_LENGTH FROM DUAL;

      -- 2.b.iv) DEFECT 13382 Resolution
      --Remove the extra single quote from START and END, as the start and end are also
      -- appended with extra single quote being clob statement
      SELECT SUBSTR(V_DDL_CREATE_INDEX, 2, V_LENGTH - 1)
        INTO V_DDL_CREATE_INDEX
        FROM DUAL;

      -- 2.b.v) Set another CLOB variable with the execution block of Create Index DDL.
      -- This would be passed as the PI_UNDO_DDL parameter to the proc: COMMONS_DDL_HANDLING.EXECUTE_DDL.

      V_DDL_CREATE_INDEX_BLOCK := TO_CLOB('
        BEGIN
          FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
            SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = ''' || V_OUT_INDEX_INFO(C)
                                          .INDEX_NAME ||
                                          '''))
          LOOP
            EXECUTE IMMEDIATE ''') ||
                                  V_DDL_CREATE_INDEX || TO_CLOB(''';
          END LOOP;
        END;');

      -- 2.c. Save the Create Index DDL for Recreating Indexes in Enable_All_Indexes flow.
      INSERT INTO INDEX_DDL_STORAGE
        (IDS_ID,
         IDS_TABLE_NAME,
         IDS_INDEX_NAME,
         IDS_DDL_CREATE_INDEX,
         IDS_DDL_DROP_INDEX,
         IDS_PROCESS_ID,
         IDS_RUN_ID,
         IDS_TRANSACTION_ID,
         IDS_FLOW_IDENTIFIER,
         IDS_CREATION_DATE)
      VALUES
        (INDEX_DDL_STORAGE_SEQ.NEXTVAL,
         V_TABLE_NAME,
         V_OUT_INDEX_INFO(C).INDEX_NAME,
         V_DDL_CREATE_INDEX_BLOCK,
         V_DDL_DROP_INDEX_BLOCK,
         PI_PROCESS_ID,
         PI_RUN_ID,
         NVL2((PI_PROCESS_ID || PI_RUN_ID), NULL, PI_TRANSACTION_ID),
         V_FLOW_IDENTIFIER,
         SYSTIMESTAMP);

      -- 2.e. Call Execute DDL to Drop Index.
      COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PI_TRANSACTION_ID,
                                       PI_DESCRIPTION    => 'DROP UNIQUE INDEX: ' || V_OUT_INDEX_INFO(C)
                                                           .INDEX_NAME ||
                                                            ' VIA DROP_ALL_UNIQUE_INDEXES FLOW',
                                       PI_DDL            => V_DDL_DROP_INDEX_BLOCK,
                                       PI_UNDO_DDL       => V_DDL_CREATE_INDEX_BLOCK,
                                       -- PI_INDEX          => NULL,   /*No OF-id, removed this parameter as per the latest DDL changes by Lucian: Dt: 7.Apr.2014 */
                                       PI_RUN_ID => PI_RUN_ID); -- Added RUN_ID parameter
    END LOOP;

    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
    COMMIT; -- FOR PRAGMA AUTONOMOUS_TRANSACTION
  END DROP_ALL_UNIQUE_INDEXES;

  /********************************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : RECREATE_ALL_DROPPED_INDEXES
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Tables_name, Transaction Id, Process Id (Optional), Run Id (Optional)
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Recreate ALL the Indexes previously Dropped.
  * Example           :
  BEGIN
    COMMONS_INDEXING.RECREATE_ALL_DROPPED_INDEXES(3126);
  END;

  Creates  T3126_BUSINESSKEY_UI on key fields
  *********************************************************************************************************************/
  /* FUNCTION RECREATE_ALL_DROPPED_INDEXES
    (
      PI_TABLE_NAME             IN VARCHAR2,
      PI_PROCESS_ID             IN NUMBER DEFAULT NULL,
      PI_RUN_ID                 IN NUMBER DEFAULT NULL,
      PI_TRANSACTION_ID         IN VARCHAR2 DEFAULT NULL,
      PI_PARENT_TRANSACTION_ID  IN VARCHAR2 DEFAULT NULL,
      PI_TABLES_ID IN NUMBER DEFAULT NULL
    )
    RETURN NUMBER
    IS
      V_TRANSACTION_ID   VARCHAR2(30 CHAR) := NULL;
      V_SQL              CLOB := '';
      V_COLUMN_LIST      TABLETYPE_CHARMAX;
      V_DDL_DESCRIPTION VARCHAR2(1300);
      V_PLSQL_CODE VARCHAR2(4000);

      V_IDS_DDL_CREATE_INDEX CLOB := '';
      V_IDS_DDL_DROP_INDEX CLOB := '';

      V_START_DATE DATE;
      V_IDX_PARALLEL_CREATION_FACTOR NUMBER;
      V_COUNTER NUMBER:= 0;
      V_BLOCK_BEGIN VARCHAR2(100 CHAR) := 'BEGIN NULL; ';
      V_BLOCK_END VARCHAR2(100 CHAR) :=  ' END;';
      V_IDENTIFIER VARCHAR2(50 CHAR) := NULL;

      V_JOB_TOTAL_COUNT NUMBER(10) := -1;
      V_JOB_SUCCESS_COUNT NUMBER(10) := -1;
      V_INDEXES_TOTAL_COUNT NUMBER(10) := 0;

      V_SQL_JOB_TOTAL_COUNT VARCHAR2(4000 CHAR) := NULL;
      V_SQL_JOB_SUCCESS_COUNT VARCHAR2(4000 CHAR) := NULL;

      V_STATUS NUMBER(1) := -1;
      V_TABLE_NAME VARCHAR2(11 CHAR) := 'T' || PI_TABLES_ID;

      PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
      -- INSERT_LOGS('RECREATE_ALL_DROPPED_INDEXES started');
      -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
      \* -- Testing -- Start
      V_SQL := '2 --  RECREATE_ALL_DROPPED_INDEXES START -- PI_TABLE_NAME = ' || PI_TABLE_NAME
        || ' -- PI_PROCESS_ID ' || PI_PROCESS_ID || ' -- PI_RUN_ID ' || PI_RUN_ID
        || ' -- PI_TRANSACTION_ID ' || PI_TRANSACTION_ID
        || ' -- COLUMNS';
       SELECT COLUMN_NAME BULK COLLECT
         INTO V_COLUMN_LIST
         FROM USER_TAB_COLUMNS
        WHERE TABLE_NAME = PI_TABLE_NAME;
        FOR I IN 1..V_COLUMN_LIST.COUNT LOOP
          V_SQL :=  V_SQL || '__' || I || '_'|| V_COLUMN_LIST(I);
        END LOOP;
        -- INSERT_LOGS(V_SQL);
      -- Testing -- End *\

      -- 1. Get the Transaction id
      \*    SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID
          INTO V_TRANSACTION_ID
          FROM DUAL;*\

      SELECT PR_VALUE INTO V_IDX_PARALLEL_CREATION_FACTOR FROM PROPERTIES WHERE PR_NAME = 'INDEX_CREATION_PARALLELISM_FACTOR';
      -- SELECT 'T' || TABLES_ID INTO V_TABLE_NAME FROM TABLES WHERE TABLES_PHYSICAL_NAME = PI_TABLE_NAME;
      -- INSERT_LOGS ('V_TABLE_NAME = ' || V_TABLE_NAME);
      -- Initializing the variables
      V_SQL      := V_BLOCK_BEGIN;
      V_COUNTER := 0;
      -- V_IDENTIFIER := V_TABLE_NAME || '_' || PI_RUN_ID;
      V_IDENTIFIER := V_TABLE_NAME; -- abhi_Sol
      -- 2. IDS_TRANSACTION_ID is NULL in the table: INDEX_DDL_STORAGE when IDS_PROCESS_ID and IDS_RUN_ID are NOT NULL.
      IF (PI_TRANSACTION_ID IS NOT NULL
       OR (PI_PROCESS_ID IS NOT NULL AND PI_RUN_ID IS NOT NULL))
      THEN -- IF_1
        -- 2.a. Iterate through table: INDEX_DDL_STORAGE for given PI_TABLE_NAME to recreate the Unique Indexes, previously Dropped.
        FOR C
          IN (SELECT IDS_ID, IDS_INDEX_NAME, -- IDS_DDL_CREATE_INDEX, IDS_DDL_DROP_INDEX,
           REGEXP_REPLACE(IDS_DDL_CREATE_INDEX, '\''', '''''') IDS_DDL_CREATE_INDEX,
           REGEXP_REPLACE(IDS_DDL_DROP_INDEX, '\''', '''''') IDS_DDL_DROP_INDEX,
           IDS_TRANSACTION_ID
                FROM INDEX_DDL_STORAGE
               WHERE IDS_TABLE_NAME = PI_TABLE_NAME
                 AND (NVL((PI_PROCESS_ID || PI_RUN_ID), NVL(PI_TRANSACTION_ID, '')) =
                        NVL2((PI_PROCESS_ID || PI_RUN_ID), (IDS_PROCESS_ID || IDS_RUN_ID), NVL(IDS_TRANSACTION_ID, ''))))
        LOOP
          -- INSERT_LOGS(PI_CLOB => ' --CREATE INDEX=>' ||C.IDS_DDL_CREATE_INDEX ||' --DROP INDEX=> '|| C.IDS_DDL_DROP_INDEX);
          -- 2.a.i) Call Execute DDL to Create Index.
          -- INSERT_LOGS(PI_CLOB => ' --C.IDS_DDL_CREATE_INDEX = ' ||C.IDS_DDL_CREATE_INDEX);
          -- INSERT_LOGS(PI_CLOB => ' --C.IDS_DDL_DROP_INDEX = ' ||C.IDS_DDL_DROP_INDEX);


          V_DDL_DESCRIPTION := 'RECREATE INDEX: ' || C.IDS_INDEX_NAME || ' VIA RECREATE_ALL_DROPPED_INDEXES FLOW';
          V_DDL_DESCRIPTION := 'ASYNC JOB FOR '|| V_DDL_DESCRIPTION;

          V_PLSQL_CODE := 'COMMONS_DDL_HANDLING.EXECUTE_DDL
          (
            PI_TRANSACTION_ID => ''' || PI_PARENT_TRANSACTION_ID || ''',
            PI_DESCRIPTION => ''' || V_DDL_DESCRIPTION || ''',
            PI_DDL      => ''' || C.IDS_DDL_CREATE_INDEX || ''',
            PI_UNDO_DDL => ''' || C.IDS_DDL_DROP_INDEX || ''',
            PI_RUN_ID   => ' || PI_RUN_ID || '
          );'; -- Added RUN_ID parameter

          -- INSERT_LOGS(PI_CLOB => ' --V_PLSQL_CODE = ' ||V_PLSQL_CODE);
          V_PLSQL_CODE := REGEXP_REPLACE(V_PLSQL_CODE, '\''', '''''');
          -- INSERT_LOGS(PI_CLOB => ' --V_PLSQL_CODE = ' ||V_PLSQL_CODE);
  --        V_START_DATE := SYSDATE+(1/24/60/60);
          V_SQL      := V_SQL || '
          BEGIN
            COMMONS_INDEXING.ASYNC_PLSQL_RUN(PI_PLSQL_CODE => ''' || V_PLSQL_CODE || ''', PI_IDENTIFIER => ''' || V_IDENTIFIER || ''', PI_COMMENT => ''' || V_DDL_DESCRIPTION || ''', PI_START_DATE => ''' || V_START_DATE || ''');
            -- 2.a.ii) Clear the table: INDEX_DDL_STORAGE after the Index is reapplied.
            DELETE FROM INDEX_DDL_STORAGE WHERE IDS_ID = ' || C.IDS_ID || ';
          END;';
          -- INSERT_LOGS('ASYNC_PLSQL_RUN added');

          V_COUNTER := V_COUNTER + 1;
          IF V_COUNTER = V_IDX_PARALLEL_CREATION_FACTOR THEN
            -- INSERT_LOGS('V_COUNTER = ' || V_COUNTER);
            V_SQL      := V_SQL || V_BLOCK_END;
            -- INSERT_LOGS('INTERMEDIATE JOB SUBMISSION: V_SQL = ' || V_SQL);
            EXECUTE IMMEDIATE V_SQL;
            -- INSERT_LOGS('JOB SUBMITTED');
            V_SQL      := V_BLOCK_BEGIN;
            V_COUNTER := 0;
          END IF;

          -- INSERT_LOGS('2 --  RECREATE_ALL_DROPPED_INDEXES START -- IDS_DDL_CREATE_INDEX = ' || C.IDS_DDL_CREATE_INDEX || ' -- IDS_DDL_DROP_INDEX ' || C.IDS_DDL_DROP_INDEX);
          V_INDEXES_TOTAL_COUNT := V_INDEXES_TOTAL_COUNT + 1;
        END LOOP;

        V_SQL      := V_SQL || V_BLOCK_END;
        -- INSERT_LOGS('FINAL JOB SUBMISSION: V_SQL = ' || V_SQL);
        EXECUTE IMMEDIATE V_SQL;
        -- INSERT_LOGS('JOB SUBMITTED -- FINAL -- RESIDUE');

      END IF; -- END IF_1

      -- INSERT_LOGS ('-- BEFORE -- V_JOB_TOTAL_COUNT = ' || V_JOB_TOTAL_COUNT || ' -- V_JOB_SUCCESS_COUNT = ' || V_JOB_SUCCESS_COUNT);

      V_SQL_JOB_TOTAL_COUNT := 'SELECT COUNT(*) FROM USER_SCHEDULER_JOB_RUN_DETAILS WHERE JOB_NAME LIKE ''ACIP_' || V_IDENTIFIER || '%''';
      V_SQL_JOB_SUCCESS_COUNT := V_SQL_JOB_TOTAL_COUNT || ' AND STATUS = ''SUCCEEDED''';

      -- INSERT_LOGS (' V_SQL_JOB_TOTAL_COUNT = ' || V_SQL_JOB_TOTAL_COUNT || ' -- V_SQL_JOB_SUCCESS_COUNT = ' || V_SQL_JOB_SUCCESS_COUNT);

      WHILE V_JOB_TOTAL_COUNT < V_INDEXES_TOTAL_COUNT LOOP
        EXECUTE IMMEDIATE V_SQL_JOB_TOTAL_COUNT INTO V_JOB_TOTAL_COUNT;
        EXECUTE IMMEDIATE V_SQL_JOB_SUCCESS_COUNT INTO V_JOB_SUCCESS_COUNT;
        -- INSERT_LOGS ('-- IN WHILE -- V_JOB_TOTAL_COUNT = ' || V_JOB_TOTAL_COUNT || ' -- V_JOB_SUCCESS_COUNT = ' || V_JOB_SUCCESS_COUNT);
      END LOOP;

      -- INSERT_LOGS ('-- AFTER -- V_JOB_TOTAL_COUNT = ' || V_JOB_TOTAL_COUNT || ' -- V_JOB_SUCCESS_COUNT = ' || V_JOB_SUCCESS_COUNT);

      IF V_JOB_TOTAL_COUNT = V_INDEXES_TOTAL_COUNT THEN
          -- INSERT_LOGS ('-- IF V_JOB_TOTAL_COUNT = V_INDEXES_TOTAL_COUNT THEN');
        IF V_JOB_SUCCESS_COUNT = V_INDEXES_TOTAL_COUNT THEN
          -- INSERT_LOGS ('-- IF V_JOB_SUCCESS_COUNT = V_INDEXES_TOTAL_COUNT THEN');
          V_STATUS := 1;
        ELSE
          -- INSERT_LOGS ('-- IF V_JOB_SUCCESS_COUNT = V_INDEXES_TOTAL_COUNT -- ELSE ');
          V_STATUS := 0;
        END IF;
      END IF;

      -- INSERT_LOGS ('V_STATUS = ' || V_STATUS);
      COMMIT;
      RETURN V_STATUS;

      -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
      -- INSERT_LOGS('RECREATE_ALL_DROPPED_INDEXES completed');
    END RECREATE_ALL_DROPPED_INDEXES;*/

  FUNCTION recreate_all_dropped_indexes(pi_table_name            IN VARCHAR2,
                                        pi_process_id            IN NUMBER DEFAULT NULL,
                                        pi_run_id                IN NUMBER DEFAULT NULL,
                                        pi_transaction_id        IN VARCHAR2 DEFAULT NULL,
                                        pi_parent_transaction_id IN VARCHAR2 DEFAULT NULL,
                                        pi_tables_id             IN NUMBER DEFAULT NULL)

   RETURN NUMBER IS

    v_parallel_created_count       NUMBER;
    v_last_count                   NUMBER;
    v_generic_id                   NUMBER;
    v_sql                          CLOB := '';
    v_plsql_code                   VARCHAR2(4000);
    v_idx_parallel_creation_factor NUMBER;
    v_individual_id                NUMBER := 1;
    v_ipc_id                       NUMBER;
    v_identifier                   VARCHAR2(30 CHAR) := NULL;
    v_table_name                   VARCHAR2(30 CHAR) := 'T' || pi_tables_id;
    v_ddl_description              VARCHAR2(1300);
    v_start_date                   DATE;
    v_SLEEP_TIME                   number;

    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    v_identifier := v_table_name;
    v_generic_id := index_parallel_creation_seq.nextval;

    SELECT pr_value
      INTO v_idx_parallel_creation_factor
      FROM properties
     WHERE pr_name = 'INDEX_CREATION_PARALLELISM_FACTOR';

    select nvl(max(pr_value), 0)
      into v_SLEEP_TIME
      from properties
     where pr_name = 'RECREATE_INDEXES_SLEEP_TIME';

    FOR v_index_ddl_storage IN (SELECT ids_id,
                                       ids_table_name,
                                       ids_index_name,
                                       regexp_replace(ids_ddl_create_index,
                                                      '\''',
                                                      '''''') ids_ddl_create_index,
                                       regexp_replace(ids_ddl_drop_index,
                                                      '\''',
                                                      '''''') ids_ddl_drop_index,
                                       ids_process_id,
                                       ids_run_id,
                                       ids_transaction_id,
                                       ids_flow_identifier,
                                       ids_creation_date
                                  FROM index_ddl_storage
                                 WHERE ids_table_name = pi_table_name
                                   AND (nvl((pi_process_id || pi_run_id),
                                            nvl(pi_transaction_id, '')) =
                                       nvl2((pi_process_id || pi_run_id),
                                             (ids_process_id || ids_run_id),
                                             nvl(ids_transaction_id, ''))))

     LOOP

      v_ddl_description := 'ASYNC JOB FOR RECREATE INDEX: ' ||
                           v_index_ddl_storage.ids_index_name ||
                           ' VIA RECREATE_ALL_DROPPED_INDEXES FLOW';
      v_ipc_id          := index_parallel_creation_seq.nextval;
      INSERT INTO index_parallel_creation
        (ipc_id,
         ipc_job_name,
         ipc_generic_id,
         ipc_create_sequence,
         ipc_status,
         ipc_reason_if_failed)
      VALUES
        (v_ipc_id,
         'ACIP_' || v_identifier,
         v_generic_id,
         v_individual_id,
         0,
         NULL);
      COMMIT;

      v_plsql_code := '
    begin

    COMMONS_DDL_HANDLING.EXECUTE_DDL
        (
          PI_TRANSACTION_ID => ''' ||
                      pi_parent_transaction_id || ''',
          PI_DESCRIPTION    => ''' ||
                      v_ddl_description || ''',
          PI_DDL            => ''' ||
                      v_index_ddl_storage.ids_ddl_create_index || ''',
          PI_UNDO_DDL       => ''' ||
                      v_index_ddl_storage.ids_ddl_drop_index || ''',
          PI_RUN_ID         => ' || pi_run_id || '
        );

    update index_parallel_creation set ipc_status = 1 where ipc_id =' ||
                      v_ipc_id || ';
            commit;
    exception
      when others then
    update index_parallel_creation set ipc_status = 2 where ipc_id =' ||
                      v_ipc_id || ';
       commit;
    end;';

      v_plsql_code := regexp_replace(v_plsql_code, '\''', '''''');
      v_sql        := NULL;

      v_sql := v_sql || '
       BEGIN
          COMMONS_INDEXING.ASYNC_PLSQL_RUN(PI_PLSQL_CODE => ''' ||
               v_plsql_code || ''',
                                           PI_IDENTIFIER => ''' ||
               v_identifier || ''',
                                           PI_COMMENT    => ''' ||
               v_ddl_description || ''',
                                           PI_START_DATE => ''' ||
               v_start_date || ''');
                 END;';

      /*  dbms_output.put_line('1 ' || v_sql);*/

      /* v_individual_id:=v_index_ddl_storage%ROWCOUNT;*/
      LOOP
        SELECT COUNT(*)
          INTO v_parallel_created_count
          FROM index_parallel_creation
         WHERE ipc_status = 0
           AND ipc_generic_id = v_generic_id;

        if v_parallel_created_count = v_idx_parallel_creation_factor then
          dbms_lock.sleep(v_SLEEP_TIME);
        elsIF v_parallel_created_count < v_idx_parallel_creation_factor THEN
          v_individual_id := v_individual_id + 1;

          begin
            EXECUTE IMMEDIATE v_sql;
          exception
            when others then
              null;
          end;
          /* dbms_output.put_line('v_parallel_created_count '||v_parallel_created_count ||'
          v_idx_parallel_creation_factor '||v_idx_parallel_creation_factor);*/

          /* dbms_output.put_line('2








          ' );*/

          EXIT;
        END IF;

      END LOOP;
      /*  IF (v_parallel_created_count = v_index_ddl_storage.count) THEN
        CONTINUE;
      ELSE
        dbms_lock.sleep(5);
      END IF;*/

    /* v_individual_id :=v_individual_id +1;*/

    END LOOP;

    LOOP
      SELECT COUNT(*)
        INTO v_last_count
        FROM index_parallel_creation
       WHERE ipc_generic_id = v_generic_id
         AND ipc_status = 0;

      IF v_last_count = 0 THEN

        /*dbms_output.put_line('index_parallel_creation count 0 exit ');*/
        EXIT;
      ELSE

        /* dbms_output.put_line (' dbms lock sleep '||sysdate);*/
        dbms_lock.sleep(v_SLEEP_TIME);
        /* dbms_output.put_line (' dbms lock sleep '||sysdate);*/
      END IF;
      --    EXIT WHEN(v_parallel_created_count <> 0);

    END LOOP;

    --add deltion here one final
    DELETE FROM index_ddl_storage
     WHERE ids_table_name = pi_table_name
       AND (nvl((pi_process_id || pi_run_id), nvl(pi_transaction_id, '')) =
           nvl2((pi_process_id || pi_run_id),
                 (ids_process_id || ids_run_id),
                 nvl(ids_transaction_id, '')));

    DELETE FROM index_parallel_creation
     WHERE ipc_generic_id = v_generic_id;
    COMMIT;
    RETURN 1;

  exception
    when others then
      return 0;
  END RECREATE_ALL_DROPPED_INDEXES;

  /*********************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : INSERT_APP_INDEXES_METADATA
    * AUTHOR            : Sagar Thorat
    * REVIEWER          : Abhishek Vijaywargiya
    * INPUT PARAMETERS  : Definition Id, Index Name, Tablename, List of columns to be indexed,
    *                     PI_RECREATE_INDEX_ON_COL_DROP --> Boolean Flag determining whether index should be dropped(1) on not(0) on structure change to table,
    *                     pi_BUSINESS_NAME --> Business Name, pi_is_unique--> boolean flag determining whether the index is unique(1) or not(0),
    *                     pi_index_type --> the type of index (whether it belongs to (1)core or (2)feature)
    * OUTPUT PARAMETERS : None
    * DESCRIPTION       : Inserts the metadata of the index created via application to APPLICATION_INDEXES_METADATA table.
    * Example           :

    BEGIN
    COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(pi_definition_id             => null,
                           pi_index_name                 => 'TEST_CASE_IDX',
                           pi_table_name                 => 'TEST_CASE',
                           pi_column_list                => COLTYPE_INDEXED_COLUMNS_LIST('COL1'),
                           PI_RECREATE_INDEX_ON_COL_DROP => 1,
                           pi_BUSINESS_NAME              => 'Test Case',
                           pi_is_unique                  => 0,
                           pi_index_type                 => 1);
    END;

    Inserts the metadata of index TEST_CASE_IDX of table TEST_CASE into APPLICATION_INDEXES_METADATA table.

  ********************************************************************************************************/
  PROCEDURE INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID              IN NUMBER,
                                        PI_INDEX_NAME                 IN VARCHAR2,
                                        PI_TABLE_NAME                 IN VARCHAR2,
                                        PI_COLUMN_LIST                IN COLTYPE_INDEXED_COLUMNS_LIST,
                                        PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                        PI_BUSINESS_NAME              IN VARCHAR2,
                                        PI_IS_UNIQUE                  IN NUMBER,
                                        PI_INDEX_TYPE                 IN NUMBER) IS
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA ');
    BEGIN
      INSERT INTO APPLICATION_INDEXES_METADATA
        (AIM_ID,
         AIM_DEF_ID,
         AIM_INDEX_NAME,
         AIM_TABLE_NAME,
         AIM_IS_INDEX_TO_BE_RECREATED,
         AIM_BUSINESS_NAME,
         AIM_INDEXED_COLUMNS,
         AIM_INDEX_IS_UNIQUE,
         AIM_INDEX_TYPE,
         AIM_IS_ENABLED,
         AIM_CREATION_DATE,
         AIM_LAST_UPDATE_DATE)
      VALUES
        (AIM_SEQ.NEXTVAL,
         PI_DEFINITION_ID,
         PI_INDEX_NAME,
         PI_TABLE_NAME,
         PI_RECREATE_INDEX_ON_COL_DROP,
         PI_BUSINESS_NAME,
         PI_COLUMN_LIST,
         PI_IS_UNIQUE,
         PI_INDEX_TYPE,
         1,
         SYSTIMESTAMP,
         SYSTIMESTAMP);
    exception
      when others then
        null;
    END;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END INSERT_APP_INDEXES_METADATA;

  PROCEDURE INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              IN NUMBER,
                                         PI_INDEX_NAME                 IN VARCHAR2,
                                         PI_TABLE_NAME                 IN VARCHAR2,
                                         PI_COLUMN_LIST                IN COLTYPE_INDEXED_COLUMNS_LIST,
                                         PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                         PI_BUSINESS_NAME              IN VARCHAR2,
                                         PI_IS_UNIQUE                  IN NUMBER,
                                         PI_INDEX_TYPE                 IN NUMBER,
                                         PI_INDEX_INSERT_DDL           IN CLOB,
                                         PI_IS_PRIMARY                 IN NUMBER DEFAULT NULL) IS
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- for logging - start
    -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIM - BEFORE -  PI_INDEX_NAME = ' || PI_INDEX_NAME);
    --          for c in (SELECT * FROM application_indexes_metadata aim where aim_table_name = PI_TABLE_NAME) loop
    --          null;
    --           -- INSERT_LOGS ('AIM.AIM_INDEX_NAME = ' || C.AIM_INDEX_NAME);
    --          end loop;
    -- for logging - end
    begin
      INSERT INTO APPLICATION_INDEXES_METADATA
        (AIM_ID,
         AIM_DEF_ID,
         AIM_INDEX_NAME,
         AIM_TABLE_NAME,
         AIM_IS_INDEX_TO_BE_RECREATED,
         AIM_BUSINESS_NAME,
         AIM_INDEXED_COLUMNS,
         AIM_INDEX_IS_UNIQUE,
         AIM_INDEX_TYPE,
         AIM_IS_ENABLED,
         AIM_CREATION_DATE,
         AIM_LAST_UPDATE_DATE)
      VALUES
        (AIM_SEQ.NEXTVAL,
         PI_DEFINITION_ID,
         PI_INDEX_NAME,
         PI_TABLE_NAME,
         PI_RECREATE_INDEX_ON_COL_DROP,
         PI_BUSINESS_NAME,
         PI_COLUMN_LIST,
         PI_IS_UNIQUE,
         PI_INDEX_TYPE,
         1,
         SYSTIMESTAMP,
         SYSTIMESTAMP);
      -- for logging - start
      -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIM - AFTER - PI_INDEX_NAME = ' || PI_INDEX_NAME);
      --                      for c in (SELECT * FROM application_indexes_metadata aim where aim_table_name = PI_TABLE_NAME) loop
      --                      null;
      --                      -- INSERT_LOGS ('AIM.AIM_INDEX_NAME = ' || C.AIM_INDEX_NAME);
      --                      end loop;
      -- for logging - end
    exception
      when others then
        null;

      -- for logging - start
      -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIM - EXCEPTION - PI_INDEX_NAME = ' || PI_INDEX_NAME);
      --                      for c in (SELECT * FROM application_indexes_metadata aim where aim_table_name = PI_TABLE_NAME) loop
      --                      null;
      --                      -- INSERT_LOGS ('AIM.AIM_INDEX_NAME = ' || C.AIM_INDEX_NAME);
      --                      end loop;
      -- for logging - end
    end;
    begin
      -- for logging - start
      -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIDS - BEFORE - PI_INDEX_NAME = ' || PI_INDEX_NAME);
      --                      for c in (SELECT * FROM AIM_INDEX_DDL_STORAGE aids where aids_table_name = PI_TABLE_NAME) loop
      --                      null;
      --                      -- INSERT_LOGS ('AIDS.AIDS_INDEX_NAME = ' || C.AIDS_INDEX_NAME);
      --                      end loop;
      -- for logging - end
      INSERT INTO AIM_INDEX_DDL_STORAGE
        (AIDS_TABLE_NAME,
         AIDS_INDEX_NAME,
         AIDS_INDEX_IS_UNIQUE,
         AIDS_INDEX_IS_PRIMARY,
         AIDS_INDEX_DDL)
      VALUES
        (PI_TABLE_NAME,
         PI_INDEX_NAME,
         PI_IS_UNIQUE,
         DECODE(PI_IS_PRIMARY, NULL, 0, PI_IS_PRIMARY),
         PI_INDEX_INSERT_DDL);
      -- for logging - start
      -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIDS - AFTER - PI_INDEX_NAME = ' || PI_INDEX_NAME);
      --                      for c in (SELECT * FROM AIM_INDEX_DDL_STORAGE aids where aids_table_name = PI_TABLE_NAME) loop
      --                      null;
      --                      -- INSERT_LOGS ('AIDS.AIDS_INDEX_NAME = ' || C.AIDS_INDEX_NAME);
      --                      end loop;
      -- for logging - end
    exception
      when others then
        null;

      -- for logging - start
      -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIDS - EXCEPTION - PI_INDEX_NAME = ' || PI_INDEX_NAME);
      --                      for c in (SELECT * FROM AIM_INDEX_DDL_STORAGE aids where aids_table_name = PI_TABLE_NAME) loop
      --                      null;
      --                      -- INSERT_LOGS ('AIDS.AIDS_INDEX_NAME = ' || C.AIDS_INDEX_NAME);
      --                      end loop;
      -- for logging - end
    end;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
    -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA1 - AIM AND AIDS - END - PI_INDEX_NAME = ' || PI_INDEX_NAME);
  END INSERT_APP_INDEXES_METADATA1;

  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DELETE_AIM
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : TABLE_NAME, INDEX_NAME, DEFINITION_ID, BUSINESS_NAME, AIM_ID
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Deletes rows from the Indexes Metadata Table as per the parameters passed.
  *                     - The parameters are OPTIONAL and following comnbinations are possible:
  *                     --  1. ONLY TABLE_NAME --> Deletes ALL Rows for given Table
  *                     --  2. ONLY INDEX_NAME --> Deletes ALL Rows for given Index and its dependent Indexes
  *                     --  3. DEFINITION_ID and BUSINESS_NAME --> Deletes 1 Row for DEFINITION_ID and BUSINESS_NAME
  * Example           :
  BEGIN
  -- Pass only the "Table_Name" parameter to delete the metadata for ALL the Indexes for the given table.
  DELETE_AIM(
    PI_TABLE_NAME    => PI_TABLE_NAME,
    PI_INDEX_NAME    => NULL,
    PI_DEFINITION_ID => NULL,
    PI_BUSINESS_NAME => NULL,
    PI_AIM_ID        => NULL);

  -- Pass only the "Index_Name" parameter to delete the metadata for the Indexes for the given Index,
  -- those Indexes which depend on this Index.
  DELETE_AIM(
    PI_TABLE_NAME    => NULL,
    PI_INDEX_NAME    => PI_INDEX_NAME,
    PI_DEFINITION_ID => NULL,
    PI_BUSINESS_NAME => NULL,
    PI_AIM_ID        => NULL);

  -- Pass only the "Defintion_Id" and "BUSINESS_NAME" parameters to delete the metadata for the Index,
  -- which matches as per the given Defintion Id and the Business Name.
  DELETE_AIM(
    PI_TABLE_NAME    => NULL,
    PI_INDEX_NAME    => NULL,
    PI_DEFINITION_ID => PI_DEFINITION_ID,
    PI_BUSINESS_NAME => PI_BUSINESS_NAME,
    PI_AIM_ID        => NULL);
  END;

  **********************************************************************************************************/
  PROCEDURE DELETE_AIM(PI_TABLE_NAME    IN VARCHAR2,
                       PI_INDEX_NAME    IN VARCHAR2,
                       PI_DEFINITION_ID IN NUMBER,
                       PI_BUSINESS_NAME IN VARCHAR2,
                       PI_AIM_ID        IN NUMBER) IS
    V_SQL VARCHAR2(1300 CHAR);
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    SELECT '
   DELETE FROM AIM_INDEX_DDL_STORAGE
    WHERE (AIDS_TABLE_NAME,AIDS_INDEX_NAME) in
          (SELECT AIM.AIM_TABLE_NAME,AIM.AIM_INDEX_NAME FROM APPLICATION_INDEXES_METADATA AIM WHERE 1 = 1' ||
           DECODE(PI_TABLE_NAME,
                  NULL,
                  '',
                  ' AND AIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''') ||
           DECODE(PI_INDEX_NAME,
                  NULL,
                  '',
                  ' AND AIM_INDEX_NAME = ''' || PI_INDEX_NAME || '''') ||
           DECODE(PI_DEFINITION_ID,
                  NULL,
                  '',
                  ' AND AIM_DEF_ID = ''' || PI_DEFINITION_ID || '''') ||
           DECODE(PI_BUSINESS_NAME,
                  NULL,
                  '',
                  ' AND AIM_BUSINESS_NAME = ''' || PI_BUSINESS_NAME || '''') ||
           DECODE(PI_AIM_ID,
                  NULL,
                  '',
                  ' AND AIM_ID = ''' || PI_AIM_ID || '''') || ')'
      INTO V_SQL
      FROM DUAL;

    -- INSERT_LOGS('-- DELETE_AIM - AIM_INDEX_DDL_STORAGE - V_SQL = ' || V_SQL);

    EXECUTE IMMEDIATE V_SQL;

    SELECT '
      DELETE FROM APPLICATION_INDEXES_METADATA
      WHERE 1 = 1' ||
           DECODE(PI_TABLE_NAME,
                  NULL,
                  '',
                  ' AND AIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''') ||
           DECODE(PI_INDEX_NAME,
                  NULL,
                  '',
                  ' AND AIM_INDEX_NAME = ''' || PI_INDEX_NAME || '''') ||
           DECODE(PI_DEFINITION_ID,
                  NULL,
                  '',
                  ' AND AIM_DEF_ID = ''' || PI_DEFINITION_ID || '''') ||
           DECODE(PI_BUSINESS_NAME,
                  NULL,
                  '',
                  ' AND AIM_BUSINESS_NAME = ''' || PI_BUSINESS_NAME || '''') ||
           DECODE(PI_AIM_ID,
                  NULL,
                  '',
                  ' AND AIM_ID = ''' || PI_AIM_ID || '''')
      INTO V_SQL
      FROM DUAL;

    -- INSERT_LOGS('-- DELETE_AIM - APPLICATION_INDEXES_METADATA - V_SQL = ' || V_SQL);

    EXECUTE IMMEDIATE V_SQL;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END DELETE_AIM;

  PROCEDURE DELETE_AIM1(PI_TABLE_NAME    IN VARCHAR2,
                        PI_INDEX_NAME    IN VARCHAR2,
                        PI_DEFINITION_ID IN NUMBER,
                        PI_BUSINESS_NAME IN VARCHAR2,
                        PI_AIM_ID        IN NUMBER) IS
    V_SQL VARCHAR2(1300 CHAR);
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    SELECT '
      DELETE FROM APPLICATION_INDEXES_METADATA
      WHERE 1 = 1' ||
           DECODE(PI_TABLE_NAME,
                  NULL,
                  '',
                  ' AND AIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''') ||
           DECODE(PI_INDEX_NAME,
                  NULL,
                  '',
                  ' AND AIM_INDEX_NAME = ''' || PI_INDEX_NAME || '''') ||
           DECODE(PI_DEFINITION_ID,
                  NULL,
                  '',
                  ' AND AIM_DEF_ID = ''' || PI_DEFINITION_ID || '''') ||
           DECODE(PI_BUSINESS_NAME,
                  NULL,
                  '',
                  ' AND AIM_BUSINESS_NAME = ''' || PI_BUSINESS_NAME || '''') ||
           DECODE(PI_AIM_ID,
                  NULL,
                  '',
                  ' AND AIM_ID = ''' || PI_AIM_ID || '''')
      INTO V_SQL
      FROM DUAL;

    EXECUTE IMMEDIATE V_SQL;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DELETE_AIM1;

  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DELETE_AIM_BY_TABLE
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : TABLE_NAME
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Deletes rows from the Indexes Metadata Table for given Table.
  * Example           :
  BEGIN
    DELETE_AIM_BY_TABLE(PI_TABLE_NAME => PI_TABLE_NAME);
  END;

  **********************************************************************************************************/
  PROCEDURE DELETE_AIM_BY_TABLE(PI_TABLE_NAME IN VARCHAR2) IS
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Pass only the "Table_Name" parameter to delete the metadata for ALL the Indexes for the given table.
    DELETE_AIM(PI_TABLE_NAME    => PI_TABLE_NAME,
               PI_INDEX_NAME    => NULL,
               PI_DEFINITION_ID => NULL,
               PI_BUSINESS_NAME => NULL,
               PI_AIM_ID        => NULL);
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DELETE_AIM_BY_TABLE;

  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DELETE_AIM_BY_INDEX
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : INDEX_NAME
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Deletes rows from the Indexes Metadata Table for given Index and its dependent Indexes.
  * Example           :
  BEGIN
    DELETE_AIM_BY_INDEX(PI_INDEX_NAME => PI_INDEX_NAME);
  END;

  **********************************************************************************************************/
  PROCEDURE DELETE_AIM_BY_INDEX(PI_INDEX_NAME IN VARCHAR2) IS
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Pass only the "Index_Name" parameter to delete the metadata for the given Index and,
    -- other Indexes that depend on this Index.
    DELETE_AIM(PI_TABLE_NAME    => NULL,
               PI_INDEX_NAME    => PI_INDEX_NAME,
               PI_DEFINITION_ID => NULL,
               PI_BUSINESS_NAME => NULL,
               PI_AIM_ID        => NULL);
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DELETE_AIM_BY_INDEX;

  /*********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : DELETE_AIM_BY_DEFID_AND_BNAME
  * AUTHOR            : Abhishek Vijaywargiya
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : DEFINITION_ID, BUSINESS_NAME
  * OUTPUT PARAMETERS : None
  * DESCRIPTION       : Deletes 1 Row from the Indexes Metadata Table for DEFINITION_ID and BUSINESS_NAME.
  * Example           :
  BEGIN
    DELETE_AIM_BY_DEFID_AND_BNAME(
      PI_DEFINITION_ID => PI_DEFINITION_ID,
      PI_BUSINESS_NAME => PI_BUSINESS_NAME);
  END;

  **********************************************************************************************************/
  PROCEDURE DELETE_AIM_BY_DEFID_AND_BNAME(PI_TABLE_NAME    IN VARCHAR2,
                                          PI_DEFINITION_ID IN NUMBER,
                                          PI_BUSINESS_NAME IN VARCHAR2) IS
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Pass only the "Defintion_Id" and "Business_Name" parameters to delete the metadata for the Index,
    -- which matches as per the given Defintion Id and the Business Name.
    DELETE_AIM(PI_TABLE_NAME    => PI_TABLE_NAME,
               PI_INDEX_NAME    => NULL,
               PI_DEFINITION_ID => PI_DEFINITION_ID,
               PI_BUSINESS_NAME => PI_BUSINESS_NAME,
               PI_AIM_ID        => NULL);
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END DELETE_AIM_BY_DEFID_AND_BNAME;

  /* ********************************************************************************************************
  * TYPE              : PROCEDURE
  * PROCEDURE NAME    : CREATE_INDEX
  * AUTHOR            : Sagar Thorat
  * REVIEWER          : Pooja Sharma
  * INPUT PARAMETERS  : Table name, index name ,comma separated column list, uniqueness characteristic,
  *                     type (normal or composite), primary key constraint, initrans, tablespace for index, nls sort function value
  * OUTPUT PARAMETERS : po_indexing_info
  * DESCRIPTION       : Creates index (unique/non-unique/composite/primary key indexes)
  * Example           :

    BEGIN

    COMMONS_INDEXING.CREATE_INDEX(PI_TABLE_NAME         => 'T3126',
                    PI_INDEX_NAME         => 'T3126' || '_BUSINESSKEY_UI',
                    pi_col_list          => 'E2787,F2631,E2794,E2800,F2634,F2635,F7777',
                    pi_uniqueness        => 1,
                    pi_composite         => 1,
                    pi_col_is_primarykey => 0,
                    pi_initrans          => 'INITRANS 5',
                    pi_index_tablespace  => 'SAGAR_SPM_LATEST_IND',
                    pi_nls_sort          => 'BINARY_CI',
                    po_indexing_info     => v_out);
    END;

    Creates unique composite index T3126_BUSINESSKEY_UI on table T3126 for columns
    E2787,F2631,E2794,E2800,F2634,F2635,F7777 with UPPER function applied to the VARCHAR columns.
  **********************************************************************************************************/
  PROCEDURE CREATE_INDEX(PI_TABLE_NAME        IN VARCHAR2,
                         PI_INDEX_NAME        IN VARCHAR2,
                         PI_COLUMN_LIST       IN SYS.HSBLKNAMLST,
                         PI_UNIQUENESS        IN NUMBER,
                         PI_COL_IS_PRIMARYKEY IN NUMBER,
                         PI_INITRANS          IN NUMBER DEFAULT 5,
                         PI_INDEX_TABLESPACE  IN VARCHAR2,
                         PI_RUN_ID            IN NUMBER DEFAULT NULL,
                         PI_TRANSACTION_ID    IN VARCHAR2,
                         PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded, 5 - Invalid Identifier
                         PO_INDEX_NAME        OUT VARCHAR2,
                         PO_IS_UNIQUE         OUT VARCHAR2) IS
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    V_COL            VARCHAR2(1300 CHAR);
    V_DDL            CLOB;
    V_UNDO_DDL       CLOB;
    V_INDEXNAME      VARCHAR2(30) := UPPER(PI_INDEX_NAME);
    V_TABLE_NAME     VARCHAR2(30) := UPPER(PI_TABLE_NAME); /* OF-5973 */
    V_DATA_TYPE      VARCHAR2(106);
    V_NLS_SORT       VARCHAR2(160 CHAR);
    V_INDEX_EXISTS   NUMBER;
    E_MAXIMUM_KEY_LENGTH_EXCEEDED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_MAXIMUM_KEY_LENGTH_EXCEEDED, -1450);

    E_PRIMARY_KEY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_PRIMARY_KEY_EXISTS, -2260);

    E_NAME_ALREADY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_NAME_ALREADY_EXISTS, -955);

    E_COLUMN_LIST_ALREADY_INDEXED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_COLUMN_LIST_ALREADY_INDEXED, -1408);
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    IF PI_COLUMN_LIST IS NOT NULL THEN
      -- Get the transaction id
      --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

      -- Create primary key constraint and index
      IF (PI_COL_IS_PRIMARYKEY = 1) THEN
        -- IF_1 START

        -- Create Primary Key on the table
        V_DDL := ' ALTER TABLE ' || V_TABLE_NAME || ' ADD CONSTRAINT ' ||
                 V_INDEXNAME || ' PRIMARY KEY (' || PI_COLUMN_LIST(1) ||
                 ') USING INDEX  INITRANS ' || PI_INITRANS ||
                 ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        V_UNDO_DDL := '
            BEGIN
              FOR C IN (
                  SELECT NULL
                  FROM USER_CONSTRAINTS UC
                  WHERE UC.TABLE_NAME = ''' ||
                      V_TABLE_NAME || '''
                    AND UC.CONSTRAINT_TYPE = ''P''
                    AND (UC.CONSTRAINT_NAME = ''' ||
                      V_INDEXNAME ||
                      '''))
              LOOP
                EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                      V_TABLE_NAME || ' DROP PRIMARY KEY DROP INDEX'';
              END LOOP;
            END;';

        -- Create the primary key index, only if v_count is increased to 1 from the above loop code
        <<CREATE_PRIMARY_KEY>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATES PRIMARY KEY CONSTRAINT AND INDEX ON TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          --If Primary key creation is done set v_primary_key_existence to 1
          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
        EXCEPTION
          WHEN E_PRIMARY_KEY_EXISTS THEN
            -- Return the index and constraint name
            SELECT CONSTRAINT_NAME
              INTO PO_INDEX_NAME
              FROM USER_CONSTRAINTS
             WHERE CONSTRAINT_TYPE = 'P'
               AND TABLE_NAME = V_TABLE_NAME;

            PO_INDEX_STATUS := 2;
        END;
        --Single column index
      ELSIF PI_COLUMN_LIST.COUNT = 1 THEN
        --Check the data type of the column
        SELECT DATA_TYPE
          INTO V_DATA_TYPE
          FROM USER_TAB_COLUMNS
         WHERE TABLE_NAME = V_TABLE_NAME /* OF-5973 */
           AND COLUMN_NAME = UPPER(PI_COLUMN_LIST(1));

        --if data type is VARCHAR2
        IF V_DATA_TYPE = 'VARCHAR2' THEN
          --IF_4 START
          -- /* OF-5973 */ APPLY UPPER function
          V_COL := 'UPPER("' || PI_COLUMN_LIST(1) || '")';
          --ELSE it is non-varchar column
        ELSE
          V_COL := PI_COLUMN_LIST(1);
        END IF; -- IF_4 END

        V_DDL := 'CREATE ';

        -- Create DDL statements based on uniqueness

        IF PI_UNIQUENESS = 1 THEN
          --IF_5 START
          V_DDL := V_DDL || 'UNIQUE';
        END IF; --IF_5 END

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        -- Execute the Create DDl through COMMONS DDL Handling service
        <<CREATE_SINGLE_COLUMN_INDEX>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMN ' ||
                                                                PI_COLUMN_LIST(1) ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            --Get the index name for the given column
            -- OF-30537 START
            -- PO_INDEX_NAME   := get_already_present_index_name(pi_table_name => V_TABLE_NAME, pi_col_list => TO_CHAR(V_COL));
            COMMONS_INDEXING.GET_INDEX_DETAILS(PI_TABLE_NAME   => PI_TABLE_NAME,
                                               PI_COL_LIST     => PI_COLUMN_LIST,
                                               PO_INDEX_NAME   => PO_INDEX_NAME,
                                               PO_INDEX_EXISTS => V_INDEX_EXISTS,
                                               PO_IS_UNIQUE    => PO_IS_UNIQUE);

            --Get uniqueness property
            /*SELECT UNIQUENESS
             INTO PO_IS_UNIQUE
             FROM USER_INDEXES
            WHERE INDEX_NAME = PO_INDEX_NAME;*/
            -- OF-30537 END
            PO_INDEX_STATUS := 2;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;

        END;
        --Multi columns to be indexed
      ELSIF PI_COLUMN_LIST.COUNT > 1 THEN
        FOR C IN 1 .. PI_COLUMN_LIST.COUNT LOOP
          --Check the data type of the column
          SELECT DATA_TYPE
            INTO V_DATA_TYPE
            FROM USER_TAB_COLUMNS
           WHERE TABLE_NAME = V_TABLE_NAME /* OF-5973 */
             AND COLUMN_NAME = UPPER(PI_COLUMN_LIST(C));

          --if data type is VARCHAR2
          IF V_DATA_TYPE = 'VARCHAR2' THEN
            --IF_4 START
            -- /* OF-5973 */ APPLY UPPER function
            V_COL := V_COL || 'UPPER("' || PI_COLUMN_LIST(C) || '")';
            --ELSE it is non-varchar column
          ELSE
            V_COL := V_COL || PI_COLUMN_LIST(C);
          END IF; -- IF_4 END

          V_COL := V_COL || ',';
        END LOOP;

        V_COL := SUBSTR(V_COL, 1, LENGTH(V_COL) - 1);

        V_DDL := 'CREATE ';

        -- Create DDL statements based on uniqueness

        IF PI_UNIQUENESS = 1 THEN
          --IF_5 START
          V_DDL := V_DDL || 'UNIQUE';
        END IF; --IF_5 END

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        <<CREATE_COMPOSITE_COLUMN_INDEX>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMN ' ||
                                                                PI_COLUMN_LIST(1) ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            --Get the index name for the given column list
            -- OF-30537 START
            -- PO_INDEX_NAME   := get_already_present_index_name(pi_table_name => V_TABLE_NAME, pi_col_list => V_COL);
            COMMONS_INDEXING.GET_INDEX_DETAILS(PI_TABLE_NAME   => PI_TABLE_NAME,
                                               PI_COL_LIST     => PI_COLUMN_LIST,
                                               PO_INDEX_NAME   => PO_INDEX_NAME,
                                               PO_INDEX_EXISTS => V_INDEX_EXISTS,
                                               PO_IS_UNIQUE    => PO_IS_UNIQUE);

            --Get uniqueness property
            /* SELECT UNIQUENESS
             INTO PO_IS_UNIQUE
             FROM USER_INDEXES
            WHERE INDEX_NAME = PO_INDEX_NAME;*/
            -- OF-30537 END
            PO_INDEX_STATUS := 2;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;

          WHEN E_MAXIMUM_KEY_LENGTH_EXCEEDED THEN
            PO_INDEX_STATUS := 4;
        END;
      END IF;
    END IF;
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END CREATE_INDEX;

  PROCEDURE CREATE_INDEX1(PI_TABLE_NAME        IN VARCHAR2,
                          PI_INDEX_NAME        IN VARCHAR2,
                          PI_COL_LIST          IN SYS.HSBLKNAMLST,
                          PI_UNIQUENESS        IN NUMBER,
                          PI_COL_IS_PRIMARYKEY IN NUMBER,
                          PI_INITRANS          IN NUMBER DEFAULT 5,
                          PI_INDEX_TABLESPACE  IN VARCHAR2, /*OF-11821*/
                          PI_RUN_ID            IN NUMBER DEFAULT NULL,
                          PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded, 5 - Invalid Identifier
                          PO_INDEX_NAME        OUT VARCHAR2,
                          PO_IS_UNIQUE         OUT VARCHAR2,
                          PO_CREATE_DDL        OUT CLOB) IS
    V_TRANSACTION_ID VARCHAR2(30 CHAR);
    V_COL            VARCHAR2(1300 CHAR);
    V_DDL            CLOB;
    V_UNDO_DDL       CLOB;
    V_INDEXNAME      VARCHAR2(30) := UPPER(PI_INDEX_NAME);
    V_TABLE_NAME     VARCHAR2(30) := UPPER(PI_TABLE_NAME);
    V_DATA_TYPE      VARCHAR2(106);
    V_NLS_SORT       VARCHAR2(160 CHAR);

    E_MAXIMUM_KEY_LENGTH_EXCEEDED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_MAXIMUM_KEY_LENGTH_EXCEEDED, -1450);

    E_PRIMARY_KEY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_PRIMARY_KEY_EXISTS, -2260);

    E_NAME_ALREADY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_NAME_ALREADY_EXISTS, -955);

    E_COLUMN_LIST_ALREADY_INDEXED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_COLUMN_LIST_ALREADY_INDEXED, -1408);
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    IF PI_COL_LIST IS NOT NULL THEN
      -- Get the transaction id
      V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

      -- Create primary key constraint and index
      IF (PI_COL_IS_PRIMARYKEY = 1) THEN
        -- IF_1 START

        -- Create Primary Key on the table
        V_DDL := ' ALTER TABLE ' || V_TABLE_NAME || ' ADD CONSTRAINT ' ||
                 V_INDEXNAME || ' PRIMARY KEY (' || PI_COL_LIST(1) ||
                 ') USING INDEX  INITRANS ' || PI_INITRANS ||
                 ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        V_UNDO_DDL := '
            BEGIN
              FOR C IN (
                  SELECT NULL
                  FROM USER_CONSTRAINTS UC
                  WHERE UC.TABLE_NAME = ''' ||
                      V_TABLE_NAME || '''
                    AND UC.CONSTRAINT_TYPE = ''P''
                    AND (UC.CONSTRAINT_NAME = ''' ||
                      V_INDEXNAME ||
                      '''))
              LOOP
                EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                      V_TABLE_NAME || ' DROP PRIMARY KEY DROP INDEX'';
              END LOOP;
            END;';

        -- Create the primary key index, only if v_count is increased to 1 from the above loop code
        <<CREATE_PRIMARY_KEY>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATES PRIMARY KEY CONSTRAINT AND INDEX ON TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          --If Primary key creation is done set v_primary_key_existence to 1
          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_CREATE_DDL   := V_DDL;
        EXCEPTION
          WHEN E_PRIMARY_KEY_EXISTS THEN
            -- Return the index and constraint name
            SELECT CONSTRAINT_NAME
              INTO PO_INDEX_NAME
              FROM USER_CONSTRAINTS
             WHERE CONSTRAINT_TYPE = 'P'
               AND TABLE_NAME = V_TABLE_NAME;

            PO_INDEX_STATUS := 2;
            PO_CREATE_DDL   := V_DDL;
        END;
        --Single column index
      ELSIF PI_COL_LIST.COUNT = 1 THEN
        --Check the data type of the column
        SELECT DATA_TYPE
          INTO V_DATA_TYPE
          FROM USER_TAB_COLUMNS
         WHERE TABLE_NAME = V_TABLE_NAME /* OF-5973 */
           AND COLUMN_NAME = UPPER(PI_COL_LIST(1));

        --if data type is VARCHAR2
        IF V_DATA_TYPE = 'VARCHAR2' THEN
          --IF_4 START
          -- /* OF-5973 */ APPLY UPPER function
          V_COL := 'UPPER("' || PI_COL_LIST(1) || '")';
          --ELSE it is non-varchar column
        ELSE
          V_COL := PI_COL_LIST(1);
        END IF; -- IF_4 END

        V_DDL := ' CREATE ';

        -- Create DDL statements based on uniqueness

        IF PI_UNIQUENESS = 1 THEN
          --IF_5 START
          V_DDL := V_DDL || 'UNIQUE';
        END IF; --IF_5 END

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        -- Execute the Create DDl through COMMONS DDL Handling service
        <<CREATE_SINGLE_COLUMN_INDEX>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMN ' ||
                                                                PI_COL_LIST(1) ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
          PO_CREATE_DDL   := V_DDL;
        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            --Get the index name for the given column
            PO_INDEX_NAME := get_already_present_index_name(pi_table_name => V_TABLE_NAME,
                                                            pi_col_list   => TO_CHAR(V_COL));

            --Get uniqueness property
            SELECT UNIQUENESS
              INTO PO_IS_UNIQUE
              FROM USER_INDEXES
             WHERE INDEX_NAME = PO_INDEX_NAME;

            PO_INDEX_STATUS := 2;
            PO_CREATE_DDL   := V_DDL;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;
            PO_CREATE_DDL := V_DDL;
        END;
        --Multi columns to be indexed
      ELSIF PI_COL_LIST.COUNT > 1 THEN
        FOR C IN 1 .. PI_COL_LIST.COUNT LOOP
          --Check the data type of the column
          SELECT DATA_TYPE
            INTO V_DATA_TYPE
            FROM USER_TAB_COLUMNS
           WHERE TABLE_NAME = V_TABLE_NAME
             AND COLUMN_NAME = UPPER(PI_COL_LIST(C));

          --if data type is VARCHAR2
          IF V_DATA_TYPE = 'VARCHAR2' THEN
            --IF_4 START
            -- /* OF-5973 */ APPLY UPPER function
            V_COL := V_COL || 'UPPER("' || PI_COL_LIST(C) || '")';
            --ELSE it is non-varchar column
          ELSE
            V_COL := V_COL || PI_COL_LIST(C);
          END IF; -- IF_4 END

          V_COL := V_COL || ',';
        END LOOP;

        V_COL := SUBSTR(V_COL, 1, LENGTH(V_COL) - 1);

        V_DDL := ' CREATE ';

        -- Create DDL statements based on uniqueness

        IF PI_UNIQUENESS = 1 THEN
          --IF_5 START
          V_DDL := V_DDL || 'UNIQUE';
        END IF; --IF_5 END

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        <<CREATE_COMPOSITE_COLUMN_INDEX>>
        BEGIN
          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMN ' ||
                                                                PI_COL_LIST(1) ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
          PO_CREATE_DDL   := V_DDL;
        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            --Get the index name for the given column list
            PO_INDEX_NAME := get_already_present_index_name(pi_table_name => V_TABLE_NAME,
                                                            pi_col_list   => V_COL);

            --Get uniqueness property
            SELECT UNIQUENESS
              INTO PO_IS_UNIQUE
              FROM USER_INDEXES
             WHERE INDEX_NAME = PO_INDEX_NAME;

            PO_INDEX_STATUS := 2;
            PO_CREATE_DDL   := V_DDL;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;
            PO_CREATE_DDL := V_DDL;
          WHEN E_MAXIMUM_KEY_LENGTH_EXCEEDED THEN
            PO_INDEX_STATUS := 4;
            --PO_CREATE_DDL := V_DDL;
        END;
      END IF;
    END IF;
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END CREATE_INDEX1;

  PROCEDURE UPDATE_AIM(PI_TABLE_NAME     IN VARCHAR2,
                       PI_INDEX_NAME     IN VARCHAR2,
                       PI_COL_LIST       IN coltype_indexed_columns_list,
                       PI_OLD_INDEX_NAME IN VARCHAR2 DEFAULT NULL,
                       PI_INDEX_TYPE     IN NUMBER,
                       PI_AIM_ID         IN NUMBER DEFAULT NULL,
                       PI_DEFINITION_ID  IN NUMBER DEFAULT NULL,
                       PI_BUSINESS_NAME  IN VARCHAR2 DEFAULT NULL,
                       PO_UPDATE_COUNT   OUT NUMBER) /*Added as part of OF-19375*/
                       IS
    V_SQL                   VARCHAR2(3000 CHAR);
    V_collection_null_check VARCHAR2(1);
    V_INDEX_COLUMN_LIST     VARCHAR2(1000);
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    IF PI_COL_LIST IS NOT NULL AND PI_COL_LIST.COUNT > 0 THEN
      V_collection_null_check := 'a';

      SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
        INTO V_INDEX_COLUMN_LIST
        FROM TABLE(PI_COL_LIST);
    END IF;
    -- INSERT_LOGS('PI_INDEX_NAME='||PI_INDEX_NAME||'--V_collection_null_check='||V_collection_null_check||'----V_INDEX_COLUMN_LIST='||V_INDEX_COLUMN_LIST);

    SELECT ' UPDATE APPLICATION_INDEXES_METADATA AIM
         SET AIM.AIM_LAST_UPDATE_DATE = systimestamp ,' ||
            DECODE(PI_INDEX_NAME,
                   NULL,
                   '',
                   'AIM.AIM_INDEX_NAME = ''' || PI_INDEX_NAME || '''')
           --|| CASE WHEN PI_COL_LIST IS NULL THEN '' ELSE ', AIM.AIM_INDEXED_COLUMNS = '
            || CASE
              WHEN PI_INDEX_NAME IS NOT NULL AND
                   V_collection_null_check IS NOT NULL THEN
               ','
            END || DECODE(V_collection_null_check,
                          NULL,
                          '',
                          'AIM.AIM_INDEXED_COLUMNS = COLTYPE_INDEXED_COLUMNS_LIST(' ||
                          V_INDEX_COLUMN_LIST || ')') ||
            ' WHERE AIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''' ||
            DECODE(PI_OLD_INDEX_NAME,
                   NULL,
                   '',
                   ' AND AIM_INDEX_NAME = ''' || PI_OLD_INDEX_NAME || '''') ||
            DECODE(PI_INDEX_TYPE,
                   NULL,
                   '',
                   ' AND AIM_INDEX_TYPE = ' || PI_INDEX_TYPE || '') ||
            DECODE(PI_DEFINITION_ID,
                   NULL,
                   '',
                   ' AND AIM_DEF_ID = ' || PI_DEFINITION_ID || '') ||
            DECODE(PI_BUSINESS_NAME,
                   NULL,
                   '',
                   ' AND AIM_BUSINESS_NAME = ''' || PI_BUSINESS_NAME || '''') ||
            DECODE(PI_AIM_ID, NULL, '', ' AND AIM_ID = ' || PI_AIM_ID || '')
      INTO V_SQL
      FROM DUAL;
    -- INSERT_LOGS('UPDATE_AIM => V_SQL :='||V_SQL);
    EXECUTE IMMEDIATE V_SQL;

    IF sql%rowcount = 0
      THEN
       PO_UPDATE_COUNT := 0; --no rows updated
    ELSE
       PO_UPDATE_COUNT := 1;
    END IF;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END UPDATE_AIM;

  PROCEDURE UPDATE_AIM1(PI_TABLE_NAME     IN VARCHAR2,
                        PI_INDEX_NAME     IN VARCHAR2,
                        PI_COL_LIST       IN coltype_indexed_columns_list,
                        PI_OLD_INDEX_NAME IN VARCHAR2 DEFAULT NULL,
                        PI_INDEX_TYPE     IN NUMBER,
                        PI_UPDATE_DDL     IN CLOB,
                        PI_AIM_ID         IN NUMBER DEFAULT NULL,
                        PI_DEFINITION_ID  IN NUMBER DEFAULT NULL,
                        PI_BUSINESS_NAME  IN VARCHAR2 DEFAULT NULL) IS
    V_SQL                   CLOB; -- VARCHAR2(3000 CHAR);
    V_collection_null_check VARCHAR2(1);
    V_INDEX_COLUMN_LIST     VARCHAR2(1000 CHAR);
  BEGIN
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    IF PI_COL_LIST IS NOT NULL AND PI_COL_LIST.COUNT > 0 THEN
      V_collection_null_check := 'a';
      SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
        INTO V_INDEX_COLUMN_LIST
        FROM TABLE(PI_COL_LIST);
    END IF;

    IF PI_INDEX_NAME IS NOT NULL THEN
      -- INSERT_LOGS('- UPDATE_AIM1 - if PI_UPDATE_DDL is not null then');

      SELECT '
      UPDATE AIM_INDEX_DDL_STORAGE
      SET  AIDS_INDEX_NAME = ''' || PI_INDEX_NAME || '''' || CASE
               WHEN PI_UPDATE_DDL IS NULL THEN
                TO_CLOB('')
               ELSE
                ',AIDS_INDEX_DDL = '''

                || REGEXP_REPLACE(PI_UPDATE_DDL, '\''', '''''') || ''''
             END

             || ' WHERE (AIDS_TABLE_NAME,AIDS_INDEX_NAME) in
        (SELECT AIM.AIM_TABLE_NAME,AIM.AIM_INDEX_NAME FROM APPLICATION_INDEXES_METADATA AIM
         WHERE  AIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''' ||
             DECODE(PI_OLD_INDEX_NAME,
                    NULL,
                    '',
                    ' AND AIM_INDEX_NAME = ''' || PI_OLD_INDEX_NAME || '''') ||
             DECODE(PI_INDEX_TYPE,
                    NULL,
                    '',
                    ' AND AIM_INDEX_TYPE = ' || PI_INDEX_TYPE || '') ||
             DECODE(PI_DEFINITION_ID,
                    NULL,
                    '',
                    ' AND AIM_DEF_ID = ' || PI_DEFINITION_ID || '') ||
             DECODE(PI_BUSINESS_NAME,
                    NULL,
                    '',
                    ' AND AIM_BUSINESS_NAME = ''' || PI_BUSINESS_NAME || '''') ||
             DECODE(PI_AIM_ID,
                    NULL,
                    '',
                    ' AND AIM_ID = ' || PI_AIM_ID || '') || ')'
        INTO V_SQL
        FROM DUAL;
      BEGIN
        -- INSERT_LOGS('- UPDATE_AIM1 - AIDS - V_SQL = ' || V_SQL);
        EXECUTE IMMEDIATE V_SQL;
        -- INSERT_LOGS('- UPDATE_AIM1 - AIDS - EXECUTE IMMEDIATE V_SQL - SUCCESSFUL - NO EXCEPTION');
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
          -- INSERT_LOGS('- UPDATE_AIM1 - AIDS - EXECUTE IMMEDIATE V_SQL - EXCEPTION - SQLERRM = ' || SQLERRM);
      END;

    END IF;

    SELECT '
    UPDATE APPLICATION_INDEXES_METADATA AIM
    SET AIM.AIM_LAST_UPDATE_DATE = systimestamp ,' ||
            DECODE(PI_INDEX_NAME,
                   NULL,
                   '',
                   'AIM.AIM_INDEX_NAME = ''' || PI_INDEX_NAME || '''')
           --|| CASE WHEN PI_COL_LIST IS NULL THEN '' ELSE ', AIM.AIM_INDEXED_COLUMNS = '
            || CASE
              WHEN PI_INDEX_NAME IS NOT NULL AND
                   V_collection_null_check IS NOT NULL THEN
               ','
            END || DECODE(V_collection_null_check,
                          NULL,
                          '',
                          'AIM.AIM_INDEXED_COLUMNS = COLTYPE_INDEXED_COLUMNS_LIST(' ||
                          V_INDEX_COLUMN_LIST || ')') ||
            ' WHERE AIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''' ||
            DECODE(PI_OLD_INDEX_NAME,
                   NULL,
                   '',
                   ' AND AIM_INDEX_NAME = ''' || PI_OLD_INDEX_NAME || '''') ||
            DECODE(PI_INDEX_TYPE,
                   NULL,
                   '',
                   ' AND AIM_INDEX_TYPE = ' || PI_INDEX_TYPE || '') ||
            DECODE(PI_DEFINITION_ID,
                   NULL,
                   '',
                   ' AND AIM_DEF_ID = ' || PI_DEFINITION_ID || '') ||
            DECODE(PI_BUSINESS_NAME,
                   NULL,
                   '',
                   ' AND AIM_BUSINESS_NAME = ''' || PI_BUSINESS_NAME || '''') ||
            DECODE(PI_AIM_ID, NULL, '', ' AND AIM_ID = ' || PI_AIM_ID || '')
      INTO V_SQL
      FROM DUAL;

    BEGIN
      -- INSERT_LOGS('- UPDATE_AIM1 - AIM - V_SQL = ' || V_SQL);
      EXECUTE IMMEDIATE V_SQL;
      -- INSERT_LOGS('- UPDATE_AIM1 - AIM - EXECUTE IMMEDIATE V_SQL - SUCCESSFUL - NO EXCEPTION');
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
        -- INSERT_LOGS('- UPDATE_AIM1 - AIM - EXECUTE IMMEDIATE V_SQL - EXCEPTION - SQLERRM = ' || SQLERRM);
    END;

    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END UPDATE_AIM1;

  -- OF-13090 - START - Create another version of UPDATE_AIM1 (renamed existing UPDATE_AIM1 to UPDATE_AIM1_OLD) -- Using MERGE in stead of UPDATE

  PROCEDURE UPDATE_CORE_INDEXES(PI_TABLES_ID                 IN NUMBER,
                                PI_PROCESS_ID                IN NUMBER DEFAULT NULL,
                                PI_RUN_ID                    IN NUMBER DEFAULT NULL,
                                PI_TABLE_NAME                IN VARCHAR2,
                                PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX, --sales change
                                PI_INDEX_TABLESPACE          IN VARCHAR2,
                                PI_TRANSACTION_ID            IN VARCHAR2,
                                PI_RENAME_INDX_NAME          IN VARCHAR2, --sales change
                                PO_RENAMED_BK_INDEX_NAME     OUT VARCHAR2,
                                PO_LOG_MSG                   OUT VARCHAR2) IS
    V_NEW_INDEX_UNIQUE     NUMBER;
    V_TR_LIFECYCLE         NUMBER(10);
    V_SKIP_BK_INDEX        NUMBER := 0;
    V_INDEX_STATUS         NUMBER;
    V_LENGTH               NUMBER;
    V_TABLENAME            VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_RENAMED_INDEX_NAME   VARCHAR2(30 CHAR) := PI_RENAME_INDX_NAME; --sales change
    V_TRANSACTION_ID       VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    V_NEW_LINE             VARCHAR2(30 CHAR) := CHR(13) || CHR(10);
    V_INDEXING_INFO        VARCHAR2(1000 CHAR) := '';
    V_INDEX_NAME_RETURNED  VARCHAR2(30 CHAR);
    V_INDEX_NAME_GENERATED VARCHAR2(30 CHAR);
    V_UNIQUENESS_RETURNED  VARCHAR2(9 CHAR);
    V_COL_LIST             coltype_indexed_columns_list;
    V_BUSINESS_NAME        VARCHAR2(100 CHAR);
    V_RETURNED_INDEX_DDL   CLOB;

    V_DDL_CREATE_INDEX CLOB := NULL;
    V_DDL_DROP_INDEX   CLOB := NULL;
    V_DDL_QUERY        CLOB := NULL;
    V_UNDO_DDL_QUERY   CLOB := NULL;
    V_UNDO_DDL         CLOB;
    V_DDL              CLOB;
    V_SQL              CLOB := '';

    V_CLOB_NEW_COL_LIST TABLETYPE_CHARMAX;
    V_CLOB_OLD_COL_LIST TABLETYPE_CHARMAX;

    V_INDEX_LIST    COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_DDL COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE;

    V_COMMA_COLUMN_LIST VARCHAR2(1000);

    V_UPDATE_COUNT        NUMBER(1) := NULL; --added as part of OF-19375
    V_IS_UNIQUE           NUMBER(1) := NULL; --added as part of OF-19375

    MAXIMUM_KEY_LENGTH_EXCEEDED EXCEPTION;
    PRAGMA EXCEPTION_INIT(MAXIMUM_KEY_LENGTH_EXCEEDED, -1450);

    E_SPECIFIED_INDEX_DOESNT_EXIST EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_SPECIFIED_INDEX_DOESNT_EXIST, -1418);

    TYPE RECTYPE_INDEX_UPDATION_CALLS IS RECORD(
      INDEX_TYPES          VARCHAR2(30 CHAR),
      INDEX_UPDATION_CALLS VARCHAR2(4000));

    TYPE COLTYPE_INDEX_CREATION_INFO IS TABLE OF RECTYPE_INDEX_UPDATION_CALLS;

    V_INDEX_CREATION_COLLECTION COLTYPE_INDEX_CREATION_INFO;

    V_LOG_MESSAGE           CLOB;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR) := PI_INDEX_TABLESPACE;
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- INSERT_LOGS('UPDATE_CORE_INDEXES - 1 - START');

    -- 2. Get the table name
    --sales planning change; commented as will get this as input paramater
    /*SELECT T.TABLES_PHYSICAL_NAME,
          COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
     INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
     FROM TABLES T
    WHERE T.TABLES_ID = PI_TABLES_ID;*/

    -- 3. Set the Log message
    V_LOG_MESSAGE := '    Indexes to be updated on table ' || V_TABLENAME;

    -- 4. Get the transaction id
    --sales planning change; transaction id is input to proc
    --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

    -- 5. Rename Business Key Index always (as it is the ONLY Composite Core Index)
    <<RENAME_BUSINESS_KEY_INDEX>>
    BEGIN
      -- 5.1. Generate the name for Renaming Index
      --commented for sales planning change;

      /*IF PI_PROCESS_ID IS NOT NULL AND PI_RUN_ID IS NOT NULL THEN
        V_NEW_INDEX_UNIQUE   := CT_INDEX_RENAME_SEQ.NEXTVAL;
        V_RENAMED_INDEX_NAME := SUBSTR('I_' || V_NEW_INDEX_UNIQUE || '_' ||
                                       PI_PROCESS_ID || '_' || PI_RUN_ID,
                                       1,
                                       30);
      ELSE
        -- OF-20855 - START - In wake of changes to Table Physical Naming strategy starting with Partitioning, Indexing needs to adopt: "T" || Tables_ID : instead of Tables_Physical_Name to name Indexes.
        -- V_RENAMED_INDEX_NAME := SUBSTR(V_TABLENAME || '_BUSINESSKEY_UI', 1, 26) || '_BKP';
        V_RENAMED_INDEX_NAME := SUBSTR('T' || PI_TABLES_ID ||
                                       '_BUSINESSKEY_UI',
                                       1,
                                       26) || '_BKP';
        -- OF-20855 - END
      END IF;*/

      -- 5.2. Set the Output parameter for Renamed Business Key Name to be used by Update_App_Indexes.
      PO_RENAMED_BK_INDEX_NAME := V_RENAMED_INDEX_NAME;

      -- 5.3. Storing process_id as 1 if not owned by a process and 0 if owned
      -- TR_LIFECYCLE --> 1 owned by a process(wrong comment in metadata) .
      V_TR_LIFECYCLE := CASE
                          WHEN PI_PROCESS_ID IS NULL THEN
                           1
                          ELSE
                           0
                        END;

      -- 5.4. Register the Key column index in TEMP_RESOURCES table
      -- Objects registered in temp resources are deleted at the end of transaction or process
      --sales planning change; object is registered by java and given as input so below insert is commented
      /*
           EXECUTE IMMEDIATE '
               INSERT INTO TEMP_RESOURCES (TR_ID, TR_NAME, TR_TYPE, TR_PATH, TR_LIFECYCLE, TR_RUN_ID, TR_TRANSACTION_ID, TR_COLUMN_TABLE_NAME, TR_LOCATION)
               VALUES (UID_SEQUENCE.NEXTVAL, :1, 6, NULL, :2, :3, :4, NULL, 0)'
             USING V_RENAMED_INDEX_NAME, V_TR_LIFECYCLE, PI_RUN_ID, V_TRANSACTION_ID;
      */
      -- 5.5. Call RENAME_INDEX procedure to rename the Index
      -- OF-31963 - START
      /*
      COMMONS_INDEXING.RENAME_INDEX
      (
        -- OF-20855 - START - In wake of changes to Table Physical Naming strategy starting with Partitioning, Indexing needs to adopt: "T" || Tables_ID : instead of Tables_Physical_Name to name Indexes.
        -- PI_INDEX_NAME => V_TABLENAME || '_BUSINESSKEY_UI',
        PI_INDEX_NAME => 'T' || PI_TABLES_ID || '_BUSINESSKEY_UI',
        -- OF-20855 - END
        PI_UNIQUE_ID => V_NEW_INDEX_UNIQUE,
        PI_PROCESS_ID => PI_PROCESS_ID,
        PI_RUN_ID   => PI_RUN_ID
      );
      */
/*OF-69424 start */
/*      COMMONS_INDEXING.RENAME_BK_INDEX(PI_INDEX_NAME     => 'T' ||
                                                            PI_TABLES_ID ||
                                                            '_BUSINESSKEY_UI',
                                       PI_UNIQUE_ID      => V_NEW_INDEX_UNIQUE,
                                       PI_PROCESS_ID     => PI_PROCESS_ID,
                                       PI_RUN_ID         => PI_RUN_ID,
                                       PI_TRANSACTION_ID => V_TRANSACTION_ID --sales change
                                       ); */
      -- OF-31963 - END
    COMMONS_INDEXING.RENAME_INDEX(PI_INDEX_NAME     => 'T' ||PI_TABLES_ID ||'_BUSINESSKEY_UI',
                                  PI_UNIQUE_ID      => V_NEW_INDEX_UNIQUE, -- right now this is being passed as null since it was commented as part of sales change
                                  PI_PROCESS_ID     => PI_PROCESS_ID,
                                  PI_RUN_ID         => PI_RUN_ID,
                                  PI_TRANSACTION_ID => PI_TRANSACTION_ID,
                                  PI_NEW_INDEX_NAME=>PI_RENAME_INDX_NAME);


    COMMONS_INDEXING.UPDATE_AIM1(PI_TABLE_NAME     => PI_TABLE_NAME,
                                 PI_INDEX_NAME     => PI_RENAME_INDX_NAME,
                                 PI_COL_LIST       => NULL,
                                 PI_OLD_INDEX_NAME => 'T' ||PI_TABLES_ID ||'_BUSINESSKEY_UI',
                                 PI_INDEX_TYPE     => NULL,
                                 PI_UPDATE_DDL     => NULL,
                                 PI_AIM_ID         => NULL,
                                 PI_DEFINITION_ID  => NULL,
                                 PI_BUSINESS_NAME  => NULL);

/* OF-69424 ends */
    EXCEPTION
      -- Business Key Index wont exist in tables having only one entity/one tupr and no other key fields
      -- This is possible only for indexes in releases before 1.19
      WHEN E_SPECIFIED_INDEX_DOESNT_EXIST THEN
        -- Do nothing
        NULL;
        -- INSERT_LOGS('UPDATE_CORE_INDEXES - 2 - E_SPECIFIED_INDEX_DOESNT_EXIST');
      WHEN NO_DATA_FOUND THEN
        --DO nothing
        NULL;
        -- INSERT_LOGS('UPDATE_CORE_INDEXES - 3 - NO_DATA_FOUND');
    END;

    -- End Step 5.

    -- Deleting the Metadata for single column indexes.
    -- IF index existed on column COL1, and COL1 is dropped from UI (actual rename happens for the column)
    -- Any Index metadata present on such column must be deleted
    FOR D IN (SELECT AIM_DATA.AIM_DEF_ID,
                     AIM_DATA.AIM_BUSINESS_NAME,
                     AIM_DATA.AIM_INDEX_NAME,
                     AIM_DATA.AIM_TABLE_NAME,
                     AIM_DATA.COLUMN_NAME,
                     AIM_DATA.AIM_IS_INDEX_TO_BE_RECREATED,
                     AIM_DATA.AIM_INDEX_IS_UNIQUE,
                     AIM_DATA.AIM_INDEX_TYPE
                FROM (SELECT AIM.AIM_INDEX_NAME,
                             AIM.AIM_TABLE_NAME,
                             AIM.AIM_DEF_ID,
                             AIM.AIM_BUSINESS_NAME,
                             (SELECT COLUMN_VALUE
                                FROM TABLE(AIM.AIM_INDEXED_COLUMNS)) COLUMN_NAME,
                             AIM.AIM_IS_INDEX_TO_BE_RECREATED,
                             AIM.AIM_INDEX_IS_UNIQUE,
                             AIM.AIM_INDEX_TYPE
                        FROM APPLICATION_INDEXES_METADATA AIM
                       WHERE AIM.AIM_TABLE_NAME = V_TABLENAME
                         AND AIM.AIM_INDEX_TYPE = 1
                            /*OF-13090 - START - Exclude Business Key Indexes from this list*/
                         AND AIM.AIM_BUSINESS_NAME <> 'CORE__BUSINESS_KEY'
                            /*OF-13090-END*/
                         AND (SELECT COUNT(COLUMN_VALUE)
                                FROM TABLE(AIM.AIM_INDEXED_COLUMNS)) = 1) AIM_DATA
               WHERE NOT EXISTS
               (SELECT /*+ FIRST_ROWS(1) */
                       1
                        FROM USER_TAB_COLUMNS UTC
                       WHERE UTC.TABLE_NAME = AIM_DATA.AIM_TABLE_NAME
                         AND UTC.COLUMN_NAME = AIM_DATA.COLUMN_NAME
                         AND ROWNUM = 1)) LOOP
      --LOOP 1 START
      -- Deleting metadata for single column indexes when column is dropped
      -- INSERT_LOGS ('UPDATE_CORE_INDEXES - 4 - DELETE_AIM_BY_DEFID_AND_BNAME : PI_TABLE_NAME => ' || V_TABLENAME || ' , PI_DEFINITION_ID => ' || d.aim_def_id  || ', PI_BUSINESS_NAME => '|| d.aim_business_name );
      COMMONS_INDEXING.DELETE_AIM_BY_DEFID_AND_BNAME(PI_TABLE_NAME    => V_TABLENAME,
                                                     PI_DEFINITION_ID => d.aim_def_id,
                                                     PI_BUSINESS_NAME => d.aim_business_name);
      COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => d.aim_def_id,
                                 PI_INDEX_NAME                 => d.AIM_INDEX_NAME,
                                 PI_TABLE_NAME                 => d.AIM_TABLE_NAME,
                                 PI_COLUMN_LIST                => d.COLUMN_NAME,
                                 PI_RECREATE_INDEX_ON_COL_DROP => d.AIM_IS_INDEX_TO_BE_RECREATED,
                                 PI_BUSINESS_NAME              => d.AIM_BUSINESS_NAME,
                                 PI_IS_UNIQUE                  => d.AIM_INDEX_IS_UNIQUE,
                                 PI_INDEX_TYPE                 => d.AIM_INDEX_TYPE,
                                 PI_STATUS                     => 3);
      --COMMONS_INDEXING.DELETE_AIM_BY_INDEX(PI_INDEX_NAME => D.AIM_INDEX_NAME);
    END LOOP;

    -- 6. Fetch All the Physical Indexes on the Table
    WITH RESULT_SET1 AS
     (SELECT CASE
               WHEN INDEXING_ORDER = 'AUTO_BUSINESS_KEY' THEN
                COLUMNS_TO_BE_INDEXED
             END B_AUTO_BUSINESSKEY_INDEX,
             CASE
               WHEN INDEXING_ORDER = 'BUSINESS_KEY' THEN
                COLUMNS_TO_BE_INDEXED
             END B_BUSINESS_KEY_INDEXES,
             CASE
               WHEN INDEXING_ORDER = 'ENTITY_KEY' THEN
                COLUMNS_TO_BE_INDEXED
             END C_ENTITY_INDEXES,
             CASE
               WHEN INDEXING_ORDER = 'PERIOD' THEN
                COLUMNS_TO_BE_INDEXED
             END D_PERIOD_INDEXES,
             OCTI_TC_IS_NULLABLE,
             OCTI_TC_ORDER
        FROM (SELECT CASE
                       WHEN picc.OCTI_TC_LOGIC_TYPE = 5 THEN
                        COMMONS_INDEXING.UPDATE_CLOB2(PI_TABLE_NAME => V_TABLENAME,
                                                      -- OF-20855 - START - In wake of changes to Table Physical Naming strategy starting with Partitioning, Indexing needs to adopt: "T" || Tables_ID : instead of Tables_Physical_Name to name Indexes.
                                                      -- PI_INDEX_NAME => V_TABLENAME || '_BUSINESSKEY_UI',
                                                      PI_INDEX_NAME => 'T' ||
                                                                       PI_TABLES_ID ||
                                                                       '_BUSINESSKEY_UI',
                                                      -- OF-20855 - END
                                                      PI_COL_LIST        => '''' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME || '''',
                                                      PI_BUSINESS_NAME   => 'CORE__BUSINESS_KEY',
                                                      PI_IS_PRIMARY_KEY  => 0,
                                                      PI_UNIQUENESS      => 1,
                                                      PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                                      PI_RUN_ID          => PI_RUN_ID,
                                                      PI_TRANSACTION_ID  => v_transaction_id)
                     END AUTO_BUSINESS_KEY,
                     CASE
                       WHEN picc.OCTI_TC_LOGIC_TYPE IN (1, 3, 6, 8, 9) THEN
                        '''' || picc.OCTI_TC_PHYSICAL_NAME || ''''
                     END BUSINESS_KEY,
                     CASE
                       WHEN picc.OCTI_TC_COLUMN_TYPE = 1 THEN
                        COMMONS_INDEXING.UPDATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                                      PI_INDEX_NAME      => 'T' ||
                                                                            PI_TABLES_ID || '_' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME ||
                                                                            '_SI', /*OF-21059*/
                                                      PI_COL_LIST        => '''' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME || '''',
                                                      PI_BUSINESS_NAME   => 'CORE__ENTITY__' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME,
                                                      PI_IS_PRIMARY_KEY  => 0,
                                                      PI_UNIQUENESS      => 0,
                                                      PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                                      PI_RUN_ID          => PI_RUN_ID,
                                                      PI_TRANSACTION_ID  => v_transaction_id)
                     END ENTITY_KEY,
                     CASE
                       WHEN picc.OCTI_FLD_DATA_TYPE = 8 THEN
                        COMMONS_INDEXING.UPDATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                                      PI_INDEX_NAME      => 'T' ||
                                                                            PI_TABLES_ID || '_' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME ||
                                                                            '_SI', /*OF-21059*/
                                                      PI_COL_LIST        => '''' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME || '''',
                                                      PI_BUSINESS_NAME   => 'CORE__PERIOD__' ||
                                                                            picc.OCTI_TC_PHYSICAL_NAME,
                                                      PI_IS_PRIMARY_KEY  => 0,
                                                      PI_UNIQUENESS      => 0,
                                                      PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                                      PI_RUN_ID          => PI_RUN_ID,
                                                      PI_TRANSACTION_ID  => v_transaction_id)
                     END PERIOD,
                     picc.OCTI_TC_IS_NULLABLE,
                     picc.OCTI_TC_ORDER
                FROM TABLE(PI_INDEX_CREATION_COLLECTION) picc
               WHERE (picc.OCTI_TC_LOGIC_TYPE IN (1, 3, 5, 6, 8, 9) OR
                     picc.OCTI_TC_COLUMN_TYPE = 1 OR
                     picc.OCTI_FLD_DATA_TYPE = 8)) RESULT UNPIVOT EXCLUDE NULLS(COLUMNS_TO_BE_INDEXED FOR INDEXING_ORDER IN(AUTO_BUSINESS_KEY,
                                                                                                                            BUSINESS_KEY,
                                                                                                                            ENTITY_KEY,
                                                                                                                            PERIOD))
       GROUP BY INDEXING_ORDER,
                COLUMNS_TO_BE_INDEXED,
                OCTI_TC_IS_NULLABLE,
                OCTI_TC_ORDER
       ORDER BY OCTI_TC_ORDER, OCTI_TC_IS_NULLABLE), --OF-35821
    RESULT_SET2 AS
     (SELECT B_AUTO_BUSINESSKEY_INDEX,
             LISTAGG(B_BUSINESS_KEY_INDEXES, ',') WITHIN GROUP(ORDER BY ROWNUM) AS B_BUSINESS_KEY_INDEXES,
             C_ENTITY_INDEXES,
             D_PERIOD_INDEXES
        FROM RESULT_SET1
       GROUP BY B_AUTO_BUSINESSKEY_INDEX, C_ENTITY_INDEXES, D_PERIOD_INDEXES)
    SELECT INDEX_TYPES,
           CASE
             WHEN INDEX_TYPES = 'B_BUSINESS_KEY_INDEXES' THEN
              COMMONS_INDEXING.UPDATE_CLOB2(PI_TABLE_NAME => V_TABLENAME,
                                            -- OF-20855 - START - In wake of changes to Table Physical Naming strategy starting with Partitioning, Indexing needs to adopt: "T" || Tables_ID : instead of Tables_Physical_Name to name Indexes.
                                            -- PI_INDEX_NAME => V_TABLENAME || '_BUSINESSKEY_UI',
                                            PI_INDEX_NAME => 'T' ||
                                                             PI_TABLES_ID ||
                                                             '_BUSINESSKEY_UI',
                                            -- OF-20855 - END
                                            PI_COL_LIST        => INDEX_UPDATION_CALLS,
                                            PI_BUSINESS_NAME   => 'CORE__BUSINESS_KEY',
                                            PI_IS_PRIMARY_KEY  => 0,
                                            PI_UNIQUENESS      => 1,
                                            PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                            PI_RUN_ID          => PI_RUN_ID,
                                            PI_TRANSACTION_ID  => v_transaction_id --sales change
                                            )
             ELSE
              INDEX_UPDATION_CALLS
           END
      BULK COLLECT
      INTO V_INDEX_CREATION_COLLECTION
      FROM RESULT_SET2 RESULT UNPIVOT EXCLUDE NULLS(INDEX_UPDATION_CALLS FOR INDEX_TYPES IN(B_AUTO_BUSINESSKEY_INDEX,
                                                                                            B_BUSINESS_KEY_INDEXES,
                                                                                            C_ENTITY_INDEXES,
                                                                                            D_PERIOD_INDEXES))
     ORDER BY INDEX_TYPES;

    -- End Step 6.

    -- Fix for Defect# 14157 -- Check if V_INDEX_CREATION_COLLECTION is EMPTY or not.
    IF V_INDEX_CREATION_COLLECTION.COUNT > 0 THEN
      -- 7. Loop through the Index collection and apply processing logic.
      FOR C IN V_INDEX_CREATION_COLLECTION.FIRST .. V_INDEX_CREATION_COLLECTION.LAST LOOP
        -- INSERT_LOGS ('c = '|| c);
        -- INSERT_LOGS ('V_INDEX_CREATION_COLLECTION(C).INDEX_UPDATION_CALLS = ' || V_INDEX_CREATION_COLLECTION(C).INDEX_UPDATION_CALLS);
        -- 7.1. Skip Business Key (non-Auto) updation, if Auto Business Key is updated.
        /*Changes as part of OF-18990 starts  commenting code as it does not allow index creation on additional fields */
        --As part OF-18990; added and condition to check if B_BUSINESS_KEY_INDEXES then skip auto BK creation
        IF V_SKIP_BK_INDEX = 1 AND V_INDEX_CREATION_COLLECTION(C).INDEX_TYPES = 'B_BUSINESS_KEY_INDEXES' THEN
          -- Reset the variable to 0 to allow processing other core indexes.
          V_SKIP_BK_INDEX := 0;
          CONTINUE;
        END IF;


        -- 7.2. Reset the output parameter for next Index updation call.
        V_INDEXING_INFO := '';

        -- 7.3. Execute the code Block, contained in a CLOB variable, for updating the corresponding Core Index.
        EXECUTE IMMEDIATE V_INDEX_CREATION_COLLECTION(C)
                          .INDEX_UPDATION_CALLS
          USING OUT V_INDEXING_INFO, OUT V_INDEX_STATUS, OUT V_INDEX_NAME_RETURNED, OUT V_UNIQUENESS_RETURNED, OUT V_INDEX_NAME_GENERATED, OUT V_COL_LIST, OUT V_BUSINESS_NAME, OUT V_RETURNED_INDEX_DDL;

        /*CHANGES FOR OF-25938 STARTS*/
        /*IF LOWER(V_INDEXING_INFO) LIKE 'maximum key length exceeded%' THEN
          RAISE_APPLICATION_ERROR(-20145,V_INDEXING_INFO);
        END IF;*/
        /*CHANGES FOR OF-25938 ENDS*/

        SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
          INTO V_COMMA_COLUMN_LIST
          FROM TABLE(V_COL_LIST);

        -- 7.4. Proceed further according to the Output from above INDEX_UPDATION_CALLS execution.
        -- 7.4.1. Check if INDEX NAME returned by CREATE_CORE_INDEX = INDEX NAME passed as an Input to CREATE_CORE_INDEX
        -- INSERT_LOGS('UPDATE_CORE_INDEXES -- V_INDEX_NAME_RETURNED = ' || V_INDEX_NAME_RETURNED || ' -- V_RENAMED_INDEX_NAME = ' || V_RENAMED_INDEX_NAME || ' -- V_INDEX_NAME_GENERATED = ' || V_INDEX_NAME_GENERATED)  ;
        IF V_INDEX_STATUS = 1 AND
           V_INDEX_NAME_RETURNED = V_INDEX_NAME_GENERATED THEN
          -- IF 7.4.1
          -- INSERT_LOGS('UPDATE_CORE_INDEXES - 5 - IF V_INDEX_STATUS =1 and V_INDEX_NAME_RETURNED = V_INDEX_NAME_GENERATED THEN');

          -- 7.4.1.1 Update Column List for the corresponding Core Index in AIM table
          IF V_BUSINESS_NAME = 'CORE__BUSINESS_KEY' THEN
            -- INSERT_LOGS('UPDATE_CORE_INDEXES - 6 - if V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' THEN');
            COMMONS_INDEXING.UPDATE_AIM1(PI_TABLE_NAME     => V_TABLENAME,
                                         PI_INDEX_NAME     => V_INDEX_NAME_GENERATED, -- NULL,
                                         PI_COL_LIST       => V_COL_LIST,
                                         PI_OLD_INDEX_NAME => NULL,
                                         PI_UPDATE_DDL     => V_RETURNED_INDEX_DDL,
                                         PI_INDEX_TYPE     => 1,
                                         PI_AIM_ID         => NULL,
                                         PI_DEFINITION_ID  => NULL,
                                         PI_BUSINESS_NAME  => V_BUSINESS_NAME);
          ELSE
            -- INSERT_LOGS('UPDATE_CORE_INDEXES - 7 - if V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' ELSE');
            --insert metadata for the new index
            commons_indexing.INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              => NULL,
                                                          PI_INDEX_NAME                 => V_INDEX_NAME_GENERATED,
                                                          PI_TABLE_NAME                 => V_TABLENAME,
                                                          PI_COLUMN_LIST                => V_COL_LIST,
                                                          PI_RECREATE_INDEX_ON_COL_DROP => 0,
                                                          PI_BUSINESS_NAME              => V_BUSINESS_NAME,
                                                          PI_IS_UNIQUE                  => 0,
                                                          PI_INDEX_TYPE                 => 1,
                                                          PI_INDEX_INSERT_DDL           => V_RETURNED_INDEX_DDL);
            --V_INDEXING_INFO := V_NEW_LINE||'Core Index '||V_INDEX_NAME_GENERATED||' created with new columns '||V_COMMA_COLUMN_LIST;
          END IF;
          -- OF-25207 - Start
        ELSIF V_INDEX_STATUS = 4 THEN
          -- get covered indexes for BK -- via AIM tables column: for covered index; if present :
          -- 1. check the indexes and their column lists -- if exact match is found with BK then simply delete the meta for BK and rename the BK index to the one that was matching
          -- 2. if partial match is found then pick the maximum matching col list - -index and then drop BK and delete its meta as well and create this new INdex and update the AIM meta for all covered indexes
          -- 3. if no covered index found then delete BK an its corresponding meta entries
          IF V_BUSINESS_NAME = 'CORE__BUSINESS_KEY' THEN
            COMMONS_INDEXING.DELETE_APP_INDEX(PI_TABLES_ID             => PI_TABLES_ID,
                                              PI_DEF_ID                => NULL,
                                              PI_BUSINESS_NAME         => V_BUSINESS_NAME, --'CORE__BUSINESS_KEY',
                                              PI_PROCESS_ID            => PI_PROCESS_ID,
                                              PI_RUN_ID                => PI_RUN_ID,
                                              PI_TABLE_NAME            => V_TABLENAME,
                                              PI_INDEX_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                              PI_TRANSACTION_ID        => v_transaction_id);
          END IF;
          -- OF-25207 - End
        ELSIF V_INDEX_STATUS = 2 THEN
          -- INSERT_LOGS('UPDATE_CORE_INDEXES - 8 - ELSIF V_INDEX_STATUS = 2 THEN -- V_INDEX_NAME_RETURNED = ' || V_INDEX_NAME_RETURNED || ' -- V_RENAMED_INDEX_NAME = ' || V_RENAMED_INDEX_NAME || ' -- V_INDEX_NAME_GENERATED = ' || V_INDEX_NAME_GENERATED)  ;
          -- V_INDEX_NAME_RETURNED = T432198_BUSINESSKEY_UI -- V_RENAMED_INDEX_NAME = T432198_BUSINESSKEY_UI_BKP -- V_INDEX_NAME_GENERATED = T432198_BUSINESSKEY_UI
          -- 7.4.1.2 Check if INDEX NAME returned by CREATE_CORE_INDEX = Renamed Backup Index Name
          IF V_BUSINESS_NAME = 'CORE__BUSINESS_KEY' AND
             V_INDEX_NAME_RETURNED = V_RENAMED_INDEX_NAME THEN
            -- IF 7.4.1.2
            -- INSERT_LOGS('UPDATE_CORE_INDEXES - 9 - IF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_INDEX_NAME_RETURNED = V_RENAMED_INDEX_NAME THEN');
            -- Rename the backup index to the index name created
            -- Replace the old business key with the name generated
            V_DDL      := 'ALTER INDEX ' || V_RENAMED_INDEX_NAME ||
                          ' RENAME TO ' || V_INDEX_NAME_GENERATED;
            V_UNDO_DDL := '
              BEGIN
                FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                          V_INDEX_NAME_GENERATED ||
                          '''))
                LOOP
                  FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                          V_RENAMED_INDEX_NAME ||
                          ''')))
                  LOOP
                    EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                          V_INDEX_NAME_GENERATED || ' RENAME TO ' ||
                          V_RENAMED_INDEX_NAME || ''';
                  END LOOP ;
                END LOOP ;
              END;';
            -- Get the transaction id
            --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;
            -- Call EXECUTE_DDL

            COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                             PI_DESCRIPTION    => 'RENAME INDEX ' ||
                                                                  V_RENAMED_INDEX_NAME ||
                                                                  ' to Index name ' ||
                                                                  V_INDEX_NAME_GENERATED,
                                             PI_DDL            => V_DDL,
                                             PI_UNDO_DDL       => V_UNDO_DDL,
                                             PI_RUN_ID         => PI_RUN_ID);

            -- Update Column List for the Business Key Index in AIM table
            COMMONS_INDEXING.UPDATE_AIM1(PI_TABLE_NAME    => V_TABLENAME,
                                         PI_INDEX_NAME    => V_INDEX_NAME_GENERATED,
                                         PI_COL_LIST      => V_COL_LIST,
                                         PI_INDEX_TYPE    => 1,
                                         PI_UPDATE_DDL    => V_RETURNED_INDEX_DDL,
                                         PI_AIM_ID        => NULL,
                                         PI_DEFINITION_ID => NULL,
                                         PI_BUSINESS_NAME => V_BUSINESS_NAME);
          ELSE
            -- INSERT_LOGS('UPDATE_CORE_INDEXES - 9 - IF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_INDEX_NAME_RETURNED = V_RENAMED_INDEX_NAME ELSE');
            -- INDEX NAME returned by CREATE_CORE_INDEX = Any Other Name
            IF V_BUSINESS_NAME = 'CORE__BUSINESS_KEY' AND
               V_UNIQUENESS_RETURNED = 'NONUNIQUE' THEN
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 10 - IF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''NONUNIQUE'' THEN');
              -- A. Drop the NonUnique Index since Business Key should always be UNIQUE.
              V_DDL_DROP_INDEX := 'DROP INDEX  ' || V_INDEX_NAME_RETURNED;
              V_DDL_QUERY      := '
                  BEGIN
                    FOR D IN (SELECT 1 FROM DUAL WHERE EXISTS(
                      SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                  V_INDEX_NAME_RETURNED ||
                                  ''')))
                    LOOP
                      EXECUTE IMMEDIATE ''' ||
                                  V_DDL_DROP_INDEX || ''';
                    END LOOP;
                  END;';
              SELECT V_INDEX_NAME_RETURNED
                BULK COLLECT
                INTO V_INDEX_LIST
                FROM DUAL;

              COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                      PO_INDEX_DDL  => V_OUT_INDEX_DDL);

              IF V_OUT_INDEX_DDL.COUNT = 1 THEN
                -- INSERT_LOGS('UPDATE_CORE_INDEXES - 11 - IF V_OUT_INDEX_DDL.COUNT = 1 THEN');
                V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;
                -- Replace single quote with TWO single quotes
                V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                                     '\''',
                                                     '''''');
                -- Get the length of statement created
                V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);
                -- Remove the extra single quote from START and END, as the start and end are also
                -- appended with extra single quote being clob statement
                V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX,
                                             2,
                                             V_LENGTH - 1);
                V_UNDO_DDL_QUERY   := '
                  BEGIN
                    FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                      SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                      V_INDEX_NAME_RETURNED ||
                                      ''')))
                    LOOP
                      EXECUTE IMMEDIATE ''' ||
                                      V_DDL_CREATE_INDEX || ''';
                    END LOOP;
                  END;';
              END IF;

              -- Call to EXECUTE_DDL
              COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                               PI_DESCRIPTION    => 'DROP NON UNIQUE INDEX ' ||
                                                                    V_INDEX_NAME_RETURNED,
                                               PI_DDL            => V_DDL_QUERY,
                                               PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                               PI_RUN_ID         => PI_RUN_ID);

              DELETE FROM AIM_INDEX_DDL_STORAGE
               WHERE AIDS_TABLE_NAME = V_TABLENAME
                 AND AIDS_INDEX_NAME = V_INDEX_NAME_RETURNED;

              -- B. Recreate with BusinessKey as UNIQUE Index
              -- Execute the code Block again, for updating the Business Key Index.
              EXECUTE IMMEDIATE V_INDEX_CREATION_COLLECTION(C)
                                .INDEX_UPDATION_CALLS
                USING OUT V_INDEXING_INFO, OUT V_INDEX_STATUS, OUT V_INDEX_NAME_RETURNED, OUT V_UNIQUENESS_RETURNED, OUT V_INDEX_NAME_GENERATED, OUT V_COL_LIST, OUT V_BUSINESS_NAME, OUT V_RETURNED_INDEX_DDL;

              -- Update Column List for the Business Key Index in AIM table
              COMMONS_INDEXING.UPDATE_AIM1(PI_TABLE_NAME     => V_TABLENAME,
                                           PI_INDEX_NAME     => V_INDEX_NAME_GENERATED,
                                           PI_COL_LIST       => V_COL_LIST,
                                           PI_OLD_INDEX_NAME => NULL,
                                           PI_INDEX_TYPE     => 1,
                                           PI_UPDATE_DDL     => V_RETURNED_INDEX_DDL,
                                           PI_AIM_ID         => NULL,
                                           PI_DEFINITION_ID  => NULL,
                                           PI_BUSINESS_NAME  => V_BUSINESS_NAME);

              V_INDEXING_INFO := V_NEW_LINE || 'Business Key ' ||
                                 V_INDEX_NAME_GENERATED ||
                                 ' updated with new columns ' ||
                                 V_COMMA_COLUMN_LIST;
              -- Fix for Defect# 14159
            ELSIF V_BUSINESS_NAME <> 'CORE__BUSINESS_KEY' AND
                  V_INDEX_NAME_RETURNED = V_RENAMED_INDEX_NAME /*AND V_UNIQUENESS_RETURNED = 'UNIQUE'*/
             THEN
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 12 - ELSIF V_BUSINESS_NAME <> ''CORE__BUSINESS_KEY'' AND V_INDEX_NAME_RETURNED = V_RENAMED_INDEX_NAME /*AND V_UNIQUENESS_RETURNED = ''UNIQUE''*/ THEN');
              -- A. Drop the Unique Index since Business Key should always be UNIQUE.
              V_DDL_DROP_INDEX := 'DROP INDEX  ' || V_INDEX_NAME_RETURNED;
              V_DDL_QUERY      := '
                  BEGIN
                    FOR D IN (SELECT 1 FROM DUAL WHERE EXISTS(
                      SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                  V_INDEX_NAME_RETURNED ||
                                  ''')))
                    LOOP
                      EXECUTE IMMEDIATE ''' ||
                                  V_DDL_DROP_INDEX || ''';
                    END LOOP;
                  END;';
              /*              SELECT V_INDEX_NAME_RETURNED
              BULK COLLECT INTO V_INDEX_LIST
              FROM DUAL; */

              SELECT V_INDEX_NAME_RETURNED
                BULK COLLECT
                INTO V_INDEX_LIST
                FROM DUAL;

              COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                      PO_INDEX_DDL  => V_OUT_INDEX_DDL);

              IF V_OUT_INDEX_DDL.COUNT = 1 THEN
                -- INSERT_LOGS('UPDATE_CORE_INDEXES - 12 - IF V_OUT_INDEX_DDL.COUNT = 1 THEN');
                V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;
                -- Replace single quote with TWO single quotes
                V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                                     '\''',
                                                     '''''');
                -- Get the length of statement created
                V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);
                -- Remove the extra single quote from START and END, as the start and end are also
                -- appended with extra single quote being clob statement
                V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX,
                                             2,
                                             V_LENGTH - 1);
                V_UNDO_DDL_QUERY   := '
                BEGIN
                  FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                    SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                      V_INDEX_NAME_RETURNED ||
                                      ''')))
                  LOOP
                    EXECUTE IMMEDIATE ''' ||
                                      V_DDL_CREATE_INDEX || ''';
                  END LOOP;
                END;';
              END IF;

              -- Call to EXECUTE_DDL
              COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                               PI_DESCRIPTION    => 'DROP UNIQUE INDEX ' ||
                                                                    V_INDEX_NAME_RETURNED,
                                               PI_DDL            => V_DDL_QUERY,
                                               PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                               PI_RUN_ID         => PI_RUN_ID);

              -- B. Recreate Core Index as NONUNIQUE Index
              -- Execute the code Block again, for updating the Core Index.
              EXECUTE IMMEDIATE V_INDEX_CREATION_COLLECTION(C)
                                .INDEX_UPDATION_CALLS
                USING OUT V_INDEXING_INFO, OUT V_INDEX_STATUS, OUT V_INDEX_NAME_RETURNED, OUT V_UNIQUENESS_RETURNED, OUT V_INDEX_NAME_GENERATED, OUT V_COL_LIST, OUT V_BUSINESS_NAME, OUT V_RETURNED_INDEX_DDL;

              -- Update Column List for the Business Key Index in AIM table
              COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_TABLENAME,
                                          PI_INDEX_NAME     => V_INDEX_NAME_GENERATED,
                                          PI_COL_LIST       => V_COL_LIST,
                                          PI_OLD_INDEX_NAME => NULL,
                                          PI_INDEX_TYPE     => 1,
                                          PI_AIM_ID         => NULL,
                                          PI_DEFINITION_ID  => NULL,
                                          PI_BUSINESS_NAME  => V_BUSINESS_NAME,
                                          PO_UPDATE_COUNT   => V_UPDATE_COUNT); /*Added as part of OF-19375*/

              IF V_INDEX_STATUS = 1 THEN
                -- INSERT_LOGS('UPDATE_CORE_INDEXES - 13 - if V_INDEX_STATUS = 1 then');

                INSERT INTO AIM_INDEX_DDL_STORAGE
                  (AIDS_TABLE_NAME,
                   AIDS_INDEX_NAME,
                   AIDS_INDEX_IS_UNIQUE,
                   AIDS_INDEX_IS_PRIMARY,
                   AIDS_INDEX_DDL)
                VALUES
                  (V_TABLENAME,
                   V_INDEX_NAME_GENERATED,
                   V_UNIQUENESS_RETURNED,
                   0,
                   V_RETURNED_INDEX_DDL);
              END IF;

              V_INDEXING_INFO := V_NEW_LINE || 'Core Index ' ||
                                 V_INDEX_NAME_GENERATED ||
                                 ' updated with new columns ' ||
                                 V_COMMA_COLUMN_LIST;
              -- End Fix for Defect# 14159

            ELSIF V_BUSINESS_NAME = 'CORE__BUSINESS_KEY' AND
                  V_UNIQUENESS_RETURNED = 'UNIQUE' THEN
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14 - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' THEN');
              -- Rename the index to the index name created
              V_DDL := 'ALTER INDEX ' || V_INDEX_NAME_RETURNED ||
                       ' RENAME TO ' || V_INDEX_NAME_GENERATED;
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14.1 - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' THEN -- V_DDL = ' || V_DDL);
              V_UNDO_DDL := '
                BEGIN
                  FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                            V_INDEX_NAME_GENERATED ||
                            '''))
                  LOOP
                    FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                            V_INDEX_NAME_RETURNED ||
                            ''')))
                    LOOP
                      EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                            V_INDEX_NAME_GENERATED || ' RENAME TO ' ||
                            V_INDEX_NAME_RETURNED || ''';
                    END LOOP ;
                  END LOOP ;
                END;';
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14.2 - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' THEN -- V_UNDO_DDL = ' || V_UNDO_DDL);
              -- Get the transaction id ;commenting for sales planning changes
              --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

              BEGIN
                -- Call EXECUTE_DDL
                COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                 PI_DESCRIPTION    => 'RENAME INDEX ' ||
                                                                      V_INDEX_NAME_RETURNED ||
                                                                      ' to Index name ' ||
                                                                      V_INDEX_NAME_GENERATED,
                                                 PI_DDL            => V_DDL,
                                                 PI_UNDO_DDL       => V_UNDO_DDL,
                                                 PI_RUN_ID         => PI_RUN_ID);
              EXCEPTION
                WHEN OTHERS THEN
                  null;
                  -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14.3 - EXCEPTION - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' THEN -- IN EXCEPTION EXECUTE_DDL - SQLERRM = ' || SQLERRM || ' -- V_INDEX_NAME_RETURNED = ' || V_INDEX_NAME_RETURNED || ' -- V_INDEX_NAME_GENERATED = ' || V_INDEX_NAME_GENERATED);
              END;

              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14.4 - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' THEN -- after EXECUTE_DDL');

              --Replace the indexname
              V_RETURNED_INDEX_DDL := REGEXP_REPLACE(V_RETURNED_INDEX_DDL,
                                                     V_INDEX_NAME_RETURNED,
                                                     V_INDEX_NAME_GENERATED);
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14.5 - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' THEN -- after EXECUTE_DDL -- V_RETURNED_INDEX_DDL = ' || V_RETURNED_INDEX_DDL);

              -- Update Column List for the Business Key Index in AIM table
              COMMONS_INDEXING.UPDATE_AIM1(PI_TABLE_NAME     => V_TABLENAME,
                                           PI_INDEX_NAME     => V_INDEX_NAME_GENERATED,
                                           PI_COL_LIST       => V_COL_LIST,
                                           PI_OLD_INDEX_NAME => NULL,
                                           PI_INDEX_TYPE     => 1,
                                           PI_UPDATE_DDL     => V_RETURNED_INDEX_DDL,
                                           PI_AIM_ID         => NULL,
                                           PI_DEFINITION_ID  => NULL,
                                           PI_BUSINESS_NAME  => V_BUSINESS_NAME);

              V_INDEXING_INFO := V_NEW_LINE || 'Business Key ' ||
                                 V_INDEX_NAME_GENERATED ||
                                 ' updated with new columns ' ||
                                 V_COMMA_COLUMN_LIST;
            ELSE
              -- INSERT_LOGS('UPDATE_CORE_INDEXES - 15 - ELSIF V_BUSINESS_NAME = ''CORE__BUSINESS_KEY'' AND V_UNIQUENESS_RETURNED = ''UNIQUE'' ELSE');
              -- Update Column List for the Business Key Index in AIM table
              COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_TABLENAME,
                                          PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                          PI_COL_LIST       => V_COL_LIST,
                                          --PI_OLD_INDEX_NAME => V_INDEX_NAME_GENERATED, /*Commented as part of OF-70755*/
                                          PI_INDEX_TYPE     => 1,
                                          PI_AIM_ID         => NULL,
                                          PI_DEFINITION_ID  => NULL,
                                          PI_BUSINESS_NAME  => V_BUSINESS_NAME,
                                          PO_UPDATE_COUNT   => V_UPDATE_COUNT);  --Added as part of OF-19375

              /*Change as of OF-19375 starts to add an entry in AIM Table  */
              IF V_UPDATE_COUNT = 0
               THEN
                IF V_UNIQUENESS_RETURNED = 'UNIQUE'
                  THEN
                    V_IS_UNIQUE := 1;
                ELSE
                    V_IS_UNIQUE := 0;
                END IF;
                COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID      => NULL,
                                                     PI_INDEX_NAME                 => V_INDEX_NAME_GENERATED,
                                                     PI_TABLE_NAME                 => V_TABLENAME,
                                                     PI_COLUMN_LIST                => V_COL_LIST,
                                                     PI_RECREATE_INDEX_ON_COL_DROP => 1,
                                                     PI_BUSINESS_NAME              => V_BUSINESS_NAME,
                                                     PI_IS_UNIQUE                  => V_IS_UNIQUE,
                                                     PI_INDEX_TYPE                 => 1);
              END IF;
              /*Change as part of OF-19375 ends*/
            END IF;
          END IF; -- END IF 7.4.1.2
        END IF; -- END IF 7.4.1

        -- INSERT_LOGS('UPDATE_CORE_INDEXES - 14 and 15 .last - IF V_INDEXING_INFO IS NOT NULL THEN -- END');
        -- End Step 7.4.

        -- 7.5. Set the Log Message.
        IF V_INDEXING_INFO IS NOT NULL THEN
          -- INSERT_LOGS('UPDATE_CORE_INDEXES - 16 - IF V_INDEXING_INFO IS NOT NULL THEN');
          V_LOG_MESSAGE := V_LOG_MESSAGE || V_INDEXING_INFO || V_NEW_LINE;
        END IF;


       /* Changes as part of OF-18990 starts  commenting code as it does not allow index creation on additional fields */
	    -- 7.6. Set the variable to skip business key index
        IF V_INDEX_CREATION_COLLECTION(C)
         .INDEX_TYPES = 'B_AUTO_BUSINESSKEY_INDEX' THEN
          -- INSERT_LOGS('UPDATE_CORE_INDEXES - 17 - IF V_INDEX_CREATION_COLLECTION(C).INDEX_TYPES = ''B_AUTO_BUSINESSKEY_INDEX'' THEN');
          V_SKIP_BK_INDEX := 1;
        END IF;
        -- INSERT_LOGS('UPDATE_CORE_INDEXES last loop finished');
      END LOOP;
      -- End Step 7.
    END IF;

    PO_LOG_MSG := SUBSTR(V_LOG_MESSAGE, 1, 32767);

    -- INSERT_LOGS('UPDATE_CORE_INDEXES finished');
    -- OF-13090 - START
    /*
      DELETE FROM AIM_INDEX_DDL_STORAGE WHERE AIDS_TABLE_NAME = V_TABLENAME AND AIDS_INDEX_NAME NOT IN (SELECT AIM_INDEX_NAME
      FROM APPLICATION_INDEXES_METADATA WHERE AIM_TABLE_NAME = V_TABLENAME) ;
       -- INSERT_LOGS('UPDATE_CORE_INDEXES - 18 - DELETE FROM AIM_INDEX_DDL_STORAGE ');
    */
    -- OF-13090 - END
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END UPDATE_CORE_INDEXES;

  /*PROCEDURE UPDATE_APP_INDEX1(PI_TABLE_NAME         IN VARCHAR2,
                              PI_RENAMED_INDEX_NAME IN VARCHAR2,
                              PI_TRANSACTION_ID     IN VARCHAR2,
                              -- PI_INDEX_UPDATE_MODE determines whether update happens from UPDATE_INDEXES call
                              -- or DELETE_APP_INDEXES call
                              PI_INDEX_UPDATE_MODE  IN NUMBER, --1 - Update_indexes 2. DELETE_APP_INDEXES
                              PI_DELETED_INDEX_NAME IN VARCHAR2,
                              PI_TABLESPACE_NAME    IN VARCHAR2,
                              PI_RUN_ID             IN NUMBER DEFAULT NULL) IS
    v_index_name  VARCHAR2(30) := '';
    v_index_name1 VARCHAR2(30) := '';

    --PI_TABLE_NAME VARCHAR2(30);
    --PI_RENAMED_INDEX_NAME VARCHAR2(30);

    TYPE TABLETYPE_AIM_TABLE_INFO IS TABLE OF APPLICATION_INDEXES_METADATA%ROWTYPE;

    V_AIM_TABLE_INFO TABLETYPE_AIM_TABLE_INFO;

    V_INDEX_COLUMN_LIST   VARCHAR2(1000);
    V_INDEX_TO_BE_UPDATED VARCHAR2(30);

    V_INDEX_CREATION_STATUS NUMBER;
    V_INDEX_NAME_RETURNED   VARCHAR2(30);
    V_UNIQUENESS_RETURNED   VARCHAR2(9);

    V_COVERING_INDEX     VARCHAR2(30);
    V_RETURNED_INDEX_DDL CLOB;
    V_TRANSACTION_ID     VARCHAR2(50);
    V_DDL                CLOB;
    V_UNDO_DDL           CLOB;
    E_INVALID_IDENTIFIER EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_INVALID_IDENTIFIER, -904);
    --Variable to determine if indexes are getting updated because of column drop (renaming of column)
    V_COLUMN_DROP              NUMBER := 1;
    V_VALID_COLUMN_LIST        SYS.HSBLKNAMLST;
    V_VALID_COLUMNS_INSERT     coltype_indexed_columns_list;
    V_VALID_COLUMNS_COLLECTION TABLETYPE_CHARMAX;
    V_TABLES_ID                NUMBER;
    V_OUT_CREATION_STATUS      NUMBER;
    V_INDEX_TABLESPACE_NAME    VARCHAR2(30 CHAR); \*OF-11821*\

  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- INSERT_LOGS('UPDATE_APP_INDEX1 started');
    V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

    IF PI_INDEX_UPDATE_MODE = 1 THEN
      --Get the metadata info for feature indexes in a collection
      -- with index names in a group and column list in descending order within each index group
      SELECT AIM.AIM_ID,
             AIM.AIM_DEF_ID,
             AIM.AIM_BUSINESS_NAME,
             AIM.AIM_INDEX_NAME,
             AIM.AIM_TABLE_NAME,
             AIM.AIM_IS_INDEX_TO_BE_RECREATED,
             AIM.AIM_INDEXED_COLUMNS,
             AIM.AIM_INDEX_IS_UNIQUE,
             AIM.AIM_INDEX_TYPE,
             AIM.AIM_IS_ENABLED,
             AIM.AIM_CREATION_DATE,
             AIM.AIM_LAST_UPDATE_DATE
        BULK COLLECT
        INTO V_AIM_TABLE_INFO
        FROM APPLICATION_INDEXES_METADATA AIM
       WHERE AIM.AIM_TABLE_NAME = PI_TABLE_NAME
         AND AIM.AIM_INDEX_TYPE = 2
       ORDER BY AIM.AIM_INDEX_NAME,
                REGEXP_COUNT((SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
                               FROM TABLE(AIM.AIM_INDEXED_COLUMNS)),
                             ',') DESC;

      IF V_AIM_TABLE_INFO.COUNT > 0 THEN

        --Loop through the collection
        FOR C IN V_AIM_TABLE_INFO.FIRST .. V_AIM_TABLE_INFO.LAST LOOP
          v_index_name1 := V_AIM_TABLE_INFO(C).AIM_INDEX_NAME;

          --For every 1st index within each group, this condition will always be true
          --create index for every first row within each index group
          IF NVL(v_index_name1, 'a') <> NVL(v_index_name, 'b') THEN
            -- assign the index name to the variable
            -- so that consequent feature indexes with same name can be just updated
            v_index_name := V_AIM_TABLE_INFO(C).AIM_INDEX_NAME;

            -- OF-31694 - START
            --Prepare the index name to be created
            \*
            IF V_AIM_TABLE_INFO(C).AIM_INDEX_IS_UNIQUE = 1
            THEN
              V_INDEX_TO_BE_UPDATED := 'APP_' || PI_TABLE_NAME || '_' || APP_INDEX_NAME_SEQ.NEXTVAL || '_UI';
            ELSIF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT > 1 AND V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT < 33
            THEN
              V_INDEX_TO_BE_UPDATED := 'APP_' || PI_TABLE_NAME || '_' || APP_INDEX_NAME_SEQ.NEXTVAL || '_CI';
            ELSE
              V_INDEX_TO_BE_UPDATED := 'APP_' || PI_TABLE_NAME || '_' || APP_INDEX_NAME_SEQ.NEXTVAL || '_SI';
            END IF; -- IF_7 END
            *\
            SELECT TABLES_ID
              INTO V_TABLES_ID
              FROM TABLES
             WHERE TABLES_PHYSICAL_NAMe = PI_TABLE_NAME;

            V_INDEX_TO_BE_UPDATED := 'APP_' || 'T' || V_TABLES_ID || '_' ||
                                     APP_INDEX_NAME_SEQ.NEXTVAL;

            IF V_AIM_TABLE_INFO(C).AIM_INDEX_IS_UNIQUE = 1 THEN
              V_INDEX_TO_BE_UPDATED := V_INDEX_TO_BE_UPDATED || '_UI';
            ELSIF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT > 1 AND V_AIM_TABLE_INFO(C)
                  .AIM_INDEXED_COLUMNS.COUNT < 33 THEN
              V_INDEX_TO_BE_UPDATED := V_INDEX_TO_BE_UPDATED || '_CI';
            ELSE
              V_INDEX_TO_BE_UPDATED := V_INDEX_TO_BE_UPDATED || '_SI';
            END IF; -- IF_7 END
            -- OF-31694 - START

            SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                                ROWNUM) AS SYS.HSBLKNAMLST)
              INTO V_VALID_COLUMN_LIST
              FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS);
            -- OF-30537 START
            -- Get the column list from the collection into comma-separated
            SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
              INTO V_INDEX_COLUMN_LIST
              FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS);

            -- INSERT_LOGS ('V_INDEX_COLUMN_LIST - SACHID = ' || V_INDEX_COLUMN_LIST);

            SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
              INTO V_INDEX_COLUMN_LIST
              FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS);

            -- INSERT_LOGS ('V_INDEX_COLUMN_LIST - TRIPATHI = ' || V_INDEX_COLUMN_LIST);
            --Call Create Index for the the given column list
            -- INSERT_LOGS('CREATE_INDEX_TOP_APP_INDEX begining');
            <<CREATE_INDEX_TOP_APP_INDEX>>
            BEGIN
              -- INSERT_LOGS('CREATE_INDEX2 called 1');
              COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_AIM_TABLE_INFO(C)
                                                                     .AIM_TABLE_NAME,
                                             PI_INDEX_NAME        => V_INDEX_TO_BE_UPDATED,
                                             PI_COLUMN_LIST       => V_VALID_COLUMN_LIST \*SYS.HSBLKNAMLST(V_INDEX_COLUMN_LIST)*\,
                                             PI_UNIQUENESS        => V_AIM_TABLE_INFO(C)
                                                                     .AIM_INDEX_IS_UNIQUE,
                                             PI_COL_IS_PRIMARYKEY => 0,
                                             PI_INDEX_TABLESPACE  => PI_TABLESPACE_NAME, \*OF-11821*\
                                             PI_TRANSACTION_ID    => V_TRANSACTION_ID,
                                             PI_RUN_ID            => PI_RUN_ID,
                                             PO_INDEX_STATUS      => V_INDEX_CREATION_STATUS,
                                             PO_INDEX_NAME        => V_INDEX_NAME_RETURNED,
                                             PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                             PO_CREATE_DDL        => V_RETURNED_INDEX_DDL);
              -- INSERT_LOGS('CREATE_INDEX2 called  1 finished');
              -- INSERT_LOGS('CREATE_INDEX_TOP_APP_INDEX end');
              -- OF-33540
              COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => V_AIM_TABLE_INFO(C)
                                                                          .AIM_DEF_ID,
                                         PI_INDEX_NAME                 => V_INDEX_TO_BE_UPDATED,
                                         PI_TABLE_NAME                 => V_AIM_TABLE_INFO(C)
                                                                          .AIM_TABLE_NAME,
                                         PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                         PI_RECREATE_INDEX_ON_COL_DROP => V_AIM_TABLE_INFO(C)
                                                                          .AIM_IS_INDEX_TO_BE_RECREATED,
                                         PI_BUSINESS_NAME              => V_AIM_TABLE_INFO(C)
                                                                          .AIM_BUSINESS_NAME,
                                         PI_IS_UNIQUE                  => V_AIM_TABLE_INFO(C)
                                                                          .AIM_INDEX_IS_UNIQUE,
                                         PI_INDEX_TYPE                 => V_AIM_TABLE_INFO(C)
                                                                          .AIM_INDEX_TYPE,
                                         PI_STATUS                     => 2);
              -- OF-30537 END
              -- if returned index name is equal to prepared index name
              -- i.e. a new index has been created
              IF V_INDEX_CREATION_STATUS = 1 THEN
                --update AIM table to update the index name with the updated (newly created) index
                -- For every row for that index
                UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                .AIM_TABLE_NAME,
                           PI_INDEX_NAME     => V_INDEX_TO_BE_UPDATED,
                           PI_COL_LIST       => NULL,
                           PI_INDEX_TYPE     => 2,
                           PI_OLD_INDEX_NAME => v_index_name);

                INSERT INTO AIM_INDEX_DDL_STORAGE
                  (AIDS_TABLE_NAME,
                   AIDS_INDEX_NAME,
                   AIDS_INDEX_IS_UNIQUE,
                   AIDS_INDEX_IS_PRIMARY,
                   AIDS_INDEX_DDL)
                VALUES
                  (V_AIM_TABLE_INFO     (C).AIM_TABLE_NAME,
                   V_INDEX_TO_BE_UPDATED,
                   V_AIM_TABLE_INFO     (C).AIM_INDEX_IS_UNIQUE,
                   0,
                   V_RETURNED_INDEX_DDL);
                -- i.e. no change of index
              ELSIF V_INDEX_CREATION_STATUS = 2 THEN
                -- if returned index name is same as index already present for that feature index
                IF V_INDEX_NAME_RETURNED = v_index_name THEN
                  --continue for the next iteration
                  CONTINUE;
                  -- else if returned existing index is not same as index name already present for that feature index
                  -- i.e. in scenarios where backup business key index is present
                ELSIF V_INDEX_NAME_RETURNED = PI_RENAMED_INDEX_NAME THEN
                  --Rename the backup index to the index name created
                  --Replace the old business key with the name generated for the feature
                  V_DDL := 'ALTER INDEX ' || PI_RENAMED_INDEX_NAME ||
                           ' RENAME TO ' || V_INDEX_TO_BE_UPDATED;

                  V_UNDO_DDL := '
                              BEGIN
                              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                V_INDEX_TO_BE_UPDATED ||
                                '''))
                              LOOP
                              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                PI_RENAMED_INDEX_NAME ||
                                ''')))
                              LOOP
                                EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                                V_INDEX_TO_BE_UPDATED || ' RENAME TO ' ||
                                PI_RENAMED_INDEX_NAME || ''';
                              END LOOP ;
                              END LOOP ;
                              END;';

                  --get the transaction id
                  V_TRANSACTION_ID := PI_TRANSACTION_ID;

                  COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                   PI_DESCRIPTION    => 'RENAME INDEX ' ||
                                                                        PI_RENAMED_INDEX_NAME ||
                                                                        ' to Feature Index name ' ||
                                                                        V_INDEX_TO_BE_UPDATED,
                                                   PI_DDL            => V_DDL,
                                                   PI_UNDO_DDL       => V_UNDO_DDL,
                                                   pi_run_id         => pi_run_id);

                  -- Update AIM table to update the index name with the updated (renamed) index
                  -- For every row for that index
                  UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                  .AIM_TABLE_NAME,
                             PI_INDEX_NAME     => V_INDEX_TO_BE_UPDATED,
                             PI_COL_LIST       => NULL,
                             PI_INDEX_TYPE     => 2,
                             PI_OLD_INDEX_NAME => v_index_name);
                  --Returned index is not same as prepared index name, the index name already present in AIM table or PI_RENAMED_INDEX_NAME(renamed business key name )
                ELSE
                  V_RETURNED_INDEX_DDL := REGEXP_REPLACE(V_RETURNED_INDEX_DDL,
                                                         V_INDEX_TO_BE_UPDATED,
                                                         V_INDEX_NAME_RETURNED);
                  --use the index name returned in update_aim metadata
                  UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                  .AIM_TABLE_NAME,
                             PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                             PI_COL_LIST       => NULL,
                             PI_INDEX_TYPE     => 2,
                             PI_OLD_INDEX_NAME => v_index_name);
                END IF;
              END IF;
            EXCEPTION
              --When the column list on which index is to be created is not a valid list i.e. columns might be dropped
              WHEN NO_DATA_FOUND OR E_INVALID_IDENTIFIER THEN
                IF V_AIM_TABLE_INFO(C).AIM_IS_INDEX_TO_BE_RECREATED = 1 THEN
                  --Prepare the valid column list
                  SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30))
                                      ORDER BY ROWNUM) AS SYS.HSBLKNAMLST)
                    INTO V_VALID_COLUMN_LIST
                    FROM (SELECT COLUMN_VALUE
                            FROM TABLE(V_AIM_TABLE_INFO(C)
                                       .AIM_INDEXED_COLUMNS)) t
                   INNER JOIN user_tab_columns utc
                      ON utc.TABLE_NAME = PI_TABLE_NAME
                     AND utc.COLUMN_NAME = t.COLUMN_VALUE;

                  --if the valid column list prepared is containing more than 0 elements, then index has to be created
                  IF V_VALID_COLUMN_LIST.COUNT > 0 THEN
                    --CREATE COMMA SEPARATED LIST OF COLUMN NAMES FROM THE COLLECTION
                    SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
                      INTO V_INDEX_COLUMN_LIST
                      FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS);

                    --check if there is any index, which is covering the index
                    V_COVERING_INDEX := GET_COVERING_INDEX(PI_TABLE_NAME  => V_AIM_TABLE_INFO(C)
                                                                             .AIM_TABLE_NAME,
                                                           PI_COLUMN_LIST => V_INDEX_COLUMN_LIST || '%');

                    IF V_COVERING_INDEX IS NOT NULL THEN
                      --V_RETURNED_INDEX_DDL := REGEXP_REPLACE(V_RETURNED_INDEX_DDL, V_INDEX_TO_BE_UPDATED ,V_COVERING_INDEX );
                      --use the index name returned in update_aim metadata
                      UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                      .AIM_TABLE_NAME,
                                 PI_INDEX_NAME     => V_COVERING_INDEX,
                                 PI_COL_LIST       => NULL,
                                 PI_INDEX_TYPE     => 2,
                                 PI_OLD_INDEX_NAME => v_index_name);

                      V_COLUMN_DROP := 1;
                    ELSE
                      <<CREATE_TOP_APP_IDX_VALID_COL>>
                      BEGIN
                        -- OF-30537 START
                        -- INSERT_LOGS('CREATE_INDEX2 called 2');
                        COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_AIM_TABLE_INFO(C)
                                                                               .AIM_TABLE_NAME,
                                                       PI_INDEX_NAME        => V_INDEX_TO_BE_UPDATED,
                                                       PI_COLUMN_LIST       => V_VALID_COLUMN_LIST,
                                                       PI_UNIQUENESS        => V_AIM_TABLE_INFO(C)
                                                                               .AIM_INDEX_IS_UNIQUE,
                                                       PI_COL_IS_PRIMARYKEY => 0,
                                                       PI_INDEX_TABLESPACE  => PI_TABLESPACE_NAME, \*OF-11821*\
                                                       PI_TRANSACTION_ID    => V_TRANSACTION_ID,
                                                       PI_RUN_ID            => PI_RUN_ID,
                                                       PO_INDEX_STATUS      => V_INDEX_CREATION_STATUS,
                                                       PO_INDEX_NAME        => V_INDEX_NAME_RETURNED,
                                                       PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                                       PO_CREATE_DDL        => V_RETURNED_INDEX_DDL);
                        -- OF-30537 END
                        -- INSERT_LOGS('CREATE_INDEX2 called 2 finished');
                        -- OF-33540
                        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_DEF_ID,
                                                   PI_INDEX_NAME                 => V_INDEX_TO_BE_UPDATED,
                                                   PI_TABLE_NAME                 => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_TABLE_NAME,
                                                   PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                                   PI_RECREATE_INDEX_ON_COL_DROP => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_IS_INDEX_TO_BE_RECREATED,
                                                   PI_BUSINESS_NAME              => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_BUSINESS_NAME,
                                                   PI_IS_UNIQUE                  => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_INDEX_IS_UNIQUE,
                                                   PI_INDEX_TYPE                 => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_INDEX_TYPE,
                                                   PI_STATUS                     => 2);
                        --After successful creation
                        IF V_INDEX_NAME_RETURNED IS NOT NULL THEN
                          --Update AIM table with the index created
                          SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS
                                                   VARCHAR2(30)) ORDER BY
                                              ROWNUM) AS
                                      coltype_indexed_columns_list)
                            INTO V_VALID_COLUMNS_INSERT
                            FROM TABLE(V_VALID_COLUMN_LIST);

                          IF V_INDEX_CREATION_STATUS = 1 THEN
                            INSERT INTO AIM_INDEX_DDL_STORAGE
                              (AIDS_TABLE_NAME,
                               AIDS_INDEX_NAME,
                               AIDS_INDEX_IS_UNIQUE,
                               AIDS_INDEX_IS_PRIMARY,
                               AIDS_INDEX_DDL)
                            VALUES
                              (V_AIM_TABLE_INFO     (C).AIM_TABLE_NAME,
                               V_INDEX_NAME_RETURNED,
                               V_AIM_TABLE_INFO     (C).AIM_INDEX_IS_UNIQUE,
                               0,
                               V_RETURNED_INDEX_DDL);
                          ELSE
                            DELETE FROM AIM_INDEX_DDL_STORAGE AIDS
                             WHERE (AIDS_TABLE_NAME, AIDS_INDEX_NAME) IN
                                   (SELECT AIM_TABLE_NAME, AIM_INDEX_NAME
                                      FROM APPLICATION_INDEXES_METADATA AIM
                                     WHERE AIM.AIM_TABLE_NAME = V_AIM_TABLE_INFO(C)
                                          .AIM_TABLE_NAME
                                       AND AIM.AIM_ID = V_AIM_TABLE_INFO(C)
                                          .AIM_ID
                                       AND NOT EXISTS
                                     (SELECT NULL
                                              FROM APPLICATION_INDEXES_METADATA AIM2
                                             WHERE AIM.AIM_INDEX_NAME =
                                                   AIM2.AIM_INDEX_NAME
                                               AND AIM2.AIM_INDEX_TYPE = 1));
                          END IF;

                          COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                                           .AIM_TABLE_NAME,
                                                      PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                                      PI_COL_LIST       => V_VALID_COLUMNS_INSERT,
                                                      PI_INDEX_TYPE     => 2,
                                                      PI_OLD_INDEX_NAME => v_index_name,
                                                      PI_AIM_ID         => V_AIM_TABLE_INFO(C)
                                                                           .AIM_ID);

                          V_COLUMN_DROP := 1;
                        END IF;
                      END;
                    END IF;
                    --Delete the metadata for the invalid rows
                  ELSE
                    DELETE FROM AIM_INDEX_DDL_STORAGE AIDS
                     WHERE (AIDS_TABLE_NAME, AIDS_INDEX_NAME) IN
                           (SELECT AIM_TABLE_NAME, AIM_INDEX_NAME
                              FROM APPLICATION_INDEXES_METADATA AIM
                             WHERE AIM.AIM_TABLE_NAME = V_AIM_TABLE_INFO(C)
                                  .AIM_TABLE_NAME
                               AND AIM.AIM_ID = V_AIM_TABLE_INFO(C).AIM_ID
                               AND NOT EXISTS
                             (SELECT NULL
                                      FROM APPLICATION_INDEXES_METADATA AIM2
                                     WHERE AIM.AIM_INDEX_NAME =
                                           AIM2.AIM_INDEX_NAME
                                       AND AIM2.AIM_INDEX_TYPE = 1));

                    -- INSERT_LOGS('delete_aim1 : PI_TABLE_NAME => ' || V_AIM_TABLE_INFO(C).AIM_TABLE_NAME  || ' , PI_AIM_ID         =>  ' || V_AIM_TABLE_INFO(C).AIM_ID);
                    commons_indexing.delete_aim1(PI_TABLE_NAME    => V_AIM_TABLE_INFO(C)
                                                                     .AIM_TABLE_NAME,
                                                 PI_INDEX_NAME    => NULL \*V_AIM_TABLE_INFO(C).AIM_INDEX_NAME*\,
                                                 PI_DEFINITION_ID => NULL \*V_AIM_TABLE_INFO(C).AIM_DEF_ID*\,
                                                 PI_BUSINESS_NAME => NULL \*V_AIM_TABLE_INFO(C).AIM_BUSINESS_NAME*\,
                                                 PI_AIM_ID        => V_AIM_TABLE_INFO(C)
                                                                     .AIM_ID);
                  END IF;
                  --Index is not be recreated for the 1st iteration
                ELSE
                  \*                DELETE FROM AIM_INDEX_DDL_STORAGE AIDS WHERE (AIDS_TABLE_NAME,AIDS_INDEX_NAME) in
                  ( SELECT AIM_TABLE_NAME,AIM_INDEX_NAME FROM APPLICATION_INDEXES_METADATA AIM where AIM.AIM_TABLE_NAME = V_AIM_TABLE_INFO(C).AIM_TABLE_NAME
                  and AIM.AIM_ID = V_AIM_TABLE_INFO(C).AIM_ID and not exists (SELECT null from APPLICATION_INDEXES_METADATA AIM2 where AIM.AIM_INDEX_NAME = AIM2.AIM_INDEX_NAME
                  and AIM2.AIM_INDEX_TYPE = 1));*\

                  --Delete the metadata for the row
                  -- INSERT_LOGS('2 - delete_aim1 : PI_TABLE_NAME => ' || V_AIM_TABLE_INFO(C).AIM_TABLE_NAME  || ' , PI_AIM_ID         =>  ' || V_AIM_TABLE_INFO(C).AIM_ID);
                  COMMONS_INDEXING.DELETE_AIM1(PI_TABLE_NAME    => V_AIM_TABLE_INFO(C)
                                                                   .AIM_TABLE_NAME,
                                               PI_INDEX_NAME    => NULL \*V_AIM_TABLE_INFO(C).AIM_INDEX_NAME*\,
                                               PI_DEFINITION_ID => NULL \*V_AIM_TABLE_INFO(C).AIM_DEF_ID*\,
                                               PI_BUSINESS_NAME => NULL \*V_AIM_TABLE_INFO(C).AIM_BUSINESS_NAME*\,
                                               PI_AIM_ID        => V_AIM_TABLE_INFO(C)
                                                                   .AIM_ID);

                  --and set the index name to null;
                  -- For the next iteration
                  v_index_name := '';
                END IF;
            END;
            --For 2nd iteration within a same index group/
          ELSE
            --V_COLUMN_DROP = 1 i.e. column has got renamed (functional rename)
            IF V_COLUMN_DROP != 1 THEN
              -- update the index_name of AIM table with the index name V_INDEX_TO_BE_UPDATED
              CONTINUE;
            ELSIF V_COLUMN_DROP = 1 THEN
              SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30))
                                  ORDER BY ROWNUM) AS
                          coltype_indexed_columns_list)
                INTO V_VALID_COLUMNS_INSERT
                FROM (SELECT COLUMN_VALUE
                        FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS)) t
               INNER JOIN user_tab_columns utc
                  ON utc.TABLE_NAME = PI_TABLE_NAME
                 AND utc.COLUMN_NAME = t.COLUMN_VALUE;

              --column count in AIM table and valid columns are not same
              IF V_AIM_TABLE_INFO(C)
               .AIM_INDEXED_COLUMNS.COUNT != V_VALID_COLUMNS_INSERT.COUNT THEN
                --Based on whether index is to be recreated
                IF V_AIM_TABLE_INFO(C).AIM_IS_INDEX_TO_BE_RECREATED = 0 OR
                    V_VALID_COLUMNS_INSERT.COUNT = 0 THEN
                  \*                DELETE FROM AIM_INDEX_DDL_STORAGE AIDS WHERE (AIDS_TABLE_NAME,AIDS_INDEX_NAME) in
                  ( SELECT AIM_TABLE_NAME,AIM_INDEX_NAME FROM APPLICATION_INDEXES_METADATA AIM where AIM.AIM_TABLE_NAME = V_AIM_TABLE_INFO(C).AIM_TABLE_NAME
                  and AIM.AIM_ID = V_AIM_TABLE_INFO(C).AIM_ID and not exists (SELECT null from APPLICATION_INDEXES_METADATA AIM2 where AIM2.AIM_INDEX_NAME = AIM.AIM_INDEX_NAME
                  and AIM2.AIM_INDEX_TYPE = 1));  *\

                  --Delete the metadata for the index
                  -- INSERT_LOGS(' 3 - delete_aim1 : PI_TABLE_NAME => ' || V_AIM_TABLE_INFO(C).AIM_TABLE_NAME  || ' , PI_AIM_ID         =>  ' || V_AIM_TABLE_INFO(C).AIM_ID);
                  COMMONS_INDEXING.DELETE_AIM1(PI_TABLE_NAME    => V_AIM_TABLE_INFO(C)
                                                                   .AIM_TABLE_NAME,
                                               PI_INDEX_NAME    => NULL \*V_AIM_TABLE_INFO(C).AIM_INDEX_NAME*\,
                                               PI_DEFINITION_ID => NULL \*V_AIM_TABLE_INFO(C).AIM_DEF_ID*\,
                                               PI_BUSINESS_NAME => NULL \*V_AIM_TABLE_INFO(C).AIM_BUSINESS_NAME*\,
                                               PI_AIM_ID        => V_AIM_TABLE_INFO(C)
                                                                   .AIM_ID);
                  -- update AIM table with column list
                ELSE
                  COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                                   .AIM_TABLE_NAME,
                                              PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                              PI_COL_LIST       => V_VALID_COLUMNS_INSERT,
                                              PI_INDEX_TYPE     => 2,
                                              PI_OLD_INDEX_NAME => v_index_name,
                                              PI_AIM_ID         => V_AIM_TABLE_INFO(C)
                                                                   .AIM_ID);
                END IF;
                --update the AIM table with index name, column list remains same
              ELSIF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT =
                     V_VALID_COLUMNS_INSERT.COUNT THEN
                COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                                 .AIM_TABLE_NAME,
                                            PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                            PI_COL_LIST       => V_VALID_COLUMNS_INSERT,
                                            PI_INDEX_TYPE     => 2,
                                            PI_OLD_INDEX_NAME => v_index_name,
                                            PI_AIM_ID         => V_AIM_TABLE_INFO(C)
                                                                 .AIM_ID);
              END IF;
            END IF;
          END IF;
        END LOOP;
      END IF;
    ELSIF PI_INDEX_UPDATE_MODE = 2 THEN
      --Feature indexes depending on this index need to be updated
      FOR c IN (SELECT AIM.*,
                       (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                          FROM TABLE(AIM.AIM_INDEXED_COLUMNS)) AIM_INDEXED_COLUMNS_LIST
                  FROM APPLICATION_INDEXES_METADATA AIM
                 WHERE AIM.AIM_INDEX_NAME = PI_DELETED_INDEX_NAME
                   AND AIM.AIM_TABLE_NAME = PI_TABLE_NAME
                   AND AIM_INDEX_TYPE != 1
                 ORDER BY REGEXP_COUNT(AIM_INDEXED_COLUMNS_LIST, ',') DESC) LOOP
        SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS tabletype_charmax)
          INTO v_valid_columns_collection
          FROM TABLE(c.aim_indexed_columns) t
         INNER JOIN user_tab_columns utc
            ON utc.TABLE_NAME = c.aim_table_name
           AND utc.COLUMN_NAME = t.COLUMN_VALUE;

        --DELETE the metadata
        \*      COMMONS_INDEXING.DELETE_AIM_BY_DEFID_AND_BNAME(PI_TABLE_NAME    => PI_TABLE_NAME,
        PI_DEFINITION_ID => c.aim_def_id,
        PI_BUSINESS_NAME => c.aim_business_name);*\

        DELETE FROM APPLICATION_INDEXES_METADATA AIM
         WHERE AIM.AIM_BUSINESS_NAME = c.aim_business_name
           AND AIM.AIM_DEF_ID = c.aim_def_id
           AND AIM.AIM_TABLE_NAME = PI_TABLE_NAME;
        -- OF-33540
        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => c.AIM_DEF_ID,
                                   PI_INDEX_NAME                 => PI_DELETED_INDEX_NAME,
                                   PI_TABLE_NAME                 => PI_TABLE_NAME,
                                   PI_COLUMN_LIST                => c.AIM_INDEXED_COLUMNS_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => c.AIM_IS_INDEX_TO_BE_RECREATED,
                                   PI_BUSINESS_NAME              => c.AIM_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => c.AIM_INDEX_IS_UNIQUE,
                                   PI_INDEX_TYPE                 => c.AIM_INDEX_TYPE,
                                   PI_STATUS                     => 3);
        --     DELETE FROM APPLICATION_INDEXES_METADATA AIM WHERE AIM.AIM_DEF_ID = c.aim_def_id and AIM.AIM_BUSINESS_NAME = c.aim_business_name and AIM.AIM_TABLE_NAME = PI_TABLE_NAME;

        COMMONS_INDEXING.CREATE_APP_INDEX(PI_TABLES_ID                  => V_TABLES_ID,
                                          PI_COLUMN_LIST                => v_valid_columns_collection,
                                          PI_IS_UNIQUE                  => 0,
                                          PI_DEF_ID                     => c.aim_def_id,
                                          PI_BUSINESS_NAME              => c.aim_business_name,
                                          PI_RECREATE_INDEX_ON_COL_DROP => c.aim_is_index_to_be_recreated,
                                          PI_RUN_ID                     => PI_RUN_ID,
                                          PI_TABLE_NAME                 => PI_TABLE_NAME,
                                          PI_TRANSACTION_ID             => V_TRANSACTION_ID,
                                          PI_INDEX_TABLESPACE_NAME      => PI_TABLESPACE_NAME,
                                          PO_INDEX_CREATION_STATUS      => V_OUT_CREATION_STATUS);
      END LOOP;
    END IF;

    DELETE FROM AIM_INDEX_DDL_STORAGE
     WHERE AIDS_TABLE_NAME = PI_TABLE_NAME
       AND AIDS_INDEX_NAME NOT IN
           (SELECT INDEX_NAME
              FROM USER_INDEXES
             WHERE TABLE_NAME = PI_TABLE_NAME);
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
    -- INSERT_LOGS('UPDATE_APP_INDEX1 ended');
  END UPDATE_APP_INDEX1;*/

  PROCEDURE UPDATE_APP_INDEX(PI_TABLE_NAME         IN VARCHAR2,
                             PI_RENAMED_INDEX_NAME IN VARCHAR2,
                             PI_TRANSACTION_ID     IN VARCHAR2,
                             -- PI_INDEX_UPDATE_MODE determines whether update happens from UPDATE_INDEXES call
                             -- or DELETE_APP_INDEXES call
                             PI_INDEX_UPDATE_MODE  IN NUMBER, --1 - Update_indexes 2. DELETE_APP_INDEXES
                             PI_DELETED_INDEX_NAME IN VARCHAR2,
                             PI_TABLESPACE_NAME    IN VARCHAR2,
                             PI_RUN_ID             IN NUMBER DEFAULT NULL,
                             PI_TABLES_ID          IN NUMBER) IS
    v_index_name  VARCHAR2(30) := '';
    v_index_name1 VARCHAR2(30) := '';

    --PI_TABLE_NAME VARCHAR2(30);
    --PI_RENAMED_INDEX_NAME VARCHAR2(30);

    TYPE TABLETYPE_AIM_TABLE_INFO IS TABLE OF APPLICATION_INDEXES_METADATA%ROWTYPE;

    V_AIM_TABLE_INFO TABLETYPE_AIM_TABLE_INFO;

    V_INDEX_COLUMN_LIST   VARCHAR2(1000);
    V_INDEX_TO_BE_UPDATED VARCHAR2(30);

    V_INDEX_CREATION_STATUS NUMBER;
    V_INDEX_NAME_RETURNED   VARCHAR2(30);
    V_UNIQUENESS_RETURNED   VARCHAR2(9);
    V_RETURNED_INDEX_DDL    CLOB;
    V_TRANSACTION_ID        VARCHAR2(50) := PI_TRANSACTION_ID;
    V_DDL                   CLOB;
    V_UNDO_DDL              CLOB;
    V_UPDATE_COUNT          NUMBER(1) := NULL; --added as part of OF-19375
    E_INVALID_IDENTIFIER EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_INVALID_IDENTIFIER, -904);
    --Variable to determine if indexes are getting updated because of column drop (renaming of column)
    V_COLUMN_DROP              NUMBER := 1;
    V_VALID_COLUMN_LIST        SYS.HSBLKNAMLST;
    V_VALID_COLUMNS_INSERT     coltype_indexed_columns_list;
    V_VALID_COLUMNS_COLLECTION TABLETYPE_CHARMAX;
    V_TABLES_ID                NUMBER := PI_TABLES_ID;
    V_OUT_CREATION_STATUS      NUMBER;
    V_INDEX_TABLESPACE_NAME    VARCHAR2(30 CHAR) := PI_TABLESPACE_NAME; /*OF-11821*/

  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- INSERT_LOGS('UPDATE_APP_INDEX started');

    --sales planning change
    --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

    IF PI_RENAMED_INDEX_NAME like 'APP%' THEN
      IF PI_INDEX_UPDATE_MODE = 1 THEN
        --Get the metadata info for feature indexes in a collection
        -- with index names in a group and column list in descending order within each index group
        SELECT AIM.AIM_ID,
               AIM.AIM_DEF_ID,
               AIM.AIM_BUSINESS_NAME,
               AIM.AIM_INDEX_NAME,
               AIM.AIM_TABLE_NAME,
               AIM.AIM_IS_INDEX_TO_BE_RECREATED,
               AIM.AIM_INDEXED_COLUMNS,
               AIM.AIM_INDEX_IS_UNIQUE,
               AIM.AIM_INDEX_TYPE,
               AIM.AIM_IS_ENABLED,
               AIM.AIM_CREATION_DATE,
               AIM.AIM_LAST_UPDATE_DATE
          BULK COLLECT
          INTO V_AIM_TABLE_INFO
          FROM APPLICATION_INDEXES_METADATA AIM
         WHERE AIM.AIM_TABLE_NAME = PI_TABLE_NAME
           AND AIM.AIM_INDEX_TYPE = 2
         ORDER BY AIM.AIM_INDEX_NAME,
                  REGEXP_COUNT((SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
                                 FROM TABLE(AIM.AIM_INDEXED_COLUMNS)),
                               ',') DESC;

        -- INSERT_LOGS(' V_AIM_TABLE_INFO.COUNT = ' || V_AIM_TABLE_INFO.COUNT);
        IF V_AIM_TABLE_INFO.COUNT > 0 THEN
          --Loop through the collection
          FOR C IN V_AIM_TABLE_INFO.FIRST .. V_AIM_TABLE_INFO.LAST LOOP
            v_index_name1 := V_AIM_TABLE_INFO(C).AIM_INDEX_NAME;
            -- INSERT_LOGS(' V_AIM_TABLE_INFO(C).AIM_INDEX_NAME = ' || V_AIM_TABLE_INFO(C).AIM_INDEX_NAME || 'V_AIM_TABLE_INFO(C).AIM_INDEX_TYPE = ' || V_AIM_TABLE_INFO(C).AIM_INDEX_TYPE);

            --For every 1st index within each group, this condition will always be true
            --create index for every first row within each index group
            IF NVL(v_index_name1, 'a') <> NVL(v_index_name, 'b') THEN
              -- assign the index name to the variable
              -- so that consequent feature indexes with same name can be just updated
              v_index_name := V_AIM_TABLE_INFO(C).AIM_INDEX_NAME;

              -- OF-31694 - START
              --Prepare the index name to be created
              /*
              IF V_AIM_TABLE_INFO(C).AIM_INDEX_IS_UNIQUE = 1
              THEN
                V_INDEX_TO_BE_UPDATED := 'APP_' || PI_TABLE_NAME || '_' || APP_INDEX_NAME_SEQ.NEXTVAL || '_UI';
              ELSIF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT > 1 AND V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT < 33
              THEN
                V_INDEX_TO_BE_UPDATED := 'APP_' || PI_TABLE_NAME || '_' || APP_INDEX_NAME_SEQ.NEXTVAL || '_CI';
              ELSE
                V_INDEX_TO_BE_UPDATED := 'APP_' || PI_TABLE_NAME || '_' || APP_INDEX_NAME_SEQ.NEXTVAL || '_SI';
              END IF; -- IF_7 END
              */

              --sales planning change; tables_id will be input to proc

              /*SELECT TABLES_ID
               INTO V_TABLES_ID
               FROM TABLES
              WHERE TABLES_PHYSICAL_NAMe = PI_TABLE_NAME;*/

              V_INDEX_TO_BE_UPDATED := 'APP_' || 'T' || V_TABLES_ID || '_' ||
                                       APP_INDEX_NAME_SEQ.NEXTVAL;

              IF V_AIM_TABLE_INFO(C).AIM_INDEX_IS_UNIQUE = 1 THEN
                V_INDEX_TO_BE_UPDATED := V_INDEX_TO_BE_UPDATED || '_UI';
              ELSIF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT > 1 AND V_AIM_TABLE_INFO(C)
                    .AIM_INDEXED_COLUMNS.COUNT < 33 THEN
                V_INDEX_TO_BE_UPDATED := V_INDEX_TO_BE_UPDATED || '_CI';
              ELSE
                V_INDEX_TO_BE_UPDATED := V_INDEX_TO_BE_UPDATED || '_SI';
              END IF; -- IF_7 END
              -- OF-31694 - START

              -- Get the column list from the collection into comma-separated
              SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                INTO V_INDEX_COLUMN_LIST
                FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS);

              SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                                  ROWNUM) AS SYS.HSBLKNAMLST)
                INTO V_VALID_COLUMN_LIST
                FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS);

              --Call Create Index for the the given column list
              <<CREATE_INDEX_TOP_APP_INDEX>>
              BEGIN
                -- OF-30537 START
                -- INSERT_LOGS('CREATE_INDEX2 called 3');
                -- INSERT_LOGS('--PI_TABLE_NAME='||V_AIM_TABLE_INFO(C).AIM_TABLE_NAME||'--PI_INDEX_NAME='||V_INDEX_TO_BE_UPDATED||'--PI_COLUMN_LIST='||V_INDEX_COLUMN_LIST||'--PI_UNIQUENESS='||V_AIM_TABLE_INFO(C).AIM_INDEX_IS_UNIQUE||'--PI_INDEX_TABLESPACE='||PI_TABLESPACE_NAME||'--PI_RUN_ID='||PI_RUN_ID);
                COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_AIM_TABLE_INFO(C)
                                                                       .AIM_TABLE_NAME,
                                               PI_INDEX_NAME        => V_INDEX_TO_BE_UPDATED,
                                               PI_COLUMN_LIST       => V_VALID_COLUMN_LIST /*SYS.HSBLKNAMLST(V_INDEX_COLUMN_LIST)*/,
                                               PI_UNIQUENESS        => V_AIM_TABLE_INFO(C)
                                                                       .AIM_INDEX_IS_UNIQUE,
                                               PI_COL_IS_PRIMARYKEY => 0,
                                               PI_INDEX_TABLESPACE  => PI_TABLESPACE_NAME, /*OF-11821*/
                                               PI_TRANSACTION_ID    => V_TRANSACTION_ID, --sales change
                                               PI_RUN_ID            => PI_RUN_ID,
                                               PO_INDEX_STATUS      => V_INDEX_CREATION_STATUS,
                                               PO_INDEX_NAME        => V_INDEX_NAME_RETURNED,
                                               PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                               PO_CREATE_DDL        => V_RETURNED_INDEX_DDL);
                -- OF-30537 END
                -- INSERT_LOGS('CREATE_INDEX2 called 3 finished -- V_INDEX_CREATION_STATUS ' || V_INDEX_CREATION_STATUS || ' -- V_INDEX_NAME_RETURNED = ' || V_INDEX_NAME_RETURNED || ' -- V_UNIQUENESS_RETURNED = ' || V_UNIQUENESS_RETURNED);
                COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => V_AIM_TABLE_INFO(C)
                                                                            .AIM_DEF_ID,
                                           PI_INDEX_NAME                 => V_INDEX_TO_BE_UPDATED,
                                           PI_TABLE_NAME                 => V_AIM_TABLE_INFO(C)
                                                                            .AIM_TABLE_NAME,
                                           PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                           PI_RECREATE_INDEX_ON_COL_DROP => V_AIM_TABLE_INFO(C)
                                                                            .AIM_IS_INDEX_TO_BE_RECREATED,
                                           PI_BUSINESS_NAME              => V_AIM_TABLE_INFO(C)
                                                                            .AIM_BUSINESS_NAME,
                                           PI_IS_UNIQUE                  => V_AIM_TABLE_INFO(C)
                                                                            .AIM_INDEX_IS_UNIQUE,
                                           PI_INDEX_TYPE                 => V_AIM_TABLE_INFO(C)
                                                                            .AIM_INDEX_TYPE,
                                           PI_STATUS                     => 2);
                -- if returned index name is equal to prepared index name
                -- i.e. a new index has been created
                IF V_INDEX_CREATION_STATUS = 1 THEN
                  --update AIM table to update the index name with the updated (newly created) index
                  -- For every row for that index
                  UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                  .AIM_TABLE_NAME,
                             PI_INDEX_NAME     => V_INDEX_TO_BE_UPDATED,
                             PI_COL_LIST       => NULL,
                             PI_INDEX_TYPE     => 2,
                             PI_OLD_INDEX_NAME => v_index_name,
                             PO_UPDATE_COUNT   => V_UPDATE_COUNT);  --added as part of OF-19375

                  INSERT INTO AIM_INDEX_DDL_STORAGE
                    (AIDS_TABLE_NAME,
                     AIDS_INDEX_NAME,
                     AIDS_INDEX_IS_UNIQUE,
                     AIDS_INDEX_IS_PRIMARY,
                     AIDS_INDEX_DDL)
                  VALUES
                    (V_AIM_TABLE_INFO     (C).AIM_TABLE_NAME,
                     V_INDEX_TO_BE_UPDATED,
                     V_AIM_TABLE_INFO     (C).AIM_INDEX_IS_UNIQUE,
                     0,
                     V_RETURNED_INDEX_DDL);
                  -- i.e. no change of index
                ELSIF V_INDEX_CREATION_STATUS = 2 THEN
                  -- if returned index name is same as index already present for that feature index
                  IF V_INDEX_NAME_RETURNED = v_index_name THEN
                    --continue for the next iteration
                    CONTINUE;
                    -- else if returned existing index is not same as index name already present for that feature index
                    -- i.e. in scenarios where backup business key index is present
                  ELSIF V_INDEX_NAME_RETURNED = PI_RENAMED_INDEX_NAME THEN
                    --Rename the backup index to the index name created
                    --Replace the old business key with the name generated for the feature
                    V_DDL := 'ALTER INDEX ' || PI_RENAMED_INDEX_NAME ||
                             ' RENAME TO ' || V_INDEX_TO_BE_UPDATED;

                    V_UNDO_DDL := '
                              BEGIN
                              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                  V_INDEX_TO_BE_UPDATED ||
                                  '''))
                              LOOP
                              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                  PI_RENAMED_INDEX_NAME ||
                                  ''')))
                              LOOP
                                EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                                  V_INDEX_TO_BE_UPDATED || ' RENAME TO ' ||
                                  PI_RENAMED_INDEX_NAME || ''';
                              END LOOP ;
                              END LOOP ;
                              END;';

                    --get the transaction id
                    V_TRANSACTION_ID := PI_TRANSACTION_ID;

                    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                     PI_DESCRIPTION    => 'RENAME INDEX ' ||
                                                                          PI_RENAMED_INDEX_NAME ||
                                                                          ' to Feature Index name ' ||
                                                                          V_INDEX_TO_BE_UPDATED,
                                                     PI_DDL            => V_DDL,
                                                     PI_UNDO_DDL       => V_UNDO_DDL,
                                                     pi_run_id         => pi_run_id);

                    --Update Index Name
                    UPDATE AIM_INDEX_DDL_STORAGE AIDS
                       SET AIDS_INDEX_NAME     = REGEXP_REPLACE(AIDS_INDEX_NAME,
                                                                v_index_name,
                                                                V_INDEX_TO_BE_UPDATED),
                           AIDS.AIDS_INDEX_DDL = REGEXP_REPLACE(AIDS_INDEX_DDL,
                                                                v_index_name,
                                                                V_INDEX_TO_BE_UPDATED)
                     WHERE AIDS_TABLE_NAME = V_AIM_TABLE_INFO(C)
                          .AIM_TABLE_NAME
                       AND AIDS_INDEX_NAME = v_index_name;

                    -- Update AIM table to update the index name with the updated (renamed) index
                    -- For every row for that index
                    UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                    .AIM_TABLE_NAME,
                               PI_INDEX_NAME     => V_INDEX_TO_BE_UPDATED,
                               PI_COL_LIST       => NULL,
                               PI_INDEX_TYPE     => 2,
                               PI_OLD_INDEX_NAME => v_index_name,
                               PO_UPDATE_COUNT   => V_UPDATE_COUNT); --added as part of OF-19375
                    --Returned index is not same as prepared index name, the index name already present in AIM table or PI_RENAMED_INDEX_NAME(renamed business key name )
                  ELSE
                    --use the index name returned in update_aim metadata
                    UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                    .AIM_TABLE_NAME,
                               PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                               PI_COL_LIST       => NULL,
                               PI_INDEX_TYPE     => 2,
                               PI_OLD_INDEX_NAME => v_index_name,
                               PO_UPDATE_COUNT   => V_UPDATE_COUNT); --added as part of OF-19375;
                  END IF;
                END IF;
              EXCEPTION
                WHEN NO_DATA_FOUND OR E_INVALID_IDENTIFIER THEN
                  IF V_AIM_TABLE_INFO(C).AIM_IS_INDEX_TO_BE_RECREATED = 1 THEN
                    -- OF-30537 START
                    --Prepare the valid column list
                    /*
                                                    SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                                                      INTO V_INDEX_COLUMN_LIST
                                                      FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS)
                                                     INNER JOIN USER_TAB_COLUMNS UTC
                                                        ON UTC.COLUMN_NAME = COLUMN_VALUE
                                                     WHERE UTC.TABLE_NAME = PI_TABLE_NAME;
                    */
                    SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30))
                                        ORDER BY ROWNUM) AS SYS.HSBLKNAMLST)
                      INTO V_VALID_COLUMN_LIST
                      FROM (SELECT COLUMN_VALUE
                              FROM TABLE(V_AIM_TABLE_INFO(C)
                                         .AIM_INDEXED_COLUMNS)) t
                     INNER JOIN user_tab_columns utc
                        ON utc.TABLE_NAME = PI_TABLE_NAME
                       AND utc.COLUMN_NAME = t.COLUMN_VALUE;

                    --V_VALID_COLUMN_LIST := SYS.HSBLKNAMLST(V_INDEX_COLUMN_LIST);

                    SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
                      INTO V_INDEX_COLUMN_LIST
                      FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS)
                     INNER JOIN USER_TAB_COLUMNS UTC
                        ON UTC.COLUMN_NAME = COLUMN_VALUE
                     WHERE UTC.TABLE_NAME = PI_TABLE_NAME;

                    --if the valid column list prepared is containing more than 0 elements
                    IF V_VALID_COLUMN_LIST.COUNT > 0 THEN
                      <<CREATE_TOP_APP_IDX_VALID_COL>>
                      BEGIN

                        COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_AIM_TABLE_INFO(C)
                                                                               .AIM_TABLE_NAME,
                                                       PI_INDEX_NAME        => V_INDEX_TO_BE_UPDATED,
                                                       PI_COLUMN_LIST       => V_VALID_COLUMN_LIST,
                                                       PI_UNIQUENESS        => V_AIM_TABLE_INFO(C)
                                                                               .AIM_INDEX_IS_UNIQUE,
                                                       PI_COL_IS_PRIMARYKEY => 0,
                                                       PI_INDEX_TABLESPACE  => PI_TABLESPACE_NAME, /*OF-11821*/
                                                       PI_TRANSACTION_ID    => V_TRANSACTION_ID, --sales change
                                                       PI_RUN_ID            => PI_RUN_ID,
                                                       PO_INDEX_STATUS      => V_INDEX_CREATION_STATUS,
                                                       PO_INDEX_NAME        => V_INDEX_NAME_RETURNED,
                                                       PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                                       PO_CREATE_DDL        => V_RETURNED_INDEX_DDL);
                        -- OF-30537 END
                        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_DEF_ID,
                                                   PI_INDEX_NAME                 => V_INDEX_TO_BE_UPDATED,
                                                   PI_TABLE_NAME                 => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_TABLE_NAME,
                                                   PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                                   PI_RECREATE_INDEX_ON_COL_DROP => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_IS_INDEX_TO_BE_RECREATED,
                                                   PI_BUSINESS_NAME              => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_BUSINESS_NAME,
                                                   PI_IS_UNIQUE                  => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_INDEX_IS_UNIQUE,
                                                   PI_INDEX_TYPE                 => V_AIM_TABLE_INFO(C)
                                                                                    .AIM_INDEX_TYPE,
                                                   PI_STATUS                     => 2);
                        --After successful creation
                        IF V_INDEX_NAME_RETURNED IS NOT NULL THEN
                          --Update AIM table with the index created
                          SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS
                                                   VARCHAR2(30)) ORDER BY
                                              ROWNUM) AS
                                      coltype_indexed_columns_list)
                            INTO V_VALID_COLUMNS_INSERT
                            FROM TABLE(V_VALID_COLUMN_LIST);

                          IF V_INDEX_CREATION_STATUS = 1 THEN
                            INSERT INTO AIM_INDEX_DDL_STORAGE
                              (AIDS_TABLE_NAME,
                               AIDS_INDEX_NAME,
                               AIDS_INDEX_IS_UNIQUE,
                               AIDS_INDEX_IS_PRIMARY,
                               AIDS_INDEX_DDL)
                            VALUES
                              (V_AIM_TABLE_INFO     (C).AIM_TABLE_NAME,
                               V_INDEX_NAME_RETURNED,
                               V_AIM_TABLE_INFO     (C).AIM_INDEX_IS_UNIQUE,
                               0,
                               V_RETURNED_INDEX_DDL);
                          END IF;

                          COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                                           .AIM_TABLE_NAME,
                                                      PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                                      PI_COL_LIST       => V_VALID_COLUMNS_INSERT,
                                                      PI_INDEX_TYPE     => 2,
                                                      PI_OLD_INDEX_NAME => v_index_name,
                                                      PI_AIM_ID         => V_AIM_TABLE_INFO(C)
                                                                           .AIM_ID,
                                                      PO_UPDATE_COUNT   => V_UPDATE_COUNT); --added as part of OF-19375;

                          V_COLUMN_DROP := 1;
                        END IF;
                      END;
                      --Delete the metadata for the invalid rows
                    ELSE
                      -- INSERT_LOGS(' 4 - delete_aim1 : PI_TABLE_NAME => ' || V_AIM_TABLE_INFO(C).AIM_TABLE_NAME  || ' , PI_AIM_ID         =>  ' || V_AIM_TABLE_INFO(C).AIM_ID);
                      COMMONS_INDEXING.DELETE_AIM1(PI_TABLE_NAME    => V_AIM_TABLE_INFO(C)
                                                                       .AIM_TABLE_NAME,
                                                   PI_INDEX_NAME    => NULL /*V_AIM_TABLE_INFO(C).AIM_INDEX_NAME*/,
                                                   PI_DEFINITION_ID => NULL /*V_AIM_TABLE_INFO(C).AIM_DEF_ID*/,
                                                   PI_BUSINESS_NAME => NULL /*V_AIM_TABLE_INFO(C).AIM_BUSINESS_NAME*/,
                                                   PI_AIM_ID        => V_AIM_TABLE_INFO(C)
                                                                       .AIM_ID);
                      NULL;
                    END IF;
                    --Index is not be recreated for the 1st iteration
                  ELSE
                    --Delete the metadata for the row
                    -- INSERT_LOGS(' 5 - delete_aim1 : PI_TABLE_NAME => ' || V_AIM_TABLE_INFO(C).AIM_TABLE_NAME  || ' , PI_AIM_ID         =>  ' || V_AIM_TABLE_INFO(C).AIM_ID);
                    COMMONS_INDEXING.DELETE_AIM1(PI_TABLE_NAME    => V_AIM_TABLE_INFO(C)
                                                                     .AIM_TABLE_NAME,
                                                 PI_INDEX_NAME    => NULL /*V_AIM_TABLE_INFO(C).AIM_INDEX_NAME*/,
                                                 PI_DEFINITION_ID => NULL /*V_AIM_TABLE_INFO(C).AIM_DEF_ID*/,
                                                 PI_BUSINESS_NAME => NULL /*V_AIM_TABLE_INFO(C).AIM_BUSINESS_NAME*/,
                                                 PI_AIM_ID        => V_AIM_TABLE_INFO(C)
                                                                     .AIM_ID);

                    --and set the index name to null;
                    -- For the next iteration
                    v_index_name := '';
                  END IF;
              END;
              --For 2nd iteration within a same index group/
            ELSE
              --V_COLUMN_DROP = 1 i.e. column has got renamed (functional rename)
              IF V_COLUMN_DROP != 1 THEN
                -- update the index_name of AIM table with the index name V_INDEX_TO_BE_UPDATED
                CONTINUE;
              ELSIF V_COLUMN_DROP = 1 THEN
                --Prepare the valid column list
                /*            SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                 INTO V_INDEX_COLUMN_LIST
                 FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS)
                INNER JOIN USER_TAB_COLUMNS UTC
                   ON UTC.COLUMN_NAME = COLUMN_VALUE
                WHERE UTC.TABLE_NAME = PI_TABLE_NAME;*/

                SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30))
                                    ORDER BY ROWNUM) AS
                            coltype_indexed_columns_list)
                  INTO V_VALID_COLUMNS_INSERT
                  FROM (SELECT COLUMN_VALUE
                          FROM TABLE(V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS)) t
                 INNER JOIN user_tab_columns utc
                    ON utc.TABLE_NAME = PI_TABLE_NAME
                   AND utc.COLUMN_NAME = t.COLUMN_VALUE;

                --V_VALID_COLUMN_LIST := SYS.HSBLKNAMLST(V_INDEX_COLUMN_LIST);

                --column count in AIM table and valid columns are not same
                IF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT !=
                    V_VALID_COLUMNS_INSERT.COUNT THEN
                  --Based on whether index is to be recreated
                  IF V_AIM_TABLE_INFO(C).AIM_IS_INDEX_TO_BE_RECREATED = 0 OR
                      V_VALID_COLUMNS_INSERT.COUNT = 0 THEN
                    --Delete the metadata for the index
                    -- INSERT_LOGS(' 7 - delete_aim1 : PI_TABLE_NAME => ' || V_AIM_TABLE_INFO(C).AIM_TABLE_NAME  || ' , PI_AIM_ID         =>  ' || V_AIM_TABLE_INFO(C).AIM_ID);
                    commons_indexing.delete_aim1(PI_TABLE_NAME    => V_AIM_TABLE_INFO(C)
                                                                     .AIM_TABLE_NAME,
                                                 PI_INDEX_NAME    => NULL /*V_AIM_TABLE_INFO(C).AIM_INDEX_NAME*/,
                                                 PI_DEFINITION_ID => NULL /*V_AIM_TABLE_INFO(C).AIM_DEF_ID*/,
                                                 PI_BUSINESS_NAME => NULL /*V_AIM_TABLE_INFO(C).AIM_BUSINESS_NAME*/,
                                                 PI_AIM_ID        => V_AIM_TABLE_INFO(C)
                                                                     .AIM_ID);
                    -- update AIM table with column list
                  ELSE
                    COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                                     .AIM_TABLE_NAME,
                                                PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                                PI_COL_LIST       => V_VALID_COLUMNS_INSERT,
                                                PI_INDEX_TYPE     => 2,
                                                PI_OLD_INDEX_NAME => v_index_name,
                                                PI_AIM_ID         => V_AIM_TABLE_INFO(C)
                                                                     .AIM_ID,
                                                PO_UPDATE_COUNT   => V_UPDATE_COUNT); --added as part of OF-19375;
                  END IF;
                  --update the AIM table with index name, column list remains same
                ELSIF V_AIM_TABLE_INFO(C).AIM_INDEXED_COLUMNS.COUNT =
                       V_VALID_COLUMNS_INSERT.COUNT THEN
                  COMMONS_INDEXING.UPDATE_AIM(PI_TABLE_NAME     => V_AIM_TABLE_INFO(C)
                                                                   .AIM_TABLE_NAME,
                                              PI_INDEX_NAME     => V_INDEX_NAME_RETURNED,
                                              PI_COL_LIST       => NULL,
                                              PI_INDEX_TYPE     => 2,
                                              PI_OLD_INDEX_NAME => v_index_name,
                                              PI_AIM_ID         => V_AIM_TABLE_INFO(C)
                                                                   .AIM_ID,
                                              PO_UPDATE_COUNT   => V_UPDATE_COUNT); --added as part of OF-19375;
                END IF;
              END IF;
            END IF;
          END LOOP;
        END IF;
      ELSIF PI_INDEX_UPDATE_MODE = 2 THEN
        --Feature indexes depending on this index need to be updated
        FOR c IN (SELECT AIM.*,
                         (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                            FROM TABLE(AIM.AIM_INDEXED_COLUMNS)) AIM_INDEXED_COLUMNS_LIST
                    FROM APPLICATION_INDEXES_METADATA AIM
                   WHERE AIM.AIM_INDEX_NAME = PI_DELETED_INDEX_NAME
                     AND AIM.AIM_TABLE_NAME = PI_TABLE_NAME
                     AND AIM_INDEX_TYPE != 1
                   ORDER BY REGEXP_COUNT(AIM_INDEXED_COLUMNS_LIST, ',') DESC) LOOP
          SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                              ROWNUM) AS tabletype_charmax)
            INTO v_valid_columns_collection
            FROM TABLE(c.aim_indexed_columns) t
           INNER JOIN user_tab_columns utc
              ON utc.TABLE_NAME = c.aim_table_name
             AND utc.COLUMN_NAME = t.COLUMN_VALUE;

          --V_VALID_COLUMNS_COLLECTION := TABLETYPE_CHARMAX(c.aim_indexed_columns_list);
          /*      --Get the valid list of columns to be indexed
          SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                              ROWNUM) AS tabletype_charmax)
            INTO v_valid_columns_collection
            from (SELECT COLUMN_VALUE from TABLE(c.aim_indexed_columns)) t
           inner join user_tab_columns utc
              on utc.TABLE_NAME = c.aim_table_name
             and utc.COLUMN_NAME = t.COLUMN_VALUE;*/

          --DELETE the metadata
          /*      COMMONS_INDEXING.delete_aim_BY_DEFID_AND_BNAME(PI_TABLE_NAME    => PI_TABLE_NAME,
          PI_DEFINITION_ID => c.aim_def_id,
          PI_BUSINESS_NAME => c.aim_business_name);*/

          DELETE FROM APPLICATION_INDEXES_METADATA AIM
           WHERE AIM.AIM_BUSINESS_NAME = c.aim_business_name
             AND AIM.AIM_DEF_ID = c.aim_def_id
             AND AIM.AIM_TABLE_NAME = PI_TABLE_NAME;
          -- OF-33540
          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => c.AIM_DEF_ID,
                                     PI_INDEX_NAME                 => PI_DELETED_INDEX_NAME,
                                     PI_TABLE_NAME                 => PI_TABLE_NAME,
                                     PI_COLUMN_LIST                => C.AIM_INDEXED_COLUMNS_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => c.AIM_IS_INDEX_TO_BE_RECREATED,
                                     PI_BUSINESS_NAME              => c.AIM_BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => c.AIM_INDEX_IS_UNIQUE,
                                     PI_INDEX_TYPE                 => c.AIM_INDEX_TYPE,
                                     PI_STATUS                     => 3);

          COMMONS_INDEXING.CREATE_APP_INDEX(PI_TABLES_ID                  => V_TABLES_ID,
                                            PI_COLUMN_LIST                => v_valid_columns_collection,
                                            PI_IS_UNIQUE                  => 0,
                                            PI_DEF_ID                     => c.aim_def_id,
                                            PI_BUSINESS_NAME              => c.aim_business_name,
                                            PI_RECREATE_INDEX_ON_COL_DROP => c.aim_is_index_to_be_recreated,
                                            PI_RUN_ID                     => PI_RUN_ID,
                                            PI_TABLE_NAME                 => PI_TABLE_NAME,
                                            PI_TRANSACTION_ID             => v_transaction_id,
                                            PI_INDEX_TABLESPACE_NAME      => V_INDEX_TABLESPACE_NAME,
                                            PO_INDEX_CREATION_STATUS      => V_OUT_CREATION_STATUS);
        END LOOP;
      END IF;

      DELETE FROM AIM_INDEX_DDL_STORAGE
       WHERE AIDS_TABLE_NAME = PI_TABLE_NAME
         AND AIDS_INDEX_NAME NOT IN
             (SELECT AIM_INDEX_NAME
                FROM APPLICATION_INDEXES_METADATA
               WHERE AIM_TABLE_NAME = PI_TABLE_NAME);
    END IF;
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
    -- INSERT_LOGS('UPDATE_APP_INDEX ended');
  END UPDATE_APP_INDEX;

  --OF-15133 Start

  PROCEDURE GET_COVERING_INDEX_DETAILS(PI_TABLE_NAME  IN VARCHAR2,
                                       PI_COLUMN_LIST IN VARCHAR2,
                                       PO_INDEX_NAME  OUT VARCHAR2,
                                       PO_INDEX_TYPE  OUT NUMBER) IS
    V_COLUMN_LIST VARCHAR2(32767 CHAR) := PI_COLUMN_LIST || '%';

  BEGIN

    PO_INDEX_NAME := NULL;
    PO_INDEX_TYPE := NULL;

    /*WITH INDEXED_COLUMN_LIST AS
     (SELECT index_name,
             listagg(col_list, ',') within GROUP(ORDER BY column_position) AS col_list
        FROM (SELECT uic.index_name,
                     CASE
                       WHEN uie.column_expression IS NULL THEN
                        uic.column_name
                       ELSE
                        commons_tables.index_column_expression_char(uie.TABLE_NAME,
                                                                    uie.index_name,
                                                                    uie.column_position)
                     END col_list,
                     uie.column_position
                FROM user_ind_columns uic
                LEFT OUTER JOIN user_ind_expressions uie
                  ON (uic.TABLE_NAME = uie.TABLE_NAME AND
                     uic.index_name = uie.index_name AND
                     uic.column_position = uie.column_position)
               WHERE uic.TABLE_NAME = PI_TABLE_NAME) inner_query
       GROUP BY inner_query.index_name)
    SELECT MIN(INDEX_NAME) INDEX_NAME,
           MIN(nvl(aim.aim_index_type, asim.asim_index_type)) index_type
      INTO PO_INDEX_NAME, PO_INDEX_TYPE
      FROM INDEXED_COLUMN_LIST icl
      left outer JOIN application_indexes_metadata aim
        on (aim.aim_index_name = icl.INDEX_NAME)
      left outer JOIN app_specific_indexes_metadata asim
        on (asim.asim_index_name = icl.INDEX_NAME)
     WHERE col_list LIKE V_COLUMN_LIST
       AND ROWNUM < 2;*/

    SELECT upper(replace(replace(replace(V_COLUMN_LIST, '"', ''), '''', ''),
                         ' ',
                         ''))
      into V_COLUMN_LIST
      from dual;

    WITH INDEXED_COLUMN_LIST AS
     (SELECT index_name,
             upper(replace(replace(replace(listagg(col_list, ',') within
                                           GROUP(ORDER BY column_position),
                                           '"',
                                           ''),
                                   '''',
                                   ''),
                           ' ',
                           '')) AS col_list
        FROM (SELECT uic.index_name,
                     CASE
                       WHEN uie.column_expression IS NULL THEN
                        uic.column_name
                       ELSE
                        commons_tables.index_column_expression_char(uie.TABLE_NAME,
                                                                    uie.index_name,
                                                                    uie.column_position)
                     END col_list,
                     nvl(uic.column_position, uie.column_position) column_position --uie.column_position
                FROM user_ind_columns uic
                LEFT OUTER JOIN user_ind_expressions uie
                  ON (uic.TABLE_NAME = uie.TABLE_NAME AND
                     uic.index_name = uie.index_name AND
                     uic.column_position = uie.column_position)
               WHERE uic.TABLE_NAME = PI_TABLE_NAME) inner_query
       GROUP BY inner_query.index_name)
    SELECT INDEX_NAME, asim.asim_index_type
      INTO PO_INDEX_NAME, PO_INDEX_TYPE
      FROM INDEXED_COLUMN_LIST icl
      left outer JOIN application_indexes_metadata aim
        on (aim.aim_index_name = icl.INDEX_NAME)
      left outer JOIN app_specific_indexes_metadata asim
        on (asim.asim_index_name = icl.INDEX_NAME)
     WHERE col_list LIKE V_COLUMN_LIST
       AND ROWNUM < 2;
  --commons_utils.insert_logs('PO_INDEX_NAME: ' || PO_INDEX_NAME || ' ' || PO_INDEX_TYPE);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END GET_COVERING_INDEX_DETAILS;
  --OF-15133 END

  -- OF-22882 - OF-26356 -- START
  /*  FUNCTION GET_NONCOVERABLE_INDEXES_COUNT (PI_TABLE_NAME   IN VARCHAR2, PI_CREATE_INDEX_OBJECT IN COLTYPE_CREATE_INDEX)
  RETURN NUMBER
  IS
  V_COMMA_INPUT_COLUMN_LIST        CLOB;
  V_NONCOVERABLE_INDEXES_COUNT number(10) :=0;
  V_INDEX_TYPE           NUMBER(1);
  V_INDEX_NAME           VARCHAR2(30) := NULL;
  BEGIN

    FOR I IN 1 .. PI_CREATE_INDEX_OBJECT.COUNT
    LOOP
      --CREATE COMMA SEPARATED LIST OF COLUMN NAMES FROM THE TABLETYPE_CHARMAX INPUT COLLECTION PARAMETER PI_CREATE_INDEX_OBJECT(I).COLUMN_LIST
      SELECT LISTAGG(UPPER(COLUMN_VALUE), ',') WITHIN GROUP (ORDER BY ROWNUM) INTO V_COMMA_INPUT_COLUMN_LIST FROM TABLE(PI_CREATE_INDEX_OBJECT(I).COLUMN_LIST);
      COMMONS_INDEXING.GET_COVERING_INDEX_DETAILS(PI_TABLE_NAME => PI_TABLE_NAME, PI_COLUMN_LIST => V_COMMA_INPUT_COLUMN_LIST, PO_INDEX_NAME => V_INDEX_NAME, PO_INDEX_TYPE => V_INDEX_TYPE);

      IF V_INDEX_NAME IS NULL
      THEN
        V_NONCOVERABLE_INDEXES_COUNT :=V_NONCOVERABLE_INDEXES_COUNT+1;
      END IF;
    END LOOP;
     -- INSERT_LOGS ('V_NONCOVERABLE_INDEXES_COUNT = ' || V_NONCOVERABLE_INDEXES_COUNT);

    RETURN V_NONCOVERABLE_INDEXES_COUNT;
  END GET_NONCOVERABLE_INDEXES_COUNT;*/

  FUNCTION GET_NONCOVERABLE_INDEXES_COUNT(PI_TABLE_NAME          IN VARCHAR2,
                                          PI_CREATE_INDEX_OBJECT IN COLTYPE_CREATE_INDEX)
    RETURN NUMBER IS

    V_NONCOVERABLE_INDEXES_COUNT number := 0;

    v_covered number;
  BEGIN
    -- dbms_output.put_line(0);
    WITH INDEXED_COLUMN_LIST AS
     (SELECT uic.INDEX_NAME,
             REPLACE(LISTAGG(CASE
                               WHEN t.column_expression IS NOT NULL THEN
                                TO_CHAR(t.column_expression)
                               ELSE
                                uic.COLUMN_NAME
                             END,
                             ',') WITHIN GROUP(ORDER BY uic.COLUMN_POSITION),
                     '"') AS COLUMN_LIST
        FROM user_ind_columns uic
        FULL OUTER JOIN (SELECT EXTRACTVALUE(xs.object_value,
                                            '/ROW/INDEX_NAME') AS INDEX_NAME,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/TABLE_NAME') AS TABLE_NAME,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/COLUMN_EXPRESSION') AS COLUMN_EXPRESSION,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/COLUMN_POSITION') AS COLUMN_POSITION
                          FROM (SELECT XMLTYPE.CREATEXML(DBMS_XMLGEN.GETXML('SELECT * FROM USER_IND_EXPRESSIONS WHERE TABLE_NAME = ''' ||
                                                                            PI_TABLE_NAME || '''')) AS xml
                                  FROM DUAL) x,
                               TABLE(XMLSEQUENCE(EXTRACT(x.xml,
                                                         '/ROWSET/ROW'))) xs) t
          ON t.index_name = uic.INDEX_NAME
         AND t.table_name = uic.TABLE_NAME
         AND t.column_position = uic.COLUMN_POSITION
       WHERE uic.table_name = PI_TABLE_NAME
       GROUP BY uic.INDEX_NAME)
    select count(*)
      into v_covered
      from (select (select LISTAGG(UPPER(COLUMN_VALUE), ',') WITHIN GROUP(ORDER BY rownum)
                      from table(Internal.COLUMN_LIST)) || '%' Col_list

              from Table(PI_CREATE_INDEX_OBJECT) Internal) Incoming_req

     where exists

     (select 1
              from INDEXED_COLUMN_LIST
             where INDEXED_COLUMN_LIST.COLUMN_LIST like
                   Incoming_req.Col_list);
  -- INSERT_LOGS ('V_NONCOVERABLE_INDEXES_COUNT = ' || V_NONCOVERABLE_INDEXES_COUNT);
    V_NONCOVERABLE_INDEXES_COUNT := PI_CREATE_INDEX_OBJECT.count -
                                    v_covered;
    -- dbms_output.put_line(11);
    RETURN V_NONCOVERABLE_INDEXES_COUNT;
    --  dbms_output.put_line(1);
  exception
    when others then
      -- dbms_output.put_line(2);

      RETURN PI_CREATE_INDEX_OBJECT.count;
  END GET_NONCOVERABLE_INDEXES_COUNT;

  FUNCTION GET_DELETABLE_INDEXES_COUNT(PI_TABLE_NAME          IN VARCHAR2,
                                       PI_DELETE_INDEX_OBJECT IN COLTYPE_DELETE_INDEX)
    RETURN NUMBER AS
    V_BNAME_LIST              clob; --VARCHAR2(32767 CHAR);
    V_DEF_ID_LIST             clob; --VARCHAR2(32767 CHAR);
    V_DELETABLE_INDEXES_COUNT NUMBER(10) := 0;
    V_SQL                     VARCHAR2(32767 CHAR) := NULL;
  BEGIN
    IF PI_DELETE_INDEX_OBJECT.COUNT > 0 THEN
      /*SELECT LISTAGG('''' || BUSINESS_NAME || '''', ',') WITHIN GROUP(ORDER BY ROWNUM) BNAME_LIST,
           LISTAGG(DEF_ID, ',') WITHIN GROUP(ORDER BY NULL) DEF_ID_LIST
      INTO V_BNAME_LIST, V_DEF_ID_LIST
      FROM TABLE(PI_DELETE_INDEX_OBJECT);*/

      FOR r in (select DEF_ID, BUSINESS_NAME
                  from TABLE(PI_DELETE_INDEX_OBJECT)) LOOP
        V_BNAME_LIST  := V_BNAME_LIST || '''' || r.BUSINESS_NAME || '''' || ',';
        V_DEF_ID_LIST := V_DEF_ID_LIST || r.DEF_ID || ',';
      END LOOP;

      SELECT rtrim(V_BNAME_LIST, ','), rtrim(V_DEF_ID_LIST, ',')
        INTO V_BNAME_LIST, V_DEF_ID_LIST
        FROM dual;

      -- INSERT_LOGS ('PI_TABLE_NAME = ' || PI_TABLE_NAME);
      -- INSERT_LOGS ('V_BNAME_LIST = ' || V_BNAME_LIST);
      -- INSERT_LOGS ('V_DEF_ID_LIST = ' || V_DEF_ID_LIST);

      -- OF-28045 - START
      V_SQL := '
      WITH RES_INDEXES_TO_BE_DELETED AS (
        SELECT ASIM.ASIM_INDEX_NAME
        FROM APP_SPECIFIC_INDEXES_METADATA ASIM
        WHERE ASIM.ASIM_INDEX_TYPE = 2
          AND ASIM.ASIM_TABLE_NAME = ''' || PI_TABLE_NAME || '''
          AND ASIM.ASIM_BUSINESS_NAME IN (' || V_BNAME_LIST || ')
          AND ASIM.ASIM_DEF_ID IN (' || V_DEF_ID_LIST || ')
        GROUP BY ASIM.ASIM_INDEX_NAME
          HAVING COUNT(*) = 1)
        SELECT COUNT (*) V_COUNT FROM RES_INDEXES_TO_BE_DELETED';

      -- INSERT_LOGS ('V_SQL = ' || V_SQL);
      EXECUTE IMMEDIATE V_SQL
        INTO V_DELETABLE_INDEXES_COUNT;
      -- OF-28045 - END
    END IF;
    -- INSERT_LOGS ('1. V_DELETABLE_INDEXES_COUNT = ' || V_DELETABLE_INDEXES_COUNT);

    RETURN V_DELETABLE_INDEXES_COUNT;
  END GET_DELETABLE_INDEXES_COUNT;
  -- OF-22882 - OF-26356 -- END
  PROCEDURE CREATE_REQUESTED_INDEX(PI_TABLES_ID                  IN NUMBER,
                                   PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                                   PI_IS_UNIQUE                  IN NUMBER,
                                   PI_DEF_ID                     IN NUMBER,
                                   PI_BUSINESS_NAME              IN VARCHAR2,
                                   PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                   PI_INDEX_TYPE                 IN NUMBER,
                                   PI_PROCESS_ID                 IN NUMBER DEFAULT NULL,
                                   PI_RUN_ID                     IN NUMBER DEFAULT NULL,
                                   PO_INDEX_CREATION_STATUS      OUT NUMBER,
                                   PO_INDEX_NAME_RETURNED        OUT VARCHAR2) IS
    --stores table name
    V_TABLENAME VARCHAR2(30) := '';

    --comma separated column list
    V_COMMA_INPUT_COLUMN_LIST CLOB;

    --column list ion collection to be inserted in ASIM table
    V_COLLECTION_INPUT_COLUMN_LIST COLTYPE_INDEXED_COLUMNS_LIST1;

    -- Feature Index name which is derived
    V_INDEXNAME VARCHAR2(30) := '';

    --stauts of index creation code
    V_INDEX_OUT_STATUS NUMBER;

    --decision to create index
    V_INDEX_CREATION_DECISION NUMBER := 1;

    --exception if user passes more than 32 columns
    MAXIMUM_NO_OF_COLS_32 EXCEPTION;
    PRAGMA EXCEPTION_INIT(MAXIMUM_NO_OF_COLS_32, -1793);

    --columnlist which is already indexed
    v_already_indexed_column_list coltype_indexed_columns_list1;

    v_already_indexed_col_list VARCHAR2(1000 CHAR);
    v_update_required          NUMBER := 0;
    V_UNIQUENESS_RETURNED      VARCHAR2(9);
    V_CREATE_INDEX_DDL         CLOB;
    V_INDEX_TABLESPACE_NAME    VARCHAR2(30);
    V_INDEX_TYPE               NUMBER(1);
  BEGIN
    -- 1. Alter Session to BINARY
    --COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY;
    --Get the table name
    SELECT T.TABLES_PHYSICAL_NAME,
           COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
      INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;

    --CREATE COMMA SEPARATED LIST OF COLUMN NAMES FROM THE TABLETYPE_CHARMAX INPUT COLLECTION PARAMETER PI_COLUMN_LIST
    SELECT LISTAGG(UPPER(COLUMN_VALUE), ',') WITHIN GROUP(ORDER BY ROWNUM)
      INTO V_COMMA_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);

    --Get column list into coltype_indexed_column_list format to insert/update the column list in ASIM table
    SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(4000 CHAR)) ORDER BY
                        ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST1) AS INDEXED_COLUMNS
      INTO V_COLLECTION_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);

    -- Loop to determine if Record already exists or not for the input definition id and business name
    FOR c IN (SELECT ASIM.*
                FROM APP_SPECIFIC_INDEXES_METADATA ASIM
               WHERE ASIM.ASIM_TABLE_NAME = V_TABLENAME
                 AND ASIM.ASIM_DEF_ID = PI_DEF_ID
                 AND ASIM.ASIM_BUSINESS_NAME = PI_BUSINESS_NAME) LOOP
      --LOOP 1 START

      -- index already exists for the given definition Id and business name
      v_indexname                   := c.asim_index_name;
      v_already_indexed_column_list := c.asim_indexed_columns;
      v_update_required             := 1;
    END LOOP; --LOOP 1 END

    --Metadata already existing for the given definition and business name
    IF V_update_required = 1 THEN
      -- IF_1 START

      -- Create COMMA SEPARATED LIST OF ALREADY INDEXED COLUMN NAMES of ASIM metadata table
      SELECT LISTAGG(UPPER(COLUMN_VALUE), ',') WITHIN GROUP(ORDER BY ROWNUM)
        INTO v_already_indexed_col_list
        FROM TABLE(v_already_indexed_column_list);

      -- if existing index columns are same as comma separated list of column list requested
      -- eg index on Columns C1,C2,C3 is same as requested C1,C2%
      -- IF_2 START
      IF v_already_indexed_col_list LIKE
         UPPER(V_COMMA_INPUT_COLUMN_LIST) || '%' THEN
        -- Check for exact matchness
        -- i.e. C1,C2 is not equal to C1,C2,C3
        IF UPPER(V_COMMA_INPUT_COLUMN_LIST) != v_already_indexed_col_list THEN
          -- IF_3 START

          COMMONS_INDEXING.DELETE_USAGE_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                              PI_DEF_ID        => PI_DEF_ID,
                                              PI_BUSINESS_NAME => PI_BUSINESS_NAME);

          v_update_required := 0;
          -- if exact matching occurs i.e. requested C1,C2 is same as already existing C1,C2
        ELSIF UPPER(V_COMMA_INPUT_COLUMN_LIST) =
              UPPER(v_already_indexed_col_list) THEN
          -- IF_3 ELSE
          -- i.e. both column lists are equal
          -- No update required
          -- The given column list is already indexed/ using index
          --Set status to 0
          PO_INDEX_CREATION_STATUS := 0;
        END IF; -- IF_3 END
        -- IF_2 ELSE
        -- i.e.  the already indexed column list in AIM table is not same as column list to be indexed for the same def id and business name
        -- existing indexed columns were C1,C2 and user requests C3,C4
      ELSE
        --Call Delete_APP_Index
        --Drops the old index if it was covering and recreates any feature index using that deleted index
        -- else if it was covered index, it just deletes the metadata)
        COMMONS_INDEXING.DELETE_USAGE_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                            PI_DEF_ID        => PI_DEF_ID,
                                            PI_BUSINESS_NAME => PI_BUSINESS_NAME);
        --set the update flag to 0

        v_update_required := 0;
      END IF; -- IF_2 END
    END IF; -- IF_1 END

    IF V_update_required = 0 THEN
      -- IF_4 START

      --Get the covering index if any
      COMMONS_INDEXING.GET_COVERING_INDEX_DETAILS(PI_TABLE_NAME  => V_TABLENAME,
                                                  PI_COLUMN_LIST => V_COMMA_INPUT_COLUMN_LIST,
                                                  PO_INDEX_NAME  => v_indexname,
                                                  PO_INDEX_TYPE  => V_INDEX_TYPE);
      --if the index name is returned for the given column list, then insert the metadata
      IF v_indexname IS NOT NULL THEN
        -- IF_5 START

        --CALL INSERT_APP_INDEXES_METADATA to insert metadata
        INSERT INTO APP_SPECIFIC_INDEXES_METADATA
          (asim_id,
           asim_def_id,
           asim_business_name,
           asim_index_name,
           asim_table_name,
           asim_is_index_to_be_recreated,
           asim_indexed_columns,
           asim_index_is_unique,
           asim_index_type,
           asim_is_enabled,
           asim_creation_date,
           asim_last_update_date)
        VALUES
          (ASIM_SEQ.NEXTVAL,
           PI_DEF_ID,
           PI_BUSINESS_NAME,
           v_indexname,
           V_TABLENAME,
           PI_RECREATE_INDEX_ON_COL_DROP,
           V_COLLECTION_INPUT_COLUMN_LIST,
           PI_IS_UNIQUE,
           PI_INDEX_TYPE,
           1,
           SYSTIMESTAMP,
           SYSTIMESTAMP);

        V_INDEX_CREATION_DECISION := 0;
        --Set status to 0
        PO_INDEX_CREATION_STATUS := 0;
      END IF; -- IF_5 END

      --IF INDEX IS TO BE CREATED
      IF V_INDEX_CREATION_DECISION = 1 THEN
        -- IF_6 START
        -- CHECK IF THE COLUMN LIST CONTAINS SINGLE COLUMN OR MULTIPLE COLUMNS

        IF PI_COLUMN_LIST.COUNT > 32 THEN
          -- IF_7 START
          RAISE MAXIMUM_NO_OF_COLS_32;
        ELSIF PI_IS_UNIQUE = 1 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_UI';
        ELSIF PI_COLUMN_LIST.COUNT > 1 AND PI_COLUMN_LIST.COUNT < 33 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_CI';
        ELSE
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_SI';
        END IF; -- IF_7 END

        --CALL THE CREATE_INDEX TO CREATE THE INDEX
        COMMONS_INDEXING.CREATE_USER_SPECIFIED_INDEX(PI_TABLE_NAME        => V_TABLENAME,
                                                     PI_INDEX_NAME        => V_INDEXNAME,
                                                     PI_COL_LIST          => PI_COLUMN_LIST,
                                                     PI_UNIQUENESS        => PI_IS_UNIQUE,
                                                     PI_COL_IS_PRIMARYKEY => 0,
                                                     PI_INDEX_TABLESPACE  => V_INDEX_TABLESPACE_NAME,
                                                     PI_RUN_ID            => PI_RUN_ID,
                                                     PO_INDEX_STATUS      => V_INDEX_OUT_STATUS,
                                                     PO_INDEX_NAME        => PO_INDEX_NAME_RETURNED,
                                                     PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                                     PO_CREATE_DDL        => V_CREATE_INDEX_DDL);

        IF V_INDEX_OUT_STATUS = 1 THEN
          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => PI_DEF_ID,
                                     PI_INDEX_NAME                 => PO_INDEX_NAME_RETURNED,
                                     PI_TABLE_NAME                 => V_TABLENAME,
                                     PI_COLUMN_LIST                => V_COMMA_INPUT_COLUMN_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                     PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                     PI_INDEX_TYPE                 => PI_INDEX_TYPE,
                                     PI_STATUS                     => 2);
          -- INDEX DETAILS ARE ENTERED INTO APPLICATION_INDEXES_METADATA TABLE
          commons_indexing.INSERT_APP_INDEXES_METADATA2(PI_DEFINITION_ID              => PI_DEF_ID,
                                                        PI_INDEX_NAME                 => PO_INDEX_NAME_RETURNED,
                                                        PI_TABLE_NAME                 => V_TABLENAME,
                                                        PI_COLUMN_LIST                => V_COLLECTION_INPUT_COLUMN_LIST,
                                                        PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                                        PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                                        PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                                        PI_INDEX_TYPE                 => PI_INDEX_TYPE,
                                                        PI_INDEX_INSERT_DDL           => V_CREATE_INDEX_DDL);
          PO_INDEX_CREATION_STATUS := 1;
          /*ELSIF V_INDEX_OUT_STATUS = 2 THEN
          PO_INDEX_CREATION_STATUS := 0;*/
        END IF;
      END IF; -- IF_6 END
    END IF; -- IF_4 END

  END CREATE_REQUESTED_INDEX;
  PROCEDURE DELETE_REQUESTED_INDEX(PI_TABLES_ID     IN NUMBER,
                                   PI_DEF_ID        IN NUMBER,
                                   PI_BUSINESS_NAME IN VARCHAR2,
                                   PI_PROCESS_ID    IN NUMBER DEFAULT NULL,
                                   PI_RUN_ID        IN NUMBER DEFAULT NULL) IS
    V_TABLENAME                VARCHAR2(30) := '';
    V_DDL_QUERY                CLOB;
    V_UNDO_DDL_QUERY           CLOB;
    V_INDEX_LIST               COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_DDL            COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE;
    V_DDL_CREATE_INDEX         CLOB := NULL;
    V_LENGTH                   NUMBER;
    V_INDEX_NAME_RETURNED      VARCHAR2(30 CHAR);
    V_VALID_COLUMNS_COLLECTION TABLETYPE_CHARMAX;
    V_OUT_CREATION_STATUS      NUMBER;
    V_INDEX_COLUMN_LIST        VARCHAR2(1300 CHAR);
  BEGIN
    -- 1. Alter Session to BINARY
    -- INSERT_LOGS('DELETE_REQUESTED_INDEX STARTED');
    IF PI_TABLES_ID IS NOT NULL AND PI_DEF_ID IS NOT NULL AND
       PI_BUSINESS_NAME IS NOT NULL THEN
      --Get Table name
      SELECT T.TABLES_PHYSICAL_NAME
        INTO V_TABLENAME
        FROM TABLES T
       WHERE T.TABLES_ID = PI_TABLES_ID;

      -- Check if this Feature Index (FI) covers any other FIs
      -- OF-26741 - Added one more clause in the WHERE part to check with AIDS table so that ones which are physically present, only those indexes should come here.
      FOR C IN (SELECT asim_PARENT.asim_DEF_ID,
                       UPPER(asim_PARENT.asim_BUSINESS_NAME),
                       asim_PARENT.asim_INDEX_TYPE,
                       asim_PARENT.asim_INDEX_NAME,
                       asim_PARENT.asim_TABLE_NAME,
                       asim_PARENT.asim_INDEX_IS_UNIQUE,
                       asim_PARENT.ASIM_INDEXED_COLUMNS,
                       (SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID
                          FROM DUAL) TRANSACTION_ID
                  FROM APP_SPECIFIC_INDEXES_METADATA asim_PARENT
                 WHERE NOT EXISTS
                 (SELECT 1
                          FROM APP_SPECIFIC_INDEXES_METADATA asim_CHILD
                         WHERE asim_PARENT.asim_INDEX_NAME =
                               asim_CHILD.asim_INDEX_NAME
                           AND ((SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(asim_CHILD.asim_INDEXED_COLUMNS)) >
                               (SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(asim_PARENT.asim_INDEXED_COLUMNS))))
                   AND asim_PARENT.asim_INDEX_TYPE IN (2, 3, 4)
                   AND asim_PARENT.asim_DEF_ID = PI_DEF_ID
                   AND UPPER(asim_PARENT.asim_TABLE_NAME) =
                       UPPER(V_TABLENAME)
                   AND UPPER(asim_PARENT.asim_BUSINESS_NAME) =
                       UPPER(PI_BUSINESS_NAME)
                   AND NOT EXISTS (SELECT 1
                          FROM APP_SPECIFIC_INDEXES_METADATA asim_CORE
                         WHERE asim_CORE.asim_INDEX_NAME =
                               asim_PARENT.asim_INDEX_NAME
                           AND asim_CORE.asim_INDEX_TYPE = 1)
                   AND EXISTS
                 (SELECT 1
                          FROM AIM_INDEX_DDL_STORAGE AIDS
                         WHERE AIDS.AIDS_INDEX_NAME =
                               asim_PARENT.asim_INDEX_NAME)) LOOP
        -- INSERT_LOGS('INSIDE FIRST LOOP');
        -- a. Drop this Physical Feature Index using DDL Framework (so that it can be rolled back if required)
        V_DDL_QUERY := 'BEGIN
                            FOR I in (SELECT * FROM DUAL WHERE EXISTS
                              (SELECT 1 FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                       C.ASIM_INDEX_NAME ||
                       '''))) LOOP
                              EXECUTE IMMEDIATE ''DROP INDEX ' ||
                       C.asim_INDEX_NAME || ''';
                            END LOOP;
                          END;';

        -- 1. Call to GET_INDEX_DDLS_FOR_APP
        SELECT C.asim_INDEX_NAME BULK COLLECT INTO V_INDEX_LIST FROM DUAL;

        --V_INDEX_LIST :=COMMONS_INDEXING.TYPE_CONSTRAINT_NAME(C.asim_INDEX_NAME);
        COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                PO_INDEX_DDL  => V_OUT_INDEX_DDL);

        IF V_OUT_INDEX_DDL.COUNT = 1 THEN
          -- INSERT_LOGS('DELETE_REQUESTED_INDEX : IF V_OUT_INDEX_DDL.COUNT = 1');
          V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;

          --Replace single quote with TWO single quotes
          V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                               '\''',
                                               '''''');

          --Get the length of statement created
          V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);

          --Remove the extra single quote from START and END, as the start and end are also
          -- appended with extra single quote being clob statement
          V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX, 2, V_LENGTH - 1);

          V_UNDO_DDL_QUERY := '
            BEGIN
              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                              C.asim_INDEX_NAME ||
                              ''')))
              LOOP
                EXECUTE IMMEDIATE ''' ||
                              V_DDL_CREATE_INDEX || ''';
              END LOOP;
            END;';
        END IF;

        -- 2. Call to EXECUTE_DDL
        COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => C.TRANSACTION_ID,
                                         PI_DESCRIPTION    => 'DROP INDEX ' ||
                                                              C.asim_INDEX_NAME,
                                         PI_DDL            => V_DDL_QUERY,
                                         PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                         pi_run_id         => PI_RUN_ID);

        DELETE FROM AIM_INDEX_DDL_STORAGE AIDS
         WHERE AIDS.AIDS_INDEX_NAME = C.asim_INDEX_NAME;

        DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
         WHERE asim.asim_DEF_ID = PI_DEF_ID
           AND asim.asim_BUSINESS_NAME = PI_BUSINESS_NAME
           AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME);
        -- OF-33540
        SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
          INTO V_INDEX_COLUMN_LIST
          FROM TABLE(C.ASIM_INDEXED_COLUMNS);

        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => C.ASIM_DEF_ID,
                                   PI_INDEX_NAME                 => C.ASIM_INDEX_NAME,
                                   PI_TABLE_NAME                 => C.ASIM_TABLE_NAME,
                                   PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                   PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => NULL,
                                   PI_INDEX_TYPE                 => C.ASIM_INDEX_TYPE,
                                   PI_STATUS                     => 3);
        -- INSERT_LOGS('DELETE_REQUESTED_INDEX : MERGE_AIR-- C.ASIM_DEF_ID '||C.ASIM_DEF_ID||'--C.ASIM_INDEX_NAME '||C.ASIM_INDEX_NAME||'--C.ASIM_TABLE_NAME '||C.ASIM_TABLE_NAME||'--V_INDEX_COLUMN_LIST '||V_INDEX_COLUMN_LIST);
        -- c. Call the proc: "UPDATE_APP_INDEXES" to: Recreate, if applicable, other FIs which are covered (i.e. NOT PHYSICALY PRESENT) by the FI to be deleted.
        --Feature indexes depending on this index need to be updated
        FOR d IN (SELECT asim.*,
                         (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                            FROM TABLE(asim.asim_INDEXED_COLUMNS)) asim_INDEXED_COLUMNS_LIST
                    FROM APP_SPECIFIC_INDEXES_METADATA asim
                   WHERE asim.asim_INDEX_NAME = c.asim_index_name
                     AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME)
                     AND asim_INDEX_TYPE IN (2, 3, 4)
                   ORDER BY REGEXP_COUNT(asim_INDEXED_COLUMNS_LIST, ',') DESC) LOOP
          -- INSERT_LOGS('DELETE_REQUESTED_INDEX : INSIDE SECOND LOOP');
          SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(4000 CHAR))
                              ORDER BY ROWNUM) AS tabletype_charmax)
            INTO v_valid_columns_collection
            FROM TABLE(d.asim_indexed_columns) t
           INNER JOIN user_tab_columns utc
              ON utc.TABLE_NAME = d.asim_table_name
             AND utc.COLUMN_NAME = t.COLUMN_VALUE;

          DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_BUSINESS_NAME = d.asim_business_name
             AND asim.asim_DEF_ID = d.asim_def_id
             AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME);

          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => d.ASIM_DEF_ID,
                                     PI_INDEX_NAME                 => d.ASIM_INDEX_NAME,
                                     PI_TABLE_NAME                 => d.ASIM_TABLE_NAME,
                                     PI_COLUMN_LIST                => D.asim_INDEXED_COLUMNS_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                     PI_BUSINESS_NAME              => d.ASIM_BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => NULL,
                                     PI_INDEX_TYPE                 => d.ASIM_INDEX_TYPE,
                                     PI_STATUS                     => 3);
          -- INSERT_LOGS('DELETE_REQUESTED_INDEX : MERGE_AIR-- D.ASIM_DEF_ID '||D.ASIM_DEF_ID||'--D.ASIM_INDEX_NAME '||D.ASIM_INDEX_NAME||'--D.ASIM_TABLE_NAME '||D.ASIM_TABLE_NAME||'--D.asim_INDEXED_COLUMNS_LIST '||D.asim_INDEXED_COLUMNS_LIST);
          IF d.ASIM_INDEX_TYPE = 2 THEN
            COMMONS_INDEXING.CREATE_SPECIFIED_APP_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                                        PI_COLUMN_LIST                => v_valid_columns_collection,
                                                        PI_IS_UNIQUE                  => d.asim_index_is_unique,
                                                        PI_DEF_ID                     => d.asim_def_id,
                                                        PI_BUSINESS_NAME              => d.asim_business_name,
                                                        PI_RECREATE_INDEX_ON_COL_DROP => d.asim_is_index_to_be_recreated,
                                                        PI_RUN_ID                     => PI_RUN_ID,
                                                        PO_INDEX_CREATION_STATUS      => V_OUT_CREATION_STATUS);
          ELSIF d.ASIM_INDEX_TYPE = 3 OR d.ASIM_INDEX_TYPE = 4 THEN
            COMMONS_INDEXING.CREATE_REQUESTED_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                                    PI_COLUMN_LIST                => v_valid_columns_collection,
                                                    PI_IS_UNIQUE                  => d.asim_index_is_unique,
                                                    PI_DEF_ID                     => d.asim_def_id,
                                                    PI_BUSINESS_NAME              => d.asim_business_name,
                                                    PI_RECREATE_INDEX_ON_COL_DROP => d.asim_is_index_to_be_recreated,
                                                    PI_INDEX_TYPE                 => d.ASIM_INDEX_TYPE,
                                                    PI_PROCESS_ID                 => NULL,
                                                    PI_RUN_ID                     => NULL,
                                                    PO_INDEX_CREATION_STATUS      => V_OUT_CREATION_STATUS,
                                                    PO_INDEX_NAME_RETURNED        => V_INDEX_NAME_RETURNED);
          END IF;
        END LOOP;
      END LOOP;

      DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
       WHERE asim.asim_DEF_ID = PI_DEF_ID
         AND asim.asim_BUSINESS_NAME = PI_BUSINESS_NAME
         AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME);
    END IF;
    -- INSERT_LOGS('DELETE_REQUESTED_INDEX ENDED');

  END DELETE_REQUESTED_INDEX;
  PROCEDURE CREATE_USAGE_APP_INDEX(PI_TABLES_ID                  IN NUMBER,
                                   PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                                   PI_IS_UNIQUE                  IN NUMBER,
                                   PI_DEF_ID                     IN NUMBER,
                                   PI_BUSINESS_NAME              IN VARCHAR2,
                                   PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                   PI_INDEX_TYPE                 IN NUMBER,
                                   PI_PROCESS_ID                 IN NUMBER DEFAULT NULL,
                                   PI_RUN_ID                     IN NUMBER DEFAULT NULL,
                                   PO_INDEX_CREATION_STATUS      OUT NUMBER,
                                   PO_INDEX_NAME_RETURNED        OUT VARCHAR2) IS
    V_TABLENAME               VARCHAR2(30) := '';
    V_INPUT_COLUMN_COLLECTION SYS.HSBLKNAMLST;

    V_COMMA_INPUT_COLUMN_LIST      CLOB;
    V_COLLECTION_INPUT_COLUMN_LIST COLTYPE_INDEXED_COLUMNS_LIST;
    V_INDEXNAME                    VARCHAR2(30) := '';
    V_INDEX_OUT_STATUS             NUMBER;
    V_INDEX_CREATION_DECISION      NUMBER := 1;
    MAXIMUM_NO_OF_COLS_32 EXCEPTION;
    PRAGMA EXCEPTION_INIT(MAXIMUM_NO_OF_COLS_32, -1793);
    v_already_indexed_column_list  coltype_indexed_columns_list;
    v_already_indexed_col_list_aim VARCHAR2(1000 CHAR);
    v_update_required              NUMBER := 0;
    V_UNIQUENESS_RETURNED          VARCHAR2(9);
    V_CREATE_INDEX_DDL             CLOB;
    V_INDEX_TABLESPACE_NAME        VARCHAR2(30 CHAR);
    v_COLUMN_LIST                  varchar2(1300 char);
    V_TRANSACTION_ID               VARCHAR2(30 CHAR);
  BEGIN

    --Get the table name
    SELECT T.TABLES_PHYSICAL_NAME,
           COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID) /*OF-11821*/
      INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;

    V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;
    --PI_INDEX_TYPE := CASE WHEN PI_BUSINESS_NAME = 'CORE__BUSINESS_KEY' THEN 1 ELSE 2 END;

    --CREATE COMMA SEPARATED LIST OF COLUMN NAMES FROM THE TABLETYPE_CHARMAX INPUT COLLECTION PARAMETER PI_COLUMN_LIST
    SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
      INTO V_COMMA_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);
    SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
      INTO v_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);
    -- INSERT_LOGS('CREATE_APP_INDEX v_COLUMN_LIST=>'||v_COLUMN_LIST||'  V_COMMA_INPUT_COLUMN_LIST=>'||V_COMMA_INPUT_COLUMN_LIST);
    --Get column list into coltype_indexed_column_list format to insert/update the column list in AIM table
    SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY ROWNUM) AS
                COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
      INTO V_COLLECTION_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);

    -- Loop to determine if Record already exists or not for the input definition id and business name
    FOR c IN (SELECT AIM.*
                FROM APPLICATION_INDEXES_METADATA AIM
               WHERE AIM.AIM_TABLE_NAME = V_TABLENAME
                 AND AIM.AIM_DEF_ID = PI_DEF_ID
                 AND AIM.AIM_BUSINESS_NAME = PI_BUSINESS_NAME) LOOP
      --LOOP 1 START

      -- index already exists for the given definition Id and business name
      v_indexname                   := c.aim_index_name;
      v_already_indexed_column_list := c.aim_indexed_columns;
      v_update_required             := 1;
    END LOOP; --LOOP 1 END

    --Metadata already existing for the given definition and business name
    IF V_update_required = 1 THEN
      -- IF_1 START

      -- Create COMMA SEPARATED LIST OF ALREADY INDEXED COLUMN NAMES of AIM metadata table
      SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
        INTO v_already_indexed_col_list_aim
        FROM TABLE(v_already_indexed_column_list);

      -- if existing index columns are same as comma separated list
      IF v_already_indexed_col_list_aim LIKE
         V_COMMA_INPUT_COLUMN_LIST || '%' THEN
        -- IF_2 START

        IF V_COMMA_INPUT_COLUMN_LIST != v_already_indexed_col_list_aim THEN
          -- IF_3 START

          --update the metadata with column list provided
          UPDATE application_indexes_metadata aim
             SET aim.aim_indexed_columns = V_COLLECTION_INPUT_COLUMN_LIST
           WHERE aim.aim_table_name = V_TABLENAME
             AND aim.aim_def_id = PI_DEF_ID
             AND aim.aim_business_name = PI_BUSINESS_NAME;
          --Update the ddl metadata with the covering index name ddl

        ELSE
          -- IF_3 ELSE
          -- i.e. both column lists are equal
          -- No update required
          -- The given column list is already indexed/ using index
          --Set status to 0
          PO_INDEX_CREATION_STATUS := 0;
        END IF; -- IF_3 END
      ELSE
        -- IF_2 ELSE
        -- i.e.  the already indexed column list in AIM table is not same as column list to be indexed for the same def id and business name

        --Call Delete_APP_Index
        --Drops the old index if it was covering and recreates any feature index using the index,
        -- else if it was covered index, it just deletes the metadata)
        COMMONS_INDEXING.DELETE_USAGE_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                            PI_DEF_ID        => PI_DEF_ID,
                                            PI_BUSINESS_NAME => PI_BUSINESS_NAME);
        --set the update flag to 0
        v_update_required := 0;
      END IF; -- IF_2 END
    END IF; -- IF_1 END

    IF V_update_required = 0 THEN
      -- IF_4 START

      --Get the covering index if any
      v_indexname := GET_COVERING_INDEX(PI_TABLE_NAME  => V_TABLENAME,
                                        PI_COLUMN_LIST => V_COMMA_INPUT_COLUMN_LIST || '%');

      --if the index name returned is not null, then insert the metadata
      IF v_indexname IS NOT NULL THEN
        -- IF_5 START
        SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
          INTO V_COLLECTION_INPUT_COLUMN_LIST
          FROM TABLE(PI_COLUMN_LIST);

        --CALL INSERT_APP_INDEXES_METADATA to insert metadata
        COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID              => PI_DEF_ID,
                                                     PI_INDEX_NAME                 => v_indexname,
                                                     PI_TABLE_NAME                 => V_TABLENAME,
                                                     PI_COLUMN_LIST                => V_COLLECTION_INPUT_COLUMN_LIST,
                                                     PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                                     PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                                     PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                                     PI_INDEX_TYPE                 => PI_INDEX_TYPE);
        V_INDEX_CREATION_DECISION := 0;
        --Set status to 0
        PO_INDEX_CREATION_STATUS := 0;
      END IF; -- IF_5 END

      --IF INDEX IS TO BE CREATED
      IF V_INDEX_CREATION_DECISION = 1 THEN
        -- IF_6 START

        -- CHECK IF THE COLUMN LIST CONTAINS SINGLE COLUMN OR MULTIPLE COLUMNS

        IF PI_COLUMN_LIST.COUNT > 32 THEN
          -- IF_7 START
          RAISE MAXIMUM_NO_OF_COLS_32;
        ELSIF PI_IS_UNIQUE = 1 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_UI'; /*OF-21059*/
        ELSIF PI_COLUMN_LIST.COUNT > 1 AND PI_COLUMN_LIST.COUNT < 33 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_CI'; /*OF-21059*/
        ELSE
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_SI'; /*OF-21059*/
        END IF; -- IF_7 END

        SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS SYS.HSBLKNAMLST) AS INDEXED_COLUMNS
          INTO V_INPUT_COLUMN_COLLECTION
          FROM TABLE(PI_COLUMN_LIST);

        --CALL THE CREATE_INDEX TO CREATE THE INDEX

        --Get column list into coltype_indexed_column_list format to insert/update the column list in AIM table
        SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
          INTO V_COLLECTION_INPUT_COLUMN_LIST
          FROM TABLE(PI_COLUMN_LIST);
        COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_TABLENAME,
                                       PI_INDEX_NAME        => V_INDEXNAME,
                                       PI_COLUMN_LIST       => V_INPUT_COLUMN_COLLECTION,
                                       PI_UNIQUENESS        => PI_IS_UNIQUE,
                                       PI_COL_IS_PRIMARYKEY => 0,
                                       PI_INDEX_TABLESPACE  => V_INDEX_TABLESPACE_NAME,
                                       PI_TRANSACTION_ID    => V_TRANSACTION_ID,
                                       PI_RUN_ID            => PI_RUN_ID,
                                       PO_INDEX_STATUS      => V_INDEX_OUT_STATUS,
                                       PO_INDEX_NAME        => PO_INDEX_NAME_RETURNED,
                                       PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                       PO_CREATE_DDL        => V_CREATE_INDEX_DDL);

        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => PI_DEF_ID,
                                   PI_INDEX_NAME                 => PO_INDEX_NAME_RETURNED,
                                   PI_TABLE_NAME                 => V_TABLENAME,
                                   PI_COLUMN_LIST                => v_COLUMN_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                   PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                   PI_INDEX_TYPE                 => PI_INDEX_TYPE,
                                   PI_STATUS                     => 2);
        PO_INDEX_CREATION_STATUS := V_INDEX_OUT_STATUS;

        IF V_INDEX_OUT_STATUS IN (1, 2) THEN
          --Redundant query as it is executed in 1st step
          SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                              ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
            INTO V_COLLECTION_INPUT_COLUMN_LIST
            FROM TABLE(PI_COLUMN_LIST);

          -- INDEX DETAILS ARE ENTERED INTO APPLICATION_INDEXES_METADATA TABLE
          COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              => PI_DEF_ID,
                                                        PI_INDEX_NAME                 => PO_INDEX_NAME_RETURNED,
                                                        PI_TABLE_NAME                 => V_TABLENAME,
                                                        PI_COLUMN_LIST                => V_COLLECTION_INPUT_COLUMN_LIST,
                                                        PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                                        PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                                        PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                                        PI_INDEX_TYPE                 => PI_INDEX_TYPE,
                                                        PI_INDEX_INSERT_DDL           => V_CREATE_INDEX_DDL);
        END IF;
      END IF; -- IF_6 END
    END IF; -- IF_4 END

  END CREATE_USAGE_APP_INDEX;

  PROCEDURE DELETE_USAGE_APP_INDEX(PI_TABLES_ID     IN NUMBER,
                                   PI_DEF_ID        IN NUMBER,
                                   PI_BUSINESS_NAME IN VARCHAR2,
                                   PI_PROCESS_ID    IN NUMBER DEFAULT NULL,
                                   PI_RUN_ID        IN NUMBER DEFAULT NULL) IS
    V_TABLENAME               VARCHAR2(30) := '';
    V_DDL_QUERY               CLOB;
    V_UNDO_DDL_QUERY          CLOB;
    V_UD_INDEX                NUMBER(10, 0);
    V_OUT_INDEX_UPDATE_STATUS NUMBER(1, 0);
    V_INDEX_LIST              COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_DDL           COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE;
    V_DDL_CREATE_INDEX        CLOB := NULL;
    V_LENGTH                  NUMBER;
    V_INDEX_TABLESPACE_NAME   VARCHAR2(30 CHAR);
    V_INDEX_COLUMN_LIST       VARCHAR2(1300 CHAR);
  BEGIN

    IF PI_TABLES_ID IS NOT NULL /*AND PI_DEF_ID IS NOT NULL*/
       AND PI_BUSINESS_NAME IS NOT NULL THEN
      --Get Table name
      SELECT T.TABLES_PHYSICAL_NAME,
             COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
        INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
        FROM TABLES T
       WHERE T.TABLES_ID = PI_TABLES_ID;

      -- Check if this Feature Index (FI) covers any other FIs
      FOR C IN (SELECT AIM_PARENT.AIM_DEF_ID,
                       UPPER(AIM_PARENT.AIM_BUSINESS_NAME) AIM_BUSINESS_NAME,
                       AIM_PARENT.AIM_INDEX_TYPE,
                       AIM_PARENT.AIM_INDEX_NAME,
                       AIM_PARENT.AIM_TABLE_NAME,
                       AIM_PARENT.AIM_INDEX_IS_UNIQUE,
                       AIM_PARENT.AIM_INDEXED_COLUMNS,
                       (SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID
                          FROM DUAL) TRANSACTION_ID
                  FROM APPLICATION_INDEXES_METADATA AIM_PARENT
                 WHERE NOT EXISTS
                 (SELECT 1
                          FROM APPLICATION_INDEXES_METADATA AIM_CHILD
                         WHERE AIM_PARENT.AIM_INDEX_NAME =
                               AIM_CHILD.AIM_INDEX_NAME
                           AND ((SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(AIM_CHILD.AIM_INDEXED_COLUMNS)) >
                               (SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(AIM_PARENT.AIM_INDEXED_COLUMNS))))
                   AND AIM_PARENT.AIM_INDEX_TYPE IN (2, 3, 4)
                   AND /*AIM_PARENT.AIM_DEF_ID = PI_DEF_ID*/
                       NVL(AIM_PARENT.AIM_DEF_ID, 0) = NVL(PI_DEF_ID, 0)
                   AND UPPER(AIM_PARENT.AIM_TABLE_NAME) = UPPER(V_TABLENAME)
                   AND UPPER(AIM_PARENT.AIM_BUSINESS_NAME) =
                       UPPER(PI_BUSINESS_NAME)
                   AND NOT EXISTS
                 (SELECT 1
                          FROM APPLICATION_INDEXES_METADATA AIM_CORE
                         WHERE AIM_CORE.AIM_INDEX_NAME =
                               AIM_PARENT.AIM_INDEX_NAME
                           AND AIM_CORE.AIM_INDEX_TYPE = 1)) LOOP
        -- a. Drop this Physical Feature Index using DDL Framework (so that it can be rolled back if required)
        V_DDL_QUERY := 'DROP INDEX  ' || C.AIM_INDEX_NAME;

        -- 1. Call to GET_INDEX_DDLS_FOR_APP
        SELECT C.AIM_INDEX_NAME BULK COLLECT INTO V_INDEX_LIST FROM DUAL;

        --V_INDEX_LIST :=COMMONS_INDEXING.TYPE_CONSTRAINT_NAME(C.AIM_INDEX_NAME);
        COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                PO_INDEX_DDL  => V_OUT_INDEX_DDL);

        IF V_OUT_INDEX_DDL.COUNT = 1 THEN
          V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;

          --Replace single quote with TWO single quotes
          V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                               '\''',
                                               '''''');

          --Get the length of statement created
          V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);

          --Remove the extra single quote from START and END, as the start and end are also
          -- appended with extra single quote being clob statement
          V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX, 2, V_LENGTH - 1);

          V_UNDO_DDL_QUERY := '
            BEGIN
              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                              C.AIM_INDEX_NAME ||
                              ''')))
              LOOP
                EXECUTE IMMEDIATE ''' ||
                              V_DDL_CREATE_INDEX || ''';
              END LOOP;
            END;';
        END IF;

        -- 2. Call to EXECUTE_DDL
        COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => C.TRANSACTION_ID,
                                         PI_DESCRIPTION    => 'DROP UNIQUE INDEX ' ||
                                                              C.AIM_INDEX_NAME,
                                         PI_DDL            => V_DDL_QUERY,
                                         PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                         pi_run_id         => PI_RUN_ID);

        -- b. Call the proc: "DELETE_AIM_BY_DEFID_AND_BNAME" to delete the Metadata for this FI.
        -- INSERT_LOGS(' 2 - DELETE_AIM_BY_DEFID_AND_BNAME : PI_TABLE_NAME => ' || V_TABLENAME);
        COMMONS_INDEXING.DELETE_AIM_BY_DEFID_AND_BNAME(PI_TABLE_NAME    => UPPER(V_TABLENAME),
                                                       PI_DEFINITION_ID => PI_DEF_ID,
                                                       PI_BUSINESS_NAME => PI_BUSINESS_NAME);

        SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
          INTO V_INDEX_COLUMN_LIST
          FROM TABLE(C.aim_indexed_columns);

        MERGE_AIR(PI_DEFINITION_ID              => C.AIM_DEF_ID,
                  PI_INDEX_NAME                 => C.AIM_INDEX_NAME,
                  PI_TABLE_NAME                 => C.AIM_TABLE_NAME,
                  PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                  PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                  PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                  PI_IS_UNIQUE                  => NULL,
                  PI_INDEX_TYPE                 => C.AIM_INDEX_TYPE,
                  PI_STATUS                     => 3);
        -- c. Call the proc: "UPDATE_APP_INDEXES" to: Recreate, if applicable, other FIs which are covered (i.e. NOT PHYSICALY PRESENT) by the FI to be deleted.
        UPDATE_APP_INDEX(PI_TABLE_NAME         => C.AIM_TABLE_NAME,
                         PI_RENAMED_INDEX_NAME => NULL,
                         PI_TRANSACTION_ID     => C.TRANSACTION_ID,
                         PI_INDEX_UPDATE_MODE  => 2,
                         PI_DELETED_INDEX_NAME => C.AIM_INDEX_NAME,
                         PI_TABLESPACE_NAME    => V_INDEX_TABLESPACE_NAME,
                         PI_RUN_ID             => PI_RUN_ID,
                         PI_TABLES_ID          => PI_TABLES_ID --sales change
                         );
      END LOOP;

      /*        -- Call the proc: "DELETE_AIM_BY_DEFID_AND_BNAME" to delete the Metadata for this FI, if it is not a COVERING Index.
      -- INSERT_LOGS(' 3 - DELETE_AIM_BY_DEFID_AND_BNAME : PI_TABLE_NAME => ' || V_TABLENAME);
       COMMONS_INDEXING.DELETE_AIM_BY_DEFID_AND_BNAME(
         PI_TABLE_NAME    => UPPER(V_TABLENAME),
         PI_DEFINITION_ID => PI_DEF_ID,
         PI_BUSINESS_NAME => PI_BUSINESS_NAME);*/

      -- OF-25207 -- START -   Change For handling maximum key length limit exceeded error
      DELETE FROM APPLICATION_INDEXES_METADATA AIM
       WHERE NVL(AIM.AIM_DEF_ID, 0) = NVL(PI_DEF_ID, 0)
         AND AIM.AIM_BUSINESS_NAME = PI_BUSINESS_NAME
         AND AIM.AIM_TABLE_NAME = UPPER(V_TABLENAME);
      -- OF-25207 -- END
    END IF;
  END DELETE_USAGE_APP_INDEX;

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
  /*FUNCTION GET_COVERING_INDEX_1(PI_TABLE_NAME  IN VARCHAR2,
                                PI_COLUMN_LIST IN VARCHAR2) RETURN VARCHAR2 IS
    V_INDEX_NAME VARCHAR2(30);
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    --COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY;
    WITH INDEXED_COLUMN_LIST AS
     (SELECT uic.INDEX_NAME,
             LISTAGG(CASE
                       WHEN t.column_expression IS NOT NULL THEN
                        TO_CHAR(t.column_expression)
                       ELSE
                        uic.COLUMN_NAME
                     END,
                     ',') WITHIN GROUP(ORDER BY uic.COLUMN_POSITION) AS COLUMN_LIST
        FROM user_ind_columns uic
        FULL OUTER JOIN (SELECT EXTRACTVALUE(xs.object_value,
                                            '/ROW/INDEX_NAME') AS INDEX_NAME,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/TABLE_NAME') AS TABLE_NAME,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/COLUMN_EXPRESSION') AS COLUMN_EXPRESSION,
                               EXTRACTVALUE(xs.object_value,
                                            '/ROW/COLUMN_POSITION') AS COLUMN_POSITION
                          FROM (SELECT XMLTYPE.CREATEXML(DBMS_XMLGEN.GETXML('SELECT * FROM USER_IND_EXPRESSIONS WHERE TABLE_NAME = ''' ||
                                                                            PI_TABLE_NAME || '''')) AS xml
                                  FROM DUAL) x,
                               TABLE(XMLSEQUENCE(EXTRACT(x.xml,
                                                         '/ROWSET/ROW'))) xs) t
          ON t.index_name = uic.INDEX_NAME
         AND t.table_name = uic.TABLE_NAME
         AND t.column_position = uic.COLUMN_POSITION
       WHERE uic.table_name = PI_TABLE_NAME
       GROUP BY uic.INDEX_NAME)
    SELECT MIN(INDEX_NAME)
      INTO V_INDEX_NAME
      FROM INDEXED_COLUMN_LIST
     WHERE COLUMN_LIST LIKE PI_COLUMN_LIST
       AND ROWNUM < 2;

    RETURN V_INDEX_NAME;
    -- Defect # 14383, 15167
    ---- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END GET_COVERING_INDEX_1;*/

  --Exposing this function, to make it visible to SQL engine
  /*FUNCTION CREATE_CLOB(PI_TABLE_NAME      IN VARCHAR2,
                       PI_INDEX_NAME      IN VARCHAR2,
                       PI_COL_LIST        IN VARCHAR2,
                       PI_BUSINESS_NAME   IN VARCHAR2,
                       PI_IS_PRIMARY_KEY  IN NUMBER,
                       PI_UNIQUENESS      IN NUMBER,
                       PI_TABLESPACE_NAME IN VARCHAR2,
                       PI_RUN_ID          IN NUMBER DEFAULT NULL)
    RETURN VARCHAR2 IS
    v_out VARCHAR2(4000 CHAR);
  BEGIN
    v_out := 'DECLARE v_out number;v_tablename  VARCHAR2(30) := ''' ||
             PI_TABLE_NAME ||
             ''';v_index_name_returned VARCHAR2(30 CHAR);v_uniqueness_returned VARCHAR2(9); v_op_indexing_info VARCHAR2(1000 CHAR); v_create_index_ddl CLOB;
    BEGIN COMMONS_INDEXING.CREATE_INDEX1(PI_TABLE_NAME=>v_tablename, PI_INDEX_TABLESPACE => ''' ||
             PI_TABLESPACE_NAME || ''',PI_INDEX_NAME=>''' || PI_INDEX_NAME ||
             ''',PI_COL_LIST=> SYS.HSBLKNAMLST(' || PI_COL_LIST ||
             '),PI_UNIQUENESS => ' || PI_UNIQUENESS ||
             ',PI_COL_IS_PRIMARYKEY => ' || PI_IS_PRIMARY_KEY || ',' || CASE
               WHEN PI_RUN_ID IS NULL THEN
                'PI_RUN_ID=> null'
               ELSE
                ' PI_RUN_ID =>'
             END || PI_RUN_ID || ',' ||
             'PO_INDEX_STATUS => v_out,PO_INDEX_NAME=> v_index_name_returned,PO_IS_UNIQUE=> v_uniqueness_returned,PO_CREATE_DDL=> v_create_index_ddl); if v_out = 1 then :1 := ''INDEX ' ||
             PI_INDEX_NAME || ' created on columns ''' ||
             REGEXP_REPLACE(srcstr     => PI_COL_LIST,
                            pattern    => ''',''',
                            replacestr => '-') ||
             '''''; elsif v_out = 4 then :1 := ''Maximum key length exceeded when trying to create INDEX ' ||
             PI_INDEX_NAME ||
             ' on key columns '';end if;  if v_out = 1 then COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID => null,PI_INDEX_NAME=> v_index_name_returned,PI_TABLE_NAME => v_tablename,PI_COLUMN_LIST => COLTYPE_INDEXED_COLUMNS_LIST(' ||
             PI_COL_LIST ||
             '),PI_RECREATE_INDEX_ON_COL_DROP => 1,PI_BUSINESS_NAME=> ''' ||
             PI_BUSINESS_NAME || ''',PI_IS_UNIQUE => ' || PI_UNIQUENESS ||
             ',PI_INDEX_TYPE => 1,PI_INDEX_INSERT_DDL  => v_create_index_ddl,PI_IS_PRIMARY=> ' ||
             PI_IS_PRIMARY_KEY ||
             '); elsif v_out = 2 then COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID => null,PI_INDEX_NAME => v_index_name_returned,PI_TABLE_NAME => v_tablename,PI_COLUMN_LIST => COLTYPE_INDEXED_COLUMNS_LIST(' ||
             PI_COL_LIST ||
             '), PI_RECREATE_INDEX_ON_COL_DROP => 1,PI_BUSINESS_NAME => ''' ||
             PI_BUSINESS_NAME || ''',PI_IS_UNIQUE => ' || PI_UNIQUENESS ||
             ',PI_INDEX_TYPE => 1); end if; END;';

    RETURN v_out;
  END CREATE_CLOB;*/

  -- OF-30537 START
  FUNCTION CREATE_CLOB2(PI_TABLE_NAME      IN VARCHAR2,
                        PI_INDEX_NAME      IN VARCHAR2,
                        PI_COL_LIST        IN VARCHAR2,
                        PI_BUSINESS_NAME   IN VARCHAR2,
                        PI_IS_PRIMARY_KEY  IN NUMBER,
                        PI_UNIQUENESS      IN NUMBER,
                        PI_TABLESPACE_NAME IN VARCHAR2,
                        PI_RUN_ID          IN NUMBER DEFAULT NULL,
                        PI_TRANSACTION_ID  IN VARCHAR2) RETURN CLOB IS
    v_out CLOB;
  BEGIN

    -- INSERT_LOGS('CREATE_INDEX2 called 1 from create clob 2');
	--additional fix; v_index_name_returned is passed to merge_air proc
    v_out := 'DECLARE v_out number;v_tablename  VARCHAR2(30) := ''' ||
             PI_TABLE_NAME ||
             ''';v_index_name_returned VARCHAR2(30 CHAR);v_uniqueness_returned VARCHAR2(9); v_op_indexing_info VARCHAR2(1000 CHAR); v_create_index_ddl CLOB;
    BEGIN COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME=>v_tablename, PI_INDEX_TABLESPACE => ''' ||
             PI_TABLESPACE_NAME || ''' , PI_TRANSACTION_ID =>
             ''' || PI_TRANSACTION_ID || ''', PI_INDEX_NAME =>
             ''' || PI_INDEX_NAME ||
             ''', PI_COLUMN_LIST => SYS.HSBLKNAMLST(' || PI_COL_LIST ||
             '), PI_UNIQUENESS => ' || PI_UNIQUENESS || ', PI_COL_IS_PRIMARYKEY =>
             ' || PI_IS_PRIMARY_KEY || ', ' || CASE
               WHEN PI_RUN_ID IS NULL THEN
                ' PI_RUN_ID => null '
               ELSE
                ' PI_RUN_ID => '
             END || PI_RUN_ID || ', ' ||
             ' PO_INDEX_STATUS =>
             v_out, PO_INDEX_NAME => v_index_name_returned, PO_IS_UNIQUE =>
             v_uniqueness_returned, PO_CREATE_DDL => v_create_index_ddl);
    COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => NULL,
                               PI_INDEX_NAME                 => v_index_name_returned,
                               PI_TABLE_NAME                 => ''' ||
             PI_TABLE_NAME || ''',
                               PI_COLUMN_LIST                => ''' ||
             REPLACE(PI_COL_LIST, '''', '') || ''',
                               PI_RECREATE_INDEX_ON_COL_DROP => 1,
                               PI_BUSINESS_NAME              => ''' ||
             PI_BUSINESS_NAME || ''',
                               PI_IS_UNIQUE                  => ' ||
             PI_UNIQUENESS || ',
                               PI_INDEX_TYPE                 => 1,
                               PI_STATUS                     => 2);
    if v_out = 1 then :1 := ''INDEX ' || PI_INDEX_NAME ||
             ' created on columns ''' ||
             REGEXP_REPLACE(srcstr     => PI_COL_LIST,
                            pattern    => ''',''',
                            replacestr => '-') ||
             '''''; elsif v_out = 4 then :1 := ''Maximum key length exceeded when trying to create INDEX ' ||
             PI_INDEX_NAME ||
             ' on key columns '';end if;
    if v_out = 1 then
      COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              => null,
                                                    PI_INDEX_NAME                 => v_index_name_returned,
                                                    PI_TABLE_NAME                 => v_tablename,
                                                    PI_COLUMN_LIST                => COLTYPE_INDEXED_COLUMNS_LIST(' ||
             PI_COL_LIST || '),
                                                    PI_RECREATE_INDEX_ON_COL_DROP => 1,
                                                    PI_BUSINESS_NAME              => ''' ||
             PI_BUSINESS_NAME || ''',
                                                    PI_IS_UNIQUE                  => ' ||
             PI_UNIQUENESS || ',
                                                    PI_INDEX_TYPE                 => 1,
                                                    PI_INDEX_INSERT_DDL           => v_create_index_ddl,
                                                    PI_IS_PRIMARY                 => ' ||
             PI_IS_PRIMARY_KEY || ');
    elsif v_out = 2 then
      COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID              => null,
                                                   PI_INDEX_NAME                 => v_index_name_returned,
                                                   PI_TABLE_NAME                 => v_tablename,
                                                   PI_COLUMN_LIST                => COLTYPE_INDEXED_COLUMNS_LIST(' ||
             PI_COL_LIST || '),
                                                   PI_RECREATE_INDEX_ON_COL_DROP => 1,
                                                   PI_BUSINESS_NAME              => ''' ||
             PI_BUSINESS_NAME || ''',
                                                   PI_IS_UNIQUE                  => ' ||
             PI_UNIQUENESS || ',
                                                   PI_INDEX_TYPE                 => 1);
    end if;
  END;
 ';
    RETURN v_out;

  END CREATE_CLOB2;
  -- OF-30537 END

  /*  FUNCTION UPDATE_CLOB(PI_TABLE_NAME      IN VARCHAR2,
                         PI_INDEX_NAME      IN VARCHAR2,
                         PI_COL_LIST        IN VARCHAR2,
                         PI_BUSINESS_NAME   IN VARCHAR2,
                         PI_IS_PRIMARY_KEY  IN NUMBER,
                         PI_UNIQUENESS      IN NUMBER,
                         PI_TABLESPACE_NAME IN VARCHAR2,
                         PI_RUN_ID          IN NUMBER DEFAULT NULL)
      RETURN VARCHAR2 IS
      V_OUT VARCHAR2(4000 CHAR);
    BEGIN

      V_OUT := 'DECLARE  V_INDEX_STATUS  NUMBER;  V_TABLENAME VARCHAR2(30 CHAR) := ''' ||
               PI_TABLE_NAME ||
               '''; V_INDEX_NAME_RETURNED VARCHAR2(30 CHAR);V_UNIQUENESS_RETURNED VARCHAR2(9 CHAR);V_OP_INDEXING_INFO    VARCHAR2(1000 CHAR); V_INDEX_NAME_INPUT    VARCHAR2(30 CHAR) := ''' ||
               PI_INDEX_NAME ||
               '''; V_COL_LIST COLTYPE_INDEXED_COLUMNS_LIST := COLTYPE_INDEXED_COLUMNS_LIST(' ||
               PI_COL_LIST || ');V_BUSINESS_NAME VARCHAR2(60 CHAR) := ''' ||
               PI_BUSINESS_NAME ||
               '''; v_create_index_ddl   CLOB; BEGIN COMMONS_INDEXING.CREATE_INDEX1(PI_TABLE_NAME => V_TABLENAME, PI_INDEX_TABLESPACE => ''' ||
               PI_TABLESPACE_NAME || ''', PI_INDEX_NAME => ''' || PI_INDEX_NAME ||
               ''',PI_COL_LIST => SYS.HSBLKNAMLST(' || PI_COL_LIST ||
               '),PI_UNIQUENESS=> ' || PI_UNIQUENESS ||
               ',PI_COL_IS_PRIMARYKEY => ' || PI_IS_PRIMARY_KEY || ',' || CASE
                 WHEN PI_RUN_ID IS NULL THEN
                  'PI_RUN_ID => null'
                 ELSE
                  ' PI_RUN_ID => '
               END || PI_RUN_ID || ',' ||
               'PO_INDEX_STATUS => V_INDEX_STATUS,PO_INDEX_NAME => V_INDEX_NAME_RETURNED,PO_IS_UNIQUE => V_UNIQUENESS_RETURNED,PO_CREATE_DDL=> v_create_index_ddl); if V_INDEX_STATUS = 1 then V_OP_INDEXING_INFO := ''INDEX ' ||
               PI_INDEX_NAME || ' created on columns ''' ||
               REGEXP_REPLACE(srcstr     => PI_COL_LIST,
                              pattern    => ''',''',
                              replacestr => '-') ||
               '''''; elsif V_INDEX_STATUS = 4 then V_OP_INDEXING_INFO := ''Maximum key length exceeded when trying to create INDEX ' ||
               PI_INDEX_NAME || ' on columns ''; end if;
    :1 := V_OP_INDEXING_INFO; :2 := V_INDEX_STATUS; :3 := V_INDEX_NAME_RETURNED; :4 := V_UNIQUENESS_RETURNED;:5 := V_INDEX_NAME_INPUT;:6 := V_COL_LIST;:7 := V_BUSINESS_NAME;:8 := v_create_index_ddl;
  END;';
      RETURN V_OUT;
    END UPDATE_CLOB;*/

  -- OF-30537 START
  FUNCTION UPDATE_CLOB2(PI_TABLE_NAME      IN VARCHAR2,
                        PI_INDEX_NAME      IN VARCHAR2,
                        PI_COL_LIST        IN VARCHAR2,
                        PI_BUSINESS_NAME   IN VARCHAR2,
                        PI_IS_PRIMARY_KEY  IN NUMBER,
                        PI_UNIQUENESS      IN NUMBER,
                        PI_TABLESPACE_NAME IN VARCHAR2,
                        PI_RUN_ID          IN NUMBER DEFAULT NULL,
                        PI_TRANSACTION_ID  IN VARCHAR2) RETURN VARCHAR2 IS
    V_OUT VARCHAR2(4000 CHAR);
  BEGIN
    V_OUT := 'DECLARE  V_INDEX_STATUS  NUMBER;  V_TABLENAME VARCHAR2(30 CHAR) := ''' ||
             PI_TABLE_NAME ||
             '''; V_INDEX_NAME_RETURNED VARCHAR2(30 CHAR);V_UNIQUENESS_RETURNED VARCHAR2(9 CHAR);V_OP_INDEXING_INFO    VARCHAR2(1000 CHAR); V_INDEX_NAME_INPUT    VARCHAR2(30 CHAR) := ''' ||
             PI_INDEX_NAME ||
             '''; V_COL_LIST COLTYPE_INDEXED_COLUMNS_LIST := COLTYPE_INDEXED_COLUMNS_LIST(' ||
             PI_COL_LIST || ');V_BUSINESS_NAME VARCHAR2(60 CHAR) := ''' ||
             PI_BUSINESS_NAME ||
             '''; v_create_index_ddl   CLOB; BEGIN COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME => V_TABLENAME, PI_INDEX_TABLESPACE => ''' ||
             PI_TABLESPACE_NAME || ''', PI_TRANSACTION_ID =>''' ||
             PI_TRANSACTION_ID || ''',PI_INDEX_NAME => ''' || PI_INDEX_NAME ||
             ''',PI_COLUMN_LIST => SYS.HSBLKNAMLST(' || PI_COL_LIST ||
             '),PI_UNIQUENESS => ' || PI_UNIQUENESS ||
             ',PI_COL_IS_PRIMARYKEY => ' || PI_IS_PRIMARY_KEY || ',' || CASE
               WHEN PI_RUN_ID IS NULL THEN
                'PI_RUN_ID => null'
               ELSE
                ' PI_RUN_ID => '
             END || PI_RUN_ID || ',' || 'PO_INDEX_STATUS => V_INDEX_STATUS,PO_INDEX_NAME => V_INDEX_NAME_RETURNED,PO_IS_UNIQUE => V_UNIQUENESS_RETURNED,PO_CREATE_DDL=> v_create_index_ddl);
            COMMONS_INDEXING.MERGE_AIR(
      PI_DEFINITION_ID =>NULL,
      PI_INDEX_NAME =>''' || PI_INDEX_NAME || ''',
      PI_TABLE_NAME =>''' || PI_TABLE_NAME || ''',
      PI_COLUMN_LIST =>''' || REPLACE(PI_COL_LIST, '''', '') || ''',
      PI_RECREATE_INDEX_ON_COL_DROP =>1,
      PI_BUSINESS_NAME =>''' || PI_BUSINESS_NAME || ''',
      PI_IS_UNIQUE =>' || PI_UNIQUENESS || ',
      PI_INDEX_TYPE =>1,
      PI_STATUS =>2
    );
    if V_INDEX_STATUS = 1 then V_OP_INDEXING_INFO := ''INDEX ' ||
             PI_INDEX_NAME || ' created on columns ''' ||
             REGEXP_REPLACE(srcstr     => PI_COL_LIST,
                            pattern    => ''',''',
                            replacestr => '-') ||
             '''''; elsif V_INDEX_STATUS = 4 then V_OP_INDEXING_INFO := ''Maximum key length exceeded when trying to create INDEX ' ||
             PI_INDEX_NAME || ' on columns ''; end if;
  :1 := V_OP_INDEXING_INFO; :2 := V_INDEX_STATUS; :3 := V_INDEX_NAME_RETURNED; :4 := V_UNIQUENESS_RETURNED;:5 := V_INDEX_NAME_INPUT;:6 := V_COL_LIST;:7 := V_BUSINESS_NAME;:8 := v_create_index_ddl;
  END;';

    RETURN V_OUT;
  END UPDATE_CLOB2;
  -- OF-30537 END

  PROCEDURE CREATE_CORE_INDEXES(PI_TABLES_ID                 IN NUMBER,
                                PI_RUN_ID                    IN NUMBER DEFAULT NULL,
                                pi_process_id                IN NUMBER DEFAULT NULL,
                                PI_TABLE_NAME                IN VARCHAR2,
                                PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX,
                                PI_INDEX_TABLESPACE          IN NUMBER,
                                PI_TRANSACTION_ID            IN VARCHAR2,
                                PO_LOG_MSG                   OUT VARCHAR2) IS
    V_TABLENAME      VARCHAR2(30 CHAR) := '';
    V_NEW_LINE       VARCHAR2(30 CHAR) := CHR(13) || CHR(10);
    V_INDEXING_INFO  VARCHAR2(32767 CHAR) := '';
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    /*TYPE RECTYPE_INDEX_CREATION_CALLS IS RECORD(
    INDEX_TYPES          VARCHAR2(30 CHAR),
    INDEX_CREATION_CALLS VARCHAR2(32767 CHAR));*/

    TYPE TAB_INDEX_TYPES IS TABLE OF VARCHAR2(30 CHAR);
    V_INDEX_TYPES TAB_INDEX_TYPES;

    TYPE TAB_INDEX_CREATION_CALLS IS TABLE OF CLOB;
    V_INDEX_CREATION_CALLS TAB_INDEX_CREATION_CALLS;
    --TYPE COLTYPE_INDEX_CREATION_INFO IS TABLE OF RECTYPE_INDEX_CREATION_CALLS;

    --V_INDEX_CREATION_COLLECTION COLTYPE_INDEX_CREATION_INFO;

    V_SKIP_BK_INDEX         NUMBER := 0;
    V_LOG_MESSAGE           CLOB;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
    v_col_name_list         VARCHAR2(32767 CHAR);
    v_col_list              VARCHAR2(32767 CHAR);
    v_index_type            VARCHAR2(30 CHAR) := '';
  BEGIN

    IF PI_INDEX_CREATION_COLLECTION.COUNT = 0 THEN
      RETURN;
    END IF;

    V_TABLENAME := PI_TABLE_NAME;
    BEGIN
      SELECT USER ||
             DECODE(PI_INDEX_TABLESPACE, 1, '_IND', 2, '_IND', 3, '_OUT')
        INTO V_INDEX_TABLESPACE_NAME
        from dual;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    FOR i in (SELECT picc.OCTI_TC_PHYSICAL_NAME col_name
                FROM table(PI_INDEX_CREATION_COLLECTION) picc
               WHERE picc.OCTI_TC_LOGIC_TYPE IN (1, 3, 5, 6, 8, 9)
               order by picc.OCTI_TC_IS_NULLABLE, picc.OCTI_TC_ORDER) LOOP
      v_col_list := v_col_list || '''' || i.col_name || '''' || ',';
    END LOOP;

    SELECT rtrim(v_col_list, ',') INTO v_col_list FROM dual;

    IF V_TABLENAME IS NOT NULL THEN
      V_LOG_MESSAGE := '       INDEXES CREATED ON TABLE: ' || V_TABLENAME;
      V_LOG_MESSAGE := V_LOG_MESSAGE || V_NEW_LINE ||
                       '       =====================================  ' ||
                       V_NEW_LINE;

      WITH q AS
       (SELECT
        --PRIMARY_KEY
         COMMONS_INDEXING.CREATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                       PI_INDEX_NAME      => 'PK_' ||
                                                             V_TABLENAME,
                                       PI_COL_LIST        => '''' ||
                                                             picc.OCTI_TC_PHYSICAL_NAME || '''',
                                       PI_BUSINESS_NAME   => 'CORE__PRIMARY_KEY',
                                       PI_IS_PRIMARY_KEY  => 1,
                                       PI_UNIQUENESS      => 1,
                                       PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                       PI_RUN_ID          => PI_RUN_ID,
                                       PI_TRANSACTION_ID  => PI_TRANSACTION_ID) V_INDEX_CREATION,
         'PRIMARY_KEY' AS index_types
          FROM table(PI_INDEX_CREATION_COLLECTION) picc
         where picc.OCTI_TC_PHYSICAL_NAME = 'ROW_IDENTIFIER'
        UNION ALL
        SELECT
        --AUTO_BUSINESS_KEY
         COMMONS_INDEXING.CREATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                       PI_INDEX_NAME      => 'T' ||
                                                             PI_TABLES_ID ||
                                                             '_BUSINESSKEY_UI',
                                       PI_COL_LIST        => '''' ||
                                                             picc.OCTI_TC_PHYSICAL_NAME || '''',
                                       PI_BUSINESS_NAME   => 'CORE__BUSINESS_KEY',
                                       PI_IS_PRIMARY_KEY  => 0,
                                       PI_UNIQUENESS      => 1,
                                       PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                       PI_RUN_ID          => PI_RUN_ID,
                                       PI_TRANSACTION_ID  => PI_TRANSACTION_ID) V_INDEX_CREATION,
         'B_AUTO_BUSINESSKEY_INDEX' AS index_types
          FROM table(PI_INDEX_CREATION_COLLECTION) picc
         where picc.OCTI_TC_LOGIC_TYPE = 5
        UNION ALL
        SELECT
        --business_key
         COMMONS_INDEXING.CREATE_CLOB2(PI_TABLE_NAME      => v_tablename,
                                       PI_INDEX_NAME      => 'T' ||
                                                             PI_TABLES_ID ||
                                                             '_BUSINESSKEY_UI',
                                       PI_COL_LIST        => v_col_list,
                                       PI_BUSINESS_NAME   => 'CORE__BUSINESS_KEY',
                                       PI_IS_PRIMARY_KEY  => 0,
                                       PI_UNIQUENESS      => 1,
                                       PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                       PI_RUN_ID          => PI_RUN_ID,
                                       PI_TRANSACTION_ID  => V_TRANSACTION_ID) V_INDEX_CREATION,
         'BUSINESS_KEY' AS index_types
          FROM DUAL
        --FROM table(PI_INDEX_CREATION_COLLECTION) picc
        --where picc.OCTI_TC_LOGIC_TYPE IN (1, 3, 5, 6, 8, 9)
        UNION ALL
        SELECT
        --ENTITY_KEY
         COMMONS_INDEXING.CREATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                       PI_INDEX_NAME      => 'T' ||
                                                             PI_TABLES_ID || '_' || picc
                                                            .OCTI_TC_PHYSICAL_NAME ||
                                                             '_SI',
                                       PI_COL_LIST        => '''' ||
                                                             picc.OCTI_TC_PHYSICAL_NAME || '''',
                                       PI_BUSINESS_NAME   => 'CORE__ENTITY__' ||
                                                             picc.OCTI_TC_PHYSICAL_NAME,
                                       PI_IS_PRIMARY_KEY  => 0,
                                       PI_UNIQUENESS      => 0,
                                       PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                       PI_RUN_ID          => PI_RUN_ID,
                                       PI_TRANSACTION_ID  => PI_TRANSACTION_ID) V_INDEX_CREATION,
         'ENTITY_KEY' AS index_types
          FROM table(PI_INDEX_CREATION_COLLECTION) picc
         where picc.OCTI_TC_COLUMN_TYPE = 1
        UNION ALL
        SELECT
        --E_INTERNAL_ID
         COMMONS_INDEXING.CREATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                       PI_INDEX_NAME      => V_TABLENAME ||
                                                             '_E_INTERNAL_ID_UI',
                                       PI_COL_LIST        => '''E_INTERNAL_ID''',
                                       PI_BUSINESS_NAME   => 'CORE__E_INTERNAL_ID',
                                       PI_IS_PRIMARY_KEY  => 0,
                                       PI_UNIQUENESS      => 1,
                                       PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                       PI_RUN_ID          => PI_RUN_ID,
                                       PI_TRANSACTION_ID  => PI_TRANSACTION_ID) V_INDEX_CREATION,
         'E_INTERNAL_ID' AS index_types
          FROM table(PI_INDEX_CREATION_COLLECTION) picc
         where picc.OCTI_TC_PHYSICAL_NAME = 'E_INTERNAL_ID'
        UNION ALL
        SELECT
        --PERIOD
         COMMONS_INDEXING.CREATE_CLOB2(PI_TABLE_NAME      => V_TABLENAME,
                                       PI_INDEX_NAME      => 'T' ||
                                                             PI_TABLES_ID || '_' || picc
                                                            .OCTI_TC_PHYSICAL_NAME ||
                                                             '_SI',
                                       PI_COL_LIST        => '''' || picc
                                                            .OCTI_TC_PHYSICAL_NAME || '''',
                                       PI_BUSINESS_NAME   => 'CORE__PERIOD__' || picc
                                                            .OCTI_TC_PHYSICAL_NAME,
                                       PI_IS_PRIMARY_KEY  => 0,
                                       PI_UNIQUENESS      => 0,
                                       PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                       PI_RUN_ID          => PI_RUN_ID,
                                       PI_TRANSACTION_ID  => PI_TRANSACTION_ID) V_INDEX_CREATION,
         'PERIOD' AS index_types
          FROM table(PI_INDEX_CREATION_COLLECTION) picc
         where picc.OCTI_FLD_DATA_TYPE = 8)
      SELECT V_INDEX_CREATION, index_types
        BULK COLLECT
        INTO V_INDEX_CREATION_CALLS, V_INDEX_TYPES
        from q;
    END IF;

    -- Fix for Defect# 14157 -- Check if V_INDEX_CREATION_COLLECTION is EMPTY or not.
    IF V_INDEX_CREATION_CALLS.COUNT > 0 THEN
      FOR C IN V_INDEX_CREATION_CALLS.FIRST .. V_INDEX_CREATION_CALLS.LAST LOOP
        IF V_SKIP_BK_INDEX = 1 THEN
          -- Reset the variable to 0 to allow processing other core indexes.
          V_SKIP_BK_INDEX := 0;
          CONTINUE;
        END IF;

        V_INDEXING_INFO := '';

        -- INSERT_LOGS(V_INDEX_CREATION_COLLECTION(C).INDEX_CREATION_CALLS);
        EXECUTE IMMEDIATE V_INDEX_CREATION_CALLS(C)
          USING OUT V_INDEXING_INFO;

        IF V_INDEXING_INFO IS NOT NULL THEN
          V_LOG_MESSAGE := V_LOG_MESSAGE || V_INDEXING_INFO || V_NEW_LINE;
        END IF;

        IF V_INDEX_TYPES(c) = 'B_AUTO_BUSINESSKEY_INDEX' THEN
          --Set the variable to skip business key index
          V_SKIP_BK_INDEX := 1;
        END IF;

        /*CHANGES FOR OF-25938 STARTS*/
        /*IF LOWER(V_INDEXING_INFO) LIKE 'maximum key length exceeded%' THEN
          RAISE_APPLICATION_ERROR(-20145,V_INDEXING_INFO);
        END IF;*/
        /*CHANGES FOR OF-25938 ENDS*/
      END LOOP;
    END IF;

    PO_LOG_MSG := SUBSTR(V_LOG_MESSAGE, 1, 32767);
    -- INSERT_LOGS('CREATE_CORE_INDEXES ended');
  END CREATE_CORE_INDEXES;

  PROCEDURE RENAME_INDEX(PI_INDEX_NAME     IN VARCHAR2,
                         PI_UNIQUE_ID      IN NUMBER DEFAULT NULL,
                         PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                         PI_RUN_ID         IN NUMBER DEFAULT NULL,
                         PI_TRANSACTION_ID IN VARCHAR2, --sales change
                         PI_NEW_INDEX_NAME IN VARCHAR2 DEFAULT NULL -- OF-69424
                         ) IS
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    V_INDEX          NUMBER(10, 0);
    V_DDL            CLOB;
    V_UNDO_DDL       CLOB;
    V_OLD_INDEX      VARCHAR2(30 CHAR) := PI_INDEX_NAME;
    V_UNIQUE_ID      NUMBER(10) := PI_UNIQUE_ID;
    V_PROCESS_ID     NUMBER(10) := PI_PROCESS_ID;
    V_RUN_ID         NUMBER(10) := PI_RUN_ID;
    V_OLD_CONSTRAINT VARCHAR2(30 CHAR);
    V_NEW_CONSTRAINT VARCHAR2(30 CHAR);
    V_TABLENAME      VARCHAR2(30 CHAR);
    V_NEW_INDEX      VARCHAR2(30 CHAR);
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    --INSERT_LOGS('RENAME_INDEX');
    -- Get the transaction id
    --commented as will get transaction id from java
    --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

 /* OF-69424 start -- not required hence removed
    SELECT NVL(MAX(UD_INDEX), 0)
      INTO V_INDEX
      FROM UNDO_DDL
     WHERE UD_TRANSACTION_ID = V_TRANSACTION_ID; */
/* OF-69424 end*/

    --INSERT_LOGS('V_INDEX: ' || V_INDEX);
if PI_NEW_INDEX_NAME is null then -- OF-69424
    IF PI_UNIQUE_ID IS NOT NULL AND PI_PROCESS_ID IS NOT NULL AND
       PI_RUN_ID IS NOT NULL THEN
      V_NEW_INDEX := 'I_' || V_UNIQUE_ID || '_' || V_PROCESS_ID || '_' ||
                     V_RUN_ID;
    ELSE
      V_NEW_INDEX := SUBSTR(V_OLD_INDEX, 1, 26) || '_BKP';
    END IF;
/*OF-69424 start  */
 else
    V_NEW_INDEX := PI_NEW_INDEX_NAME;
 end if;
/*OF-69424 end  */

    SELECT UI.TABLE_NAME,
           CASE
             WHEN UC.CONSTRAINT_NAME IS NOT NULL THEN
              UC.CONSTRAINT_NAME
           END
      INTO V_TABLENAME, V_OLD_CONSTRAINT
      FROM USER_INDEXES UI
      LEFT OUTER JOIN USER_CONSTRAINTS UC
        ON (UI.TABLE_NAME = UC.TABLE_NAME AND UI.INDEX_NAME = UC.INDEX_NAME)
     WHERE UI.INDEX_NAME = V_OLD_INDEX;

    IF V_OLD_CONSTRAINT IS NOT NULL THEN
      IF PI_UNIQUE_ID IS NOT NULL AND PI_PROCESS_ID IS NOT NULL AND
         PI_RUN_ID IS NOT NULL THEN
        V_NEW_CONSTRAINT := 'C_' || V_UNIQUE_ID || '_' || V_PROCESS_ID || '_' ||
                            V_RUN_ID;
      ELSE
        V_NEW_CONSTRAINT := SUBSTR(V_OLD_CONSTRAINT, 1, 26) || '_BKP';
      END IF;

      -- INSERT_LOGS ('RENAME_INDEX - V_OLD_INDEX = PI_INDEX_NAME = ' || V_OLD_INDEX);
      -- INSERT_LOGS ('RENAME_INDEX - V_NEW_INDEX = ' || V_NEW_INDEX);
      -- INSERT_LOGS ('RENAME_INDEX - V_OLD_CONSTRAINT = ' || V_OLD_CONSTRAINT);
      -- INSERT_LOGS ('RENAME_INDEX - V_NEW_CONSTRAINT = ' || V_NEW_CONSTRAINT);
      -- INSERT_LOGS ('RENAME_INDEX - V_TABLENAME = ' || V_TABLENAME);

      V_DDL      := '
        BEGIN
          EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                    V_OLD_INDEX || ' RENAME TO ' || V_NEW_INDEX ||
                    ''' ;
          EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                    V_TABLENAME || ' RENAME CONSTRAINT ' ||
                    V_OLD_CONSTRAINT || ' TO ' || V_NEW_CONSTRAINT ||
                    ''' ;
        END;';
      V_UNDO_DDL := '
        BEGIN
          FOR C IN (SELECT 1 FROM DUAL WHERE EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                    V_NEW_INDEX ||
                    ''')))
          LOOP
            FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                    V_OLD_INDEX ||
                    ''')))
            LOOP
              EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                    V_NEW_INDEX || ' RENAME TO ' || V_OLD_INDEX || ''';
              EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                    V_TABLENAME || ' RENAME CONSTRAINT ' ||
                    V_NEW_CONSTRAINT || ' TO ' || V_OLD_CONSTRAINT ||
                    ''' ;
            END LOOP ;
          END LOOP ;
        END;';
    ELSIF V_OLD_CONSTRAINT IS NULL THEN
      V_DDL      := 'ALTER INDEX ' || V_OLD_INDEX || ' RENAME TO ' ||
                    V_NEW_INDEX;
      V_UNDO_DDL := '
        BEGIN
          FOR C IN (SELECT 1 FROM DUAL WHERE EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                    v_new_index ||
                    ''')))
          LOOP
            FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                    V_OLD_INDEX ||
                    ''')))
            LOOP
              EXECUTE IMMEDIATE ''ALTER INDEX ' ||
                    V_NEW_INDEX || ' RENAME TO ' || V_OLD_INDEX || ''';
            END LOOP ;
          END LOOP ;
        END;';
    END IF;

    -- INSERT_LOGS ('RENAME_INDEX - BEFORE EXECUTE_DDL');
    BEGIN
      COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                       PI_DESCRIPTION    => 'RENAME INDEX ' ||
                                                            PI_INDEX_NAME,
                                       PI_DDL            => V_DDL,
                                       PI_UNDO_DDL       => V_UNDO_DDL,
                                       -- PI_INDEX          => V_INDEX + 1,   /*No OF-id, removed this parameter as per the latest DDL changes by Lucian: Dt: 7.Apr.2014 */
                                       pi_run_id => PI_RUN_ID); --FIX FOR OF-11231
      -- INSERT_LOGS ('RENAME_INDEX - AFTER EXECUTE_DDL SUCCESSFUL - NO EXCEPTION');
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
        -- INSERT_LOGS ('RENAME_INDEX - EXECUTE_DDL - EXCEPTION - SQLERRM = ' || SQLERRM);
    END;
    -- INSERT_LOGS ('RENAME_INDEX - END');

    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END RENAME_INDEX;

/* OF-69424 start */
/*
  -- OF-31885 - START
  PROCEDURE RENAME_BK_INDEX(PI_INDEX_NAME     IN VARCHAR2,
                            PI_UNIQUE_ID      IN NUMBER DEFAULT NULL,
                            PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                            PI_RUN_ID         IN NUMBER DEFAULT NULL,
                            PI_TRANSACTION_ID IN VARCHAR2 --sales change
                            ) IS
    V_OLD_INDEX      VARCHAR2(30 CHAR) := PI_INDEX_NAME;
    V_UNIQUE_ID      NUMBER(10) := PI_UNIQUE_ID;
    V_PROCESS_ID     NUMBER(10) := PI_PROCESS_ID;
    V_RUN_ID         NUMBER(10) := PI_RUN_ID;
    V_TABLENAME      VARCHAR2(30 CHAR);
    V_NEW_INDEX      VARCHAR2(30 CHAR);
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
  BEGIN

    IF PI_UNIQUE_ID IS NOT NULL AND PI_PROCESS_ID IS NOT NULL AND
       PI_RUN_ID IS NOT NULL THEN
      V_NEW_INDEX := 'I_' || V_UNIQUE_ID || '_' || V_PROCESS_ID || '_' ||
                     V_RUN_ID;
    ELSE
      V_NEW_INDEX := SUBSTR(V_OLD_INDEX, 1, 26) || '_BKP';
    END IF;

    --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

    SELECT UI.TABLE_NAME
      INTO V_TABLENAME
      FROM USER_INDEXES UI
     WHERE UI.INDEX_NAME = V_OLD_INDEX;

    -- INSERT_LOGS ('RENAME_BK_INDEX - V_OLD_INDEX = PI_INDEX_NAME = ' || V_OLD_INDEX);
    -- INSERT_LOGS ('RENAME_BK_INDEX - V_NEW_INDEX = ' || V_NEW_INDEX);
    -- INSERT_LOGS ('RENAME_BK_INDEX - V_TABLENAME = ' || V_TABLENAME);

    -- Call RENAME_INDEX procedure to rename the Index
    COMMONS_INDEXING.RENAME_INDEX(PI_INDEX_NAME     => PI_INDEX_NAME,
                                  PI_UNIQUE_ID      => PI_UNIQUE_ID,
                                  PI_PROCESS_ID     => PI_PROCESS_ID,
                                  PI_RUN_ID         => PI_RUN_ID,
                                  PI_TRANSACTION_ID => V_TRANSACTION_ID);
    -- INSERT_LOGS ('RENAME_BK_INDEX - AFTER RENAME_INDEX SUCCESSFUL');

    COMMONS_INDEXING.UPDATE_AIM1(PI_TABLE_NAME     => V_TABLENAME,
                                 PI_INDEX_NAME     => V_NEW_INDEX,
                                 PI_COL_LIST       => NULL,
                                 PI_OLD_INDEX_NAME => V_OLD_INDEX,
                                 PI_INDEX_TYPE     => NULL,
                                 PI_UPDATE_DDL     => NULL,
                                 PI_AIM_ID         => NULL,
                                 PI_DEFINITION_ID  => NULL,
                                 PI_BUSINESS_NAME  => NULL);
    -- INSERT_LOGS ('RENAME_BK_INDEX - AFTER UPDATE_AIM1 SUCCESSFUL - END RENAME_BK_INDEX');

  END RENAME_BK_INDEX;
  -- OF-31885 - END
*/
/* OF-69424 ends */
  PROCEDURE DELETE_INDEXES(PI_TABLE_NAME     IN VARCHAR2, --sales change
                           PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                           PI_RUN_ID         IN NUMBER DEFAULT NULL,
                           PI_TRANSACTION_ID IN VARCHAR2,
                           PO_LOG_MSG        OUT VARCHAR2) IS
    V_TABLENAME      VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_PROCESS_ID     NUMBER(10) := PI_PROCESS_ID;
    V_RUN_ID         NUMBER(10) := PI_RUN_ID;
    V_NEW_LINE       VARCHAR2(30 CHAR) := CHR(13) || CHR(10);
    V_LOG_MESSAGE    CLOB;
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    --V_PR_VALUE    VARCHAR2(1300 char);
    --V_IS_EXEC     BOOLEAN;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    --INSERT_LOGS('DELETE_INDEXES');
    -- If table exists
    IF V_TABLENAME IS NOT NULL THEN
      V_LOG_MESSAGE := V_NEW_LINE || 'Indexes to be deleted on table ' ||
                       V_TABLENAME;
      --INSERT_LOGS('V_LOG_MESSAGE: ' || V_LOG_MESSAGE);
      -- Delete the Application_indexes_metadata for the table
      -- INSERT_LOGS('DELETE_AIM_BY_TABLE : PI_TABLE_NAME => ' || V_TABLENAME);
      COMMONS_INDEXING.DELETE_AIM_BY_TABLE(PI_TABLE_NAME => v_TABLENAME);

      -- Delete from AIM_INDEX_DDL_STORAGE table
      DELETE FROM AIM_INDEX_DDL_STORAGE AIM
       WHERE AIM.AIDS_TABLE_NAME = v_TABLENAME;
      -- OF-33540
      FOR I IN (SELECT AIR_DEF_ID,
                       AIR_BUSINESS_NAME,
                       AIR_INDEX_NAME,
                       AIR_TABLE_NAME,
                       AIR_INDEXED_COLUMNS,
                       AIR_IS_INDEX_TO_BE_RECREATED,
                       AIR_INDEX_IS_UNIQUE,
                       AIR_INDEX_TYPE
                  FROM APPLICATION_INDEX_REQUESTS
                 WHERE AIR_TABLE_NAME = V_TABLENAME
                   AND AIR_STATUS <> 3) LOOP
        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => I.AIR_DEF_ID,
                                   PI_INDEX_NAME                 => I.AIR_INDEX_NAME,
                                   PI_TABLE_NAME                 => I.AIR_TABLE_NAME,
                                   PI_COLUMN_LIST                => I.AIR_INDEXED_COLUMNS,
                                   PI_RECREATE_INDEX_ON_COL_DROP => I.AIR_IS_INDEX_TO_BE_RECREATED,
                                   PI_BUSINESS_NAME              => I.AIR_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => I.AIR_INDEX_IS_UNIQUE,
                                   PI_INDEX_TYPE                 => I.AIR_INDEX_TYPE,
                                   PI_STATUS                     => 3);
      END LOOP;
      FOR c IN (SELECT INDEX_NAME
                  FROM USER_INDEXES
                 WHERE TABLE_NAME = V_TABLENAME
                   AND INDEX_TYPE != 'LOB') LOOP
        --INSERT_LOGS('Calling RENAME_INDEX');
        COMMONS_INDEXING.RENAME_INDEX(PI_INDEX_NAME     => C.INDEX_NAME,
                                      PI_UNIQUE_ID      => CT_INDEX_RENAME_SEQ.NEXTVAL,
                                      PI_PROCESS_ID     => V_PROCESS_ID,
                                      PI_RUN_ID         => V_RUN_ID,
                                      PI_TRANSACTION_ID => V_TRANSACTION_ID);
        V_LOG_MESSAGE := V_LOG_MESSAGE || V_NEW_LINE || 'Index ' ||
                         C.INDEX_NAME || ' renamed successfully';
        --INSERT_LOGS('V_LOG_MESSAGE: ' || V_LOG_MESSAGE);
      END LOOP;
    END IF;

    PO_LOG_MSG := SUBSTR(V_LOG_MESSAGE, 1, 32767);
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DELETE_INDEXES;

  -- OF-15163 - START - DELETE_INDEXES_WITHOUT_IMETA, to only Rename (Functional Delete) Indexes and keep their meta intact. This way we need not create Indexing Meta again.
  PROCEDURE DELETE_INDEXES_WITHOUT_IMETA(PI_TABLE_NAME     IN VARCHAR2,
                                         PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                                         PI_RUN_ID         IN NUMBER DEFAULT NULL,
                                         PI_TRANSACTION_ID IN VARCHAR2,
                                         PO_LOG_MSG        OUT VARCHAR2) IS
    V_TABLENAME      VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_PROCESS_ID     NUMBER(10) := PI_PROCESS_ID;
    V_RUN_ID         NUMBER(10) := PI_RUN_ID;
    V_NEW_LINE       VARCHAR2(30 CHAR) := CHR(13) || CHR(10);
    V_LOG_MESSAGE    CLOB;
    V_TRANSACTION_ID VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
  BEGIN
    --sales change
    /*SELECT T.TABLES_PHYSICAL_NAME
     INTO V_TABLENAME
     FROM TABLES T
    WHERE T.TABLES_ID = PI_TABLES_ID;*/

    -- If table exists
    IF V_TABLENAME IS NOT NULL THEN
      V_LOG_MESSAGE := V_NEW_LINE || 'Indexes to be deleted on table ' ||
                       V_TABLENAME;

      FOR c IN (SELECT INDEX_NAME
                  FROM USER_INDEXES
                 WHERE TABLE_NAME = V_TABLENAME
                   AND INDEX_TYPE != 'LOB') LOOP
        COMMONS_INDEXING.RENAME_INDEX(PI_INDEX_NAME     => C.INDEX_NAME,
                                      PI_UNIQUE_ID      => CT_INDEX_RENAME_SEQ.NEXTVAL,
                                      PI_PROCESS_ID     => V_PROCESS_ID,
                                      PI_RUN_ID         => V_RUN_ID,
                                      PI_TRANSACTION_ID => V_TRANSACTION_ID);
        V_LOG_MESSAGE := V_LOG_MESSAGE || V_NEW_LINE || 'Index ' ||
                         C.INDEX_NAME || ' renamed successfully';
      END LOOP;
    END IF;

    PO_LOG_MSG := SUBSTR(V_LOG_MESSAGE, 1, 32767);
  END DELETE_INDEXES_WITHOUT_IMETA;

  -- OF-15163 - END

  PROCEDURE UPDATE_INDEXES(PI_TABLES_ID                 IN NUMBER,
                           PI_PROCESS_ID                IN NUMBER DEFAULT NULL,
                           PI_RUN_ID                    IN NUMBER DEFAULT NULL,
                           PI_TRANSACTION_ID            IN VARCHAR2,
                           PI_TABLE_NAME                IN VARCHAR2,
                           PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX, --sales change
                           PI_INDEX_TABLESPACE          IN NUMBER,
                           PI_RENAMED_INDEX_NAME        IN VARCHAR2, --sales change
                           PO_LOG_MSG                   OUT VARCHAR2) IS
    V_TABLENAME             VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_RETURNED_INDEX_NAME   VARCHAR2(30 CHAR);
    V_TRANSACTION_ID        VARCHAR2(50 CHAR) := PI_TRANSACTION_ID;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
    V_COUNT1                NUMBER(1) := 0;
    V_COUNT2                NUMBER(1) := 0;
    V_COUNT3                NUMBER(1) := 0;
    V_COUNT4                NUMBER(1) := 0;
  BEGIN
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    -- commons_utils.INSERT_LOGS('UPDATE_INDEXES - 1 - START');

    --sales change; table_name is commented as table_name is input to proc
    /*SELECT T.TABLES_PHYSICAL_NAME,
          COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
     INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
     FROM TABLES T
    WHERE T.TABLES_ID = PI_TABLES_ID;*/

    --sales change; get tablespace name based on PI_INDEX_TABLESPACE
    BEGIN
      SELECT USER ||
             DECODE(PI_INDEX_TABLESPACE, 1, '_IND', 2, '_IND', 3, '_OUT')
        INTO V_INDEX_TABLESPACE_NAME
        from dual;

    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    IF CORE_COLS_MINUS_INDEX_COLS(pi_tables_id,
                                  PI_INDEX_CREATION_COLLECTION,
                                  V_TABLENAME) = 1 OR
       INDEX_COLS_MINUS_CORE_COLS(pi_tables_id,
                                  PI_INDEX_CREATION_COLLECTION,
                                  V_TABLENAME) = 1 THEN

      COMMONS_INDEXING.UPDATE_CORE_INDEXES(PI_TABLES_ID                 => PI_TABLES_ID,
                                           PI_PROCESS_ID                => PI_PROCESS_ID,
                                           PI_RUN_ID                    => PI_RUN_ID,
                                           PI_TABLE_NAME                => V_TABLENAME,
                                           PI_INDEX_CREATION_COLLECTION => PI_INDEX_CREATION_COLLECTION, --sales change
                                           PI_INDEX_TABLESPACE          => V_INDEX_TABLESPACE_NAME,
                                           PI_TRANSACTION_ID            => V_TRANSACTION_ID,
                                           PI_RENAME_INDX_NAME          => PI_RENAMED_INDEX_NAME, --sales change
                                           PO_RENAMED_BK_INDEX_NAME     => V_RETURNED_INDEX_NAME,
                                           PO_LOG_MSG                   => PO_LOG_MSG);
    END IF;
    --sales change
    --V_TRANSACTION_ID := COMMONS_DDL_HANDLING.get_transaction_id;

    IF APP_COL_MINUS_INDEX_COL(V_TABLENAME) = 1 OR
       INDEX_COL_MINUS_APP_COL(V_TABLENAME) = 1 THEN

      COMMONS_INDEXING.UPDATE_APP_INDEX(PI_TABLE_NAME         => V_TABLENAME,
                                        PI_RENAMED_INDEX_NAME => V_RETURNED_INDEX_NAME,
                                        PI_TRANSACTION_ID     => V_TRANSACTION_ID,
                                        PI_INDEX_UPDATE_MODE  => 1, -- 1 - Update_indexes 2 - DELETE_APP_INDEXES
                                        PI_DELETED_INDEX_NAME => NULL,
                                        PI_TABLESPACE_NAME    => V_INDEX_TABLESPACE_NAME,
                                        PI_RUN_ID             => PI_RUN_ID,
                                        PI_TABLES_ID          => PI_TABLES_ID);
    END IF;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END UPDATE_INDEXES;

  PROCEDURE CREATE_APP_INDEX(PI_TABLES_ID                  IN NUMBER,
                             PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                             PI_IS_UNIQUE                  IN NUMBER,
                             PI_DEF_ID                     IN NUMBER,
                             PI_BUSINESS_NAME              IN VARCHAR2,
                             PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                             PI_PROCESS_ID                 IN NUMBER DEFAULT NULL,
                             PI_RUN_ID                     IN NUMBER DEFAULT NULL,
                             PI_TABLE_NAME                 IN VARCHAR2, --sales change
                             PI_TRANSACTION_ID             IN VARCHAR2, --sales change
                             PI_INDEX_TABLESPACE_NAME      IN VARCHAR2, --sales change
                             PO_INDEX_CREATION_STATUS      OUT NUMBER) IS
    V_TABLENAME               VARCHAR2(30) := PI_TABLE_NAME;
    V_INPUT_COLUMN_COLLECTION SYS.HSBLKNAMLST;

    V_COMMA_INPUT_COLUMN_LIST      CLOB;
    V_COLLECTION_INPUT_COLUMN_LIST COLTYPE_INDEXED_COLUMNS_LIST;
    V_INDEXNAME                    VARCHAR2(30) := '';
    V_INDEX_OUT_STATUS             NUMBER;
    V_INDEX_NAME_RETURNED          VARCHAR2(30);
    V_INDEX_CREATION_DECISION      NUMBER := 1;
    MAXIMUM_NO_OF_COLS_32 EXCEPTION;
    PRAGMA EXCEPTION_INIT(MAXIMUM_NO_OF_COLS_32, -1793);

    v_already_indexed_column_list  coltype_indexed_columns_list;
    v_already_indexed_col_list_aim VARCHAR2(1000 CHAR);
    v_update_required              NUMBER := 0;

    v_INDEX_TYPE NUMBER;

    V_UNIQUENESS_RETURNED   VARCHAR2(9);
    V_CREATE_INDEX_DDL      CLOB;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR) := PI_INDEX_TABLESPACE_NAME; /*OF-11821*/
    v_COLUMN_LIST           varchar2(1300 char);
    V_TRANSACTION_ID        VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
  BEGIN
    -- INSERT_LOGS('CREATE_APP_INDEX started with PI_TABLES_ID=>'||PI_TABLES_ID||' pi_process_id=>'||pi_process_id||' PI_RUN_ID=>'||PI_RUN_ID||' PI_COLUMN_LIST count=>'||PI_COLUMN_LIST.count||' PI_BUSINESS_NAME=>'||PI_BUSINESS_NAME);
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    --Get the table name

    --as part of SALES PLANNING changes, TABLES_PHYSICAL_NAME and INDEX_TABLESPACE_NAME will be passed as input to SP

    /*SELECT T.TABLES_PHYSICAL_NAME,
          COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
     INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
     FROM TABLES T
    WHERE T.TABLES_ID = PI_TABLES_ID;

    V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;*/

    v_INDEX_TYPE := CASE
                      WHEN PI_BUSINESS_NAME = 'CORE__BUSINESS_KEY' THEN
                       1
                      ELSE
                       2
                    END;

    --CREATE COMMA SEPARATED LIST OF COLUMN NAMES FROM THE TABLETYPE_CHARMAX INPUT COLLECTION PARAMETER PI_COLUMN_LIST
    SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
      INTO V_COMMA_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);
    SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
      INTO v_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);
    -- INSERT_LOGS('CREATE_APP_INDEX v_COLUMN_LIST=>'||v_COLUMN_LIST||'  V_COMMA_INPUT_COLUMN_LIST=>'||V_COMMA_INPUT_COLUMN_LIST);
    --Get column list into coltype_indexed_column_list format to insert/update the column list in AIM table
    SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY ROWNUM) AS
                COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
      INTO V_COLLECTION_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);

    -- Loop to determine if Record already exists or not for the input definition id and business name
    FOR c IN (SELECT AIM.*
                FROM APPLICATION_INDEXES_METADATA AIM
               WHERE AIM.AIM_TABLE_NAME = V_TABLENAME
                 AND AIM.AIM_DEF_ID = PI_DEF_ID
                 AND AIM.AIM_BUSINESS_NAME = PI_BUSINESS_NAME) LOOP
      --LOOP 1 START

      -- index already exists for the given definition Id and business name
      v_indexname                   := c.aim_index_name;
      v_already_indexed_column_list := c.aim_indexed_columns;
      v_update_required             := 1;
    END LOOP; --LOOP 1 END

    --Metadata already existing for the given definition and business name
    IF V_update_required = 1 THEN
      -- IF_1 START

      -- Create COMMA SEPARATED LIST OF ALREADY INDEXED COLUMN NAMES of AIM metadata table
      SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
        INTO v_already_indexed_col_list_aim
        FROM TABLE(v_already_indexed_column_list);

      -- if existing index columns are same as comma separated list
      IF v_already_indexed_col_list_aim LIKE
         V_COMMA_INPUT_COLUMN_LIST || '%' THEN
        -- IF_2 START

        IF V_COMMA_INPUT_COLUMN_LIST != v_already_indexed_col_list_aim THEN
          -- IF_3 START

          --update the metadata with column list provided
          UPDATE application_indexes_metadata aim
             SET aim.aim_indexed_columns = V_COLLECTION_INPUT_COLUMN_LIST
           WHERE aim.aim_table_name = V_TABLENAME
             AND aim.aim_def_id = PI_DEF_ID
             AND aim.aim_business_name = PI_BUSINESS_NAME;
          --Update the ddl metadata with the covering index name ddl

        ELSE
          -- IF_3 ELSE
          -- i.e. both column lists are equal
          -- No update required
          -- The given column list is already indexed/ using index
          --Set status to 0
          PO_INDEX_CREATION_STATUS := 0;
        END IF; -- IF_3 END
      ELSE
        -- IF_2 ELSE
        -- i.e.  the already indexed column list in AIM table is not same as column list to be indexed for the same def id and business name

        --Call Delete_APP_Index
        --Drops the old index if it was covering and recreates any feature index using the index,
        -- else if it was covered index, it just deletes the metadata)

        COMMONS_INDEXING.DELETE_APP_INDEX(PI_TABLES_ID             => PI_TABLES_ID,
                                          PI_DEF_ID                => PI_DEF_ID,
                                          PI_BUSINESS_NAME         => PI_BUSINESS_NAME,
                                          PI_PROCESS_ID            => PI_PROCESS_ID,
                                          PI_RUN_ID                => PI_RUN_ID,
                                          PI_TABLE_NAME            => V_TABLENAME, --sales change
                                          PI_INDEX_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME, --sales change
                                          PI_TRANSACTION_ID        => PI_TRANSACTION_ID --sales change
                                          );
        --set the update flag to 0
        v_update_required := 0;
      END IF; -- IF_2 END
    END IF; -- IF_1 END

    IF V_update_required = 0 THEN
      -- IF_4 START

      --Get the covering index if any
      v_indexname := GET_COVERING_INDEX(PI_TABLE_NAME  => V_TABLENAME,
                                        PI_COLUMN_LIST => V_COMMA_INPUT_COLUMN_LIST || '%');

      --if the index name returned is not null, then insert the metadata
      IF v_indexname IS NOT NULL THEN
        -- IF_5 START
        SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
          INTO V_COLLECTION_INPUT_COLUMN_LIST
          FROM TABLE(PI_COLUMN_LIST);
        /*-- OF-33540

        COMMONS_INDEXING.MERGE_AIR(
          PI_DEFINITION_ID =>PI_DEF_ID,
          PI_INDEX_NAME =>v_indexname,
          PI_TABLE_NAME =>V_TABLENAME,
          PI_COLUMN_LIST =>v_COLUMN_LIST,
          PI_RECREATE_INDEX_ON_COL_DROP =>PI_RECREATE_INDEX_ON_COL_DROP,
          PI_BUSINESS_NAME =>PI_BUSINESS_NAME,
          PI_IS_UNIQUE =>PI_IS_UNIQUE,
          PI_INDEX_TYPE =>v_INDEX_TYPE,
          PI_STATUS =>1
        );  */
        --CALL INSERT_APP_INDEXES_METADATA to insert metadata
        COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID              => PI_DEF_ID,
                                                     PI_INDEX_NAME                 => v_indexname,
                                                     PI_TABLE_NAME                 => V_TABLENAME,
                                                     PI_COLUMN_LIST                => V_COLLECTION_INPUT_COLUMN_LIST,
                                                     PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                                     PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                                     PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                                     PI_INDEX_TYPE                 => v_INDEX_TYPE);
        V_INDEX_CREATION_DECISION := 0;
        --Set status to 0
        PO_INDEX_CREATION_STATUS := 0;
      END IF; -- IF_5 END

      --IF INDEX IS TO BE CREATED
      IF V_INDEX_CREATION_DECISION = 1 THEN
        -- IF_6 START

        -- CHECK IF THE COLUMN LIST CONTAINS SINGLE COLUMN OR MULTIPLE COLUMNS

        IF PI_COLUMN_LIST.COUNT > 32 THEN
          -- IF_7 START
          RAISE MAXIMUM_NO_OF_COLS_32;
        ELSIF PI_IS_UNIQUE = 1 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_UI'; /*OF-21059*/
        ELSIF PI_COLUMN_LIST.COUNT > 1 AND PI_COLUMN_LIST.COUNT < 33 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_CI'; /*OF-21059*/
        ELSE
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_SI'; /*OF-21059*/
        END IF; -- IF_7 END

        SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS SYS.HSBLKNAMLST) AS INDEXED_COLUMNS
          INTO V_INPUT_COLUMN_COLLECTION
          FROM TABLE(PI_COLUMN_LIST);
        -- OF-30537 START
        --CALL THE CREATE_INDEX TO CREATE THE INDEX
        /*commons_indexing.create_index1
          (
            PI_TABLE_NAME => V_TABLENAME,
            PI_INDEX_NAME => V_INDEXNAME,
            PI_COL_LIST => V_INPUT_COLUMN_COLLECTION,
            PI_UNIQUENESS => PI_IS_UNIQUE,
            PI_COL_IS_PRIMARYKEY => 0,
        PI_INDEX_TABLESPACE   => V_INDEX_TABLESPACE_NAME,
            PI_RUN_ID   => PI_RUN_ID,
            PO_INDEX_STATUS => V_INDEX_OUT_STATUS,
            PO_INDEX_NAME => V_INDEX_NAME_RETURNED,
            PO_IS_UNIQUE => V_UNIQUENESS_RETURNED,
            PO_CREATE_DDL => V_CREATE_INDEX_DDL
          );*/
        --Get column list into coltype_indexed_column_list format to insert/update the column list in AIM table
        SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                            ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
          INTO V_COLLECTION_INPUT_COLUMN_LIST
          FROM TABLE(PI_COLUMN_LIST);
        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => PI_DEF_ID,
                                   PI_INDEX_NAME                 => V_INDEXNAME,
                                   PI_TABLE_NAME                 => V_TABLENAME,
                                   PI_COLUMN_LIST                => v_COLUMN_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                   PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                   PI_INDEX_TYPE                 => v_INDEX_TYPE,
                                   PI_STATUS                     => 1);
        COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_TABLENAME,
                                       PI_INDEX_NAME        => V_INDEXNAME,
                                       PI_COLUMN_LIST       => V_INPUT_COLUMN_COLLECTION,
                                       PI_UNIQUENESS        => PI_IS_UNIQUE,
                                       PI_COL_IS_PRIMARYKEY => 0,
                                       PI_INDEX_TABLESPACE  => V_INDEX_TABLESPACE_NAME,
                                       PI_TRANSACTION_ID    => V_TRANSACTION_ID, --sales change
                                       PI_RUN_ID            => PI_RUN_ID,
                                       PO_INDEX_STATUS      => V_INDEX_OUT_STATUS,
                                       PO_INDEX_NAME        => V_INDEX_NAME_RETURNED,
                                       PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                       PO_CREATE_DDL        => V_CREATE_INDEX_DDL);
        -- OF-30537 END
        -- OF-33540
        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => PI_DEF_ID,
                                   PI_INDEX_NAME                 => v_indexname,
                                   PI_TABLE_NAME                 => V_TABLENAME,
                                   PI_COLUMN_LIST                => v_COLUMN_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                   PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                   PI_INDEX_TYPE                 => v_INDEX_TYPE,
                                   PI_STATUS                     => 2);
        PO_INDEX_CREATION_STATUS := V_INDEX_OUT_STATUS;

        IF V_INDEX_OUT_STATUS IN (1, 2) THEN
          --Redundant query as it is executed in 1st step
          SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY
                              ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST) AS INDEXED_COLUMNS
            INTO V_COLLECTION_INPUT_COLUMN_LIST
            FROM TABLE(PI_COLUMN_LIST);

          -- INDEX DETAILS ARE ENTERED INTO APPLICATION_INDEXES_METADATA TABLE
          COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              => PI_DEF_ID,
                                                        PI_INDEX_NAME                 => V_INDEX_NAME_RETURNED,
                                                        PI_TABLE_NAME                 => V_TABLENAME,
                                                        PI_COLUMN_LIST                => V_COLLECTION_INPUT_COLUMN_LIST,
                                                        PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                                        PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                                        PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                                        PI_INDEX_TYPE                 => v_INDEX_TYPE,
                                                        PI_INDEX_INSERT_DDL           => V_CREATE_INDEX_DDL);
        END IF;
      END IF; -- IF_6 END
    END IF; -- IF_4 END
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
    -- INSERT_LOGS('CREATE_APP_INDEX ended');
  END CREATE_APP_INDEX;

  PROCEDURE DELETE_APP_INDEX(PI_TABLES_ID             IN NUMBER,
                             PI_DEF_ID                IN NUMBER,
                             PI_BUSINESS_NAME         IN VARCHAR2,
                             PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                             PI_RUN_ID                IN NUMBER DEFAULT NULL,
                             PI_TABLE_NAME            IN VARCHAR2, --sales change
                             PI_INDEX_TABLESPACE_NAME IN VARCHAR2, --sales change
                             PI_TRANSACTION_ID        IN VARCHAR2) IS
    V_TABLENAME               VARCHAR2(30) := PI_TABLE_NAME;
    V_DDL_QUERY               CLOB;
    V_UNDO_DDL_QUERY          CLOB;
    V_UD_INDEX                NUMBER(10, 0);
    V_OUT_INDEX_UPDATE_STATUS NUMBER(1, 0);
    V_INDEX_LIST              COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_DDL           COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE;
    V_DDL_CREATE_INDEX        CLOB := NULL;
    V_LENGTH                  NUMBER;
    V_INDEX_TABLESPACE_NAME   VARCHAR2(30 CHAR) := PI_INDEX_TABLESPACE_NAME;
    V_INDEX_COLUMN_LIST       VARCHAR2(1300 CHAR);
    V_PO_DEF_ID               NUMBER(10); --OF-35669
    V_PO_FLAG                 NUMBER(1); --OF-35669
    V_PO_BUSINESS_NAME        VARCHAR2(60 CHAR); --OF-35669
    V_TRANSACTION_ID          VARCHAR2(50 CHAR) := PI_TRANSACTION_ID;
    V_IS_EXEC                 BOOLEAN;
    V_PR_VALUE                VARCHAR2(1300 char);
    V_SQL                     VARCHAR2(32767 char);
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- OF-25207
    --sales planning change ; to derive env name
    SELECT nvl(max(PR_VALUE), 'SPM')
      INTO V_PR_VALUE
      FROM PROPERTIES
     WHERE PR_NAME = 'ENV_NAME';

    CASE V_PR_VALUE
      WHEN 'SPM' THEN
        V_IS_EXEC := TRUE;
      ELSE
        V_IS_EXEC := FALSE;
    END CASE;

    IF PI_TABLES_ID IS NOT NULL /*AND PI_DEF_ID IS NOT NULL*/
       AND PI_BUSINESS_NAME IS NOT NULL THEN
      --Get Table name
      --commented sales planning change
      /*SELECT T.TABLES_PHYSICAL_NAME,
            COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
       INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
       FROM TABLES T
      WHERE T.TABLES_ID = PI_TABLES_ID;*/

      -- Check if this Feature Index (FI) covers any other FIs
      FOR C IN (SELECT AIM_PARENT.AIM_DEF_ID,
                       UPPER(AIM_PARENT.AIM_BUSINESS_NAME) AIM_BUSINESS_NAME,
                       AIM_PARENT.AIM_INDEX_TYPE,
                       AIM_PARENT.AIM_INDEX_NAME,
                       AIM_PARENT.AIM_TABLE_NAME,
                       AIM_PARENT.AIM_INDEX_IS_UNIQUE,
                       AIM_PARENT.AIM_INDEXED_COLUMNS,
                       /*(SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID
                       FROM DUAL) TRANSACTION_ID*/
                       V_TRANSACTION_ID TRANSACTION_ID
                  FROM APPLICATION_INDEXES_METADATA AIM_PARENT
                 WHERE NOT EXISTS
                 (SELECT 1
                          FROM APPLICATION_INDEXES_METADATA AIM_CHILD
                         WHERE AIM_PARENT.AIM_INDEX_NAME =
                               AIM_CHILD.AIM_INDEX_NAME
                           AND ((SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(AIM_CHILD.AIM_INDEXED_COLUMNS)) >
                               (SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(AIM_PARENT.AIM_INDEXED_COLUMNS))))
                   AND AIM_PARENT.AIM_INDEX_TYPE = 2
                   AND /*AIM_PARENT.AIM_DEF_ID = PI_DEF_ID*/ -- OF-25207
                       NVL(AIM_PARENT.AIM_DEF_ID, 0) = NVL(PI_DEF_ID, 0)
                   AND UPPER(AIM_PARENT.AIM_TABLE_NAME) = UPPER(V_TABLENAME)
                   AND UPPER(AIM_PARENT.AIM_BUSINESS_NAME) =
                       UPPER(PI_BUSINESS_NAME)
                   AND NOT EXISTS
                 (SELECT 1
                          FROM APPLICATION_INDEXES_METADATA AIM_CORE
                         WHERE AIM_CORE.AIM_INDEX_NAME =
                               AIM_PARENT.AIM_INDEX_NAME
                           AND AIM_CORE.AIM_INDEX_TYPE = 1)) LOOP
        /*OF-35669 start */

        BEGIN
          --sales planning change; if schema is SPM then only execute index_usage.is_delete
          IF V_IS_EXEC THEN
            v_sql := 'BEGIN
                         INDEX_USAGE.IS_DELETE(PI_INDEX_NAME    => ''' ||
                     C.AIM_INDEX_NAME || ''',
                                PO_BUSINESS_NAME => :V_PO_BUSINESS_NAME,
                                PO_DEF_ID        => :V_PO_DEF_ID,
                                PO_FLAG          => :V_PO_FLAG);
                       END;';
            EXECUTE IMMEDIATE v_sql
              USING OUT V_PO_BUSINESS_NAME, V_PO_DEF_ID, V_PO_FLAG;
          END IF;

          IF V_PO_FLAG = 0 THEN
            UPDATE APPLICATION_INDEXES_METADATA AIM
               SET AIM_DEF_ID        = V_PO_DEF_ID,
                   AIM_BUSINESS_NAME = V_PO_BUSINESS_NAME
             WHERE AIM_DEF_ID = C.AIM_DEF_ID
               AND AIM_TABLE_NAME = C.AIM_TABLE_NAME
               AND AIM.AIM_BUSINESS_NAME = C.AIM_BUSINESS_NAME;
            RETURN;
          END IF;
        END;
        /*OF-35669 end */
        -- a. Drop this Physical Feature Index using DDL Framework (so that it can be rolled back if required)
        V_DDL_QUERY := 'DROP INDEX  ' || C.AIM_INDEX_NAME;

        -- 1. Call to GET_INDEX_DDLS_FOR_APP
        SELECT C.AIM_INDEX_NAME BULK COLLECT INTO V_INDEX_LIST FROM DUAL;

        --V_INDEX_LIST :=COMMONS_INDEXING.TYPE_CONSTRAINT_NAME(C.AIM_INDEX_NAME);
        COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                PO_INDEX_DDL  => V_OUT_INDEX_DDL);

        IF V_OUT_INDEX_DDL.COUNT = 1 THEN
          V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;

          --Replace single quote with TWO single quotes
          V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                               '\''',
                                               '''''');

          --Get the length of statement created
          V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);

          --Remove the extra single quote from START and END, as the start and end are also
          -- appended with extra single quote being clob statement
          V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX, 2, V_LENGTH - 1);

          V_UNDO_DDL_QUERY := '
            BEGIN
              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                              C.AIM_INDEX_NAME ||
                              ''')))
              LOOP
                EXECUTE IMMEDIATE ''' ||
                              V_DDL_CREATE_INDEX || ''';
              END LOOP;
            END;';
        END IF;

        -- 2. Call to EXECUTE_DDL
        COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => C.TRANSACTION_ID,
                                         PI_DESCRIPTION    => 'DROP UNIQUE INDEX ' ||
                                                              C.AIM_INDEX_NAME,
                                         PI_DDL            => V_DDL_QUERY,
                                         PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                         pi_run_id         => PI_RUN_ID);

        -- b. Call the proc: "DELETE_AIM_BY_DEFID_AND_BNAME" to delete the Metadata for this FI.
        -- INSERT_LOGS(' 2 - DELETE_AIM_BY_DEFID_AND_BNAME : PI_TABLE_NAME => ' || V_TABLENAME);
        COMMONS_INDEXING.DELETE_AIM_BY_DEFID_AND_BNAME(PI_TABLE_NAME    => UPPER(V_TABLENAME),
                                                       PI_DEFINITION_ID => PI_DEF_ID,
                                                       PI_BUSINESS_NAME => PI_BUSINESS_NAME);
        -- OF-33540
        SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
          INTO V_INDEX_COLUMN_LIST
          FROM TABLE(C.aim_indexed_columns);

        MERGE_AIR(PI_DEFINITION_ID              => C.AIM_DEF_ID,
                  PI_INDEX_NAME                 => C.AIM_INDEX_NAME,
                  PI_TABLE_NAME                 => C.AIM_TABLE_NAME,
                  PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                  PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                  PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                  PI_IS_UNIQUE                  => NULL,
                  PI_INDEX_TYPE                 => C.AIM_INDEX_TYPE,
                  PI_STATUS                     => 3);
        -- c. Call the proc: "UPDATE_APP_INDEXES" to: Recreate, if applicable, other FIs which are covered (i.e. NOT PHYSICALY PRESENT) by the FI to be deleted.
        UPDATE_APP_INDEX(PI_TABLE_NAME         => C.AIM_TABLE_NAME,
                         PI_RENAMED_INDEX_NAME => NULL,
                         PI_TRANSACTION_ID     => C.TRANSACTION_ID,
                         PI_INDEX_UPDATE_MODE  => 2,
                         PI_DELETED_INDEX_NAME => C.AIM_INDEX_NAME,
                         PI_TABLESPACE_NAME    => V_INDEX_TABLESPACE_NAME,
                         PI_RUN_ID             => PI_RUN_ID,
                         PI_TABLES_ID          => PI_TABLES_ID);
      END LOOP;

      /*        -- Call the proc: "DELETE_AIM_BY_DEFID_AND_BNAME" to delete the Metadata for this FI, if it is not a COVERING Index.
      -- INSERT_LOGS(' 3 - DELETE_AIM_BY_DEFID_AND_BNAME : PI_TABLE_NAME => ' || V_TABLENAME);
       COMMONS_INDEXING.DELETE_AIM_BY_DEFID_AND_BNAME(
         PI_TABLE_NAME    => UPPER(V_TABLENAME),
         PI_DEFINITION_ID => PI_DEF_ID,
         PI_BUSINESS_NAME => PI_BUSINESS_NAME);*/

      -- OF-25207 -- START -   Change For handling maximum key length limit exceeded error
      DELETE FROM APPLICATION_INDEXES_METADATA AIM
       WHERE
      /*AIM.AIM_DEF_ID = PI_DEF_ID*/
       NVL(AIM.AIM_DEF_ID, 0) = NVL(PI_DEF_ID, 0)
       AND AIM.AIM_BUSINESS_NAME = PI_BUSINESS_NAME
       AND AIM.AIM_TABLE_NAME = UPPER(V_TABLENAME);
      -- OF-25207 -- END
    END IF;
    -- Defect # 14383, 15167
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DELETE_APP_INDEX;

  PROCEDURE DISABLE_ALL_INDEXES(PI_TABLES_ID      IN NUMBER,
                                PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                                PI_RUN_ID         IN NUMBER DEFAULT NULL,
                                PI_TRANSACTION_ID IN VARCHAR2 /*DEFAULT NULL*/,
                                PO_LOG_MSG        OUT CLOB) IS
    V_TABLE_NAME            VARCHAR2(30 CHAR) := NULL;
    V_TRANSACTION_ID        VARCHAR2(30 CHAR) := NULL;
    V_INDEX                 INTEGER := NULL;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- 1. Fetch the Table Name in V_TABLE_NAME for given PI_TABLES_ID.

      SELECT UPPER(T.TABLES_PHYSICAL_NAME) /* OF-5973 */,
             COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID) /*OF-11821*/
        INTO V_TABLE_NAME, V_INDEX_TABLESPACE_NAME
        FROM TABLES T
       WHERE T.TABLES_ID = PI_TABLES_ID;

      -- 2. Proceed ahead.
      -- 2.a. Get the Transaction id
      IF PI_TRANSACTION_ID IS NULL THEN
        -- IF_3
        SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID
          INTO V_TRANSACTION_ID
          FROM DUAL;
      ELSE
        V_TRANSACTION_ID := PI_TRANSACTION_ID;
      END IF; -- END IF_3

      -- 2.b. Disable Primary Key Constraint and Drop Primary Key Index
      -- Fix for Defect# 14165
      -- Disable Primary Key Constraint
      COMMONS_INDEXING.DISABLE_PRIMARY_KEY_CONS(PI_TABLE_NAME     => V_TABLE_NAME,
                                                PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                PI_RUN_ID         => PI_RUN_ID);

      -- This would drop the corresponding Primary Key Index.
      FOR C IN (SELECT UI.INDEX_NAME
                  FROM USER_INDEXES UI
                 INNER JOIN USER_CONSTRAINTS UC
                    ON (UC.CONSTRAINT_NAME = UI.INDEX_NAME AND
                       UI.TABLE_NAME = UC.TABLE_NAME)
                 WHERE UC.CONSTRAINT_TYPE = 'P'
                   AND UI.TABLE_NAME = V_TABLE_NAME) LOOP
        COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => 'DROP INDEX ' ||
                                                         C.INDEX_NAME);
      END LOOP;

      -- End of Fix for Defect# 14165

      -- 2.c. Drop All Unique Indexes
      -- Unique Indexes need to be dropped, as they cannot be disabled.
      COMMONS_INDEXING.DROP_ALL_UNIQUE_INDEXES(PI_TABLE_NAME       => V_TABLE_NAME,
                                               PI_TRANSACTION_ID   => V_TRANSACTION_ID,
                                               PI_PROCESS_ID       => PI_PROCESS_ID,
                                               PI_INDEX_TABLESPACE => V_INDEX_TABLESPACE_NAME,
                                               PI_RUN_ID           => PI_RUN_ID);

      -- 2.d. Disable All Non-Unique Indexes
      -- Fix for Defect# 14165
      COMMONS_INDEXING.DISABLE_NONUNIQUE_INDEXES(PI_TABLE_NAME     => V_TABLE_NAME,
                                                 PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                 PI_RUN_ID         => PI_RUN_ID);
    END IF; -- END IF_1

    PO_LOG_MSG := '';
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DISABLE_ALL_INDEXES;

  PROCEDURE DISABLE_ALL_INDEXES(PI_TABLES_ID  IN NUMBER,
                                PI_PROCESS_ID IN NUMBER DEFAULT NULL,
                                PI_RUN_ID     IN NUMBER DEFAULT NULL,
                                PO_LOG_MSG    OUT CLOB) IS
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- 1. Call DISABLE_ALL_INDEXES with PI_TRANSACTION_ID NULL.
      COMMONS_INDEXING.DISABLE_ALL_INDEXES(PI_TABLES_ID      => PI_TABLES_ID,
                                           PI_PROCESS_ID     => PI_PROCESS_ID,
                                           PI_RUN_ID         => PI_RUN_ID,
                                           PI_TRANSACTION_ID => NULL,
                                           PO_LOG_MSG        => PO_LOG_MSG);
    END IF; -- END IF_1
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END DISABLE_ALL_INDEXES;

  PROCEDURE ENABLE_ALL_INDEXES(PI_TABLES_ID      IN NUMBER,
                               PI_PROCESS_ID     IN NUMBER DEFAULT NULL,
                               PI_RUN_ID         IN NUMBER DEFAULT NULL,
                               PI_TRANSACTION_ID IN VARCHAR2 /*DEFAULT NULL*/,
                               PI_GATHER_STATS   IN NUMBER DEFAULT 1, -- 0- No, 1- Yes
                               PO_LOG_MSG        OUT CLOB) IS
    V_TABLE_NAME      VARCHAR2(30 CHAR) := NULL;
    V_TRANSACTION_ID  VARCHAR2(30 CHAR) := PI_TRANSACTION_ID; -- Fix for Defect# 16211
    V_STATUS          NUMBER; -- OF-17109
    V_STATUS_RECREATE NUMBER := 0;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    -- Fix for Defect# 16211
    -- A. Get the Transaction id, if PI_TRANSACTION_ID is NULL
    V_TRANSACTION_ID := NVL(PI_TRANSACTION_ID,
                            COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

    -- B. Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- 1. Fetch the Table Name in V_TABLE_NAME for given PI_TABLES_ID.
      SELECT UPPER(T.TABLES_PHYSICAL_NAME) /* OF-5973 */
        INTO V_TABLE_NAME
        FROM TABLES T
       WHERE T.TABLES_ID = PI_TABLES_ID;

      -- 2. Proceed ahead.
      -- 2.a. Rebuild All Non-Unique Indexes
      -- Fix for Defect# 14165
      COMMONS_INDEXING.REBUILD_NONUNIQUE_INDEXES(PI_TABLE_NAME     => V_TABLE_NAME,
                                                 PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                 PI_RUN_ID         => PI_RUN_ID);
      -- 2.b. Re-create All Unique Indexes (In this case, ONLY Unique Indexes were dropped in ENABLE_ALL_INDEXES flow)
      -- Fix for Defect# 14165  -- Added the PI_PARENT_TRANSACTION_ID parameter to the procedure call.
      V_STATUS_RECREATE := COMMONS_INDEXING.RECREATE_ALL_DROPPED_INDEXES(PI_TABLE_NAME            => V_TABLE_NAME,
                                                                         PI_PROCESS_ID            => PI_PROCESS_ID,
                                                                         PI_RUN_ID                => PI_RUN_ID,
                                                                         PI_TRANSACTION_ID        => PI_TRANSACTION_ID,
                                                                         PI_PARENT_TRANSACTION_ID => V_TRANSACTION_ID,
                                                                         PI_TABLES_ID             => PI_TABLES_ID);
      -- 2.c. Enable Primary Key Constraint
      -- Fix for Defect# 14165
      COMMONS_INDEXING.ENABLE_PRIMARY_KEY_CONS(PI_TABLE_NAME     => V_TABLE_NAME,
                                               PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                               PI_RUN_ID         => PI_RUN_ID);

      -- 2.d. Gather statistics on table and indexes
      -- Fix for Defect# 16837

      IF PI_GATHER_STATS = 1 THEN
        -- Alter Session to BINARY
        -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

        -- OF-17109 - START - Replace Statistics Gathering with 'FOR ALL COLUMNS SIZE SKEWONLY' mode call from Enable_All_Indexes procedure in Indexing package with the standard Statistics Gathering procedure call
        -- PI_MODE = 1 -- This implies that the statistics will be gathered always.
        COMMONS_UTILS.CALCULATE_TABLE_STATISTICS(PI_TABLE_NAME => V_TABLE_NAME,
                                                 PI_MODE       => 1,
                                                 PO_STATUS     => V_STATUS);
        -- OF-17109 - END

        -- Alter Session to NLS Parameters
        -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
      END IF;
    END IF; -- END IF_1

    PO_LOG_MSG := NULL;
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END ENABLE_ALL_INDEXES;

  PROCEDURE ENABLE_ALL_INDEXES(PI_TABLES_ID  IN NUMBER,
                               PI_PROCESS_ID IN NUMBER DEFAULT NULL,
                               PI_RUN_ID     IN NUMBER DEFAULT NULL,
                               PO_LOG_MSG    OUT CLOB) IS
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- 1. Call ENABLE_ALL_INDEXES with PI_TRANSACTION_ID NULL.
      COMMONS_INDEXING.ENABLE_ALL_INDEXES(PI_TABLES_ID      => PI_TABLES_ID,
                                          PI_PROCESS_ID     => PI_PROCESS_ID,
                                          PI_RUN_ID         => PI_RUN_ID,
                                          PI_TRANSACTION_ID => NULL,
                                          PO_LOG_MSG        => PO_LOG_MSG);
    END IF; -- END IF_1
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END ENABLE_ALL_INDEXES;

  PROCEDURE PRESERVE_ALL_INDEXES(PI_TABLES_ID             IN NUMBER,
                                 PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                                 PI_RUN_ID                IN NUMBER DEFAULT NULL,
                                 PI_TRANSACTION_ID        IN VARCHAR2,
                                 PI_TEMP_TABLE_NAME       IN VARCHAR2 DEFAULT NULL, /*OF-7798*/
                                 PI_TABLE_NAME            IN VARCHAR2, --sales change
                                 PI_INDEX_TABLESPACE_NAME IN VARCHAR2, --sales change
                                 PO_LOG_MSG               OUT CLOB) IS
    V_DDL_DROP_INDEX         CLOB := NULL;
    V_DDL_CREATE_INDEX       CLOB := NULL;
    V_DDL_CREATE_INDEX_BLOCK CLOB := NULL;
    V_DDL_DROP_INDEX_BLOCK   CLOB := NULL;
    V_TABLE_NAME             VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_FLOW_IDENTIFIER        VARCHAR2(30 CHAR) := 'PRESERVE_ALL_INDEXES';

    V_INDEX_LIST     COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_INFO COMMONS_INDEXING.TYPE_INDEX_DDL_INFO;
    --Defect 13382 to take care of single quote in NLSSORT function applied to VARCHAR2 columns
    V_LENGTH NUMBER;
    -- Testing -- Start
    V_SQL CLOB;
    -- Testing -- End
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR) := PI_INDEX_TABLESPACE_NAME;
    V_SQL_RENAME_INDEX      VARCHAR2(32767 CHAR); -- OF-28369
    v_temp_index_name       varchar2(100) := '';
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    -- Testing -- Start
    V_SQL := '2 --  PRESERVE_ALL_INDEXES -2 START -- PI_TABLES_ID = ' ||
             PI_TABLES_ID || ' -- PI_PROCESS_ID ' || PI_PROCESS_ID ||
             ' -- PI_RUN_ID ' || PI_RUN_ID || ' -- PI_TRANSACTION_ID ' ||
             PI_TRANSACTION_ID || ' -- PI_TEMP_TABLE_NAME ' ||
             PI_TEMP_TABLE_NAME;

    -- INSERT_LOGS(V_SQL);
    -- Testing -- End

    -- Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- A. Fetch the Table Name in V_TABLE_NAME for given PI_TABLES_ID.
      --sales planning change; table name and tablespace name are input to proc
      /* SELECT UPPER(T.TABLES_PHYSICAL_NAME)
            COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
       INTO V_TABLE_NAME, V_INDEX_TABLESPACE_NAME
       FROM TABLES T
      WHERE T.TABLES_ID = PI_TABLES_ID;*/

      -- Fix for Defects #13917 and #13927
      -- B.1. Get DDLs of ALL Indexes, EXCEPT the PRIMARY and UNIQUE constraints.
      -- UPDATED: 10.JUL.2013
      GET_INDEX_DDLS(PI_TABLE_NAME      => V_TABLE_NAME,
                     PI_ONLY_UNIQUE     => 0,
                     PI_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                     PO_INDEX_INFO      => V_OUT_INDEX_INFO);

      -- B.2. Iterate through indexes fetched above.
      FOR C IN 1 .. V_OUT_INDEX_INFO.COUNT LOOP
        -- B.2.a.i) Set the V_DDL_DROP_INDEX variable with the Drop Index DDL.
        V_DDL_DROP_INDEX := 'DROP INDEX ' || V_OUT_INDEX_INFO(C).INDEX_NAME;

        -- B.2.a.ii) Set another CLOB variable with the execution block of Drop Index DDL.
        -- This would be passed as the PI_DDL parameter to the proc: COMMONS_DDL_HANDLING.EXECUTE_DDL.
        V_DDL_DROP_INDEX_BLOCK := TO_CLOB('
          BEGIN
            FOR D IN (SELECT 1 FROM DUAL WHERE EXISTS(
              SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = ''' || V_OUT_INDEX_INFO(C)
                                          .INDEX_NAME ||
                                          '''))
            LOOP
              EXECUTE IMMEDIATE ''') ||
                                  V_DDL_DROP_INDEX || TO_CLOB(''';
            END LOOP;
          END;');

        -- B.2.b.i) Set the V_DDL_CREATE_INDEX variable with the Create Index DDL in CLOB variable.
        V_DDL_CREATE_INDEX := V_OUT_INDEX_INFO(C).DDL_STMT;

        -- /* OF-5973 */ -- Removed NLSSORT handling wrt QC Defect 13382
        -- B.2.b.ii) DEFECT 13382 Resolution
        -- Replace EACH single quote with TWO single quotes
        SELECT REGEXP_REPLACE(V_DDL_CREATE_INDEX, '\''', '''''')
          INTO V_DDL_CREATE_INDEX
          FROM DUAL;

        -- B.2.b.iii) DEFECT 13382 Resolution
        -- Get the length of statement created
        SELECT LENGTH(V_DDL_CREATE_INDEX) INTO V_LENGTH FROM DUAL;

        -- B.2.b.iv) DEFECT 13382 Resolution
        -- Remove the extra single quote from START and END, as the start and end are also
        -- appended with extra single quote being clob statement
        SELECT SUBSTR(V_DDL_CREATE_INDEX, 2, V_LENGTH - 1)
          INTO V_DDL_CREATE_INDEX
          FROM DUAL;

        -- OF-28369 - START
        V_SQL_RENAME_INDEX := 'ALTER INDEX ' ||
                              UPPER(SUBSTR(PI_TEMP_TABLE_NAME, 0, 25)) ||
                              '_DPBK' || ' RENAME TO ' || V_OUT_INDEX_INFO(C)
                             .INDEX_NAME;
        v_temp_index_name  := UPPER(SUBSTR(PI_TEMP_TABLE_NAME, 0, 25)) ||
                              '_DPBK';
        -- OF-28369 - END

        -- B.2.b.v) Set another CLOB variable with the execution block of Create Index DDL.
        -- This would be passed as the PI_UNDO_DDL parameter to the proc: COMMONS_DDL_HANDLING.EXECUTE_DDL.
        -- OF-7798 -- START -- Replace following block with a new one
        /*
          V_DDL_CREATE_INDEX_BLOCK := TO_CLOB('
            BEGIN
              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = ''' || V_OUT_INDEX_INFO(C).INDEX_NAME || '''))
              LOOP
                EXECUTE IMMEDIATE ''') || V_DDL_CREATE_INDEX || TO_CLOB(''';
              END LOOP;
            END;');
        */
        -- OF-28369 - START - Modified the V_DDL_CREATE_INDEX_BLOCK  below to use V_SQL_RENAME_INDEX
        -- New Block
        -- INSERT_LOGS ('BEFORE V_DDL_CREATE_INDEX_BLOCK aaaaa = ' || V_DDL_CREATE_INDEX_BLOCK);
        V_DDL_CREATE_INDEX_BLOCK := TO_CLOB('

          DECLARE
           E_NAME_ALREADY_EXISTS EXCEPTION;
           PRAGMA EXCEPTION_INIT(E_NAME_ALREADY_EXISTS, -955);

           E_COLUMN_LIST_ALREADY_INDEXED EXCEPTION;
           PRAGMA EXCEPTION_INIT(E_COLUMN_LIST_ALREADY_INDEXED, -1408);
          BEGIN
              EXECUTE IMMEDIATE ''') ||
                                    V_DDL_CREATE_INDEX || TO_CLOB(''';
          EXCEPTION
              WHEN E_NAME_ALREADY_EXISTS
               THEN
                -- INSERT_LOGS (''E_NAME_ALREADY_EXISTS'');
               NULL;
              WHEN E_COLUMN_LIST_ALREADY_INDEXED
               THEN
                -- INSERT_LOGS (''E_COLUMN_LIST_ALREADY_INDEXED'');
                  IF ''' || V_OUT_INDEX_INFO(C)
                                                                  .INDEX_NAME ||
                                                                  ''' LIKE ''%_BUSINESSKEY_UI'' THEN
                       -- INSERT_LOGS (''V_SQL_RENAME_INDEX = ' ||
                                                                  V_SQL_RENAME_INDEX || ');
                      EXECUTE IMMEDIATE ' ||
                                                                  V_SQL_RENAME_INDEX || ';
                  ELSE
                    -- INSERT_LOGS (''E_COLUMN_LIST_ALREADY_INDEXED  ELSE'');
                    NULL;
                  END IF;
              WHEN OTHERS THEN
                -- INSERT_LOGS (''OTHERS'');
                NULL;
          END;
      ');


 V_DDL_CREATE_INDEX_BLOCK := TO_CLOB('

          DECLARE

           E_NAME_ALREADY_EXISTS EXCEPTION;
           PRAGMA EXCEPTION_INIT(E_NAME_ALREADY_EXISTS, -955);

           E_COLUMN_LIST_ALREADY_INDEXED EXCEPTION;
           PRAGMA EXCEPTION_INIT(E_COLUMN_LIST_ALREADY_INDEXED, -1408);
           v_create_index_flag number(1):=0;
          BEGIN
            IF ''' || V_OUT_INDEX_INFO(C)
                                            .INDEX_NAME ||
                                            ''' LIKE ''%_BUSINESSKEY_UI'' THEN

            select count(1) into v_create_index_flag from dual where exists (select 1 from user_indexes where table_name = ''' ||
                                            PI_TABLE_NAME ||
                                            ''' and index_name = ''' ||
                                            v_temp_index_name ||
                                            ''');

            end if;

            if v_create_index_flag = 1
              then
              EXECUTE IMMEDIATE ''' ||
                                            V_SQL_RENAME_INDEX || ''';
            else
              EXECUTE IMMEDIATE ''') ||
                                    V_DDL_CREATE_INDEX || TO_CLOB(''';
            end if;

          EXCEPTION
              WHEN E_NAME_ALREADY_EXISTS
               THEN
                -- INSERT_LOGS (''E_NAME_ALREADY_EXISTS'');
               NULL;
              WHEN OTHERS THEN
                -- INSERT_LOGS (''OTHERS'');

                commons_utils.insert_logs(''error in block created in preserv_all_index : ''||sqlerrm||dbms_utility.format_error_backtrace());
          END;
      ');



        -- OF-28369 - END

        -- INSERT_LOGS ('V_DDL_CREATE_INDEX_BLOCK AFTER = ' || V_DDL_CREATE_INDEX_BLOCK);
        -- OF-7798 -- END

        -- B.2.c. Save the Create Index DDL for Recreating Indexes in Enable_All_Indexes flow.
        INSERT INTO INDEX_DDL_STORAGE
          (IDS_ID,
           IDS_TABLE_NAME,
           IDS_INDEX_NAME,
           IDS_DDL_CREATE_INDEX,
           IDS_DDL_DROP_INDEX,
           IDS_PROCESS_ID,
           IDS_RUN_ID,
           IDS_TRANSACTION_ID,
           IDS_FLOW_IDENTIFIER,
           IDS_CREATION_DATE)
        VALUES
          (INDEX_DDL_STORAGE_SEQ.NEXTVAL,
           V_TABLE_NAME,
           V_OUT_INDEX_INFO(C).INDEX_NAME,
           V_DDL_CREATE_INDEX_BLOCK,
           V_DDL_DROP_INDEX_BLOCK,
           PI_PROCESS_ID,
           PI_RUN_ID,
           NVL2((PI_PROCESS_ID || PI_RUN_ID), NULL, PI_TRANSACTION_ID),
           V_FLOW_IDENTIFIER,
           SYSTIMESTAMP);
      END LOOP;
    END IF; -- END IF_1

    PO_LOG_MSG := '';

    /* -- Testing -- Start
    V_SQL := '2 --  PRESERVE_ALL_INDEXES -2 END';
     -- INSERT_LOGS(V_SQL);
    -- Testing -- End */

    COMMIT; -- For PRAGMA AUTONOMOUS_TRANSACTION
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END PRESERVE_ALL_INDEXES;

  PROCEDURE PRESERVE_ALL_INDEXES(PI_TABLES_ID        IN NUMBER,
                                 PI_PROCESS_ID       IN NUMBER DEFAULT NULL,
                                 PI_RUN_ID           IN NUMBER DEFAULT NULL,
                                 PI_TEMP_TABLE_NAME  IN VARCHAR2 DEFAULT NULL, /*OF-7798*/
                                 PI_TABLE_NAME       IN VARCHAR2,
                                 PI_INDEX_TABLESPACE IN NUMBER,
                                 PI_TRANSACTION_ID   IN VARCHAR2,
                                 PO_LOG_MSG          OUT CLOB) IS
    V_LOG_OUTPUT            CLOB;
    V_TABLE_NAME            VARCHAR2(30 Char) := PI_TABLE_NAME;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
    V_TRANSACTION_ID        VARCHAR2(30 Char) := PI_TRANSACTION_ID;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    /* -- Testing -- Start
    V_SQL := '1 --  PRESERVE_ALL_INDEXES -1 START';
     -- INSERT_LOGS(V_SQL);
    -- Testing -- End */
    --sales planning change;
    BEGIN
      SELECT USER ||
             DECODE(PI_INDEX_TABLESPACE, 1, '_IND', 2, '_IND', 3, '_OUT')
        INTO V_INDEX_TABLESPACE_NAME
        from dual;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    -- Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- 1. Call PRESERVE_ALL_INDEXES with PI_TRANSACTION_ID NULL.
      COMMONS_INDEXING.PRESERVE_ALL_INDEXES(PI_TABLES_ID             => PI_TABLES_ID,
                                            PI_PROCESS_ID            => PI_PROCESS_ID,
                                            PI_RUN_ID                => PI_RUN_ID,
                                            PI_TRANSACTION_ID        => NULL,
                                            PI_TEMP_TABLE_NAME       => PI_TEMP_TABLE_NAME,
                                            PI_TABLE_NAME            => V_TABLE_NAME, --sales change
                                            PI_INDEX_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME, --sales change
                                            PO_LOG_MSG               => PO_LOG_MSG);

      -- 2. Call DELETE_INDEXES to take rename the existing indexes.
      -- OF-15163 - Replace DELETE_INDEXES with COMMONS_INDEXING.DELETE_INDEXES_WITHOUT_IMETA, so as to only Rename (Functional Delete) Indexes and keep their meta intact. This way REAPPLY_ALL_DROPPED_INDEXES need not create Indexing Meta again
      COMMONS_INDEXING.DELETE_INDEXES_WITHOUT_IMETA(PI_TABLE_NAME     => V_TABLE_NAME,
                                                    PI_PROCESS_ID     => PI_PROCESS_ID,
                                                    PI_RUN_ID         => PI_RUN_ID,
                                                    PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                                    PO_LOG_MSG        => V_LOG_OUTPUT);
    END IF; -- END IF_1
    /* -- Testing -- Start
    V_SQL := '1 --  PRESERVE_ALL_INDEXES -1 END';
     -- INSERT_LOGS(V_SQL);
    -- Testing -- End */
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END PRESERVE_ALL_INDEXES;

  PROCEDURE REAPPLY_ALL_DROPPED_INDEXES(PI_TABLES_ID             IN NUMBER,
                                        PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                                        PI_RUN_ID                IN NUMBER DEFAULT NULL,
                                        PI_TRANSACTION_ID        IN VARCHAR2 /* DEFAULT NULL*/,
                                        PI_TABLE_NAME            IN VARCHAR2, --sales change
                                        PI_INDEX_TABLESPACE_NAME IN VARCHAR2, --sales change
                                        PO_LOG_MSG               OUT CLOB) IS
    V_TABLE_NAME            VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_INDEX_STATUS          NUMBER;
    V_RETURNED_INDEX_NAME   VARCHAR2(30 CHAR);
    v_RETURNED_UNIQUENESS   VARCHAR2(9 CHAR);
    V_TRANSACTION_ID        VARCHAR2(30 CHAR) := PI_TRANSACTION_ID; -- Fix for Defect# 16211
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR) := PI_INDEX_TABLESPACE_NAME; /*OF-11821*/

    V_STATUS_RECREATE NUMBER := 0;
    --PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789

    /* -- Testing -- Start
    V_SQL := '2 --  REAPPLY_ALL_DROPPED_INDEXES -2 START -- PI_TABLES_ID = ' || PI_TABLES_ID
      || ' -- PI_PROCESS_ID ' || PI_PROCESS_ID || ' -- PI_RUN_ID ' || PI_RUN_ID
      || ' -- PI_TRANSACTION_ID ' || PI_TRANSACTION_ID;
     -- INSERT_LOGS(V_SQL);
    -- Testing -- End */

    -- Fix for Defect# 16211
    -- A. Get the Transaction id, if PI_TRANSACTION_ID is NULL
    --commented for sales change; transaction id is input to proc
    --V_TRANSACTION_ID := NVL(PI_TRANSACTION_ID,COMMONS_DDL_HANDLING.GET_TRANSACTION_ID);

    -- B. Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      -- IF_1
      -- B.1. Fetch the Table Name in V_TABLE_NAME for given PI_TABLES_ID.

      --commented for sales planning change;
      /* SELECT UPPER(T.TABLES_PHYSICAL_NAME),
            COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
       INTO V_TABLE_NAME, V_INDEX_TABLESPACE_NAME
       FROM TABLES T
      WHERE T.TABLES_ID = PI_TABLES_ID;*/

      -- B.2. Proceed ahead.
      -- B.2.a. Re-create the Primary Key
      -- OF-30537 START

      COMMONS_INDEXING.CREATE_INDEX(PI_TABLE_NAME        => V_TABLE_NAME,
                                    PI_INDEX_NAME        => 'PK_' ||
                                                            V_TABLE_NAME,
                                    PI_COLUMN_LIST       => SYS.HSBLKNAMLST('ROW_IDENTIFIER'),
                                    PI_UNIQUENESS        => 0,
                                    PI_COL_IS_PRIMARYKEY => 1,
                                    PI_RUN_ID            => PI_RUN_ID,
                                    PO_INDEX_STATUS      => V_INDEX_STATUS,
                                    PO_INDEX_NAME        => V_RETURNED_INDEX_NAME,
                                    PI_TRANSACTION_ID    => V_TRANSACTION_ID,
                                    PO_IS_UNIQUE         => v_RETURNED_UNIQUENESS,
                                    PI_INDEX_TABLESPACE  => V_INDEX_TABLESPACE_NAME /*OF-11821*/);
      -- OF-30537 END
      /* -- Testing -- Start
      V_SQL := '2 -- a.  REAPPLY_ALL_DROPPED_INDEXES -2 START -- CREATE PK -- INDEX_NAME = ' || V_INDEX_NAME1;
       -- INSERT_LOGS(V_SQL);
      -- Testing -- End */

      -- B.2.b. Re-create All Indexes that were dropped.

      V_STATUS_RECREATE := COMMONS_INDEXING.RECREATE_ALL_DROPPED_INDEXES(PI_TABLE_NAME            => V_TABLE_NAME,
                                                                         PI_PROCESS_ID            => PI_PROCESS_ID,
                                                                         PI_RUN_ID                => PI_RUN_ID,
                                                                         PI_TRANSACTION_ID        => PI_TRANSACTION_ID,
                                                                         PI_PARENT_TRANSACTION_ID => V_TRANSACTION_ID,
                                                                         PI_TABLES_ID             => PI_TABLES_ID);
    END IF; -- END IF_1

    PO_LOG_MSG := '';
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

    --COMMIT; -- For PRAGMA AUTONOMOUS_TRANSACTION;
  EXCEPTION
    WHEN OTHERS THEN
      COMMONS_INDEXING.SAVE_EXCEPTIONS(PI_RUN_ID    => PI_RUN_ID,
                                       PI_EXCEPTION => SQLERRM);

  END REAPPLY_ALL_DROPPED_INDEXES;

  PROCEDURE REAPPLY_ALL_DROPPED_INDEXES(PI_TABLES_ID        IN NUMBER,
                                        PI_PROCESS_ID       IN NUMBER DEFAULT NULL,
                                        PI_RUN_ID           IN NUMBER DEFAULT NULL,
                                        PI_TRANSACTION_ID   IN VARCHAR2,
                                        PI_TABLE_NAME       IN VARCHAR2,
                                        PI_INDEX_TABLESPACE IN NUMBER,
                                        PO_LOG_MSG          OUT CLOB) IS
    V_TRANSACTION_ID        VARCHAR2(30 CHAR) := PI_TRANSACTION_ID;
    V_TABLE_NAME            VARCHAR2(30 CHAR) := PI_TABLE_NAME;
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
  BEGIN
    -- Alter Session to BINARY
    -- COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; -- OF-7789
    -- Proceed ahead ONLY IF PI_TABLES_ID has a value.
    IF PI_TABLES_ID IS NOT NULL THEN
      --sales planning change;
      BEGIN
        SELECT USER ||
               DECODE(PI_INDEX_TABLESPACE, 1, '_IND', 2, '_IND', 3, '_OUT')
          INTO V_INDEX_TABLESPACE_NAME
          from dual;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      -- IF_1
      -- 1. Call REAPPLY_ALL_DROPPED_INDEXES with PI_TRANSACTION_ID NULL.
      COMMONS_INDEXING.REAPPLY_ALL_DROPPED_INDEXES(PI_TABLES_ID             => PI_TABLES_ID,
                                                   PI_PROCESS_ID            => PI_PROCESS_ID,
                                                   PI_RUN_ID                => PI_RUN_ID,
                                                   PI_TRANSACTION_ID        => V_TRANSACTION_ID,
                                                   PI_TABLE_NAME            => V_TABLE_NAME,
                                                   PI_INDEX_TABLESPACE_NAME => V_INDEX_TABLESPACE_NAME,
                                                   PO_LOG_MSG               => PO_LOG_MSG);
    END IF; -- END IF_1
    -- Alter Session to NLS Parameters
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  EXCEPTION
    WHEN OTHERS THEN
      COMMONS_INDEXING.SAVE_EXCEPTIONS(PI_RUN_ID    => PI_RUN_ID,
                                       PI_EXCEPTION => SQLERRM);

  END REAPPLY_ALL_DROPPED_INDEXES;

  PROCEDURE CREATE_SPECIFIED_APP_INDEX(PI_TABLES_ID                  IN NUMBER,
                                       PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                                       PI_IS_UNIQUE                  IN NUMBER,
                                       PI_DEF_ID                     IN NUMBER,
                                       PI_BUSINESS_NAME              IN VARCHAR2,
                                       PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                       PI_PROCESS_ID                 IN NUMBER DEFAULT NULL,
                                       PI_RUN_ID                     IN NUMBER DEFAULT NULL,
                                       PO_INDEX_CREATION_STATUS      OUT NUMBER) IS
    --stores table name
    V_TABLENAME VARCHAR2(30) := '';

    --comma separated column list
    V_COMMA_INPUT_COLUMN_LIST CLOB;

    --column list ion collection to be inserted in ASIM table
    V_COLLECTION_INPUT_COLUMN_LIST COLTYPE_INDEXED_COLUMNS_LIST1;

    -- Feature Index name which is derived
    V_INDEXNAME VARCHAR2(30) := '';

    --stauts of index creation code
    V_INDEX_OUT_STATUS NUMBER;

    -- index name returned
    V_INDEX_NAME_RETURNED VARCHAR2(30);

    --decision to create index
    V_INDEX_CREATION_DECISION NUMBER := 1;

    --exception if user passes more than 32 columns
    MAXIMUM_NO_OF_COLS_32 EXCEPTION;
    PRAGMA EXCEPTION_INIT(MAXIMUM_NO_OF_COLS_32, -1793);

    --columnlist which is already indexed
    v_already_indexed_column_list coltype_indexed_columns_list1;

    v_already_indexed_col_list_aim VARCHAR2(1000 CHAR);
    v_update_required              NUMBER := 0;
    V_UNIQUENESS_RETURNED          VARCHAR2(9);
    V_CREATE_INDEX_DDL             CLOB;
    V_INDEX_TABLESPACE_NAME        VARCHAR2(30);
    --OF-15133
    V_INDEX_TYPE NUMBER(1);
    V_PO_FLAG    NUMBER(1); --OF-35664
  BEGIN
    -- 1. Alter Session to BINARY
    --COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; --OF-7789
    --OF-76348; added if clause to avoid exception
   IF PI_TABLES_ID IS NOT NULL AND PI_DEF_ID IS NOT NULL AND
       PI_BUSINESS_NAME IS NOT NULL THEN
    --Get the table name
    /*CHANGES STARTS FOR OF-77212*/
    BEGIN
    SELECT T.TABLES_PHYSICAL_NAME,
           COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID) /*OF-11821*/
      INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN;
    END;
    /*CHANGES ENDS FOR OF-77212*/

    --CREATE COMMA SEPARATED LIST OF COLUMN NAMES FROM THE TABLETYPE_CHARMAX INPUT COLLECTION PARAMETER PI_COLUMN_LIST
    SELECT LISTAGG(UPPER(COLUMN_VALUE), ',') WITHIN GROUP(ORDER BY ROWNUM)
      INTO V_COMMA_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);

    --Get column list into coltype_indexed_column_list format to insert/update the column list in ASIM table
    SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(4000 CHAR)) ORDER BY
                        ROWNUM) AS COLTYPE_INDEXED_COLUMNS_LIST1) AS INDEXED_COLUMNS
      INTO V_COLLECTION_INPUT_COLUMN_LIST
      FROM TABLE(PI_COLUMN_LIST);

    -- Loop to determine if Record already exists or not for the input definition id and business name
    FOR c IN (SELECT ASIM.*
                FROM APP_SPECIFIC_INDEXES_METADATA ASIM
               WHERE ASIM.ASIM_TABLE_NAME = V_TABLENAME
                 AND ASIM.ASIM_DEF_ID = PI_DEF_ID
                 AND ASIM.ASIM_BUSINESS_NAME = PI_BUSINESS_NAME) LOOP
      --LOOP 1 START

      -- index already exists for the given definition Id and business name
      v_indexname                   := c.asim_index_name;
      v_already_indexed_column_list := c.asim_indexed_columns;
      v_update_required             := 1;
    END LOOP; --LOOP 1 END

    --Metadata already existing for the given definition and business name
    IF V_update_required = 1 THEN
      -- IF_1 START

      -- Create COMMA SEPARATED LIST OF ALREADY INDEXED COLUMN NAMES of ASIM metadata table
      SELECT LISTAGG(UPPER(COLUMN_VALUE), ',') WITHIN GROUP(ORDER BY ROWNUM)
        INTO v_already_indexed_col_list_aim
        FROM TABLE(v_already_indexed_column_list);

      -- if existing index columns are same as comma separated list of column list requested
      -- eg index on Columns C1,C2,C3 is same as requested C1,C2%
      -- IF_2 START
      IF v_already_indexed_col_list_aim LIKE
         UPPER(V_COMMA_INPUT_COLUMN_LIST) || '%' THEN
        -- Check for exact matchness
        -- i.e. C1,C2 is not equal to C1,C2,C3
        IF UPPER(V_COMMA_INPUT_COLUMN_LIST) !=
           v_already_indexed_col_list_aim THEN
          -- IF_3 START

          --update the metadata with column list provided
          /*        UPDATE APP_SPECIFIC_INDEXES_METADATA asim
            set asim.asim_indexed_columns = V_COLLECTION_INPUT_COLUMN_LIST
          where asim.asim_table_name = V_TABLENAME
            and asim.asim_def_id = PI_DEF_ID
            and asim.asim_business_name = PI_BUSINESS_NAME;

            UPDATE AIM_INDEX_DDL_STORAGE AIDS
            SET AIDS.AIDS_INDEX_DDL =' CREATE '||CASE WHEN PI_IS_UNIQUE =1 then 'UNIQUE' else '' end|| ' INDEX ' || V_INDEXNAME || ' ON ' || V_TABLENAME || '(' ||
                V_COMMA_INPUT_COLUMN_LIST || ')' || ' TABLESPACE '||USER||'_IND'
             WHERE AIDS.AIDS_INDEX_NAME =  V_INDEXNAME; */

          COMMONS_INDEXING.DELETE_SPECIFIED_APP_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                                      PI_DEF_ID        => PI_DEF_ID,
                                                      PI_BUSINESS_NAME => PI_BUSINESS_NAME,
                                                      PI_PROCESS_ID    => PI_PROCESS_ID,
                                                      PI_RUN_ID        => PI_RUN_ID);

          v_update_required := 0;
          -- if exact matching occurs i.e. requested C1,C2 is same as already existing C1,C2
        ELSIF UPPER(V_COMMA_INPUT_COLUMN_LIST) =
              UPPER(v_already_indexed_col_list_aim) THEN
          -- IF_3 ELSE
          -- i.e. both column lists are equal
          -- No update required
          -- The given column list is already indexed/ using index
          --Set status to 0
          PO_INDEX_CREATION_STATUS := 0;
        END IF; -- IF_3 END
        -- IF_2 ELSE
        -- i.e.  the already indexed column list in AIM table is not same as column list to be indexed for the same def id and business name
        -- existing indexed columns were C1,C2 and user requests C3,C4
      ELSE
        --Call Delete_APP_Index
        --Drops the old index if it was covering and recreates any feature index using that deleted index
        -- else if it was covered index, it just deletes the metadata)
        COMMONS_INDEXING.DELETE_SPECIFIED_APP_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                                    PI_DEF_ID        => PI_DEF_ID,
                                                    PI_BUSINESS_NAME => PI_BUSINESS_NAME,
                                                    PI_PROCESS_ID    => PI_PROCESS_ID,
                                                    PI_RUN_ID        => PI_RUN_ID);
        --set the update flag to 0

        v_update_required := 0;
      END IF; -- IF_2 END
    END IF; -- IF_1 END

    IF V_update_required = 0 THEN
      -- IF_4 START

      --Get the covering index if any
      --OF-15133 Start
      --v_indexname := COMMONS_INDEXING.GET_COVERING_INDEX_1(PI_TABLE_NAME => V_TABLENAME, PI_COLUMN_LIST => V_COMMA_INPUT_COLUMN_LIST || '%');
      COMMONS_INDEXING.GET_COVERING_INDEX_DETAILS(PI_TABLE_NAME  => V_TABLENAME,
                                                  PI_COLUMN_LIST => V_COMMA_INPUT_COLUMN_LIST,
                                                  PO_INDEX_NAME  => v_indexname,
                                                  PO_INDEX_TYPE  => V_INDEX_TYPE);
      --OF-15133 End
      --if the index name is returned for the given column list, then insert the metadata

      IF v_indexname IS NOT NULL THEN
        -- IF_5 START

        --CALL INSERT_APP_INDEXES_METADATA to insert metadata
        INSERT INTO APP_SPECIFIC_INDEXES_METADATA
          (asim_id,
           asim_def_id,
           asim_business_name,
           asim_index_name,
           asim_table_name,
           asim_is_index_to_be_recreated,
           asim_indexed_columns,
           asim_index_is_unique,
           asim_index_type,
           asim_is_enabled,
           asim_creation_date,
           asim_last_update_date)
        VALUES
          (ASIM_SEQ.NEXTVAL,
           PI_DEF_ID,
           PI_BUSINESS_NAME,
           v_indexname,
           V_TABLENAME,
           PI_RECREATE_INDEX_ON_COL_DROP,
           V_COLLECTION_INPUT_COLUMN_LIST,
           PI_IS_UNIQUE,
           /*2, --OF-15133 Start */
           nvl(v_index_type, 2), /*--OF-15133 End*/
           1,
           SYSTIMESTAMP,
           SYSTIMESTAMP);

        V_INDEX_CREATION_DECISION := 0;
        --Set status to 0
        PO_INDEX_CREATION_STATUS := 0;
      END IF; -- IF_5 END

      --IF INDEX IS TO BE CREATED
      IF V_INDEX_CREATION_DECISION = 1 THEN
        -- IF_6 START

        -- CHECK IF THE COLUMN LIST CONTAINS SINGLE COLUMN OR MULTIPLE COLUMNS

        IF PI_COLUMN_LIST.COUNT > 32 THEN
          -- IF_7 START
          RAISE MAXIMUM_NO_OF_COLS_32;
        ELSIF PI_IS_UNIQUE = 1 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_UI'; /*OF-21059*/
        ELSIF PI_COLUMN_LIST.COUNT > 1 AND PI_COLUMN_LIST.COUNT < 33 THEN
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_CI'; /*OF-21059*/
        ELSE
          V_INDEXNAME := 'APP_' || 'T' || PI_TABLES_ID || '_' ||
                         APP_INDEX_NAME_SEQ.NEXTVAL || '_SI'; /*OF-21059*/
        END IF; -- IF_7 END
        /*-- OF-33540
        COMMONS_INDEXING.MERGE_AIR(
          PI_DEFINITION_ID =>PI_DEF_ID,
          PI_INDEX_NAME =>V_INDEX_NAME_RETURNED,
          PI_TABLE_NAME =>V_TABLENAME,
          PI_COLUMN_LIST =>v_already_indexed_col_list_aim,
          PI_RECREATE_INDEX_ON_COL_DROP =>PI_RECREATE_INDEX_ON_COL_DROP,
          PI_BUSINESS_NAME =>PI_BUSINESS_NAME,
          PI_IS_UNIQUE =>PI_IS_UNIQUE,
          PI_INDEX_TYPE =>2,
          PI_STATUS =>1
        );    */
        /* OF-35664 START */
        BEGIN
          INDEX_USAGE.IS_CREATE(PI_TABLE_NAME           => V_TABLENAME,
                                PI_INDEX_NAME           => V_INDEXNAME,
                                PI_COLUMN_NAME_LIST     => NULL,
                                PI_COLUMN_LIST_FUNCTION => V_COLLECTION_INPUT_COLUMN_LIST,
                                PI_IDENTIFIER           => 0, /* 0 APP INDEX, 1 DBA INDEX, (CORE TYPES START HERE)2- BUSINESS, 3-PK, 4 ENTITY, 5- PERIOD*/
                                PO_FLAG                 => V_PO_FLAG);
          IF V_PO_FLAG = 0 THEN

            COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => PI_DEF_ID,
                                       PI_INDEX_NAME                 => V_INDEXNAME,
                                       PI_TABLE_NAME                 => V_TABLENAME,
                                       PI_COLUMN_LIST                => v_already_indexed_col_list_aim,
                                       PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                       PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                       PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                       PI_INDEX_TYPE                 => 2,
                                       PI_STATUS                     => 1);
            RETURN;
          END IF;
        END;
        /* OF-35664 END */
        --CALL THE CREATE_INDEX TO CREATE THE INDEX
        COMMONS_INDEXING.CREATE_USER_SPECIFIED_INDEX(PI_TABLE_NAME        => V_TABLENAME,
                                                     PI_INDEX_NAME        => V_INDEXNAME,
                                                     PI_COL_LIST          => PI_COLUMN_LIST,
                                                     PI_UNIQUENESS        => PI_IS_UNIQUE,
                                                     PI_COL_IS_PRIMARYKEY => 0,
                                                     PI_INDEX_TABLESPACE  => V_INDEX_TABLESPACE_NAME, /*OF-11821*/
                                                     PI_RUN_ID            => PI_RUN_ID,
                                                     PO_INDEX_STATUS      => V_INDEX_OUT_STATUS,
                                                     PO_INDEX_NAME        => V_INDEX_NAME_RETURNED,
                                                     PO_IS_UNIQUE         => V_UNIQUENESS_RETURNED,
                                                     PO_CREATE_DDL        => V_CREATE_INDEX_DDL);

        IF V_INDEX_OUT_STATUS = 1 THEN

          -- OF-33540
          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => PI_DEF_ID,
                                     PI_INDEX_NAME                 => V_INDEX_NAME_RETURNED,
                                     PI_TABLE_NAME                 => V_TABLENAME,
                                     PI_COLUMN_LIST                => V_COMMA_INPUT_COLUMN_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                     PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                     PI_INDEX_TYPE                 => 2,
                                     PI_STATUS                     => 2);
          -- INDEX DETAILS ARE ENTERED INTO APPLICATION_INDEXES_METADATA TABLE

          commons_indexing.INSERT_APP_INDEXES_METADATA2(PI_DEFINITION_ID              => PI_DEF_ID,
                                                        PI_INDEX_NAME                 => V_INDEX_NAME_RETURNED,
                                                        PI_TABLE_NAME                 => V_TABLENAME,
                                                        PI_COLUMN_LIST                => V_COLLECTION_INPUT_COLUMN_LIST,
                                                        PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                                        PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                                        PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                                        PI_INDEX_TYPE                 => 2,
                                                        PI_INDEX_INSERT_DDL           => V_CREATE_INDEX_DDL);
          PO_INDEX_CREATION_STATUS := 1;
        ELSIF V_INDEX_OUT_STATUS = 2 THEN
          PO_INDEX_CREATION_STATUS := 0;
        END IF;
      END IF; -- IF_6 END
    END IF; -- IF_4 END
    END IF; --OF-76348;
    --COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END CREATE_SPECIFIED_APP_INDEX;

  PROCEDURE DELETE_SPECIFIED_APP_INDEX(PI_TABLES_ID     IN NUMBER,
                                       PI_DEF_ID        IN NUMBER,
                                       PI_BUSINESS_NAME IN VARCHAR2,
                                       PI_PROCESS_ID    IN NUMBER DEFAULT NULL,
                                       PI_RUN_ID        IN NUMBER DEFAULT NULL) IS
    V_TABLENAME        VARCHAR2(30) := '';
    V_DDL_QUERY        CLOB;
    V_UNDO_DDL_QUERY   CLOB;
    V_INDEX_LIST       COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_DDL    COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE;
    V_DDL_CREATE_INDEX CLOB := NULL;
    V_LENGTH           NUMBER;

    V_VALID_COLUMNS_COLLECTION TABLETYPE_CHARMAX;
    V_OUT_CREATION_STATUS      NUMBER;
    V_INDEX_COLUMN_LIST        VARCHAR2(1300 CHAR);
    V_PO_DEF_ID                NUMBER(10); --OF-35669
    V_PO_FLAG                  NUMBER(1); --OF-35669
    V_PO_BUSINESS_NAME         VARCHAR2(60 CHAR); --OF-35669
  BEGIN
    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    --COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY;

    IF PI_TABLES_ID IS NOT NULL AND PI_DEF_ID IS NOT NULL AND
       PI_BUSINESS_NAME IS NOT NULL THEN
      --Get Table name
      SELECT T.TABLES_PHYSICAL_NAME
        INTO V_TABLENAME
        FROM TABLES T
       WHERE T.TABLES_ID = PI_TABLES_ID;

      -- Check if this Feature Index (FI) covers any other FIs
      -- OF-26741 - Added one more clause in the WHERE part to check with AIDS table so that ones which are physically present, only those indexes should come here.
      FOR C IN (SELECT asim_PARENT.asim_DEF_ID,
                       UPPER(asim_PARENT.asim_BUSINESS_NAME) ASIM_BUSINESS_NAME,
                       asim_PARENT.asim_INDEX_TYPE,
                       asim_PARENT.asim_INDEX_NAME,
                       asim_PARENT.asim_TABLE_NAME,
                       asim_PARENT.asim_INDEX_IS_UNIQUE,
                       asim_PARENT.ASIM_INDEXED_COLUMNS,
                       (SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID
                          FROM DUAL) TRANSACTION_ID
                  FROM APP_SPECIFIC_INDEXES_METADATA asim_PARENT
                 WHERE NOT EXISTS
                 (SELECT 1
                          FROM APP_SPECIFIC_INDEXES_METADATA asim_CHILD
                         WHERE asim_PARENT.asim_INDEX_NAME =
                               asim_CHILD.asim_INDEX_NAME
                           AND ((SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(asim_CHILD.asim_INDEXED_COLUMNS)) >
                               (SELECT REGEXP_COUNT(LISTAGG(COLUMN_VALUE, ',')
                                                     WITHIN
                                                     GROUP(ORDER BY ROWNUM),
                                                     ',')
                                   FROM TABLE(asim_PARENT.asim_INDEXED_COLUMNS))))
                   AND asim_PARENT.asim_INDEX_TYPE = 2
                   AND asim_PARENT.asim_DEF_ID = PI_DEF_ID
                   AND UPPER(asim_PARENT.asim_TABLE_NAME) =
                       UPPER(V_TABLENAME)
                   AND UPPER(asim_PARENT.asim_BUSINESS_NAME) =
                       UPPER(PI_BUSINESS_NAME)
                   AND NOT EXISTS (SELECT 1
                          FROM APP_SPECIFIC_INDEXES_METADATA asim_CORE
                         WHERE asim_CORE.asim_INDEX_NAME =
                               asim_PARENT.asim_INDEX_NAME
                           AND asim_CORE.asim_INDEX_TYPE = 1)
                   AND EXISTS
                 (SELECT 1
                          FROM AIM_INDEX_DDL_STORAGE AIDS
                         WHERE AIDS.AIDS_INDEX_NAME =
                               asim_PARENT.asim_INDEX_NAME)) LOOP
        /*OF-35669 START */
        BEGIN
          INDEX_USAGE.IS_DELETE(PI_INDEX_NAME    => C.ASIM_INDEX_NAME,
                                PO_BUSINESS_NAME => V_PO_BUSINESS_NAME,
                                PO_DEF_ID        => V_PO_DEF_ID,
                                PO_FLAG          => V_PO_FLAG);
          IF V_PO_FLAG = 0 THEN
            UPDATE APP_SPECIFIC_INDEXES_METADATA ASIM
               SET ASIM_DEF_ID        = V_PO_DEF_ID,
                   ASIM_BUSINESS_NAME = V_PO_BUSINESS_NAME
             WHERE ASIM.ASIM_DEF_ID = C.ASIM_DEF_ID
               AND ASIM.ASIM_TABLE_NAME = C.ASIM_TABLE_NAME
               AND ASIM.ASIM_BUSINESS_NAME = C.ASIM_BUSINESS_NAME;
            RETURN;
          END IF;
        END;
        /*OF-35669 END */
        -- a. Drop this Physical Feature Index using DDL Framework (so that it can be rolled back if required)
        V_DDL_QUERY := 'BEGIN
                            FOR I in (SELECT * FROM DUAL WHERE EXISTS
                              (SELECT 1 FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                       C.ASIM_INDEX_NAME ||
                       '''))) LOOP
                              EXECUTE IMMEDIATE ''DROP INDEX ' ||
                       C.asim_INDEX_NAME || ''';
                            END LOOP;
                          END;';

        -- 1. Call to GET_INDEX_DDLS_FOR_APP
        SELECT C.asim_INDEX_NAME BULK COLLECT INTO V_INDEX_LIST FROM DUAL;

        --V_INDEX_LIST :=COMMONS_INDEXING.TYPE_CONSTRAINT_NAME(C.asim_INDEX_NAME);
        COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                PO_INDEX_DDL  => V_OUT_INDEX_DDL);

        IF V_OUT_INDEX_DDL.COUNT = 1 THEN
          V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;

          --Replace single quote with TWO single quotes
          V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                               '\''',
                                               '''''');

          --Get the length of statement created
          V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);

          --Remove the extra single quote from START and END, as the start and end are also
          -- appended with extra single quote being clob statement
          V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX, 2, V_LENGTH - 1);

          V_UNDO_DDL_QUERY := '
            BEGIN
              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                              C.asim_INDEX_NAME ||
                              ''')))
              LOOP
                EXECUTE IMMEDIATE ''' ||
                              V_DDL_CREATE_INDEX || ''';
              END LOOP;
            END;';
        END IF;

        -- 2. Call to EXECUTE_DDL
        COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => C.TRANSACTION_ID,
                                         PI_DESCRIPTION    => 'DROP INDEX ' ||
                                                              C.asim_INDEX_NAME,
                                         PI_DDL            => V_DDL_QUERY,
                                         PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                         pi_run_id         => PI_RUN_ID);

        DELETE FROM AIM_INDEX_DDL_STORAGE AIDS
         WHERE AIDS.AIDS_INDEX_NAME = C.asim_INDEX_NAME;

        DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
         WHERE asim.asim_DEF_ID = PI_DEF_ID
           AND asim.asim_BUSINESS_NAME = PI_BUSINESS_NAME
           AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME);
        -- OF-33540
        SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
          INTO V_INDEX_COLUMN_LIST
          FROM TABLE(C.ASIM_INDEXED_COLUMNS);

        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => C.ASIM_DEF_ID,
                                   PI_INDEX_NAME                 => C.ASIM_INDEX_NAME,
                                   PI_TABLE_NAME                 => C.ASIM_TABLE_NAME,
                                   PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                   PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                   PI_IS_UNIQUE                  => NULL,
                                   PI_INDEX_TYPE                 => C.ASIM_INDEX_TYPE,
                                   PI_STATUS                     => 3);

        -- c. Call the proc: "UPDATE_APP_INDEXES" to: Recreate, if applicable, other FIs which are covered (i.e. NOT PHYSICALY PRESENT) by the FI to be deleted.
        --Feature indexes depending on this index need to be updated
        FOR d IN (SELECT asim.*,
                         (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                            FROM TABLE(asim.asim_INDEXED_COLUMNS)) asim_INDEXED_COLUMNS_LIST
                    FROM APP_SPECIFIC_INDEXES_METADATA asim
                   WHERE asim.asim_INDEX_NAME = c.asim_index_name
                     AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME)
                     AND asim_INDEX_TYPE = 2
                   ORDER BY REGEXP_COUNT(asim_INDEXED_COLUMNS_LIST, ',') DESC) LOOP
          SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(4000 CHAR))
                              ORDER BY ROWNUM) AS tabletype_charmax)
            INTO v_valid_columns_collection
            FROM TABLE(d.asim_indexed_columns) t
           INNER JOIN user_tab_columns utc
              ON utc.TABLE_NAME = d.asim_table_name
             AND utc.COLUMN_NAME = t.COLUMN_VALUE;

          DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_BUSINESS_NAME = d.asim_business_name
             AND asim.asim_DEF_ID = d.asim_def_id
             AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME);
          -- OF-33540
          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => d.ASIM_DEF_ID,
                                     PI_INDEX_NAME                 => d.ASIM_INDEX_NAME,
                                     PI_TABLE_NAME                 => d.ASIM_TABLE_NAME,
                                     PI_COLUMN_LIST                => D.asim_INDEXED_COLUMNS_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                     PI_BUSINESS_NAME              => d.ASIM_BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => NULL,
                                     PI_INDEX_TYPE                 => d.ASIM_INDEX_TYPE,
                                     PI_STATUS                     => 3);
          COMMONS_INDEXING.CREATE_SPECIFIED_APP_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                                      PI_COLUMN_LIST                => v_valid_columns_collection,
                                                      PI_IS_UNIQUE                  => d.asim_index_is_unique,
                                                      PI_DEF_ID                     => d.asim_def_id,
                                                      PI_BUSINESS_NAME              => d.asim_business_name,
                                                      PI_RECREATE_INDEX_ON_COL_DROP => d.asim_is_index_to_be_recreated,
                                                      PI_RUN_ID                     => PI_RUN_ID,
                                                      PO_INDEX_CREATION_STATUS      => V_OUT_CREATION_STATUS);
        END LOOP;
      END LOOP;

      /*        -- Call the proc: "DELETE_asim_BY_DEFID_AND_BNAME" to delete the Metadata for this FI, if it is not a COVERING Index.
      COMMONS_INDEXING.DELETE_asim_BY_DEFID_AND_BNAME(
        PI_TABLE_NAME    => UPPER(V_TABLENAME),
        PI_DEFINITION_ID => PI_DEF_ID,
        PI_BUSINESS_NAME => PI_BUSINESS_NAME);*/

      DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
       WHERE asim.asim_DEF_ID = PI_DEF_ID
         AND asim.asim_BUSINESS_NAME = PI_BUSINESS_NAME
         AND asim.asim_TABLE_NAME = UPPER(V_TABLENAME);
    END IF;
    -- Defect # 14383, 15167

  END DELETE_SPECIFIED_APP_INDEX;

  PROCEDURE COMBINED_DELETE_SPEC_APP_INDEX(PI_TABLES_ID           IN NUMBER,
                                           PI_DELETE_INDEX_OBJECT IN COLTYPE_DELETE_INDEX,
                                           PI_PROCESS_ID          IN NUMBER DEFAULT NULL,
                                           PI_RUN_ID              IN NUMBER DEFAULT NULL) IS
    V_TABLENAME           VARCHAR2(30) := '';
    V_DDL_QUERY           CLOB;
    V_UNDO_DDL_QUERY      CLOB;
    V_INDEX_LIST          COMMONS_INDEXING.TYPE_CONSTRAINT_NAME;
    V_OUT_INDEX_DDL       COMMONS_INDEXING.TYPE_INDEX_DDL_COMPOSITE;
    V_DDL_CREATE_INDEX    CLOB := NULL;
    V_LENGTH              NUMBER;
    v_index_rec           TABLETYPE_ASIM_COLUMNS := TABLETYPE_ASIM_COLUMNS();
    v_index_name          VARCHAR2(30 char);
    v_transaction_id      VARCHAR2(30 char);
    V_ORPHAN_INDEX_OBJECT COLTYPE_DELETE_INDEX;
    V_PARENT_INDEX_OBJECT COLTYPE_DELETE_INDEX;
    V_CHILD_INDEX_OBJECT  COLTYPE_DELETE_INDEX;

    V_VALID_COLUMNS_COLLECTION TABLETYPE_CHARMAX;
    V_OUT_CREATION_STATUS      NUMBER;
    V_INDEX_COLUMN_LIST        VARCHAR2(1300 CHAR);
    V_PO_DEF_ID                NUMBER(10); --OF-35669
    V_PO_FLAG                  NUMBER(1); --OF-35669
    V_PO_BUSINESS_NAME         VARCHAR2(60 CHAR); --OF-35669
    V_CNT                      NUMBER;
  BEGIN

    IF PI_TABLES_ID IS NULL THEN
      RETURN;
    END IF;
    --Get Table name
    SELECT UPPER(T.TABLES_PHYSICAL_NAME)
      INTO V_TABLENAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;

    --commons_utils.insert_logs('V_TABLENAME: ' || V_TABLENAME);
    SELECT OBJTYPE_ASIM_COLUMNS(asim_PARENT.asim_DEF_ID,
                                asim_PARENT.Asim_Business_Name,
                                asim_CHILD.asim_DEF_ID,
                                asim_CHILD.Asim_Business_Name,
                                (SELECT case
                                          when count(1) = 1 then
                                           0
                                          else
                                           1
                                        end
                                   from dual
                                  where exists((SELECT listagg(column_value,
                                                               ',') within GROUP(ORDER BY rownum) V_INDEX_COLUMN_LIST1
                                                  FROM TABLE(asim_PARENT.ASIM_INDEXED_COLUMNS))
                                               minus
                                               (SELECT listagg(column_value,
                                                               ',') within GROUP(ORDER BY rownum) V_INDEX_COLUMN_LIST2
                                                  FROM TABLE(asim_CHILD.ASIM_INDEXED_COLUMNS))

                                               ))) --matching_flag; count(1) = 1 means there is a difference so match_flag=0
      bulk collect
      into v_index_rec
      FROM APP_SPECIFIC_INDEXES_METADATA asim_PARENT
      left outer join APP_SPECIFIC_INDEXES_METADATA asim_CHILD
        on (regexp_instr((SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
                           FROM TABLE(asim_PARENT.asim_INDEXED_COLUMNS)),
                         (SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
                            FROM TABLE(asim_CHILD.asim_INDEXED_COLUMNS))) = 1 AND
           asim_child.asim_DEF_ID <> asim_PARENT.asim_DEF_ID AND
           UPPER(asim_PARENT.asim_TABLE_NAME) =
           UPPER(asim_child.asim_TABLE_NAME))
     where asim_PARENT.asim_INDEX_TYPE in (1, 2)
       AND (asim_PARENT.asim_DEF_ID, UPPER(asim_PARENT.asim_BUSINESS_NAME)) IN
           (SELECT def_id, BUSINESS_NAME from table(PI_DELETE_INDEX_OBJECT))
          --AND asim_child.asim_DEF_ID NOT IN asim_PARENT.asim_DEF_ID
       AND UPPER(asim_PARENT.asim_TABLE_NAME) = V_TABLENAME;
    --AND UPPER(asim_child.asim_TABLE_NAME) = V_TABLENAME

    --commons_utils.insert_logs('v_index_rec.count: ' || v_index_rec.count);
    IF v_index_rec.count > 0 THEN
      --scenario 1; only child, drop index and delete entry from AIDS and ASIM tables

      SELECT OBJTYPE_DELETE_INDEX(tab.PARENT_BIZ_NAME, tab.PARENT_DEF_ID)
        bulk collect
        into V_ORPHAN_INDEX_OBJECT
        from table(v_index_rec) tab
       where match_flag = 0;

      --commons_utils.insert_logs('V_ORPHAN_INDEX_OBJECT.count: ' ||V_ORPHAN_INDEX_OBJECT.count);
      FOR i in 1 .. V_ORPHAN_INDEX_OBJECT.count LOOP
        BEGIN
          SELECT asim_index_name,
                 (SELECT COMMONS_DDL_HANDLING.GET_TRANSACTION_ID FROM DUAL) TRANSACTION_ID,
                 (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                    FROM TABLE(ASIM_INDEXED_COLUMNS))
            into v_index_name, v_transaction_id, V_INDEX_COLUMN_LIST
            FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_DEF_ID = V_ORPHAN_INDEX_OBJECT(i).DEF_ID
             and asim.asim_BUSINESS_NAME = V_ORPHAN_INDEX_OBJECT(i)
                .BUSINESS_NAME
             AND asim_table_name = V_TABLENAME;

          V_CNT := 0;

          select count(1)
            into v_cnt
            from APP_SPECIFIC_INDEXES_METADATA asim
           where asim.asim_business_name = V_ORPHAN_INDEX_OBJECT(i)
                .BUSINESS_NAME
             and asim.asim_table_name = V_TABLENAME;
          --and asim.asim_index_name = v_index_name

          --commons_utils.insert_logs('v_cnt: ' || v_cnt);
          IF v_cnt <= 1 and v_index_name not like '%BUSINESSKEY_UI' THEN
            V_DDL_QUERY := 'BEGIN
                            FOR I in (SELECT * FROM DUAL WHERE EXISTS
                              (SELECT 1 FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                           v_index_name ||
                           '''))) LOOP
                              EXECUTE IMMEDIATE ''DROP INDEX ' ||
                           v_index_name || ''';
                            END LOOP;
                            EXCEPTION
                              WHEN OTHERS
                                THEN
                                  NULL;
                          END;';

            SELECT v_index_name BULK COLLECT INTO V_INDEX_LIST FROM DUAL;

            --V_INDEX_LIST := COMMONS_INDEXING.TYPE_CONSTRAINT_NAME(v_index_name);

            COMMONS_INDEXING.GET_INDEX_DDLS_FOR_APP(PI_INDEX_LIST => V_INDEX_LIST,
                                                    PO_INDEX_DDL  => V_OUT_INDEX_DDL);

            IF V_OUT_INDEX_DDL.COUNT = 1 THEN
              V_DDL_CREATE_INDEX := V_OUT_INDEX_DDL(1).DDL_STMT;

              --Replace single quote with TWO single quotes
              V_DDL_CREATE_INDEX := REGEXP_REPLACE(V_DDL_CREATE_INDEX,
                                                   '\''',
                                                   '''''');

              --Get the length of statement created
              V_LENGTH := LENGTH(V_DDL_CREATE_INDEX);

              --Remove the extra single quote from START and END, as the start and end are also
              -- appended with extra single quote being clob statement
              V_DDL_CREATE_INDEX := SUBSTR(V_DDL_CREATE_INDEX,
                                           2,
                                           V_LENGTH - 1);
              V_UNDO_DDL_QUERY   := '
            BEGIN
              FOR D IN (SELECT 1 FROM DUAL WHERE NOT EXISTS(
                SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME = UPPER(''' ||
                                    v_index_name ||
                                    ''')))
              LOOP
                EXECUTE IMMEDIATE ''' ||
                                    V_DDL_CREATE_INDEX || ''';
              END LOOP;
                   EXCEPTION
                              WHEN OTHERS
                                THEN
                                  NULL;
            END;';
            END IF;

            -- 2. Call to EXECUTE_DDL
            COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => v_transaction_id,
                                             PI_DESCRIPTION    => 'COMBINED_DELETE_SPEC_APP_INDEX - DROP INDEX ' ||
                                                                  v_index_name,
                                             PI_DDL            => V_DDL_QUERY,
                                             PI_UNDO_DDL       => V_UNDO_DDL_QUERY,
                                             pi_run_id         => PI_RUN_ID);

            DELETE FROM AIM_INDEX_DDL_STORAGE AIDS
             WHERE AIDS.AIDS_INDEX_NAME = v_index_name
               and AIDS_TABLE_NAME = V_TABLENAME;

          END IF;

          DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_def_id = V_ORPHAN_INDEX_OBJECT(i).DEF_ID
             AND asim.asim_BUSINESS_NAME = V_ORPHAN_INDEX_OBJECT(i)
                .BUSINESS_NAME
             AND asim.asim_TABLE_NAME = V_TABLENAME;

          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => V_ORPHAN_INDEX_OBJECT(i)
                                                                      .DEF_ID,
                                     PI_INDEX_NAME                 => v_index_name,
                                     PI_TABLE_NAME                 => V_TABLENAME,
                                     PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                     PI_BUSINESS_NAME              => V_ORPHAN_INDEX_OBJECT(i)
                                                                      .BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => NULL,
                                     PI_INDEX_TYPE                 => 2,
                                     PI_STATUS                     => 3);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      END LOOP;

      --*****************scenario 2******************************************-----
      --when parent def id matches with existing entry in ASIM (match = 1) then delete an entry

      SELECT OBJTYPE_DELETE_INDEX(tab.PARENT_BIZ_NAME, tab.PARENT_DEF_ID)
        bulk collect
        into V_PARENT_INDEX_OBJECT
        from table(v_index_rec) tab
       where match_flag = 1;

      --commons_utils.insert_logs('V_PARENT_INDEX_OBJECT.count: ' ||V_PARENT_INDEX_OBJECT.count);
      FOR i in 1 .. V_PARENT_INDEX_OBJECT.count LOOP

        BEGIN
          SELECT asim_index_name,
                 (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                    FROM TABLE(asim.ASIM_INDEXED_COLUMNS))
            into v_index_name, V_INDEX_COLUMN_LIST
            FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_def_id = V_PARENT_INDEX_OBJECT(i).def_id
             AND asim.asim_BUSINESS_NAME = V_PARENT_INDEX_OBJECT(i)
                .business_name
             AND asim_table_name = V_TABLENAME;

          /*DELETE FROM AIM_INDEX_DDL_STORAGE AIDS
          WHERE AIDS.AIDS_INDEX_NAME = v_index_name
            and AIDS_TABLE_NAME = V_TABLENAME;*/

          DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_def_id = V_PARENT_INDEX_OBJECT(i).def_id
             AND asim.asim_BUSINESS_NAME = V_PARENT_INDEX_OBJECT(i)
                .business_name
             AND asim.asim_TABLE_NAME = V_TABLENAME;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
        COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => V_PARENT_INDEX_OBJECT(i)
                                                                    .def_id,
                                   PI_INDEX_NAME                 => v_index_name,
                                   PI_TABLE_NAME                 => V_TABLENAME,
                                   PI_COLUMN_LIST                => V_INDEX_COLUMN_LIST,
                                   PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                   PI_BUSINESS_NAME              => V_PARENT_INDEX_OBJECT(i)
                                                                    .business_name,
                                   PI_IS_UNIQUE                  => NULL,
                                   PI_INDEX_TYPE                 => 2,
                                   PI_STATUS                     => 3);
      END LOOP;

      --scenario 3 :recreate

      select OBJTYPE_DELETE_INDEX(tab.child_def_id, tab.child_biz_name)
        bulk collect
        into V_CHILD_INDEX_OBJECT
        from (SELECT child_def_id, child_biz_name
                from table(v_index_rec)
               where match_flag = 0
              minus
              SELECT child_def_id, child_biz_name
                from table(v_index_rec)) tab;

      IF V_CHILD_INDEX_OBJECT.count > 0 THEN

        FOR d IN (SELECT asim.*,
                         (SELECT LISTAGG('''' || COLUMN_VALUE || '''', ',') WITHIN GROUP(ORDER BY ROWNUM)
                            FROM TABLE(asim.asim_INDEXED_COLUMNS)) asim_INDEXED_COLUMNS_LIST
                    FROM APP_SPECIFIC_INDEXES_METADATA asim
                   WHERE (asim.asim_def_id, asim.asim_business_name) in
                         (SELECT def_id, BUSINESS_NAME
                            from table(V_CHILD_INDEX_OBJECT))
                     AND asim.asim_TABLE_NAME = V_TABLENAME
                     AND asim_INDEX_TYPE = 2
                   ORDER BY REGEXP_COUNT(asim_INDEXED_COLUMNS_LIST, ',') DESC) LOOP
          SELECT CAST(COLLECT(CAST(t.COLUMN_VALUE AS VARCHAR2(4000 CHAR))
                              ORDER BY ROWNUM) AS tabletype_charmax)
            INTO v_valid_columns_collection
            FROM TABLE(d.asim_indexed_columns) t
           INNER JOIN user_tab_columns utc
              ON utc.TABLE_NAME = d.asim_table_name
             AND utc.COLUMN_NAME = t.COLUMN_VALUE;

          DELETE FROM APP_SPECIFIC_INDEXES_METADATA asim
           WHERE asim.asim_BUSINESS_NAME = d.asim_business_name
             AND asim.asim_DEF_ID = d.asim_def_id
             AND asim.asim_TABLE_NAME = V_TABLENAME;

          -- OF-33540
          COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => d.ASIM_DEF_ID,
                                     PI_INDEX_NAME                 => d.ASIM_INDEX_NAME,
                                     PI_TABLE_NAME                 => d.ASIM_TABLE_NAME,
                                     PI_COLUMN_LIST                => d.asim_INDEXED_COLUMNS_LIST,
                                     PI_RECREATE_INDEX_ON_COL_DROP => NULL,
                                     PI_BUSINESS_NAME              => d.ASIM_BUSINESS_NAME,
                                     PI_IS_UNIQUE                  => NULL,
                                     PI_INDEX_TYPE                 => d.ASIM_INDEX_TYPE,
                                     PI_STATUS                     => 3);

          COMMONS_INDEXING.CREATE_SPECIFIED_APP_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                                      PI_COLUMN_LIST                => v_valid_columns_collection,
                                                      PI_IS_UNIQUE                  => d.asim_index_is_unique,
                                                      PI_DEF_ID                     => d.asim_def_id,
                                                      PI_BUSINESS_NAME              => d.asim_business_name,
                                                      PI_RECREATE_INDEX_ON_COL_DROP => d.asim_is_index_to_be_recreated,
                                                      PI_RUN_ID                     => PI_RUN_ID,
                                                      PO_INDEX_CREATION_STATUS      => V_OUT_CREATION_STATUS);

        END LOOP;
      END IF;
    END IF;
  END COMBINED_DELETE_SPEC_APP_INDEX;

  PROCEDURE INSERT_APP_INDEXES_METADATA2(PI_DEFINITION_ID              IN NUMBER,
                                         PI_INDEX_NAME                 IN VARCHAR2,
                                         PI_TABLE_NAME                 IN VARCHAR2,
                                         PI_COLUMN_LIST                IN COLTYPE_INDEXED_COLUMNS_LIST1,
                                         PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                                         PI_BUSINESS_NAME              IN VARCHAR2,
                                         PI_IS_UNIQUE                  IN NUMBER,
                                         PI_INDEX_TYPE                 IN NUMBER,
                                         PI_INDEX_INSERT_DDL           IN CLOB,
                                         PI_IS_PRIMARY                 IN NUMBER DEFAULT NULL) IS
  BEGIN
    --COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY;--OF-7789
    -- INSERT_LOGS('In INSERT_APP_INDEXES_METADATA ');
    INSERT INTO APP_SPECIFIC_INDEXES_METADATA
      (asim_ID,
       asim_DEF_ID,
       asim_INDEX_NAME,
       asim_TABLE_NAME,
       asim_IS_INDEX_TO_BE_RECREATED,
       asim_BUSINESS_NAME,
       asim_INDEXED_COLUMNS,
       asim_INDEX_IS_UNIQUE,
       asim_INDEX_TYPE,
       asim_IS_ENABLED,
       asim_CREATION_DATE,
       asim_LAST_UPDATE_DATE)
    VALUES
      (asim_SEQ.NEXTVAL,
       PI_DEFINITION_ID,
       PI_INDEX_NAME,
       PI_TABLE_NAME,
       PI_RECREATE_INDEX_ON_COL_DROP,
       PI_BUSINESS_NAME,
       PI_COLUMN_LIST,
       PI_IS_UNIQUE,
       PI_INDEX_TYPE,
       1,
       SYSTIMESTAMP,
       SYSTIMESTAMP);

    INSERT INTO AIM_INDEX_DDL_STORAGE
      (AIDS_TABLE_NAME,
       AIDS_INDEX_NAME,
       AIDS_INDEX_IS_UNIQUE,
       AIDS_INDEX_IS_PRIMARY,
       AIDS_INDEX_DDL)
    VALUES
      (PI_TABLE_NAME,
       PI_INDEX_NAME,
       PI_IS_UNIQUE,
       DECODE(PI_IS_PRIMARY, NULL, 0, PI_IS_PRIMARY),
       PI_INDEX_INSERT_DDL);
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789
  END INSERT_APP_INDEXES_METADATA2;

  PROCEDURE CREATE_USER_SPECIFIED_INDEX(PI_TABLE_NAME        IN VARCHAR2,
                                        PI_INDEX_NAME        IN VARCHAR2,
                                        PI_COL_LIST          IN tabletype_charmax,
                                        PI_UNIQUENESS        IN NUMBER,
                                        PI_COL_IS_PRIMARYKEY IN NUMBER,
                                        PI_INITRANS          IN NUMBER DEFAULT 5,
                                        PI_INDEX_TABLESPACE  IN VARCHAR2, /*OF-11821*/
                                        PI_RUN_ID            IN NUMBER DEFAULT NULL,
                                        PO_INDEX_STATUS      OUT NUMBER, -- 1 - Created, 2 - Already exists, 3- name already taken, 4 - Maximum Key length Exceeded
                                        PO_INDEX_NAME        OUT VARCHAR2,
                                        PO_IS_UNIQUE         OUT VARCHAR2,
                                        PO_CREATE_DDL        OUT CLOB) IS
    V_TRANSACTION_ID VARCHAR2(30 CHAR);
    V_COL            VARCHAR2(1300 CHAR);
    V_DDL            CLOB;
    V_UNDO_DDL       CLOB;
    V_INDEXNAME      VARCHAR2(30) := UPPER(PI_INDEX_NAME);
    V_TABLE_NAME     VARCHAR2(30) := UPPER(PI_TABLE_NAME);
    E_MAXIMUM_KEY_LENGTH_EXCEEDED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_MAXIMUM_KEY_LENGTH_EXCEEDED, -1450);

    E_PRIMARY_KEY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_PRIMARY_KEY_EXISTS, -2260);

    E_NAME_ALREADY_EXISTS EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_NAME_ALREADY_EXISTS, -955);

    E_COLUMN_LIST_ALREADY_INDEXED EXCEPTION;
    PRAGMA EXCEPTION_INIT(E_COLUMN_LIST_ALREADY_INDEXED, -1408);
  BEGIN

    -- Defect # 14383, 15167
    -- 1. Alter Session to BINARY
    --COMMONS_INDEXING.ALTER_SESSION_NLS_BINARY; --OF-7789
    IF PI_COL_LIST IS NOT NULL THEN
      -- Get the transaction id
      V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;

      -- Create primary key constraint and index
      IF (PI_COL_IS_PRIMARYKEY = 1) THEN
        -- IF_1 START

        -- Create Primary Key on the table
        V_DDL := ' ALTER TABLE ' || V_TABLE_NAME || ' ADD CONSTRAINT ' ||
                 V_INDEXNAME || ' PRIMARY KEY (' || PI_COL_LIST(1) ||
                 ') USING INDEX  INITRANS ' || PI_INITRANS ||
                 ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        V_UNDO_DDL := '
            BEGIN
              FOR C IN (
                  SELECT NULL
                  FROM USER_CONSTRAINTS UC
                  WHERE UC.TABLE_NAME = ''' ||
                      V_TABLE_NAME || '''
                    AND UC.CONSTRAINT_TYPE = ''P''
                    AND (UC.CONSTRAINT_NAME = ''' ||
                      V_INDEXNAME ||
                      '''))
              LOOP
                EXECUTE IMMEDIATE ''ALTER TABLE ' ||
                      V_TABLE_NAME || ' DROP PRIMARY KEY DROP INDEX'';
              END LOOP;
            END;';

        -- Create the primary key index, only if v_count is increased to 1 from the above loop code
        <<CREATE_PRIMARY_KEY>>
        BEGIN

          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATES PRIMARY KEY CONSTRAINT AND INDEX ON TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          --If Primary key creation is done set v_primary_key_existence to 1
          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_CREATE_DDL   := V_DDL;

        EXCEPTION
          WHEN E_PRIMARY_KEY_EXISTS THEN
            -- Return the index and constraint name
            SELECT CONSTRAINT_NAME
              INTO PO_INDEX_NAME
              FROM USER_CONSTRAINTS
             WHERE CONSTRAINT_TYPE = 'P'
               AND TABLE_NAME = V_TABLE_NAME;

            PO_INDEX_STATUS := 2;
            PO_CREATE_DDL   := V_DDL;

        END;
        --Single column index
      ELSIF PI_COL_LIST.COUNT = 1 THEN
        V_DDL := ' CREATE ' || CASE
                   WHEN PI_UNIQUENESS = 1 THEN
                    'UNIQUE'
                   ELSE
                    ''
                 END;

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || PI_COL_LIST(1) || ')' ||
                 ' INITRANS ' || PI_INITRANS || ' TABLESPACE ' ||
                 PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        -- Execute the Create DDl through COMMONS DDL Handling service
        <<CREATE_SINGLE_COLUMN_INDEX>>
        BEGIN

          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMN ' ||
                                                                PI_COL_LIST(1) ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
          PO_CREATE_DDL   := V_DDL;

        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            PO_INDEX_STATUS := 2;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;

        END;
        --Multi columns to be indexed
      ELSIF PI_COL_LIST.COUNT > 1 THEN
        SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY ROWNUM)
          INTO V_COL
          FROM TABLE(PI_COL_LIST);

        V_DDL := ' CREATE ' || CASE
                   WHEN PI_UNIQUENESS = 1 THEN
                    'UNIQUE'
                   ELSE
                    ''
                 END;

        V_DDL := V_DDL || ' INDEX ' || V_INDEXNAME || ' ON ' ||
                 V_TABLE_NAME || '(' || V_COL || ')' || ' INITRANS ' ||
                 PI_INITRANS || ' TABLESPACE ' || PI_INDEX_TABLESPACE;

        -- UNDO DDL statement
        V_UNDO_DDL := '
            BEGIN
              FOR C IN (SELECT NULL FROM USER_INDEXES WHERE INDEX_NAME =''' ||
                      V_INDEXNAME || ''')
              LOOP
                EXECUTE IMMEDIATE ''DROP INDEX ' ||
                      V_INDEXNAME || ''';
              END LOOP;
            END;';

        <<CREATE_COMPOSITE_COLUMN_INDEX>>
        BEGIN

          COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => V_TRANSACTION_ID,
                                           PI_DESCRIPTION    => 'CREATED INDEX ' ||
                                                                V_INDEXNAME ||
                                                                ' ON COLUMNS ' ||
                                                                V_COL ||
                                                                ' OF TABLE ' ||
                                                                V_TABLE_NAME,
                                           PI_DDL            => V_DDL,
                                           PI_UNDO_DDL       => V_UNDO_DDL,
                                           PI_RUN_ID         => PI_RUN_ID);

          PO_INDEX_STATUS := 1;
          PO_INDEX_NAME   := V_INDEXNAME;
          PO_IS_UNIQUE    := PI_UNIQUENESS;
          PO_CREATE_DDL   := V_DDL;

        EXCEPTION
          WHEN E_COLUMN_LIST_ALREADY_INDEXED THEN
            PO_INDEX_STATUS := 2;
          WHEN E_NAME_ALREADY_EXISTS THEN
            PO_INDEX_STATUS := 3;
            --RAISE E_NAME_ALREADY_EXISTS;

          WHEN E_MAXIMUM_KEY_LENGTH_EXCEEDED THEN
            PO_INDEX_STATUS := 4;
            --PO_CREATE_DDL := V_DDL;
        END;
      END IF;
    END IF;
    -- COMMONS_INDEXING.ALTER_SESSION_PROJ_NLS_SETTING; -- OF-7789

  END CREATE_USER_SPECIFIED_INDEX;

  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : CHECK_INDEX_EXISTS
    * AUTHOR            : Abhivyakti Mirajkar
    * REVIEWER          : Maxim Rohit
    * INPUT PARAMETERS  : Tables_id,
    * OUTPUT PARAMETERS : N/A
    * DESCRIPTION       : This procedure is to be used by Java for identifying if any required index is missing (related to Data Views). If its missing, then an alert will be sent.
    *                     Will internally call COMMONS_INDEXING.RECREATE_ALL_DROPPED_INDEXES.
    * Example           :

   DECLARE
    V_NUM NUMBER;
    BEGIN
    COMMONS_INDEXING.CHECK_INDEX_EXISTS(
     PI_TABLES_ID   => 1234,
     PI_DEF_ID   => 382204,
     PI_BUSINESS_NAME => 'DV_FILTER_T381541_F380810',
     PI_INDEX_EXIST   =>V_NUM );
    DBMS_OUTPUT.PUT_LINE (to_char(V_NUM));
  END;

    **********************************************************************************************************************/
  PROCEDURE CHECK_INDEX_EXISTS(PI_TABLES_ID     IN NUMBER,
                               PI_DEF_ID        IN NUMBER,
                               PI_BUSINESS_NAME IN VARCHAR2,
                               PO_INDEX_STATUS  OUT NUMBER) IS
    V_INDX_COUNT NUMBER;
  BEGIN
    /*DBMS_OUTPUT.enable;*/

    SELECT COUNT(1)
      INTO V_INDX_COUNT
      FROM APP_SPECIFIC_INDEXES_METADATA
     WHERE ASIM_DEF_ID = PI_DEF_ID
       AND ASIM_BUSINESS_NAME = PI_BUSINESS_NAME
       AND ASIM_TABLE_NAME IN
           (SELECT TABLES_PHYSICAL_NAME
              FROM TABLES
             WHERE TABLES_ID = PI_TABLES_ID);

    IF V_INDX_COUNT >= 1 THEN
      --- MORE THAN ONE INSTANCES OF THE INDEX FOUND
      V_INDX_COUNT := 1;
    ELSIF V_INDX_COUNT = 0 THEN
      --NO INDEX FOUND
      SELECT COUNT(1)
        INTO V_INDX_COUNT
        FROM APPLICATION_INDEXES_METADATA
       WHERE AIM_DEF_ID = PI_DEF_ID
         AND AIM_BUSINESS_NAME = PI_BUSINESS_NAME
         AND AIM_TABLE_NAME IN
             (SELECT TABLES_PHYSICAL_NAME
                FROM TABLES
               WHERE TABLES_ID = PI_TABLES_ID);

      IF V_INDX_COUNT >= 1 THEN
        --- MORE THAN ONE INSTANCES OF THE INDEX FOUND
        V_INDX_COUNT := 1;
      ELSIF V_INDX_COUNT = 0 THEN
        --NO INDEX FOUND
        V_INDX_COUNT := 0;
      END IF;
    END IF;

    PO_INDEX_STATUS := V_INDX_COUNT;
  END CHECK_INDEX_EXISTS;

  FUNCTION GET_COLUMNS_FOR_INDEX(pi_table_info IN TABLETYPE_NAME_MAP)
    RETURN TABLETYPE_COLUMN_SELECTIVITY AS
    v_total_no_of_objects NUMBER(10);
    v_orderded_col_list   TABLETYPE_COLUMN_SELECTIVITY;
    v_stamp               VARCHAR2(200 CHAR);
  BEGIN
    v_stamp := 'COMMONS_INDEXING.GET_COLUMNS_FOR_INDEX - ' ||
               TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCOLLECTION(pi_table_info),
                             'pi_table_info := <value>;',
                             v_stamp);

    SELECT COUNT(*) -- total number of columns
      INTO v_total_no_of_objects
      FROM user_tables ut
     INNER JOIN user_tab_cols utc
        ON ut.table_name = utc.table_name
     WHERE (utc.table_name, utc.column_name) IN
           (SELECT name1 AS table_name, name2 AS column_name
              FROM TABLE(pi_table_info));

    -- check that the table and columns provided as input are valid
    IF v_total_no_of_objects - pi_table_info.COUNT < 0 THEN
      raise_application_error(-20001,
                              'Please provide valid values for table name and column names.');
    END IF;

    SELECT OBJTYPE_COLUMN_SELECTIVITY(table_name,
                                      column_name,
                                      col_selectivity)
      BULK COLLECT
      INTO v_orderded_col_list
      FROM (SELECT table_name,
                   column_name,
                   col_selectivity,
                   -- the priority of column selection is:
                   --        the most selective column,
                   --        the column with highest number of distinct values,
                   --        column name
                   ROW_NUMBER() OVER(PARTITION BY table_name ORDER BY table_name, col_selectivity ASC, num_distinct DESC, column_name ASC) AS rn
              FROM (SELECT ut.table_name,
                           utcs.column_name AS column_name,
                           -- Selectivity = (1/NumberDistinctValues) * (Num_rows - NumberOfNulls)/Num_rows
                           --      best selectivity = 0 => all rows are distinct
                           (1 / utcs.num_distinct) *
                           (ut.num_rows - utcs.num_nulls) / ut.num_rows AS col_selectivity,
                           utcs.num_distinct,
                           ut.num_rows
                      FROM user_tables ut
                     INNER JOIN user_tab_col_statistics utcs
                        ON ut.table_name = utcs.table_name
                     INNER JOIN user_tab_cols utc
                        ON utc.table_name = ut.table_name
                       AND utc.column_name = utcs.column_name
                      LEFT JOIN tables t
                        ON t.tables_physical_name = ut.table_name
                      LEFT JOIN entities e
                        ON e.entity_tables_id = t.tables_id
                       AND entity_base_entity IS NULL
                     CROSS JOIN (SELECT pr_value AS total_no_of_allowed_indexes
                                  FROM properties
                                 WHERE pr_name = 'INDEXING_LIMIT') ind
                     WHERE (utc.table_name, utc.column_name) IN
                           (SELECT name1 AS table_name, name2 AS column_name
                              FROM TABLE(pi_table_info))
                          -- avoid divide by 0 error
                       AND ut.num_rows != 0
                       AND utcs.num_distinct != 0
                       AND NVL2(e.entity_tables_id, utcs.column_name, CHR(0)) !=
                           'E_INTERNAL_ID'
                          -- check if the maximum number of indexes on the table was reached. If yes, return NULL
                       AND (SELECT COUNT(*) AS total_no_of_indexes
                              FROM user_indexes
                             WHERE table_name = ut.table_name) <
                           ind.total_no_of_allowed_indexes) t
            -- return only columns with maximum 10% duplicates
             WHERE 1 - num_distinct / num_rows <= 0.1) TAB
    -- return only the first NO_OF_INDEX_COLS rows
     WHERE RN <= NVL((SELECT pr_value AS no_of_index_col_to_return
                       FROM properties
                      WHERE pr_name = 'NO_OF_INDEX_COLS'),
                     0);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG,
                             ANYDATA.CONVERTCOLLECTION(v_orderded_col_list),
                             'v_orderded_col_list := <value>;',
                             v_stamp);
    RETURN v_orderded_col_list;
  END GET_COLUMNS_FOR_INDEX;

  -- OF-27498 - START
  FUNCTION IS_INDEX_LIMIT_EXCEEDING(PI_TABLES_ID           IN NUMBER,
                                    PI_PROCESS_ID          IN NUMBER DEFAULT NULL,
                                    PI_RUN_ID              IN NUMBER DEFAULT NULL,
                                    PI_CREATE_INDEX_OBJECT IN COLTYPE_CREATE_INDEX,
                                    PI_DELETE_INDEX_OBJECT IN COLTYPE_DELETE_INDEX)
    RETURN NUMBER -- 1 = Yes, 0 = No; Warning for the proposed indexes modification (Created and/or Dropped) for the relevant App Indexes vis-a-vis the INDEX_LIMIT property
   AS
    V_INDEX_LIMIT_WARNING_STATUS   NUMBER(1) := 0;
    V_TABLE_NAME                   VARCHAR2(30 CHAR) := NULL;
    V_EXISTING_INDEXES_COUNT       NUMBER := 0;
    V_NONCOVERABLE_INDEXES_COUNT   NUMBER := 0;
    V_DELETABLE_INDEXES_COUNT      NUMBER := 0;
    V_PROPOSED_TOTAL_INDEXES_COUNT NUMBER := 0;
    V_INDEX_LIMIT                  NUMBER := 0;
  BEGIN

    -- Retrieve Table Name for the given: PI_TABLES_ID
    SELECT T.TABLES_PHYSICAL_NAME
      INTO V_TABLE_NAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;

    -- a. calculate the number of indexes already present physically -- select count(*) from user_indexes ui where ui.table_name = V_TABLE_NAME; -- INTO V_EXISTING_INDEXES_COUNT
    select count(*)
      INTO V_EXISTING_INDEXES_COUNT
      from user_indexes ui
     where ui.table_name = V_TABLE_NAME;
    -- b. calculate the actual number of indexes to be CREATED physically from the ones which are requested ==  GET_NONCOVERABLE_INDEXES_COUNT   INTO V_NONCOVERABLE_INDEXES_COUNT
    V_NONCOVERABLE_INDEXES_COUNT := COMMONS_INDEXING.GET_NONCOVERABLE_INDEXES_COUNT(PI_TABLE_NAME          => V_TABLE_NAME,
                                                                                    PI_CREATE_INDEX_OBJECT => PI_CREATE_INDEX_OBJECT);
    -- c. calculate the actual number of indexes to be DELETED physically from the ones which are requested  == GET_DELETABLE_INDEXES_COUNT  INTO V_DELETABLE_INDEXES_COUNT
    V_DELETABLE_INDEXES_COUNT := COMMONS_INDEXING.GET_DELETABLE_INDEXES_COUNT(PI_TABLE_NAME          => V_TABLE_NAME,
                                                                              PI_DELETE_INDEX_OBJECT => PI_DELETE_INDEX_OBJECT);
    -- d. calculate final number of indexes to be present if request is successful as:    V_PROPOSED_TOTAL_INDEXES_COUNT = V_EXISTING_INDEXES_COUNT + V_NONCOVERABLE_INDEXES_COUNT - V_DELETABLE_INDEXES_COUNT
    V_PROPOSED_TOTAL_INDEXES_COUNT := V_EXISTING_INDEXES_COUNT +
                                      V_NONCOVERABLE_INDEXES_COUNT -
                                      V_DELETABLE_INDEXES_COUNT;
    -- e. retrieve the maximum proposed indexes from the PROPERTIES table === SELECT PR_VALUE FROM PROPERTIES WHERE PR_NAME = 'INDEXING_LIMIT';   -- INTO V_INDEX_LIMIT
    SELECT PR_VALUE
      INTO V_INDEX_LIMIT
      FROM PROPERTIES
     WHERE PR_NAME = 'INDEXING_LIMIT';
    -- f. Warning is TRUE(1) if: V_PROPOSED_TOTAL_INDEXES_COUNT > V_INDEX_LIMIT, else warning is FALSE (0).
    V_INDEX_LIMIT_WARNING_STATUS := CASE
                                      WHEN V_PROPOSED_TOTAL_INDEXES_COUNT >
                                           V_INDEX_LIMIT THEN
                                       1
                                      ELSE
                                       0
                                    END;

    RETURN V_INDEX_LIMIT_WARNING_STATUS;
  END IS_INDEX_LIMIT_EXCEEDING;
  -- OF-27498 - END

  --OF-22882 - OF-26356 -- START
  PROCEDURE MODIFY_SPECIFIED_APP_INDEXES(PI_TABLES_ID             IN NUMBER,
                                         PI_PROCESS_ID            IN NUMBER DEFAULT NULL,
                                         PI_RUN_ID                IN NUMBER DEFAULT NULL,
                                         PI_IS_FORCE_INDEX_CREATE IN NUMBER DEFAULT 0,
                                         PI_CREATE_INDEX_OBJECT   IN COLTYPE_CREATE_INDEX,
                                         PI_DELETE_INDEX_OBJECT   IN COLTYPE_DELETE_INDEX,
                                         PO_SAVE_STATUS           OUT NUMBER -- 0 = Warning, 1 = Successfully Updated (Created and/or Dropped) the relevant App Indexes
                                         ) IS
    V_INDEX_LIMIT                NUMBER := 0;
    V_INDEX_CREATION_STATUS      NUMBER(1) := 0;
    V_TABLE_NAME                 VARCHAR2(30 CHAR) := NULL;
    V_EXISTING_INDEXES_COUNT     NUMBER := 0;
    V_TOTAL_COUNT                NUMBER := 0;
    V_INDEX_LIMIT_WARNING_STATUS NUMBER(1) := 0;
  BEGIN

    -- A. if PI_IS_FORCE_INDEX_CREATE = 0 then check for warning
    IF PI_IS_FORCE_INDEX_CREATE = 0 THEN
      -- Retrieve Table Name for the given: PI_TABLES_ID
      SELECT T.TABLES_PHYSICAL_NAME
        INTO V_TABLE_NAME
        FROM TABLES T
       WHERE T.TABLES_ID = PI_TABLES_ID;

      -- a. calculate the number of indexes already present physically
      select count(*)
        INTO V_EXISTING_INDEXES_COUNT
        from user_indexes ui
       where ui.table_name = V_TABLE_NAME;

      --b. sum of existing index count and input index request count
      V_TOTAL_COUNT := V_EXISTING_INDEXES_COUNT +
                       PI_CREATE_INDEX_OBJECT.count;

      --c. retrieve indexing limit from the PROPERTIES table
      SELECT PR_VALUE
        INTO V_INDEX_LIMIT
        FROM PROPERTIES
       WHERE PR_NAME = 'INDEXING_LIMIT';

      IF V_TOTAL_COUNT < V_INDEX_LIMIT THEN
        -- 1. calculate for the warning
        V_INDEX_LIMIT_WARNING_STATUS := IS_INDEX_LIMIT_EXCEEDING(PI_TABLES_ID           => PI_TABLES_ID,
                                                                 PI_PROCESS_ID          => PI_PROCESS_ID,
                                                                 PI_RUN_ID              => PI_RUN_ID,
                                                                 PI_CREATE_INDEX_OBJECT => PI_CREATE_INDEX_OBJECT,
                                                                 PI_DELETE_INDEX_OBJECT => PI_DELETE_INDEX_OBJECT);
      ELSE
        V_INDEX_LIMIT_WARNING_STATUS := 1;
      END IF;

      -- 2. Check warning status and act:
      -- a. If warning is true, i.e. V_INDEX_LIMIT_WARNING_STATUS=1, then set PO_SAVE_STATUS = 0 (i.e. Warning reached) and exit the procedure
      IF V_INDEX_LIMIT_WARNING_STATUS = 1 THEN
        PO_SAVE_STATUS := 0;
        RETURN;
      END IF; -- END IF_A_2
    END IF; -- END IF_A

    -- B. Delete and Create requested Indexes using DELETE_SPECIFIED_APP_INDEX and CREATE_SPECIFIED_APP_INDEX respectively.
    -- This will be done when: either the warning is false, i.e. f=0 OR PI_IS_FORCE_INDEX_CREATE = 1 (this will be implicitly handled by above IF-A, so no need to explicitly check them)
    -- 1. Loop through PI_DELETE_INDEX_OBJECT and call DELETE_SPECIFIED_APP_INDEX for each iteration
    /*FOR I IN 1 .. PI_DELETE_INDEX_OBJECT.COUNT LOOP
      COMMONS_INDEXING.DELETE_SPECIFIED_APP_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                                  PI_DEF_ID        => PI_DELETE_INDEX_OBJECT(I)
                                                                      .DEF_ID,
                                                  PI_BUSINESS_NAME => PI_DELETE_INDEX_OBJECT(I)
                                                                      .BUSINESS_NAME,
                                                  PI_PROCESS_ID    => PI_PROCESS_ID,
                                                  PI_RUN_ID        => PI_RUN_ID);
    END LOOP;*/

    IF PI_DELETE_INDEX_OBJECT.COUNT > 0 THEN
      COMMONS_INDEXING.COMBINED_DELETE_SPEC_APP_INDEX(PI_TABLES_ID           => PI_TABLES_ID,
                                                      PI_DELETE_INDEX_OBJECT => PI_DELETE_INDEX_OBJECT,
                                                      PI_PROCESS_ID          => PI_PROCESS_ID,
                                                      PI_RUN_ID              => PI_RUN_ID);
    END IF;

    -- 2. Loop through PI_CREATE_INDEX_OBJECT and call CREATE_SPECIFIED_APP_INDEX for each iteration
    FOR I IN 1 .. PI_CREATE_INDEX_OBJECT.COUNT LOOP
      COMMONS_INDEXING.CREATE_SPECIFIED_APP_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                                  PI_COLUMN_LIST                => PI_CREATE_INDEX_OBJECT(I)
                                                                                   .COLUMN_LIST,
                                                  PI_IS_UNIQUE                  => PI_CREATE_INDEX_OBJECT(I)
                                                                                   .IS_UNIQUE,
                                                  PI_DEF_ID                     => PI_CREATE_INDEX_OBJECT(I)
                                                                                   .DEF_ID,
                                                  PI_BUSINESS_NAME              => PI_CREATE_INDEX_OBJECT(I)
                                                                                   .BUSINESS_NAME,
                                                  PI_RECREATE_INDEX_ON_COL_DROP => PI_CREATE_INDEX_OBJECT(I)
                                                                                   .RECREATE_INDEX_ON_COL_DROP,
                                                  PI_PROCESS_ID                 => PI_PROCESS_ID,
                                                  PI_RUN_ID                     => PI_RUN_ID,
                                                  PO_INDEX_CREATION_STATUS      => V_INDEX_CREATION_STATUS);
    END LOOP;

    -- 3. Set PO_SAVE_STATUS = 1 (i.e. Successful) and exit
    PO_SAVE_STATUS := 1;
  END MODIFY_SPECIFIED_APP_INDEXES;
  --OF-22882 - OF-26356 -- END

  -- OF-27120 - START
  PROCEDURE CREATE_PRIMARY_KEY_INDEX(PI_TABLES_ID IN NUMBER,
                                     PI_RUN_ID    IN NUMBER DEFAULT NULL,
                                     PO_STATUS    OUT NUMBER,
                                     PO_LOG_MSG   OUT VARCHAR2) IS
    v_out                   NUMBER;
    V_TABLENAME             VARCHAR2(30 CHAR);
    V_INDEX_TABLESPACE_NAME VARCHAR2(30 CHAR);
    v_index_name_returned   VARCHAR2(30 CHAR);
    v_uniqueness_returned   VARCHAR2(9);
    v_create_index_ddl      CLOB;
    V_TRANSACTION_ID        VARCHAR2(30 CHAR);
  BEGIN
    PO_STATUS := 0; -- Set by default

    SELECT T.TABLES_PHYSICAL_NAME,
           COMMONS_INDEXING.GET_INDEX_TABLESPACE(PI_TABLES_ID)
      INTO V_TABLENAME, V_INDEX_TABLESPACE_NAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;

    V_TRANSACTION_ID := COMMONS_DDL_HANDLING.GET_TRANSACTION_ID;
    -- OF-33540
    COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => NULL,
                               PI_INDEX_NAME                 => 'PK_' ||
                                                                V_TABLENAME,
                               PI_TABLE_NAME                 => V_TABLENAME,
                               PI_COLUMN_LIST                => 'ROW_IDENTIFIER',
                               PI_RECREATE_INDEX_ON_COL_DROP => 1,
                               PI_BUSINESS_NAME              => 'CORE__PRIMARY_KEY',
                               PI_IS_UNIQUE                  => 1,
                               PI_INDEX_TYPE                 => 1,
                               PI_STATUS                     => 1);
    -- OF-30537 START
    COMMONS_INDEXING.CREATE_INDEX2(PI_TABLE_NAME        => V_TABLENAME,
                                   PI_INDEX_TABLESPACE  => V_INDEX_TABLESPACE_NAME,
                                   PI_INDEX_NAME        => 'PK_' ||
                                                           V_TABLENAME,
                                   PI_COLUMN_LIST       => SYS.HSBLKNAMLST('ROW_IDENTIFIER'),
                                   PI_UNIQUENESS        => 1,
                                   PI_COL_IS_PRIMARYKEY => 1,
                                   PI_TRANSACTION_ID    => V_TRANSACTION_ID,
                                   PI_RUN_ID            => PI_RUN_ID,
                                   PO_INDEX_STATUS      => v_out,
                                   PO_INDEX_NAME        => v_index_name_returned,
                                   PO_IS_UNIQUE         => v_uniqueness_returned,
                                   PO_CREATE_DDL        => v_create_index_ddl);
    -- OF-30537 END
    IF v_out = 1 THEN
      PO_LOG_MSG := 'INDEX ' || v_index_name_returned ||
                    ' created on column ''ROW_IDENTIFIER''';

      COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA1(PI_DEFINITION_ID              => NULL,
                                                    PI_INDEX_NAME                 => v_index_name_returned,
                                                    PI_TABLE_NAME                 => V_TABLENAME,
                                                    PI_COLUMN_LIST                => COLTYPE_INDEXED_COLUMNS_LIST('ROW_IDENTIFIER'),
                                                    PI_RECREATE_INDEX_ON_COL_DROP => 1,
                                                    PI_BUSINESS_NAME              => 'CORE__PRIMARY_KEY',
                                                    PI_IS_UNIQUE                  => 1,
                                                    PI_INDEX_TYPE                 => 1,
                                                    PI_INDEX_INSERT_DDL           => v_create_index_ddl,
                                                    PI_IS_PRIMARY                 => 1);

    ELSIF v_out = 2 THEN
      PO_LOG_MSG := 'INDEX ' || v_index_name_returned ||
                    ' already exists on column ''ROW_IDENTIFIER''';

      COMMONS_INDEXING.INSERT_APP_INDEXES_METADATA(PI_DEFINITION_ID              => NULL,
                                                   PI_INDEX_NAME                 => v_index_name_returned,
                                                   PI_TABLE_NAME                 => V_TABLENAME,
                                                   PI_COLUMN_LIST                => COLTYPE_INDEXED_COLUMNS_LIST('ROW_IDENTIFIER'),
                                                   PI_RECREATE_INDEX_ON_COL_DROP => 1,
                                                   PI_BUSINESS_NAME              => 'CORE__PRIMARY_KEY',
                                                   PI_IS_UNIQUE                  => 1,
                                                   PI_INDEX_TYPE                 => 1);
    END IF;
    -- OF-33540
    COMMONS_INDEXING.MERGE_AIR(PI_DEFINITION_ID              => NULL,
                               PI_INDEX_NAME                 => 'PK_' ||
                                                                V_TABLENAME,
                               PI_TABLE_NAME                 => V_TABLENAME,
                               PI_COLUMN_LIST                => 'ROW_IDENTIFIER',
                               PI_RECREATE_INDEX_ON_COL_DROP => 1,
                               PI_BUSINESS_NAME              => 'CORE__PRIMARY_KEY',
                               PI_IS_UNIQUE                  => 1,
                               PI_INDEX_TYPE                 => 1,
                               PI_STATUS                     => 2);
    if v_out in (1, 2) then
      PO_STATUS := 1;
    end if;

  END CREATE_PRIMARY_KEY_INDEX;
  -- OF-27120 - END

  -- OF-31450 START
  PROCEDURE GET_INDEX_DETAILS(PI_TABLE_NAME   IN VARCHAR2,
                              PI_COL_LIST     IN SYS.HSBLKNAMLST,
                              PO_INDEX_NAME   OUT VARCHAR2,
                              PO_INDEX_EXISTS OUT NUMBER,
                              PO_IS_UNIQUE    OUT VARCHAR2) AS
    V_INDEX_COLUMN_LIST VARCHAR2(1300 CHAR);
    V_AIM_COL_LIST      COLTYPE_INDEXED_COLUMNS_LIST := COLTYPE_INDEXED_COLUMNS_LIST();
    V_ASIM_COL_LIST     COLTYPE_INDEXED_COLUMNS_LIST1 := COLTYPE_INDEXED_COLUMNS_LIST1();
  BEGIN
    -- Initial Default Set the OUT parameters to be: PO_INDEX_NAME = NULL and PO_INDEX_EXISTS = 0

    SELECT LISTAGG(COLUMN_VALUE, ', ') WITHIN GROUP(ORDER BY ROWNUM)
      INTO V_INDEX_COLUMN_LIST
      FROM TABLE(PI_COL_LIST);
    -- INSERT_LOGS(' GET_INDEX_DETAILS --PI_TABLE_NAME='||PI_TABLE_NAME||'--V_INDEX_COLUMN_LIST='||V_INDEX_COLUMN_LIST);

    SELECT CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY ROWNUM) AS
                COLTYPE_INDEXED_COLUMNS_LIST) AIM_COL_LIST,
           CAST(COLLECT(CAST(COLUMN_VALUE AS VARCHAR2(30)) ORDER BY ROWNUM) AS
                COLTYPE_INDEXED_COLUMNS_LIST1) ASIM_COL_LIST
      INTO V_AIM_COL_LIST, V_ASIM_COL_LIST
      FROM TABLE(PI_COL_LIST);

    -- INSERT_LOGS('GET_INDEX_DETAILS--single quote -- V_INDEX_COLUMN_LIST='||V_INDEX_COLUMN_LIST);
    PO_INDEX_NAME   := NULL;
    PO_INDEX_EXISTS := 0;
    PO_IS_UNIQUE    := NULL;
    -- Initial Check: The Column list should not be empty.
    -- INSERT_LOGS('PI_COL_LIST.count = ' || PI_COL_LIST.count);
    IF PI_COL_LIST.count > 0 THEN
      -- INSERT_LOGS('IF PI_COL_LIST.count > 0 THEN');
      -- Part A. Check in optymyze Indexing Metadata for the Index name
      -- 1. Call GET_INDEX_DETAILS_I_META
      GET_INDEX_DETAILS_I_META(PI_AIM_COL_LIST  => V_AIM_COL_LIST,
                               PI_ASIM_COL_LIST => V_ASIM_COL_LIST,
                               PI_TABLE_NAME    => PI_TABLE_NAME,
                               PO_INDEX_NAME    => PO_INDEX_NAME,
                               PO_INDEX_EXISTS  => PO_INDEX_EXISTS,
                               PO_IS_UNIQUE     => PO_IS_UNIQUE);
      -- 2. Check GET_INDEX_DETAILS_I_META.PO_INDEX_EXISTS
      --  -- a. If = 1 (i.e. TRUE) then return the control with the OUT parameters
      IF PO_INDEX_EXISTS = 0 THEN
        -- Part B: Call get_already_present_index_name and return the control with the OUT parameters
        PO_INDEX_NAME := get_already_present_index_name(pi_table_name => PI_TABLE_NAME,
                                                        pi_col_list   => V_INDEX_COLUMN_LIST);
        IF PO_INDEX_NAME IS NOT NULL THEN
          SELECT UNIQUENESS
            INTO PO_IS_UNIQUE
            FROM USER_INDEXES
           WHERE INDEX_NAME = PO_INDEX_NAME;

          PO_INDEX_EXISTS := 1;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      PO_INDEX_NAME   := NULL;
      PO_INDEX_EXISTS := 0;
      PO_IS_UNIQUE    := NULL;

  END GET_INDEX_DETAILS;

  -- OF-31450 START
  PROCEDURE GET_INDEX_NAME(PI_TABLE_NAME   IN VARCHAR2,
                           PI_COL_LIST     IN SYS.HSBLKNAMLST,
                           PO_INDEX_NAME   OUT VARCHAR2,
                           PO_INDEX_EXISTS OUT NUMBER) AS
    V_IS_UNIQUE VARCHAR2(100 CHAR);
  BEGIN

    COMMONS_INDEXING.GET_INDEX_DETAILS(PI_TABLE_NAME   => PI_TABLE_NAME,
                                       PI_COL_LIST     => PI_COL_LIST,
                                       PO_INDEX_NAME   => PO_INDEX_NAME,
                                       PO_INDEX_EXISTS => PO_INDEX_EXISTS,
                                       PO_IS_UNIQUE    => V_IS_UNIQUE);

  END GET_INDEX_NAME;

  PROCEDURE CREATE_USAGE_INDEX(PI_TABLES_ID                  IN NUMBER,
                               PI_COLUMN_LIST                IN TABLETYPE_CHARMAX,
                               PI_IS_UNIQUE                  IN NUMBER,
                               PI_DEF_ID                     IN NUMBER,
                               PI_BUSINESS_NAME              IN VARCHAR2,
                               PI_INDEX_CREATION_LOGIC_FLAG  IN NUMBER,
                               PI_RECREATE_INDEX_ON_COL_DROP IN NUMBER,
                               PO_INDEX_CREATION_STATUS      OUT NUMBER,
                               PO_INDEX_NAME_RETURNED        OUT VARCHAR2) AS

  BEGIN

    IF PI_INDEX_CREATION_LOGIC_FLAG = 0 THEN
      COMMONS_INDEXING.CREATE_REQUESTED_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                              PI_COLUMN_LIST                => PI_COLUMN_LIST,
                                              PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                              PI_DEF_ID                     => PI_DEF_ID,
                                              PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                              PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                              PI_INDEX_TYPE                 => 4,
                                              PI_PROCESS_ID                 => NULL,
                                              PI_RUN_ID                     => NULL,
                                              PO_INDEX_CREATION_STATUS      => PO_INDEX_CREATION_STATUS,
                                              PO_INDEX_NAME_RETURNED        => PO_INDEX_NAME_RETURNED);
    ELSIF PI_INDEX_CREATION_LOGIC_FLAG = 1 THEN
      COMMONS_INDEXING.CREATE_USAGE_APP_INDEX(PI_TABLES_ID                  => PI_TABLES_ID,
                                              PI_COLUMN_LIST                => PI_COLUMN_LIST,
                                              PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                              PI_DEF_ID                     => PI_DEF_ID,
                                              PI_BUSINESS_NAME              => PI_BUSINESS_NAME,
                                              PI_RECREATE_INDEX_ON_COL_DROP => PI_RECREATE_INDEX_ON_COL_DROP,
                                              PI_INDEX_TYPE                 => 4,
                                              PI_PROCESS_ID                 => NULL,
                                              PI_RUN_ID                     => NULL,
                                              PO_INDEX_CREATION_STATUS      => PO_INDEX_CREATION_STATUS,
                                              PO_INDEX_NAME_RETURNED        => PO_INDEX_NAME_RETURNED);
    END IF;
  END CREATE_USAGE_INDEX;
  PROCEDURE CREATE_DBA_INDEX(PI_TABLES_NAME           IN VARCHAR2,
                             PI_COLUMN_LIST           IN TABLETYPE_CHARMAX,
                             PI_IS_UNIQUE             IN NUMBER,
                             PO_INDEX_CREATION_STATUS OUT NUMBER,
                             PO_INDEX_NAME_RETURNED   OUT VARCHAR2) AS
    V_TABLES_ID     NUMBER(10);
    V_DEF_ID        NUMBER(10);
    V_BUSINESS_NAME VARCHAR2(60 CHAR);
  BEGIN
    V_DEF_ID        := DID_SEQ.NEXTVAL;
    V_BUSINESS_NAME := 'DBI_' || V_DEF_ID;

    SELECT T.TABLES_ID
      INTO V_TABLES_ID
      FROM TABLES T
     WHERE T.TABLES_PHYSICAL_NAME = PI_TABLES_NAME;
    IF V_TABLES_ID IS NOT NULL THEN
      COMMONS_INDEXING.CREATE_REQUESTED_INDEX(PI_TABLES_ID                  => V_TABLES_ID,
                                              PI_COLUMN_LIST                => PI_COLUMN_LIST,
                                              PI_IS_UNIQUE                  => PI_IS_UNIQUE,
                                              PI_DEF_ID                     => V_DEF_ID,
                                              PI_BUSINESS_NAME              => V_BUSINESS_NAME,
                                              PI_RECREATE_INDEX_ON_COL_DROP => 1,
                                              PI_INDEX_TYPE                 => 3,
                                              PI_PROCESS_ID                 => NULL,
                                              PI_RUN_ID                     => NULL,
                                              PO_INDEX_CREATION_STATUS      => PO_INDEX_CREATION_STATUS,
                                              PO_INDEX_NAME_RETURNED        => PO_INDEX_NAME_RETURNED);
    END IF;
  END CREATE_DBA_INDEX;
  PROCEDURE DELETE_USAGE_INDEX(PI_TABLES_ID     IN NUMBER,
                               PI_DEF_ID        IN NUMBER,
                               PI_BUSINESS_NAME IN VARCHAR2) AS
    FLAG        NUMBER(1);
    V_TABLENAME VARCHAR2(30 CHAR);
  BEGIN

    --Get Table name
    SELECT T.TABLES_PHYSICAL_NAME
      INTO V_TABLENAME
      FROM TABLES T
     WHERE T.TABLES_ID = PI_TABLES_ID;
    FLAG := 0;
    BEGIN
      SELECT 1
        INTO FLAG
        FROM APP_SPECIFIC_INDEXES_METADATA ASIM
       WHERE ASIM.ASIM_DEF_ID = PI_DEF_ID
         AND ASIM.ASIM_TABLE_NAME = V_TABLENAME
         AND ASIM.ASIM_BUSINESS_NAME = PI_BUSINESS_NAME;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
    IF FLAG = 1 THEN
      COMMONS_INDEXING.DELETE_REQUESTED_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                              PI_DEF_ID        => PI_DEF_ID,
                                              PI_BUSINESS_NAME => PI_BUSINESS_NAME,
                                              PI_PROCESS_ID    => NULL,
                                              PI_RUN_ID        => NULL);
    ELSE
      COMMONS_INDEXING.DELETE_USAGE_APP_INDEX(PI_TABLES_ID     => PI_TABLES_ID,
                                              PI_DEF_ID        => PI_DEF_ID,
                                              PI_BUSINESS_NAME => PI_BUSINESS_NAME,
                                              PI_PROCESS_ID    => NULL,
                                              PI_RUN_ID        => NULL);
    END IF;
  END DELETE_USAGE_INDEX;
  PROCEDURE DELETE_DBA_INDEX(PI_TABLES_NAME IN VARCHAR2,
                             PI_INDEX_NAME  IN VARCHAR2) AS
    V_TABLES_ID     NUMBER(10);
    V_FLAG          NUMBER(1);
    V_DEF_ID        NUMBER(10);
    V_BUSINESS_NAME VARCHAR2(60 CHAR);
  BEGIN
    V_FLAG := 0;
    SELECT T.TABLES_ID
      INTO V_TABLES_ID
      FROM TABLES T
     WHERE T.TABLES_PHYSICAL_NAME = PI_TABLES_NAME;
    BEGIN
      SELECT ASIM_DEF_ID, ASIM_BUSINESS_NAME, 1
        INTO V_DEF_ID, V_BUSINESS_NAME, V_FLAG
        FROM APP_SPECIFIC_INDEXES_METADATA
       WHERE ASIM_TABLE_NAME = PI_TABLES_NAME
         AND ASIM_INDEX_NAME = PI_INDEX_NAME;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
    IF V_FLAG = 1 THEN
      COMMONS_INDEXING.DELETE_REQUESTED_INDEX(PI_TABLES_ID     => V_TABLES_ID,
                                              PI_DEF_ID        => V_DEF_ID,
                                              PI_BUSINESS_NAME => V_BUSINESS_NAME,
                                              PI_PROCESS_ID    => NULL,
                                              PI_RUN_ID        => NULL);
      /*ELSE
      BEGIN
        SELECT AIM_DEF_ID,AIM_BUSINESS_NAME,2 INTO V_DEF_ID,V_BUSINESS_NAME,V_FLAG FROM APPLICATION_INDEXES_METADATA WHERE AIM_TABLE_NAME=PI_TABLES_NAME AND AIM_INDEX_NAME=PI_INDEX_NAME;
          EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
      END;
      IF V_FLAG=2
      THEN
            COMMONS_INDEXING.DELETE_USAGE_APP_INDEX
          (
            PI_TABLES_ID      =>V_TABLES_ID,
            PI_DEF_ID         =>PI_DEF_ID,
            PI_BUSINESS_NAME  =>PI_BUSINESS_NAME,
            PI_PROCESS_ID     =>NULL,
            PI_RUN_ID         =>NULL
          );
      END IF;*/
    END IF;

  END DELETE_DBA_INDEX;

  FUNCTION CORE_COLS_MINUS_INDEX_COLS(pi_tables_id                 IN NUMBER,
                                      PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX, --sales change
                                      pi_table_name                IN VARCHAR2)
    RETURN NUMBER IS
    v_count NUMBER(1) := 0;
  BEGIN
    SELECT COUNT(*)
      INTO v_count
      FROM dual
     WHERE EXISTS (SELECT *
              from (SELECT listagg(CASE
                                     WHEN picc.OCTI_FLD_DATA_TYPE = 1 THEN
                                      'UPPER("' || picc.OCTI_TC_PHYSICAL_NAME || '")'
                                     ELSE
                                      picc.OCTI_TC_PHYSICAL_NAME
                                   END,
                                   ',') within GROUP(ORDER BY picc.OCTI_TC_ORDER) AS col_list
                      FROM TABLE(PI_INDEX_CREATION_COLLECTION) picc
                     WHERE --tc1.tc_tables_id = pi_tables_id
                     picc.OCTI_TC_LOGIC_TYPE IN (1, 3, 5, 6, 9, 8)
                    UNION
                    SELECT picc1.OCTI_TC_PHYSICAL_NAME
                      FROM TABLE(PI_INDEX_CREATION_COLLECTION) picc1
                     WHERE --tc.tc_tables_id = pi_tables_id
                     (picc1.OCTI_TC_COLUMN_TYPE = 1 OR
                     picc1.OCTI_TC_LOGIC_TYPE IN (6, 7, 8, 9) OR
                     picc1.OCTI_TC_PHYSICAL_NAME IN
                     ('E_INTERNAL_ID', 'ROW_IDENTIFIER')))
            MINUS (SELECT listagg(CASE
                                   WHEN uie.column_expression IS NULL THEN
                                    uic.column_name
                                   ELSE
                                    commons_tables.index_column_expression_char(uie.TABLE_NAME,
                                                                                uie.index_name,
                                                                                uie.column_position)
                                 END,
                                 ',') within GROUP(ORDER BY uic.column_position) col_name
                    FROM user_ind_columns uic
                    LEFT OUTER JOIN user_ind_expressions uie
                      ON (uic.TABLE_NAME = uie.TABLE_NAME AND
                         uic.index_name = uie.index_name AND
                         uic.column_position = uie.column_position)
                   WHERE uic.TABLE_NAME = pi_table_name
                   GROUP BY uic.index_name));

    RETURN v_count;
  END CORE_COLS_MINUS_INDEX_COLS;

  FUNCTION INDEX_COLS_MINUS_CORE_COLS(pi_tables_id                 IN NUMBER,
                                      PI_INDEX_CREATION_COLLECTION IN COLTYPE_COLS_TO_INDEX, --sales change
                                      pi_table_name                IN VARCHAR2)
    RETURN NUMBER IS
    v_col_count NUMBER(1) := 0;
  BEGIN
    SELECT COUNT(*)
      INTO v_col_count
      FROM dual
     WHERE EXISTS (SELECT *
              from (SELECT listagg(CASE
                                     WHEN uie.column_expression IS NULL THEN
                                      uic.column_name
                                     ELSE
                                      commons_tables.index_column_expression_char(uie.TABLE_NAME,
                                                                                  uie.index_name,
                                                                                  uie.column_position)
                                   END,
                                   ',') within GROUP(ORDER BY uic.column_position) col_name
                      FROM user_ind_columns uic
                      LEFT OUTER JOIN user_ind_expressions uie
                        ON (uic.TABLE_NAME = uie.TABLE_NAME AND
                           uic.index_name = uie.index_name AND
                           uic.column_position = uie.column_position)
                     WHERE uic.TABLE_NAME = pi_table_name
                       and uic.index_name NOT LIKE 'APP%'
                     GROUP BY uic.index_name)
            MINUS
            SELECT *
              from (SELECT listagg(CASE
                                     WHEN picc.OCTI_FLD_DATA_TYPE = 1 THEN
                                      'UPPER("' || picc.OCTI_TC_PHYSICAL_NAME || '")'
                                     ELSE
                                      picc.OCTI_TC_PHYSICAL_NAME
                                   END,
                                   ',') within GROUP(ORDER BY picc.OCTI_TC_ORDER) AS col_list
                      FROM TABLE(PI_INDEX_CREATION_COLLECTION) picc
                     WHERE --tc1.tc_tables_id = pi_tables_id
                     picc.OCTI_TC_LOGIC_TYPE IN (1, 3, 5, 6, 9, 8)
                    UNION
                    SELECT picc1.OCTI_TC_PHYSICAL_NAME
                      FROM TABLE(PI_INDEX_CREATION_COLLECTION) picc1
                     WHERE --tc.tc_tables_id = pi_tables_id
                     (picc1.OCTI_TC_COLUMN_TYPE = 1 OR
                     picc1.OCTI_TC_LOGIC_TYPE IN (6, 7, 8, 9) OR
                     picc1.OCTI_TC_PHYSICAL_NAME IN
                     ('E_INTERNAL_ID', 'ROW_IDENTIFIER'))));

    RETURN v_col_count;
  END INDEX_COLS_MINUS_CORE_COLS;

  FUNCTION APP_COL_MINUS_INDEX_COL(pi_table_name IN VARCHAR2) RETURN NUMBER IS
    v_app_ind_minus_user_ind_cnt NUMBER(1) := 0;
    v_col                        varchar2(2000);
  BEGIN

    SELECT COUNT(1)
      INTO v_app_ind_minus_user_ind_cnt
      FROM dual
     WHERE EXISTS(WITH app_column_list AS (SELECT upper((SELECT listagg(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(column_value,
                                                                                                         ' ',
                                                                                                         ''), --space removed
                                                                                                 '''',
                                                                                                 ''), --single quotes removed
                                                                                         '"',
                                                                                         ''), --double quotes removed
                                                                                 '(',
                                                                                 ''), --opening bracket removed
                                                                         ')',
                                                                         ''), --closing bracket removed
                                                                 ',') within GROUP(ORDER BY rownum) col_name
                                                    FROM TABLE(asim_indexed_columns))) col_name
                                       FROM app_specific_indexes_metadata
                                      WHERE asim_table_name =
                                            pi_table_name), oracle_column_list AS (SELECT upper(listagg(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(col_list,
                                                                                                                                                ' ',
                                                                                                                                                ''), --space removed
                                                                                                                                        '''',
                                                                                                                                        ''), --single quotes removed
                                                                                                                                '"',
                                                                                                                                ''), ----double quotes removed
                                                                                                                        '(',
                                                                                                                        ''), --opening bracket removed
                                                                                                                ')',
                                                                                                                ''), --closing bracket removed
                                                                                                        ',')
                                                                                                within
                                                                                                GROUP(ORDER BY
                                                                                                      column_position)) AS col_list
                                                                                     FROM (SELECT CASE
                                                                                                    WHEN uie.column_expression IS NULL THEN
                                                                                                     uic.column_name
                                                                                                    ELSE
                                                                                                     commons_tables.index_column_expression_char(uie.TABLE_NAME,
                                                                                                                                                 uie.index_name,
                                                                                                                                                 uie.column_position)
                                                                                                  END col_list,
                                                                                                  uic.index_name,
                                                                                                  uie.column_position
                                                                                             FROM user_ind_columns uic
                                                                                             LEFT OUTER JOIN user_ind_expressions uie
                                                                                               ON (uic.TABLE_NAME =
                                                                                                  uie.TABLE_NAME AND
                                                                                                  uic.index_name =
                                                                                                  uie.index_name AND
                                                                                                  uic.column_position =
                                                                                                  uie.column_position)
                                                                                            WHERE uic.TABLE_NAME =
                                                                                                  pi_table_name) inner_query
                                                                                    GROUP BY inner_query.index_name), res_cols AS (SELECT col_name
                                                                                                                                     FROM app_column_list
                                                                                                                                   minus
                                                                                                                                   SELECT col_list col_name
                                                                                                                                     FROM oracle_column_list)
       SELECT col_name
         FROM res_cols
         LEFT OUTER JOIN oracle_column_list
           ON regexp_instr(col_list, col_name) = 1
        WHERE col_list IS NULL);


    RETURN v_app_ind_minus_user_ind_cnt;

  END APP_COL_MINUS_INDEX_COL;

  FUNCTION INDEX_COL_MINUS_APP_COL(pi_table_name IN VARCHAR2) RETURN NUMBER IS
    v_ind_minus_app_ind_cnt NUMBER(1) := 0;
    v_col                   varchar2(2000);
  BEGIN

    SELECT COUNT(1)
      INTO v_ind_minus_app_ind_cnt
      FROM dual
     WHERE EXISTS((SELECT listagg(col_name, ',') within GROUP(ORDER BY column_position) AS col_list
                     FROM (SELECT CASE
                                    WHEN uie.column_expression IS NULL THEN
                                     uic.column_name
                                    ELSE
                                     commons_tables.index_column_expression_char(uie.TABLE_NAME,
                                                                                 uie.index_name,
                                                                                 uie.column_position)
                                  END col_name,
                                  uic.index_name,
                                  uie.column_position
                             FROM user_ind_columns uic
                             LEFT OUTER JOIN user_ind_expressions uie
                               ON (uic.TABLE_NAME = uie.TABLE_NAME AND
                                  uic.index_name = uie.index_name AND
                                  uic.column_position = uie.column_position)
                            WHERE uic.TABLE_NAME = pi_table_name
                              and uic.index_name like 'APP%') inner_query
                    GROUP BY inner_query.index_name) MINUS
                  (SELECT (SELECT listagg(column_value, ',') within GROUP(ORDER BY rownum) col_name
                             FROM TABLE(asim_indexed_columns)) col_name
                     FROM app_specific_indexes_metadata
                    WHERE asim_table_name = pi_table_name));
    RETURN v_ind_minus_app_ind_cnt;

  END INDEX_COL_MINUS_APP_COL;

  /* ********************************************************************************************************
  * TYPE              : FUNCTION
  * PROCEDURE NAME    : GET_DEF_APP_INDEX
  * AUTHOR            : Hardika Bhate
  * REVIEWER          : Pimparkar Shriniket
  * INPUT PARAMETERS  : pi_def_id
  * OUTPUT PARAMETERS : po_app_index
  * DESCRIPTION       : A new bulk method in IndexingService needed for Data Views indexes
  * Example           :

    DECLARE
     c SYS_REFCURSOR;
     v1 APP_SPECIFIC_INDEXES_METADATA.asim_business_name%TYPE;
     v2 APP_SPECIFIC_INDEXES_METADATA.asim_table_name%TYPE;
    BEGIN
     c := commons_indexing.GET_DEF_APP_INDEX(5717505);   -- Get ref cursor from function
     LOOP
       FETCH c into v1,v2;
       EXIT WHEN c%NOTFOUND;
       dbms_output.put_line('Value from cursor: '||v1||' '||v2);
     END LOOP;
    END;

  **********************************************************************************************************/

  FUNCTION GET_DEF_APP_INDEX(pi_def_id IN NUMBER) RETURN sys_refcursor is
    po_app_index sys_refcursor;
  BEGIN
    OPEN po_app_index for
      select asim_business_name, asim_table_name
        FROM APP_SPECIFIC_INDEXES_METADATA
       where asim_def_id = pi_def_id
         AND exists
       (Select 1
                from Tables
               where tables_physical_name = asim_table_name);

    return po_app_index;
  END GET_DEF_APP_INDEX;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END COMMONS_INDEXING;
/
