CREATE PACKAGE BODY REPORTS_GET_DATA AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product      : reportrepositorymanagement
  -- Module      : reportsourcetables
  -- Requester    : Budau, Marius
  -- Author      : Lazarescu, Bogdan
  -- Reviewer   :
  -- Review date    :
  -- Description    :
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************
  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

  PROCEDURE EXPOSE_DATA_FROM_FILE(pin_report_schema varchar2
    , pin_table_name varchar2
    , pin_table_type varchar2) AS

    v_sql_current_schema VARCHAR2(30);
    v_sql_create_view    CLOB;
    v_sql_joins    CLOB;
    v_sql_flds_from_entity    CLOB;
  BEGIN

    v_sql_current_schema := sys_context('userenv', 'current_schema');

    --get data
    FOR c IN (
                  SELECT
                     T.TABLES_ID
                    ,T.TABLES_PHYSICAL_NAME AS table_physical_name
                    ,DEF.DEF_NAME AS TABLE_BUSINESS_NAME
                  FROM
                    TABLES T
                    LEFT JOIN
                    (  -- DATA_TABLES
                      SELECT 'DATA_TABLE' DEF_TYPE, DT_ID DEF_ID, DT_NAME DEF_NAME, DT_FOL_ID DEF_CONTAINER, NULL TABLE_DESC, DT_TABLES_ID TABLE_ID
                      FROM DATA_TABLES
                      WHERE DT_TABLES_ID IS NOT NULL
                      -- ENTITIES
                      UNION ALL
                      SELECT 'ENTITY', ENTITY_ID, ENTITY_NAME, NULL, NULL, ENTITY_TABLES_ID
                      FROM ENTITIES
                      WHERE ENTITY_TABLES_ID IS NOT NULL
                      -- ENTITY_ASSIGNMENTS
                      UNION ALL
                      SELECT 'ENTITY_ASSIGNMENT', EA_ID, EA_NAME, EA_FOL_ID, NULL, EA_TABLES_ID
                      FROM ENTITY_ASSIGNMENTS
                      WHERE EA_TABLES_ID IS NOT NULL
                    ) DEF ON T.TABLES_ID = DEF.TABLE_ID
                  WHERE DEF_TYPE = TRIM(pin_table_type)
                        AND DEF_NAME = TRIM(pin_table_name)
                        )

     LOOP

      --list of exposed tables
      L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Exposing table: ' || REPLACE(UPPER(c.TABLE_BUSINESS_NAME), ' ', '_'));

      --grant read rights for exposed tables
      EXECUTE IMMEDIATE ' GRANT SELECT ON ' || c.table_physical_name ||
                        ' TO ' || pin_report_schema;

      v_sql_create_view := ' CREATE OR REPLACE VIEW "' ||
                           REPLACE(UPPER(c.TABLE_BUSINESS_NAME), ' ', '_') || '"' || CHR(13) ||
                           ' AS ' || ' SELECT ';

      --get associated entities if exists
      v_sql_joins := '';
      v_sql_flds_from_entity := '';
      for ent in (select T.TABLES_PHYSICAL_NAME AS TABLE_PHYSICAL_NAME, TC.TC_PHYSICAL_NAME AS TABLE_FIELD_NAME, E.entity_id
                  FROM table_columns TC
                      INNER JOIN entities E ON TC.TC_ENTITY_ID = E.entity_id
                      INNER JOIN TABLES T ON E.entity_tables_id = T.TABLES_ID
                  WHERE TC.TC_TABLES_ID = c.TABLES_ID) LOOP

                  --grant read rights for exposed tables
                  EXECUTE IMMEDIATE ' GRANT SELECT ON ' || ent.TABLE_PHYSICAL_NAME ||
                                    ' TO ' || pin_report_schema;

                  v_sql_joins := v_sql_joins || ' INNER JOIN ' || v_sql_current_schema || '.' || ent.TABLE_PHYSICAL_NAME || ' ON ' || c.table_physical_name || '.' || ent.TABLE_FIELD_NAME || ' = ' || ent.TABLE_PHYSICAL_NAME || '.E_INTERNAL_ID ';


                  for ent_fld in (select f.fld_column_name, f.fld_business_name
                                 from entity_display_field EDF
                                      INNER JOIN fields f on edf.edf_fld_id = f.fld_id
                                 where edf.edf_entity_id = ent.entity_id) LOOP

                                 v_sql_flds_from_entity := v_sql_flds_from_entity || ',' || ent.TABLE_PHYSICAL_NAME || '.' || ent_fld.fld_column_name || ' AS ' || '"' || REPLACE(UPPER(ent_fld.fld_business_name), ' ', '_') || '"';

                  end loop;

      END LOOP;

      for f in (SELECT F.FLD_BUSINESS_NAME, F.FLD_COLUMN_NAME
                FROM table_columns TC
                 INNER JOIN FIELDS F ON TC.TC_FLD_ID = F.FLD_ID
                 WHERE TC.TC_TABLES_ID = c.TABLES_ID
                 ORDER BY TC_ORDER) LOOP

       v_sql_create_view := v_sql_create_view || CHR(13) ||
                            c.table_physical_name || '.' || f.FLD_COLUMN_NAME || ' AS ' ||
                             '"' || REPLACE(UPPER(f.FLD_BUSINESS_NAME), ' ', '_') || '"' || ',';

      END LOOP;

      v_sql_create_view := substr(v_sql_create_view,
                                  1,
                                  length(v_sql_create_view) - 1)
                            || v_sql_flds_from_entity;

      v_sql_create_view := v_sql_create_view || CHR(13) || ' FROM ' ||
                           v_sql_current_schema || '.' ||
                           c.TABLE_PHYSICAL_NAME || v_sql_joins ;

--      DBMS_OUTPUT.PUT_LINE(v_sql_create_view);

      EXECUTE IMMEDIATE 'begin ' || pin_report_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql_create_view ||
                        '''); end;';

  END LOOP;

  END EXPOSE_DATA_FROM_FILE;


PROCEDURE EXPOSE_DATA_FROM_REPORTSOURCE
  (
  pin_report_schema varchar2
   , pin_view_name varchar2
   , pin_query clob
   , pin_partner_schema INTEGER DEFAULT 0
  )
AS
v_sql_grant clob;
v_sql_current_schema clob;
v_sql_create_view clob;
v_sql_create_synonym clob;
BEGIN

  v_sql_current_schema := sys_context('userenv', 'current_schema');

  -- Create view only for the RDS SCHEMA
  IF pin_partner_schema = 0 THEN
    --build create view statement
      v_sql_create_view := 'CREATE OR REPLACE VIEW "' || pin_view_name || '"
      AS ' || pin_query ;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_create_view),'v_sql_create_view := <value>', null);

    EXECUTE IMMEDIATE v_sql_create_view;
  END IF;

  BEGIN
    --grant select for datatable and involved entities/time_periods
    v_sql_grant := 'GRANT SELECT ON "' || pin_view_name || '" TO ' || pin_report_schema;
    EXECUTE IMMEDIATE v_sql_grant;

    v_sql_create_synonym := 'CREATE OR REPLACE SYNONYM "' || pin_view_name || '" FOR ' || v_sql_current_schema || '."' || pin_view_name || '"';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_create_synonym),'v_sql_create_synonym := <value>', null);
    EXECUTE IMMEDIATE 'begin ' || pin_report_schema ||
                          '.UTILS.CREATE_VIEW(''' || v_sql_create_synonym ||
                          '''); end;';
  EXCEPTION
    WHEN OTHERS THEN
      IF pin_partner_schema = 1 THEN
        raise_application_error(-20001,'Could not add privileges or create synonym for partner schema due to: ' || SQLERRM);
      ELSE
        RAISE;
      END IF;
  END;

END EXPOSE_DATA_FROM_REPORTSOURCE;


PROCEDURE DROP_DATA_FROM_REPORTSOURCE
  (
  pin_report_schema varchar2
   , pin_view_name varchar2
  )
AS
v_sql clob;
BEGIN


--build drop synonym statement
  v_sql := '
        BEGIN
          FOR c IN (SELECT 1 FROM user_synonyms WHERE synonym_name  = ''''' || replace(pin_view_name, '''', '''''''''') || ''''') LOOP
          EXECUTE IMMEDIATE ''''DROP SYNONYM "' || replace(pin_view_name, '''', '''''''''') || '"'''';
          END LOOP;
        END;
    ';
--DBMS_OUTPUT.PUT_LINE(v_sql);

--execute drop view over report schema
EXECUTE IMMEDIATE 'begin ' || pin_report_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql ||
                        '''); end;';

--drop view
  for c in (select 1 from user_views where view_name = pin_view_name) LOOP
    EXECUTE IMMEDIATE 'DROP VIEW "' || pin_view_name || '"';
  END LOOP;

END DROP_DATA_FROM_REPORTSOURCE;


PROCEDURE CREATE_ROLES
    (
  pin_ahmtd_schema varchar2
   , pin_roles_list TABLETYPE_RD_ROLE
  )
AS
v_sql clob;
BEGIN

  FOR i IN (SELECT NAME FROM TABLE(pin_roles_list)) LOOP
  v_sql := '

declare v_ROLEID NUMBER;
        v_ROLENAME VARCHAR2(30);
        v_DATABASE_ID NUMBER;

BEGIN

  v_ROLENAME := ''''' || i.NAME || ''''';

  --catch no data exception
  select databaseid INTO v_database_id from sourcedatabase where ROWNUM = 1;

  FOR c in (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ROLE WHERE ROLENAME = v_ROLENAME)) LOOP

      v_ROLEID := ROLE_ROLEID_SEQ.NEXTVAL;

    INSERT INTO ROLE(ROLEID, ROLENAME, DESCRIPTION) VALUES (v_ROLEID, v_ROLENAME, NULL);
    INSERT INTO databaserole (databaseroleid, databaseid, roleid) VALUES(databaserole_databaseroleid_se.nextval, v_database_id, v_ROLEID);
    --permissionid is set to 2 - "End User"
    INSERT INTO rolepermissions (rolepermissionid, roleid, permissionid) VALUES (rolepermissions_rolepermission.nextval, v_ROLEID, 2);
    --groupid is set to 1 - "Default"
    INSERT INTO usergrouproles (usergrouproleid, groupid, roleid) values (usergrouproles_usergrouproleid.nextval, 1, v_ROLEID);

    --add data to roleobjects to register current role for no permissions
    INSERT INTO roleobjects (roleid, objectid, accesstype)
    SELECT v_ROLEID, objectid, 0
    FROM objects
    WHERE databaseid = v_database_id;

  END LOOP;

END;
';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
  EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql ||
                        '''); end;';

  END LOOP;

END CREATE_ROLES;


PROCEDURE DELETE_ROLES
    (
  pin_ahmtd_schema varchar2
   , pin_roles_list TABLETYPE_RD_ROLE
  )
AS
v_sql clob;
BEGIN

  FOR i IN (SELECT NAME FROM TABLE(pin_roles_list)) LOOP
  v_sql := '

declare v_ROLEID NUMBER;
        v_ROLENAME VARCHAR2(30);

BEGIN

  v_ROLENAME := ''''' || i.NAME || ''''';

  FOR c in (SELECT 1 FROM ROLE WHERE ROLENAME = v_ROLENAME) LOOP

    SELECT ROLEID INTO v_ROLEID FROM ROLE WHERE ROLENAME = v_ROLENAME;

    DELETE FROM usergrouproles WHERE roleid = v_ROLEID;
    DELETE FROM rolepermissions WHERE roleid = v_ROLEID;
    DELETE FROM databaserole WHERE roleid = v_ROLEID;
    DELETE FROM roleobjects WHERE roleid = v_ROLEID;
    DELETE FROM ROLE WHERE roleid = v_ROLEID;

  END LOOP;

END;
';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
  EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql ||
                        '''); end;';

  END LOOP;

END DELETE_ROLES;

PROCEDURE ADD_OBJECT
  (
  pin_ahmtd_schema varchar2
  , pin_object_name varchar2
  , pin_column_list TABLETYPE_RD_FIELD
  )
AS
v_initial_sql CLOB;
v_declare_sql CLOB;
v_sql CLOB;
v_sql_current_schema varchar2(30);
BEGIN

  v_sql_current_schema := sys_context('userenv', 'current_schema');

-- the inserts that are run just one time at the beginning

v_initial_sql := 'DECLARE v_objects_objectid_seq number;
                  v_database_id number;
BEGIN
  v_objects_objectid_seq := objects_objectid_seq.nextval;

  --catch no data exception
  select databaseid INTO v_database_id from sourcedatabase where ROWNUM = 1;

FOR c in (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM objects WHERE objectname = ''' || pin_object_name || ''')) LOOP
    v_objects_objectid_seq := objects_objectid_seq.nextval;

    INSERT INTO objects(objectid, objectschema, objectname, objectalias, description, type, databaseid, definition, hideobject, explanationid, iscatalogue)
    values (v_objects_objectid_seq, ''' || v_sql_current_schema || ''', ''' || pin_object_name || ''', NULL, ''' || pin_object_name || ''', ''V'', v_database_id, NULL, 0, 0, 1);
END LOOP;

FOR c in (SELECT 1 FROM DUAL WHERE EXISTS (SELECT 1 FROM objects WHERE objectname = ''' || pin_object_name || ''')) LOOP
    SELECT objectid into v_objects_objectid_seq FROM objects WHERE objectname = ''' || pin_object_name || ''';
END LOOP;



INSERT INTO roleobjects (roleid, objectid, accesstype)
SELECT ROLEID, v_objects_objectid_seq, 0
FROM role
WHERE NOT EXISTS (SELECT 1 FROM roleobjects WHERE objectid = v_objects_objectid_seq);

DELETE FROM columns where objectid = v_objects_objectid_seq;
';

      v_initial_sql := REPLACE(v_initial_sql, '''', '''''') || '
            END;';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_initial_sql),'v_sql := <value>', null);

  EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_initial_sql ||
                        '''); end;';

-- the declare part that is appended to each insert

v_declare_sql := 'DECLARE v_objects_objectid_seq number;

BEGIN
  v_objects_objectid_seq := objects_objectid_seq.nextval;

FOR c in (SELECT 1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM objects WHERE objectname = ''' || pin_object_name || ''')) LOOP
    v_objects_objectid_seq := objects_objectid_seq.nextval;
END LOOP;

FOR c in (SELECT 1 FROM DUAL WHERE EXISTS (SELECT 1 FROM objects WHERE objectname = ''' || pin_object_name || ''')) LOOP
    SELECT objectid into v_objects_objectid_seq FROM objects WHERE objectname = ''' || pin_object_name || ''';
END LOOP;

';

  -- the inserts run for each batch of 20 columns

  --CHARACTER(0), BOOLEAN(1), DATE(2), DATETIME(3), NOTE(4), NUMERIC(5), SERIES(6), PERIOD(7)
  FOR i IN (SELECT NAME, ORD, TYPE, LENGTH FROM TABLE(pin_column_list)) LOOP

      v_sql := v_declare_sql || '


      INSERT INTO columns (columnid, columnname, columnalias, description, columntype, objectid, ordinalposition, columnorder
             , datatype, charactermaxlen, numericprecision, numericscale
             , displayformat
             , alignment, nativedatatype, definition, explanationid, linkrptid, linkurl, frameid, hidecolumn)
      VALUES (columns_columnid_seq.nextval, ''' || i.NAME || ''', NULL, ''' || i.NAME || ''', ''D'', v_objects_objectid_seq, ' || to_char(i.ORD) || ', ' || to_char(i.ORD + 1) || '
             , ' || to_char(CASE WHEN i.TYPE IN (0, 4, 7) THEN 200 --character
                                 WHEN i.TYPE IN (1, 5, 6) THEN 131 --numeric
                                 WHEN i.TYPE = 2 THEN 135 --date
                                 WHEN i.TYPE = 3 THEN 135 --datetime
                     END) || '
             , ' || to_char(CASE WHEN i.TYPE IN (0, 4, 7)  THEN COALESCE(to_char(i.LENGTH), 'NULL')
                                 WHEN i.TYPE IN (1, 5, 6) THEN '22'
                                 WHEN i.TYPE = 2 THEN '7'
                                 WHEN i.TYPE = 3 THEN '11'
                     END) || '
             , ' || to_char(CASE WHEN i.TYPE IN (5, 6) THEN 38
                                 ELSE 0
                     END) || '
             , NULL
             , ' || (CASE WHEN i.TYPE IN (5, 6) THEN '''General Number'''
                          WHEN i.TYPE IN (2, 3) THEN '''Short Date'''
                          ELSE 'NULL'
                     END) || '
             , ' || (CASE WHEN i.TYPE IN (5, 6) THEN '''Right'''
                                 ELSE '''Left'''
                     END) || '

             , NULL, NULL, 0, 0, NULL, NULL, 0);
      ';

        v_sql := REPLACE(v_sql, '''', '''''') || '
                  END;';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);

        EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                              '.UTILS.CREATE_VIEW(''' || v_sql ||
                              '''); end;';


  END LOOP;


END ADD_OBJECT;

PROCEDURE DELETE_OBJECT
  (
  pin_ahmtd_schema varchar2
  , pin_object_name varchar2
  )
AS
v_sql CLOB;
BEGIN
  v_sql := '
  BEGIN
    DELETE FROM columns WHERE objectid IN (SELECT objectid FROM objects WHERE objectname = ''' || pin_object_name || ''');
    DELETE FROM roleobjects WHERE objectid IN (SELECT objectid FROM objects WHERE objectname = ''' || pin_object_name || ''');
    DELETE FROM objects WHERE objectname = ''' || pin_object_name || ''';
  END;
  ';

  v_sql := REPLACE(v_sql, '''', '''''');
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
--/*
  EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql ||
                        '''); end;';
--*/

END DELETE_OBJECT;


PROCEDURE GRANT_RIGHTS_TO_ROLE
  (
  pin_ahmtd_schema varchar2
  , pin_role_object_map TABLETYPE_RD_ROLE_OBJECT_MAP
  )
AS
v_sql CLOB;
BEGIN
  v_sql := 'BEGIN';

  FOR i IN (SELECT ROLE, OBJECT FROM TABLE(pin_role_object_map)) LOOP

    v_sql := v_sql || '
            DELETE
            FROM roleobjects RO
            WHERE EXISTS (SELECT 1 FROM ROLE R WHERE RO.ROLEID = R.ROLEID AND R.ROLENAME = ''''' || i.ROLE || ''''')
                  AND EXISTS (SELECT 1 FROM OBJECTS O WHERE RO.OBJECTID = O.OBJECTID AND O.OBJECTNAME = ''''' || i.OBJECT || ''''');
  ';

  END LOOP;

v_sql := v_sql || '
      END;';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
  EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql ||
                        '''); end;';

END GRANT_RIGHTS_TO_ROLE;



PROCEDURE REVOKE_RIGHTS_TO_ROLE
  (
  pin_ahmtd_schema varchar2
  , pin_role_object_map TABLETYPE_RD_ROLE_OBJECT_MAP
  )
AS
v_sql CLOB;
BEGIN
  v_sql := 'DECLARE v_database_id number;
BEGIN

  --catch no data exception
  select databaseid INTO v_database_id from sourcedatabase where ROWNUM = 1;
  ';

  FOR i IN (SELECT ROLE, OBJECT FROM TABLE(pin_role_object_map)) LOOP

    v_sql := v_sql || '
          INSERT INTO roleobjects (roleid, objectid, accesstype)
          VALUES((SELECT ROLEID FROM ROLE R WHERE R.ROLENAME = ''''' || i.ROLE || ''''')
                ,(SELECT OBJECTID FROM OBJECTS O WHERE O.OBJECTNAME = ''''' || i.OBJECT || ''''' AND databaseid = v_database_id)
                ,0);
          ';

   END LOOP;

v_sql := v_sql || '
      END;';

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', null);
--/*
  EXECUTE IMMEDIATE 'begin ' || pin_ahmtd_schema ||
                        '.UTILS.CREATE_VIEW(''' || v_sql ||
                        '''); end;';
--*/

END REVOKE_RIGHTS_TO_ROLE;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END REPORTS_GET_DATA;
/
