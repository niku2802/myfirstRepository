CREATE package EXPRESSION_BUILDER is

  -- --------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------

  -- Database Type  : SPM
  -- Product        : commons
  -- Module         : commons-filters
  -- Requester      : Homeuca, Victor
  -- Authors        : Hrubaru, Ionut
  -- Create date    : 20121127
  -- Reviewer       : Homeuca, Victor
  -- Review date    : 20110415
  -- Description    : package which contain implementation for ExB functions
  -- Function and procedure implementations

  -- Public function and procedure declarations

    /*
    -- Author     : Hrubaru Ionut
    -- Create date: 20121127
    -- Description: FUNCTION returns period number for a specific date and time unit id
    -- Parameters:
    -- IN Parameters

    -- pin_Date              date for which period number is required
    -- pin_TimeUnit          time unit id for which period number is required
    -- pin_Date_Time         if the parameter is date or date time (0/1)
    Example:-
    declare
    result number;

    begin
    -- Call the function
    result := expression_builder.SYNYGY_PERIOD_NUMBER(pin_Date => to_Date(''15/12/2025'', ''DD/MM/YYYY''), pin_TimeUnit=>241, pin_Date_Time => 0);
    dbms_output.put_line(result);
    end;
  */
  function SYNYGY_PERIOD_NUMBER(pin_Date DATE
                              ,pin_TimeUnit number, pin_Date_Time number) return number;

  /*
    -- Author     : Hrubaru Ionut
    -- Create date: 20121127
    -- Description: FUNCTION returns period year for a specific date and time unit id
    -- Parameters:
    -- IN Parameters

    -- pin_Date              date for which period year is required
    -- pin_TimeUnit          time unit id for which period year is required
    -- pin_Date_Time         if the parameter is date or date time (0/1)
    Example:-
    declare
    result number;

    begin
    -- Call the function
    result := expression_builder.SYNYGY_PERIOD_YEAR(pin_Date => to_Date(''15/12/2025'', ''DD/MM/YYYY''), pin_TimeUnit=>241, pin_Date_Time => 0);
    dbms_output.put_line(result);
    end;
  */
  function SYNYGY_PERIOD_YEAR(pin_Date DATE
                              ,pin_TimeUnit number, pin_Date_Time number) return number;

  /*
    -- Author     : Hrubaru Ionut
    -- Create date: 20130218
    -- Description: FUNCTION returns RIGHT characters from a string, for the specified length
    -- Parameters:
    -- IN Parameters

    -- pin_string          input string from which the characters are extracted
    -- pin_length          time unit id for which period year is required
    Example:-
    declare
    result varchar2;

    begin
    -- Call the function
    result := expression_builder.SYNYGY_RIGHT(pin_string => 'abcde', pin_length=>2);
    dbms_output.put_line(result);
    end;
  */
  function SYNYGY_RIGHT(pin_string VARCHAR2
                              ,pin_length number) return varchar2;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130812
    -- Description: FUNCTION returns period value for a specific date and time unit id
    -- Parameters:
    -- IN Parameters

    -- pin_Date              date for which period number is required
    -- pin_TimeUnit          time unit id for which period number is required
    -- pin_Date_Time         if the parameter is date or date time (0/1)
    Example:-
    declare
       v_result varchar2(36);

    begin
       -- Call the function
       v_result := expression_builder.SYNYGY_PERIOD_VALUE(pin_Date => to_Date('15/12/2025', 'DD/MM/YYYY'), pin_TimeUnit=>241, pin_Date_Time => 0);
       dbms_output.put_line(v_result);
    end;
  */
  function SYNYGY_PERIOD_VALUE(pin_Date DATE
                              ,pin_TimeUnit number, pin_Date_Time number) return number deterministic;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130812
    -- Description: FUNCTION returns period value for a specific time unit id and period number and year
    -- Parameters:
    -- IN Parameters

    -- pin_TimeUnit          time unit id
    -- pin_PeriodNumber      period number
    -- pin_year              year of the period
    Example:
    declare
       v_result varchar2(36);

    begin
       -- Call the function
       v_result := expression_builder.SYNYGY_PERIOD(pin_TimeUnit => 241, pin_PeriodNumber => 12.1, pin_year => 2025);
       dbms_output.put_line(v_result);
    end;
  */
  function SYNYGY_PERIOD(pin_TimeUnit NUMBER
  						, pin_PeriodNumber number, pin_year number) return number deterministic;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130812
    -- Description: FUNCTION adds a specified number of periods to a period
    -- Parameters:
    -- IN Parameters

    -- pin_period_id  period id
    -- pin_periods_to_add    the number of periods to add
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.ADD_PERIOD(pin_period_id => 478, pin_periods_to_add => 6);
       dbms_output.put_line(v_result);
    end;
  */
  function ADD_PERIOD(pin_period_id number,
                      pin_periods_to_add number)
  return number deterministic;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130812
    -- Description: FUNCTION substracts a specified number of periods to a period
    -- Parameters:
    -- IN Parameters

    -- pin_period_id  period id
    -- pin_periods_to_add    the number of periods to add
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.SUBSTRACT_PERIOD(pin_period_id => 478, pin_periods_to_add => 6);
       dbms_output.put_line(v_result);
    end;
  */
  function SUBSTRACT_PERIOD(pin_period_id number,
                      pin_periods_to_substract number)
  return number deterministic;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130812
    -- Description: FUNCTION Returns the period of the specified time unit that the specified period corresponds to.
    -- Parameters:
    -- IN Parameters

    -- pin_period_id         period id
    -- pin_time_unit_id      the id of the time unit
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.CORRESPONDING_PERIOD(pin_period_id => 461, pin_time_unit_id => 465);
       dbms_output.put_line(v_result);
    end;
  */

  function CORRESPONDING_PERIOD(pin_period_id number,
                      pin_time_unit_id number)
  return number deterministic;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns the period number of the specified period
    -- Parameters:
    -- IN Parameters

    -- pin_period_id         period id
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.PERIOD_NUMBER_FOR_PERIOD(pin_period_id => 461);
       dbms_output.put_line(v_result);
    end;
  */
  function PERIOD_NUMBER_FOR_PERIOD(pin_period_id number)
  return number deterministic;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns the year of the specified period
    -- Parameters:
    -- IN Parameters

    -- pin_period_id         period id
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.PERIOD_YEAR_FOR_PERIOD(pin_period_id => 461);
       dbms_output.put_line(v_result);
    end;
  */
  function PERIOD_YEAR_FOR_PERIOD(pin_period_id number)
  return number deterministic;


  /*  -----------------------------------------------------------------------------------------
  Author     : Macarie, Sabina
  Create date: 2015.07.27
  Description: Function used to return the name of a period
  -----------------------------------------------------------------------------------------*/
  FUNCTION PERIOD_NAME_FOR_PERIOD(pin_period_id NUMBER)
  RETURN VARCHAR2 deterministic;


   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns the maximum period from the specified table
    -- Parameters:
    -- IN Parameters

    -- pin_period_column         VARCHAR2
    -- pin_table_name            VARCHAR2
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.LAST_PERIOD_IN_TABLE(pin_period_column => 'F463', pin_table_name => 'T23456');
       dbms_output.put_line(v_result);
    end;
  */
  function LAST_PERIOD_IN_TABLE(pin_period_column VARCHAR2, pin_table_name VARCHAR2)
  return number;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns the minimum period from the specified table
    -- Parameters:
    -- IN Parameters

    -- pin_period_column         VARCHAR2
    -- pin_table_name            VARCHAR2
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.FIRST_PERIOD_IN_TABLE(pin_period_column => 'F463', pin_table_name => 'T23456');
       dbms_output.put_line(v_result);
    end;
  */
  function FIRST_PERIOD_IN_TABLE(pin_period_column VARCHAR2, pin_table_name VARCHAR2)
  return number;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns the maximum period from the specified periods
    -- Parameters:
    -- IN Parameters

    -- pin_period_ids         TABLETYPE_NUMBER
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.MAX_PERIOD(pin_period_id => TABLETYPE_NUMBER(461,462,463));
       dbms_output.put_line(v_result);
    end;
  */
  function MAX_PERIOD(pin_period_ids TABLETYPE_NUMBER)
  return number;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns the minimum period from the specified periods
    -- Parameters:
    -- IN Parameters

    -- pin_period_ids         TABLETYPE_NUMBER
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.MIN_PERIOD(pin_period_id => TABLETYPE_NUMBER(461,462,463));
       dbms_output.put_line(v_result);
    end;
  */
  function MIN_PERIOD(pin_period_ids TABLETYPE_NUMBER)
  return number;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns if the period is in the list of the specified periods
    -- Parameters:
    -- IN Parameters

    -- pin_period_id          NUMBER
    -- pin_period_ids         TABLETYPE_NUMBER
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.PERIOD_IN(pin_period_id => TABLETYPE_NUMBER(461,462,463));
       dbms_output.put_line(v_result);
    end;
  */
  function PERIOD_IN(pin_period_id NUMBER, pin_period_ids TABLETYPE_NUMBER)
  return number;

   /*
    -- Author     : Kristo Robert
    -- Create date: 20130905
    -- Description: FUNCTION Returns if the period is not in the list of the specified periods
    -- Parameters:
    -- IN Parameters

    -- pin_period_id          NUMBER
    -- pin_period_ids         TABLETYPE_NUMBER
    Example:

    declare
       v_result number;
    begin
       -- Call the function
       v_result := expression_builder.PERIOD_NOT_IN(pin_period_id => TABLETYPE_NUMBER(461,462,463));
       dbms_output.put_line(v_result);
    end;
  */
  function PERIOD_NOT_IN(pin_period_id NUMBER, pin_period_ids TABLETYPE_NUMBER)
  return number;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130827
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	pi_period_id	NUMBER - the id of the period range for which the start date must be calculated
  -----------------------------------------------------------------------------------------
  Returned value:
	The start date of the input period.
	If the supplied period id is NULL, a NULL is also returned.
	If the id of the period cannot be found in the system an error is returned.
  -----------------------------------------------------------------------------------------*/
FUNCTION FIRST_DAY_OF_PERIOD
(	pi_period_id	NUMBER
) RETURN DATE deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130827
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	pi_period_id	NUMBER - the id of the period range for which the end date must be calculated
  -----------------------------------------------------------------------------------------
  Returned value:
	The end date of the input period.
	If the supplied period id is NULL, a NULL is also returned.
	If the id of the period cannot be found in the system an error is returned.
  -----------------------------------------------------------------------------------------*/
FUNCTION LAST_DAY_OF_PERIOD
(	pi_period_id	NUMBER
) RETURN DATE deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value equals the right value.
   0 - the left value does not equal the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION EQUALS_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
 	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
		1 - timeunit of left period value equals timeunit of right period value
		2 - timeunit of left period value corresponds to timeunit of right period value
		3 - timeunit of right period value corresponds to timeunit of left period value
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value equals the right value.
   0 - the left value does not equal the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION EQUALS_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value does not equal the right value.
   0 - the left value equals the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION NOT_EQUALS_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
		1 - timeunit of left period value equals timeunit of right period value
		2 - timeunit of left period value corresponds to timeunit of right period value
		3 - timeunit of right period value corresponds to timeunit of left period value
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value does not equal the right value.
   0 - the left value equals the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION NOT_EQUALS_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is greater than the right value.
   0 - the left value is not greater than the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION GREATER_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
		1 - timeunit of left period value equals timeunit of right period value
		2 - timeunit of left period value corresponds to timeunit of right period value
		3 - timeunit of right period value corresponds to timeunit of left period value
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is greater than the right value.
   0 - the left value is not greater than the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION GREATER_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is greater than or equal to the right value.
   0 - the left value is not greater than or equal to the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION GREATER_EQ_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
		1 - timeunit of left period value equals timeunit of right period value
		2 - timeunit of left period value corresponds to timeunit of right period value
		3 - timeunit of right period value corresponds to timeunit of left period value
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is greater than or equal to the right value.
   0 - the left value is not greater than or equal to the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION GREATER_EQ_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is less than the right value.
   0 - the left value is not less than the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION LESS_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
		1 - timeunit of left period value equals timeunit of right period value
		2 - timeunit of left period value corresponds to timeunit of right period value
		3 - timeunit of right period value corresponds to timeunit of left period value
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is less than the right value.
   0 - the left value is not less than the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION LESS_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is less than or equal to the right value.
   0 - the left value is not less than or equal to the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION LESS_EQ_DATE_VS_OTHER
(	 pi_left_value				IN DATE
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_period_value		IN NUMBER
	,pi_right_period_tu_id		IN NUMBER
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description:
  ---------------------------------------------------------------------------------------
  Input Parameters:
	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
		0,1,2,5 - 'NONE'
		9 - 'EFF_SINGLE_DATE'
		3 - 'EFF_START_DATE'
		4 - 'EFF_END_DATE'
		8 - 'EFF_SINGLE_PERIOD'
		6 - 'EFF_START_PERIOD'
		7 - 'EFF_END_PERIOD'
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
		1 - timeunit of left period value equals timeunit of right period value
		2 - timeunit of left period value corresponds to timeunit of right period value
		3 - timeunit of right period value corresponds to timeunit of left period value
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
  -----------------------------------------------------------------------------------------
  Returned value:
   1 - the left value is less than or equal to the right value.
   0 - the left value is not less than or equal to the right value.
  -----------------------------------------------------------------------------------------*/
FUNCTION LESS_EQ_PERIOD_VS_OTHER
(	 pi_left_value				IN NUMBER
	,pi_left_period_tu_id		IN NUMBER
	,pi_lv_eff_option			IN NUMBER DEFAULT NULL
	,pi_right_date_value		IN DATE DEFAULT NULL
	,pi_right_period_value		IN NUMBER DEFAULT NULL
	,pi_right_period_tu_id		IN NUMBER DEFAULT NULL
	,pi_tu_correspondence		IN NUMBER DEFAULT NULL
	,pi_rv_eff_option			IN NUMBER DEFAULT NULL
) RETURN NUMBER deterministic;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description: This function is used in order to get an expression calculated value and treat errors that appear in calculations.
  				If errors are encountered then NULL will be returned instead of stoping the entire SQL query.
				It is designed to be used initially with Objectives.
				This function is to calculate NUMBER values.
  -----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_NUMBER_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN NUMBER;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description: This function is used in order to get an expression calculated value and treat errors that appear in calculations.
  				If errors are encountered then NULL will be returned instead of stoping the entire SQL query.
				It is designed to be used initially with Objectives.
				This function is to calculate VARCHAR2 values.
  -----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_VARCHAR2_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN VARCHAR2;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description: This function is used in order to get an expression calculated value and treat errors that appear in calculations.
  				If errors are encountered then NULL will be returned instead of stoping the entire SQL query.
				It is designed to be used initially with Objectives.
				This function is to calculate DATE values.
  -----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_DATE_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN DATE;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 20130807
  Description: This function is used in order to get an expression calculated value and treat errors that appear in calculations.
  				If errors are encountered then NULL will be returned instead of stoping the entire SQL query.
				It is designed to be used initially with Objectives.
				This function is to calculate TIMESTAMP values.
  -----------------------------------------------------------------------------------------*/
FUNCTION GET_CF_TIMESTAMP_VALUE
(	 pi_expr		CLOB
	,pi_from_sql	CLOB
	,pi_id_column	VARCHAR2
	,pi_id_value	NUMBER
) RETURN TIMESTAMP;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 2014.06.04
  Description: This function is used to parse an expression from EXPRESSIONS.EXP_EXPRESSION and replace IDs with names
  -----------------------------------------------------------------------------------------*/
FUNCTION GET_FILTER_EXPRESSION
(	pi_str CLOB
) RETURN CLOB;


/*  -----------------------------------------------------------------------------------------
  Author     : Dumitriu, Cosmin
  Create date: 2014.06.04
  Description: This procedures saves all the expressions into a temporary table for use in PHS feature of Management tool
                this is needed in order to work with CLOB across DATABASE LINKS
  -----------------------------------------------------------------------------------------*/
PROCEDURE SAVE_FILTER_EXPRESSIONS;

/*  -----------------------------------------------------------------------------------------
  Author     : Dobranici, Alexandru
  Create date: 2017.04.11
  Description: This function calculates natural logarithm for a certain value
  -----------------------------------------------------------------------------------------*/
FUNCTION NATURAL_LOGARITHM_CALCULATION(PI_LN_VARIABLE       NUMBER)
  RETURN NUMBER;

end EXPRESSION_BUILDER;
/
