CREATE package rank_records is

  procedure run_rank_records(PIN_INPUT_FROM_CLAUSE IN VARCHAR2, -- TABLE IN WHICH THE FIELDS TO BE RANKED ARE (+ ENTITY TABLES)
                             PIN_OUTPUT_TABLE      IN VARCHAR2, -- OUTPUT TABLE FOR RAKING PROCESS (CONTAINS OUTPUT FIELDS, RANK FIELDS AND COUT FIELDS)
                             PIN_OUTPUT_FIELDS     IN TABLETYPE_DT_RR_COL_ALIAS_LIST, --  Column mapping
                             /*  Columns:
                                                                                                                       COLUMN_NAME  VARCHAR2(30 CHAR) - name of column as in the input source
                                                                                                                       COLUMN_ALIAS VARCHAR2(50 CHAR) - alias for column
                                                                                                                       DISPLAY_FINAL_OUTPUT  NUMBER(1) - Flag 1/0 - to output in result table ot not
                                                                                                                       RANK_OR_COUNT_FLD NUMBER(1) - Flag 1/0 - rank result fld or count fld field
                                                                                                                   */
                             PIN_WHERE_CLAUSE      IN VARCHAR2, -- WHERECLAUSE CONTAINING FLTERING FOR PRIMARY OUTPUT
                             PIN_RANK_OPERATION_ID IN NUMBER,
                             PIN_TABLE_ALIAS       IN VARCHAR2,
                             PIN_INPUT_TABLE_NAME  IN VARCHAR2,
                               POUT_RECORD_COUNT    OUT NUMBER -- TOTAL COUNT OF RECORDS INSERTED INTO THE RESULT TABLE
                             );

  /* -----------------------------------------------------------------
     Call example:
         begin
          rank_records.run_rank_records(pin_input_from_clause => 'select ADJUSTED_BY, ACTION_PERFORMED, TASK_ID, ADJUSTMENT_ID, PAYMENT_DUE,syndate from tab1',
                                  pin_output_table => 'TEST_TAB_RANK_RES',
                                  pin_output_fields => tabletype_rr_col_alias_list(objtype_rr_col_alias_list ('ADJUSTED_BY','ADJUSTED_BY', 1, 0),
                                                                                   objtype_rr_col_alias_list ('ACTION_PERFORMED', 'ACTION_PERFORMED',1,0),
                                                                                   objtype_rr_col_alias_list ('TASK_ID','TASK_ID',1,0),
                                                                                   objtype_rr_col_alias_list ('ADJUSTMENT_ID','ADJUSTMENT_ID',1,0),
                                                                                   objtype_rr_col_alias_list ('PAYMENT_DUE','PAYMENT_DUE',1,0),
                                                                                   objtype_rr_col_alias_list ('METRIC1','METRIC1',1,1),
                                                                                   objtype_rr_col_alias_list ('OVERRIDE','OVERRIDE',1,1),
                                                                                   objtype_rr_col_alias_list ('METRIC2','METRIC2',1,1),
                                                                                   objtype_rr_col_alias_list ('QUALIFIER','QUALIFIER',1,1)),
                                  pin_where_clause => 'where 1=1',
                                  pin_rank_operation_id => 1);

  end;
    ----------------------------------------------------------------- */

  TYPE TABLETYPE_ALIASES IS TABLE OF VARCHAR2(50) INDEX BY VARCHAR2(64);
  ALIAS_Table TABLETYPE_ALIASES;

end rank_records;
/
