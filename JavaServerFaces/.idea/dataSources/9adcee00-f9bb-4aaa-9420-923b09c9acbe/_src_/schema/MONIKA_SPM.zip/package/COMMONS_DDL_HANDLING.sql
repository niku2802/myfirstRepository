CREATE package commons_ddl_handling is
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  appframework
  -- Requester    :  Homeuca, Victor
  -- Author    :  Lazar, Lucian
  -- Reviewer    :  Sharma, Pooja
  -- Review date    :  20110202
  -- Description    :  Used for executing and rolling back DDL statements
  -- Modified : 20140321 - refactoring
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110412
  -- Description: Starts a transaction and returns transaction id
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect Java to call this function right after begining a logic transaction.
     The function will start a Oracle transaction and generate a transaction id
     (normally a transaction is started when executing the first DML or DDL).
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    v_transaction_id := commons_ddl_handling.get_transaction_id;
    ...
  */
  -----------------------------------------------------------------------------------------
  function get_transaction_id return varchar2;
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110202
  -- Description: Executes a DDL in an autonomous transaction and logs the undo statement
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_transaction_id  in  varchar2 Logical transaction ID sent from Java (obtained with get_transaction_id)
     pi_description     in  varchar2 Description of the transaction (GUI operation, update script, etc)
     pi_ddl             in  clob     Anonymous block to be executed by autonomous transaction. Should contain an existance check.
     pi_undo_ddl        in  clob     Anonymous undo block to reverse the effect of pi_ddl in case of a rollback. Must contain an existance check.
     pi_run_id          in  number   Run ID sent from Java
     pi_resource_id     in  varchar2 ID of the resource affected by the DDL
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     In case any exception is thrown, all the ddls in the transaction are logged in the UNDO_DDL_HISTORY table
     and then the exception is passed on to the calling environment.
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.execute_ddl(v_transaction_id,
                                     'Tests',
                                     v_ddl,
                                     v_undo_ddl,
                                     null,
                                     123456);

    Example of v_ddl or v_undo_ddl block:
    begin
      for c in (select 1 from user_tables where table_name=''DI_TEST'') loop
        execute immediate ''drop table DI_TEST'';
      end loop;
    end;
  */
  -----------------------------------------------------------------------------------------
  procedure execute_ddl(pi_transaction_id  in varchar2,
                        pi_description     in varchar2,
                        pi_ddl             in clob,
                        pi_undo_ddl        in clob,
                        pi_run_id          in number default null,
                        pi_resource_id     in varchar2 default null);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110202
  -- Description: Executes a DDL in an autonomous transaction without logging the undo statement as no rollback is required
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_ddl in clob Anonymous block to be executed autonomous transaction. Should contain an existance check.
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect the caller to execute this procedure for DDL that clean backups (ex: drop temp resource).
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.execute_ddl_nolog(v_ddl);

    Example of v_ddl:
    begin
      for c in (select 1 from user_tables where table_name=''DI_TEST'') loop
        execute immediate ''drop table DI_TEST'';
      end loop;
    end;
  */
  -----------------------------------------------------------------------------------------
  procedure execute_ddl_nolog(pi_ddl      in clob,
	    					  pi_to_trace in number default 0) ;
  -- ========================================================

  -- ========================================================
  -- Author     : Dumitriu, Cosmin
  -- Create date: 20140627
  -- Description: Executes a DDL in an autonomous transaction without logging the undo statement as no rollback is required
  --              This is similar to execute_ddl_nolog just that it supports up to 5 varchar2 bind variables to be passed
  -----------------------------------------------------------------------------------------
  procedure execute_ddl_nolog_binds
  (pi_ddl in CLOB
  ,pi_bindvar1 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar2 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar3 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar4 IN VARCHAR2 DEFAULT NULL
  ,pi_bindvar5 IN VARCHAR2 DEFAULT NULL
  ,pi_log_id   IN VARCHAR2 DEFAULT NULL
  );
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20140923
  -- Description: Executes a DDL in an autonomous transaction without logging the undo statement and returning the number of rows affected
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_ddl in clob Anonymous block to be executed autonomous transaction. Should contain an existance check.
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_rowcount out number Number of rows affected by the DDL
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect the caller to execute this procedure for DDL that need the rowcount, like Data Load
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.execute_ddl_nolog_rowcount(v_ddl,v_count);
  */
  -----------------------------------------------------------------------------------------
  procedure execute_ddl_nolog_rowcount(pi_ddl in clob,
									   pi_to_trace in number default 0,
									   po_rowcount out number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110202
  -- Description: Cleans the DDL logs for a transaction; executed only if the transaction is successful
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_transaction_id in varchar2 Logical transaction ID sent from Java
     pi_run_id         in number   Run ID sent from Java
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect the caller to execute this procedure only if the transaction is successful.
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.clean_ddl_log(v_transaction_id);
  */
  -----------------------------------------------------------------------------------------
  procedure clean_ddl_log(pi_transaction_id in varchar2,
                          pi_run_id         in number default null);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110202
  -- Description: Rollbacks all DDL in a transaction; executed in the exception block
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_transaction_id in varchar2 Logical transaction ID sent from Java
     pi_run_id         in number   Run ID sent from Java
     pi_orphan_job     in number   Flag if the procedure is called from the rollback orphan transactions job: 1 = true, 0 (default) = false
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect Java to execute this procedure only in case of exceptions.
     Also, the procedure can be called from the rollback_orphan_ddl_trans procedure that is part of the rollback orphan transactions job
     In case any exception is thrown it is passed on to the calling environment after updating the status in the UNDO_DDL table
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.rollback_ddl(v_transaction_id, v_run_id);
  */
  -----------------------------------------------------------------------------------------
  procedure rollback_ddl(pi_transaction_id in varchar2,
                         pi_run_id         in number default null,
                         pi_orphan_job     in number default 0);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20120713
  -- Description: Rollback orphan DDLs application transactions (obtained with get_transaction_id)
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.rollback_orphan_ddl_trans;
  */
  -----------------------------------------------------------------------------------------
  procedure rollback_orphan_ddl_trans;
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20140909
  -- Description: Checks if the objects to be used by a run or a rollback are locked by a db rollback running in background
  --              Called before running the process or starting the rollback
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_run_id         in  number  not null  Run ID of the process
     pi_definition_id  in  number  null      Definition ID of the process; will be used only if the procedure is called before a run
     pi_mode           in  number  not null  Flag specifying if the procedure is called before a run or a rollback: 1 - run, 2 - rollback
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_locks         out  number  not null  Flag specifying if there are locks and if the run/rollback can start or not
                                             - 0 - there are no locks and the run/rollback can be started immediatly
                                             - 1 - there are locks and the run/rollback cannot start
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect Java to execute this procedure before running the process or starting the rollback for a process.
     If this procedure returns 0 then the run/rollback can be started immediatly.
     If this procedure returns 1 then it should be called again after a certain wait.
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.check_locks(v_run_id, v_definition_id, v_mode, v_locks);
  */
  -----------------------------------------------------------------------------------------
  procedure check_locks(pi_run_id        in number,
                        pi_definition_id in number,
                        pi_mode          in number,
                        po_locks         out number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20141002
  -- Description: Wrapper over check_locks, gets as input a list of process runs or rollbacks to determine the first one that can be started
  --              Checks if the objects to be used by a list of process runs or rollbacks are locked by a db rollback running in background
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_run_id_set  in  coltype_id  not null  Collection run ID of the processes; should not be empty
     pi_mode        in  number      not null  Flag specifying if the procedure is called before a run or a rollback: 1 - run, 2 - rollback
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_run_id  out  number  not null  Run ID of the first process thet can be started immediatly
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect Java to execute this procedure before running one item from a list of process runs or rollbacks.
     If this procedure returns a value not null then the run/rollback for that run id can be started immediatly.
     If this procedure returns null then it should be called again after a certain wait.
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.check_multiple_locks(v_run_id_set, v_mode, v_run_id);
  */
  -----------------------------------------------------------------------------------------
  procedure check_multiple_locks(pi_run_id_set in coltype_id,
                                 pi_mode       in number,
                                 po_run_id     out number);
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20150427
  -- Description: Function returning the rollback status for a process run id received as input
  --              Used internally and declared only to be accessed via sql in process_activity_status
  --              Returns:
  --              5 - ddl rollback in progress
  --              6 - ddl rollback failed
  --              7 - no activity
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_run_id  in  number  not null  Process run id
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.check_rollback(v_run_id);
  */
  -----------------------------------------------------------------------------------------
  function check_rollback(pi_run_id in number) return number;
  -- ========================================================

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20150306
  -- Description: This sp will return the db activity of all the leaf processes belonging to a process run id received as input
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_run_id  in  number  not null  Process run id; can be a parent (job, process) or a leaf (operation)
  */
  -----------------------------------------------------------------------------------------
  -- Output Parameters:
  /*
     po_process_status  out  tabletype_process_db_activity  not null  Collection with the all leaves of the input process run id with the following fields:
                                                                       - process_id         number    Process run id of the leaf (RUN_DATA.RD_ID)
                                                                       - process_name       varchar2  Process name (RUN_DATA.RD_NAME)
                                                                       - process_log_id     varchar2  Process log id (RUN_DATA.RD_LOG_ID)
                                                                       - process_type_id    number    Process type id (RUN_DATA.RD_TYPE)
                                                                       - process_type_name  varchar2  Process Type name (UTL_PROCESS_TYPE.PROCESS_TYPE_NAME)
                                                                       - process_status     number    Process status (RUN_STATUS_DATA.RS_STATUS)
                                                                       - process_db_status  number    DB status with these possible values:
                           1 - sql in progress
                           2 - sql stuck (not implemented yet)
                           3 - dml rollback in progress
                           4 - dml rollback stuck (not implemented yet)
                           5 - ddl rollback in progress
                           6 - ddl rollback failed
                           7 - no activity
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect to have this sp called from a shell script or from a tool included in Optymyze or OCM.
     The caller needs permissions to connect to the SPM schema.
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
    commons_ddl_handling.process_activity_status(v_run_id_set, v_process_status);
  */
  -----------------------------------------------------------------------------------------
  procedure process_activity_status(pi_run_id         in number,
                                    po_process_status out tabletype_process_db_activity);
  -- ========================================================

-- *******************************    PUBLIC PROCEDURES END         *******************************

end commons_ddl_handling;
/
