CREATE PACKAGE BODY LOGS AS
PRAGMA SERIALLY_REUSABLE;
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type	: SPM
-- Product			: commons
-- Module			: processing-commons
-- Requester		:  Obreja, Petru
-- Author		:  Lazarescu, Bogdan
-- Reviewer		:  Lazar, Lucian
-- Review date		:  20110328
-- Description		: create objects for LOGS insert/update/delete and LOGS counts refresh
-- ---------------------------------------------------------------------------
		-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
		-- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

		-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

/*******************************************************/
/**procedure used to insert data logs and logs details**/
/*******************************************************/
    PROCEDURE LOGS_UPSERT_DATA (
              pin_LM_RD_ID IN LOGS_MESSAGES.LM_RD_ID%TYPE
              , pin_LM_LEVEL IN LOGS_MESSAGES.LM_LEVEL%TYPE
              , pin_LM_MESSAGE IN LOGS_MESSAGES.LM_MESSAGE%TYPE
              , pin_LM_MESSAGE_DETAILS IN coltype_LOG_DETAILS
              , pin_LM_START_DATE IN LOGS_MESSAGES.LM_START_DATE%TYPE
              , pin_LM_UPDATE_DATE IN LOGS_MESSAGES.LM_UPDATE_DATE%TYPE
              , pinout_LM_ID IN OUT LOGS_MESSAGES.LM_ID%TYPE)
    AS

    v_old_level LOGS_MESSAGES.LM_LEVEL%TYPE;
    v_errors NUMBER;
    v_warnings NUMBER;
    v_next_LM_ID NUMBER;
    BEGIN

      IF (pinout_LM_ID IS NULL)
       THEN
        --insert
        v_errors := (CASE WHEN pin_LM_LEVEL = 0 THEN 1 ELSE 0 END);
        v_warnings := (CASE WHEN pin_LM_LEVEL = 1 THEN 1 ELSE 0 END);
      ELSE
        --update
        SELECT LM_LEVEL INTO v_old_level FROM LOGS_MESSAGES WHERE LM_ID = pinout_LM_ID;
        v_errors := (CASE WHEN v_old_level = 2 AND pin_LM_LEVEL = 1 THEN 0
                          WHEN v_old_level = 2 AND pin_LM_LEVEL = 0 THEN 1
                          WHEN v_old_level = 1 AND pin_LM_LEVEL = 0 THEN 1
                          WHEN v_old_level = 0 AND pin_LM_LEVEL IN (1, 2) THEN -1
                          ELSE 0
                     END);
        v_warnings := (CASE WHEN v_old_level = 2 AND pin_LM_LEVEL = 1 THEN 1
                          WHEN v_old_level = 2 AND pin_LM_LEVEL = 0 THEN 0
                          WHEN v_old_level = 1 AND pin_LM_LEVEL IN (0, 2)  THEN -1
                          WHEN v_old_level = 0 AND pin_LM_LEVEL = 1 THEN 1
                          ELSE 0
                     END);
      END IF;

      --get next uid for insert
      v_next_LM_ID := UID_SEQUENCE.NEXTVAL;

      merge into LOGS_MESSAGES LMC using dual on (LM_ID = pinout_LM_ID)
            when not matched then insert (LM_ID, LM_RD_ID, LM_LEVEL, LM_MESSAGE, LM_START_DATE, LM_UPDATE_DATE) values (v_next_LM_ID, pin_LM_RD_ID, pin_LM_LEVEL, pin_LM_MESSAGE, pin_LM_START_DATE, NULL)
            when matched then update set LM_LEVEL = pin_LM_LEVEL, LM_MESSAGE = pin_LM_MESSAGE, LM_UPDATE_DATE = pin_LM_UPDATE_DATE;

      --for insert the PK is returned
      pinout_LM_ID := COALESCE(pinout_LM_ID, v_next_LM_ID);
      --delete details first
      DELETE LOGS_MESSAGE_DETAILS WHERE LMD_LM_ID = pinout_LM_ID;
      FOR i IN 1..pin_LM_MESSAGE_DETAILS.COUNT LOOP
          INSERT INTO LOGS_MESSAGE_DETAILS(LMD_LM_ID, LMD_TEXT, LMD_ORDER) VALUES(pinout_LM_ID, pin_LM_MESSAGE_DETAILS(i).LMD_TEXT, pin_LM_MESSAGE_DETAILS(i).LMD_ORDER);
      END LOOP;

      LOGS.LOGS_MESSAGE_COUNT_REFRESH(pin_RD_ID => pin_LM_RD_ID, pin_errors => v_errors, pin_warnings => v_warnings);
    END LOGS_UPSERT_DATA;

/*********************************/
/**procedure used to delete logs**/
/*********************************/
    PROCEDURE LOGS_DELETE_DATA (pin_RD_IDS IN coltype_ID)
    AS

    v_errors NUMBER;
    v_warnings NUMBER;
    BEGIN

      FOR i IN 1..pin_RD_IDS.COUNT LOOP

      --refresh counts after getting errors and warnings only for current RD_ID
      SELECT SUM((CASE WHEN lm_level = 0 THEN 1 ELSE 0 END)) AS erorrs, SUM((CASE WHEN lm_level = 1 THEN 1 ELSE 0 END)) AS warnings INTO v_errors, v_warnings FROM LOGS_MESSAGES WHERE lm_rd_id = pin_RD_IDS(i);
      LOGS.LOGS_MESSAGE_COUNT_REFRESH(pin_RD_ID => pin_RD_IDS(i), pin_errors => - v_errors, pin_warnings => - v_warnings);

      --delete messages only the message not the count
      DELETE FROM LOGS_MESSAGES WHERE LM_RD_ID = pin_RD_IDS(i);

      END LOOP;

    END LOGS_DELETE_DATA;

/********************************************/
/**procedure used to refresh message counts**/
/********************************************/
    PROCEDURE LOGS_MESSAGE_COUNT_REFRESH (
      pin_RD_ID IN RUN_DATA.RD_ID%TYPE
      , pin_errors number
      , pin_warnings number)
    AS

    vr_RD_IDS coltype_RD_IDS;
    v_root_path varchar2(1300);
    BEGIN

          --get root path
          SELECT RD.RD_FULL_PATH INTO v_root_path
          FROM RUN_DATA RD
          WHERE RD.RD_ID = pin_RD_ID;
          --upsert message counts for current rundata
          --doing it this way in order to avoid duplicates
          update LOGS_MESSAGE_COUNT set LMC_ERROR_COUNT = LMC_ERROR_COUNT + pin_errors, LMC_WARN_COUNT = LMC_WARN_COUNT + pin_warnings WHERE LMC_RD_ID = pin_RD_ID;
          if ( sql%rowcount = 0 )
          then
              begin
              insert into LOGS_MESSAGE_COUNT (LMC_RD_ID, LMC_ERROR_COUNT, LMC_WARN_COUNT) values (pin_RD_ID, pin_errors, pin_warnings);
              exception
                     when dup_val_on_index
                         then
                             update LOGS_MESSAGE_COUNT set LMC_ERROR_COUNT = LMC_ERROR_COUNT + pin_errors, LMC_WARN_COUNT = LMC_WARN_COUNT + pin_warnings WHERE LMC_RD_ID = pin_RD_ID;
              end;
          end if;

         --upsert for higher hierarchy
         vr_RD_IDS := SPLIT_ROOT_PATH(v_root_path, '/');

         for i in 1..vr_RD_IDS.count loop

            if (vr_RD_IDS(i) IS NULL)
              then NULL;
                else
                  --doing it this way in order to avoid duplicates
                  update LOGS_MESSAGE_COUNT set LMC_ERROR_COUNT = LMC_ERROR_COUNT + pin_errors, LMC_WARN_COUNT = LMC_WARN_COUNT + pin_warnings WHERE LMC_RD_ID = vr_RD_IDS(i);
                  if ( sql%rowcount = 0 )
                    then
                        begin
                              insert into LOGS_MESSAGE_COUNT (LMC_RD_ID, LMC_ERROR_COUNT, LMC_WARN_COUNT) values (vr_RD_IDS(i), pin_errors, pin_warnings);
                        exception
                               when dup_val_on_index
                                   then
                                       update LOGS_MESSAGE_COUNT set LMC_ERROR_COUNT = LMC_ERROR_COUNT + pin_errors, LMC_WARN_COUNT = LMC_WARN_COUNT + pin_warnings WHERE LMC_RD_ID = vr_RD_IDS(i);
                        end;
                  end if;
            end if;
         end loop;


	EXCEPTION
	   WHEN NO_DATA_FOUND
	   THEN
		  L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, 'Error in retrieving any path for "'|| pin_RD_ID ||'"', SQLCODE, SQLERRM);
		  raise_application_error(-20001,SQLERRM);


    END LOGS_MESSAGE_COUNT_REFRESH;

/***********************************************/
/**funtion for spliting root path of a rundata**/
/***********************************************/
    function SPLIT_ROOT_PATH
	 (pin_str   in varchar2,
	  pin_delim in varchar2)
	 return coltype_RD_IDS
    as
       l_str	    long default pin_str || pin_delim;
       l_n	    number;
       l_data     coltype_RD_IDS := coltype_RD_IDS();
    begin
       loop
           l_n := instr( l_str, pin_delim );
           exit when (nvl(l_n,0) = 0);
           l_data.extend;
           l_data( l_data.count ) := ltrim(rtrim(substr(l_str,1,l_n-1)));
           l_str := substr( l_str, l_n+length(pin_delim) );
       end loop;
       return l_data;
    end;
		-- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

		-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************
		-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END LOGS;
/
