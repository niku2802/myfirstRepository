CREATE PACKAGE BODY PLANNING_MODELS AS

/* FORMAT_CONSTANT_VALUE
-----------------------------------------------------------------------------------------------
History:
    2016.05.31 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION FORMAT_CONSTANT_VALUE
(    pi_dim_type        VARCHAR2
    ,pi_dim_data_type   NUMBER
    ,pi_dim_value       VARCHAR2
) RETURN VARCHAR2 IS
    v_value             VARCHAR2(2000 CHAR);
BEGIN
    v_value := CASE WHEN pi_dim_type = 'ENTITY' THEN pi_dim_value
                    WHEN pi_dim_type = 'FIELD' AND pi_dim_data_type IN (2, 6, 8) THEN pi_dim_value
                    WHEN pi_dim_type = 'FIELD' AND pi_dim_data_type IN (1, 4) THEN ''''||REPLACE(pi_dim_value,'''','''''')||''''
                    WHEN pi_dim_type = 'FIELD' AND pi_dim_data_type = 3 THEN 'TO_DATE('''||pi_dim_value||''', ''YYYY-MM-DD'')'
                    WHEN pi_dim_type = 'FIELD' AND pi_dim_data_type = 5 THEN 'TO_TIMESTAMP('''||pi_dim_value||''', ''YYYY-MM-DD HH24:MI:SS'')'
                    ELSE NULL END;

    RETURN v_value;
END FORMAT_CONSTANT_VALUE;


/* FORMAT_CONSTANT_VALUE_LIST
-----------------------------------------------------------------------------------------------
History:
    2016.05.31 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION FORMAT_CONSTANT_VALUE_LIST
(    pi_dim_type        VARCHAR2
    ,pi_dim_data_type   NUMBER
    ,pi_list            TABLETYPE_CHARMAX
) RETURN VARCHAR2 IS
    v_value             CLOB;
BEGIN
    FOR c IN (SELECT COLUMN_VALUE FROM TABLE(pi_list))
    LOOP
        v_value := v_value||CASE WHEN v_value IS NOT NULL THEN ',' ELSE NULL END
                    ||PLANNING_MODELS.FORMAT_CONSTANT_VALUE(pi_dim_type        => pi_dim_type
                                                           ,pi_dim_data_type   => pi_dim_data_type
                                                           ,pi_dim_value       => c.COLUMN_VALUE);
    END LOOP;

    RETURN v_value;
END FORMAT_CONSTANT_VALUE_LIST;


/* FORMAT_COLUMN_FOR_DISPLAY
-----------------------------------------------------------------------------------------------
History:
    2016.05.31 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION FORMAT_COLUMN_FOR_DISPLAY
(    pi_col_name            VARCHAR2
    ,pi_col_data_type       NUMBER
    ,pi_col_length          NUMBER
    ,pi_col_th_separator    NUMBER
    ,pi_col_percent         NUMBER
    ,pi_col_period_prefix   VARCHAR2
    ,pi_session_separator   NUMBER
) RETURN VARCHAR2 IS
    v_number_value          VARCHAR2(4000 CHAR);
    v_value                 VARCHAR2(4000 CHAR);
BEGIN
    IF (pi_col_data_type = 6)
    THEN
        v_number_value := 'LTRIM(TO_CHAR('||pi_col_name||CASE WHEN pi_col_percent = 1 THEN '*100' ELSE NULL END
                                        ||', '''||CASE WHEN pi_col_th_separator = 1
                                                       THEN '999G999G999G999G999G999G999G999G999G990'
                                                       ELSE '999999999999999999999999999990'
                                                       END
                                                ||CASE WHEN pi_col_percent = 0 AND pi_col_length > 0 THEN 'D'||RPAD('9', pi_col_length, '9')
                                                       WHEN pi_col_percent = 1 AND pi_col_length > 2 THEN 'D'||RPAD('9', pi_col_length - 2, '9')
                                                       ELSE NULL END
                                                ||''''
                                        ||', ''NLS_NUMERIC_CHARACTERS = '''''
                                                ||CASE WHEN pi_session_separator = 1 THEN '.,' ELSE ',.' END
                                                ||''''''''
                                        ||'))'
                          ||CASE WHEN pi_col_percent = 1 THEN '||CASE WHEN '||pi_col_name||' IS NOT NULL THEN ''%'' ELSE NULL END' ELSE NULL END;
    END IF;

    v_value := CASE WHEN pi_col_data_type IN (1, 4) THEN pi_col_name
                    WHEN pi_col_data_type = 2 THEN 'CASE WHEN '||pi_col_name||' = 1 THEN ''Yes'' ELSE ''No'' END'
                    WHEN pi_col_data_type = 6 THEN v_number_value
                    WHEN pi_col_data_type = 3 THEN 'TO_CHAR('||pi_col_name||', ''YYYY-MM-DD'')'
                    WHEN pi_col_data_type = 5 THEN 'TO_CHAR('||pi_col_name||', ''YYYY-MM-DD HH24:MI:SS'')'
                    WHEN pi_col_data_type = 8 THEN pi_col_period_prefix||'.TUPR_PERIOD_RANGE_NAME'
                    ELSE 'TO_CHAR('||pi_col_name||')' END;

    RETURN v_value;
END FORMAT_COLUMN_FOR_DISPLAY;
-----------------------------------------------------------------------------------------------
PROCEDURE GET_REBUILT_FROM_CLAUSE( PI_TU_SELECT         IN  CLOB,
                                   PI_TU_COLUMNS        IN  CLOB,
                                   PI_ORIG_FROM_CLAUSE  IN  CLOB,
                                   PI_TABLE_NAME        IN  CLOB,
                                   PI_DIM_TYPE          IN  NUMBER,
                                   PO_FROM_CLAUSE       OUT CLOB) IS

BEGIN
  IF PI_TU_COLUMNS IS NOT NULL AND PI_DIM_TYPE = 8 THEN
    PO_FROM_CLAUSE := '(SELECT ALL_COMB.*, '||PI_TU_COLUMNS||' FROM '||CASE WHEN PI_ORIG_FROM_CLAUSE IS NOT NULL THEN '('||PI_ORIG_FROM_CLAUSE||')'
                            ELSE PI_TABLE_NAME END
                            ||' ALL_COMB '||PI_TU_SELECT||') ALL_COMB'||CHR(10);
  ELSE PO_FROM_CLAUSE :=  CASE WHEN PI_ORIG_FROM_CLAUSE IS NOT NULL THEN '('||PI_ORIG_FROM_CLAUSE||')'
                            ELSE PI_TABLE_NAME END
                            ||' ALL_COMB '||CHR(10);
  END IF;

END GET_REBUILT_FROM_CLAUSE;

------------------------------------------------------------------------------------------------

PROCEDURE GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST TABLETYPE_MDL_DIM_PATH_EXP,
                                                    PO_TU_SELECT         OUT CLOB,
                                                    PO_TU_COLUMNS        OUT CLOB
                                                   ) IS

  V_SELECT_STMT      CLOB;
  v_SELECTED_COLUMNS CLOB;
  V_PREV_SELECT_STMT VARCHAR2(1000CHAR);
  V_PREV_JOIN_COLUMN VARCHAR2(250CHAR);
  V_BASE_TIMEUNIT    NUMBER;
  V_BASE_PERIOD_FLD  VARCHAR2(30CHAR);
  V_TAB_ALIAS        VARCHAR2(50CHAR);
  V_TIMEUNITS        CLOB;
  V_TU_COLUMNS       CLOB;


BEGIN
  FOR C IN (SELECT DIM_NAME, DIM_ID, FLD_TIMEUNIT, DIM_BASE_ID
              FROM TABLE(PI_EXPANDED_DIM_LIST)
              JOIN FIELDS
                ON FLD_ID = DIM_ID
             WHERE DIM_DATA_TYPE = 8
               AND DIM_BASE_ID IS NOT NULL
             ORDER BY DIM_ORDER DESC) LOOP

    V_SELECT_STMT := V_SELECT_STMT || CASE
                       WHEN V_SELECT_STMT IS NOT NULL THEN
                        ' INNER JOIN '
                     END || V_PREV_SELECT_STMT;

    V_SELECTED_COLUMNS := REPLACE(V_SELECTED_COLUMNS,
                                  '<NEXT_DIM_NAME_PLACEHOLDER>',
                                  C.DIM_NAME);
    V_TU_COLUMNS := REPLACE(V_TU_COLUMNS,
                                  '<NEXT_DIM_NAME_PLACEHOLDER>',
                                  C.DIM_NAME);
    V_SELECT_STMT      := REPLACE(V_SELECT_STMT,
                                  '<NEXT_DIM_NAME_PLACEHOLDER>',
                                  C.DIM_NAME);
    V_SELECT_STMT      := REPLACE(V_SELECT_STMT,
                                  '<NEXT_DIM_TU_PLACEHOLDER>',
                                  C.FLD_TIMEUNIT);

    IF V_SELECTED_COLUMNS IS NULL THEN
      V_SELECTED_COLUMNS := 'P_' || C.FLD_TIMEUNIT || '.' || C.DIM_NAME;
    END IF;
    V_SELECTED_COLUMNS := V_SELECTED_COLUMNS || ' , P_' || C.FLD_TIMEUNIT ||
                          '.<NEXT_DIM_NAME_PLACEHOLDER>';
    V_TU_COLUMNS       := V_TU_COLUMNS ||CASE WHEN V_TU_COLUMNS IS NOT NULL THEN ',GTU.<NEXT_DIM_NAME_PLACEHOLDER>' ELSE 'GTU.<NEXT_DIM_NAME_PLACEHOLDER>' END;
    V_PREV_SELECT_STMT := '( SELECT TUPR_ID AS ' || C.DIM_NAME ||
                          ',TUPR_ID_CORR AS <NEXT_DIM_NAME_PLACEHOLDER>
                              FROM TU_CORR_MAT_VIEW
                              WHERE TUC_TU_ID = ' ||
                          C.FLD_TIMEUNIT ||
                          ' AND TUC_TU_ID_CORR = <NEXT_DIM_TU_PLACEHOLDER>) P_' ||
                          C.FLD_TIMEUNIT || ' ' || CASE
                            WHEN V_SELECT_STMT IS NOT NULL THEN
                             ' ON ' || V_TAB_ALIAS || '.' || C.DIM_NAME || '=' || 'P_' ||
                             C.FLD_TIMEUNIT || '.' || C.DIM_NAME
                          END;

    IF C.DIM_ID = C.DIM_BASE_ID THEN
      V_BASE_PERIOD_FLD := C.DIM_NAME;
    END IF;

    V_TAB_ALIAS := 'P_' || C.FLD_TIMEUNIT;

  END LOOP;

  V_SELECTED_COLUMNS := REPLACE(V_SELECTED_COLUMNS,
                                ', '||V_TAB_ALIAS ||
                                '.<NEXT_DIM_NAME_PLACEHOLDER>',
                                NULL);

  V_TU_COLUMNS := REPLACE(V_TU_COLUMNS,
                              ',GTU.<NEXT_DIM_NAME_PLACEHOLDER>',
                               NULL);

  V_SELECT_STMT := ' INNER JOIN ( SELECT ' || V_SELECTED_COLUMNS || 'FROM ' ||
                   V_SELECT_STMT || ') GTU ON GTU.'||V_BASE_PERIOD_FLD ||' = '||'ALL_COMB.'||V_BASE_PERIOD_FLD;

  PO_TU_SELECT  := V_SELECT_STMT;
  PO_TU_COLUMNS := V_TU_COLUMNS;

END GET_TIME_UNIT_STRUCTURE;

----------------------------------------------------------------------------------------------------------------

/* GET_PERIOD_SCENARIO_COMB
-----------------------------------------------------------------------------------------------
History:
    2017.06.13 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_PERIOD_SCENARIO_COMB
(    pi_def             SALES_PLANNING_MODELS%ROWTYPE
    ,pi_period_col      VARCHAR2
    ,pi_scenario_col    VARCHAR2
    ,pi_scenario_type   VARCHAR2
) RETURN CLOB AS
    v_sql               CLOB;
    v_scenario_e_table  VARCHAR2(30 CHAR);
BEGIN
    IF (pi_def.SPM_HAS_SCENARIO_ENTITY = 1)
    THEN
        SELECT T.TABLES_PHYSICAL_NAME
        INTO v_scenario_e_table
        FROM TABLES T
             INNER JOIN ENTITIES E ON ENTITY_TABLES_ID = TABLES_ID
        WHERE ENTITY_ID = pi_def.SPM_SCENARIO_ENTITY_ID;
    END IF;

    IF (pi_scenario_type = 'FORECAST' AND NVL(pi_def.SPM_HAS_SCENARIO_ENTITY, 0) = 0)
    THEN
        v_sql := '    SELECT S.'||pi_scenario_col||', P.'||pi_period_col||', S.SCENARIO_ORDER, P.PERIOD_ORDER'||CHR(10)
               ||'    FROM (SELECT SPMS_NAME AS '||pi_scenario_col||', SPMS_ORDER AS SCENARIO_ORDER FROM SPM_SCENARIOS WHERE SPMS_SPM_ID = v_definition_id'
                            ||CASE WHEN pi_def.SPM_ACTUALS_START_PERIOD IS NOT NULL THEN ' AND SPMS_NAME <> ''Actuals''' ELSE NULL END
                            ||') S'||CHR(10)
               ||'         CROSS JOIN '||CHR(10)
               ||'         (SELECT TUPR_ID AS '||pi_period_col||', TUPR_RANGE_NUMBER AS PERIOD_ORDER FROM TU_PERIODS_RANGE_V WHERE TUPR_TU_ID = v_timeunit_id AND TUPR_RANGE_NUMBER BETWEEN v_forecast_start AND v_forecast_end) P';

    ELSIF (pi_scenario_type = 'FORECAST' AND pi_def.SPM_HAS_SCENARIO_ENTITY = 1)
    THEN
        v_sql := '    SELECT S.'||pi_scenario_col||', P.'||pi_period_col||', S.SCENARIO_ORDER, P.PERIOD_ORDER'||CHR(10)
               ||'    FROM (SELECT E_INTERNAL_ID AS '||pi_scenario_col||', ROW_IDENTIFIER AS SCENARIO_ORDER FROM '||v_scenario_e_table
                            ||CASE WHEN pi_def.SPM_ACTUALS_START_PERIOD IS NOT NULL THEN ' WHERE E_INTERNAL_ID <> '||pi_def.SPM_SCENARIO_E_INTERNAL_ID ELSE NULL END
                            ||') S'||CHR(10)
               ||'         CROSS JOIN '||CHR(10)
               ||'         (SELECT TUPR_ID AS '||pi_period_col||', TUPR_RANGE_NUMBER AS PERIOD_ORDER FROM TU_PERIODS_RANGE_V WHERE TUPR_TU_ID = v_timeunit_id AND TUPR_RANGE_NUMBER BETWEEN v_forecast_start AND v_forecast_end) P';

    ELSIF (pi_scenario_type = 'ACTUALS' AND NVL(pi_def.SPM_HAS_SCENARIO_ENTITY, 0) = 0)
    THEN
        v_sql := '    SELECT S.'||pi_scenario_col||', P.'||pi_period_col||', S.SCENARIO_ORDER, P.PERIOD_ORDER'||CHR(10)
               ||'    FROM (SELECT SPMS_NAME AS '||pi_scenario_col||', SPMS_ORDER AS SCENARIO_ORDER FROM SPM_SCENARIOS WHERE SPMS_SPM_ID = v_definition_id AND SPMS_NAME = ''Actuals'' ) S'||CHR(10)
               ||'         CROSS JOIN '||CHR(10)
               ||'         (SELECT TUPR_ID AS '||pi_period_col||', TUPR_RANGE_NUMBER AS PERIOD_ORDER FROM TU_PERIODS_RANGE_V WHERE TUPR_TU_ID = v_timeunit_id AND TUPR_RANGE_NUMBER BETWEEN v_actuals_start AND v_actuals_end) P';

    ELSIF (pi_scenario_type = 'ACTUALS' AND pi_def.SPM_HAS_SCENARIO_ENTITY = 1)
    THEN
        v_sql := '    SELECT S.'||pi_scenario_col||', P.'||pi_period_col||', S.SCENARIO_ORDER, P.PERIOD_ORDER'||CHR(10)
               ||'    FROM (SELECT E_INTERNAL_ID AS '||pi_scenario_col||', ROW_IDENTIFIER AS SCENARIO_ORDER FROM '||v_scenario_e_table||' WHERE E_INTERNAL_ID = '||pi_def.SPM_SCENARIO_E_INTERNAL_ID||') S'||CHR(10)
               ||'         CROSS JOIN '||CHR(10)
               ||'         (SELECT TUPR_ID AS '||pi_period_col||', TUPR_RANGE_NUMBER AS PERIOD_ORDER FROM TU_PERIODS_RANGE_V WHERE TUPR_TU_ID = v_timeunit_id AND TUPR_RANGE_NUMBER BETWEEN v_actuals_start AND v_actuals_end) P';
    END IF;

    RETURN v_sql;
END GET_PERIOD_SCENARIO_COMB;


/* FORMAT_EXPR_FOR_NULL_IN_AGG
-----------------------------------------------------------------------------------------------
History:
    2017.02.27 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION FORMAT_EXPR_FOR_NULL_IN_AGG
(    pi_expr                VARCHAR2
    ,pi_expr_data_type      NUMBER
) RETURN VARCHAR2 IS
    v_formatted_expr        VARCHAR2(2000);
BEGIN
    v_formatted_expr := CASE -- boolean or period
                             WHEN pi_expr_data_type IN (2, 8) THEN 'NVL('||pi_expr||', -1)'

                             --character or note
                             WHEN pi_expr_data_type IN (1, 4) THEN 'NVL('||pi_expr||', CHR(0))'

                             -- date
                             WHEN pi_expr_data_type = 3       THEN 'NVL('||pi_expr||', TO_DATE(''01/01/1800'', ''DD/MM/YYYY''))'

                             -- datetime
                             WHEN pi_expr_data_type = 5       THEN 'NVL('||pi_expr||', TO_TIMESTAMP(''01/01/1800 00:00:00'', ''DD/MM/YYYY HH24:MI:SS''))'

                             -- numeric
                             WHEN pi_expr_data_type = 6       THEN 'NVL('||pi_expr||', 1E38)'
                             ELSE pi_expr END;

    RETURN v_formatted_expr;
END FORMAT_EXPR_FOR_NULL_IN_AGG;

------
FUNCTION GET_ORDERED_DIMS(PI_ROW_DIMS TABLETYPE_MDL_DIM_PATH_EXP,
                          PI_COL_DIMS TABLETYPE_MDL_DIM_PATH_EXP,
                          PI_TABLE_ID NUMBER) RETURN VARCHAR2 IS
  V_DIM_NAME VARCHAR2(2000 CHAR);
BEGIN

  SELECT LISTAGG(SUBSTR(F.FLD_BUSINESS_NAME, 1, 2), '-') WITHIN GROUP(ORDER BY DIM.TC_ORDER ASC, DIM_ORDER ASC)
    INTO V_DIM_NAME
    FROM (SELECT PI_COL_DIMS.DIM_ID,
                 PI_COL_DIMS.DIM_TYPE,
                 PI_COL_DIMS.DIM_DISPLAY_FLD_ID,
                 PI_COL_DIMS.DIM_ORDER,
                 TC_ORDER
            FROM TABLE(PI_COL_DIMS) PI_COL_DIMS
            JOIN TABLE_COLUMNS
              ON TC_TABLES_ID = PI_TABLE_ID
             AND (TC_FLD_ID = PI_COL_DIMS.DIM_ID OR
                 TC_ENTITY_ID = PI_COL_DIMS.DIM_ID OR
                 TC_FLD_ID = PI_COL_DIMS.DIM_BASE_ID)
          UNION ALL
          SELECT PI_ROW_DIMS.DIM_ID,
                 PI_ROW_DIMS.DIM_TYPE,
                 PI_ROW_DIMS.DIM_DISPLAY_FLD_ID,
                 PI_ROW_DIMS.DIM_ORDER,
                 TC_ORDER
            FROM TABLE(PI_ROW_DIMS) PI_ROW_DIMS
            JOIN TABLE_COLUMNS
              ON TC_TABLES_ID = PI_TABLE_ID
             AND (TC_FLD_ID = PI_ROW_DIMS.DIM_ID OR
                 TC_ENTITY_ID = PI_ROW_DIMS.DIM_ID OR
                 TC_FLD_ID = PI_ROW_DIMS.DIM_BASE_ID)) DIM
    LEFT JOIN ENTITIES E
      ON DIM_TYPE = 'ENTITY'
     AND DIM_ID = E.ENTITY_ID
    LEFT JOIN TABLE_COLUMNS E_TC
      ON E.ENTITY_TABLES_ID = E_TC.TC_TABLES_ID
     AND E_TC.TC_LOGIC_TYPE IN (1, 5)
    LEFT JOIN FIELDS F
      ON COALESCE(CASE
                    WHEN DIM_TYPE = 'FIELD' THEN
                     DIM_ID
                    ELSE
                     NULL
                  END,
                  DIM_DISPLAY_FLD_ID,
                  E_TC.TC_FLD_ID) = F.FLD_ID;

  RETURN V_DIM_NAME;
END GET_ORDERED_DIMS;

/* GET_DISP_FIELD_NAME
-----------------------------------------------------------------------------------------------
History:
    2017.05.23 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_DISP_FIELD_NAME
(    pi_dim                 OBJTYPE_MDL_DIM_PATH_EXP
) RETURN VARCHAR2 IS
    v_dim_name              VARCHAR2(2000 CHAR);
BEGIN
    SELECT F.FLD_BUSINESS_NAME
    INTO v_dim_name
    FROM (SELECT pi_dim.DIM_ID
                ,pi_dim.DIM_TYPE
                ,pi_dim.DIM_DISPLAY_FLD_ID
          FROM dual) DIM
          LEFT JOIN ENTITIES              E ON DIM_TYPE = 'ENTITY' AND DIM_ID = E.ENTITY_ID
          LEFT JOIN TABLE_COLUMNS         E_TC ON E.ENTITY_TABLES_ID = E_TC.TC_TABLES_ID AND E_TC.TC_LOGIC_TYPE IN (1, 5)
          LEFT JOIN FIELDS                F ON COALESCE(CASE WHEN DIM_TYPE = 'FIELD' THEN DIM_ID ELSE NULL END
                                                       ,DIM_DISPLAY_FLD_ID
                                                       ,E_TC.TC_FLD_ID) = F.FLD_ID;

    RETURN v_dim_name;
END GET_DISP_FIELD_NAME;


/* GET_DIM_BUSINESS_NAME
-----------------------------------------------------------------------------------------------
History:
    2017.05.23 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_DIM_BUSINESS_NAME
(    pi_dim_id              NUMBER
    ,pi_dim_type            VARCHAR2
) RETURN VARCHAR2 IS
    v_dim_name              VARCHAR2(2000 CHAR);
BEGIN
    IF (pi_dim_type = 'FIELD')
    THEN
        SELECT FLD_BUSINESS_NAME INTO v_dim_name FROM FIELDS WHERE FLD_ID = pi_dim_id;
    ELSE
        SELECT ENTITY_NAME INTO v_dim_name FROM ENTITIES WHERE ENTITY_ID = pi_dim_id;
    END IF;

    RETURN v_dim_name;
END GET_DIM_BUSINESS_NAME;


/* GET_AGG_FUNC_CLAUSES
-----------------------------------------------------------------------------------------------
History:
    2017.02.28 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_AGG_FUNC_CLAUSES
(    pi_view_def            CLOB
    ,pi_table_id            NUMBER
    ,pi_include_row_hash    NUMBER
    ,po_value_cols          OUT VARCHAR2
    ,po_value_cols_list     OUT VARCHAR2
) IS
    v_func                  VARCHAR2(32000 CHAR);
    v_temp                  VARCHAR2(32000 CHAR);
BEGIN
    IF (pi_include_row_hash = 1)
    THEN
        po_value_cols := ',SUM(ROW_VERSION) AS ROW_VERSION_HASH,COUNT(*) AS ROW_COUNT';
        po_value_cols_list := ',ROW_VERSION_HASH,ROW_COUNT';
    END IF;

    FOR c IN
    (   SELECT   VAL.FIELD_ID
                ,VAL.FUNCTION_TYPE
                ,VAL.WEIGHT_FIELD_ID
                ,TC.TC_PHYSICAL_NAME AS COLUMN_NAME
                ,TCW.TC_PHYSICAL_NAME AS WEIGHT_COLUMN_NAME
                ,COALESCE(TC.TC_FLD_OVERRIDDEN_LENGTH, F.FLD_LENGTH, 0) AS DEC_LENGTH
                ,F.FLD_DATA_TYPE
                ,COALESCE(TCW.TC_FLD_OVERRIDDEN_LENGTH, FW.FLD_LENGTH, 0) AS W_DEC_LENGTH
        FROM    (SELECT FIELD_ID, FUNCTION_TYPE, WEIGHT_FIELD_ID, ROWNUM AS FIELD_ORDER
                 FROM XMLTABLE('/pivotView/values/value' PASSING XMLTYPE(pi_view_def) COLUMNS
                         FIELD_ID NUMBER PATH 'fieldId'
                        ,FUNCTION_TYPE NUMBER PATH 'functionType'
                        ,WEIGHT_FIELD_ID NUMBER PATH 'weightFieldId')
                ) VAL
                LEFT JOIN TABLE_COLUMNS TC ON TC.TC_TABLES_ID = pi_table_id AND VAL.FIELD_ID = TC.TC_FLD_ID
                LEFT JOIN TABLE_COLUMNS TCW ON TCW.TC_TABLES_ID = pi_table_id AND VAL.WEIGHT_FIELD_ID = TCW.TC_FLD_ID
                LEFT JOIN FIELDS F ON VAL.FIELD_ID = F.FLD_ID
                LEFT JOIN FIELDS FW ON VAL.WEIGHT_FIELD_ID = FW.FLD_ID
        ORDER BY VAL.FIELD_ORDER
    )
    LOOP
        v_temp := PLANNING_MODELS.FORMAT_EXPR_FOR_NULL_IN_AGG(pi_expr           => 'A.FLD'
                                                             ,pi_expr_data_type => c.FLD_DATA_TYPE);

        IF (c.FLD_DATA_TYPE IN (1, 2, 4)) -- character, boolean and note fields
        THEN
            v_func := 'CASE WHEN (COUNT(DISTINCT A.FLD) + COUNT(DISTINCT CASE WHEN A.FLD IS NULL THEN 1 END)) != 1
                            THEN NULL
                            ELSE MIN(TO_CHAR(A.FLD)) KEEP(DENSE_RANK FIRST ORDER BY A.FLD)
                       END AS FLD';

        ELSE
            v_func := CASE c.FUNCTION_TYPE WHEN 1 THEN 'ROUND(SUM(A.FLD), DEC_LENGTH) AS FLD'
                                           WHEN 2 THEN 'ROUND(AVG(A.FLD), DEC_LENGTH) AS FLD'
                                           WHEN 3 THEN 'ROUND(MEDIAN(A.FLD), DEC_LENGTH) AS FLD'
                                           WHEN 4 THEN 'MIN(A.FLD) AS FLD'
                                           WHEN 5 THEN 'MAX(A.FLD) AS FLD'
                                           WHEN 6 THEN 'COUNT(A.FLD) AS FLD'
                                           WHEN 7 THEN 'COUNT(DISTINCT A.FLD) AS FLD'
                                           WHEN 8 THEN 'ROUND(STDDEV_POP(A.FLD), DEC_LENGTH) AS FLD'
                                           WHEN 9 THEN 'ROUND(STDDEV_SAMP(A.FLD), DEC_LENGTH) AS FLD'
                                           WHEN 10 THEN 'CASE WHEN MIN('||v_temp||')=MAX('||v_temp||') THEN MIN(A.FLD) ELSE NULL END AS FLD'
                                           WHEN 11 THEN '(CASE WHEN COUNT(A.FLD) = 1 '
                                                           || ' THEN AVG(A.FLD)'
                                                           || ' ELSE (CASE WHEN COUNT(A.WEIGHT_F) > 1 AND SUM(NVL(A.WEIGHT_F, 0)) != 0 '
                                                                      || ' THEN SUM(NVL(A.FLD,0) * NVL(A.WEIGHT_F,0))/SUM(NVL(A.WEIGHT_F,0))'
                                                                      || ' ELSE NULL END) END) AS FLD'
										   ELSE NULL END;
        END IF;

        po_value_cols := po_value_cols||','||REPLACE(REPLACE(REPLACE(v_func, 'WEIGHT_F', c.WEIGHT_COLUMN_NAME), 'FLD', c.COLUMN_NAME)
                                                  ,'DEC_LENGTH'
                                                  ,TO_CHAR(c.DEC_LENGTH)
                                                  )||CHR(10);

        po_value_cols_list := po_value_cols_list||','||c.COLUMN_NAME||CHR(10);
    END LOOP;
END GET_AGG_FUNC_CLAUSES;


/* GET_ROOT_CELL_FILTER
-----------------------------------------------------------------------------------------------
History:
    2017.03.01 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ROOT_CELL_FILTER
(    pi_row_exp_dim_list    TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_row_exp_root_items  TABLETYPE_CHARMAX
    ,pi_col_exp_dim_list    TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_col_exp_root_items  TABLETYPE_CHARMAX
) RETURN CLOB IS
    v_filter                CLOB;
    v_idx                   PLS_INTEGER;
    v_row_exp_root_flt      CLOB;
    v_row_first_dim_name    VARCHAR2(30 CHAR);
    v_col_exp_root_flt      CLOB;
    v_col_first_dim_name    VARCHAR2(30 CHAR);
BEGIN
    v_idx := pi_row_exp_dim_list.FIRST;
    v_row_first_dim_name := pi_row_exp_dim_list(v_idx).DIM_NAME;
    v_row_exp_root_flt := PLANNING_MODELS.FORMAT_CONSTANT_VALUE_LIST(pi_dim_type        => pi_row_exp_dim_list(v_idx).DIM_TYPE
                                                                    ,pi_dim_data_type   => pi_row_exp_dim_list(v_idx).DIM_DATA_TYPE
                                                                    ,pi_list            => pi_row_exp_root_items);

    v_idx := pi_col_exp_dim_list.FIRST;
    v_col_first_dim_name := pi_col_exp_dim_list(v_idx).DIM_NAME;
    v_col_exp_root_flt := PLANNING_MODELS.FORMAT_CONSTANT_VALUE_LIST(pi_dim_type        => pi_col_exp_dim_list(v_idx).DIM_TYPE
                                                                    ,pi_dim_data_type   => pi_col_exp_dim_list(v_idx).DIM_DATA_TYPE
                                                                    ,pi_list            => pi_col_exp_root_items);

    IF (v_row_exp_root_flt IS NOT NULL OR v_col_exp_root_flt IS NOT NULL)
    THEN
        v_filter := 'WHERE'||CHR(10)
            ||CASE WHEN v_row_exp_root_flt IS NOT NULL
                   THEN 'A.'||v_row_first_dim_name||' IN ('||v_row_exp_root_flt||')'
                   ELSE NULL END||CHR(10)
            ||CASE WHEN v_row_exp_root_flt IS NOT NULL AND v_col_exp_root_flt IS NOT NULL
                   THEN 'OR '
                   ELSE NULL END
            ||CASE WHEN v_col_exp_root_flt IS NOT NULL
                   THEN 'A.'||v_col_first_dim_name||' IN ('||v_col_exp_root_flt||')'
                   ELSE NULL END||CHR(10);
    END IF;

    RETURN v_filter;
END GET_ROOT_CELL_FILTER;


/* PREPARE_TABLE_FOR_PLA
-----------------------------------------------------------------------------------------------
History:
    2016.11.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE PREPARE_TABLE_FOR_PLA
(   pio_table_name          IN OUT VARCHAR2
) IS
    v_is_on_same_db         VARCHAR2(30 CHAR);
    v_pla_schema_name       VARCHAR2(30 CHAR);
    v_pla_to_spm_link_name  VARCHAR2(30 CHAR);
    v_grant                 VARCHAR2(200 CHAR);
BEGIN
    SELECT PR_VALUE INTO v_is_on_same_db FROM PROPERTIES WHERE PR_NAME = 'SPM_PLA_ON_SAME_DB';
    SELECT PR_VALUE INTO v_pla_schema_name FROM PROPERTIES WHERE PR_NAME = 'PLA_NAME';
    SELECT PR_VALUE INTO v_pla_to_spm_link_name FROM PROPERTIES WHERE PR_NAME = 'PLA_TO_SPM_DB_LINK_NAME';

    IF (v_is_on_same_db = '1')
    THEN
        v_grant := 'GRANT SELECT ON '||pio_table_name||' TO '||v_pla_schema_name;
        BEGIN
            COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(PI_DDL => v_grant);
        EXCEPTION
            WHEN OTHERS THEN NULL;
        END;
        pio_table_name := USER||'.'||pio_table_name;
    ELSE
        pio_table_name := pio_table_name||'@'||v_pla_to_spm_link_name;
    END IF;
END PREPARE_TABLE_FOR_PLA;


/* GET_DIMENSION_LIST
-----------------------------------------------------------------------------------------------
History:
    2016.06.08 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_DIMENSION_LIST
(    pi_model_table_id  NUMBER
    ,pi_view_def        CLOB
    ,pi_xml_path        VARCHAR2
    ,pi_parent_path     TABLETYPE_MDL_DIM_PATH
) RETURN TABLETYPE_MDL_DIM_PATH_EXP IS
    v_dim_list          TABLETYPE_MDL_DIM_PATH_EXP;
BEGIN
    SELECT  OBJTYPE_MDL_DIM_PATH_EXP(
             ALL_DIM.DIM_ID
            ,ALL_DIM.DIM_TYPE
            ,TC.TC_PHYSICAL_NAME
            ,F.FLD_DATA_TYPE
            ,ALL_DIM.DIM_ORDER
            ,ALL_DIM.DIM_DISPLAY_FLD_ID
            ,ALL_DIM.DIM_DISPLAY_ENTITY_BK
            ,P_DIM.DIM_VALUE
            ,NULL)
    BULK COLLECT INTO v_dim_list
    FROM    -- take all dimensions per row/column
            (SELECT  DIM_ID
                    ,DIM_TYPE
                    ,DIM_DISPLAY_FLD_ID
                    ,CASE WHEN UPPER(DIM_DISPLAY_ENTITY_BK) = 'TRUE' THEN 1 ELSE 0 END AS DIM_DISPLAY_ENTITY_BK
                    ,ROWNUM AS DIM_ORDER
             FROM XMLTABLE(pi_xml_path PASSING XMLTYPE(pi_view_def) COLUMNS
                     DIM_ID NUMBER PATH 'dimensionId'
                    ,DIM_TYPE VARCHAR2(30 CHAR) PATH 'dimensionType'
                    ,DIM_DISPLAY_FLD_ID NUMBER PATH 'displayFieldId'
                    ,DIM_DISPLAY_ENTITY_BK VARCHAR2(30 CHAR) PATH 'displayAlsoDimensionId'
                    )
            ) ALL_DIM
            -- see if some have already been expanded
            LEFT JOIN TABLE(pi_parent_path) P_DIM ON ALL_DIM.DIM_ID = P_DIM.DIM_ID AND ALL_DIM.DIM_TYPE = P_DIM.DIM_TYPE
            LEFT JOIN TABLE_COLUMNS TC ON TC.TC_TABLES_ID = pi_model_table_id
                                        AND (  (ALL_DIM.DIM_TYPE = 'ENTITY' AND TC.TC_COLUMN_TYPE = 1 AND ALL_DIM.DIM_ID = TC.TC_ENTITY_ID)
                                            OR (ALL_DIM.DIM_TYPE = 'FIELD'  AND TC.TC_COLUMN_TYPE = 2 AND ALL_DIM.DIM_ID = TC.TC_FLD_ID))
            LEFT JOIN FIELDS F ON ALL_DIM.DIM_TYPE = 'FIELD' AND ALL_DIM.DIM_ID = F.FLD_ID
    ORDER BY ALL_DIM.DIM_ORDER;

    RETURN v_dim_list;
END GET_DIMENSION_LIST;


/* GET_ENTITY_QUERY
-----------------------------------------------------------------------------------------------
History:
    2016.05.16 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ENTITY_QUERY
(   pi_definition_id    NUMBER
) RETURN CLOB IS
    v_stamp             VARCHAR2(200 CHAR);
    v_table_name        VARCHAR2(100 CHAR);
    v_query             CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_ENTITY_QUERY - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id), 'pi_definition_id := <value>', v_stamp);

    SELECT TABLES_PHYSICAL_NAME
    INTO v_table_name
    FROM ENTITIES INNER JOIN TABLES ON ENTITY_TABLES_ID = TABLES_ID
    WHERE ENTITY_ID = pi_definition_id;

    PLANNING_MODELS.PREPARE_TABLE_FOR_PLA(pio_table_name => v_table_name);

    v_query := 'SELECT E_INTERNAL_ID AS E'||TO_CHAR(pi_definition_id)||' FROM '||v_table_name;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query), 'v_query := <value>', v_stamp);
    RETURN v_query;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_ENTITY_QUERY;


/* GET_ASSIGNMENT_QUERY
-----------------------------------------------------------------------------------------------
History:
    2016.05.16 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_ASSIGNMENT_QUERY
(   pi_definition_id    NUMBER
) RETURN CLOB IS
    v_stamp             VARCHAR2(200 CHAR);
    v_table_name        VARCHAR2(100 CHAR);
    v_left_entity       VARCHAR2(30 CHAR);
    v_left_entity_id    NUMBER;
    v_is_eff_dated      NUMBER;
    v_second_entity_sel VARCHAR2(4000 CHAR);
    v_second_entity_cnd VARCHAR2(4000 CHAR);
    v_second_entity_cnt NUMBER;
    v_query             CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_ASSIGNMENT_QUERY - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id), 'pi_definition_id := <value>', v_stamp);

    -- get left entity
    SELECT TABLES_PHYSICAL_NAME, 'E'||EA_ENTITY_ID_LA, EA_ENTITY_ID_LA, EA_IS_EFFECTIVE_DATED
    INTO v_table_name, v_left_entity, v_left_entity_id, v_is_eff_dated
    FROM ENTITY_ASSIGNMENTS INNER JOIN TABLES ON EA_TABLES_ID = TABLES_ID
    WHERE EA_ID = pi_definition_id;

    PLANNING_MODELS.PREPARE_TABLE_FOR_PLA(pio_table_name => v_table_name);

    -- get secondary (right) entities
    SELECT   LISTAGG('E'||TO_CHAR(SA_ENTITY_ID), ',') WITHIN GROUP (ORDER BY SA_ORDER)
            ,LISTAGG('E'||TO_CHAR(SA_ENTITY_ID)||' IS NOT NULL', ' AND ') WITHIN GROUP (ORDER BY SA_ORDER)
            ,COUNT(*)
    INTO     v_second_entity_sel
            ,v_second_entity_cnd
            ,v_second_entity_cnt
    FROM SECONDARY_ASSIGNMENTS
    WHERE SA_EA_ID = pi_definition_id
          AND SA_ENTITY_ID <> v_left_entity_id;

    -- put together final query
    v_query := 'SELECT '||CASE WHEN v_is_eff_dated <> 0 THEN 'DISTINCT ' ELSE NULL END
        ||v_left_entity||','||v_second_entity_sel
        ||' FROM '||v_table_name
        ||CASE WHEN v_second_entity_cnt > 1 THEN ' WHERE '||v_second_entity_cnd ELSE NULL END;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query), 'v_query := <value>', v_stamp);
    RETURN v_query;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_ASSIGNMENT_QUERY;


/* GET_HIERARCHY_QUERY
-----------------------------------------------------------------------------------------------
History:
    2016.05.16 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_HIERARCHY_QUERY
(   pi_definition_id    NUMBER
) RETURN CLOB IS
    v_stamp             VARCHAR2(200 CHAR);
    v_table_name        VARCHAR2(100 CHAR);
    v_struct_id         NUMBER;
    v_is_eff_dated      NUMBER;
    v_select_sql        CLOB;
    v_from_sql          CLOB;
    v_query             CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_HIERARCHY_QUERY - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id), 'pi_definition_id := <value>', v_stamp);

    -- see if hierarchy is effective dated
    SELECT   HS_ID
            ,CASE WHEN HS_IS_DATED <> 0 OR HS_TIMEUNIT_ID IS NOT NULL THEN 1 ELSE 0 END
    INTO     v_struct_id
            ,v_is_eff_dated
    FROM    HIERARCHY_TABLES
            INNER JOIN HIERARCHY_STRUCTURE ON HT_ID = HS_HT_ID
    WHERE   HT_ID = pi_definition_id;

    -- for each hierarchy relationship build the necessary strings
    FOR c IN
    (   WITH HRC AS
        (   SELECT   'E'||HR_HIGHER_ENTITY_ID               AS UPPER_ENTITY
                    ,'E'||UE.ENTITY_BASE_ENTITY             AS UPPER_BASE_ENTITY
                    ,'E'||HR_LOWER_ENTITY_ID                AS LOWER_ENTITY
                    ,'E'||LE.ENTITY_BASE_ENTITY             AS LOWER_BASE_ENTITY
                    ,TABLES_PHYSICAL_NAME                   AS TABLE_NAME
                    ,ROW_NUMBER() OVER (ORDER BY HR_ORDER)  AS TABLE_ORDER
            FROM    HIERARCHY_RELATIONSHIP
                    INNER JOIN TABLES ON HR_TABLE_ID = TABLES_ID
                    INNER JOIN ENTITIES LE ON HR_LOWER_ENTITY_ID = LE.ENTITY_ID
                    INNER JOIN ENTITIES UE ON HR_HIGHER_ENTITY_ID = UE.ENTITY_ID
            WHERE   HR_HS_ID = v_struct_id
        )
        SELECT   A.UPPER_ENTITY
                ,A.UPPER_BASE_ENTITY
                ,A.LOWER_ENTITY
                ,A.LOWER_BASE_ENTITY
                ,A.TABLE_NAME
                ,A.TABLE_ORDER
                ,P.TABLE_NAME AS PREV_TABLE_NAME
                ,CASE WHEN A.UPPER_BASE_ENTITY = P.UPPER_BASE_ENTITY THEN P.UPPER_ENTITY
                      WHEN A.UPPER_BASE_ENTITY = P.LOWER_BASE_ENTITY THEN P.LOWER_ENTITY
                      ELSE NULL END AS PREV_ENTITY
        FROM    HRC A
                LEFT JOIN HRC P ON A.TABLE_ORDER > 1
                                AND P.TABLE_ORDER < A.TABLE_ORDER
                                AND (A.UPPER_BASE_ENTITY = P.UPPER_BASE_ENTITY OR A.UPPER_BASE_ENTITY = P.LOWER_BASE_ENTITY)
                                AND NOT EXISTS (SELECT 1 FROM HRC P1 WHERE P1.TABLE_ORDER < P.TABLE_ORDER
                                                                        AND (A.UPPER_BASE_ENTITY = P1.UPPER_BASE_ENTITY OR A.UPPER_BASE_ENTITY = P1.LOWER_BASE_ENTITY))
        ORDER BY A.TABLE_ORDER
    )
    LOOP
        v_table_name := c.TABLE_NAME;
        PLANNING_MODELS.PREPARE_TABLE_FOR_PLA(pio_table_name => v_table_name);

        IF (c.TABLE_ORDER = 1)
        THEN
            v_select_sql := c.TABLE_NAME||'.'||c.UPPER_ENTITY||' AS '||c.UPPER_BASE_ENTITY;
        END IF;

        v_select_sql := v_select_sql||','||c.TABLE_NAME||'.'||c.LOWER_ENTITY||' AS '||c.LOWER_BASE_ENTITY;

        v_from_sql := v_from_sql
            ||CASE WHEN c.TABLE_ORDER = 1 THEN v_table_name
                   ELSE CHR(10)||'INNER JOIN '||v_table_name||' ON '||c.TABLE_NAME||'.'||c.UPPER_ENTITY||' = '||c.PREV_TABLE_NAME||'.'||c.PREV_ENTITY END;
    END LOOP;

    -- put together the final query
    v_query := 'SELECT '||CASE WHEN v_is_eff_dated <> 0 THEN 'DISTINCT ' ELSE NULL END
        ||v_select_sql||CHR(10)
        ||'FROM '||v_from_sql||CHR(10);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query), 'v_query := <value>', v_stamp);
    RETURN v_query;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_HIERARCHY_QUERY;


/* GET_MODEL_RELATIONSHIPS
-----------------------------------------------------------------------------------------------
History:
    2018.08.04 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_MODEL_RELATIONSHIPS
(    pi_definition_id           IN NUMBER
) RETURN TABLETYPE_MDL_RELATIONSHIPS IS
    v_ent                       TABLETYPE_MDL_RELATIONSHIPS;
BEGIN
    SELECT OBJTYPE_MDL_RELATIONSHIPS(    SPME_ID
                                        ,DEF_LEVEL
                                        ,UPPER_ENTITY_ID
                                        ,LOWER_ENTITY_ID)
    BULK COLLECT INTO v_ent
    FROM    SPM_ENTITIES
            INNER JOIN
            (   SELECT   9 AS DEF_TYPE_ID
                        ,EA_ID AS DEF_ID
                        ,EA_ORDER AS DEF_LEVEL
                        ,UPPER_ENTITY_ID
                        ,LOWER_ENTITY_ID
                FROM    (   SELECT   EA_ID
                                    ,EA_ENTITY_ID AS UPPER_ENTITY_ID
                                    ,LEAD (EA_ENTITY_ID) OVER (PARTITION BY EA_ID ORDER BY EA_ORDER) AS LOWER_ENTITY_ID
                                    ,ROW_NUMBER() OVER (PARTITION BY EA_ID ORDER BY EA_ORDER) AS EA_ORDER
                            FROM   (    SELECT EA_ID, EA_ENTITY_ID_LA AS EA_ENTITY_ID, 0 AS EA_ORDER
                                        FROM ENTITY_ASSIGNMENTS
                                        WHERE EA_ENTITY_ID_LA IS NOT NULL
                                        UNION ALL
                                        SELECT SA_EA_ID AS EA_ID, SA_ENTITY_ID AS EA_ENTITY_ID, SA_ORDER + 1 AS EA_ORDER
                                        FROM SECONDARY_ASSIGNMENTS
                                    )
                        )
                WHERE   LOWER_ENTITY_ID IS NOT NULL
                UNION ALL
                SELECT   15 AS DEF_TYPE_ID
                        ,HS_HT_ID AS DEF_ID
                        ,HR_ORDER AS DEF_LEVEL
                        ,UE.ENTITY_BASE_ENTITY AS UPPER_ENTITY_ID
                        ,LE.ENTITY_BASE_ENTITY AS LOWER_ENTITY_ID
                FROM    HIERARCHY_RELATIONSHIP
                        INNER JOIN HIERARCHY_STRUCTURE ON HR_HS_ID = HS_ID
                        INNER JOIN ENTITIES UE ON HR_HIGHER_ENTITY_ID = UE.ENTITY_ID
                        INNER JOIN ENTITIES LE ON HR_LOWER_ENTITY_ID = LE.ENTITY_ID
            ) ON SPME_DEF_ID = DEF_ID AND SPME_DEF_TYPE_ID = DEF_TYPE_ID
    WHERE   SPME_SPM_ID = pi_definition_id
    ORDER BY SPME_ORDER, DEF_LEVEL;

    RETURN v_ent;
END GET_MODEL_RELATIONSHIPS;


/* GET_MODEL_DIMENSIONS
-----------------------------------------------------------------------------------------------
History:
    2016.05.09 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_MODEL_DIMENSIONS
(    pi_definition_id           IN NUMBER
) RETURN TABLETYPE_MDL_DIMENSIONS IS
    v_ent                       TABLETYPE_MDL_DIMENSIONS;
BEGIN
    WITH DIMENSIONS AS
    (   -- take stand-alone entities - they do not have relationships in SPMER
        SELECT   SPME_ORDER             AS DEF_ORDER
                ,SPME_ID                AS REL_ID
                ,SPME_DEF_ID            AS DEF_ID
                ,SPME_DEF_TYPE_ID       AS DEF_TYPE_ID
                ,1                      AS DIM_ORDER_IN_DEF
                ,SPME_DEF_ID            AS ENTITY_ID
                ,NULL                   AS FLD_ID
        FROM    SPM_ENTITIES
        WHERE   SPME_SPM_ID = pi_definition_id
                AND SPME_DEF_TYPE_ID = 12

        UNION ALL
        -- take first level UPPER entities
        SELECT   SPME_ORDER             AS DEF_ORDER
                ,SPME_ID                AS REL_ID
                ,SPME_DEF_ID            AS DEF_ID
                ,SPME_DEF_TYPE_ID       AS DEF_TYPE_ID
                ,SPMER_LEVEL            AS DIM_ORDER_IN_DEF
                ,SPMER_UPPER_ENTITY_ID  AS ENTITY_ID
                ,NULL                   AS FLD_ID
        FROM    SPM_ENTITIES
                INNER JOIN SPM_ENTITY_RELATIONSHIPS ON SPME_ID = SPMER_SPME_ID
        WHERE   SPME_SPM_ID = pi_definition_id
                AND SPMER_LEVEL = 1

        UNION ALL
        -- take all other LOWER entities
        SELECT   SPME_ORDER             AS DEF_ORDER
                ,SPME_ID                AS REL_ID
                ,SPME_DEF_ID            AS DEF_ID
                ,SPME_DEF_TYPE_ID       AS DEF_TYPE_ID
                ,SPMER_LEVEL + 1        AS DIM_ORDER_IN_DEF
                ,SPMER_LOWER_ENTITY_ID  AS ENTITY_ID
                ,NULL                   AS FLD_ID
        FROM    SPM_ENTITIES
                INNER JOIN SPM_ENTITY_RELATIONSHIPS ON SPME_ID = SPMER_SPME_ID
        WHERE   SPME_SPM_ID = pi_definition_id
    )
    SELECT OBJTYPE_MDL_DIMENSIONS
    (    DEF_ORDER
        ,REL_ID
        ,DEF_ID
        ,DEF_TYPE_ID
        ,DIM_ORDER_IN_DEF
        ,ENTITY_ID
        ,FLD_ID
    )
    BULK COLLECT INTO v_ent
    FROM DIMENSIONS
    ORDER BY DEF_ORDER, DIM_ORDER_IN_DEF;

    RETURN v_ent;
END GET_MODEL_DIMENSIONS;


/* GET_MODEL_CHANGED_DIMENSIONS
-----------------------------------------------------------------------------------------------
History:
    2017.08.01 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_MODEL_CHANGED_DIMENSIONS
(    pi_definition_id           IN NUMBER
    ,pi_entity_relationships    IN TABLETYPE_MDL_RELATIONSHIPS
) RETURN TABLETYPE_MDL_DIMENSIONS IS
    v_ent                       TABLETYPE_MDL_DIMENSIONS;
BEGIN
    WITH DIMENSIONS AS
    (   -- take stand-alone entities - they do not have relationships in SPMER
        SELECT   SPME_ORDER             AS DEF_ORDER
                ,SPME_ID                AS REL_ID
                ,SPME_DEF_ID            AS DEF_ID
                ,SPME_DEF_TYPE_ID       AS DEF_TYPE_ID
                ,1                      AS DIM_ORDER_IN_DEF
                ,SPME_DEF_ID            AS ENTITY_ID
                ,NULL                   AS FLD_ID
        FROM    SPM_ENTITIES
        WHERE   SPME_SPM_ID = pi_definition_id
                AND SPME_DEF_TYPE_ID = 12

        UNION ALL
        -- take first level UPPER entities
        SELECT   SPME_ORDER             AS DEF_ORDER
                ,SPME_ID                AS REL_ID
                ,SPME_DEF_ID            AS DEF_ID
                ,SPME_DEF_TYPE_ID       AS DEF_TYPE_ID
                ,R_LEVEL                AS DIM_ORDER_IN_DEF
                ,R_UPPER_ENTITY_ID      AS ENTITY_ID
                ,NULL                   AS FLD_ID
        FROM    SPM_ENTITIES
                INNER JOIN TABLE(pi_entity_relationships) ON SPME_ID = R_SPME_ID
        WHERE   SPME_SPM_ID = pi_definition_id
                AND R_LEVEL = 1

        UNION ALL
        -- take all other LOWER entities
        SELECT   SPME_ORDER             AS DEF_ORDER
                ,SPME_ID                AS REL_ID
                ,SPME_DEF_ID            AS DEF_ID
                ,SPME_DEF_TYPE_ID       AS DEF_TYPE_ID
                ,R_LEVEL + 1            AS DIM_ORDER_IN_DEF
                ,R_LOWER_ENTITY_ID      AS ENTITY_ID
                ,NULL                   AS FLD_ID
        FROM    SPM_ENTITIES
                INNER JOIN TABLE(pi_entity_relationships) ON SPME_ID = R_SPME_ID
        WHERE   SPME_SPM_ID = pi_definition_id
    )
    SELECT OBJTYPE_MDL_DIMENSIONS
    (    DEF_ORDER
        ,REL_ID
        ,DEF_ID
        ,DEF_TYPE_ID
        ,DIM_ORDER_IN_DEF
        ,ENTITY_ID
        ,FLD_ID
    )
    BULK COLLECT INTO v_ent
    FROM DIMENSIONS
    ORDER BY DEF_ORDER, DIM_ORDER_IN_DEF;

    RETURN v_ent;
END GET_MODEL_CHANGED_DIMENSIONS;


/* GET_MODEL_DISTINCT_DIMENSIONS
-----------------------------------------------------------------------------------------------
History:
    2016.05.09 - Dumitriu, Cosmin - created
    2017.08.01 - Dumitriu, Cosmin - added second parameter
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_MODEL_DISTINCT_DIMENSIONS
(    pi_definition_id           IN NUMBER
    ,pi_entity_relationships    IN TABLETYPE_MDL_RELATIONSHIPS DEFAULT NULL
) RETURN SYS_REFCURSOR IS
    v_ent                       SYS_REFCURSOR;
    v_stamp                     VARCHAR2(200 CHAR);
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_MODEL_DISTINCT_DIMENSIONS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),               ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_entity_relationships),    ',pi_entity_relationships => <value>', v_stamp);
    END;

    OPEN v_ent FOR
    WITH DIM AS
    (   SELECT   DEF_ORDER
                ,DEF_TYPE_ID
                ,DIM_ORDER_IN_DEF
                ,ROW_NUMBER() OVER (PARTITION BY DEF_ORDER ORDER BY DIM_ORDER_IN_DEF DESC) AS DIM_ORDER_IN_DEF_DESC
                ,ROW_NUMBER() OVER (PARTITION BY COALESCE(ENTITY_ID, FLD_ID) ORDER BY DEF_ORDER) AS DIM_ORDER_IN_ALL
                ,ENTITY_ID
                ,FLD_ID
        FROM    (SELECT DEF_ORDER,REL_ID,DEF_ID,DEF_TYPE_ID,DIM_ORDER_IN_DEF,ENTITY_ID,FLD_ID
                 FROM TABLE(PLANNING_MODELS.GET_MODEL_DIMENSIONS(pi_definition_id))
                 WHERE pi_entity_relationships IS NULL

                 UNION ALL
                 SELECT DEF_ORDER,REL_ID,DEF_ID,DEF_TYPE_ID,DIM_ORDER_IN_DEF,ENTITY_ID,FLD_ID
                 FROM TABLE(PLANNING_MODELS.GET_MODEL_CHANGED_DIMENSIONS(pi_definition_id        => pi_definition_id
                                                                        ,pi_entity_relationships => pi_entity_relationships))
                 WHERE pi_entity_relationships IS NOT NULL
                )
    )
    ,DIM_DISTINCT AS
    (   SELECT   ROW_NUMBER() OVER (ORDER BY DEF_ORDER, DIM_ORDER_IN_DEF) AS DIM_ORDER
                ,ENTITY_ID
                ,FLD_ID
                ,CASE WHEN DEF_TYPE_ID = 15 AND DIM_ORDER_IN_DEF_DESC > 1 THEN 0 ELSE 1 END AS IS_KEY
        FROM    DIM
        WHERE   DIM_ORDER_IN_ALL = 1
    )
    SELECT   DIM_ORDER
            ,ENTITY_ID
            ,FLD_ID
            ,IS_KEY
    FROM    DIM_DISTINCT
    UNION ALL
    SELECT   (SELECT MAX(DIM_ORDER)+1 FROM DIM_DISTINCT) AS DIM_ORDER
            ,NULL AS ENTITY_ID
            ,FLD_ID
            ,1 AS IS_KEY
    FROM    SALES_PLANNING_MODELS
            INNER JOIN TIME_UNITS ON SPM_TIMEUNIT_ID = TU_ID
            INNER JOIN FIELDS ON TU_ID = FLD_TIMEUNIT AND TU_NAME = FLD_BUSINESS_NAME
    WHERE   SPM_ID = pi_definition_id
    UNION ALL
    SELECT   (SELECT MAX(DIM_ORDER)+2 FROM DIM_DISTINCT) AS DIM_ORDER
            ,NULL AS ENTITY_ID
            ,FLD_ID
            ,1 AS IS_KEY
    FROM FIELDS
    WHERE FLD_COLUMN_NAME = 'SCENARIO'
        AND FLD_TYPE = 1 AND FLD_IS_PREDEFINED = 1
        AND (SELECT NVL(SPM_HAS_SCENARIO_ENTITY, 0) FROM SALES_PLANNING_MODELS WHERE SPM_ID = pi_definition_id) = 0
    UNION ALL
    SELECT   (SELECT MAX(DIM_ORDER)+2 FROM DIM_DISTINCT) AS DIM_ORDER
            ,SPM_SCENARIO_ENTITY_ID AS ENTITY_ID
            ,NULL AS FLD_ID
            ,1 AS IS_KEY
    FROM SALES_PLANNING_MODELS
    WHERE SPM_ID = pi_definition_id
        AND SPM_HAS_SCENARIO_ENTITY = 1;

    RETURN v_ent;
END GET_MODEL_DISTINCT_DIMENSIONS;


/* GET_SQL_FOR_GENERATE_COMB_TMP
-----------------------------------------------------------------------------------------------
History:
    2016.05.19 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_GENERATE_COMB_TMP
(    pi_definition_id           IN NUMBER
    ,po_sql                     OUT CLOB
) IS
    v_queries                   TABLETYPE_ID_QUERY;
BEGIN
    SELECT  OBJTYPE_ID_QUERY
            (SPME_ID
            ,CASE WHEN SPME_DEF_TYPE_ID = 12 THEN PLANNING_MODELS.GET_ENTITY_QUERY(SPME_DEF_ID)
                  WHEN SPME_DEF_TYPE_ID =  9 THEN PLANNING_MODELS.GET_ASSIGNMENT_QUERY(SPME_DEF_ID)
                  WHEN SPME_DEF_TYPE_ID = 15 THEN PLANNING_MODELS.GET_HIERARCHY_QUERY(SPME_DEF_ID)
                  ELSE NULL END)
    BULK COLLECT INTO v_queries
    FROM    SPM_ENTITIES
    WHERE   SPME_SPM_ID = pi_definition_id;

    PLANNING_MODELS.GET_SQL_FOR_GENERATE_COMB
    (pi_definition_id       => pi_definition_id
    ,pi_dimension_queries   => v_queries
    ,po_sql                 => po_sql);

    UPDATE SALES_PLANNING_MODELS SET SPM_HAS_GENERATED_DATA = 1 WHERE SPM_ID = pi_definition_id;
END GET_SQL_FOR_GENERATE_COMB_TMP;


/* GET_SQL_FOR_GENERATE_COMB
-----------------------------------------------------------------------------------------------
History:
    2016.04.29 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_GENERATE_COMB
(    pi_definition_id           IN NUMBER
    ,pi_dimension_queries       IN TABLETYPE_ID_QUERY
    ,po_sql                     OUT CLOB
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    SALES_PLANNING_MODELS%ROWTYPE;
    v_mod_table_name            VARCHAR2(30 CHAR);
    v_scenario_col              VARCHAR2(30 CHAR);
    v_period_col                VARCHAR2(30 CHAR);
    v_forecast_start            NUMBER;
    v_forecast_end              NUMBER;
    v_actuals_start             NUMBER;
    v_actuals_end               NUMBER;
    v_from_clause               CLOB;
    v_other_dim_clause          CLOB;
    v_insert_clause             VARCHAR2(32000 CHAR);
    v_upper_select_clause       VARCHAR2(32000 CHAR);
    v_select_clause             VARCHAR2(32000 CHAR);
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_GENERATE_COMB - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id), ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_dimension_queries), ',pi_dimension_queries => <value>', v_stamp);

        IF (pi_definition_id IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The model definition ID provided must not be null.'); END IF;
    END;

    -- get model definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM SALES_PLANNING_MODELS
        WHERE SPM_ID = pi_definition_id;

        IF (vrec_def.SPM_TABLE_ID IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The model table is not yet defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The model definition supplied does not exist.');
    END;

    v_scenario_col := CASE WHEN NVL(vrec_def.SPM_HAS_SCENARIO_ENTITY, 0) = 0 THEN 'SCENARIO'
                           ELSE 'E'||vrec_def.SPM_SCENARIO_ENTITY_ID
                           END;

    SELECT FLD_COLUMN_NAME INTO v_period_col
    FROM FIELDS INNER JOIN TIME_UNITS ON FLD_TIMEUNIT = TU_ID AND TU_NAME = FLD_BUSINESS_NAME
    WHERE TU_ID = vrec_def.SPM_TIMEUNIT_ID;

    v_mod_table_name := COMMONS_APPFRAMEWORK.GET_TABLE_NAME(pin_table_id => vrec_def.SPM_TABLE_ID);

    -- build helpful clauses
    FOR c IN
    (   WITH DIM AS
        (   SELECT   DENSE_RANK() OVER (ORDER BY DEF_ORDER) AS DEF_ORDER
                    ,REL_ID
                    ,DEF_ID
                    ,ROW_NUMBER() OVER (PARTITION BY DEF_ORDER ORDER BY DIM_ORDER_IN_DEF) AS DIM_ORDER_IN_DEF
                    ,ROW_NUMBER() OVER (PARTITION BY COALESCE(ENTITY_ID, FLD_ID) ORDER BY DEF_ORDER) AS DIM_ORDER_IN_ALL
                    ,ENTITY_ID
                    ,FLD_ID
            FROM    TABLE(PLANNING_MODELS.GET_MODEL_DIMENSIONS(pi_definition_id))
        )
        SELECT   DIM.DEF_ORDER
                ,SUM(CASE WHEN DIM.DIM_ORDER_IN_ALL > 1 THEN 1 ELSE 0 END) OVER (PARTITION BY DIM.DEF_ORDER) AS EXISTING_DIM_COUNT
                ,DIM.DIM_ORDER_IN_DEF
                ,DIM_FIRST.DEF_ORDER AS DIM_FIRST_DEF_ORDER
                ,ROW_NUMBER() OVER (PARTITION BY DIM.DEF_ORDER, CASE WHEN DIM.DIM_ORDER_IN_ALL > 1 THEN 1 ELSE 0 END ORDER BY DIM.DIM_ORDER_IN_DEF) AS DIM_JOIN_ORDER
                ,DIM.ENTITY_ID
                ,DIM.FLD_ID
                ,DQ.QUERY
        FROM    DIM
                LEFT JOIN DIM DIM_FIRST ON DIM.DIM_ORDER_IN_ALL > 1
                                    AND DIM_FIRST.DIM_ORDER_IN_ALL = 1
                                    AND COALESCE(DIM.ENTITY_ID, DIM.FLD_ID) = COALESCE(DIM_FIRST.ENTITY_ID, DIM_FIRST.FLD_ID)
                LEFT JOIN TABLE(pi_dimension_queries) DQ ON DIM.REL_ID = DQ.ID
        ORDER BY DIM.DEF_ORDER, DIM.DIM_ORDER_IN_DEF
    )
    LOOP
        IF (c.DIM_ORDER_IN_DEF = 1)
        THEN
            v_from_clause := v_from_clause
                ||CASE WHEN c.DEF_ORDER > 1 AND c.EXISTING_DIM_COUNT > 0 THEN CHR(10)||'INNER JOIN '
                       WHEN c.DEF_ORDER > 1 AND c.EXISTING_DIM_COUNT = 0 THEN CHR(10)||'CROSS JOIN '
                       ELSE NULL END
                ||'('||CHR(10)
                ||c.QUERY||') D'||TO_CHAR(c.DEF_ORDER);
        END IF;

        IF (c.DIM_FIRST_DEF_ORDER IS NOT NULL)
        THEN
            v_from_clause := v_from_clause
                ||CASE WHEN c.DIM_JOIN_ORDER = 1 THEN ' ON ' ELSE ' AND ' END
                ||CASE WHEN c.ENTITY_ID IS NOT NULL
                       THEN 'D'||c.DIM_FIRST_DEF_ORDER||'.E'||TO_CHAR(c.ENTITY_ID)||' = D'||c.DEF_ORDER||'.E'||TO_CHAR(c.ENTITY_ID)
                       ELSE NULL END;
        ELSE
            v_insert_clause := v_insert_clause||CASE WHEN v_insert_clause IS NOT NULL THEN ',' ELSE NULL END
                ||CASE WHEN c.ENTITY_ID IS NOT NULL THEN 'E'||TO_CHAR(c.ENTITY_ID)
                       ELSE NULL END;

            v_upper_select_clause := v_upper_select_clause||CASE WHEN v_upper_select_clause IS NOT NULL THEN CHR(10)||',' ELSE NULL END
                ||CASE WHEN c.ENTITY_ID IS NOT NULL THEN 'E'||TO_CHAR(c.ENTITY_ID)
                       ELSE NULL END;

            v_select_clause := v_select_clause||CASE WHEN v_select_clause IS NOT NULL THEN CHR(10)||',' ELSE NULL END
                ||CASE WHEN c.ENTITY_ID IS NOT NULL THEN 'D'||c.DEF_ORDER||'.E'||TO_CHAR(c.ENTITY_ID)
                       ELSE NULL END;
        END IF;
    END LOOP;

    -- build scenarios and periods clause
    BEGIN
        SELECT   (SELECT TUPR_RANGE_NUMBER FROM TU_PERIODS_RANGE_V WHERE TUPR_ID = vrec_def.SPM_FORECAST_START_PERIOD)
                ,(SELECT TUPR_RANGE_NUMBER FROM TU_PERIODS_RANGE_V WHERE TUPR_ID = vrec_def.SPM_FORECAST_END_PERIOD)
        INTO     v_forecast_start
                ,v_forecast_end
        FROM DUAL;

        v_other_dim_clause := GET_PERIOD_SCENARIO_COMB(pi_def               => vrec_def
                                                      ,pi_period_col        => v_period_col
                                                      ,pi_scenario_col      => v_scenario_col
                                                      ,pi_scenario_type     => 'FORECAST');

        IF (vrec_def.SPM_ACTUALS_START_PERIOD IS NOT NULL)
        THEN
            SELECT   (SELECT TUPR_RANGE_NUMBER FROM TU_PERIODS_RANGE_V WHERE TUPR_ID = vrec_def.SPM_ACTUALS_START_PERIOD)
                    ,(SELECT TUPR_RANGE_NUMBER FROM TU_PERIODS_RANGE_V WHERE TUPR_ID = vrec_def.SPM_ACTUALS_END_PERIOD)
            INTO     v_actuals_start
                    ,v_actuals_end
            FROM DUAL;

            v_other_dim_clause := v_other_dim_clause||CHR(10)
                ||'    UNION ALL'||CHR(10)
                ||GET_PERIOD_SCENARIO_COMB(pi_def               => vrec_def
                                          ,pi_period_col        => v_period_col
                                          ,pi_scenario_col      => v_scenario_col
                                          ,pi_scenario_type     => 'ACTUALS');
        END IF;
    END;

    po_sql := 'DECLARE'||CHR(10)
        ||'v_definition_id      NUMBER := :1;'||CHR(10)
        ||'v_timeunit_id        NUMBER := '||TO_CHAR(vrec_def.SPM_TIMEUNIT_ID)||';'||CHR(10)
        ||'v_forecast_start     NUMBER := '||TO_CHAR(v_forecast_start)||';'||CHR(10)
        ||'v_forecast_end       NUMBER := '||TO_CHAR(v_forecast_end)||';'||CHR(10)
        ||'v_actuals_start      NUMBER := '||NVL(TO_CHAR(v_actuals_start), 'NULL')||';'||CHR(10)
        ||'v_actuals_end        NUMBER := '||NVL(TO_CHAR(v_actuals_end), 'NULL')||';'||CHR(10)
    ||'BEGIN'||CHR(10)
    ||'EXECUTE IMMEDIATE ''TRUNCATE TABLE '||v_mod_table_name||''';'||CHR(10)

    ||'INSERT /*+ APPEND*/ INTO '||v_mod_table_name||'('
        ||v_insert_clause
        ||case when v_insert_clause is not null then ',' else null end
        ||v_period_col
        ||','||v_scenario_col
        ||',ROW_VERSION,ROW_IDENTIFIER)'||CHR(10)
        ||'SELECT '
        ||v_upper_select_clause
        ||case when v_upper_select_clause is not null then ',' else null end
        ||v_period_col
        ||','||v_scenario_col
        ||',0,'||COMMONS_APPFRAMEWORK.GET_ROW_IDENTIFIER_SEQUENCE(pi_table_name => v_mod_table_name
                                                                 ,pi_period_id  => NULL)||'.NEXTVAL'
        ||' FROM '

        ||'('||CHR(10)
        ||'SELECT '
        ||v_select_clause
        ||case when v_select_clause is not null then ',' else null end
        ||'SP.'||v_period_col
        ||',SP.'||v_scenario_col||CHR(10)
        ||'FROM '||v_from_clause
        ||case when v_from_clause is not null then CHR(10)||'CROSS JOIN ' else null end
        ||'('||v_other_dim_clause||') SP'||CHR(10)
        ||'ORDER BY '||v_select_clause
        ||case when v_select_clause is not null then ', ' else null end
        ||'SP.SCENARIO_ORDER, SP.PERIOD_ORDER'
        ||');'||CHR(10)
    ||'END;';

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, po_sql, NULL, NULL, v_stamp);

	UPDATE SALES_PLANNING_MODELS SET SPM_HAS_GENERATED_DATA = 1 WHERE SPM_ID = pi_definition_id;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_SQL_FOR_GENERATE_COMB;


/* GET_SQL_FOR_LOAD_DATA
-----------------------------------------------------------------------------------------------
History:
    2016.04.28 - Dumitriu, Cosmin - created
    2016.09.22 - Dumitriu, Cosmin - changed to not call CALCULATE and not trigger STATS
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_LOAD_DATA
(    pi_definition_id           IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_CHARMAX
    ,po_sql                     OUT CLOB
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    SALES_PLANNING_MODELS%ROWTYPE;
    v_mod_table_name            VARCHAR2(30 CHAR);
    v_vld_key_fields            VARCHAR2(32000 CHAR);
    v_vld_input_mappings_cnt    PLS_INTEGER := 0;
    v_sel_columns               VARCHAR2(32000 CHAR);
    v_join_columns              VARCHAR2(32000 CHAR);
    v_update_columns            VARCHAR2(32000 CHAR);
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_LOAD_DATA - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),        ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temp_table_name),    ',pi_temp_table_name => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_column_mapping),   ',pi_column_mapping => <value>', v_stamp);

        IF (pi_definition_id IS NULL)                       THEN RAISE_APPLICATION_ERROR(-20001, 'The model definition ID provided must not be null.'); END IF;
        IF (pi_temp_table_name IS NULL)                     THEN RAISE_APPLICATION_ERROR(-20001, 'The temporary table provided must not be null.'); END IF;
        IF (pi_column_mapping IS NULL)                      THEN RAISE_APPLICATION_ERROR(-20001, 'The column mapping provided must not be null.'); END IF;
    END;

    -- get model definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM SALES_PLANNING_MODELS
        WHERE SPM_ID = pi_definition_id;

        IF (vrec_def.SPM_TABLE_ID IS NULL)                  THEN RAISE_APPLICATION_ERROR(-20001, 'The model table is not yet defined.'); END IF;
        IF (NVL(vrec_def.SPM_HAS_GENERATED_DATA, 0) <> 1)   THEN RAISE_APPLICATION_ERROR(-20001, 'The model table is not yet been populated with possible combinations.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The model definition supplied does not exist.');
    END;

    v_mod_table_name := COMMONS_APPFRAMEWORK.GET_TABLE_NAME(pin_table_id => vrec_def.SPM_TABLE_ID);

    -- for each column in the model table build the merge clauses
    -- all keyfields must have a mapping in the temp table
    -- only Input values can have mappings for update
    FOR C IN
    (   SELECT   TC.TC_PHYSICAL_NAME
                ,TC.TC_LOGIC_TYPE
                ,MP.COLUMN_VALUE AS TEMP_MAPPING_COL
                ,I.SPMI_FLD_ID
        FROM    TABLE_COLUMNS TC
                LEFT JOIN TABLE(pi_column_mapping) MP ON TC.TC_PHYSICAL_NAME = MP.COLUMN_VALUE
                LEFT JOIN SPM_INPUTS I ON I.SPMI_SPM_ID = pi_definition_id AND TC.TC_FLD_ID = I.SPMI_FLD_ID
        WHERE   TC.TC_TABLES_ID = vrec_def.SPM_TABLE_ID
                AND (TC.TC_LOGIC_TYPE IN (1,9,3,4,8,6,7,5) /*key fields and eff dated columns*/
                     OR (I.SPMI_FLD_ID IS NOT NULL AND MP.COLUMN_VALUE IS NOT NULL) /*input values that have mapping in the source table*/)
        ORDER BY TC_ORDER
    )
    LOOP
        v_sel_columns := v_sel_columns||CASE WHEN v_sel_columns IS NOT NULL THEN ',' ELSE NULL END
            ||C.TEMP_MAPPING_COL||' AS '||C.TC_PHYSICAL_NAME;

        -- column is input value
        IF (C.SPMI_FLD_ID IS NOT NULL)
        THEN
            v_update_columns := v_update_columns||CASE WHEN v_update_columns IS NOT NULL THEN ',' ELSE NULL END
                ||C.TC_PHYSICAL_NAME||' = S.'||C.TC_PHYSICAL_NAME||CHR(10);

            -- validation - at least one input value is mapped and must be updated in the destination table
            v_vld_input_mappings_cnt := v_vld_input_mappings_cnt + 1;
        END IF;

        -- column is key field
        IF (C.TC_LOGIC_TYPE IN (1,9,3,4,8,6,7,5))
        THEN
            IF (C.TEMP_MAPPING_COL IS NOT NULL)
            THEN
                v_join_columns := v_join_columns||CASE WHEN v_join_columns IS NOT NULL THEN 'AND ' ELSE NULL END
                    ||'D.'||C.TC_PHYSICAL_NAME||' = S.'||C.TC_PHYSICAL_NAME||CHR(10);
            ELSE
                -- validation - some key fields are not mapped in input
                v_vld_key_fields := v_vld_key_fields||CASE WHEN v_vld_key_fields IS NOT NULL THEN ',' ELSE NULL END||C.TC_PHYSICAL_NAME;
            END IF;
        END IF;
    END LOOP;

    IF (v_vld_key_fields IS NOT NULL)
    THEN
        RAISE_APPLICATION_ERROR(-20001, 'The key fields '||v_vld_key_fields||' in the destination model table have not been mapped from the input.');
    END IF;

    /* IF (v_vld_input_mappings_cnt = 0)
    THEN
        RAISE_APPLICATION_ERROR(-20001, 'None of the input values have been mapped from the input.');
    END IF;*/

    /*  MERGE INTO T123 D
        USING (SELECT KEYFIELD_DIM1
                     ,KEYFIELD_DIM2
                     ,F234 - scenario which is also a key field
                     ,F456 - period which is also a keyfield
                     ,InputVal1
                     ,InputVal2
                FROM TMP_323) S
        ON (D.KEYFIELD_DIM1 = S.KEYFIELD_DIM1
            and ... all key field joins)
        WHEN MATCHED THEN UPDATE SET InputVal1 = S.InputVal1, ...; */

    po_sql := 'DECLARE'||CHR(10)
            ||'v_definition_id      NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_definition_id      := :1;'||CHR(10)
            || case when v_vld_input_mappings_cnt <> 0 then -- bypass in case none of the input values have been mapped from the input.
                      COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'PLANNING_MODELS.LOAD_DATA' ,pi_hint_id=> 'MRG_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'MERGE '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'PLANNING_MODELS.LOAD_DATA' ,pi_hint_id=> 'MRG_MAIN' ,pi_proc_id => pi_definition_id, pi_other_hints => 'NO_USE_NL(D)')||CHR(10)
            ||'INTO '||v_mod_table_name||' D'||CHR(10)
            ||'USING ('||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'PLANNING_MODELS.LOAD_DATA' ,pi_hint_id=> 'SEL_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'PLANNING_MODELS.LOAD_DATA' ,pi_hint_id=> 'SEL_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||v_sel_columns||CHR(10)
            ||'FROM '||pi_temp_table_name||') S'||CHR(10)
            ||' ON ('||v_join_columns||')'||CHR(10)
            ||'WHEN MATCHED THEN UPDATE SET '||v_update_columns||';'||CHR(10)
            ||':2 := SQL%ROWCOUNT;'||CHR(10)
           else  ':2 := 0;'||CHR(10) end
        ||'END;';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(po_sql), 'po_sql := <value>;', v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_SQL_FOR_LOAD_DATA;


/* GET_SQL_FOR_LOAD_DATA_MOD
-----------------------------------------------------------------------------------------------
History:
    2016.09.22 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_LOAD_DATA_MOD
(    pi_definition_id           IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_CHARMAX
    ,po_updated_fld_ids         OUT TABLETYPE_NUMBER
    ,po_sql                     OUT CLOB
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    SALES_PLANNING_MODELS%ROWTYPE;
    v_mod_table_name            VARCHAR2(30 CHAR);
    v_join_columns              VARCHAR2(32000 CHAR);
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_LOAD_DATA_MOD - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),        ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temp_table_name),    ',pi_temp_table_name => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_column_mapping),   ',pi_column_mapping => <value>', v_stamp);

        IF (pi_definition_id IS NULL)                       THEN RAISE_APPLICATION_ERROR(-20001, 'The model definition ID provided must not be null.'); END IF;
        IF (pi_temp_table_name IS NULL)                     THEN RAISE_APPLICATION_ERROR(-20001, 'The temporary table provided must not be null.'); END IF;
        IF (pi_column_mapping IS NULL)                      THEN RAISE_APPLICATION_ERROR(-20001, 'The column mapping provided must not be null.'); END IF;
    END;

    -- get model definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM SALES_PLANNING_MODELS
        WHERE SPM_ID = pi_definition_id;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The model definition supplied does not exist.');
    END;

    v_mod_table_name := COMMONS_APPFRAMEWORK.GET_TABLE_NAME(pin_table_id => vrec_def.SPM_TABLE_ID);
    po_updated_fld_ids := TABLETYPE_NUMBER();

    FOR C IN
    (   SELECT   TC.TC_PHYSICAL_NAME
                ,TC.TC_LOGIC_TYPE
                ,MP.COLUMN_VALUE AS TEMP_MAPPING_COL
                ,I.SPMI_FLD_ID
        FROM    TABLE_COLUMNS TC
                LEFT JOIN TABLE(pi_column_mapping) MP ON TC.TC_PHYSICAL_NAME = MP.COLUMN_VALUE
                LEFT JOIN SPM_INPUTS I ON I.SPMI_SPM_ID = pi_definition_id AND TC.TC_FLD_ID = I.SPMI_FLD_ID
        WHERE   TC.TC_TABLES_ID = vrec_def.SPM_TABLE_ID
                AND (TC.TC_LOGIC_TYPE IN (1,9,3,4,8,6,7,5) /*key fields and eff dated columns*/
                     OR (I.SPMI_FLD_ID IS NOT NULL AND MP.COLUMN_VALUE IS NOT NULL) /*input values that have mapping in the source table*/)
        ORDER BY TC_ORDER
    )
    LOOP
        -- column is input value
        IF (C.SPMI_FLD_ID IS NOT NULL)
        THEN
            po_updated_fld_ids.EXTEND;
            po_updated_fld_ids(po_updated_fld_ids.LAST) := C.SPMI_FLD_ID;
        END IF;

        -- column is key field
        IF (C.TC_LOGIC_TYPE IN (1,9,3,4,8,6,7,5))
        THEN
            v_join_columns := v_join_columns||CASE WHEN v_join_columns IS NOT NULL THEN 'AND ' ELSE NULL END
                ||'D.'||C.TC_PHYSICAL_NAME||' = S.'||C.TC_PHYSICAL_NAME||CHR(10);
        END IF;
    END LOOP;

    po_sql := 'SELECT  /*+use_merge(D, S)*/ D.ROW_IDENTIFIER FROM '||v_mod_table_name||' D WHERE EXISTS (SELECT 1 FROM '||pi_temp_table_name||' S WHERE '||v_join_columns||')';
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(po_sql), 'po_sql := <value>;', v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_SQL_FOR_LOAD_DATA_MOD;


/* GET_SQL_FOR_PIVOT_STRUCTURE
-----------------------------------------------------------------------------------------------
History:
    1. 2016.05.30 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SQL_FOR_PIVOT_STRUCTURE
(    pi_view_id             NUMBER
    ,pi_axis_type           NUMBER
    ,pi_from_clause         CLOB
    ,pi_parent_id           VARCHAR2
    ,pi_expanded_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_login_id            VARCHAR2 DEFAULT NULL
) RETURN CLOB IS
    v_view_def              CLOB;
    v_table_id              NUMBER;
    v_table_name            VARCHAR2(30 CHAR);
    v_spm_id                NUMBER;

    v_expand_dim_id         NUMBER;
    v_expand_dim_name       VARCHAR2(30 CHAR);
    v_expand_dim_type       VARCHAR2(30 CHAR);
    v_expand_dim_f_dtype    NUMBER;
    v_expand_dim_e_disp_fid NUMBER;
    v_expand_dim_e_disp_bk  NUMBER;

    v_e_table               VARCHAR2(30 CHAR);
    v_e_bk_colname          VARCHAR2(30 CHAR);
    v_e_bk_dtype            NUMBER;
    v_e_bk_null             NUMBER;
    v_e_bk_format           VARCHAR2(4000 CHAR);
    v_e_disp_colname        VARCHAR2(30 CHAR);
    v_e_disp_dtype          NUMBER;
    v_e_disp_null           NUMBER;
    v_e_disp_format         VARCHAR2(4000 CHAR);

    v_decimal_separator     NUMBER;
    v_parent_filter         CLOB;
    v_query                 CLOB;
    v_stamp                 VARCHAR2(200 CHAR);

    v_tu_join               CLOB;
    v_tu_cols               CLOB;
    v_rebuilt_from_clause   CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_PIVOT_STRUCTURE - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_id),              ',pi_view_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_axis_type),            ',pi_axis_type => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_from_clause),            ',pi_from_clause => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_parent_id),          ',pi_parent_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_expanded_dim_list),',pi_expanded_dim_list => <value>', v_stamp);
    END;

    -- get user settings - Decimal separator: 1=Period, 2=Comma
    BEGIN
        SELECT SUS_DECIMAL_SEPARATOR
        INTO v_decimal_separator
        FROM SET_USER_SETTINGS
        WHERE SUS_LOGIN_ID = pi_login_id;
    EXCEPTION
    WHEN OTHERS THEN
        v_decimal_separator := 1;
    END;

    -- get view properties
    SELECT   OD_DEFINITION
            ,TABLES_ID
            ,TABLES_PHYSICAL_NAME
            ,SPM_ID
    INTO     v_view_def
            ,v_table_id
            ,v_table_name
            ,v_spm_id
    FROM    OBJECT_DEFINITIONS
            INNER JOIN TABLE_REFERENCES ON TREF_ID = EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/tableReferenceId')
            INNER JOIN TABLES ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
            LEFT JOIN SALES_PLANNING_MODELS ON TREF_DEFINITION_ID = SPM_TABLE_ID
    WHERE   OD_CONTAINER_ID = pi_view_id;

   -- get time unit joins
    GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_expanded_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    FOR c IN
    (   SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER,DIM_DISPLAY_FLD_ID,DIM_DISPLAY_ENTITY_BK,DIM_VALUE
        FROM    TABLE(pi_expanded_dim_list)
        ORDER BY DIM_ORDER
    )
    LOOP
        -- get first dimension that has not been expanded
        IF (c.DIM_VALUE IS NULL AND v_expand_dim_id IS NULL)
        THEN
            v_expand_dim_id         := c.DIM_ID;
            v_expand_dim_type       := c.DIM_TYPE;
            v_expand_dim_name       := c.DIM_NAME;
            v_expand_dim_f_dtype    := c.DIM_DATA_TYPE;
            v_expand_dim_e_disp_fid := c.DIM_DISPLAY_FLD_ID;
            v_expand_dim_e_disp_bk  := c.DIM_DISPLAY_ENTITY_BK;
        END IF;

        IF (c.DIM_VALUE IS NOT NULL)
        THEN
            v_parent_filter := v_parent_filter||CASE WHEN v_parent_filter IS NOT NULL THEN CHR(10)||'AND ' ELSE NULL END
                ||'ALL_COMB.'||c.DIM_NAME||' = '||PLANNING_MODELS.FORMAT_CONSTANT_VALUE(pi_dim_type        => c.DIM_TYPE
                                                                                       ,pi_dim_data_type   => c.DIM_DATA_TYPE
                                                                                       ,pi_dim_value       => c.DIM_VALUE);
        END IF;
    END LOOP;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_expand_dim_name), '<value>', v_stamp);

     GET_REBUILT_FROM_CLAUSE(PI_TU_SELECT         => v_tu_join,
                               PI_TU_COLUMNS        => v_tu_cols,
                               PI_ORIG_FROM_CLAUSE  => pi_from_clause,
                               PI_TABLE_NAME        => v_table_name,
                               PI_DIM_TYPE          => 8,
                               PO_FROM_CLAUSE       => v_rebuilt_from_clause);
    IF (v_expand_dim_type = 'ENTITY')
    THEN
        -- get bk
        SELECT   ET.TABLES_PHYSICAL_NAME
                ,ETC_BK.TC_PHYSICAL_NAME
                ,F.FLD_DATA_TYPE
                ,ETC_BK.TC_IS_NULLABLE
                ,PLANNING_MODELS.FORMAT_COLUMN_FOR_DISPLAY(pi_col_name          => ETC_BK.TC_PHYSICAL_NAME
                                                          ,pi_col_data_type     => F.FLD_DATA_TYPE
                                                          ,pi_col_length        => NVL(ETC_BK.TC_FLD_OVERRIDDEN_LENGTH, F.FLD_LENGTH)
                                                          ,pi_col_th_separator  => F.FLD_DISPLAY_THOUSAND_SEPARATOR
                                                          ,pi_col_percent       => F.FLD_DISPLAY_AS_PERCENT
                                                          ,pi_col_period_prefix => CASE WHEN F.FLD_DATA_TYPE = 8 THEN 'PR' ELSE NULL END
                                                          ,pi_session_separator => v_decimal_separator)
        INTO     v_e_table
                ,v_e_bk_colname
                ,v_e_bk_dtype
                ,v_e_bk_null
                ,v_e_bk_format
        FROM    ENTITIES                    E
                LEFT JOIN TABLES            ET ON E.ENTITY_TABLES_ID = ET.TABLES_ID
                LEFT JOIN TABLE_COLUMNS     ETC_BK ON E.ENTITY_TABLES_ID = ETC_BK.TC_TABLES_ID AND ETC_BK.TC_LOGIC_TYPE IN (1, 5)
                LEFT JOIN FIELDS            F ON ETC_BK.TC_FLD_ID = F.FLD_ID
        WHERE   E.ENTITY_ID = v_expand_dim_id;

        -- for old preconditions where display field was not yet populated in the xml - take as default the entity BK as display
        -- else get info about display field
        IF (v_expand_dim_e_disp_fid IS NULL)
        THEN
            v_e_disp_colname    := v_e_bk_colname;
            v_e_disp_dtype      := v_e_bk_dtype;
            v_e_disp_null       := v_e_bk_null;
            v_e_disp_format     := v_e_bk_format;
        ELSE
            SELECT   ETC_DISP.TC_PHYSICAL_NAME
                    ,F_DISP.FLD_DATA_TYPE
                    ,ETC_DISP.TC_IS_NULLABLE
                    ,PLANNING_MODELS.FORMAT_COLUMN_FOR_DISPLAY(pi_col_name          => ETC_DISP.TC_PHYSICAL_NAME
                                                              ,pi_col_data_type     => F_DISP.FLD_DATA_TYPE
                                                              ,pi_col_length        => NVL(ETC_DISP.TC_FLD_OVERRIDDEN_LENGTH, F_DISP.FLD_LENGTH)
                                                              ,pi_col_th_separator  => F_DISP.FLD_DISPLAY_THOUSAND_SEPARATOR
                                                              ,pi_col_percent       => F_DISP.FLD_DISPLAY_AS_PERCENT
                                                              ,pi_col_period_prefix => CASE WHEN F_DISP.FLD_DATA_TYPE = 8 THEN 'PR' ELSE NULL END
                                                              ,pi_session_separator => v_decimal_separator)
            INTO     v_e_disp_colname
                    ,v_e_disp_dtype
                    ,v_e_disp_null
                    ,v_e_disp_format
            FROM    ENTITIES                    E
                    LEFT JOIN TABLE_COLUMNS     ETC_DISP ON E.ENTITY_TABLES_ID = ETC_DISP.TC_TABLES_ID AND ETC_DISP.TC_FLD_ID = v_expand_dim_e_disp_fid
                    LEFT JOIN FIELDS            F_DISP ON ETC_DISP.TC_FLD_ID = F_DISP.FLD_ID
            WHERE   E.ENTITY_ID = v_expand_dim_id;
        END IF;

        v_query := 'SELECT '
            ||CASE WHEN pi_parent_id IS NOT NULL THEN ''''||REPLACE(pi_parent_id,'''','''''')||'''||CHR(0)||' ELSE NULL END
            ||'TO_CHAR('||v_expand_dim_name||'.E_INTERNAL_ID) AS CHILD_ID'
            ||', '
            ||CASE WHEN v_expand_dim_e_disp_bk = 1
                   THEN 'CASE WHEN '||v_e_disp_format||' IS NULL THEN '||v_e_bk_format||' ELSE '||v_e_disp_format||'||'' (''||'||v_e_bk_format||'||'')'' END'
                   WHEN v_e_disp_null = 0 THEN v_e_disp_format
                   ELSE 'NVL('||v_e_disp_format||', '||v_e_bk_format||')'
                   END||' AS DISPLAY_VALUE'||CHR(10)
            ||'FROM '||v_e_table||' '||v_expand_dim_name||CHR(10)
                ||CASE WHEN v_e_disp_dtype = 8
                       THEN 'LEFT JOIN TU_PERIODS_RANGE_V PR ON '||v_expand_dim_name||'.'||v_e_disp_colname||' = PR.TUPR_ID'||CHR(10)
                       ELSE NULL END
            ||'WHERE EXISTS (SELECT 1 FROM '
            ||v_rebuilt_from_clause||CHR(10)
            ||' WHERE '||CASE WHEN pi_parent_id IS NOT NULL THEN v_parent_filter||CHR(10)||'AND ' ELSE NULL END
            ||'ALL_COMB.'||v_expand_dim_name||' = '||v_expand_dim_name||'.E_INTERNAL_ID'||CHR(10)
            ||')'||CHR(10)
            ||'ORDER BY '||CASE WHEN v_e_disp_dtype = 8 THEN 'PR.TUPR_RANGE_NUMBER'
                                ELSE v_expand_dim_name||'.'||v_e_disp_colname END
            ||CASE WHEN (v_expand_dim_e_disp_bk = 1 OR v_e_disp_null <> 0)
                        AND v_e_disp_colname <> v_e_bk_colname
                   THEN ', '||v_expand_dim_name||'.'||v_e_bk_colname
                   ELSE NULL END;

        /*  SELECT pi_parent_id||CHR(0)||E4330835.E_INTERNAL_ID AS CHILD_ID, E4330835.F4330839 AS DISPLAY_VALUE
            FROM T4330845 E4330835
            WHERE EXISTS (SELECT 1 FROM (QUERY_FILTERED) ALL_COMB
                          WHERE <   ALL_COMB.E4330835 = 1 AND
                                    ALL_COMB.F330835 = 456 AND
                                    ALL_COMB.F234335 = 'Actuals' AND
                                 >
                                ALL_COMB.E4330835 = E4330835.E_INTERNAL_ID)
            ORDER BY E4330835.F4330839
        */

    /* if the dimension to expand is a field then as of now they can only be the period and SCENARIO
       which cannot hold NULL values */
    ELSE

        v_query := 'SELECT '
            ||CASE WHEN pi_parent_id IS NOT NULL THEN ''''||REPLACE(pi_parent_id,'''','''''')||'''||CHR(0)||' ELSE NULL END
            ||'TO_CHAR(CHILD_ID) AS CHILD_ID, TO_CHAR(DISPLAY_VALUE) AS DISPLAY_VALUE'||CHR(10)
            ||'FROM (SELECT DISTINCT ALL_COMB.'||v_expand_dim_name||' AS CHILD_ID, '
            ||CASE WHEN v_expand_dim_f_dtype = 8 THEN v_expand_dim_name||'.TUPR_PERIOD_RANGE_NAME'
                   ELSE 'ALL_COMB.'||v_expand_dim_name END||' AS DISPLAY_VALUE, '
            ||CASE WHEN v_expand_dim_f_dtype = 8 THEN v_expand_dim_name||'.TUPR_RANGE_NUMBER'
                   --WHEN v_expand_dim_name = 'SCENARIO' THEN v_expand_dim_name||'.SPMS_ORDER'
                   ELSE 'ALL_COMB.'||v_expand_dim_name END||' AS DISPLAY_ORDER'||CHR(10)
            ||'FROM '||v_rebuilt_from_clause||CHR(10)
            ||CASE WHEN v_expand_dim_f_dtype = 8
                   THEN 'INNER JOIN TU_PERIODS_RANGE_V '||v_expand_dim_name||' ON ALL_COMB.'||v_expand_dim_name||' = '||v_expand_dim_name||'.TUPR_ID'||CHR(10)
                   --WHEN v_expand_dim_name = 'SCENARIO'
                   --THEN 'INNER JOIN SPM_SCENARIOS '||v_expand_dim_name||' ON ALL_COMB.'||v_expand_dim_name||' = '||v_expand_dim_name||'.SPMS_NAME AND SPMS_SPM_ID = '||TO_CHAR(v_spm_id)||CHR(10)
                   ELSE NULL END
            ||CASE WHEN pi_parent_id IS NOT NULL THEN 'WHERE '||v_parent_filter||CHR(10) ELSE NULL END
            ||')'||CHR(10)
            ||'ORDER BY DISPLAY_ORDER';

        /*  SELECT DISTINCT pi_parent_id||CHR(0)||ALL_COMB.F432 AS CHILD_ID, ALL_COMB.F432 AS DISPLAY_VALUE
            FROM (QUERY_FILTERED) ALL_COMB
            <WHERE    ALL_COMB.E4330835 = 1 AND
                      ALL_COMB.F330835 = 456 AND
                      ALL_COMB.F234335 = 'Actuals'
            >
            ORDER BY ALL_COMB.F432
        */
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query), 'v_query := <value>', v_stamp);

    RETURN v_query;
END GET_SQL_FOR_PIVOT_STRUCTURE;


/* GET_SQL_FOR_PIVOT_VALUES
-----------------------------------------------------------------------------------------------
History:
    1. 2016.05.30 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SQL_FOR_PIVOT_VALUES
(    pi_view_id             NUMBER
    ,pi_axis_type           NUMBER
    ,pi_max_opposite_level  NUMBER
    ,pi_opp_root_exp_items  TABLETYPE_CHARMAX
    ,pi_from_clause         CLOB
    ,pi_parent_id           VARCHAR2
    ,pi_expanded_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_opposite_dim_list   TABLETYPE_MDL_DIM_PATH_EXP
) RETURN CLOB IS
    v_view_def              CLOB;
    v_use_grouping_sets     NUMBER := 1;
    v_table_id              NUMBER;
    v_row_grandtotals       VARCHAR2(200 CHAR);
    v_col_grandtotals       VARCHAR2(200 CHAR);
    v_table_name            VARCHAR2(30 CHAR);
    v_value_cols            VARCHAR2(32000 CHAR);
    v_value_cols_list       VARCHAR2(32000 CHAR);
    v_expand_dim_name       VARCHAR2(30 CHAR);
    v_opp_first_dim_name    VARCHAR2(30 CHAR);
    v_opp_first_dim_flt     CLOB;
    v_max_opposite_level    NUMBER;
    v_parent_filter         CLOB;
    v_temp                  VARCHAR2(32000 CHAR);
    v_row_clause            VARCHAR2(32000 CHAR);
    v_col_clause            VARCHAR2(32000 CHAR);
    v_group_by_clause       VARCHAR2(32000 CHAR);
    v_gs_group_by           VARCHAR2(32000 CHAR);
    v_gs_group_id           VARCHAR2(32000 CHAR);
    v_query                 CLOB;
    v_stamp                 VARCHAR2(200 CHAR);

    v_tu_join               CLOB;
    v_tu_cols               CLOB;
    v_rebuilt_from_clause   CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_PIVOT_VALUES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_id),               ',pi_view_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_axis_type),             ',pi_axis_type => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_max_opposite_level),    ',pi_max_opposite_level => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_opp_root_exp_items),',pi_opp_root_exp_items => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_from_clause),             ',pi_from_clause => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_parent_id),           ',pi_parent_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_expanded_dim_list), ',pi_expanded_dim_list => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_opposite_dim_list), ',pi_opposite_dim_list => <value>', v_stamp);
    END;

    -- get view properties
    SELECT   OD_DEFINITION
            ,TABLES_ID
            ,TABLES_PHYSICAL_NAME
            ,EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/rows/grandTotalLabel')
            ,EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/columns/grandTotalLabel')
    INTO     v_view_def
            ,v_table_id
            ,v_table_name
            ,v_row_grandtotals
            ,v_col_grandtotals
    FROM    OBJECT_DEFINITIONS
            INNER JOIN TABLE_REFERENCES ON TREF_ID = EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/tableReferenceId')
            INNER JOIN TABLES ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
    WHERE   OD_CONTAINER_ID = pi_view_id;

    -- get values string
    PLANNING_MODELS.GET_AGG_FUNC_CLAUSES
    (    pi_view_def            => v_view_def
        ,pi_table_id            => v_table_id
        ,pi_include_row_hash    => 1
        ,po_value_cols          => v_value_cols
        ,po_value_cols_list     => v_value_cols_list
    );
   -- get time unit joins
    GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_expanded_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    IF v_tu_cols IS NULL THEN
       GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_opposite_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    END IF;
    -- for all dimensions that are parents of the expanded node - build helpful clauses
    FOR c IN
    (   SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER,DIM_VALUE
        FROM    TABLE(pi_expanded_dim_list)
        ORDER BY DIM_ORDER
    )
    LOOP
        -- get first dimension that has not been expanded
        IF (c.DIM_VALUE IS NULL AND v_expand_dim_name IS NULL)
        THEN
            v_expand_dim_name  := c.DIM_NAME;
        END IF;

        IF (c.DIM_VALUE IS NOT NULL)
        THEN
            v_parent_filter := v_parent_filter||CASE WHEN v_parent_filter IS NOT NULL THEN CHR(10)||'AND ' ELSE NULL END
                ||'ALL_COMB.'||c.DIM_NAME||' = '||PLANNING_MODELS.FORMAT_CONSTANT_VALUE(pi_dim_type        => c.DIM_TYPE
                                                                                       ,pi_dim_data_type   => c.DIM_DATA_TYPE
                                                                                       ,pi_dim_value       => c.DIM_VALUE);
        END IF;
    END LOOP;
    GET_REBUILT_FROM_CLAUSE(PI_TU_SELECT         => v_tu_join,
                            PI_TU_COLUMNS        => v_tu_cols,
                            PI_ORIG_FROM_CLAUSE  => pi_from_clause,
                            PI_TABLE_NAME        => v_table_name,
                            PI_DIM_TYPE          => 8,
                            PO_FROM_CLAUSE       => v_rebuilt_from_clause);

    v_query := 'WITH ALL_COMB_FLT AS (SELECT * FROM '
        ||v_rebuilt_from_clause||CHR(10)
        ||CASE WHEN pi_parent_id IS NOT NULL THEN 'WHERE '||v_parent_filter||CHR(10) ELSE NULL END
        ||')'||CHR(10);

    v_temp := CASE WHEN pi_parent_id IS NOT NULL THEN ''''||REPLACE(pi_parent_id,'''','''''')||'''||CHR(0)||' ELSE NULL END
            ||'TO_CHAR(A.'||v_expand_dim_name||')';

    v_row_clause := CASE WHEN pi_axis_type IN (0, 1) THEN v_temp ELSE NULL END;
    v_col_clause := CASE WHEN pi_axis_type = 2 THEN v_temp ELSE NULL END;
    v_group_by_clause := 'A.'||v_expand_dim_name;

    v_max_opposite_level := CASE WHEN pi_axis_type = 0 THEN 1
                                 ELSE pi_max_opposite_level END;

    IF (v_use_grouping_sets <> 1)
    THEN
        -- for all dimensions expanded on the opposite axis
        FOR c IN
        (   SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER
            FROM    TABLE(pi_opposite_dim_list)
            WHERE   DIM_ORDER <= v_max_opposite_level
            ORDER BY DIM_ORDER
        )
        LOOP
            IF (c.DIM_ORDER = 1)
            THEN
                v_opp_first_dim_name := c.DIM_NAME;
                v_opp_first_dim_flt := PLANNING_MODELS.FORMAT_CONSTANT_VALUE_LIST(pi_dim_type        => c.DIM_TYPE
                                                                                 ,pi_dim_data_type   => c.DIM_DATA_TYPE
                                                                                 ,pi_list            => pi_opp_root_exp_items);
            END IF;

            v_temp := 'TO_CHAR(A.'||c.DIM_NAME||')';

            IF (pi_axis_type IN (0, 1))
            THEN
                v_col_clause := v_col_clause||CASE WHEN v_col_clause IS NOT NULL THEN '||CHR(0)||' ELSE NULL END||v_temp;
            ELSIF (pi_axis_type = 2)
            THEN
                v_row_clause := v_row_clause||CASE WHEN v_row_clause IS NOT NULL THEN '||CHR(0)||' ELSE NULL END||v_temp;
            END IF;

            v_group_by_clause := v_group_by_clause||', A.'||c.DIM_NAME;

            v_query := v_query||CASE WHEN c.DIM_ORDER > 1 THEN 'UNION ALL'||CHR(10) ELSE NULL END
                ||'SELECT'||CHR(10)
                ||' '||v_row_clause||' AS ROW_ID'||CHR(10)
                ||','||v_col_clause||' AS COLUMN_ID'||CHR(10)
                ||v_value_cols
                ||'FROM ALL_COMB_FLT A'||CHR(10)
                ||CASE  WHEN c.DIM_ORDER > 1 AND v_opp_first_dim_flt IS NOT NULL
                        THEN 'WHERE A.'||v_opp_first_dim_name||' IN ('||v_opp_first_dim_flt||')'||CHR(10)
                        ELSE NULL END
                ||'GROUP BY '||v_group_by_clause||CHR(10);
        END LOOP;

        -- add grand totals
        IF (pi_axis_type = 0)
        THEN
            IF (v_col_grandtotals IS NOT NULL)
            THEN
                v_query := v_query||'UNION ALL'||CHR(10)
                    ||'SELECT'||CHR(10)
                    ||' TO_CHAR(A.'||v_expand_dim_name||') AS ROW_ID'||CHR(10)
                    ||',''GT'' AS COLUMN_ID'||CHR(10)
                    ||v_value_cols
                    ||'FROM ALL_COMB_FLT A'||CHR(10)
                    ||'GROUP BY A.'||v_expand_dim_name||CHR(10);
            END IF;

            IF (v_row_grandtotals IS NOT NULL)
            THEN
                v_query := v_query||'UNION ALL'||CHR(10)
                    ||'SELECT'||CHR(10)
                    ||' ''GT'' AS ROW_ID'||CHR(10)
                    ||',TO_CHAR(A.'||v_opp_first_dim_name||') AS COLUMN_ID'||CHR(10)
                    ||v_value_cols
                    ||'FROM ALL_COMB_FLT A'||CHR(10)
                    ||'GROUP BY A.'||v_opp_first_dim_name||CHR(10);
            END IF;

            IF (v_col_grandtotals IS NOT NULL AND v_row_grandtotals IS NOT NULL)
            THEN
                v_query := v_query||'UNION ALL'||CHR(10)
                    ||'SELECT'||CHR(10)
                    ||' ''GT'' AS ROW_ID'||CHR(10)
                    ||',''GT'' AS COLUMN_ID'||CHR(10)
                    ||v_value_cols
                    ||'FROM ALL_COMB_FLT A'||CHR(10);
            END IF;
        ELSIF (pi_axis_type = 1 AND v_col_grandtotals IS NOT NULL)
        THEN
            v_query := v_query||'UNION ALL'||CHR(10)
                ||'SELECT'||CHR(10)
                ||' '''||REPLACE(pi_parent_id,'''','''''')||'''||CHR(0)||TO_CHAR(A.'||v_expand_dim_name||') AS ROW_ID'||CHR(10)
                ||',''GT'' AS COLUMN_ID'||CHR(10)
                ||v_value_cols
                ||'FROM ALL_COMB_FLT A'||CHR(10)
                ||'GROUP BY A.'||v_expand_dim_name||CHR(10);
        ELSIF (pi_axis_type = 2 AND v_row_grandtotals IS NOT NULL)
        THEN
            v_query := v_query||'UNION ALL'||CHR(10)
                ||'SELECT'||CHR(10)
                ||' ''GT'' AS ROW_ID'||CHR(10)
                ||','''||REPLACE(pi_parent_id,'''','''''')||'''||CHR(0)||TO_CHAR(A.'||v_expand_dim_name||') AS COLUMN_ID'||CHR(10)
                ||v_value_cols
                ||'FROM ALL_COMB_FLT A'||CHR(10)
                ||'GROUP BY A.'||v_expand_dim_name||CHR(10);
        END IF;
    ELSE
        -- if initial expansion
        IF (pi_axis_type = 0)
        THEN
            -- get first dimension on the opposite axis
            FOR c IN
            (   SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER
                FROM    TABLE(pi_opposite_dim_list)
                WHERE   DIM_ORDER = 1
                ORDER BY DIM_ORDER
            )
            LOOP
                v_opp_first_dim_name := c.DIM_NAME;
            END LOOP;

            v_gs_group_by := '(A.'||v_expand_dim_name||',A.'||v_opp_first_dim_name||')'||CHR(10);

            IF (v_col_grandtotals IS NOT NULL)
            THEN
                v_gs_group_by := v_gs_group_by||',(A.'||v_expand_dim_name||')'||CHR(10);
            END IF;

            IF (v_row_grandtotals IS NOT NULL)
            THEN
                v_gs_group_by := v_gs_group_by||',(A.'||v_opp_first_dim_name||')'||CHR(10);
            END IF;

            IF (v_col_grandtotals IS NOT NULL AND v_row_grandtotals IS NOT NULL)
            THEN
                v_gs_group_by := v_gs_group_by||',()'||CHR(10);
            END IF;

            v_query := v_query||'SELECT'||CHR(10)
                ||' CASE WHEN GROUPING_ID IN (0, 1) THEN TO_CHAR(A.'||v_expand_dim_name||') ELSE ''GT'' END AS ROW_ID'||CHR(10)
                ||',CASE WHEN GROUPING_ID IN (0, 2) THEN TO_CHAR(A.'||v_opp_first_dim_name||') ELSE ''GT'' END AS COLUMN_ID'||CHR(10)
                ||v_value_cols_list
                ||'FROM ('||CHR(10)
                ||'SELECT A.'||v_expand_dim_name||',A.'||v_opp_first_dim_name||CHR(10)
                ||v_value_cols
                ||',GROUPING_ID(A.'||v_expand_dim_name||',A.'||v_opp_first_dim_name||') AS GROUPING_ID'||CHR(10)
                ||'FROM ALL_COMB_FLT A'||CHR(10)
                ||'GROUP BY GROUPING SETS ('||CHR(10)
                ||v_gs_group_by
                ||')) A'||CHR(10);

        -- expand a node row/column
        ELSE
            -- for all dimensions expanded on the opposite axis
            FOR c IN
            (   SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER,COUNT(*) OVER (PARTITION BY NULL) DIM_COUNT
                FROM    TABLE(pi_opposite_dim_list)
                WHERE   DIM_ORDER <= v_max_opposite_level
                ORDER BY DIM_ORDER
            )
            LOOP
                IF (c.DIM_ORDER = 1)
                THEN
                    v_opp_first_dim_name := c.DIM_NAME;
                    v_opp_first_dim_flt := PLANNING_MODELS.FORMAT_CONSTANT_VALUE_LIST(pi_dim_type        => c.DIM_TYPE
                                                                                     ,pi_dim_data_type   => c.DIM_DATA_TYPE
                                                                                     ,pi_list            => pi_opp_root_exp_items);
                END IF;

                v_temp := 'TO_CHAR(A.'||c.DIM_NAME||')';

                IF (pi_axis_type = 1)
                THEN
                    v_col_clause := v_col_clause||CASE WHEN v_col_clause IS NOT NULL THEN '||CHR(0)||' ELSE NULL END||v_temp;
                    IF (c.DIM_ORDER > 1)
                    THEN
                        v_gs_group_id := v_gs_group_id||'WHEN GROUPING_ID = '||TO_CHAR(POWER(2, c.DIM_COUNT - c.DIM_ORDER) - 1)||' THEN '||v_col_clause||CHR(10);
                    END IF;
                ELSIF (pi_axis_type = 2)
                THEN
                    v_row_clause := v_row_clause||CASE WHEN v_row_clause IS NOT NULL THEN '||CHR(0)||' ELSE NULL END||v_temp;
                    IF (c.DIM_ORDER > 1)
                    THEN
                        v_gs_group_id := v_gs_group_id||'WHEN GROUPING_ID = '||TO_CHAR(POWER(2, c.DIM_COUNT - c.DIM_ORDER) - 1)||' THEN '||v_row_clause||CHR(10);
                    END IF;
                END IF;

                v_group_by_clause := v_group_by_clause||', A.'||c.DIM_NAME;

                IF (c.DIM_ORDER > 1)
                THEN
                    v_gs_group_by := v_gs_group_by||CASE WHEN v_gs_group_by IS NOT NULL THEN CHR(10)||',' ELSE ' ' END
                        ||'('||v_group_by_clause||')';
                END IF;

                IF (c.DIM_ORDER = 1)
                THEN
                    v_query := v_query||'SELECT'||CHR(10)
                        ||' '||CASE WHEN pi_axis_type = 2 THEN 'CASE WHEN GROUPING_ID('||v_group_by_clause||') = 1 THEN ''GT'' ELSE '||v_row_clause||' END'
                                    ELSE v_row_clause END||' AS ROW_ID'||CHR(10)

                        ||','||CASE WHEN pi_axis_type = 1 THEN 'CASE WHEN GROUPING_ID('||v_group_by_clause||') = 1 THEN ''GT'' ELSE '||v_col_clause||' END'
                                    ELSE v_col_clause END||' AS COLUMN_ID'||CHR(10)
                        ||v_value_cols
                        ||'FROM ALL_COMB_FLT A'||CHR(10)
                        ||'GROUP BY GROUPING SETS (('||v_group_by_clause||')'
                        ||CASE WHEN    (pi_axis_type = 1 AND v_col_grandtotals IS NOT NULL)
                                    OR (pi_axis_type = 2 AND v_row_grandtotals IS NOT NULL)
                               THEN ',(A.'||v_expand_dim_name||')'
                               ELSE NULL END
                        ||')'||CHR(10);
                END IF;
            END LOOP;

            IF (v_gs_group_by IS NOT NULL)
            THEN
                IF (pi_axis_type = 1)
                THEN
                    v_col_clause := 'CASE'||CHR(10)||v_gs_group_id||'END';
                ELSIF (pi_axis_type = 2)
                THEN
                    v_row_clause := 'CASE'||CHR(10)||v_gs_group_id||'END';
                END IF;

                v_query := v_query||'UNION ALL'||CHR(10)
                    ||'SELECT'||CHR(10)
                    ||' '||v_row_clause||' AS ROW_ID'||CHR(10)
                    ||','||v_col_clause||' AS COLUMN_ID'||CHR(10)
                    ||v_value_cols_list
                    ||'FROM ('||CHR(10)
                    ||'SELECT'||CHR(10)
                    ||v_group_by_clause||CHR(10)
                    ||v_value_cols
                    ||',GROUPING_ID('||v_group_by_clause||') AS GROUPING_ID'||CHR(10)

                    ||'FROM ALL_COMB_FLT A'||CHR(10)
                    ||CASE  WHEN v_opp_first_dim_flt IS NOT NULL
                            THEN 'WHERE A.'||v_opp_first_dim_name||' IN ('||v_opp_first_dim_flt||')'||CHR(10)
                            ELSE NULL END
                    ||'GROUP BY GROUPING SETS ('||CHR(10)
                    ||v_gs_group_by
                    ||')) A';
            END IF;
        END IF;
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query), 'v_query := <value>', v_stamp);

    RETURN v_query;
END GET_SQL_FOR_PIVOT_VALUES;


/* GET_SQL_FOR_PIVOT_REFRESH
-----------------------------------------------------------------------------------------------
History:
    1. 2017.02.28 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_SQL_FOR_PIVOT_REFRESH
(    pi_view_id             NUMBER
    ,pi_row_exp_max_lvl     NUMBER
    ,pi_row_exp_root_items  TABLETYPE_CHARMAX
    ,pi_row_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_col_exp_max_lvl     NUMBER
    ,pi_col_exp_root_items  TABLETYPE_CHARMAX
    ,pi_col_dim_list        TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_from_clause         CLOB
) RETURN CLOB IS
    v_view_def              CLOB;
    v_table_id              NUMBER;
    v_table_name            VARCHAR2(30 CHAR);
    v_value_cols            VARCHAR2(32000 CHAR);
    v_value_cols_list       VARCHAR2(32000 CHAR);
    v_group_by_col_list     VARCHAR2(32000 CHAR);
    v_group_by_gsets        VARCHAR2(32000 CHAR);
    v_row_grandtotals       VARCHAR2(200 CHAR);
    v_col_grandtotals       VARCHAR2(200 CHAR);
    v_row_first_dim_name    VARCHAR2(30 CHAR);
    v_col_first_dim_name    VARCHAR2(30 CHAR);
    v_row_clause            VARCHAR2(32000 CHAR);
    v_col_clause            VARCHAR2(32000 CHAR);
    v_row_grouping_value    VARCHAR2(32000 CHAR);
    v_col_grouping_value    VARCHAR2(32000 CHAR);
    v_row_gset_list         VARCHAR2(32000 CHAR);
    v_col_gset_list         VARCHAR2(32000 CHAR);
    v_row_idx               PLS_INTEGER;
    v_col_idx               PLS_INTEGER;
    v_query                 CLOB;
    v_filter                CLOB;
    v_stamp                 VARCHAR2(200 CHAR);


    v_tu_join               CLOB;
    v_tu_cols               CLOB;
    v_rebuilt_from_clause   CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_PIVOT_REFRESH - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_id),               ',pi_view_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_row_exp_max_lvl),       ',pi_row_exp_max_lvl => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_row_exp_root_items),',pi_row_exp_root_items => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_row_dim_list),      ',pi_row_dim_list => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_col_exp_max_lvl),       ',pi_col_exp_max_lvl => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_col_exp_root_items),',pi_col_exp_root_items => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_col_dim_list),      ',pi_col_dim_list => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_from_clause),             ',pi_from_clause => <value>', v_stamp);
    END;

    -- get view properties
    SELECT   OD_DEFINITION
            ,TABLES_ID
            ,TABLES_PHYSICAL_NAME
            ,EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/rows/grandTotalLabel')
            ,EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/columns/grandTotalLabel')
    INTO     v_view_def
            ,v_table_id
            ,v_table_name
            ,v_row_grandtotals
            ,v_col_grandtotals
    FROM    OBJECT_DEFINITIONS
            INNER JOIN TABLE_REFERENCES ON TREF_ID = EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/tableReferenceId')
            INNER JOIN TABLES ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
    WHERE   OD_CONTAINER_ID = pi_view_id;
    --
    -- get time unit joins
    GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_row_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    IF v_tu_cols IS NULL THEN
       GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_col_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    END IF;
    -- get values string
    PLANNING_MODELS.GET_AGG_FUNC_CLAUSES
    (    pi_view_def            => v_view_def
        ,pi_table_id            => v_table_id
        ,pi_include_row_hash    => 1
        ,po_value_cols          => v_value_cols
        ,po_value_cols_list     => v_value_cols_list
    );
    -- get first row dimension
    v_row_first_dim_name := pi_row_dim_list(pi_row_dim_list.FIRST).DIM_NAME;

    -- get first column dimension
    v_col_first_dim_name := pi_col_dim_list(pi_col_dim_list.FIRST).DIM_NAME;

    -- query to refresh all root cells together with grand totals
    BEGIN
        v_group_by_col_list := 'A.'||v_row_first_dim_name||',A.'||v_col_first_dim_name;
        v_group_by_gsets := '('||v_group_by_col_list||')'||CHR(10);

        IF (v_col_grandtotals IS NOT NULL)
        THEN
            v_group_by_gsets := v_group_by_gsets||',(A.'||v_row_first_dim_name||')'||CHR(10);
        END IF;

        IF (v_row_grandtotals IS NOT NULL)
        THEN
            v_group_by_gsets := v_group_by_gsets||',(A.'||v_col_first_dim_name||')'||CHR(10);
        END IF;

        IF (v_col_grandtotals IS NOT NULL AND v_row_grandtotals IS NOT NULL)
        THEN
            v_group_by_gsets := v_group_by_gsets||',()'||CHR(10);
        END IF;

     GET_REBUILT_FROM_CLAUSE(PI_TU_SELECT         => v_tu_join,
                            PI_TU_COLUMNS        => v_tu_cols,
                            PI_ORIG_FROM_CLAUSE  => pi_from_clause,
                            PI_TABLE_NAME        => v_table_name,
                            PI_DIM_TYPE          => 8,
                            PO_FROM_CLAUSE       => v_rebuilt_from_clause);

        v_query := 'WITH ALL_COMB_FLT AS (SELECT * FROM '
            ||v_rebuilt_from_clause
            ||')'||CHR(10)
            ||'SELECT'||CHR(10)
            ||' CASE WHEN GROUPING_ID IN (0, 1) THEN TO_CHAR(A.'||v_row_first_dim_name||') ELSE ''GT'' END AS ROW_ID'||CHR(10)
            ||',CASE WHEN GROUPING_ID IN (0, 2) THEN TO_CHAR(A.'||v_col_first_dim_name||') ELSE ''GT'' END AS COLUMN_ID'||CHR(10)
            ||v_value_cols_list
            ||'FROM ('||CHR(10)
            ||'SELECT '||v_group_by_col_list||CHR(10)
            ||v_value_cols
            ||',GROUPING_ID('||v_group_by_col_list||') AS GROUPING_ID'||CHR(10)
            ||'FROM ALL_COMB_FLT A'||CHR(10)
            ||'GROUP BY GROUPING SETS ('||CHR(10)
            ||v_group_by_gsets
            ||')) A'||CHR(10);
    END;

    -- if any root cells are expanded either on row or column then
    -- construct query to refresh more detailed levels only for those cells
    IF (pi_row_exp_max_lvl > 1 OR pi_col_exp_max_lvl > 1)
    THEN
        -- reset variables that were also used for the first query generation
        v_group_by_col_list := NULL;
        v_group_by_gsets := NULL;
        v_row_clause := 'CASE'||CHR(10);
        v_col_clause := 'CASE'||CHR(10);

        -- build the total list of columns to group by: row dimensions<max expanded level + col dimensions<max expanded level
        BEGIN
            FOR v_idx IN pi_row_dim_list.FIRST..pi_row_exp_max_lvl
            LOOP
                v_group_by_col_list := v_group_by_col_list||',A.'||pi_row_dim_list(v_idx).DIM_NAME;
            END LOOP;

            FOR v_idx IN pi_col_dim_list.FIRST..pi_col_exp_max_lvl
            LOOP
                v_group_by_col_list := v_group_by_col_list||',A.'||pi_col_dim_list(v_idx).DIM_NAME;
            END LOOP;

            v_group_by_col_list := SUBSTR(v_group_by_col_list, 2, LENGTH(v_group_by_col_list));
        END;

        -- build the dynamic grouping sets and the ROW_ID/COLUMN_ID values
        -- for every 0 .. pi_row_exp_max_lvl
        --       and every 0 .. pi_col_exp_max_lvl
        BEGIN
            v_row_idx := 0;
            LOOP
                v_row_gset_list := v_row_gset_list||CASE WHEN v_row_idx = 1 THEN  'A.'||pi_row_dim_list(v_row_idx).DIM_NAME
                                                         WHEN v_row_idx > 1 THEN ',A.'||pi_row_dim_list(v_row_idx).DIM_NAME
                                                         ELSE NULL END;
                v_col_gset_list := NULL;

                -- build ROW_ID
                BEGIN
                    v_row_grouping_value := v_row_grouping_value||CASE WHEN v_row_idx = 1 THEN           'TO_CHAR(A.'||pi_row_dim_list(v_row_idx).DIM_NAME||')'
                                                                       WHEN v_row_idx > 1 THEN '||CHR(0)||TO_CHAR(A.'||pi_row_dim_list(v_row_idx).DIM_NAME||')'
                                                                       ELSE NULL END;

                    v_row_clause := v_row_clause
                        ||'WHEN TRUNC(GROUPING_ID / '||TO_CHAR(POWER(2, pi_col_exp_max_lvl))||') = '||TO_CHAR(POWER(2, pi_row_exp_max_lvl - v_row_idx) - 1)
                        ||' THEN '||CASE WHEN v_row_idx > 0 THEN v_row_grouping_value
                                                         ELSE '''GT''' END
                        ||CHR(10);
                END;

                v_col_idx := 0;
                LOOP
                    v_col_gset_list := v_col_gset_list||CASE WHEN v_col_idx = 1 THEN  'A.'||pi_col_dim_list(v_col_idx).DIM_NAME
                                                             WHEN v_col_idx > 1 THEN ',A.'||pi_col_dim_list(v_col_idx).DIM_NAME
                                                             ELSE NULL END;

                    -- build COLUMN_ID
                    IF (v_row_idx = 0)
                    THEN
                        v_col_grouping_value := v_col_grouping_value||CASE WHEN v_col_idx = 1 THEN           'TO_CHAR(A.'||pi_col_dim_list(v_col_idx).DIM_NAME||')'
                                                                           WHEN v_col_idx > 1 THEN '||CHR(0)||TO_CHAR(A.'||pi_col_dim_list(v_col_idx).DIM_NAME||')'
                                                                           ELSE NULL END;

                        v_col_clause := v_col_clause
                            ||'WHEN MOD(GROUPING_ID, '||TO_CHAR(POWER(2, pi_col_exp_max_lvl))||') = '||TO_CHAR(POWER(2, pi_col_exp_max_lvl - v_col_idx) - 1)
                            ||' THEN '||CASE WHEN v_col_idx > 0 THEN v_col_grouping_value
                                                             ELSE '''GT''' END
                            ||CHR(10);
                    END IF;

                    -- build grouping sets
                    -- ignore combinations at the root cells
                    IF NOT (   (v_row_idx = 0 AND v_col_idx = 0)
                            OR (v_row_idx = 0 AND v_col_idx = 1)
                            OR (v_row_idx = 1 AND v_col_idx = 0)
                            OR (v_row_idx = 1 AND v_col_idx = 1)
                            )
                    THEN
                        v_group_by_gsets := v_group_by_gsets
                            ||CASE WHEN v_group_by_gsets IS NULL THEN ' ' ELSE ',' END
                            ||'('||v_row_gset_list
                            ||CASE WHEN v_row_idx > 0 AND v_col_idx > 0 THEN '    ,' ELSE NULL END
                            ||v_col_gset_list||')'||CHR(10);
                    END IF;

                    v_col_idx := v_col_idx + 1;
                    EXIT WHEN v_col_idx > pi_col_exp_max_lvl;
                END LOOP;

                v_row_idx := v_row_idx + 1;
                EXIT WHEN v_row_idx > pi_row_exp_max_lvl;
            END LOOP;
        END;

        v_row_clause := v_row_clause||'END';
        v_col_clause := v_col_clause||'END';

        v_filter := PLANNING_MODELS.GET_ROOT_CELL_FILTER
                    (    pi_row_exp_dim_list    => pi_row_dim_list
                        ,pi_row_exp_root_items  => pi_row_exp_root_items
                        ,pi_col_exp_dim_list    => pi_col_dim_list
                        ,pi_col_exp_root_items  => pi_col_exp_root_items
                    );

        v_query := v_query||'UNION ALL'||CHR(10)
            ||'SELECT'||CHR(10)
            ||' '||v_row_clause||' AS ROW_ID'||CHR(10)
            ||','||v_col_clause||' AS COLUMN_ID'||CHR(10)
            ||v_value_cols_list
            ||'FROM ('||CHR(10)
            ||'SELECT'||CHR(10)
            ||v_group_by_col_list||CHR(10)
            ||v_value_cols
            ||',GROUPING_ID('||v_group_by_col_list||') AS GROUPING_ID'||CHR(10)
            ||'FROM ALL_COMB_FLT A'||CHR(10)
            ||v_filter
            ||'GROUP BY GROUPING SETS ('||CHR(10)
            ||v_group_by_gsets
            ||')) A';

        /* example of pivot view

        -- row dimensions that were expanded to a max of lvl 2

        TABLETYPE_MDL_DIM_PATH_EXP(
                                            dim_id      , dim_type    , dim_name      , dim_data_type   , dim_order , dim_display_fld_id, dim_display_entity_bk ,dim_value
             OBJTYPE_MDL_DIM_PATH_EXP(        4284896   ,'ENTITY'     ,'E4284896'     ,NULL             ,1          ,4284920            ,0                      ,NULL    )
            ,OBJTYPE_MDL_DIM_PATH_EXP(        4284899   ,'ENTITY'     ,'E4284899'     ,NULL             ,2          ,4284921            ,0                      ,NULL    )
            ,OBJTYPE_MDL_DIM_PATH_EXP(        4284902   ,'ENTITY'     ,'E4284902'     ,NULL             ,3          ,4284923            ,1                      ,NULL    ))

        -- column dimensions that were expanded to a max of lvl 3

        TABLETYPE_MDL_DIM_PATH_EXP(
                                            dim_id      , dim_type    , dim_name      , dim_data_type   , dim_order , dim_display_fld_id, dim_display_entity_bk ,dim_value
             OBJTYPE_MDL_DIM_PATH_EXP(      4284911     ,'ENTITY'     ,'E4284911'     ,NULL             ,1          ,4285043            ,0                      ,NULL    )
            ,OBJTYPE_MDL_DIM_PATH_EXP(      4284908     ,'ENTITY'     ,'E4284908'     ,NULL             ,2          ,4285042            ,0                      ,NULL    )
            ,OBJTYPE_MDL_DIM_PATH_EXP(      563         ,'FIELD'      ,'F563'         ,8                ,3          ,NULL               ,0                      ,NULL    )
            ,OBJTYPE_MDL_DIM_PATH_EXP(      3437128     ,'FIELD'      ,'SCENARIO'     ,1                ,4          ,NULL               ,0                      ,NULL    ))

        -- this is the final computed sql
        SELECT
             ---------------------------------------------

             CASE WHEN GROUPING(A.E4284896) = 0 AND GROUPING(A.E4284899) = 0 THEN TO_CHAR(A.E4284896)||CHR(0)||TO_CHAR(A.E4284899)
                  WHEN GROUPING(A.E4284896) = 0 AND GROUPING(A.E4284899) = 1 THEN TO_CHAR(A.E4284896)
                  WHEN GROUPING(A.E4284896) = 1 AND GROUPING(A.E4284899) = 1 THEN 'GT'
                  END AS ROW_ID
            ,CASE WHEN GROUPING(A.E4284911) = 0 AND GROUPING(A.E4284908) = 0 AND GROUPING(A.F563) = 0 THEN TO_CHAR(A.E4284911)||CHR(0)||TO_CHAR(A.E4284908)||CHR(0)||TO_CHAR(A.F563)
                  WHEN GROUPING(A.E4284911) = 0 AND GROUPING(A.E4284908) = 0 AND GROUPING(A.F563) = 1 THEN TO_CHAR(A.E4284911)||CHR(0)||TO_CHAR(A.E4284908)
                  WHEN GROUPING(A.E4284911) = 0 AND GROUPING(A.E4284908) = 1 AND GROUPING(A.F563) = 1 THEN TO_CHAR(A.E4284911)
                  WHEN GROUPING(A.E4284911) = 1 AND GROUPING(A.E4284908) = 1 AND GROUPING(A.F563) = 1 THEN 'GT'
                  END AS COLUMN_ID

             ---------------------------------------------
            ,REACHED_QUOTA
            ,GOAL
        FROM (SELECT A.E4284896,A.E4284899,A.E4284911,A.E4284908,A.F563
                    ,ROUND(SUM(A.REACHED_QUOTA), 0) AS REACHED_QUOTA
                    ,ROUND(AVG(A.GOAL), 2) AS GOAL
                    ,GROUPING_ID(A.E4284896,A.E4284899,A.E4284911,A.E4284908,A.F563) AS GROUPING_ID
                FROM ALL_COMB_FLT A
                WHERE -- filter here
                GROUP BY GROUPING SETS (
             ---------------------------------------------
             -- beginning of v_group_by_gsets

                                         (A.E4284896,A.E4284899  ,A.E4284911,A.E4284908,A.F563)
                                        ,(A.E4284896,A.E4284899  ,A.E4284911,A.E4284908)
                                        ,(A.E4284896,A.E4284899  ,A.E4284911)
                                        ,(A.E4284896,A.E4284899)

                                        ,(A.E4284896  ,A.E4284911,A.E4284908,A.F563)
                                        ,(A.E4284896  ,A.E4284911,A.E4284908)
                                      --,(A.E4284896  ,A.E4284911)                  -- this comb is covered by the root cells query: 1, 1
                                      --,(A.E4284896)                               -- this comb is covered by the root cells query: 1, 0

                                        ,(A.E4284911,A.E4284908,A.F563)
                                        ,(A.E4284911,A.E4284908)
                                      --,(A.E4284911)                               -- this comb is covered by the root cells query: 0, 1
                                      --,()                                         -- this comb is covered by the root cells query: 0, 0
            -- end of v_group_by_gsets
            ---------------------------------------------
            )) A
        */
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_query), 'v_query := <value>', v_stamp);

    RETURN v_query;
END GET_SQL_FOR_PIVOT_REFRESH;



/* PIVOT_CAN_GENERATE_EXPORT
-----------------------------------------------------------------------------------------------
History:
    1. 2017.07.17 - Luca, Iulian - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE PIVOT_CAN_GENERATE_EXPORT
  (
   pi_view_id             IN      NUMBER,
   po_tables_id           OUT     NUMBER,
   po_row_count           OUT     NUMBER,
   po_row_versions_sum    OUT     NUMBER,
   po_max_row_identifier  OUT     NUMBER,
   po_object_version      OUT     NUMBER,
   po_definition_version  OUT     NUMBER,
   po_can_generate        OUT     NUMBER
  )
  IS
         v_tables_physical_name               VARCHAR2(32 CHAR);
         v_tables_name                        VARCHAR2(32 CHAR);

         v_gec_row_count                      NUMBER;
         v_gec_row_versions_sum               NUMBER;
         v_gec_max_row_identifier             NUMBER;
         v_gec_object_version                 NUMBER;
         v_gec_definition_version             NUMBER;

         v_stamp                              VARCHAR2(200 CHAR);
  BEGIN
    v_stamp := 'PLANNING_MODELS.PIVOT_CAN_GENERATE_EXPORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
         L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_id), 'pi_view_id := <value>', v_stamp);
    END;

    SELECT     T.TABLES_ID, T.TABLES_PHYSICAL_NAME, T.TABLES_NAME, OD.OD_DEFINITION_VERSION
      INTO     po_tables_id, v_tables_physical_name, v_tables_name, po_definition_version
      FROM OBJECT_DEFINITIONS OD
        INNER JOIN TABLE_REFERENCES TR ON TR.TREF_ID = EXTRACTVALUE(XMLTYPE(OD.OD_DEFINITION), '/pivotView/tableReferenceId')
        INNER JOIN TABLES T ON TR.TREF_DEFINITION_ID = T.TABLES_DEFINITION_ID
      WHERE OD.OD_TYPE = 120 --pivot type
        AND OD.OD_CONTAINER_ID = pi_view_id;


    EXECUTE IMMEDIATE 'SELECT COUNT(1) ROW_COUNT, SUM(ROW_VERSION) ROW_VERSIONS_SUM, MAX(ROW_IDENTIFIER) MAX_ROW_IDENTIFIER
                        FROM ' || v_tables_physical_name INTO po_row_count, po_row_versions_sum, po_max_row_identifier;

    EXECUTE IMMEDIATE 'SELECT OBJECT_VERSION FROM SALES_PLANNING_MODELS WHERE SPM_NAME = ''' || v_tables_name || '''' INTO po_object_version;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_tables_id),                      'po_tables_id := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_tables_physical_name),          'v_tables_physical_name := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(v_tables_name),                   'v_tables_name := <value>', v_stamp);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_row_count),                      'po_row_count := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_row_versions_sum),               'po_row_versions_sum := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_object_version),                 'po_object_version := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_definition_version),             'po_definition_version := <value>', v_stamp);

    SELECT GEC_ROW_COUNT, GEC_ROW_VERSIONS_SUM,  GEC_OBJECT_VERSION,   GEC_DEFINITION_VERSION,   GEC_MAX_ROW_IDENTIFIER
    INTO v_gec_row_count, v_gec_row_versions_sum,v_gec_object_version, v_gec_definition_version, v_gec_max_row_identifier
    FROM GENERATE_EXPORT_CHECK WHERE GEC_VIEW_ID = pi_view_id AND GEC_TABLES_ID = po_tables_id;

    IF v_gec_row_versions_sum <> po_row_versions_sum
      OR v_gec_row_count <> po_row_count
      OR v_gec_object_version <> po_object_version
      OR v_gec_definition_version <> po_definition_version
      OR v_gec_max_row_identifier <> po_max_row_identifier
    THEN
      po_can_generate := 1; -- values changed so we can generate a new export
    ELSE
      po_can_generate := 0; -- values didn't change
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_can_generate), 'po_can_generate := <value>', v_stamp);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN -- if no row is found in GENERATE_EXPORT_CHECK table
        po_can_generate := 1; -- then we can generate a fresh export and pass the parameters to the next procedure for insertion
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(po_can_generate), 'po_can_generate := <value>', v_stamp);

END PIVOT_CAN_GENERATE_EXPORT;



/* UPDATE_CAN_GENERATE_EXPORT
-----------------------------------------------------------------------------------------------
History:
    1. 2017.07.17 - Luca, Iulian - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE UPDATE_CAN_GENERATE_EXPORT
  (
   pi_view_id             IN      NUMBER,
   pi_tables_id           IN      NUMBER,
   pi_row_count           IN      NUMBER,
   pi_row_versions_sum    IN      NUMBER,
   pi_max_row_identifier  IN      NUMBER,
   pi_object_version      IN      NUMBER,
   pi_definition_version  IN      NUMBER
  )
  IS
   v_stamp                              VARCHAR2(200 CHAR);
BEGIN
     v_stamp := 'PLANNING_MODELS.UNDO_CAN_GENERATE_EXPORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
     BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_id),            'pi_view_id := <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_tables_id),          'pi_tables_id := <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_row_count),          'pi_row_count := <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_row_versions_sum),   'pi_row_versions_sum := <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_object_version),     'pi_object_version := <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_version), 'pi_definition_version := <value>', v_stamp);
     END;

     UPDATE GENERATE_EXPORT_CHECK
        SET GEC_ROW_COUNT = pi_row_count,
            GEC_ROW_VERSIONS_SUM = pi_row_versions_sum,
            GEC_MAX_ROW_IDENTIFIER = pi_max_row_identifier,
            GEC_OBJECT_VERSION = pi_object_version,
            GEC_DEFINITION_VERSION = pi_definition_version
        WHERE GEC_VIEW_ID = pi_view_id AND GEC_TABLES_ID = pi_tables_id;

     IF SQL%ROWCOUNT = 0 THEN
       INSERT INTO GENERATE_EXPORT_CHECK
        (GEC_ID, GEC_VIEW_ID, GEC_TABLES_ID, GEC_ROW_COUNT, GEC_ROW_VERSIONS_SUM, GEC_MAX_ROW_IDENTIFIER,  GEC_OBJECT_VERSION, GEC_DEFINITION_VERSION)
        VALUES
        (UID_SEQUENCE.NEXTVAL, pi_view_id, pi_tables_id, pi_row_count, pi_row_versions_sum, pi_max_row_identifier, pi_object_version, pi_definition_version);
     END IF;
END UPDATE_CAN_GENERATE_EXPORT;




/* GET_SQL_FOR_PIVOT_EXPORT
-----------------------------------------------------------------------------------------------
History:
    1. 2017.05.03 - Dumitriu, Cosmin - created

    -- BE SURE TO MARK THE ISOLATION LEVEL AS SERIALIZABILE
    -- or lock the table/entities
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_PIVOT_EXPORT
(    pi_view_id             IN NUMBER
    ,pi_row_dim_list        IN TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_col_dim_list        IN TABLETYPE_MDL_DIM_PATH_EXP
    ,pi_from_clause         IN CLOB
    ,pio_column_aliases     IN OUT TABLETYPE_NAME_JOIN_MAP
    ,po_queries             OUT TABLETYPE_NAME_QUERY
) IS
    TYPE TREC_ALIAS IS RECORD (ALIAS VARCHAR2(200 CHAR), COLL_INDEX NUMBER);
    TYPE TASSOC_ALIASES IS TABLE OF TREC_ALIAS INDEX BY VARCHAR2(200 CHAR);
    v_view_def              CLOB;
    v_table_id              NUMBER;
    v_table_name            VARCHAR2(30 CHAR);
    v_row_grandtotals       VARCHAR2(200 CHAR);
    v_col_grandtotals       VARCHAR2(200 CHAR);
    v_value_cols            VARCHAR2(32000 CHAR);
    v_value_cols_list       VARCHAR2(32000 CHAR);
    v_column_list           VARCHAR2(32000 CHAR);
    v_column_list_nulls     VARCHAR2(32000 CHAR);
    v_column_list_row       VARCHAR2(32000 CHAR);
    v_column_list_col       VARCHAR2(32000 CHAR);
    v_groupby_list_row      VARCHAR2(32000 CHAR);
    v_groupby_list_col      VARCHAR2(32000 CHAR);
    v_outer_select          VARCHAR2(32000 CHAR);
    v_outer_join            VARCHAR2(32000 CHAR);
    v_outer_order           VARCHAR2(32000 CHAR);
    vrec_alias              TREC_ALIAS;
    vtab_aliases_indexed    TASSOC_ALIASES;
    vtab_column_aliases     TABLETYPE_NAME_JOIN_MAP := TABLETYPE_NAME_JOIN_MAP();
    v_alias_index           VARCHAR2(200 CHAR);
    v_table_alias           VARCHAR2(200 CHAR);
    v_sheet_row_dims_coll   TABLETYPE_MDL_DIM_PATH_EXP := TABLETYPE_MDL_DIM_PATH_EXP();
    v_sheet_col_dims_coll   TABLETYPE_MDL_DIM_PATH_EXP := TABLETYPE_MDL_DIM_PATH_EXP();
    v_sheet_name            VARCHAR2(50 CHAR);
    v_row_idx               PLS_INTEGER;
    v_col_idx               PLS_INTEGER;
    v_query                 CLOB;
    v_query_all_sheet       CLOB;
    vtab_query_coll         TABLETYPE_NAME_PROP_QUERY := TABLETYPE_NAME_PROP_QUERY();
    v_stamp                 VARCHAR2(200 CHAR);

    v_tu_join               CLOB;
    v_tu_cols               CLOB;
    v_rebuilt_from_clause   CLOB;
BEGIN
    v_stamp := 'PLANNING_MODELS.GET_SQL_FOR_PIVOT_EXPORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_id),               ',pi_view_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_row_dim_list),      ',pi_row_dim_list => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_col_dim_list),      ',pi_col_dim_list => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_from_clause),             ',pi_from_clause => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pio_column_aliases),   ',pio_column_aliases => <value>', v_stamp);
    END;

    -- get view properties
    SELECT   OD_DEFINITION
            ,TABLES_ID
            ,TABLES_PHYSICAL_NAME
            ,EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/rows/grandTotalLabel')
            ,EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/columns/grandTotalLabel')
    INTO     v_view_def
            ,v_table_id
            ,v_table_name
            ,v_row_grandtotals
            ,v_col_grandtotals
    FROM    OBJECT_DEFINITIONS
            INNER JOIN TABLE_REFERENCES ON TREF_ID = EXTRACTVALUE(XMLTYPE(OD_DEFINITION), '/pivotView/tableReferenceId')
            INNER JOIN TABLES ON TREF_DEFINITION_ID = TABLES_DEFINITION_ID
    WHERE   OD_CONTAINER_ID = pi_view_id;

    -- get values string
    PLANNING_MODELS.GET_AGG_FUNC_CLAUSES
    (    pi_view_def            => v_view_def
        ,pi_table_id            => v_table_id
        ,pi_include_row_hash    => 0
        ,po_value_cols          => v_value_cols
        ,po_value_cols_list     => v_value_cols_list
    );

    /* create a helping collection that contains aliases indexed by the definition of the columns.
    for an input pio_column_aliases collection of:
        TABLETYPE_NAME_JOIN_MAP(OBJTYPE_NAME_JOIN_MAP(50    ,null  ,null         ,NULL    ,C_0_3EHSS_8CIO)
                               ,OBJTYPE_NAME_JOIN_MAP(60    ,null  ,tupr_tup_id  ,NULL    ,P_0_0_CU)
                               ,OBJTYPE_NAME_JOIN_MAP(60    ,null  ,tupr_year    ,NULL    ,Y_0_0_CU)
                               ,OBJTYPE_NAME_JOIN_MAP(89    ,300   ,null         ,NULL    ,ADF)
                               ,OBJTYPE_NAME_JOIN_MAP(567   ,300   ,tupr_tup_id  ,NULL    ,ADFADSF)
                               ,OBJTYPE_NAME_JOIN_MAP(567   ,300   ,tupr_year    ,NULL    ,ASDF)
                               )
    we would generate:
        vtab_aliases_indexed('50')                  := 'C_0_3EHSS_8CIO' ,1;
        vtab_aliases_indexed('60.tupr_tup_id')      := 'P_0_0_CU'       ,2;
        vtab_aliases_indexed('60.tupr_year')        := 'Y_0_0_CU'       ,3;
        vtab_aliases_indexed('89.300')              := 'ADF'            ,4;
        vtab_aliases_indexed('567.300.tupr_tup_id') := 'ADFADSF'        ,5;
        vtab_aliases_indexed('567.300.tupr_year')   := 'ASDF'           ,6;
    */
    FOR idx IN pio_column_aliases.FIRST..pio_column_aliases.LAST
    LOOP
        v_alias_index := pio_column_aliases(idx).NAME1
                         ||CASE WHEN pio_column_aliases(idx).NAME2 IS NOT NULL THEN '.'||pio_column_aliases(idx).NAME2 ELSE NULL END
                         ||CASE WHEN pio_column_aliases(idx).NAME3 IS NOT NULL THEN '.'||UPPER(pio_column_aliases(idx).NAME3) ELSE NULL END;
        vrec_alias.ALIAS := pio_column_aliases(idx).NAME5;
        vrec_alias.COLL_INDEX := idx;
        vtab_aliases_indexed(v_alias_index) := vrec_alias;
    END LOOP;

    -- iterate through all row dimensions + col dimensions
    -- build necessary help clauses: join + outer select
    FOR c IN
    (   SELECT  DIM_TYPE                                            -- ENTITY/FIELD
               ,DIM_ID                                              -- 200/234/6756 - id of field/entity
               ,DIM_NAME                                            -- E200/F234/SCENARIO - column name as it is in the model table
               ,DIM_DATA_TYPE                   AS FIELD_DATA_TYPE  -- for dim_type = FIELD - the data type: 1 = 'CHARACTER' / 8 = 'PERIOD'
               ,E_T.TABLES_PHYSICAL_NAME        AS ENTITY_TAB_NAME  -- for dim_type = ENTITY - the name of the physical table
               ,E_BK_FLD.FLD_ID                 AS ENTITY_BK_FLD_ID -- for dim_type = ENTITY - the business key field ID
               ,E_BK_FLD.FLD_COLUMN_NAME        AS ENTITY_BK_C_NAME -- for dim_type = ENTITY - the BK column name as it appears in the entity table
               ,E_DISP_FLD.FLD_ID               AS ENTITY_DSP_FLD_ID-- for dim_type = ENTITY - the display field ID - can be equal or different than ENTITY_BK_FLD_ID
               ,E_DISP_FLD.FLD_COLUMN_NAME      AS ENTITY_DSP_C_NAME-- for dim_type = ENTITY - the display field column name as it appears in the entity table - can be equal or different than ENTITY_BK_C_NAME
               ,E_DISP_FLD.FLD_DATA_TYPE        AS ENTITY_DSP_D_TYPE-- for dim_type = ENTITY - the display field data type
        FROM   (SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER,DIM_DISPLAY_FLD_ID,DIM_DISPLAY_ENTITY_BK,DIM_VALUE, 1 AS DIM_AXIS
                FROM    TABLE(pi_row_dim_list)
                UNION ALL
                SELECT  DIM_ID,DIM_TYPE,DIM_NAME,DIM_DATA_TYPE,DIM_ORDER,DIM_DISPLAY_FLD_ID,DIM_DISPLAY_ENTITY_BK,DIM_VALUE, 2 AS DIM_AXIS
                FROM    TABLE(pi_col_dim_list)
                ) DIM_LIST
                LEFT JOIN FIELDS                FLD ON DIM_TYPE = 'FIELD' AND DIM_ID = FLD.FLD_ID
                LEFT JOIN ENTITIES              E ON DIM_TYPE = 'ENTITY' AND DIM_ID = E.ENTITY_ID
                LEFT JOIN TABLE_COLUMNS         E_TC ON E.ENTITY_TABLES_ID = E_TC.TC_TABLES_ID AND E_TC.TC_LOGIC_TYPE IN (1, 5)
                LEFT JOIN TABLES                E_T ON E.ENTITY_TABLES_ID = E_T.TABLES_ID
                LEFT JOIN FIELDS                E_BK_FLD ON E_TC.TC_FLD_ID = E_BK_FLD.FLD_ID
                LEFT JOIN FIELDS                E_DISP_FLD ON DIM_TYPE = 'ENTITY' AND DIM_DISPLAY_FLD_ID = E_DISP_FLD.FLD_ID
        ORDER BY DIM_AXIS, DIM_ORDER
    ) LOOP
        v_column_list_nulls := v_column_list_nulls||',NULL AS '||c.DIM_NAME;

        IF (C.DIM_TYPE = 'ENTITY')
        THEN
            v_outer_join := v_outer_join||CHR(10)||'LEFT JOIN '||C.ENTITY_TAB_NAME||' '||C.DIM_NAME||' ON INTER.'||C.DIM_NAME||' = '||C.DIM_NAME||'.E_INTERNAL_ID';

            -- based on the field to export construct the alias index so that we can find the actual alias
            v_alias_index := TO_CHAR(C.ENTITY_BK_FLD_ID)||'.'||TO_CHAR(C.DIM_ID);
            v_outer_select := v_outer_select||CHR(10)||','||C.DIM_NAME||'.'||C.ENTITY_BK_C_NAME||' AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
            vtab_column_aliases.EXTEND;
            vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                  ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                  ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                  ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                  ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);

            -- we have to display an additional field
            IF (C.ENTITY_BK_FLD_ID <> C.ENTITY_DSP_FLD_ID)
            THEN
                -- the display field is a PERIOD
                IF (C.ENTITY_DSP_D_TYPE = 8)
                THEN
                    v_table_alias := 'P_'||TO_CHAR(C.ENTITY_DSP_FLD_ID)||'_'||TO_CHAR(C.DIM_ID);
                    v_outer_join := v_outer_join||CHR(10)||'LEFT JOIN TU_PERIODS_RANGE_V '||v_table_alias||' ON '||C.DIM_NAME||'.'||C.ENTITY_DSP_C_NAME||' = '||v_table_alias||'.TUPR_ID';
                    v_outer_order := v_outer_order||','||v_table_alias||'.TUPR_RANGE_NUMBER';

                    v_alias_index := TO_CHAR(C.ENTITY_DSP_FLD_ID)||'.'||TO_CHAR(C.DIM_ID)||'.TUPR_TUP_ID';
                    v_outer_select := v_outer_select||CHR(10)||','||v_table_alias||'.TUPR_TUP_ID AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
                    vtab_column_aliases.EXTEND;
                    vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);

                    v_alias_index := TO_CHAR(C.ENTITY_DSP_FLD_ID)||'.'||TO_CHAR(C.DIM_ID)||'.TUPR_YEAR';
                    v_outer_select := v_outer_select||CHR(10)||','||v_table_alias||'.TUPR_YEAR AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
                    vtab_column_aliases.EXTEND;
                    vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);
                -- the display field is a regular field
                ELSE
                    v_outer_order := v_outer_order||','||C.DIM_NAME||'.'||C.ENTITY_DSP_C_NAME;

                    v_alias_index := TO_CHAR(C.ENTITY_DSP_FLD_ID)||'.'||TO_CHAR(C.DIM_ID);
                    v_outer_select := v_outer_select||CHR(10)||','||C.DIM_NAME||'.'||C.ENTITY_DSP_C_NAME||' AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
                    vtab_column_aliases.EXTEND;
                    vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                          ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);
                END IF;
            ELSE
                v_outer_order := v_outer_order||','||C.DIM_NAME||'.'||C.ENTITY_BK_C_NAME;
            END IF;
        ELSE
            IF (C.FIELD_DATA_TYPE = 8) --period
            THEN
                v_table_alias := 'P_'||TO_CHAR(C.DIM_ID);
                v_outer_join := v_outer_join||CHR(10)||'LEFT JOIN TU_PERIODS_RANGE_V '||v_table_alias||' ON INTER.'||C.DIM_NAME||' = '||v_table_alias||'.TUPR_ID';
                v_outer_order := v_outer_order||','||v_table_alias||'.TUPR_RANGE_NUMBER';

                v_alias_index := TO_CHAR(C.DIM_ID)||'.TUPR_TUP_ID';
                v_outer_select := v_outer_select||CHR(10)||','||v_table_alias||'.TUPR_TUP_ID AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
                vtab_column_aliases.EXTEND;
                vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);

                v_alias_index := TO_CHAR(C.DIM_ID)||'.TUPR_YEAR';
                v_outer_select := v_outer_select||CHR(10)||','||v_table_alias||'.TUPR_YEAR AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
                vtab_column_aliases.EXTEND;
                vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);
            ELSE --or scenario
                v_outer_order := v_outer_order||',INTER.'||C.DIM_NAME;

                v_alias_index := TO_CHAR(C.DIM_ID);
                v_outer_select := v_outer_select||CHR(10)||',INTER.'||C.DIM_NAME||' AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
                vtab_column_aliases.EXTEND;
                vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                                      ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);
            END IF;
        END IF;
    END LOOP;

    -- iterate through all numerical inputs/outputs referenced by the pivot view
    -- complete the outer select
    FOR c IN
    (   SELECT   VAL.FIELD_ID
                ,TC.TC_PHYSICAL_NAME AS COLUMN_NAME -- column name as it is in the model table
                ,F.FLD_BUSINESS_NAME AS FIELD_NAME  -- field business name as it should be in the header
                ,VAL.FUNCTION_TYPE                  -- aggregation function used for the field
        FROM    (SELECT FIELD_ID, FUNCTION_TYPE, ROWNUM AS FIELD_ORDER
                 FROM XMLTABLE('/pivotView/values/value' PASSING XMLTYPE(v_view_def) COLUMNS
                         FIELD_ID NUMBER PATH 'fieldId'
                        ,FUNCTION_TYPE NUMBER PATH 'functionType')
                ) VAL
                LEFT JOIN TABLE_COLUMNS TC ON TC.TC_TABLES_ID = v_table_id AND VAL.FIELD_ID = TC.TC_FLD_ID
                LEFT JOIN FIELDS F ON VAL.FIELD_ID = F.FLD_ID
        ORDER BY VAL.FIELD_ORDER
    )
    LOOP
        v_alias_index := TO_CHAR(C.FIELD_ID);
        v_outer_select := v_outer_select||CHR(10)||',INTER.'||C.COLUMN_NAME||' AS "'||vtab_aliases_indexed(v_alias_index).ALIAS||'"';
        vtab_column_aliases.EXTEND;
        vtab_column_aliases(vtab_column_aliases.LAST) := OBJTYPE_NAME_JOIN_MAP(pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME1
                                                                              ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME2
                                                                              ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME3
                                                                              ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME4
                                                                              ,pio_column_aliases(vtab_aliases_indexed(v_alias_index).COLL_INDEX).NAME5);
    END LOOP;

    v_column_list_nulls := v_column_list_nulls||',';
    v_column_list := REPLACE(v_column_list_nulls, 'NULL AS ', '');


    /* for a pivot view with 2 row dimensions and 3 column dimensions the below will be the combinations of group bys

    r1, r2, c1, c2, c3, sum
    ------------------------
                        10
            c1          10
            c1, c2      10
            c1, c2, c3  10
    r1                  10
    r1,     c1          10
    r1,     c1, c2      10
    r1,     c1, c2, c3  10
    r1, r2              10
    r1, r2, c1          10
    r1, r2, c1, c2      10
    r1, r2, c1, c2, c3  10  Leaf */
    -- get time unit joins
    GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_row_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    IF v_tu_cols IS NULL THEN
       GET_TIME_UNIT_STRUCTURE(PI_EXPANDED_DIM_LIST => pi_col_dim_list,
                            PO_TU_SELECT         => v_tu_join,
                            PO_TU_COLUMNS        => v_tu_cols
                            );
    END IF;
     GET_REBUILT_FROM_CLAUSE(PI_TU_SELECT         => v_tu_join,
                            PI_TU_COLUMNS        => v_tu_cols,
                            PI_ORIG_FROM_CLAUSE  => pi_from_clause,
                            PI_TABLE_NAME        => v_table_name,
                            PI_DIM_TYPE          => 8,
                            PO_FROM_CLAUSE       => v_rebuilt_from_clause);

    BEGIN
        -- for every 0 .. pi_row_dim_list.LAST
        v_row_idx := 0;
        v_column_list_row := v_column_list_nulls;
        LOOP
            IF (v_row_idx > 0)
            THEN
                v_column_list_row := REPLACE(v_column_list_row
                                            ,',NULL AS '||pi_row_dim_list(v_row_idx).DIM_NAME||','
                                            ,',A.'||pi_row_dim_list(v_row_idx).DIM_NAME||',');
                v_groupby_list_row := v_groupby_list_row||',A.'||pi_row_dim_list(v_row_idx).DIM_NAME;
                v_sheet_row_dims_coll.EXTEND;
                v_sheet_row_dims_coll(v_sheet_row_dims_coll.LAST) :=  pi_row_dim_list(v_row_idx);
            END IF;

            -- and every 0 .. pi_col_dim_list.LAST
            v_col_idx := 0;
            v_column_list_col     := v_column_list_row;
            v_sheet_col_dims_coll := TABLETYPE_MDL_DIM_PATH_EXP();
            v_groupby_list_col := NULL;
            LOOP
                IF (v_col_idx > 0)
                THEN
                    v_column_list_col := REPLACE(v_column_list_col
                                                ,',NULL AS '||pi_col_dim_list(v_col_idx).DIM_NAME||','
                                                ,',A.'||pi_col_dim_list(v_col_idx).DIM_NAME||',');
                    v_groupby_list_col := v_groupby_list_col||',A.'||pi_col_dim_list(v_col_idx).DIM_NAME;
                    v_sheet_col_dims_coll.EXTEND;
                    v_sheet_col_dims_coll(v_sheet_col_dims_coll.LAST) :=  pi_col_dim_list(v_col_idx);
                END IF;

                -- build a query
                IF NOT (   (v_row_idx = 0 AND v_col_idx = 0)
                        OR (v_row_idx = 0 AND v_row_grandtotals IS NULL)
                        OR (v_col_idx = 0 AND v_col_grandtotals IS NULL))
                THEN
                    IF (v_row_idx = pi_row_dim_list.LAST AND v_col_idx = pi_col_dim_list.LAST)
                    THEN
                        v_sheet_name := 'Leaf';
                    ELSE
                        v_sheet_name := GET_ORDERED_DIMS(PI_ROW_DIMS => v_sheet_row_dims_coll,
                                                         PI_COL_DIMS => v_sheet_col_dims_coll,
                                                         PI_TABLE_ID => v_table_id);

                    END IF;

                    v_query := 'WITH ALL_COMB_FLT AS (SELECT * FROM '
                        ||v_rebuilt_from_clause
                        ||')'||CHR(10)
                        ||', INTER AS'||CHR(10)
                        ||'(SELECT '||LTRIM(RTRIM(v_column_list, ','), ',')||CHR(10)
                        ||v_value_cols_list
                        ||'FROM ('||CHR(10)
                        ||'SELECT '||LTRIM(RTRIM(v_column_list_col, ','), ',')||CHR(10)
                        ||v_value_cols
                        ||'FROM ALL_COMB_FLT A'||CHR(10)
                        ||'GROUP BY '||LTRIM(v_groupby_list_row||v_groupby_list_col, ',')
                        ||') A)'||CHR(10)
                        ||'SELECT '||LTRIM(v_outer_select, CHR(10)||',')||CHR(10)
                        ||'FROM INTER'
                        ||v_outer_join||CHR(10)
                        ||'ORDER BY '||LTRIM(v_outer_order, ',');

                    vtab_query_coll.EXTEND;
                    vtab_query_coll(vtab_query_coll.LAST) := OBJTYPE_NAME_PROP_QUERY(v_sheet_name, TO_CHAR(v_row_idx+v_col_idx), v_query);

                    v_query_all_sheet := v_query_all_sheet||CASE WHEN v_query_all_sheet IS NOT NULL THEN CHR(10)||'UNION ALL'||CHR(10) ELSE NULL END
                        ||'SELECT '||TO_CHAR(v_row_idx+v_col_idx)||' AS PVE_SHEET_ID'||RTRIM(v_column_list, ',')||CHR(10)
                        ||v_value_cols_list
                        ||'FROM ('||CHR(10)
                        ||'SELECT '||LTRIM(RTRIM(v_column_list_col, ','), ',')||CHR(10)
                        ||v_value_cols
                        ||'FROM ALL_COMB_FLT A'||CHR(10)
                        ||'GROUP BY '||LTRIM(v_groupby_list_row||v_groupby_list_col, ',')
                        ||') A';
                END IF;

                v_col_idx := v_col_idx + 1;
                EXIT WHEN v_col_idx > pi_col_dim_list.LAST;
            END LOOP;

            v_row_idx := v_row_idx + 1;
            EXIT WHEN v_row_idx > pi_row_dim_list.LAST;
        END LOOP;
    END;

    -- add All sheet
    BEGIN
        v_sheet_name := 'All';
        v_query := 'WITH ALL_COMB_FLT AS (SELECT * FROM '
            ||v_rebuilt_from_clause
            ||')'||CHR(10)
            ||', INTER AS'||CHR(10)
            ||'('||v_query_all_sheet||')'||CHR(10)
            ||'SELECT '||LTRIM(v_outer_select, CHR(10)||',')||CHR(10)
            ||'FROM INTER'
            ||v_outer_join||CHR(10)
            ||'ORDER BY PVE_SHEET_ID DESC'||v_outer_order;

        vtab_query_coll.EXTEND;
        vtab_query_coll(vtab_query_coll.LAST) := OBJTYPE_NAME_PROP_QUERY(v_sheet_name, TO_CHAR(v_row_idx+v_col_idx), v_query);
    END;

    SELECT OBJTYPE_NAME_QUERY(SHEET_NAME, SHEET_QUERY)
    BULK COLLECT INTO po_queries
    FROM (  SELECT CASE WHEN RN > 1 THEN SUBSTR(SHEET_NAME, 1, 28)||'-'||TO_CHAR(RN-1)
                        ELSE SUBSTR(SHEET_NAME, 1, 28) END AS SHEET_NAME
                  ,SHEET_QUERY
                  ,SHEET_ORDER
            FROM (   SELECT  NAME AS SHEET_NAME
                            ,QUERY AS SHEET_QUERY
                            ,TO_NUMBER(PROP) AS SHEET_ORDER
                            ,ROW_NUMBER() OVER (PARTITION BY SUBSTR(NAME, 1, 28) ORDER BY 1) AS RN
                     FROM   TABLE(vtab_query_coll)
                 )
         )
    ORDER BY SHEET_ORDER DESC;

    pio_column_aliases := vtab_column_aliases;
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pio_column_aliases), 'pio_column_aliases := <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(po_queries), 'po_queries := <value>', v_stamp);
END GET_SQL_FOR_PIVOT_EXPORT;

/* GET_SQL_FOR_MODEL_EXPORT
-----------------------------------------------------------------------------------------------
History:
    1. 2017.07.28 - Tudose, Alexandra - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_SQL_FOR_MODEL_EXPORT
(    PI_SPM_MODEL_ID        IN NUMBER
    ,PI_EXP_MODEL_DIM_LIST  IN TABLETYPE_EXP_MODEL_DIMS
    ,PI_EXP_MODEL_FLD_LIST  IN TABLETYPE_EXP_MODEL_FLDS
    ,PI_FROM_CLAUSE         IN CLOB
    ,PO_QUERY               OUT CLOB
) IS
    V_TABLE_ID             	NUMBER;
    V_TABLE_NAME            VARCHAR2(30 CHAR);
    V_AGG_FLDS_CLAUSE       CLOB;
    V_DIM_FLDS_CLAUSE       CLOB;
    V_GROUPING_SETS         CLOB;
    V_AGG_FUNC              VARCHAR2(32000 CHAR);
    V_TEMP                  VARCHAR2(32000 CHAR);
    V_FIXED_DIMS            VARCHAR2(32000 CHAR);
    V_GROUPING_COLS         VARCHAR2(32000 CHAR);
    V_GR_IXD_COL            VARCHAR2(32000 CHAR);
    V_FIXED_GROUPING_NR     VARCHAR2(1000 CHAR);
    V_STAMP                 VARCHAR2(200 CHAR);

BEGIN
    V_STAMP := 'PLANNING_MODELS.GET_SQL_FOR_MODEL_EXPORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PI_SPM_MODEL_ID),           ',PI_SPM_MODEL_ID => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PI_EXP_MODEL_DIM_LIST), ',PI_EXP_MODEL_DIM_LIST => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PI_EXP_MODEL_FLD_LIST), ',PI_EXP_MODEL_FLD_LIST => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PI_FROM_CLAUSE),              ',PI_FROM_CLAUSE => <value>', V_STAMP);
    END;

    -- get model table properties
    SELECT  TABLES_ID
           ,TABLES_PHYSICAL_NAME
    INTO    V_TABLE_ID
           ,V_TABLE_NAME
    FROM SALES_PLANNING_MODELS
    INNER JOIN TABLES ON TABLES_ID = SPM_TABLE_ID
    WHERE SPM_ID = PI_SPM_MODEL_ID;

    -- get aggregated fields clause
    FOR C IN (SELECT FL.FLD_ID, FL.AGG_TYPE, FL.AUX_FLD_ID
                     ,TC.TC_PHYSICAL_NAME AS COLUMN_NAME
                     ,F.FLD_DATA_TYPE
                     ,COALESCE(TC.TC_FLD_OVERRIDDEN_LENGTH, F.FLD_LENGTH, 0) AS DEC_LENGTH
              FROM TABLE(PI_EXP_MODEL_FLD_LIST) FL
              INNER JOIN TABLE_COLUMNS TC ON TC.TC_FLD_ID = FL.FLD_ID
              INNER JOIN FIELDS F ON F.FLD_ID = FL.FLD_ID
              WHERE TC_TABLES_ID = V_TABLE_ID
             )
    LOOP
        V_TEMP := PLANNING_MODELS.FORMAT_EXPR_FOR_NULL_IN_AGG(pi_expr           => 'FLD'
                                                             ,pi_expr_data_type =>  C.FLD_DATA_TYPE);

        V_AGG_FUNC := CASE C.AGG_TYPE WHEN 1 THEN 'ROUND(SUM(FLD), DEC_LENGTH) AS FLD'
                                      WHEN 2 THEN 'ROUND(AVG(FLD), DEC_LENGTH) AS FLD'
	                                    WHEN 3 THEN 'ROUND(MEDIAN(FLD), DEC_LENGTH) AS FLD'
                                      WHEN 4 THEN 'MIN(FLD) AS FLD'
                                      WHEN 5 THEN 'MAX(FLD) AS FLD'
                                      WHEN 6 THEN 'COUNT(FLD) AS FLD'
                                      WHEN 7 THEN 'COUNT(DISTINCT FLD) AS FLD'
                                      WHEN 8 THEN 'ROUND(STDDEV_POP(FLD), DEC_LENGTH) AS FLD'
                                      WHEN 9 THEN 'ROUND(STDDEV_SAMP(FLD), DEC_LENGTH) AS FLD'
                                      WHEN 10 THEN 'CASE WHEN MIN('||V_TEMP||')=MAX('||V_TEMP||') THEN MIN(FLD) ELSE NULL END AS FLD'
                                      ELSE NULL END;

        V_AGG_FLDS_CLAUSE := V_AGG_FLDS_CLAUSE || ',' || REPLACE(REPLACE(V_AGG_FUNC, 'FLD', C.COLUMN_NAME)
                                                                 ,'DEC_LENGTH'
                                                                 ,TO_CHAR(C.DEC_LENGTH)
                                                                 ) || CHR(10);
    END LOOP;

    -- get dim fields clause
    FOR C IN (SELECT DIM_ID, DIM_NAME, IS_FIXED, IS_ADDITIONAL, ADDITIONAL_ORDER, HAS_SUBTOTAL
              FROM TABLE(PI_EXP_MODEL_DIM_LIST) DL
              ORDER BY IS_ADDITIONAL, ADDITIONAL_ORDER
             )
    LOOP
        V_DIM_FLDS_CLAUSE := V_DIM_FLDS_CLAUSE || (CASE WHEN V_DIM_FLDS_CLAUSE IS NOT NULL THEN ',' ELSE NULL END) || C.DIM_NAME || ' AS ' || C.DIM_NAME;

        IF(NVL(C.IS_FIXED, 0) = 1)
        THEN
            V_FIXED_DIMS := V_FIXED_DIMS || (CASE WHEN V_FIXED_DIMS IS NOT NULL THEN ',' ELSE NULL END) || C.DIM_NAME;
            V_FIXED_GROUPING_NR := V_FIXED_GROUPING_NR || '0';
        END IF;

        V_GROUPING_COLS := V_GROUPING_COLS || (CASE WHEN V_GROUPING_COLS IS NOT NULL THEN '||' ELSE NULL END) || 'GROUPING(' || C.DIM_NAME || ')';
    END LOOP;

    IF (V_FIXED_DIMS IS NOT NULL)
    THEN
        V_GROUPING_SETS := 'GROUPING SETS (('|| V_FIXED_DIMS || ')';
        V_GR_IXD_COL := ',CASE WHEN ' || V_GROUPING_COLS || '=' || RPAD(V_FIXED_GROUPING_NR, PI_EXP_MODEL_DIM_LIST.COUNT, '1') || ' THEN 0 ' || CHR(10);
    END IF;

    -- get GROUP BY
    FOR C IN (SELECT DIM_ID, DIM_NAME, IS_FIXED, IS_ADDITIONAL, ADDITIONAL_ORDER, HAS_SUBTOTAL
              FROM TABLE(PI_EXP_MODEL_DIM_LIST) DL
              WHERE IS_ADDITIONAL = 1
              ORDER BY ADDITIONAL_ORDER
             )
    LOOP
        IF (V_FIXED_DIMS IS NULL)
        THEN
            V_FIXED_DIMS := C.DIM_NAME;
            V_FIXED_GROUPING_NR := '0';
            V_GROUPING_SETS := 'GROUPING SETS (('|| V_FIXED_DIMS || ')';
            V_GR_IXD_COL := ',CASE WHEN ' || V_GROUPING_COLS || '=' || RPAD(V_FIXED_GROUPING_NR, PI_EXP_MODEL_DIM_LIST.COUNT, '1') || ' THEN ' || C.ADDITIONAL_ORDER || ' ' || CHR(10);
        ELSE
            V_FIXED_DIMS := V_FIXED_DIMS || ',' || C.DIM_NAME;
            V_FIXED_GROUPING_NR := V_FIXED_GROUPING_NR || '0';
            V_GROUPING_SETS := V_GROUPING_SETS || ',(' || V_FIXED_DIMS || ')';
            V_GR_IXD_COL := V_GR_IXD_COL || ' WHEN ' || V_GROUPING_COLS || ' = ' || RPAD(V_FIXED_GROUPING_NR, PI_EXP_MODEL_DIM_LIST.COUNT, '1') || ' THEN ' || C.ADDITIONAL_ORDER || ' ' || CHR(10);
        END IF;
    END LOOP;

    V_GR_IXD_COL := V_GR_IXD_COL || ' ELSE -1 END AS GR_IDX ' || CHR(10);

    V_GROUPING_SETS := V_GROUPING_SETS || ')';

    -- get ALL_COMB
    PO_QUERY := 'WITH ALL_COMB AS ('
                || (CASE WHEN PI_FROM_CLAUSE IS NOT NULL THEN PI_FROM_CLAUSE ELSE ('SELECT * FROM ' || V_TABLE_NAME) END)
                || ')' || CHR(10);

    -- final query
    PO_QUERY := PO_QUERY || 'SELECT ' || V_DIM_FLDS_CLAUSE || V_AGG_FLDS_CLAUSE || V_GR_IXD_COL || 'FROM ALL_COMB ' || CHR(10)
                || 'GROUP BY ' || V_GROUPING_SETS;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(PO_QUERY), 'PO_QUERY := <value>', V_STAMP);
END GET_SQL_FOR_MODEL_EXPORT;

/* GET_MODELS_BY_CRITERIA
-----------------------------------------------------------------------------------------------
History:
    1. 2017.08.01 - Tudose, Alexandra - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_MODELS_BY_CRITERIA
(    PI_TIME_UNIT_ID        IN NUMBER
    ,PI_SCENARIO_NAME_LIST  IN TABLETYPE_CHARMAX
    ,PI_EXACT_SCENARIO_NAME IN NUMBER
    ,PI_REL_TBL_ID_LIST     IN TABLETYPE_NUMBER
    ,PI_EXACT_REL_TBL       IN NUMBER
    ,PI_INPUT_FLD_ID_LIST   IN TABLETYPE_NUMBER
    ,PI_EXACT_INPUT_FLD     IN NUMBER
    ,PI_OUTPUT_FLD_ID_LIST  IN TABLETYPE_NUMBER
    ,PI_EXACT_OUTPUT_FLD    IN NUMBER
    ,PO_MODEL_ID_LIST       OUT TABLETYPE_NUMBER
) IS
    V_SCENARIO_FLD_ID       NUMBER;
    V_STAMP                 VARCHAR2(200 CHAR);
    V_SQL                   CLOB;
    V_WITH_CLAUSE           CLOB;
    V_FROM_CLAUSE           CLOB;
    V_JOIN_CLAUSE           CLOB;
    V_WHERE_CLAUSE          CLOB;
    V_MODEL_ID_LIST_TMP1    TABLETYPE_NUMBER;
    V_MODEL_ID_LIST_TMP2    TABLETYPE_NUMBER;
    V_COUNT                 INTEGER;
BEGIN
    V_STAMP := 'PLANNING_MODELS.GET_MODELS_BY_CRITERIA - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(PI_TIME_UNIT_ID),            ',PI_TIME_UNIT_ID => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PI_SCENARIO_NAME_LIST),  ',PI_SCENARIO_NAME_LIST => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PI_REL_TBL_ID_LIST),     ',PI_REL_TBL_ID_LIST => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PI_INPUT_FLD_ID_LIST),   ',PI_INPUT_FLD_ID_LIST => <value>', V_STAMP);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PI_OUTPUT_FLD_ID_LIST),  ',PI_OUTPUT_FLD_ID_LIST => <value>', V_STAMP);
    END;

    SELECT FLD_ID INTO V_SCENARIO_FLD_ID
    FROM FIELDS
    WHERE FLD_COLUMN_NAME = 'SCENARIO';

    V_WHERE_CLAUSE := ' WHERE SPM.SPM_LAST_DEFINED_SUBTAB_INDEX >= 6 ';

    -- filter by PI_TIME_UNIT_ID
    IF (PI_TIME_UNIT_ID IS NOT NULL)
    THEN
        V_WHERE_CLAUSE := V_WHERE_CLAUSE || ' AND SPM.SPM_TIMEUNIT_ID = ' || PI_TIME_UNIT_ID || ' ' || CHR(10);
    END IF;

    -- filter by PI_REL_TBL_ID_LIST
    IF (PI_REL_TBL_ID_LIST IS NOT NULL AND PI_REL_TBL_ID_LIST.COUNT > 0)
    THEN
        -- with
        V_WITH_CLAUSE := V_WITH_CLAUSE
                         || (CASE WHEN V_WITH_CLAUSE IS NOT NULL THEN (CHR(10) || ',') ELSE NULL END)
                         || ' SPME_3 AS (SELECT * FROM SPM_ENTITIES SPME'
                         || (CASE WHEN NVL(PI_EXACT_REL_TBL, 0) = 1 THEN '' ELSE ' WHERE SPME.SPME_DEF_ID IN (SELECT * FROM TABLE(VL_REL_TBL_ID_LIST))' END)
                         || ')' || CHR(10);

        V_WITH_CLAUSE := V_WITH_CLAUSE || ' ,PI_ENT_REL_AGG AS (SELECT LISTAGG(COLUMN_VALUE, '','') WITHIN GROUP(ORDER BY COLUMN_VALUE) AS COLUMN_VALUE_AGG FROM TABLE(VL_REL_TBL_ID_LIST))';

        -- from
        V_FROM_CLAUSE := V_FROM_CLAUSE || (CASE WHEN V_FROM_CLAUSE IS NOT NULL THEN ',' ELSE NULL END) || ' PI_ENT_REL_AGG';

        -- join
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' LEFT JOIN (' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || 'SELECT DISTINCT SPM.SPM_ID ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ',LISTAGG(SPME_3.SPME_DEF_ID, '','') WITHIN GROUP(ORDER BY SPME_3.SPME_DEF_ID) OVER(PARTITION BY SPM.SPM_ID) ENTITY_RELS ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' FROM SALES_PLANNING_MODELS SPM ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' LEFT JOIN SPME_3 ON SPME_3.SPME_SPM_ID = SPM.SPM_ID ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ') E3 ON E3.SPM_ID = SPM.SPM_ID ';

        -- where
        V_WHERE_CLAUSE := V_WHERE_CLAUSE || ' AND E3.ENTITY_RELS = PI_ENT_REL_AGG.COLUMN_VALUE_AGG ' || CHR(10);
    END IF;

    -- filter by PI_INPUT_FLD_ID_LIST
    IF (PI_INPUT_FLD_ID_LIST IS NOT NULL AND PI_INPUT_FLD_ID_LIST.COUNT > 0)
    THEN
        -- with
        V_WITH_CLAUSE := V_WITH_CLAUSE
                         || (CASE WHEN V_WITH_CLAUSE IS NOT NULL THEN (CHR(10) || ',') ELSE NULL END)
                         || ' SPMI_2 AS (SELECT * FROM SPM_INPUTS SPMI'
                         || (CASE WHEN NVL(PI_EXACT_INPUT_FLD, 0) = 1 THEN '' ELSE ' WHERE SPMI.SPMI_FLD_ID IN (SELECT * FROM TABLE(VL_INPUT_FLD_ID_LIST))' END)
                         || ')' || CHR(10);

        V_WITH_CLAUSE := V_WITH_CLAUSE || ' ,PI_INPUT_AGG AS (SELECT LISTAGG(COLUMN_VALUE, '','') WITHIN GROUP(ORDER BY COLUMN_VALUE) AS COLUMN_VALUE_AGG FROM TABLE(VL_INPUT_FLD_ID_LIST))';

        -- from
        V_FROM_CLAUSE := V_FROM_CLAUSE || (CASE WHEN V_FROM_CLAUSE IS NOT NULL THEN ',' ELSE NULL END) || ' PI_INPUT_AGG';

        -- join
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' LEFT JOIN (' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || 'SELECT DISTINCT SPM.SPM_ID ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ', LISTAGG(SPMI_2.SPMI_FLD_ID, '','') WITHIN GROUP(ORDER BY SPMI_2.SPMI_FLD_ID) OVER(PARTITION BY SPM.SPM_ID) INPUTS ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' FROM SALES_PLANNING_MODELS SPM ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' LEFT JOIN SPMI_2 ON SPMI_2.SPMI_SPM_ID = SPM.SPM_ID ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ') E5 ON E5.SPM_ID = SPM.SPM_ID ';

        -- where
        V_WHERE_CLAUSE := V_WHERE_CLAUSE || ' AND E5.INPUTS = PI_INPUT_AGG.COLUMN_VALUE_AGG ' || CHR(10);
    END IF;

    -- filter by PI_OUTPUT_FLD_ID_LIST
    IF (PI_OUTPUT_FLD_ID_LIST IS NOT NULL AND PI_OUTPUT_FLD_ID_LIST.COUNT > 0)
    THEN
        -- with
        V_WITH_CLAUSE := V_WITH_CLAUSE
                         || (CASE WHEN V_WITH_CLAUSE IS NOT NULL THEN (CHR(10) || ',') ELSE NULL END)
                         || ' SPMO_2 AS (SELECT * FROM SPM_OUTPUTS SPMO'
                         || (CASE WHEN NVL(PI_EXACT_OUTPUT_FLD, 0) = 1 THEN '' ELSE ' WHERE SPMO.SPMO_FLD_ID IN (SELECT * FROM TABLE(VL_OUTPUT_FLD_ID_LIST))' END)
                         || ')' || CHR(10);

        V_WITH_CLAUSE := V_WITH_CLAUSE || ' ,PI_OUTPUT_AGG AS (SELECT LISTAGG(COLUMN_VALUE, '','') WITHIN GROUP(ORDER BY COLUMN_VALUE) AS COLUMN_VALUE_AGG FROM TABLE(VL_OUTPUT_FLD_ID_LIST))';

        -- from
        V_FROM_CLAUSE := V_FROM_CLAUSE || (CASE WHEN V_FROM_CLAUSE IS NOT NULL THEN ',' ELSE NULL END) || ' PI_OUTPUT_AGG';

        -- join
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' LEFT JOIN (' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || 'SELECT DISTINCT SPM.SPM_ID ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ', LISTAGG(SPMO_2.SPMO_FLD_ID, '','') WITHIN GROUP(ORDER BY SPMO_2.SPMO_FLD_ID) OVER(PARTITION BY SPM.SPM_ID) OUTPUTS ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' FROM SALES_PLANNING_MODELS SPM ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ' LEFT JOIN SPMO_2 ON SPMO_2.SPMO_SPM_ID = SPM.SPM_ID ' || CHR(10);
        V_JOIN_CLAUSE := V_JOIN_CLAUSE || ') E6 ON E6.SPM_ID = SPM.SPM_ID ';

        -- where
        V_WHERE_CLAUSE := V_WHERE_CLAUSE || ' AND E6.OUTPUTS = PI_OUTPUT_AGG.COLUMN_VALUE_AGG ' || CHR(10);
    END IF;

    -- generate query
    V_SQL := 'BEGIN ' || CHR(10);
    V_SQL := V_SQL || 'DECLARE ' || CHR(10);
    V_SQL := V_SQL || 'VL_SCENARIO_NAME_LIST TABLETYPE_CHARMAX := :PI_SCENARIO_NAME_LIST; ' || CHR(10);
    V_SQL := V_SQL || 'VL_REL_TBL_ID_LIST TABLETYPE_NUMBER := :PI_REL_TBL_ID_LIST; ' || CHR(10);
    V_SQL := V_SQL || 'VL_INPUT_FLD_ID_LIST TABLETYPE_NUMBER := :PI_INPUT_FLD_ID_LIST; ' || CHR(10);
    V_SQL := V_SQL || 'VL_OUTPUT_FLD_ID_LIST TABLETYPE_NUMBER := :PI_OUTPUT_FLD_ID_LIST; ' || CHR(10);
    V_SQL := V_SQL || 'BEGIN ' || CHR(10);

    IF (V_WITH_CLAUSE IS NOT NULL)
    THEN
        V_SQL := V_SQL || ' WITH ' || V_WITH_CLAUSE || ' ' || CHR(10);
    END IF;

    V_SQL := V_SQL || 'SELECT DISTINCT SPM.SPM_ID BULK COLLECT INTO :PO_MODEL_ID_LIST ' || CHR(10);
    V_FROM_CLAUSE := V_FROM_CLAUSE || (CASE WHEN V_FROM_CLAUSE IS NOT NULL THEN ', ' ELSE NULL END) || 'SALES_PLANNING_MODELS SPM ';

    V_SQL := V_SQL || 'FROM ' || V_FROM_CLAUSE || CHR(10) || V_JOIN_CLAUSE || CHR(10) ||  V_WHERE_CLAUSE || ' ;' || CHR(10);

    V_SQL := V_SQL || ' END; ' || CHR(10);
    V_SQL := V_SQL || ' END; ' || CHR(10);

    EXECUTE IMMEDIATE V_SQL USING PI_SCENARIO_NAME_LIST, PI_REL_TBL_ID_LIST, PI_INPUT_FLD_ID_LIST, PI_OUTPUT_FLD_ID_LIST, OUT PO_MODEL_ID_LIST;

    -- PI_SCENARIO_NAME_LIST
    IF (PI_SCENARIO_NAME_LIST IS NOT NULL AND PI_SCENARIO_NAME_LIST.COUNT > 0)
    THEN
        -- get model tables that meet scenario criteria where scenario is defined as a field
        WITH  PI_SCENARIOS_AGG AS (SELECT LISTAGG(COLUMN_VALUE, ',') WITHIN GROUP(ORDER BY COLUMN_VALUE) AS COLUMN_VALUE_AGG FROM TABLE(PI_SCENARIO_NAME_LIST))
              ,SPMS_2 AS (SELECT * FROM SPM_SCENARIOS SPMS
                          WHERE (NVL(PI_EXACT_SCENARIO_NAME, 0) = 1) OR (SPMS.SPMS_NAME IN (SELECT * FROM TABLE(PI_SCENARIO_NAME_LIST)))
                         )
        SELECT SPM.SPM_ID
               BULK COLLECT INTO V_MODEL_ID_LIST_TMP1
        FROM PI_SCENARIOS_AGG, SALES_PLANNING_MODELS SPM
        LEFT JOIN
             (
              SELECT DISTINCT SPM.SPM_ID
                     ,LISTAGG(SPMS_2.SPMS_NAME, ',') WITHIN GROUP(ORDER BY SPMS_2.SPMS_NAME) OVER(PARTITION BY SPM.SPM_ID) SCENARIOS
              FROM SALES_PLANNING_MODELS SPM
              LEFT JOIN SPMS_2 ON SPMS_2.SPMS_SPM_ID = SPM.SPM_ID
              WHERE SPM.SPM_ID IN (SELECT COLUMN_VALUE FROM TABLE(PO_MODEL_ID_LIST))
             ) E1 ON E1.SPM_ID = SPM.SPM_ID
        WHERE SPM.SPM_ID IN (SELECT COLUMN_VALUE FROM TABLE(PO_MODEL_ID_LIST))
			  AND SPM.SPM_SCENARIO_ENTITY_ID IS NULL
              AND E1.SCENARIOS = PI_SCENARIOS_AGG.COLUMN_VALUE_AGG;

        -- get model tables that meet scenario criteria where scenario is selected from an entity table => V_MODEL_ID_LIST_TMP2
        V_MODEL_ID_LIST_TMP2 := TABLETYPE_NUMBER();

        FOR C IN (SELECT SPM.SPM_ID, E.ENTITY_TABLES_ID, TC.TC_PHYSICAL_NAME
                  FROM SALES_PLANNING_MODELS SPM
                  LEFT JOIN ENTITIES E ON E.ENTITY_ID = SPM.SPM_SCENARIO_ENTITY_ID
                  LEFT JOIN TABLE_COLUMNS TC ON TC.TC_TABLES_ID = E.ENTITY_TABLES_ID
                  WHERE SPM.SPM_ID IN (SELECT COLUMN_VALUE
                                       FROM TABLE(PO_MODEL_ID_LIST)
                                       WHERE COLUMN_VALUE NOT IN (SELECT * FROM TABLE(NVL(V_MODEL_ID_LIST_TMP1, TABLETYPE_NUMBER())))
                                      )
                        AND SPM.SPM_SCENARIO_ENTITY_ID IS NOT NULL
                        AND TC.TC_FLD_ID = SPM.SPM_SCENARIO_NAME_FLD_ID
                 )
        LOOP
            EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM T' || C.ENTITY_TABLES_ID || ' WHERE ' || C.TC_PHYSICAL_NAME || ' IN (SELECT * FROM TABLE(:1))'
            INTO V_COUNT USING PI_SCENARIO_NAME_LIST;

            IF (V_COUNT = PI_SCENARIO_NAME_LIST.COUNT)
            THEN
                IF (NVL(PI_EXACT_SCENARIO_NAME, 0) = 0)
                THEN
                   V_MODEL_ID_LIST_TMP2.EXTEND;
                   V_MODEL_ID_LIST_TMP2(V_MODEL_ID_LIST_TMP2.LAST) := C.SPM_ID;
                END IF;

                IF (NVL(PI_EXACT_SCENARIO_NAME, 0) = 1)
                THEN
                    EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM T' || C.ENTITY_TABLES_ID || ' WHERE TO_CHAR(' || C.TC_PHYSICAL_NAME || ') NOT IN (SELECT * FROM TABLE(:1))'
                    INTO V_COUNT USING PI_SCENARIO_NAME_LIST;

                    IF (V_COUNT = 0)
                    THEN
                        V_MODEL_ID_LIST_TMP2.EXTEND;
                        V_MODEL_ID_LIST_TMP2(V_MODEL_ID_LIST_TMP2.LAST) := C.SPM_ID;
                    END IF;
                END IF;
            END IF;
        END LOOP;

        PO_MODEL_ID_LIST := V_MODEL_ID_LIST_TMP1 MULTISET UNION V_MODEL_ID_LIST_TMP2;
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(PO_MODEL_ID_LIST),  ',PO_MODEL_ID_LIST => <value>', V_STAMP);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(V_SQL),                   ',V_SQL => <value>', V_STAMP);

END GET_MODELS_BY_CRITERIA;

END PLANNING_MODELS;
/
