CREATE PACKAGE CREDITING
AS
  -- --------------------------------------------------------------------------
  -- Copyright ? 2012 - 2013 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd.  It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : compensation-product
  -- Module         : crediting
  -- Requester      : Sharma, Pooja
  -- Author         : Vijaywargiya, Abhishek
  -- Create date    : 29-Oct-2013
  -- Reviewer       : Sharma, Pooja
  -- Review date    :
  -- Description    : Package for Crediting
  --ls
  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :CREDITING
  -- Change description :
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC CURSORS START       *******************************
  -- *******************************    PUBLIC CURSORS END         *******************************

  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
  -- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

  -- *******************************    PUBLIC FUNCTIONS START       *******************************
  -- *******************************    PUBLIC FUNCTIONS END         *******************************

  -- *******************************    PUBLIC PROCEDURES START       *******************************
  /********************************************************************************************************************
    * TYPE              : PROCEDURE
    * PROCEDURE NAME    : EVALUATE_CREDITING
    * AUTHOR            : Vijaywargiya, Abhishek
    * REVIEWER          : Sharma, Pooja
    * INPUT PARAMETERS  : PI_CDT_INFO             : Contains Crediting Data Table info
    *                     PI_CAT_INFO             : Contains Crediting Approach Table info
    *                                               CAT = Alignments Table when Approach used to Crediting is: Alignments,
    *                                               else Assignment Table when Approach used to Crediting is: Assignment Table
    *                     PI_CRT_INFO             : Contains Crediting Result Table info
    *                     PI_DATA_ENTITY_INFO     : Contains Data Entity info
    *                     PI_FIELDS_TO_CREDIT     : Contains records for All Fields to Credit
    *                     PI_ADD_FIELDS_TO_CREDIT : Contains records for All Additional Fields to Credit
    *                     PI_RUN_ID               : Run ID used for logging messages
    *
    * OUTPUT PARAMETERS : PO_STATUS               : Output status
    * DESCRIPTION       : Evaluates the Crediting logic and posts in Crediting Result Table if output records are valid; else records the error messages in log.
    * Example           :
    BEGIN
        CREDITING.EVALUATE_CREDITING (
        PI_CDT_INFO               ,
        PI_CAT_INFO               ,
        PI_CRT_INFO               ,
        PI_DATA_ENTITY_INFO       ,
        PI_FIELDS_TO_CREDIT       ,
        PI_ADD_FIELDS_TO_CREDIT   ,
        PI_CRED_CONDITIONS_INFO,
        PI_CRED_CONDITIONS_DETAIL,
        PI_UDT_INFO,
        PI_RUN_ID                 ,
        PO_STATUS,
        PO_IS_CRT_EMPTY,
        PO_IS_UDT_EMPTY);
    END;

    Evaluates the Alignment Logic based on the corresponding Alignment and Aligned Entities and the Conditions.
    *********************************************************************************************************************/

  PROCEDURE EVALUATE_CREDITING
  (
    PI_CDT_INFO                    IN     COLTYPE_CDT_INFO,
    PI_CAT_INFO                    IN     COLTYPE_CAT_INFO,
    PI_CRT_INFO                    IN     COLTYPE_CRT_INFO,
    PI_DATA_ENTITY_INFO            IN     COLTYPE_DATA_ENTITY_INFO,
    PI_FIELDS_TO_CREDIT            IN     COLTYPE_FIELDS_TO_CREDIT,
    PI_ADD_FIELDS_TO_CREDIT        IN     COLTYPE_ADD_FIELDS_TO_CREDIT,
    PI_CRED_CONDITIONS_INFO        IN     COLTYPE_CRED_CONDITIONS_INFO,
    PI_CRED_CONDITIONS_DETAIL      IN     COLTYPE_CRED_CONDITIONS_DETAIL,
    -- PI_UNCREDITED_DATA_TABLE_NAME  IN     VARCHAR2,     /* OF-14723 */
    PI_UDT_INFO                    IN     COLTYPE_UDT_INFO,       /* OF-14723  */
    -- PI_UDT_NAME  IN     VARCHAR2,     /* OF-14723 */
    -- PI_UDT_NON_TECH_COL_LIST          IN CLOB,                /* OF-14723 */
    PI_RUN_ID                      IN     NUMBER,
    PO_STATUS                         OUT NUMBER,
    PO_IS_CRT_EMPTY                OUT NUMBER,   /* OF-16309 */
    PO_IS_UDT_EMPTY                OUT NUMBER    /* OF-16309 */
  );
  PROCEDURE CREDITING_ROLLUP
  (
    PI_CRD_INFO                IN     COLTYPE_CRD_INFO,
    PI_CRT_INFO                IN     COLTYPE_CRT_INFO,
    PI_RTE_INFO                IN     COLTYPE_RTE_INFO,
    PI_HRD_INFO        IN     COLTYPE_HRD_INFO,
    PI_FTR_INFO        IN     COLTYPE_FTR_INFO,
    PI_RRT_INFO    IN     COLTYPE_RRT_INFO,
    PI_NRT_INFO    IN     COLTYPE_NRT_INFO,
    PI_URT_INFO  IN     COLTYPE_URT_INFO,
    PI_RUN_ID IN NUMBER DEFAULT 0, -- ADDED
     PI_date_run_for date default null ,-- if its date for processing period then this will store that value, else it will be null
    PI_period_run_for number ,--- tupr_id for processing period (null in other cases)
   PI_CREDITING_ID IN NUMBER, -- new added parameter for crediting definition id
    PO_STATUS                     OUT NUMBER,
    POUT_PRIMARY_ROWS               OUT NUMBER,
    POUT_NO_ROLLUP_ROWS               OUT NUMBER,
    Pout_No_Match_Rows               Out Number
  );
END CREDITING;
/
