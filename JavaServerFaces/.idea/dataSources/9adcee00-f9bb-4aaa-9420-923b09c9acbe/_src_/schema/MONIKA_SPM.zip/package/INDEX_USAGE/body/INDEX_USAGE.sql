CREATE PACKAGE BODY index_usage AS

  PROCEDURE report_unusable_indexes AS
    v_run_number NUMBER;
    v_max_id     NUMBER;
    v_min_id     NUMBER;
  BEGIN
    /*EXECUTE IMMEDIATE 'alter table UNUSABLE_INDEXES drop column UI_CURRENT_RUN';
    EXECUTE IMMEDIATE 'alter table UNUSABLE_INDEXES add UI_CURRENT_RUN number default 0';*/

    FOR i IN (SELECT table_name, column_name
                FROM user_tab_columns
               WHERE table_name = 'UNUSABLE_INDEXES'
                 AND column_name IN ('UI_CONSECUTIVE_RUN_NEW')) LOOP
      commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'ALTER TABLE UNUSABLE_INDEXES RENAME COLUMN  ' ||
                                                       i.column_name ||
                                                       '  TO  ' ||
                                                       ' UI_CONSECUTIVE_RUN ');
    END LOOP;

    FOR i IN (SELECT table_name, column_name
                FROM user_tab_columns
               WHERE table_name = 'UNUSABLE_INDEXES'
                 AND column_name IN ('UI_CURRENT_RUN_NEW')) LOOP
      commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'ALTER TABLE UNUSABLE_INDEXES RENAME COLUMN  ' ||
                                                       i.column_name ||
                                                       '  TO  ' ||
                                                       ' UI_CURRENT_RUN ');
    END LOOP;

    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'alter table UNUSABLE_INDEXES add UI_CURRENT_RUN_NEW number default 0');
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'alter table UNUSABLE_INDEXES add UI_CONSECUTIVE_RUN_NEW number default 0');

    SELECT MAX(ses_id) INTO v_max_id FROM sql_execution_stats;

    SELECT pr_value
      INTO v_run_number
      FROM properties
     WHERE pr_name = 'INDEX_USAGE_RUN_NUMBER';

    SELECT pr_value
      INTO v_min_id
      FROM properties
     WHERE pr_name = 'INDEX_USAGE_MIN_ID';
    EXECUTE IMMEDIATE 'MERGE INTO UNUSABLE_INDEXES uci
                      USING (SELECT index_name,table_name
                               FROM user_indexes ui
                              WHERE REGEXP_like(ui.table_name, ''^T[0-9]'')
                             MINUS
                             SELECT ses_object_name, null
                               FROM sql_execution_stats
                              WHERE ses_ID > ' ||
                      v_min_id || '
                                AND ses_ID <=  ' ||
                      v_max_id || ') S
                      ON (uci.UI_index_name = S.index_name)
                      WHEN MATCHED THEN
                        UPDATE
                           SET UCI.UI_last_updated_date   = case when UI_CURRENT_RUN=1 then UI_last_updated_date else SYSDATE end,
                               UI_TOTAL_RUN               = UI_TOTAL_RUN + 1,
                               UI_CURRENT_RUN_NEW         = 1,
                               UI_CONSECUTIVE_RUN_NEW     = UI_CONSECUTIVE_RUN + 1
                      WHEN NOT MATCHED THEN
                        INSERT
                          (UCI.UI_ID,
                           UCI.UI_INDEX_NAME,
                           UCI.UI_TABLE_NAME,
                           UCI.UI_CURRENT_RUN_NEW,
                           UCI.UI_CONSECUTIVE_RUN_NEW,
                           UCI.UI_TOTAL_RUN)
                        VALUES
                          (UI_seq.NEXTVAL, S.INDEX_NAME,S.table_name ,1, 1, 1)
                      ';
    --  dbms_output.put_line(sql%rowcount);
    UPDATE properties
       SET pr_value = pr_value + 1
     WHERE pr_name = 'INDEX_USAGE_RUN_NUMBER';

    UPDATE properties
       SET pr_value = v_max_id
     WHERE pr_name = 'INDEX_USAGE_MIN_ID';
    commit;
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'ALTER TABLE UNUSABLE_INDEXES DROP COLUMN UI_CONSECUTIVE_RUN');
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'alter table UNUSABLE_INDEXES drop column UI_CURRENT_RUN');
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'ALTER TABLE UNUSABLE_INDEXES RENAME COLUMN  UI_CONSECUTIVE_RUN_NEW TO  UI_CONSECUTIVE_RUN');
    commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'ALTER TABLE UNUSABLE_INDEXES RENAME COLUMN  UI_CURRENT_RUN_NEW TO  UI_CURRENT_RUN');

  EXCEPTION
    WHEN OTHERS THEN
      FOR i IN (SELECT table_name, column_name
                  FROM user_tab_columns
                 WHERE table_name = 'UNUSABLE_INDEXES'
                   AND column_name IN
                       ('UI_CONSECUTIVE_RUN_NEW', 'UI_CURRENT_RUN_NEW')) LOOP
        commons_ddl_handling.execute_ddl_nolog(pi_ddl => 'alter table ' ||
                                                         i.table_name ||
                                                         ' drop column ' ||
                                                         i.column_name);
      END LOOP;
  END;

  PROCEDURE post_modulewise_ind IS
    v_run_number NUMBER;
  BEGIN

    SELECT pr_value
      INTO v_run_number
      FROM properties
     WHERE pr_name = 'INDEX_USAGE_RUN_NUMBER';

    FOR i IN (SELECT * FROM central_query_repo) LOOP
      EXECUTE IMMEDIATE 'merge into REPORT_UNUSED_INDEXES D USING (SELECT table_name, index_name, def_id, uci.* from (' ||
                        i.cqr_query ||
                        ') d_query LEFT OUTER JOIN UNUSABLE_INDEXES uci ON uci.UI_INDEX_NAME = d_query.index_name)  S
                        ON (S.table_name = D.RUI_TABLE_NAME AND S.index_name = D.RUI_INDEX_NAME AND nvl(S.def_id,-1) = nvl(D.RUI_DEF_ID,-1))
                        WHEN MATCHED THEN
                          UPDATE SET d.RUI_LAST_UPDATED_DATE = SYSDATE, rui_usage_factor = ((s.UI_CONSECUTIVE_RUN*' ||
                        v_run_number || ' *0.5)+s.UI_TOTAL_RUN)/(' ||
                        v_run_number || '+1)
                        WHEN NOT MATCHED THEN
                          INSERT
                            (D.RUI_TABLE_NAME,
                             D.RUI_INDEX_NAME,
                             D.RUI_DEF_ID,
                             D.RUI_CREATE_DATE,
                             D.RUI_LAST_UPDATED_DATE,
                             D.rui_usage_factor)
                          VALUES
                            (S.table_name,
                             S.index_name,
                             S.def_id,
                             SYSDATE,
                             SYSDATE,
                             ((s.UI_CONSECUTIVE_RUN*' ||
                        v_run_number || '*0.5)+s.UI_TOTAL_RUN)/(' ||
                        v_run_number || '+1)
                             )';
    commit;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  PROCEDURE purge_sql_stats IS
    /*v_run_number NUMBER;*/
  BEGIN
    /*SELECT pr_value
      INTO v_run_number
      FROM properties
     WHERE pr_name = 'INDEX_USAGE_RUN_NUMBER';*/

    DELETE FROM sql_execution_stats ses
     WHERE ses_id < (SELECT MAX(PR_VALUE) FROM PROPERTIES WHERE PR_NAME = 'INDEX_USAGE_MIN_ID')
       AND NOT EXISTS (SELECT 1
              FROM table_query_plans tqp
             WHERE tqp.tqp_sql_id = ses.ses_sql_id);
 COMMIT;
    DELETE FROM report_unused_indexes
     WHERE NOT EXISTS (SELECT 1
              FROM user_indexes
             WHERE report_unused_indexes.rui_index_name =
                   user_indexes.index_name);
 COMMIT;
    DELETE FROM unusable_indexes
     WHERE NOT EXISTS
     (SELECT 1
              FROM user_indexes
             WHERE unusable_indexes.ui_index_name = user_indexes.index_name);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  PROCEDURE index_usage_job AS
  BEGIN
    ---add property base chek at every step
    FOR i IN (SELECT 1
                FROM properties
               WHERE pr_name = 'RUN_REPORT_UNUSABLE_INDEXES'
                 AND pr_value = '1') LOOP
      report_unusable_indexes;
    END LOOP;

    FOR i IN (SELECT 1
                FROM properties
               WHERE pr_name = 'RUN_POST_MODULEWISE_IND'
                 AND pr_value = '1') LOOP
      post_modulewise_ind;
    END LOOP;
     ---new  call usage proc
    FOR i IN (SELECT 1
                FROM properties
               WHERE pr_name = 'RUN_REPORT_USED'
                 AND pr_value = '1') LOOP
      report_used_indexes;
    END LOOP;

    FOR i IN (SELECT 1
                FROM properties
               WHERE pr_name = 'RUN_PURGE_SQL_STATS'
                 AND pr_value = '1') LOOP
      purge_sql_stats;
    END LOOP;

    FOR i IN (SELECT 1
                FROM properties
               WHERE pr_name = 'DROP_UNUSED_INDEXES'
                 AND pr_value = '1') LOOP
    -----delet call form report unused otehr taht buisnekey and pk
      drop_unused_index;
    END LOOP;

    FOR i IN (SELECT 1
                FROM properties
               WHERE pr_name = 'CREATE_INDEXES'
                 AND pr_value = '1') LOOP
      create_index;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END index_usage_job;

  PROCEDURE report_used_indexes AS
    v_min_id NUMBER;
	v_max_id NUMBER;
	BEGIN
	SELECT pr_value
	  INTO v_min_id
	  FROM properties
	WHERE pr_name = 'IUS_MIN_ID';

	SELECT MAX(ses_id) INTO v_max_id FROM sql_execution_stats;

	EXECUTE IMMEDIATE 'MERGE INTO index_usage_stats ius
	USING (SELECT tab.*
					FROM user_indexes
					INNER JOIN (
					SELECT ses_object_name,
													  listagg(user_definition, '','') within GROUP(ORDER BY NULL) user_definition,
													  listagg(or_id, '','') within GROUP(ORDER BY NULL) user_id,
													  MAX(last_used_on) last_used_on,
													  max(ses_sql_id) sql_id
									   FROM (SELECT /*+ use_hash (ses b) INDEX(ses SQL_ID_RUN_ID_SI)*/ obr.or_name user_definition,
																	  obr.or_id,
																	  ses.ses_object_name,
																	 max(last_used_on) last_used_on,
																	  max(ses_sql_id) ses_sql_id
													   FROM sql_execution_stats ses
													   LEFT OUTER JOIN (SELECT tqp_sql_id          sql_id,
																									  NULL                run_id,
																									  tqp_object_id       definition_id,
																									  tqp_last_usage_time last_used_on
																									FROM table_query_plans
																					   UNION ALL
																					   SELECT NULL                      sql_id,
																									  rd_id,
																									  rd_definition_id          definition_id,
																									  rsd.rs_execution_end_time last_used_on
																									FROM run_data rd
																									INNER JOIN run_status_data rsd
																									ON rsd.rs_id = rd.rd_id
																					   ) b
																	ON (/*b.sql_id = ses.ses_sql_id OR*/
																	  b.run_id = ses.ses_run_id)
													   LEFT OUTER JOIN object_registration obr
																	ON obr.or_id = b.definition_id
																	WHERE ses.ses_ID > ' ||
									  v_min_id || '
													  AND ses.ses_ID <= ' ||
									  v_max_id || ' and
									  ses.ses_object_name like ''APP%''
									  group by obr.or_name,obr.or_id,ses.ses_object_name
									  ) user_internal
									  GROUP BY ses_object_name
									  ) tab
					   ON tab.ses_object_name = index_name) tab
	ON (tab.ses_object_name = ius.ius_index_name)
	WHEN MATCHED THEN
	  UPDATE
	   SET
     ius.ius_user_definition = ius.ius_user_definition||nvl2(tab.user_definition,'',''||tab.user_definition,tab.user_definition),
					ius.ius_user_id         = 	ius.ius_user_id||nvl2(tab.user_id,'',''||tab.user_id,tab.user_id),
					ius.ius_last_used_on    = tab.last_used_on
	WHEN NOT MATCHED THEN
	  INSERT
	  (ius.ius_index_name,
	   ius.ius_user_definition,
	   ius.ius_user_id,
	   ius.ius_last_used_on)
	  VALUES
	  (tab.ses_object_name,
	   tab.user_definition,
	   tab.user_id,
	   tab.last_used_on
	   )';

	commit;

EXECUTE IMMEDIATE 'MERGE INTO index_usage_stats ius
	USING (SELECT tab.*
					FROM user_indexes
					INNER JOIN (
					SELECT ses_object_name,
													  listagg(user_definition, '','') within GROUP(ORDER BY NULL) user_definition,
													  listagg(or_id, '','') within GROUP(ORDER BY NULL) user_id,
													  MAX(last_used_on) last_used_on,
													  max(ses_sql_id) sql_id
									   FROM (SELECT /*+ use_hash (ses b) INDEX(ses SQL_ID_RUN_ID_SI)*/ obr.or_name user_definition,
																	  obr.or_id,
																	  ses.ses_object_name,
																	 max(last_used_on) last_used_on,
																	  max(ses_sql_id) ses_sql_id
													   FROM sql_execution_stats ses
													   LEFT OUTER JOIN (SELECT tqp_sql_id          sql_id,
																									  NULL                run_id,
																									  tqp_object_id       definition_id,
																									  tqp_last_usage_time last_used_on
																									FROM table_query_plans
																					   UNION ALL
																					   SELECT NULL                      sql_id,
																									  rd_id,
																									  rd_definition_id          definition_id,
																									  rsd.rs_execution_end_time last_used_on
																									FROM run_data rd
																									INNER JOIN run_status_data rsd
																									ON rsd.rs_id = rd.rd_id
																					   ) b
																	ON (b.sql_id = ses.ses_sql_id /* OR
																	  b.run_id = ses.ses_run_id */)
													   LEFT OUTER JOIN object_registration obr
																	ON obr.or_id = b.definition_id
																	WHERE ses.ses_ID > ' ||
									  v_min_id || '
													  AND ses.ses_ID <= ' ||
									  v_max_id || ' and
									  ses.ses_object_name like ''APP%''
									  group by obr.or_name,obr.or_id,ses.ses_object_name
									  ) user_internal
									  GROUP BY ses_object_name
									  ) tab
					   ON tab.ses_object_name = index_name) tab
	ON (tab.ses_object_name = ius.ius_index_name)
	WHEN MATCHED THEN
	  UPDATE
	   SET  ius.ius_user_definition = ius.ius_user_definition||nvl2(tab.user_definition,'',''||tab.user_definition,tab.user_definition),
          ius.ius_user_id         =   ius.ius_user_id||nvl2(tab.user_id,'',''||tab.user_id,tab.user_id),
          ius.ius_last_used_on    = tab.last_used_on
	WHEN NOT MATCHED THEN
	  INSERT
	  (ius.ius_index_name,
	   ius.ius_user_definition,
	   ius.ius_user_id,
	   ius.ius_last_used_on)
	  VALUES
	  (tab.ses_object_name,
	   tab.user_definition,
	   tab.user_id,
	   tab.last_used_on
	   )';

	UPDATE properties SET pr_value = v_max_id WHERE pr_name = 'IUS_MIN_ID';
	COMMIT;
	END report_used_indexes;


  FUNCTION get_ind_col_list1(pi_type_col IN coltype_indexed_columns_list1)
    RETURN VARCHAR2 IS
    RESULT VARCHAR2(32676);
  BEGIN
    FOR c IN 1 .. pi_type_col.count LOOP

      IF (c > 1) THEN
        RESULT := RESULT || ',';
      END IF;

      RESULT := RESULT || pi_type_col(c);
    END LOOP;
    RETURN(RESULT);
  END get_ind_col_list1;

  FUNCTION get_ind_col_list(pi_type_col IN coltype_indexed_columns_list)
    RETURN VARCHAR2 IS
    RESULT VARCHAR2(32676);
  BEGIN
    FOR c IN 1 .. pi_type_col.count LOOP

      IF (c > 1) THEN
        RESULT := RESULT || ',';
      END IF;

      RESULT := RESULT || pi_type_col(c);
    END LOOP;
    RETURN(RESULT);
  END get_ind_col_list;

  PROCEDURE drop_unused_index AS
    v_tables_id NUMBER;
  BEGIN
    FOR c IN (SELECT di.rui_index_name index_name,
                     index_meta.definition_id,
                     index_meta.business_name,
                     index_meta.table_name
                FROM drop_indexes di
              /*               union all
              select create_index_requests */
                LEFT OUTER JOIN (SELECT asim.asim_def_id        AS definition_id,
                                       asim.asim_index_name    AS index_name,
                                       asim.asim_business_name AS business_name,
                                       asim.asim_table_name    AS table_name
                                  FROM app_specific_indexes_metadata asim
                                UNION ALL
                                SELECT aim.aim_def_id,
                                       aim.aim_index_name,
                                       aim.aim_business_name,
                                       aim.aim_table_name
                                  FROM application_indexes_metadata aim) index_meta
                  ON index_meta.index_name = di.rui_index_name
                   where  index_meta.index_name LIKE 'APP%') LOOP
      SELECT tables_id
        INTO v_tables_id
        FROM tables
       WHERE tables_physical_name = c.table_name;

      commons_indexing.delete_usage_index(pi_tables_id     => v_tables_id,
                                          pi_def_id        => c.definition_id,
                                          pi_business_name => c.business_name);

    END LOOP;
  END drop_unused_index;

PROCEDURE is_create(pi_table_name           IN VARCHAR2,
                    pi_index_name           IN VARCHAR2,
                    pi_column_name_list     IN coltype_indexed_columns_list,
                    pi_column_list_function IN coltype_indexed_columns_list1,
                    pi_identifier           IN NUMBER DEFAULT 0, -- 0 - app_index, 1 - DBA Index, (core types start here) 2 - business, 3 - pk, 4 - entity,5-- period
                    po_flag                 OUT NUMBER) IS
  v_factor NUMBER;
  pragma autonomous_transaction;
BEGIN
  po_flag := 1;
  SELECT MAX(column_selectivity)
    INTO v_factor
    FROM column_selectivity
   WHERE table_name = pi_table_name
     AND column_name IN
         (SELECT column_value FROM TABLE(pi_column_name_list));

  INSERT INTO create_index_requests
    (cir_table_name,
     cir_index_name,
     cir_column_name_list,
     cir_column_list_function,
     cir_create_factor,
     cir_insert_date,
     cir_identifier)
  VALUES
    (pi_table_name,
     pi_index_name,
     pi_column_name_list,
     pi_column_list_function,
     v_factor,
     SYSDATE,
     pi_identifier);
  IF pi_identifier = 1 THEN
    po_flag := 1;
  END IF;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    po_flag := 1;
END is_create;

PROCEDURE is_delete(pi_index_name    IN VARCHAR2,
                    po_business_name OUT VARCHAR2,
                    po_def_id        OUT NUMBER,
                    po_flag          OUT NUMBER) IS
  v_ncount   NUMBER := 0;
  pragma autonomous_transaction;
BEGIN

  SELECT COUNT(1)
    INTO v_ncount
    FROM report_unused_indexes
   WHERE ROWNUM <= 1 AND rui_usage_factor < (SELECT pr_value
   FROM properties
  WHERE pr_name = 'INDEX_USAGE_FACTOR')
     AND rui_index_name = pi_index_name
     AND NOT EXISTS
   (SELECT 1
            FROM index_usage_stats
           WHERE ius_index_name = pi_index_name
             AND SYSDATE - ius_last_used_on >
                 (SELECT pr_value
                    FROM properties
                   WHERE pr_name = 'INDEX_LAST_USED'));

  IF v_ncount = 0 THEN
    po_flag := 1;
  ELSE
    po_flag := 0;
    INSERT INTO delete_index_requests
      (dir_index_name, dir_status)
    VALUES
      (pi_index_name, po_flag);

    po_def_id := recommend_create_index_seq.nextval;
    po_business_name := 'USAGE_'||po_def_id;

    INSERT INTO recommend_create_index
        (rci_id,
         rci_index_name,
         rci_table_name,
         rci_column_list,
         rci_recommended_on,
         rci_created_on,
         rci_deleted_on,
         rci_flag,
         RCI_REQUESTER_FLAG)
      VALUES
        (po_def_id,
         pi_index_name,
         NULL,
         NULL,-- coltype_indexed_columns_list(c.column_name),
         NULL,
         NULL,
         SYSDATE,
         0,
         2);
    COMMIT;

    -- send def id and unique business name when we say not to delete index, this for meta sync perpose
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    po_flag := 1;
END is_delete;

  PROCEDURE create_index IS
    v_ncount   NUMBER := 0;
    v_pr_value NUMBER;

  BEGIN
/*    SELECT pr_value
      INTO v_pr_value
      FROM properties
     WHERE pr_name = 'INDEX_USAGE_FACTOR';*/

    FOR c IN (SELECT *
                FROM create_index_requests
               INNER JOIN report_unused_indexes
                  ON rui_index_name = cir_index_name
               WHERE rui_usage_factor < (SELECT pr_value
                      FROM properties
                     WHERE pr_name = 'INDEX_USAGE_FACTOR')
                    /*\* AND rui_index_name = cir_index_name*\*/
                 AND NOT EXISTS
               (SELECT 1
                  FROM index_usage_stats
                 WHERE ius_index_name = rui_index_name
                   AND SYSDATE - ius_last_used_on >  (SELECT pr_value FROM properties WHERE pr_name = 'INDEX_LAST_USED'))) LOOP


      NULL;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
/*
PROCEDURE create_index_call(pi_table_name            IN VARCHAR2,
                            pi_col_list              IN coltype_indexed_columns_list,
                            pi_def_id                IN NUMBER,
                            po_index_name            OUT VARCHAR2,
                            po_index_creation_status OUT NUMBER) */

PROCEDURE create_index_call IS

  v_index_creation_status NUMBER;
  v_index_name_returned   VARCHAR2(30);
  v_def_id                NUMBER;
  v_tables_id             NUMBER;
BEGIN

  FOR i IN (SELECT rci_id,
                   rci_table_name,
                   /*(SELECT CAST(COLLECT(CAST(t.column_value AS
                                          VARCHAR2(4000 CHAR)) ORDER BY
                                     rownum) AS tabletype_charmax)
                   FROM TABLE(rci_column_list) t) column_list*/
                   (SELECT CAST(t.column_value AS tabletype_charmax)
                      FROM TABLE(rci_column_list) t) column_list
              FROM recommend_create_index
             WHERE rci_flag = 0 -- join this tables
            ) LOOP
    SELECT tables_id
      INTO v_tables_id
      FROM tables
     WHERE tables_physical_name = i.rci_table_name;

    commons_indexing.create_usage_index(pi_tables_id                  => v_tables_id,
                                        pi_column_list                => i.column_list, -- ask maxim --IN     TABLETYPE_CHARMAX, casting done as rci_column_list is varray
                                        pi_is_unique                  => 0,
                                        pi_def_id                     => i.rci_id,
                                        pi_business_name              => 'USAGE_' ||
                                                                         i.rci_id, -- ask max
                                        pi_index_creation_logic_flag  => 0, -- jaisa bheja waisa banega 1-- index will decide whether the fucntions will be used or not
                                        pi_recreate_index_on_col_drop => 1,
                                        po_index_creation_status      => v_index_creation_status,
                                        po_index_name_returned        => v_index_name_returned);
    /*
        po_index_creation_status := v_index_creation_status;
        po_index_name            := v_index_name_returned;
    */

    UPDATE recommend_create_index
       SET rci_flag = CASE
                        WHEN v_index_creation_status IS NULL THEN
                         2
                        WHEN v_index_creation_status = 0 THEN
                         2
                        ELSE
                         1
                      END,
           rci_index_name = v_index_name_returned,
           rci_created_on = SYSDATE
     WHERE rci_id = i.rci_id;

    COMMIT;
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    NULL;
END;

PROCEDURE create_index_recommendation /*(pi_table_name IN VARCHAR2,
                              pi_col_list   IN coltype_indexed_columns_list default null) */
 IS
  v_count    NUMBER;
  v_pr_value NUMBER;
BEGIN

  FOR c IN (SELECT table_name, column_name
              FROM column_selectivity
             WHERE /*table_name = c.cir_table_name
                               AND column_name IN
                                   (SELECT t.column_value FROM TABLE(c.cir_column_name_list) t) \*TABLE(CAST(pi_col_list AS coltype_indexed_columns_list)*\
                               AND */
             column_selectivity > (SELECT pr_value
                      FROM properties
                     WHERE pr_name = 'COLUMN_SELECTIVITY')
                  /*   minus
                     select */
                     ) LOOP

    IF v_count > 0 THEN

   MERGE INTO recommend_create_index D
   USING (select c.table_name, c.column_name from dual) S
   ON (D.rci_table_name  = S.table_name )--and TABLE(rci_column_list) in s.column_name )--and (SELECT column_value FROM TABLE(rci_column_list) where column_value = c.column_name) )
   WHEN MATCHED THEN UPDATE SET D.rci_recommended_on = sysdate
   WHEN NOT MATCHED THEN INSERT (d.rci_id,
         d.rci_index_name,
         d.rci_table_name,
         d.rci_column_list,
         d.rci_recommended_on,
         d.rci_created_on,
         d.rci_deleted_on,
         d.rci_flag,
         d.RCI_REQUESTER_FLAG)
     VALUES (recommend_create_index_seq.nextval,
         NULL,
         s.table_name,
         coltype_indexed_columns_list(s.column_name),
         SYSDATE,
         NULL,
         NULL,
         0,
         1);
/*

      INSERT INTO recommend_create_index
        (rci_id,
         rci_index_name,
         rci_table_name,
         rci_column_list,
         rci_recommended_on,
         rci_created_on,
         rci_deleted_on,
         rci_flag,
         RCI_REQUESTER_FLAG)
      VALUES
        (recommend_create_index_seq.nextval,
         NULL,
         c.table_name,
         coltype_indexed_columns_list(c.column_name),
         SYSDATE,
         NULL,
         NULL,
         0,
         1);-- DBA INDEXES*/
      COMMIT;
    END IF;
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    NULL;
END;


PROCEDURE delete_index IS
BEGIN
  NULL;
EXCEPTION
  WHEN OTHERS THEN
    NULL;
END;

PROCEDURE create_index_usage_job IS
BEGIN

  FOR i IN (SELECT 1
              FROM dual
             WHERE NOT EXISTS (SELECT job_name
                      FROM user_scheduler_jobs
                     WHERE job_name = 'JOB_INDEX_USAGE')) LOOP
    dbms_scheduler.create_job(job_name        => 'JOB_INDEX_USAGE',
                              job_type        => 'STORED_PROCEDURE',
                              job_action      => 'INDEX_USAGE.INDEX_USAGE_JOB',
                              start_date      => '11-OCT-15 12.00.00 AM',
                              repeat_interval => 'FREQ=WEEKLY;INTERVAL=1',
                              comments        => 'Gather index usage information');
  END LOOP;
  FOR c IN (SELECT job_name
              FROM user_scheduler_jobs
             WHERE state = 'DISABLED'
               AND job_name = 'JOB_INDEX_USAGE') LOOP
    dbms_scheduler.enable(NAME => c.job_name);
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    NULL;
END;


END index_usage;
/
