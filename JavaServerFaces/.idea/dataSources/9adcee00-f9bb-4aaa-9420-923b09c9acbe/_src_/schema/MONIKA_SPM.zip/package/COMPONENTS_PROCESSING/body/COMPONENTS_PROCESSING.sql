CREATE PACKAGE BODY COMPONENTS_PROCESSING AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : COMPENSATION
  -- Module   : COMPENSATION-PROCESSING
  -- ---------------------------------------------------------------------------
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
	TYPE rtype_lookup_table_list IS RECORD (
			 LOOKUP_COLUMN			    VARCHAR2(30)
			,TABLE_NAME		          VARCHAR2(30)
			,LOWER_VALUE_OPTION	    NUMERIC(2)
			,HIGHER_VALUE_OPTION    NUMERIC(2)
			,USED_FOR		            NUMERIC(1)
		  ,VARY_BY_FIELDS         varchar2(2000)
      ,FROM_CLAUSE            varchar2(32767)
      ,WHERE_CLAUSE           varchar2(32767)
	  ,EFFECTIVE_DATE_PROPS   OBJTYPE_DATE_RANGE_INTERNAL
       );

	TYPE rtype_table_list IS RECORD (    TABLE_NAME     VARCHAR2(30)
					    ,FROM_CLAUSE   CLOB
					    ,WHERE_CLAUSE  CLOB
					    ,TABLE_TYPE    NUMERIC(2)
					    ,INPUT_NUMBER  NUMERIC(10));
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

    -- ############################# WHERE_TO_APPLY_VALIDATIONS START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110603
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from CREATE_DETAILED_EARNINGS
    Output Parameters:
	pout_apply_validations NUMBER NOT NULL :
        6 -- validations must be applied at modified earnings - on res table
        5 -- validations must be applied at modified earnings - together with processing
        4 -- validations must be applied at aggregated earnings - on res table
        3 -- validations must be applied at aggregated earnings - together with processing
        2 -- validations must be applied at detailed earnings - on res table
        1 -- validations must be applied at detailed earnings - together with processing
        0 -- validations must not be executed
    */
    PROCEDURE WHERE_TO_APPLY_VALIDATIONS
	(	 pin_input_table_list		IN tabletype_input_table_list
		,pin_aggregation_type		IN NUMBER
        ,pin_mod_apply_option       IN NUMBER
		,pin_vld_when				IN CLOB
		,pout_apply_validations		OUT NUMBER
	) AS
		v_run_with_selected_roster	NUMBER;
        v_apply_validations         NUMBER;
		v_stamp						VARCHAR2(200);
    BEGIN
   	v_stamp := 'COMPONENTS_PROCESSING.WHERE_TO_APPLY_VALIDATIONS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
	SELECT count(*) INTO v_run_with_selected_roster FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE IN (14);

    /*  - validations must be applied on the last result table before Component Earnings.
        - depending on whether we have modifiers, where modifiers are applied (before/after agg) or if we have aggregation at all.
        - also validations must be done on the entire period records so:
            * if processing is done with selected roster records we must do the processing and then apply the vld on the entire result table
            * otherwise we can do validations during the same time as the processing - we already go through all period records
    */

   	v_apply_validations :=  CASE WHEN pin_mod_apply_option = 2  OR (pin_mod_apply_option = 1 AND pin_aggregation_type IS NULL) THEN 5
								 WHEN pin_aggregation_type IS NOT NULL THEN 3
                                 ELSE 1 END;

    pout_apply_validations := CASE WHEN pin_vld_when IS NULL THEN 0
                                   WHEN v_run_with_selected_roster = 1 THEN v_apply_validations + 1
                                   ELSE v_apply_validations END;

	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pout_apply_validations) ,'pout_apply_validations := <value>', v_stamp);

   END WHERE_TO_APPLY_VALIDATIONS;
    -- ############################# WHERE_TO_APPLY_VALIDATIONS END   #############################

    -- ############################# RUN_VALIDATIONS_ON_RES_TABLE START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110913
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from CREATE_DETAILED_EARNINGS
    */
	PROCEDURE RUN_VALIDATIONS_ON_RES_TABLE
	(	 pin_result_table			IN OBJTYPE_INPUT_TABLE_LIST
		,pin_vld_when				IN CLOB
		,pin_vld_select				IN CLOB
		,pin_vld_from				IN CLOB
		,pin_earning_calc_ent		IN TABLETYPE_CPM_ENTITIES
	) AS
		v_sql_uival_select_src  VARCHAR2(32000 CHAR);
        v_sql_uival_from        VARCHAR2(32000 CHAR);
        v_validations_query		CLOB;
		v_stamp					VARCHAR2(200 CHAR);
	BEGIN
		v_stamp := 'COMPONENTS_PROCESSING.RUN_VALIDATIONS_ON_RES_TABLE - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        /* build column PECE list and possibile joins */
        FOR c_calc_ent IN (SELECT * FROM TABLE(pin_earning_calc_ent)
                           WHERE ENTITY_TYPE IN (1, 4) AND COLUMN_TYPE = 1
                           ORDER BY ENTITY_ORDER)
        LOOP
            v_sql_uival_select_src := v_sql_uival_select_src||','||c_calc_ent.ENTITY_NAME||'.'||c_calc_ent.ENTITY_FIELD_NAME;
            v_sql_uival_from := v_sql_uival_from||CASE WHEN c_calc_ent.ENTITY_TYPE = 1 THEN 'INNER' ELSE 'LEFT' END
                ||' JOIN '||c_calc_ent.ENTITY_TABLE_NAME||' '||c_calc_ent.ENTITY_NAME||' ON MAIN_S.'||c_calc_ent.ENTITY_NAME||' = '||c_calc_ent.ENTITY_NAME||'.E_INTERNAL_ID'||CHR(10);
        END LOOP;

		v_validations_query:= 'INSERT ALL '||chr(10)
			||pin_vld_when||chr(10)
			||'SELECT 1 DUMMY'||chr(10)
			||v_sql_uival_select_src||chr(10)
			||pin_vld_select||chr(10)
			||'FROM '||pin_result_table.TABLE_NAME||' MAIN_S'||chr(10)
			||v_sql_uival_from
			||pin_vld_from;

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_validations_query) ,'v_validations_query := <value>', v_stamp);
		EXECUTE IMMEDIATE v_validations_query;

	END RUN_VALIDATIONS_ON_RES_TABLE;
    -- ############################# RUN_VALIDATIONS_ON_RES_TABLE END   #############################

    -- ############################# OUTPUT_VALIDATION_RESULTS START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110913
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from CREATE_DETAILED_EARNINGS
    */
	PROCEDURE OUTPUT_VALIDATION_RESULTS
	(	 pin_result_table			IN OBJTYPE_INPUT_TABLE_LIST
		,pin_vld_get_values			IN CLOB
		,pin_vld_need_to_count		IN NUMBER
		,pout_vld_results			OUT SYS_REFCURSOR
	) AS
		v_total_rowcount		NUMBER;
	BEGIN
		IF (pin_vld_need_to_count = 1)
		THEN
			EXECUTE IMMEDIATE ' SELECT COUNT(*) FROM '||pin_result_table.TABLE_NAME
			INTO v_total_rowcount;
		ELSE
			v_total_rowcount:=0;
		END IF;
	OPEN pout_vld_results FOR pin_vld_get_values USING v_total_rowcount;
	END OUTPUT_VALIDATION_RESULTS;
    -- ############################# OUTPUT_VALIDATION_RESULTS END   #############################

	-- ############################# GET_TABLE_BY_TYPE START #############################
	FUNCTION GET_TABLE_BY_TYPE
	(	 pin_input_table_list	IN TABLETYPE_INPUT_TABLE_LIST
		,pin_table_type			IN NUMBER
	) RETURN OBJTYPE_INPUT_TABLE_LIST AS
		v_table					OBJTYPE_INPUT_TABLE_LIST;
		v_idx					PLS_INTEGER;
	BEGIN
		v_idx := pin_input_table_list.FIRST;
		WHILE (v_idx IS NOT NULL)
		LOOP
			IF (pin_input_table_list(v_idx).TABLE_TYPE = pin_table_type)
			THEN
				v_table := pin_input_table_list(v_idx);
			END IF;

			v_idx := pin_input_table_list.NEXT(v_idx);
		END LOOP;

		RETURN v_table;
	END GET_TABLE_BY_TYPE;
	-- ############################# GET_TABLE_BY_TYPE END #############################

  -- #############################    GET_NUMBER_OF_COMPONENT_FILTER  START   #############################
  /*
  ---------------------------------------------------------------------------------------
  Author     : Alex, Huiban
  Create date: 2017-07-19
  Description: Returns 1 or more when component roster is present and roster is generated by an assignment entity
         and the other entity from the assignment can be found in Entities calculation in both metric and component
         also the earning calculation type for component is lookup 'Discrete Lookup' - more info here OF-51368

  ---------------------------------------------------------------------------------------
  Input Parameters: Inherit parameters from RUN_COMPONENT

  -----------------------------------------------------------------------------------------
  Result set:

  -----------------------------------------------------------------------------------------
  Example:
    my_var_count := GET_NUMBER_OF_COMPONENT_FILTER(  pin_definition_id  => '415425');

  -----------------------------------------------------------------------------------------
  */

  FUNCTION GET_NUMBER_OF_COMPONENT_FILTER
  (  pin_definition_id  IN NUMBER
  ) RETURN NUMBER AS
    v_count   NUMBER;
  BEGIN

    Select count(1) INTO v_count
      from plan_definitions pd
     inner join plan_versions pv
        on pd.pd_id = pv.pdv_pd_id
     INNER JOIN PLAN_ROSTERS_TAB prt
        ON prt.prt_ver_object_id = pv.pdv_ver_object_id
     INNER JOIN SECONDARY_ASSIGNMENTS sa
        ON sa.sa_ea_id = prt.prt_earning_assign_table_id
     INNER JOIN plan_roster_comp_roster_cols prcrc
        ON prcrc.prcrc_prt_id = prt.prt_id
     INNER JoIN plan_component_definitions pcd
        ON pcd.pcd_ver_object_id = pv.pdv_ver_object_id
     INNER JOIN plan_comp_entities_tab PCET
        on PCET.pcet_pcd_id = pcd.pcd_id
     INNER JOIN plan_comp_entity_calc_cols pcecc
        ON pcecc.pcecc_pcet_id = pcet.pcet_id
     WHERE PRT_EARNING_ASSIGN_TABLE_ID IS NOT NULL
       AND PRT_COMP_ROSTER_TABLE_ID IS NOT NULL
       AND pcecc.pcecc_type = 1
       AND pcecc.pcecc_col_id = prcrc.prcrc_field_entity_id
       AND prcrc.prcrc_field_entity_id = sa.sa_entity_id
       AND pcd.pcd_id = pin_definition_id;

   RETURN v_count;
  END GET_NUMBER_OF_COMPONENT_FILTER;

  -- #############################    GET_NUMBER_OF_COMPONENT_FILTER  END   #############################

	-- ############################# GET_POSTED_EE_FLAG START #############################
	FUNCTION GET_POSTED_EE_FLAG
	(	 pin_result_table	IN OBJTYPE_INPUT_TABLE_LIST
		,pin_sel_roster_sql	IN CLOB
	) RETURN NUMBER AS
		v_sql		CLOB;
		v_flag		NUMBER;
		v_stamp		VARCHAR2(200 CHAR);
	BEGIN
		v_stamp := 'COMPONENTS_PROCESSING.GET_POSTED_EE_FLAG - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

		v_sql := 'SELECT COUNT(*) FROM (SELECT 1 FROM '||pin_result_table.TABLE_NAME||' I WHERE ROWNUM = 1'
			||CASE WHEN pin_sel_roster_sql IS NOT NULL THEN ' AND '||pin_sel_roster_sql ELSE NULL END
			||')';

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>', v_stamp);
		EXECUTE IMMEDIATE v_sql INTO v_flag;

		RETURN v_flag;
	END GET_POSTED_EE_FLAG;
	-- ############################# GET_POSTED_EE_FLAG START #############################

	-- ############################# DELETE_RES_INVALID_ENT START #############################
	PROCEDURE DELETE_RES_INVALID_ENT
	(	 pin_input_table_list	IN TABLETYPE_INPUT_TABLE_LIST
		,pin_earning_entity		IN TABLETYPE_NAME_MAP
	) AS
		v_sql		CLOB;
		v_stamp		VARCHAR2(200 CHAR);
	BEGIN
		v_stamp := 'COMPONENTS_PROCESSING.DELETE_RES_INVALID_ENT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');


		FOR c IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE IN (8, 9, 10, 11, 17, 34))
		LOOP
			v_sql := 'DELETE FROM '||c.TABLE_NAME||' WHERE '||pin_earning_entity(1).NAME1||' IN (SELECT EARNING_ENTITY_ID FROM TEMP_PROC_VALIDATION_VALUES)';

			L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,'v_sql := <value>', v_stamp);
			EXECUTE IMMEDIATE v_sql;

			v_sql := 'DELETE FROM '||c.TABLE_NAME||' WHERE '||pin_earning_entity(1).NAME1||' IN (SELECT EARNING_ENTITY_ID FROM TEMP_MODIFIERS_REJECTED_TABLE)';

			L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,'v_sql := <value>', v_stamp);
			EXECUTE IMMEDIATE v_sql;
		END LOOP;
	END DELETE_RES_INVALID_ENT;
	-- ############################# DELETE_RES_INVALID_ENT END #############################

	-- ############################# DELETE_UIVLD_INVALID_ENT START #############################
	PROCEDURE DELETE_UIVLD_INVALID_ENT
	(	 pin_entity_table		IN OBJTYPE_INPUT_TABLE_LIST
		,pin_earning_entity		IN TABLETYPE_NAME_MAP
	) AS
		v_sql		CLOB;
		v_stamp		VARCHAR2(200 CHAR);
	BEGIN
		v_stamp := 'COMPONENTS_PROCESSING.DELETE_UIVLD_INVALID_ENT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

		v_sql := 'DELETE FROM TEMP_UI_VALIDATION_VALUES
		WHERE UPPER(C1) IN (SELECT UPPER(TO_CHAR(ET.'||pin_earning_entity(1).name2||'))
                            FROM TEMP_PROC_VALIDATION_VALUES PR
						         INNER JOIN '||pin_entity_table.TABLE_NAME||' ET ON PR.EARNING_ENTITY_ID = ET.E_INTERNAL_ID)';

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,'v_delete_UI_vld_sql := <value>', v_stamp);
		EXECUTE IMMEDIATE v_sql;

		v_sql := 'DELETE FROM TEMP_UI_VALIDATION_VALUES
		WHERE UPPER(C1) IN (SELECT UPPER(ENTITY_1) FROM TEMP_MODIFIERS_REJECTED_TABLE)';

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,'v_delete_UI_vld_sql := <value>', v_stamp);
		EXECUTE IMMEDIATE v_sql;
	END DELETE_UIVLD_INVALID_ENT;
	-- ############################# DELETE_UIVLD_INVALID_ENT END #############################

    -- ############################# BUILD_SQL_DETAIL_ROSTER START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110603
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from CREATE_DETAILED_EARNINGS
    */
    PROCEDURE BUILD_SQL_DETAIL_ROSTER
	(	 pin_input_table_list   IN TABLETYPE_INPUT_TABLE_LIST
        ,pin_component_type		IN NUMBER
        ,pin_cust_form_clauses  IN TABLETYPE_CUST_FORM_CLAUSES
        ,pin_definition_id      IN NUMBER
		,pout_sql_from_roster   OUT VARCHAR2
    ,pout_sql_comp_filter   OUT VARCHAR2
	) AS
        v_r                         OBJTYPE_INPUT_TABLE_LIST;
        v_r_clauses                 OBJTYPE_CUST_FORM_CLAUSES;
        v_idx                       PLS_INTEGER;
        v_comp_roster_table         RTYPE_TABLE_LIST;
        v_comp_roster_table_exists  NUMBER := 0;
        v_count_comp_rost           NUMBER(10) := 0;
        v_filter_comp               CLOB;
        v_stamp		VARCHAR2(200 CHAR);
    BEGIN
    v_stamp := 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_ROSTER - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    -- see if comp rostering is applied
    FOR cv_comp_roster IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE = 30)
	LOOP
        v_comp_roster_table_exists := 1;
        v_comp_roster_table := cv_comp_roster;
	END LOOP;

    -- get the roster table
    v_idx := pin_input_table_list.FIRST;
    WHILE (v_idx IS NOT NULL)
    LOOP
        IF (pin_input_table_list(v_idx).TABLE_TYPE IN (0, 14))
        THEN
            v_r := pin_input_table_list(v_idx);
	    END IF;
        v_idx := pin_input_table_list.NEXT(v_idx);
    END LOOP;

    -- if calc type = "custom formula" then see if there are any LastDateInTable/LastPeriodInTable clauses
    -- that must be added to the roster
    IF (pin_component_type = 3 AND pin_cust_form_clauses IS NOT NULL)
    THEN
        v_idx := pin_cust_form_clauses.FIRST;
        WHILE (v_idx IS NOT NULL)
        LOOP
            IF (pin_cust_form_clauses(v_idx).INPUT_NUMBER = 0)
            THEN
                v_r_clauses := pin_cust_form_clauses(v_idx);
            END IF;
            v_idx := pin_cust_form_clauses.NEXT(v_idx);
        END LOOP;
    END IF;

      v_count_comp_rost := GET_NUMBER_OF_COMPONENT_FILTER(  pin_definition_id  => pin_definition_id);

     --in this case we don't send any roster as it will be ignored by the processing
      IF  v_count_comp_rost > 0 THEN
        v_filter_comp := CASE WHEN v_comp_roster_table_exists = 1
               THEN ' INNER JOIN '||v_comp_roster_table.TABLE_NAME||' '||REPLACE(REPLACE(v_comp_roster_table.FROM_CLAUSE
                                                                                        ,'R.'
                                                                                        ,'TAB.'
                                                                                        )
                                                                                ,'RC.'
                                                                                ,v_comp_roster_table.TABLE_NAME||'.')||CHR(10)
               ELSE NULL END
        ||CASE WHEN v_r_clauses.FROM_CLAUSE IS NOT NULL THEN ' '||REPLACE(v_r_clauses.FROM_CLAUSE, 'R.', v_r.TABLE_NAME||'.')||CHR(10) ELSE NULL END
        ||' '||v_r.WHERE_CLAUSE
        ||CASE WHEN v_comp_roster_table_exists = 1 AND v_r.WHERE_CLAUSE IS NOT NULL
               THEN ' AND '||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id)
               WHEN v_comp_roster_table_exists = 1 AND v_r.WHERE_CLAUSE IS NULL
               THEN ' AND '||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id)
               ELSE NULL END
        ||CASE WHEN v_comp_roster_table_exists = 1 AND v_comp_roster_table.WHERE_CLAUSE IS NOT NULL
               THEN ' AND '||SUBSTR(v_comp_roster_table.WHERE_CLAUSE, 7, LENGTH(v_comp_roster_table.WHERE_CLAUSE)) /*remove the WHERE word*/
               ELSE NULL END
        ||CHR(10);

        IF (v_r.TABLE_TYPE = 0) THEN
          v_comp_roster_table_exists := 0;
        ELSE
           v_filter_comp := '';
        END IF;

      ELSE
         v_filter_comp := '';
      END IF;

    pout_sql_comp_filter:= v_filter_comp;

    pout_sql_from_roster:='FROM (SELECT '
            ||v_r.TABLE_NAME||'.*'||CHR(10)
            ||CASE WHEN v_r_clauses.SELECT_CLAUSE IS NOT NULL THEN ','||REPLACE(v_r_clauses.SELECT_CLAUSE, 'R.', v_r.TABLE_NAME||'.')||CHR(10) ELSE NULL END
        ||' FROM '||v_r.TABLE_NAME||CHR(10)
        ||CASE WHEN v_comp_roster_table_exists = 1
               THEN ' INNER JOIN '||v_comp_roster_table.TABLE_NAME||' '||REPLACE(REPLACE(v_comp_roster_table.FROM_CLAUSE
                                                                                        ,'R.'
                                                                                        ,v_r.TABLE_NAME||'.'
                                                                                        )
                                                                                ,'RC.'
                                                                                ,v_comp_roster_table.TABLE_NAME||'.')||CHR(10)
               ELSE NULL END
        ||CASE WHEN v_r_clauses.FROM_CLAUSE IS NOT NULL THEN ' '||REPLACE(v_r_clauses.FROM_CLAUSE, 'R.', v_r.TABLE_NAME||'.')||CHR(10) ELSE NULL END
        ||' '||v_r.WHERE_CLAUSE
        ||CASE WHEN v_comp_roster_table_exists = 1 AND v_r.WHERE_CLAUSE IS NOT NULL
               THEN ' AND '||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id)
               WHEN v_comp_roster_table_exists = 1 AND v_r.WHERE_CLAUSE IS NULL
               THEN 'WHERE '||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id)
               ELSE NULL END
        ||CASE WHEN v_comp_roster_table_exists = 1 AND v_comp_roster_table.WHERE_CLAUSE IS NOT NULL
               THEN ' AND '||SUBSTR(v_comp_roster_table.WHERE_CLAUSE, 7, LENGTH(v_comp_roster_table.WHERE_CLAUSE)) /*remove the WHERE word*/
               ELSE NULL END
        ||') R'||CHR(10);


    	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_comp_filter) ,'pout_sql_comp_filter := <value>', v_stamp);
    	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_from_roster) ,'pout_sql_from_roster := <value>', v_stamp);


   END BUILD_SQL_DETAIL_ROSTER;
    -- ############################# BUILD_SQL_DETAIL_ROSTER END   #############################

    -- ############################# BUILD_SQL_DETAIL_EARN_PROJ START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110603
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from CREATE_DETAILED_EARNINGS
    */
    PROCEDURE BUILD_SQL_DETAIL_EARN_PROJ
    (	 pin_projected_period_column IN VARCHAR2
		,pin_projected_period        IN NUMBER
		,pin_projected		 IN NUMBER
		,pout_sql_proj_insert        OUT VARCHAR2
		,pout_sql_proj_select        OUT VARCHAR2
	) AS
    BEGIN
	pout_sql_proj_insert:=CASE WHEN pin_projected_period_column IS NOT NULL THEN ','||pin_projected_period_column||chr(10)||chr(32)||
										     ',PROJECTED'||chr(10)||chr(32) ELSE '' END;

	pout_sql_proj_select:=CASE WHEN pin_projected_period_column IS NOT NULL THEN ','||pin_projected_period||' '||pin_projected_period_column||chr(10)||chr(32)||
										     ','||pin_projected||' PROJECTED'||chr(10)||chr(32) ELSE '' END;
    END BUILD_SQL_DETAIL_EARN_PROJ;
    -- ############################# BUILD_SQL_DETAIL_EARN_PROJ END   #############################

   -- ############################# BUILD_SQL_DETAIL_LOOKUP START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110603
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from CREATE_DETAILED_EARNINGS

    */
   PROCEDURE BUILD_SQL_DETAIL_LOOKUP
   (	 pin_component_type		IN NUMBER
        ,pin_component_subtype      IN NUMBER
        ,pin_lookup_table		IN tabletype_lookup_table_list
        ,pin_input_table_list	IN tabletype_input_table_list
        ,pin_input_values_columns		IN tabletype_id_name
        ,pin_earning_entity		IN tabletype_name_map
        ,pin_ece_column_list	IN VARCHAR2
        ,pin_ece_column_list_vld IN VARCHAR2
        ,pin_ece_column_list_lookup IN VARCHAR2
        ,pin_from_roster      IN VARCHAR2-- #ADDED
        ,pin_sql_comp_filter  IN VARCHAR2-- #ADDED
        ,pin_lookup_precision IN NUMBER
        ,pout_sql_lookup_insert	OUT VARCHAR2
        ,pout_sql_lookup_select	OUT VARCHAR2
        ,pout_sql_lookup_earnings	OUT VARCHAR2
        ,pout_sql_lookup_from	OUT CLOB
        ,pout_sql_prval_insert_lookup OUT CLOB
        ,pout_sql_prval_select_lookup OUT CLOB
	) AS
        v_sql_from_input	   CLOB;
        v_sql_from_lookup	   CLOB;
        v_InputColumns		   VARCHAR2(32767);
        v_InputColumnsAlias	 VARCHAR2(32767);
        v_sql_from_roster    VARCHAR2(32767);
        v_sql_lookup_table   VARCHAR2(32767);
        v_sql_roster_join    VARCHAR2(32767);
        v_table              rtype_table_list;
        v_lookup_table       rtype_lookup_table_list;
        v_input_values_column VARCHAR2(30 CHAR);
        v_stamp             VARCHAR2(200 CHAR);
        v_vary_by_fields    VARCHAR2(200 CHAR);
        v_from_clause       CLOB;

   BEGIN
    IF pin_component_type    = 1
     THEN

     /* LOOKUP_INPUT(3),
        COMMISSION_RATE_INPUT(4),
        COMMISSION_RATE_LOOKUP_INPUT(5)*/
     SELECT NAME INTO v_input_values_column
     FROM TABLE(pin_input_values_columns) WHERE ID = 3;

	pout_sql_lookup_insert:=CASE WHEN pin_component_subtype IN (1,2,3) THEN ',LOOKUP_METRIC'||chr(10)||chr(32)
				     WHEN pin_component_subtype IN (4) THEN ',COLUMN_LOOKUP_METRIC'||chr(10)||chr(32)||
									    ',ROW_LOOKUP_METRIC'||chr(10)||chr(32)
				    END;

	pout_sql_prval_insert_lookup:= 'WHEN (VLD_NO_LKCURVES = 1 and COMP_LOOKUP_RESULT_VALUE IS NULL) THEN'             ||chr(10)||chr(32)||
					                         'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)' ||chr(10)||chr(32)||
					                         'VALUES ('||pin_ece_column_list||',2520)'                                        ||chr(10)||chr(32)||
                                 'WHEN (VLD_NO_LKCURVES = 0 )                                     THEN'             ||chr(10)||chr(32)||
					                         'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)' ||chr(10)||chr(32)||
					                         'VALUES ('||pin_ece_column_list||',2510)';

	pout_sql_prval_select_lookup:=',COMP_LOOKUP_RESULT_VALUE' ||chr(10)||chr(32)||
                                ',ROW_IDENTIFIER'           ||chr(10)||chr(32)||
                                ',VLD_NO_LKCURVES'          ||chr(10)||chr(32);

	pout_sql_lookup_select:=  ',I.RESULT_VALUE COMP_LOOKUP_RESULT_VALUE'                                                                          ||chr(10)||chr(32)||
				               ',I.ROW_IDENTIFIER ROW_IDENTIFIER'                                                                                  ||chr(10)||chr(32)||
				               ',VLD_NO_LKCURVES'                                                                                                  ||chr(10)||chr(32)||
		                        CASE WHEN pin_component_subtype IN (1,2,3)
                                     THEN ',CAST(I.'||v_input_values_column||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('LOOKUP_METRIC')||') LOOKUP_METRIC'          ||chr(10)||chr(32)

                             WHEN pin_component_subtype IN (4)
                                     THEN ',CAST(NULL AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COLUMN_LOOKUP_METRIC')||') COLUMN_LOOKUP_METRIC'||chr(10)||chr(32)||
							    ',CAST(NULL AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('ROW_LOOKUP_METRIC')   ||') ROW_LOOKUP_METRIC'   ||chr(10)||chr(32) end;

    pout_sql_lookup_earnings:=  ' (CAST( I.RESULT_VALUE AS NUMBER '||
                  CASE WHEN pin_lookup_precision IS NULL
                            THEN COMMONS.FIELD_PRECISION_AND_SCALE('EARNINGS_FACTOR')
                            ELSE COMMONS.FIELD_SCALE('EARNINGS_FACTOR',pin_lookup_precision)
                  END
                  ||'))'||chr(10)  ;

	--:pout_sql_lookup_from
	  -- build parameters for calling lookup functions which will provide the necessary strings
	  v_InputColumns:=pin_ece_column_list||','||v_input_values_column||',ROW_IDENTIFIER';
	  v_InputColumnsAlias:=pin_ece_column_list_lookup||',TAB.'||v_input_values_column||',TAB.ROW_IDENTIFIER';
	  SELECT * INTO v_lookup_table FROM TABLE(pin_lookup_table) WHERE USED_FOR=1;

	-- get the information about the input (metric or component result table)
	SELECT * INTO v_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=2;
	v_sql_from_input:=CASE WHEN v_table.from_clause IS NOT NULL THEN v_table.from_clause ELSE v_table.table_name END||' I '||v_table.where_clause;

  -- get the info about the Roster
  v_sql_from_roster := pin_from_roster;
  v_sql_roster_join := 'ON R.'||pin_earning_entity(1).name1||' = TAB.'||pin_earning_entity(1).name1;

  --Add Period filter for lookup table
  v_sql_lookup_table := ' (SELECT * FROM ' || v_lookup_table.table_name || ' ' || v_lookup_table.WHERE_CLAUSE || ')';

	begin
		v_stamp := 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_LOOKUP - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookup_table) ,',pin_lookup_table => <value>', v_stamp);
	end;

	v_vary_by_fields := v_lookup_table.VARY_BY_FIELDS;
    v_from_clause    := v_lookup_table.FROM_CLAUSE;

   IF (v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 IS NOT NULL) AND (v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 IS NOT NULL) THEN
      IF v_vary_by_fields IS NOT NULL THEN
         v_vary_by_fields := v_vary_by_fields || ',' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2;
      ELSE
         v_vary_by_fields := v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2;
      END IF;
      IF v_from_clause IS NOT NULL THEN
         v_from_clause    := v_from_clause || ' AND TAB.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_COLUMN_NAME || '  BETWEEN
                                nvl(LOOKUP.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) AND
                                nvl(LOOKUP.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))';
      ELSE
         v_from_clause    := ' LOOKUP ON TAB.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_COLUMN_NAME || '  BETWEEN
                                nvl(LOOKUP.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) AND
                                nvl(LOOKUP.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))';
      END IF;
   END IF;

	--build the lookup query
	IF        pin_component_subtype = 1 THEN
		SELECT COMPENSATION_PROCESSING.STEP_LOOKUP(
					    pin_InputColumns		  => v_InputColumns
					   ,pin_InputColumnsAlias	=> v_InputColumnsAlias
					   ,pin_InputFrom		      => v_sql_from_input
					   ,pin_InputLookupColumn	=> v_lookup_table.lookup_column
					   ,pin_LookupTable		    => v_sql_lookup_table
					   ,pin_LowerValueOption	=> v_lookup_table.lower_value_option
					   ,pin_HigherValueOption	=> v_lookup_table.higher_value_option
             ,pin_RosterFrom        => v_sql_from_roster
             ,pin_RosterJoinClause  => v_sql_roster_join
			       ,pin_LookupJoinClause  => v_from_clause
             ,pin_varyByFields      => v_vary_by_fields
             ,pin_comp_filter       => pin_sql_comp_filter
					   )
	        INTO v_sql_from_lookup
		FROM DUAL;
	   ELSIF pin_component_subtype = 2 THEN
		SELECT COMPENSATION_PROCESSING.CONTINUOUS_LOOKUP(
					  pin_InputColumns		    => v_InputColumns
					 ,pin_InputColumnsAlias		=> v_InputColumnsAlias
					 ,pin_InputFrom			=> v_sql_from_input
           ,pin_InputLookupColumn		=> v_lookup_table.lookup_column
           ,pin_LookupTable		      => v_sql_lookup_table
           ,pin_LowerValueOption		=> v_lookup_table.lower_value_option
           ,pin_HigherValueOption		=> v_lookup_table.higher_value_option
           ,pin_RosterFrom          => v_sql_from_roster
           ,pin_RosterJoinClause    => v_sql_roster_join
			     ,pin_LookupJoinClause  => v_from_clause
           ,pin_varyByFields      => v_vary_by_fields
           ,pin_comp_filter       => pin_sql_comp_filter
					 )
	        INTO v_sql_from_lookup
		FROM DUAL;
	   ELSIF pin_component_subtype = 3 THEN
		SELECT COMPENSATION_PROCESSING.DISCRETE_LOOKUP(
					  pin_InputColumns		    => v_InputColumns
					 ,pin_InputColumnsAlias		=> v_InputColumnsAlias
           ,pin_InputFrom			      => v_sql_from_input
           ,pin_InputLookupColumn		=> v_lookup_table.lookup_column
           ,pin_LookupTable		      => v_sql_lookup_table
           ,pin_RosterFrom          => v_sql_from_roster
           ,pin_RosterJoinClause    => v_sql_roster_join
			     ,pin_LookupJoinClause  => v_from_clause
           ,pin_varyByFields      => v_vary_by_fields
           ,pin_comp_filter       => pin_sql_comp_filter
           )

	        INTO v_sql_from_lookup
		FROM DUAL;
	   ELSIF pin_component_subtype = 4 THEN -- MATRIX
		v_sql_from_lookup:='';
	  END IF;

	-- finalize the string
	pout_sql_lookup_from:='INNER JOIN ('||v_sql_from_lookup||') I ON R.'||pin_earning_entity(1).name1||' = I.'||pin_earning_entity(1).name1||chr(10);


	BEGIN
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_from_clause) ,',v_from_clause => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_vary_by_fields) ,',v_vary_by_fields => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_from_lookup) ,',v_sql_from_lookup => <value>', v_stamp);
	END;

    END IF;

   END BUILD_SQL_DETAIL_LOOKUP;
   -- ############################# BUILD_SQL_DETAIL_LOOKUP END   #############################

   -- ############################# BUILD_SQL_DETAIL_COM_RATE START   #############################
   PROCEDURE BUILD_SQL_DETAIL_COM_RATE
   (	 pin_component_type		IN NUMBER
		,pin_component_subtype      IN NUMBER
		,pin_comision_rate_value    IN NUMBER
		,pin_lookup_table		IN tabletype_lookup_table_list
		,pin_input_table_list	IN tabletype_input_table_list
    ,pin_input_values_columns		IN tabletype_id_name
		,pin_earning_entity		IN tabletype_name_map
		,pin_ece_column_list	IN VARCHAR2
		,pin_ece_column_list_vld IN VARCHAR2
		,pin_ece_column_list_lookup IN VARCHAR2
		,pin_ece_column_list_join	IN VARCHAR2
    ,pin_from_roster         IN VARCHAR2  -- #ADDED
    ,pin_sql_comp_filter  IN VARCHAR2-- #ADDED
    ,pin_definition_id       IN VARCHAR2 -- #ADDED
    ,pin_lookup_precision    IN VARCHAR2
		,pout_sql_com_rate_insert OUT VARCHAR2
		,pout_sql_com_rate_select OUT VARCHAR2
		,pout_sql_com_rate_earnings	OUT VARCHAR2
		,pout_sql_com_rate_from   OUT CLOB
		,pout_sql_prval_insert_com_rate OUT CLOB
		,pout_sql_prval_select_com_rate OUT CLOB
		,pout_sql_com_rate_i_from   OUT CLOB
	) AS
		v_sql_from_input		CLOB;
		v_sql_from_com_rate_lookup	CLOB;
		v_sql_from_com_rate_mt		CLOB;
		v_sql_from_com_rate_input	CLOB;
		v_InputColumns			VARCHAR2(32767);
		v_InputColumnsAlias		VARCHAR2(32767);
		v_table                         rtype_table_list;
		v_lookup_table			rtype_lookup_table_list;
    v_sql_roster_join    VARCHAR2(32767);
    v_sql_from_roster    VARCHAR2(32767);
    v_sql_lookup_table   VARCHAR2(32767);
    v_input_values_column VARCHAR2(30 CHAR);
    v_lk_input_values_column VARCHAR2(30 CHAR);
    v_count_comp_rost        NUMBER(10);
   BEGIN
    IF pin_component_type    = 2 -- COMMISION RATE
     THEN
     /* LOOKUP_INPUT(3),
        COMMISSION_RATE_INPUT(4),
        COMMISSION_RATE_LOOKUP_INPUT(5)*/
     SELECT NAME INTO v_input_values_column
     FROM TABLE(pin_input_values_columns) WHERE ID = 4;

     IF (pin_component_subtype IN (101,102,103))
     THEN
        SELECT NAME INTO v_lk_input_values_column
        FROM TABLE(pin_input_values_columns) WHERE ID = 5;
     END IF;

	pout_sql_com_rate_insert:=',COMMISSION_METRIC'||chr(10)||chr(32)||
		                  ',COMMISSION_RATE'||chr(10)||chr(32)
				  ||CASE WHEN pin_component_subtype IN (101,102,103)
					THEN ',LOOKUP_METRIC'||chr(10)||chr(32)
					WHEN pin_component_subtype IN (104)
					THEN ',COLUMN_LOOKUP_METRIC'||chr(10)||chr(32)||
					     ',ROW_LOOKUP_METRIC'||chr(10)||chr(32)
					ELSE ''
				    END
				 ;

	pout_sql_prval_insert_com_rate:=
              CASE
                WHEN pin_component_subtype IN (101,102,103)
                  THEN 'WHEN (VLD_NO_LKCURVES = 1 and COM_RATE_LOOKUP_RESULT_VALUE IS NULL) THEN'                              ||chr(10)||chr(32)||
											   'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'                      ||chr(10)||chr(32)||
											   'VALUES ('||pin_ece_column_list||',2580)'                                                             ||chr(10)||chr(32)||
                       'WHEN (VLD_NO_LKCURVES = 0                                         ) THEN'                              ||chr(10)||chr(32)||
											   'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'                      ||chr(10)||chr(32)||
											   'VALUES ('||pin_ece_column_list||',2570)'                                                             ||chr(10)
				WHEN pin_component_subtype IN (105)
                  THEN 'WHEN (COMMISSION_RATE IS NULL) THEN'                                                                   ||chr(10)||chr(32)||
											 'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'                        ||chr(10)||chr(32)||
											 'VALUES ('||pin_ece_column_list||',2550)'||chr(10)
				END;

	pout_sql_prval_select_com_rate:=CASE
                                    WHEN pin_component_subtype IN (101,102,103)
                                      THEN ',COM_RATE_LOOKUP_RESULT_VALUE,ROW_IDENTIFIER2,VLD_NO_LKCURVES'
					                          WHEN pin_component_subtype IN (100,105)
                                      THEN ',ROW_IDENTIFIER' END||chr(10)||chr(32);

	pout_sql_com_rate_select:=CASE
                              WHEN pin_component_subtype IN (101,102,103)
                                THEN ',I2.RESULT_VALUE COM_RATE_LOOKUP_RESULT_VALUE,I2.ROW_IDENTIFIER ROW_IDENTIFIER2'
				                      WHEN pin_component_subtype IN (100,105)
                                THEN ',I.ROW_IDENTIFIER ROW_IDENTIFIER'  END||chr(10)||chr(32)||
                            ',CAST(I.'||v_input_values_column||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COMMISSION_METRIC')||') COMMISSION_METRIC'||chr(10)||chr(32)||
                            ',CAST('||  CASE
                                          WHEN pin_component_subtype IN (101,102,103) THEN 'CAST((I2.RESULT_VALUE)  AS NUMBER ' ||
                                             CASE WHEN pin_lookup_precision IS NULL
                                                THEN COMMONS.FIELD_PRECISION_AND_SCALE('COMMISSION_RATE')
                                                ELSE COMMONS.FIELD_SCALE('COMMISSION_RATE',pin_lookup_precision)
                                             END
                                              ||')'||chr(10)
                                          WHEN pin_component_subtype = 100 		        THEN TO_CHAR(pin_comision_rate_value)
                                          WHEN pin_component_subtype = 105 		        THEN 'MT_COM.COMMISSION_RATE' end ||
                           ' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COMMISSION_RATE')||') COMMISSION_RATE'||chr(10)||chr(32)||
                           CASE
                             WHEN pin_component_subtype IN (101,102,103) THEN ',VLD_NO_LKCURVES,CAST(I2.'||v_lk_input_values_column||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('LOOKUP_METRIC')||') LOOKUP_METRIC'||chr(10)||chr(32)  ELSE '' end ||
                           CASE
                             WHEN pin_component_subtype IN (104)	    THEN ',CAST(NULL AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COLUMN_LOOKUP_METRIC')||') COLUMN_LOOKUP_METRIC'||chr(10)||chr(32)||
                                                  ',CAST(NULL AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('ROW_LOOKUP_METRIC')||') ROW_LOOKUP_METRIC'||chr(10)||chr(32)  ELSE '' END
                          ;

	pout_sql_com_rate_earnings :=CASE WHEN pin_component_subtype = 100		THEN 'I.'||v_input_values_column||'*'||TO_CHAR(pin_comision_rate_value)
					 WHEN pin_component_subtype IN (101,102,103)	THEN 'I.'||v_input_values_column||'*  (CAST((I2.RESULT_VALUE) AS NUMBER ' ||
                         CASE WHEN pin_lookup_precision IS NULL
                            THEN COMMONS.FIELD_PRECISION_AND_SCALE('DETAILED_EARNINGS')
                            ELSE COMMONS.FIELD_SCALE('DETAILED_EARNINGS',pin_lookup_precision)
                         END
                         ||'))'||chr(10)
					 WHEN pin_component_subtype  =105 		THEN 'I.'||v_input_values_column||'*MT_COM.COMMISSION_RATE'
					 WHEN pin_component_subtype IN (104)		THEN 'NULL'
					 ELSE NULL
					END
					;

	-- get the information about the input (metric result table used as input for the component)
	SELECT * INTO v_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=2;
	v_sql_from_input:='INNER JOIN (SELECT '||pin_ece_column_list||',ROW_IDENTIFIER,'||v_input_values_column
                                ||' FROM  '||CASE WHEN v_table.from_clause IS NOT NULL THEN v_table.from_clause ELSE v_table.table_name END||' I '||v_table.where_clause
                                ||') I ON R.'||pin_earning_entity(1).name1||' = I.'||pin_earning_entity(1).name1;

  --here we add the component filtering
  v_sql_from_input:= v_sql_from_input || CHR(10) || REPLACE(pin_sql_comp_filter, 'TAB', 'I');

	 --get lookup parameters when lookup is used for commition rate
	 IF     pin_component_subtype IN (101,102,103,104)
	  THEN
		v_InputColumns:=pin_ece_column_list||','||v_lk_input_values_column||',ROW_IDENTIFIER';
		v_InputColumnsAlias:=pin_ece_column_list_lookup||',TAB.'||v_lk_input_values_column||',TAB.ROW_IDENTIFIER';

		-- get the lookup parameters
		SELECT * INTO v_lookup_table FROM TABLE(pin_lookup_table) WHERE USED_FOR=2;

	DECLARE
		v_stamp varchar2(250 char):= 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_COM_RATE - output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_lookup_table.FROM_CLAUSE) ,',v_lookup_table.FROM_CLAUSE => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_lookup_table.VARY_BY_FIELDS) ,',v_lookup_table.VARY_BY_FIELDS => <value>', v_stamp);
     END;

   IF (v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 IS NOT NULL) AND (v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 IS NOT NULL) THEN
      IF v_lookup_table.VARY_BY_FIELDS IS NOT NULL THEN
         v_lookup_table.VARY_BY_FIELDS := v_lookup_table.VARY_BY_FIELDS || ',' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2;
      ELSE
         v_lookup_table.VARY_BY_FIELDS := v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2;
      END IF;

      IF v_lookup_table.FROM_CLAUSE IS NOT NULL THEN
         v_lookup_table.FROM_CLAUSE := v_lookup_table.FROM_CLAUSE || ' and TAB.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_COLUMN_NAME || '  between nvl(LOOKUP.' ||
                                  v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) and nvl(LOOKUP.' ||
                                  v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))';
      ELSE
         v_lookup_table.FROM_CLAUSE := ' LOOKUP ON TAB.' || v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_COLUMN_NAME || '  between nvl(LOOKUP.' ||
                                  v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) and nvl(LOOKUP.' ||
                                  v_lookup_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))';
     END IF;
   END IF;


		-- get the input used for commission rate lookup ( metric result table used in commission rate lookup)
		-- since in some cases the table type = 12 can be NULL, then we need to use table type as 2 (fix for #16499)
		SELECT * INTO v_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=2;
		v_sql_from_com_rate_input:=CASE WHEN v_table.from_clause IS NOT NULL THEN v_table.from_clause ELSE v_table.table_name END||' '||REPLACE(v_table.where_clause, 'I.', '');
		--if table type = 12 exists
		FOR c IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=12) LOOP
		  SELECT * INTO v_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=12;
		  v_sql_from_com_rate_input:=CASE WHEN v_table.from_clause IS NOT NULL THEN v_table.from_clause ELSE v_table.table_name END||' '||v_table.where_clause;
		END LOOP;
	 END IF;

  -- get the info about the Roster
  v_sql_from_roster := pin_from_roster;
  v_sql_roster_join := 'ON R.'||pin_earning_entity(1).name1||' = TAB.'||pin_earning_entity(1).name1;

  --Add Period filter for lookup table
  v_sql_lookup_table := ' (SELECT * FROM ' || v_lookup_table.table_name || ' ' || v_lookup_table.WHERE_CLAUSE || ')';

	--build the lookup query
	IF     pin_component_subtype = 101 --lookup rate step
		THEN
			SELECT COMPENSATION_PROCESSING.STEP_LOOKUP(
				    pin_InputColumns		=> v_InputColumns
				   ,pin_InputColumnsAlias	=> v_InputColumnsAlias
				   ,pin_InputFrom		=> v_sql_from_com_rate_input
				   ,pin_InputLookupColumn	=> v_lookup_table.lookup_column
				   ,pin_LookupTable		=> v_sql_lookup_table
				   ,pin_LowerValueOption	=> v_lookup_table.lower_value_option
				   ,pin_HigherValueOption	=> v_lookup_table.higher_value_option
           ,pin_RosterFrom          => v_sql_from_roster
           ,pin_RosterJoinClause    => v_sql_roster_join
           ,pin_LookupJoinClause    => v_lookup_table.FROM_CLAUSE
           ,pin_varyByFields        => v_lookup_table.VARY_BY_FIELDS
           ,pin_comp_filter       => pin_sql_comp_filter
				   )
		         INTO v_sql_from_com_rate_lookup
			 FROM DUAL;
 	  ELSIF pin_component_subtype = 102 --lookup rate continuous
		THEN
			SELECT COMPENSATION_PROCESSING.CONTINUOUS_LOOKUP(
							  pin_InputColumns		=> v_InputColumns
							 ,pin_InputColumnsAlias		=> v_InputColumnsAlias
							 ,pin_InputFrom			=> v_sql_from_com_rate_input
               ,pin_InputLookupColumn		=> v_lookup_table.lookup_column
               ,pin_LookupTable		=> v_sql_lookup_table
               ,pin_LowerValueOption		=> v_lookup_table.lower_value_option
               ,pin_HigherValueOption		=> v_lookup_table.higher_value_option
               ,pin_RosterFrom          => v_sql_from_roster
               ,pin_RosterJoinClause    => v_sql_roster_join
               ,pin_LookupJoinClause    => v_lookup_table.FROM_CLAUSE
               ,pin_varyByFields        => v_lookup_table.VARY_BY_FIELDS
               ,pin_comp_filter       => pin_sql_comp_filter
							 )
		         INTO v_sql_from_com_rate_lookup
			 FROM DUAL;
 	  ELSIF pin_component_subtype = 103 --lookup rate discrete value
		THEN
			SELECT COMPENSATION_PROCESSING.DISCRETE_LOOKUP(
							  pin_InputColumns		=> v_InputColumns
							 ,pin_InputColumnsAlias		=> v_InputColumnsAlias
               ,pin_InputFrom			=> v_sql_from_com_rate_input
               ,pin_InputLookupColumn		=> v_lookup_table.lookup_column
               ,pin_LookupTable		=> v_sql_lookup_table
               ,pin_RosterFrom          => v_sql_from_roster
               ,pin_RosterJoinClause    => v_sql_roster_join
               ,pin_LookupJoinClause    => v_lookup_table.FROM_CLAUSE
               ,pin_varyByFields        => v_lookup_table.VARY_BY_FIELDS
               ,pin_comp_filter       => pin_sql_comp_filter
							 )
		         INTO v_sql_from_com_rate_lookup
			FROM DUAL;
 	  ELSIF pin_component_subtype = 104 --lookup rate matrix
		THEN
			v_sql_from_com_rate_lookup:='';

	END IF;
	-- finalize string for lookup
	IF     pin_component_subtype IN (101,102,103,104) THEN
		v_sql_from_com_rate_lookup:='INNER JOIN ('||v_sql_from_com_rate_lookup||') I2 ON '||pin_ece_column_list_join;
	END IF;

	-- build query for match table rate
	IF	pin_component_subtype = 105 --match table rate
		THEN
			--get the commission rate match table
			SELECT * INTO v_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=3;

    v_count_comp_rost := GET_NUMBER_OF_COMPONENT_FILTER(  pin_definition_id  => pin_definition_id);

     --in this case we change the left join to inner join in order not to output error for the entities without commision rate
      IF  v_count_comp_rost > 0 THEN
        v_sql_from_com_rate_mt:='INNER JOIN (SELECT * FROM '||v_table.table_name||' '||v_table.where_clause||') '||v_table.from_clause;
	    ELSE
        v_sql_from_com_rate_mt:='LEFT JOIN (SELECT * FROM '||v_table.table_name||' '||v_table.where_clause||') '||v_table.from_clause;
	    END IF;

	END IF;
	/*
	pout_sql_com_rate_from:=  v_sql_from_input||chr(10)
				||v_sql_from_com_rate_lookup||chr(10)
				||v_sql_from_com_rate_mt;
	*/
	pout_sql_com_rate_i_from:=v_sql_from_input||chr(10);



  --pout_sql_com_rate_i_from:= pout_sql_com_rate_i_from ||



	pout_sql_com_rate_from:=v_sql_from_com_rate_lookup||chr(10)
				||v_sql_from_com_rate_mt;

  declare
    v_stamp varchar2(250 char):= 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_COM_RATE - output'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
  begin
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pout_sql_com_rate_insert) ,     ',pout_sql_com_rate_insert          => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pout_sql_com_rate_select) ,     ',pout_sql_com_rate_select          => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pout_sql_com_rate_earnings),    ',pout_sql_com_rate_earnings        => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_from),            ',pout_sql_com_rate_from            => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_prval_insert_com_rate),    ',pout_sql_prval_insert_com_rate    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_prval_select_com_rate),    ',pout_sql_prval_select_com_rate    => <value>' , v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_i_from),          ',pout_sql_com_rate_i_from          => <value>' , v_stamp);
  end;
    END IF;

   END BUILD_SQL_DETAIL_COM_RATE;
   -- ############################# BUILD_SQL_DETAIL_COM_RATE END   #############################

    -- ############################# BUILD_SQL_DETAIL_COM_RATE_TIERED START   #############################
    PROCEDURE BUILD_SQL_DETAIL_COM_RATE_TIER
    (	 pin_component_type		          IN NUMBER
      ,pin_component_subtype          IN NUMBER
      ,pin_lookup_table		            IN tabletype_lookup_table_list
      ,pin_input_table_list	          IN tabletype_input_table_list
      ,pin_input_values_column		IN VARCHAR2
      ,pin_earning_entity		          IN tabletype_name_map
      ,pin_ece_column_list	          IN VARCHAR2
      ,pin_ece_column_list_vld        IN VARCHAR2
      ,pin_ece_column_list_join       IN VARCHAR2
      ,pin_sql_comp_filter            IN VARCHAR2-- #ADDED
      ,pout_sql_com_rate_insert       OUT clob
      ,pout_sql_com_rate_select       OUT clob
      ,pout_sql_com_rate_earnings	    OUT clob
      ,pout_sql_com_rate_from         OUT clob
      ,pout_sql_prval_insert_com_rate OUT clob
      ,pout_sql_prval_select_com_rate OUT clob
      ,pout_sql_com_rate_i_from       OUT clob
	) AS
	v_source_table              objtype_input_table_list;
    v_earnings_in_tiers_table   objtype_input_table_list;
    v_tab_indx				    PLS_INTEGER;
    v_stamp varchar2(250 char):= 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_COM_RATE_TIER - input'||TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN

    if pin_component_type = 4 then

      --1. Get the information about the input (metric result table used as input for the component)

      v_tab_indx := pin_input_table_list.FIRST;
        WHILE (v_tab_indx IS NOT NULL)
        LOOP
          IF pin_input_table_list(v_tab_indx).TABLE_TYPE = 2   -- Metric/Component Input
          THEN
            v_source_table := pin_input_table_list(v_tab_indx);
          ELSIF pin_input_table_list(v_tab_indx).TABLE_TYPE = 17 -- Earnings in tiers - contains the detailed data to be aggregated
          THEN
            v_earnings_in_tiers_table := pin_input_table_list(v_tab_indx);
          END IF;
          v_tab_indx := pin_input_table_list.NEXT(v_tab_indx);
        END LOOP;

      --4. Build the Out Parameters

	  pout_sql_com_rate_select       := ',cast(I.'||pin_input_values_column||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COMMISSION_METRIC')  || ') COMMISSION_METRIC'||chr(10)||chr(32);
      pout_sql_com_rate_insert       := ',COMMISSION_METRIC';
      pout_sql_com_rate_i_from       := ' INNER JOIN (SELECT '|| pin_ece_column_list ||',ROW_IDENTIFIER,'||pin_input_values_column
                                                    ||' FROM  '|| CASE WHEN v_source_table.from_clause IS NOT NULL THEN v_source_table.from_clause ELSE v_source_table.table_name END ||' I '||v_source_table.where_clause
                                                    ||') I ON R.'||pin_earning_entity(1).name1||' = I.'||pin_earning_entity(1).name1;
      pout_sql_com_rate_from         := ' LEFT JOIN (SELECT '||pin_ece_column_list||', SUM( COMMISSION_RATE * AMOUNT_IN_TIER ) AS DETAILED_EARNINGS'||CHR(10)
                                        ||'FROM '||v_earnings_in_tiers_table.table_name||CHR(10)
                                        ||'GROUP BY '||pin_ece_column_list||') TE ON '||REPLACE(pin_ece_column_list_join, 'I2.', 'TE.');
      pout_sql_com_rate_from            := pout_sql_com_rate_from || CHR(10) || REPLACE (pin_sql_comp_filter,'TAB','I');
      pout_sql_com_rate_earnings     := 'TE.DETAILED_EARNINGS';

      --6. Log the output values
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_insert) ,     ',pout_sql_com_rate_insert          => <value>' , replace(v_stamp,'input','output'));
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_select) ,     ',pout_sql_com_rate_select          => <value>' , replace(v_stamp,'input','output'));
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_earnings),        ',pout_sql_com_rate_earnings        => <value>' , replace(v_stamp,'input','output'));
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_from),            ',pout_sql_com_rate_from            => <value>' , replace(v_stamp,'input','output'));
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_prval_insert_com_rate),    ',pout_sql_prval_insert_com_rate    => <value>' , replace(v_stamp,'input','output'));
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_prval_select_com_rate),    ',pout_sql_prval_select_com_rate    => <value>' , replace(v_stamp,'input','output'));
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pout_sql_com_rate_i_from),          ',pout_sql_com_rate_i_from          => <value>' , replace(v_stamp,'input','output'));

    end if;




    END BUILD_SQL_DETAIL_COM_RATE_TIER;
    -- ############################# BUILD_SQL_DETAIL_COM_RATE_TIERED END   #############################


    -- ############################# BUILD_SQL_DETAIL_CUST_FORM START   #############################
    PROCEDURE BUILD_SQL_DETAIL_CUST_FORM
    (    pin_component_type         IN NUMBER
        ,pin_earning_entity		    IN TABLETYPE_NAME_MAP
        ,pin_earning_calc_ent		IN TABLETYPE_CPM_ENTITIES
        ,pin_input_table_list       IN TABLETYPE_INPUT_TABLE_LIST
        ,pin_input_values_column	IN VARCHAR2
        ,pin_cust_form_clauses      IN TABLETYPE_CUST_FORM_CLAUSES
        ,pin_cust_form_ass_ent      IN TABLETYPE_NAME_JOIN_MAP
        ,pin_ece_column_list        IN VARCHAR2
        ,pin_ece_column_list_vld    IN VARCHAR2
        ,pin_ece_column_list_join	IN VARCHAR2
        ,pin_sql_comp_filter  IN VARCHAR2-- #ADDED
        ,pio_ece_column_list_sel    IN OUT VARCHAR2
        ,po_sql_from                OUT CLOB
        ,po_sql_sql_prval_insert    OUT CLOB
    ) AS
        v_ece_column_list_join  VARCHAR2(2000 CHAR);
        v_first_input_number    NUMBER;
        v_stamp varchar2(250 char);
        v_comp_filter_number    NUMBER;
   BEGIN
     v_stamp := 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_CUST_FORM - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');


        IF (pin_component_type = 3)
        THEN
            -- add to the main from clause the joins between each input
            FOR cv_input IN
            (   SELECT *
                FROM (  SELECT   ROW_NUMBER() OVER (PARTITION BY NULL ORDER BY CASE WHEN C.INPUT_NUMBER IS NOT NULL THEN 1 ELSE 2 END ASC, I.INPUT_NUMBER ASC) AS INPUT_ORDER
                                ,I.INPUT_NUMBER
                                ,I.TABLE_NAME
                                ,I.FROM_CLAUSE
                                ,I.WHERE_CLAUSE
                                ,C.SELECT_CLAUSE AS CUST_SELECT_CLAUSE
                                ,C.FROM_CLAUSE AS CUST_FROM_CLAUSE
                        FROM    TABLE(pin_input_table_list) I
                                LEFT JOIN TABLE(pin_cust_form_clauses) C ON I.INPUT_NUMBER = C.INPUT_NUMBER
                        WHERE  I.TABLE_TYPE = 2) I
                ORDER BY INPUT_ORDER
            )
            LOOP
                -- each input has the same query form
                po_sql_from := po_sql_from||'INNER JOIN (SELECT '
                        ||pin_ece_column_list||','||pin_input_values_column
                        ||CASE WHEN cv_input.CUST_SELECT_CLAUSE IS NOT NULL THEN ','||REPLACE(cv_input.CUST_SELECT_CLAUSE, 'I'||cv_input.INPUT_NUMBER||'.', 'I.') ELSE NULL END
                    ||' FROM '||cv_input.TABLE_NAME||' I'
                    ||CASE WHEN cv_input.CUST_FROM_CLAUSE IS NOT NULL THEN ' '||REPLACE(cv_input.CUST_FROM_CLAUSE, 'I'||cv_input.INPUT_NUMBER||'.', 'I.') ELSE NULL END
                    ||' '||cv_input.WHERE_CLAUSE||') I'||cv_input.INPUT_NUMBER;

                    v_comp_filter_number := cv_input.INPUT_NUMBER;
                    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertNumber(cv_input.INPUT_NUMBER) ,',cv_input.INPUT_NUMBER => <value>', v_stamp);

                -- but first input will be joined with the roster based on EE only
                -- the rest of them will be joined with the first input based on all ECE columns
                IF (cv_input.INPUT_ORDER = 1)
                THEN
                    v_first_input_number := cv_input.INPUT_NUMBER;
                    v_ece_column_list_join := REPLACE(pin_ece_column_list_join, 'I.', 'I'||cv_input.INPUT_NUMBER||'.');
                    po_sql_from := po_sql_from||' ON R.'||pin_earning_entity(1).NAME1||' = I'||cv_input.INPUT_NUMBER||'.'||pin_earning_entity(1).NAME1||CHR(10);
                ELSE
                    po_sql_from := po_sql_from||' ON '||REPLACE(v_ece_column_list_join, 'I2.', 'I'||cv_input.INPUT_NUMBER||'.')||CHR(10);
                END IF;
            END LOOP;

            -- add to the main from clause the joins with the entity tables of each entity in ECE
            -- this is to have access to their BK
            FOR cv_entity IN
            (   SELECT ENTITY_TYPE, ENTITY_NAME, ENTITY_TABLE_NAME
                FROM TABLE(pin_earning_calc_ent) E
                WHERE E.ENTITY_TYPE IN (1, 3, 4) AND E.COLUMN_TYPE = 1
            )
            LOOP
                po_sql_from := po_sql_from||CASE WHEN cv_entity.ENTITY_TYPE = 1 THEN 'INNER' ELSE 'LEFT' END
                    ||' JOIN '||cv_entity.ENTITY_TABLE_NAME||' '||cv_entity.ENTITY_NAME
                    ||' ON I'||v_first_input_number||'.'||cv_entity.ENTITY_NAME||' = '||cv_entity.ENTITY_NAME||'.E_INTERNAL_ID'||CHR(10);
            END LOOP;

            -- if roster is built based on an assignment between EE and another entity
            -- then also add a join with that entity's table to have access to it's BK
            FOR cv_ass_entity IN
            (   SELECT NAME1 AS ENTITY_NAME, NAME2 AS ENTITY_TABLE_NAME, NAME3 AS ENTITY_FIELD_NAME
                FROM TABLE(pin_cust_form_ass_ent) AE
                WHERE NOT EXISTS (SELECT 1 FROM TABLE(pin_earning_calc_ent) E
                                  WHERE E.ENTITY_TYPE IN (1, 3, 4) AND E.COLUMN_TYPE = 1
                                        AND E.ENTITY_NAME = AE.NAME1)
            )
            LOOP
                po_sql_from := po_sql_from||'INNER JOIN '||cv_ass_entity.ENTITY_TABLE_NAME||' '||cv_ass_entity.ENTITY_NAME
                    ||' ON R.'||cv_ass_entity.ENTITY_NAME||' = '||cv_ass_entity.ENTITY_NAME||'.E_INTERNAL_ID'||CHR(10);
            END LOOP;

            po_sql_from := po_sql_from || CHR(10) || REPLACE(pin_sql_comp_filter, 'TAB', 'I'||v_comp_filter_number);

            pio_ece_column_list_sel := REPLACE(pio_ece_column_list_sel, 'I.', 'I'||v_first_input_number||'.');
            po_sql_sql_prval_insert := 'WHEN (DETAILED_EARNINGS IS NULL) THEN INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID) VALUES ('||pin_ece_column_list||',2700)'||CHR(10);

      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(po_sql_from) ,',po_sql_from => <value>', v_stamp);
      L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_input_values_column) ,',pin_input_values_column => <value>', v_stamp);


        END IF;
    END BUILD_SQL_DETAIL_CUST_FORM;
    -- ############################# BUILD_SQL_DETAIL_CUST_FORM END   #############################

    -- ############################# BUILD_SQL_DETAIL_TARGET START   #############################
    PROCEDURE BUILD_SQL_DETAIL_TARGET
    (	 pin_use_target			        IN	NUMBER
		,pin_input_table_list		    IN	tabletype_input_table_list
        ,pin_plan_target_earn_val		IN	NUMBER
		,pin_component_weight_value		IN	NUMBER
		,pin_no_plan_per_for_comp_per	IN	NUMBER
		,pin_no_plan_per_for_target		IN	NUMBER
		,pin_comp_target_earn_val		IN	NUMBER
		,pin_no_comp_per_for_target		IN	NUMBER
		,pin_no_comp_per_pas_in_sub IN NUMBER
		,pin_ece_column_list		    IN VARCHAR2
		,pin_ece_column_list_vld	    IN VARCHAR2
		,pin_component_weight_fields    IN	tabletype_id_name
        ,pin_lookup_precision           IN	NUMBER
		,pinout_earnings			    IN OUT	VARCHAR2
		,pout_sql_target_insert		    OUT	VARCHAR2
		,pout_sql_target_select		    OUT	VARCHAR2
		,pout_sql_target_from		    OUT	CLOB
		,pout_sql_prval_insert_target	OUT	CLOB
		,pout_sql_prval_select_target	OUT	CLOB
	) AS
		v_target			VARCHAR2(32767);
    v_plan_te     VARCHAR2(32767);
    v_comp_weight VARCHAR2(32767);
		v_weight_join_column	VARCHAR2(250);
		v_curent_component_weight	VARCHAR2(30);
		v_sum_component_weights	VARCHAR2(32767);
    v_prec_earn_fact_sys    NUMBER;
    v_prec_earn_fact        VARCHAR2(200 CHAR);
    v_stamp					    VARCHAR2(200);

    BEGIN
      v_stamp := 'COMPONENTS_PROCESSING.BUILD_SQL_DETAIL_TARGET - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    IF pin_use_target    IN (1,2)  --0 no target, 1 with plan target, 2 with component target
     THEN
       IF (pin_use_target = 1) THEN
         	pout_sql_target_insert:=',EARNINGS_FACTOR'||chr(10)||chr(32)||
          ',PLAN_TARGET_EARNINGS'||chr(10)||chr(32)||
          ',COMPONENT_WEIGHT'||chr(10)||chr(32)||
				  ',TARGET_EARNINGS'||chr(10)||chr(32);
       ELSE
         	pout_sql_target_insert:=',EARNINGS_FACTOR'||chr(10)||chr(32)||
				  ',TARGET_EARNINGS'||chr(10)||chr(32);
       END IF;


	-- get a KEY column from weight match table
	FOR v_table IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE IN (4)) LOOP

	v_weight_join_column:=LTRIM(LTRIM(RTRIM(
				SUBSTRC(v_table.from_clause
					,3+INSTRC(v_table.from_clause,'ON',1)
					,INSTRC(v_table.from_clause,'=',1)-3-INSTRC(v_table.from_clause,'ON',1)
					)
				)), '(');
	END LOOP;
	-- get weight column and sum of weights
	FOR v_comp_id IN (SELECT * FROM TABLE(pin_component_weight_fields) ) LOOP
	 IF v_comp_id.id=0 THEN
	  v_curent_component_weight:= v_comp_id.name;
	 END IF;
	  v_sum_component_weights:=(CASE WHEN v_sum_component_weights IS NOT NULL THEN v_sum_component_weights||'+' END)||v_comp_id.name;
	END LOOP;

	pout_sql_prval_insert_target:= CASE WHEN pin_use_target =1 AND pin_plan_target_earn_val IS NULL
											 THEN 'WHEN (TARGET IS NULL) THEN'||chr(10)||chr(32)
											     ||'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'||chr(10)||chr(32)
											     ||'VALUES ('||pin_ece_column_list||',2610)'||chr(10) END
					||CASE WHEN pin_use_target =1 AND pin_component_weight_value IS NULL
											 THEN 'WHEN (WEIGHT_JOIN_COLUMN IS NULL) THEN'||chr(10)||chr(32)
											     ||'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'||chr(10)||chr(32)
											     ||'VALUES ('||pin_ece_column_list||',2630)'||chr(10)
											     ||'WHEN (WEIGHT_JOIN_COLUMN IS NOT NULL AND '||v_curent_component_weight||' IS NULL) THEN'||chr(10)||chr(32)
											     ||'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'||chr(10)||chr(32)
											     ||'VALUES ('||pin_ece_column_list||',2650)'||chr(10)
											     ||'WHEN (WEIGHT_JOIN_COLUMN IS NOT NULL AND '||v_curent_component_weight||' IS NOT NULL AND NVL(WEIGHT_SUM,0)!=1) THEN'||chr(10)||chr(32)
											     ||'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'||chr(10)||chr(32)
											     ||'VALUES ('||pin_ece_column_list||',2670)'||chr(10) END
					||CASE WHEN pin_use_target =2 AND pin_comp_target_earn_val IS NULL
											 THEN 'WHEN (TARGET IS NULL) THEN'||chr(10)||chr(32)
											     ||'INTO TEMP_PROC_VALIDATION_VALUES ('||pin_ece_column_list_vld||',VALIDATION_ID)'||chr(10)||chr(32)
											     ||'VALUES ('||pin_ece_column_list||',2690)'||chr(10)
					     END;

 L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pout_sql_prval_insert_target) ,'pout_sql_prval_insert_target := <value>', v_stamp);


	pout_sql_prval_select_target:=    CASE WHEN pin_use_target =1 AND pin_plan_target_earn_val IS NULL
												 THEN ',TARGET'||chr(10) END
					||CASE WHEN pin_use_target =1 AND pin_component_weight_value IS NULL
												 THEN ','||v_curent_component_weight||chr(10)
												    ||',WEIGHT_JOIN_COLUMN'||chr(10)
												    ||',WEIGHT_SUM' END
					||CASE WHEN pin_use_target =2 AND pin_comp_target_earn_val IS NULL
												 THEN ',TARGET'||chr(10)
						     END

					;
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pout_sql_prval_select_target) ,'pout_sql_prval_select_target := <value>', v_stamp);


	v_plan_te        := CASE WHEN pin_use_target = 1 THEN
							CASE WHEN pin_plan_target_earn_val IS NULL
								  THEN ' MT_P_TARGET.TARGET_EARNINGS  *('||pin_no_plan_per_for_comp_per||'/'||pin_no_plan_per_for_target||')' ||'*'||NVL(pin_no_comp_per_pas_in_sub,1)
								  ELSE TO_CHAR(pin_plan_target_earn_val) ||' *('||pin_no_plan_per_for_comp_per||'/'||pin_no_plan_per_for_target||')' ||'*'||NVL(pin_no_comp_per_pas_in_sub,1)
						   END
						 END;
	v_comp_weight    :=CASE WHEN pin_use_target = 1 THEN
							CASE WHEN pin_component_weight_value IS NULL
								 THEN ' MT_WEIGTH.'||v_curent_component_weight
								 ELSE TO_CHAR(pin_component_weight_value)
							END
						 END;

   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(v_plan_te) ,'v_plan_te := <value>', v_stamp);
   L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(v_comp_weight) ,'v_comp_weight := <value>', v_stamp);


	v_target:= CASE WHEN pin_use_target =1
			THEN
        v_plan_te ||' * ' || v_comp_weight
			WHEN pin_use_target =2
			THEN CASE WHEN pin_comp_target_earn_val IS NOT NULL
				  THEN TO_CHAR(pin_comp_target_earn_val)
				  ELSE 'MT_C_TARGET.TARGET_EARNINGS'
				 END
			   ||'/'||pin_no_comp_per_for_target
			   ||'*'||NVL(pin_no_comp_per_pas_in_sub,1)
			 END
			 ;
  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(v_target) ,'v_target := <value>', v_stamp);


	pout_sql_target_select:=  ',CAST('||pinout_earnings||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('EARNINGS_FACTOR')||') EARNINGS_FACTOR'||chr(10)||chr(32)
       ||CASE WHEN pin_use_target = 1 THEN
              ',CAST('|| v_plan_te ||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('PLAN_TARGET_EARNINGS')||') PLAN_TARGET_EARNINGS'||chr(10)||chr(32)
            ||',CAST('|| v_comp_weight ||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COMPONENT_WEIGHT')||') COMPONENT_WEIGHT'||chr(10)||chr(32)
         END
				||',CAST('||v_target||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('TARGET_EARNINGS')||') TARGET_EARNINGS'||chr(10)||chr(32)
				||CASE WHEN pin_use_target =1 AND pin_plan_target_earn_val IS NULL
											 THEN ',MT_P_TARGET.TARGET_EARNINGS TARGET'||chr(10) END
				||CASE WHEN pin_use_target =1 AND pin_component_weight_value IS NULL
											 THEN ',MT_WEIGTH.'||v_curent_component_weight||' '||v_curent_component_weight||chr(10)
											    ||','||v_weight_join_column||' WEIGHT_JOIN_COLUMN'||chr(10)
											    ||','||v_sum_component_weights||' WEIGHT_SUM' END
				||CASE WHEN pin_use_target =2 AND pin_comp_target_earn_val IS NULL
											 THEN ',MT_C_TARGET.TARGET_EARNINGS TARGET'||chr(10)
					     END;

  L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertVarchar2(pout_sql_target_select) ,'pout_sql_target_select := <value>', v_stamp);


	pinout_earnings:='('||pinout_earnings||')
			 *('||v_target||')'
			 ;
/*
    SELECT FLD_LENGTH INTO v_prec_earn_fact_sys FROM FIELDS WHERE FLD_COLUMN_NAME ='EARNINGS_FACTOR';
    IF pin_lookup_precision < v_prec_earn_fact_sys THEN
        v_prec_earn_fact := COMMONS.FIELD_SCALE('EARNINGS_FACTOR',pin_lookup_precision);
    ELSE
        v_prec_earn_fact := COMMONS.FIELD_PRECISION_AND_SCALE('EARNINGS_FACTOR');
    END IF;

    --adding the precission in order to have the earnings factor system precission displayed in the result table
    pinout_earnings := ' (CAST( '|| pinout_earnings || ' AS NUMBER '||
                  CASE WHEN pin_lookup_precision IS NULL
                            THEN COMMONS.FIELD_PRECISION_AND_SCALE('EARNINGS_FACTOR')
                            ELSE v_prec_earn_fact END
                  ||'))'||chr(10)  ;
*/

	--get match tables:4 component weight, 5 plan target, 6 component target
	FOR v_table IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE IN (4,5,6)) LOOP
		pout_sql_target_from:=pout_sql_target_from||'LEFT JOIN (SELECT * FROM '||v_table.table_name||' '||v_table.where_clause||') '||v_table.from_clause||chr(10);
	END LOOP;

 L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.ConvertClob(pout_sql_target_from) ,'pout_sql_target_from := <value>', v_stamp);


    END IF;

    END BUILD_SQL_DETAIL_TARGET;
    -- ############################# BUILD_SQL_DETAIL_TARGET END   #############################

	-- #############################    BUILD_SELECTED_RECS_FILTER  START   #############################
	/*
	---------------------------------------------------------------------------------------
	Author     : Dumitriu, Cosmin
	Create date: 2015.OCT.21
	Description:
	-----------------------------------------------------------------------------------------
	    pin_step := 1 - DETAILED_EARNINGS
                    2 - AGGREGATED_EARNINGS
                    3 - MODIFIED_EARNINGS
                    4 - COMPONENT_EARNINGS
    */
    PROCEDURE BUILD_SELECTED_RECS_FILTER
    (    pin_step               IN NUMBER
        ,pin_input_table_list   IN TABLETYPE_INPUT_TABLE_LIST
        ,pin_definition_id      IN NUMBER
        ,pin_src_table_alias    IN VARCHAR2
        ,pin_earning_entity     IN VARCHAR2
        ,pin_payment_entity     IN VARCHAR2
		,pout_delete_string     OUT VARCHAR2
        ,pout_join_string       OUT VARCHAR2
    ) IS
        v_comp_roster_table         RTYPE_TABLE_LIST;
        v_comp_roster_table_exists  NUMBER := 0;
        v_from_string               VARCHAR2(2000 CHAR);
        v_temp_string               VARCHAR2(2000 CHAR);
        v_roster_0                  objtype_input_table_list;
        v_roster_1                  objtype_input_table_list;
        v_roster_14                 objtype_input_table_list;
        v_roster_15                 objtype_input_table_list;
        v_sel_roster                objtype_input_table_list;
        v_tab_indx                  NUMBER;
    BEGIN
        -- see if comp rostering is used
        FOR cv_comp_roster IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE = 30)
        LOOP
            v_comp_roster_table_exists := 1;
            v_comp_roster_table := cv_comp_roster;
        END LOOP;

        IF (pin_step IN (1, 2, 3))
        THEN
            FOR vr_roster IN (SELECT * FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE IN (14))
            LOOP
                v_temp_string := vr_roster.WHERE_CLAUSE;

                IF (v_comp_roster_table_exists = 1)
                THEN
                    v_temp_string := v_temp_string||CASE WHEN v_temp_string IS NOT NULL THEN ' AND ' ELSE NULL END
                        ||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id);

                    v_temp_string := v_temp_string||CASE WHEN v_comp_roster_table.WHERE_CLAUSE IS NOT NULL THEN ' AND '||v_comp_roster_table.WHERE_CLAUSE ELSE NULL END;
                END IF;

                v_from_string := ' FROM '||vr_roster.table_name||CHR(10)
                    ||CASE WHEN v_comp_roster_table_exists = 1
                           THEN 'INNER JOIN '||v_comp_roster_table.TABLE_NAME||' '||REPLACE(REPLACE(v_comp_roster_table.FROM_CLAUSE
                                                                                                    ,'R.'
                                                                                                    ,vr_roster.TABLE_NAME||'.'
                                                                                                    )
                                                                                            ,'RC.'
                                                                                            ,v_comp_roster_table.TABLE_NAME||'.')||CHR(10)
                           ELSE NULL END
                    ||CASE WHEN v_temp_string IS NOT NULL THEN 'WHERE '||v_temp_string||CHR(10) ELSE NULL END;

                pout_delete_string := pin_earning_entity||' IN (SELECT '||vr_roster.table_name||'.'||pin_earning_entity
                    ||v_from_string
                    ||')';

                pout_join_string := 'INNER JOIN (SELECT '||vr_roster.table_name||'.*'
                    ||v_from_string
                    ||') R ON '||pin_src_table_alias||'.' ||pin_earning_entity||' = R.'||pin_earning_entity;
            END LOOP;
        ELSIF (pin_step = 4)
        THEN
            /***roster***/
            -- roster table is used for two purposes:
            -- * when earning entity <> payment entity we need to expand the earning records to payment level
            -- * when user includes only "selected records" we need to delete and then insert back only those records
            -- sometimes we need to both filter and expand at the same time
            -- sometimes we don't need anything
            v_tab_indx := pin_input_table_list.FIRST;
            WHILE (v_tab_indx IS NOT NULL)
            LOOP
                IF    (pin_input_table_list(v_tab_indx).TABLE_TYPE = 0)  THEN v_roster_0  := pin_input_table_list(v_tab_indx);
                ELSIF (pin_input_table_list(v_tab_indx).TABLE_TYPE = 1)  THEN v_roster_1  := pin_input_table_list(v_tab_indx);
                ELSIF (pin_input_table_list(v_tab_indx).TABLE_TYPE = 14) THEN v_roster_14 := pin_input_table_list(v_tab_indx);
                ELSIF (pin_input_table_list(v_tab_indx).TABLE_TYPE = 15) THEN v_roster_15 := pin_input_table_list(v_tab_indx);
                END IF;

                v_tab_indx := pin_input_table_list.NEXT(v_tab_indx);
            END LOOP;

            -- if user includes only "selected records" we need to delete only those values
            -- the table list will contain either 14 or (14 and 15 - if EE <> PE)
            IF (v_roster_14 IS NOT NULL)
            THEN
                v_temp_string := v_roster_14.WHERE_CLAUSE;

                IF (v_comp_roster_table_exists = 1)
                THEN
                    v_temp_string := v_temp_string||CASE WHEN v_temp_string IS NOT NULL THEN ' AND ' ELSE NULL END
                        ||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id);

                    v_temp_string := v_temp_string||CASE WHEN v_comp_roster_table.WHERE_CLAUSE IS NOT NULL THEN ' AND '||v_comp_roster_table.WHERE_CLAUSE ELSE NULL END;
                END IF;

                pout_delete_string := pin_earning_entity||' IN (SELECT '||v_roster_14.table_name||'.'||pin_earning_entity
                    ||' FROM '||v_roster_14.table_name||CHR(10)
                    ||CASE WHEN v_comp_roster_table_exists = 1
                           THEN 'INNER JOIN '||v_comp_roster_table.TABLE_NAME||' '||REPLACE(REPLACE(v_comp_roster_table.FROM_CLAUSE
                                                                                                    ,'R.'
                                                                                                    ,v_roster_14.TABLE_NAME||'.'
                                                                                                    )
                                                                                            ,'RC.'
                                                                                            ,v_comp_roster_table.TABLE_NAME||'.')||CHR(10)
                           ELSE NULL END
                    ||CASE WHEN v_temp_string IS NOT NULL THEN 'WHERE '||v_temp_string||CHR(10) ELSE NULL END
                    ||')';
            END IF;

            -- if EE <> PE and processing is done for all records - we need to join with roster 1 in order to expand at payment level
            IF (pin_earning_entity != pin_payment_entity AND v_roster_1 IS NOT NULL)
            THEN v_sel_roster := v_roster_1;

            -- if EE <> PE and processing is done for "selected" records - we need to join with roster 15 in order to filter only selected and expand at payment level
            ELSIF (pin_earning_entity != pin_payment_entity AND v_roster_15 IS NOT NULL)
            THEN v_sel_roster := v_roster_15;

            -- if EE = PE and processing is done for "selected" records - we need to join with roster 14 in order to filter only selected
            ELSIF (pin_earning_entity = pin_payment_entity AND v_roster_14 IS NOT NULL)
            THEN v_sel_roster := v_roster_14;
            END IF;

            IF (v_sel_roster IS NOT NULL)
            THEN
                v_temp_string := v_sel_roster.WHERE_CLAUSE;

                IF (v_comp_roster_table_exists = 1)
                THEN
                    v_temp_string := v_temp_string||CASE WHEN v_temp_string IS NOT NULL THEN ' AND ' ELSE NULL END
                        ||v_comp_roster_table.TABLE_NAME||'.COMPONENT_NAME = '||TO_CHAR(pin_definition_id);

                    v_temp_string := v_temp_string||CASE WHEN v_comp_roster_table.WHERE_CLAUSE IS NOT NULL THEN ' AND '||v_comp_roster_table.WHERE_CLAUSE ELSE NULL END;
                END IF;

                pout_join_string := 'INNER JOIN (SELECT '||v_sel_roster.table_name||'.*'
                    ||' FROM '||v_sel_roster.table_name||CHR(10)
                    ||CASE WHEN v_comp_roster_table_exists = 1
                           THEN CASE WHEN v_roster_1 IS NOT NULL THEN 'INNER JOIN '||v_roster_0.TABLE_NAME||' ON '||v_sel_roster.TABLE_NAME||'.'||pin_earning_entity||' = '||v_roster_0.TABLE_NAME||'.'||pin_earning_entity||CHR(10)
                                     WHEN v_roster_15 IS NOT NULL THEN 'INNER JOIN '||v_roster_14.TABLE_NAME||' ON '||v_sel_roster.TABLE_NAME||'.'||pin_earning_entity||' = '||v_roster_14.TABLE_NAME||'.'||pin_earning_entity||CHR(10)
                                     ELSE NULL END
                                ||'INNER JOIN '||v_comp_roster_table.TABLE_NAME||' '||REPLACE(REPLACE(v_comp_roster_table.FROM_CLAUSE
                                                                                                    ,'R.'
                                                                                                    ,COALESCE(v_roster_0.TABLE_NAME, v_roster_14.TABLE_NAME, v_sel_roster.TABLE_NAME)||'.'
                                                                                                    )
                                                                                            ,'RC.'
                                                                                            ,v_comp_roster_table.TABLE_NAME||'.')||CHR(10)
                           ELSE NULL END
                    ||CASE WHEN v_temp_string IS NOT NULL THEN 'WHERE '||v_temp_string||CHR(10) ELSE NULL END
                    ||') R ON '||pin_src_table_alias||'.' ||pin_earning_entity||' = R.'||pin_earning_entity;
            END IF;
        END IF;
    END BUILD_SELECTED_RECS_FILTER;

    -- ############################# BUILD_SELECTED_RECS_FILTER END   #############################

	-- #############################    CREATE_DETAILED_EARNINGS_TIER  START   #############################
	/*
	---------------------------------------------------------------------------------------
	Author     : Filip, Catalin
	Create date: 2014-12-12
	Description:

	---------------------------------------------------------------------------------------
	Input Parameters: Inherit parameters from RUN_COMPONENT

	-----------------------------------------------------------------------------------------
	Result set:

	-----------------------------------------------------------------------------------------
	Example:
	CALL CREATE_DETAILED_EARNINGS_TIER (
		 pin_input_table_list			=> tabletype_input_table_list(
											 objtype_input_table_list('T_INPUT', '', '', 2, 1)
											,objtype_input_table_list('T1000', '', '', 8, 1)
											,objtype_input_table_list('T2000', '', '', 9, 1)
											)
		,pin_earning_entity				=> tabletype_name_map('E777','F5')
		,pin_aggregation_type			=> 3
		,pin_period_column				=> 'F100'
		,pin_current_period				=> 1002
		,pin_projected_period_column	=> 'F10'
		,pin_projected_period			=> 103
		,pin_projected					=> 1
	);

	-----------------------------------------------------------------------------------------
	*/
	PROCEDURE CREATE_DETAILED_EARNINGS_TIER
	(	 pin_definition_id         IN NUMBER
    ,pin_input_table_list			    IN tabletype_input_table_list
    ,pin_input_values_column		IN VARCHAR2
    ,pin_lookup_table             IN tabletype_lookup_table_list
		,pin_earning_entity				    IN tabletype_name_map
    ,pin_earning_calc_ent		      IN TABLETYPE_CPM_ENTITIES
		,pin_no_plan_per_for_target	  IN NUMBER
		,pin_component_subtype		    IN NUMBER
		,pin_period_column				    IN VARCHAR2
		,pin_current_period				    IN NUMBER
		,pin_projected_period_column	IN VARCHAR2
		,pin_projected_period			    IN NUMBER
		,pin_projected					      IN number

	)
  is
		v_dest_table				          objtype_input_table_list;
		v_source_table				        objtype_input_table_list;
		v_targets_table				        objtype_input_table_list;
    v_tiers_table                 objtype_lookup_table_list;
    v_exceptions_table            objtype_lookup_table_list;
		v_tab_indx					          PLS_INTEGER;
		v_input_param_error_message	  CLOB;
		v_ece_column_list             VARCHAR2(32000 CHAR);
		v_delete_string				        CLOB;
		v_insert_string				        CLOB;
		v_select_string				        CLOB;
	  v_sql_from_roster		          VARCHAR2(32767);
    v_in_input_table_list		      tabletype_input_table_list;
    v_in_lookup_table_list        tabletype_lookup_table_list;
	  v_ece_column_list_sel		      VARCHAR2(32767);
	  v_ece_column_list_vld		      VARCHAR2(32767);
    v_sql_input_join              VARCHAR2(32767);
    v_sql_tiers_join              VARCHAR2(32767);
    v_sql_exceptions_join         VARCHAR2(32767);
    v_sql_targets_join            VARCHAR2(32767);
    v_sql_validation_clause       VARCHAR2(32767);
    v_hint_loc                    VARCHAR2(2000 CHAR);
	  v_hint                        VARCHAR2(2000 CHAR);
    v_roster_delete_string        VARCHAR2(32000 CHAR);
    v_roster_join_string          VARCHAR2(32000 CHAR);
    v_stamp                       varchar2(250 char):= 'COMPONENTS_PROCESSING.CREATE_DETAILED_EARNINGS_TIER  - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
	  v_varyby_eff_lk               VARCHAR2(32767);
    v_varyby_eff_ex               VARCHAR2(32767);
    v_from_clause_lk              VARCHAR2(32767);
    v_from_clause_ex              VARCHAR2(32767);
    v_tiers_uv                    VARCHAR2(32767);
    v_ex_uv                       VARCHAR2(32767);
    v_comp_filter                 VARCHAR2(32767);
  begin

  		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookup_table) ,',pin_lookup_table => <value>', v_stamp);
    	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_input_table_list) ,',pin_input_table_list => <value>', v_stamp);

		/*<<Step1>> Add where clauses, Get the source , destination, earning entity, lookup table objects */
    v_in_input_table_list:=pin_input_table_list;
    FOR i IN v_in_input_table_list.FIRST .. v_in_input_table_list.LAST
     LOOP
      v_in_input_table_list(i).where_clause:=CASE WHEN v_in_input_table_list(i).where_clause IS NOT NULL THEN 'WHERE '||v_in_input_table_list(i).where_clause ELSE '' END;
    END LOOP;

    if pin_lookup_table is not empty then
      v_in_lookup_table_list:=pin_lookup_table;
      FOR i IN v_in_lookup_table_list.FIRST .. v_in_lookup_table_list.LAST LOOP
        v_in_lookup_table_list(i).where_clause:=CASE WHEN v_in_lookup_table_list(i).where_clause IS NOT NULL THEN 'WHERE '||v_in_lookup_table_list(i).where_clause ELSE '' END;
      END LOOP;
    end if;



    v_tab_indx := v_in_input_table_list.FIRST;
		WHILE (v_tab_indx IS NOT NULL)
		LOOP
			IF v_in_input_table_list(v_tab_indx).TABLE_TYPE =   2   -- Metric Input
			THEN
				v_source_table := v_in_input_table_list(v_tab_indx);
			ELSIF v_in_input_table_list(v_tab_indx).TABLE_TYPE = 17 -- Earnings In Tiers
			THEN
				v_dest_table    := v_in_input_table_list(v_tab_indx);
			ELSIF v_in_input_table_list(v_tab_indx).TABLE_TYPE = 18 -- Target Values Table (Tiered commission type: Percent of Target Treshold)
			THEN
				v_targets_table := v_in_input_table_list(v_tab_indx);
			END IF;
			v_tab_indx := pin_input_table_list.NEXT(v_tab_indx);
		END LOOP;

		v_tab_indx := v_in_lookup_table_list.FIRST;
		WHILE (v_tab_indx IS NOT NULL)
		LOOP
			IF v_in_lookup_table_list(v_tab_indx).USED_FOR = 3      -- TIERS Table
			THEN
				v_tiers_table := v_in_lookup_table_list(v_tab_indx);
			ELSIF v_in_lookup_table_list(v_tab_indx).USED_FOR = 4   -- TIERS EXCEPTIONS Table
			THEN
				v_exceptions_table := v_in_lookup_table_list(v_tab_indx);
			END IF;
			v_tab_indx := v_in_lookup_table_list.NEXT(v_tab_indx);
		END LOOP;


    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(v_in_lookup_table_list) ,',v_in_lookup_table_list => <value>', v_stamp);


    /*<<Step2>> Add Validations */
		BEGIN
		v_input_param_error_message :=
			   CASE	WHEN v_source_table.TABLE_NAME IS NULL
					THEN 'tabletype_input_table_list parameter does not contain a table of type 2 (Metric Input);'
					ELSE NULL END
			|| CASE	WHEN v_dest_table.TABLE_NAME IS NULL
					THEN 'tabletype_input_table_list parameter does not contain a table of type 17 (Earnings In Tiers);'
					ELSE NULL END
			|| CASE	WHEN pin_earning_entity(1).name1 IS NULL
					THEN 'pin_earning_entity parameter must not be null;'
					ELSE NULL END
			|| CASE	WHEN pin_period_column IS NULL
					THEN 'pin_period_column parameter must not be null;'
					ELSE NULL END
			|| CASE	WHEN pin_current_period IS NULL
					THEN 'pin_current_period parameter must not be null;'
					ELSE NULL END
			|| CASE	WHEN NVL(pin_projected, 0) NOT IN (0, 1)
					THEN 'pin_projected parameter does not contain any expected values (null, 0, 1);'
					ELSE NULL END
			|| CASE	WHEN pin_projected IS NOT NULL AND pin_projected_period_column IS NULL
					THEN 'pin_projected_period_column parameter must not be null;'
					ELSE NULL END
			|| CASE	WHEN pin_projected IS NOT NULL AND pin_projected_period IS NULL
					THEN 'pin_projected_period parameter must not be null;'
					ELSE NULL END;

		IF v_input_param_error_message IS NOT NULL THEN
			raise_application_error(-20001, v_input_param_error_message);
		END IF;

		END;

    /*<<Step3>> Build column PECE list*/
	  FOR c_calc_ent IN (SELECT ENTITY_NAME,ENTITY_ORDER,ENTITY_TYPE,COLUMN_TYPE,ENTITY_TABLE_NAME,ENTITY_FIELD_NAME
							,ROW_NUMBER() OVER (PARTITION BY CASE WHEN ENTITY_TYPE IN (3, 4) THEN 1 ELSE 0 END
                                                ORDER BY ENTITY_ORDER) CALC_ENTITY_ORDER
                            ,F.FLD_DATA_TYPE
						FROM TABLE(pin_earning_calc_ent) P
                            LEFT JOIN FIELDS F ON P.COLUMN_TYPE = 2 AND P.ENTITY_NAME = F.FLD_COLUMN_NAME
                        ORDER BY ENTITY_ORDER)
	  LOOP
		  v_ece_column_list     := v_ece_column_list || CASE WHEN v_ece_column_list IS NOT NULL THEN ',' ELSE NULL END||c_calc_ent.ENTITY_NAME;
 		  v_ece_column_list_sel := v_ece_column_list_sel || CASE WHEN v_ece_column_list_sel IS NOT NULL THEN ',' ELSE NULL END||'I.'||c_calc_ent.ENTITY_NAME;
		  v_ece_column_list_vld := v_ece_column_list_vld
                              ||CASE  WHEN v_ece_column_list_vld IS NOT NULL THEN ',' ELSE NULL END
                              ||CASE  WHEN c_calc_ent.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
                                  WHEN c_calc_ent.ENTITY_TYPE IN (3, 4) AND c_calc_ent.COLUMN_TYPE = 1 THEN 'CALC_ENTITY_'||TO_CHAR(c_calc_ent.CALC_ENTITY_ORDER)||'_ID'
                                  WHEN c_calc_ent.ENTITY_TYPE IN (3, 4) AND c_calc_ent.COLUMN_TYPE = 2 THEN 'CALC_ENTITY_'||TO_CHAR(c_calc_ent.CALC_ENTITY_ORDER)||'_VALUE'
                                  ELSE NULL END;

    END LOOP;

    /*<<Step4>> Build VALIDATION CLAUSE*/
    v_sql_validation_clause := 'when (VLD_TIER_POSITIVE < 0) then'                                            ||chr(10)||chr(32)
                      || 'into TEMP_PROC_VALIDATION_VALUES ('||v_ece_column_list_vld||',VALIDATION_ID)'       ||chr(10)||chr(32)
                      || 'values ('                                                                           ||chr(10)||chr(32)
                      || v_ece_column_list                                                                    ||chr(10)||chr(32)
                      || ',2770)'                                                                             ||chr(10)||chr(32)

                      || 'when (TIER_START IS NULL) then'                                                     ||chr(10)||chr(32)
                      || 'into TEMP_PROC_VALIDATION_VALUES ('||v_ece_column_list_vld||',VALIDATION_ID)'       ||chr(10)||chr(32)
                      || 'values ('                                                                           ||chr(10)||chr(32)
                      || v_ece_column_list                                                                    ||chr(10)||chr(32)
                      || ',2720)'                                                                             ||chr(10)||chr(32)

                      || case when v_exceptions_table.TABLE_NAME is not null then
                         'when (VLD_EX_POSITIVE < 0) then'                                                    ||chr(10)||chr(32)
                      || 'into TEMP_PROC_VALIDATION_VALUES ('||v_ece_column_list_vld||',VALIDATION_ID)'       ||chr(10)||chr(32)
                      || 'values ('                                                                           ||chr(10)||chr(32)
                      || v_ece_column_list                                                                    ||chr(10)||chr(32)
                      || ',2790)'                                                                             ||chr(10)||chr(32)   else null end

                      || case when pin_component_subtype = 401  then
                         'when (VLD_TARGET_POSITIVE <= 0) then'                                               ||chr(10)||chr(32)
                      || 'into TEMP_PROC_VALIDATION_VALUES ('||v_ece_column_list_vld||',VALIDATION_ID)'       ||chr(10)||chr(32)
                      || 'values ('                                                                           ||chr(10)||chr(32)
                      || v_ece_column_list                                                                    ||chr(10)||chr(32)
                      || ',2810)'                                                                             ||chr(10)||chr(32)   else null END

                      || case when pin_component_subtype = 401  then
                         'when (TARGET_VALUE IS NULL AND TIERNO =1) OR (TARGET_VALUE is null AND TIERNO IS NULL) then'                                                   ||chr(10)||chr(32)
                      || 'into TEMP_PROC_VALIDATION_VALUES ('||v_ece_column_list_vld||',VALIDATION_ID)'       ||chr(10)||chr(32)
                      || 'values ('                                                                           ||chr(10)||chr(32)
                      || v_ece_column_list                                                                    ||chr(10)||chr(32)
                      || ',2740)'                                                                             ||chr(10)||chr(32)   else null END
                      ;

    /*<<Step5>> Build ROSTER*/
    BUILD_SQL_DETAIL_ROSTER
      (   pin_input_table_list   => v_in_input_table_list
         ,pin_component_type	 => 4
         ,pin_cust_form_clauses  => NULL
         ,pin_definition_id      => pin_definition_id
         ,pout_sql_from_roster   => v_sql_from_roster
         ,pout_sql_comp_filter   => v_comp_filter
      );

    /*<<Step6>> Build INPUT JOIN with ROSTER*/
    v_sql_input_join := 'INNER JOIN (SELECT '||v_ece_column_list||',ROW_IDENTIFIER,'||pin_input_values_column||' FROM  '||v_source_table.table_name||' I ' || v_source_table.where_clause ||') I ON R.'||pin_earning_entity(1).name1||' = I.'||pin_earning_entity(1).name1;




    /*<<Step7>> Build TIERS JOIN with INPUT */
    BEGIN
      v_varyby_eff_lk := v_tiers_table.vary_by_fields
                                 ||case when v_tiers_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is not null AND v_tiers_table.vary_by_fields IS NOT NULL
                                             then  ',' || v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2
                                        when v_tiers_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is NOT null AND v_tiers_table.VARY_BY_FIELDS IS NULL
                                             then v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2
                                        else NULL
                                    end;

       if v_exceptions_table.TABLE_NAME is not null then
          v_varyby_eff_ex := v_exceptions_table.VARY_BY_FIELDS
                                 ||case when v_exceptions_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is not null AND v_exceptions_table.VARY_BY_FIELDS IS NOT NULL
                                             then  ',' || v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2
                                        when v_exceptions_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is NOT null AND v_exceptions_table.VARY_BY_FIELDS IS NULL
                                             then v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ',' || v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2
                                        else NULL
                                    end;
       end if;

       v_from_clause_lk := case when v_tiers_table.from_clause is not null
                                 then v_tiers_table.from_clause
                                 else ' TIERS ON 1=1 '
                           end
                           || case when v_tiers_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is not null
                                   then ' AND ' || v_tiers_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS  || '.' || v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_COLUMN_NAME || '  BETWEEN nvl(TIERS.' ||
                                    v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) and nvl(TIERS.' ||
                                    v_tiers_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))'
                                    else null
                            end;

      if v_exceptions_table.TABLE_NAME is not null then
        v_from_clause_ex := v_exceptions_table.from_clause ||
                      case when v_exceptions_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is not null
                               then ' AND ' || v_exceptions_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS  || '.' || v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_COLUMN_NAME || '  between nvl(EX.' ||
                                               v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_1 || ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) and nvl(EX.' ||
                                               v_exceptions_table.EFFECTIVE_DATE_PROPS.ENTITY_DATE_RANGE_PART_2 || ', TO_DATE(''01/01/9999'', ''DD/MM/YYYY''))'
                               else null
                           end;
      end if;



    END;

    v_sql_tiers_join      := 'LEFT JOIN  (SELECT '|| case when v_varyby_eff_lk is not null then v_varyby_eff_lk || ' , ' else null end || '
                                            TIER_START as LV,
                                            '
                                            ||CASE WHEN v_tiers_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is null
                                                   THEN 'LEAD(TIER_START,1,1E38) OVER ('|| case when v_varyby_eff_lk is not null then ' partition by '|| v_varyby_eff_lk else null end ||' order by TIER_START) as UV,
                                            '      ELSE NULL END
                                            ||'COMMISSION_RATE FROM '|| v_tiers_table.table_name || ' ' || v_tiers_table.WHERE_CLAUSE || ' ) '
                                            || v_from_clause_lk
                                            || case when v_exceptions_table.TABLE_NAME is not null then ' and EX.COMMISSION_RATE is null ' else null end;

    v_tiers_uv := CASE WHEN v_tiers_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is NULL
                       THEN 'TIERS.UV'
                       ELSE 'CASE WHEN TIERS.LV IS NOT NULL THEN LEAD(TIERS.LV,1,1E38) OVER (partition by '||v_ece_column_list_sel||' order by TIERS.LV) ELSE NULL END'
                       END;

   /*<<Step8>> Build TARGETS JOIN with INPUT */
    v_sql_targets_join := 'LEFT JOIN (SELECT * FROM ' || v_targets_table.TABLE_NAME || ' ' || v_targets_table.WHERE_CLAUSE || ' ) ' ||  v_targets_table.FROM_CLAUSE;


    /*<<Step9>> Build EXCEPTIONS JOIN with INPUT */
    v_sql_exceptions_join := 'LEFT JOIN  (SELECT '|| case when v_varyby_eff_ex is not null then v_varyby_eff_ex || ' , ' else null end || '
                                            TIER_START as LV,
                                            '
                                            ||CASE WHEN v_exceptions_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is null
                                                   THEN 'LEAD(TIER_START,1,1E38) OVER ('|| case when v_varyby_eff_ex is not null then ' partition by '|| v_varyby_eff_ex else null end ||' order by TIER_START) as UV,
                                            '      ELSE NULL END
                                            ||'COMMISSION_RATE FROM '|| v_exceptions_table.table_name || ' ' || v_exceptions_table.where_clause ||' ) '
                                            || v_from_clause_ex; -- Exceptions always vary-by

    v_ex_uv := CASE WHEN v_exceptions_table.EFFECTIVE_DATE_PROPS.RELATIONSHIP_TABLE_ALIAS is NULL
                    THEN 'EX.UV'
                    ELSE 'CASE WHEN EX.LV IS NOT NULL THEN LEAD(EX.LV,1,1E38) OVER (partition by '||v_ece_column_list_sel||' order by EX.LV) ELSE NULL END'
                    END;


    /*<<Step10>> Build final strings */
    /* Build delete clause - if roster has selected records, then delete only those records and then process only those records

       -- notice that in DETAILED_EARNINGS the pout_join_string is not used - the corresponding logic is built in BUILD_SQL_DETAIL_ROSTER
          and is more complicated than in the other 3 steps
       -- for pin_input_table_list use as input also pin_input_table_list, not v_in_input_table_list which has the where_clause modified
          this is in order to keep compatibility with the other 3 steps */
    COMPONENTS_PROCESSING.BUILD_SELECTED_RECS_FILTER
    (    pin_step             => 1
        ,pin_input_table_list => pin_input_table_list
        ,pin_definition_id    => pin_definition_id
        ,pin_src_table_alias  => 'S'
        ,pin_earning_entity   => pin_earning_entity(1).name1
        ,pin_payment_entity   => NULL
        ,pout_delete_string   => v_roster_delete_string
        ,pout_join_string     => v_roster_join_string
    );

    v_delete_string   := 'DELETE FROM '||v_dest_table.TABLE_NAME||CHR(10)
        ||CASE WHEN v_roster_delete_string IS NOT NULL
                  THEN ' WHERE ' || v_roster_delete_string
                ELSE NULL
           END;

    /* Build Insert clause */
    v_insert_string := 'INSERT ALL'                                                                       ||chr(10)||chr(32)
        || v_sql_validation_clause
        || 'WHEN 1=1 then INTO ' || v_dest_table.TABLE_NAME || '('                                        ||chr(10)||chr(32)
        || v_ece_column_list                                                                              ||chr(10)||chr(32)
        || ', TIER_START'                                                                                 ||chr(10)||chr(32)
        || ', ' || pin_period_column                                                                      ||chr(10)||chr(32)
        || CASE WHEN pin_projected is not null   then ', ' || pin_projected_period_column                 ||chr(10)||chr(32) else null end
        || case WHEN pin_projected is not null   then ', PROJECTED'                                       ||chr(10)||chr(32) else null end
        || case when pin_component_subtype = 401 then ', TARGET_VALUE'                                    ||chr(10)||chr(32) else null end
        || case when pin_component_subtype = 401 then ', TIER_START_AMOUNT'                               ||chr(10)||chr(32) else null end
        || ', AMOUNT_IN_TIER'                                                                             ||chr(10)||chr(32)
        || ', COMMISSION_RATE'                                                                            ||chr(10)||chr(32)
        || ', EARNINGS_IN_TIER'                                                                           ||chr(10)||chr(32)
        || ', PROCESSED_DATE_TIME'                                                                        ||chr(10)||chr(32)
        || ', ROW_IDENTIFIER'                                                                             ||chr(10)||chr(32)
        || ', ROW_VERSION)'             			                                                            ||chr(10)||chr(32)
        || 'VALUES ('                                                                                     ||chr(10)||chr(32)
        || v_ece_column_list                                                                              ||chr(10)||chr(32)
        || ', TIER_START , '                                                                              ||chr(10)||chr(32)
        || pin_period_column                                                                              ||chr(10)||chr(32)
        || case when pin_projected is not null   then ', ' || pin_projected_period_column                 ||chr(10)||chr(32) else null end
        || case when pin_projected is not null   then ', PROJECTED'                                       ||chr(10)||chr(32) else null end
        || case when pin_component_subtype = 401 then ', TARGET_VALUE'                                    ||chr(10)||chr(32) else null end
        || case when pin_component_subtype = 401 then ', TIER_START_AMOUNT'                               ||chr(10)||chr(32) else null end
        || ', AMOUNT_IN_TIER'                                                                             ||chr(10)||chr(32)
        || ', COMMISSION_RATE'                                                                            ||chr(10)||chr(32)
        || ', EARNINGS_IN_TIER'                                                                           ||chr(10)||chr(32)
        || ', PROCESSED_DATE_TIME'                                                                        ||chr(10)||chr(32)
        || ', ' || commons_appframework.get_row_identifier_sequence
                    (pi_table_name => v_dest_table.TABLE_NAME
                    ,pi_period_id => CASE WHEN pin_projected IS NOT NULL THEN pin_projected_period
                                          ELSE pin_current_period END
                    ) || '.NEXTVAL'                                                                       ||chr(10)||chr(32)
        || ', ROW_VERSION)'                                                                               ||chr(10)||chr(32);

    v_hint_loc := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPONENTS_PROCESSING.CREATE_DETAILED_EARNINGS_TIER' ,pi_hint_id => 'SEL_EXCLUDE_DUP_EE' ,pi_proc_id => pin_definition_id);
    v_hint :=                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPONENTS_PROCESSING.CREATE_DETAILED_EARNINGS_TIER' ,pi_hint_id => 'SEL_EXCLUDE_DUP_EE' ,pi_proc_id => pin_definition_id
                                                           ,pi_other_hints => 'CARDINALITY(VDUP '||COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES')||')');

    v_select_string := 'SELECT'                                                                                                                                                   ||chr(10)||chr(32)
                       || 'MAIN_S.'|| replace(v_ece_column_list,',',',MAIN_S.')                                                                                                   ||chr(10)||chr(32)
                       ||',MAIN_S.'|| pin_period_column
                       || CASE WHEN pin_projected is not null   then ', MAIN_S.' || pin_projected_period_column              else null end
                       || CASE WHEN pin_projected is not null   then ', MAIN_S.PROJECTED'                                    else null end
                       || ', MAIN_S.TIER_START '                                                                                                                                  ||chr(10)||chr(32)
                       || case when pin_component_subtype = 401 then ', MAIN_S.TARGET_VALUE'                                 else null end                                        ||chr(10)||chr(32)
                       || case when pin_component_subtype = 401 then ', MAIN_S.TIER_START_AMOUNT'                            else null end                                        ||chr(10)||chr(32)
                       || ', MAIN_S.COMMISSION_RATE '                                                                                                                             ||chr(10)||chr(32)
                       || ', MAIN_S.AMOUNT_IN_TIER  '                                                                                                                             ||chr(10)||chr(32)
                       || ', MAIN_S.EARNINGS_IN_TIER  '                                                                                                                           ||chr(10)||chr(32)
                       || ', MAIN_S.ROW_VERSION  '                                                                                                                                ||chr(10)||chr(32)
                       ||                                                          ', MAIN_S.VLD_TIER_POSITIVE   '                                                                ||chr(10)||chr(32)
                       || case when v_exceptions_table.TABLE_NAME is not null then ', MAIN_S.VLD_EX_POSITIVE     '          else null end                                         ||chr(10)||chr(32)
                       || case when pin_component_subtype = 401               then ', MAIN_S.VLD_TARGET_POSITIVE '          else null end                                         ||chr(10)||chr(32)
                       || ', MAIN_S.PROCESSED_DATE_TIME  '
                       || case when pin_component_subtype = 401 then ' , MAIN_S.TIERNO '                                    else null end                                                                                                                ||chr(10)||chr(32)
                       || 'FROM
                       (SELECT Q.* '
                           || ', CAST(Q.AMOUNT_IN_TIER * Q.COMMISSION_RATE as NUMBER ' || COMMONS.FIELD_PRECISION_AND_SCALE('EARNINGS_IN_TIER') || ') as EARNINGS_IN_TIER '       ||chr(10)||chr(32)
                           || 'FROM ( SELECT '
                           || case when pin_component_subtype = 401 then ' ROW_NUMBER() OVER (PARTITION BY ' || v_ece_column_list || ' ORDER BY TIER_START)  AS TIERNO, '  else null end  ||chr(10)||chr(32)
                           || v_ece_column_list || ', '
                           || TO_CHAR(pin_current_period) || ' ' || pin_period_column
                           || case WHEN pin_projected IS NOT NULL THEN ', ' || TO_CHAR(pin_projected_period) || ' ' || pin_projected_period_column  else null end
                           || case WHEN pin_projected IS NOT NULL THEN ', ' || TO_CHAR(pin_projected) || ' PROJECTED'  else null end                                              ||chr(10)||chr(32)
                           || ', 0 ROW_VERSION '                                                                                                                                  ||chr(10)||chr(32)
                           || ', CAST(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' AS DATE) as PROCESSED_DATE_TIME '                                                                    ||chr(10)||chr(32)
                           || ' ,CAST((case when Q.'||pin_input_values_column||' > Q.UV then '                                                                                                           ||chr(10)||chr(32)
                           || '     greatest(Q.UV - Q.LV,0) else'                                                                                                                 ||chr(10)||chr(32)
                           || '     greatest(Q.'||pin_input_values_column||' - Q.LV,0) end) AS NUMBER' || COMMONS.FIELD_PRECISION_AND_SCALE('AMOUNT_IN_TIER')||') AMOUNT_IN_TIER'                        ||chr(10)||chr(32)
                           || ' ,CAST(TIER_START AS NUMBER '|| COMMONS.FIELD_PRECISION_AND_SCALE('TIER_START') || ') AS TIER_START'                                               ||chr(10)||chr(32)
                           ||                                                          ',VLD_TIER_POSITIVE   '                                                                    ||chr(10)||chr(32)
                           || case when v_exceptions_table.TABLE_NAME is not null then ',VLD_EX_POSITIVE     ' else null end                                                      ||chr(10)||chr(32)
                           || case when pin_component_subtype = 401               then ',VLD_TARGET_POSITIVE ' else null end                                                      ||chr(10)||chr(32)
                           || ' ,CAST(Q.COMMISSION_RATE AS NUMBER '|| COMMONS.FIELD_PRECISION_AND_SCALE('COMMISSION_RATE') || ') AS COMMISSION_RATE'                              ||chr(10)||chr(32)
                           || case when pin_component_subtype = 401
                                then ' ,CAST(TARGET_VALUE AS NUMBER '|| COMMONS.FIELD_PRECISION_AND_SCALE('TARGET_VALUE') || ') AS TARGET_VALUE '                                 ||chr(10)||chr(32)     else null end
                           || case when pin_component_subtype = 401
                                then ' ,CAST(TIER_START * TARGET_VALUE AS NUMBER '|| COMMONS.FIELD_PRECISION_AND_SCALE('TIER_START_AMOUNT') || ') AS TIER_START_AMOUNT '          ||chr(10)||chr(32)     else null end
                           ||'FROM (SELECT '                                                                                                                                      ||chr(10)||chr(32)
                              || v_ece_column_list_sel || ', '                                                                                                                    ||chr(10)||chr(32)
                              || 'I.'||pin_input_values_column||','                                                                                                                                      ||chr(10)||chr(32)
                              ||                                                          'TIERS.LV               VLD_TIER_POSITIVE, '                                                                              ||chr(10)||chr(32)
                              || case when v_exceptions_table.TABLE_NAME is not null then 'EX.LV                  VLD_EX_POSITIVE, '     else null end                                                              ||chr(10)||chr(32)
                              || case when pin_component_subtype = 401               then 'TARGETS.TARGET_VALUE   VLD_TARGET_POSITIVE, ' else null end                                                              ||chr(10)||chr(32)
                              || case when v_exceptions_table.TABLE_NAME  is null then 'TIERS.LV as  TIER_START,'  else 'NVL(TIERS.LV, EX.LV) as TIER_START,' end                 ||chr(10)||chr(32)

                              || case when pin_component_subtype = 401 then
                                     case when v_exceptions_table.TABLE_NAME  is null then v_tiers_uv||' * (TARGET_VALUE/'|| pin_no_plan_per_for_target ||') as UV,' else 'NVL('||v_tiers_uv||', '||v_ex_uv||') * (TARGET_VALUE/' || pin_no_plan_per_for_target || ') as UV,' end          ||chr(10)||chr(32)||
                                     case when v_exceptions_table.TABLE_NAME  is null then 'TIERS.LV * (TARGET_VALUE/'|| pin_no_plan_per_for_target ||') as LV,'     else 'NVL(TIERS.LV, EX.LV) * (TARGET_VALUE/' || pin_no_plan_per_for_target || ') as LV,' end          ||chr(10)||chr(32)
                                 else
                                     case when v_exceptions_table.TABLE_NAME  is null then v_tiers_uv||' as UV,' else 'NVL('||v_tiers_uv||', '||v_ex_uv||') as UV,' end                                        ||chr(10)||chr(32)||
                                     case when v_exceptions_table.TABLE_NAME  is null then 'TIERS.LV as LV,'     else 'NVL(TIERS.LV, EX.LV) as LV,' end                                        ||chr(10)||chr(32)
                                 end

                              || case when pin_component_subtype = 401 then '(TARGETS.TARGET_VALUE/' || pin_no_plan_per_for_target ||' )as TARGET_VALUE,'    else null end                                          ||chr(10)||chr(32)
                              || case when v_exceptions_table.TABLE_NAME is null then 'TIERS.COMMISSION_RATE as COMMISSION_RATE'  else 'NVL(TIERS.COMMISSION_RATE, EX.COMMISSION_RATE) as COMMISSION_RATE ' end     ||chr(10)||chr(32)
                              ||  v_sql_from_roster                                                                                                                                                                 ||chr(10)||chr(32)
                              ||  v_sql_input_join                                                                                                                                                                  ||chr(10)||chr(32)
                              ||  case when v_exceptions_table.TABLE_NAME is not null then v_sql_exceptions_join else null end                                                                                      ||chr(10)||chr(32)
                              ||  v_sql_tiers_join                                                                                                                                                                  ||chr(10)||chr(32)
                              ||  case when pin_component_subtype = 401               then v_sql_targets_join    else null end                                                                                      ||chr(10)||chr(32)


                              --here I add the component filtering
                              || REPLACE (v_comp_filter,'TAB','I')

                              -- adding logic for excluding EE values that previously failed during the input validations
                              -- with errors for duplicate records
                              ||'WHERE R.'||pin_earning_entity(1).name1||' NOT IN ('                                                                                                                                         ||chr(10)||chr(32)
                                ||v_hint_loc                                                                                                                                                                        ||chr(10)||chr(32)
                                ||'SELECT '||v_hint||' EARNING_ENTITY_ID FROM TEMP_PROC_VALIDATION_VALUES VDUP WHERE VALIDATION_ID = 2030)'                                                                         ||chr(10)||chr(32)
                              ||') Q ) Q )MAIN_S'                                                                                                                                                                   ||chr(10)||chr(32);

		v_insert_string := v_insert_string || CHR(10) || v_select_string;

L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_select_string) ,',v_select_string => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_delete_string) ,',v_delete_string => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_insert_string) ,',v_insert_string => <value>', v_stamp);
		EXECUTE IMMEDIATE v_delete_string;
		EXECUTE IMMEDIATE v_insert_string;

	END CREATE_DETAILED_EARNINGS_TIER ;
	-- #############################  CREATE_DETAILED_EARNINGS_TIER  END   #############################

    -- ############################# CREATE_DETAILED_EARNINGS START   #############################
    /*
    Author     : Cozac, Tudor
    Create date: 20110603
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from RUN_COMPONENT
    -----------------------------------------------------------------------------------------
    Result set:

    -----------------------------------------------------------------------------------------
    Example:
    */
    PROCEDURE CREATE_DETAILED_EARNINGS
	(	 pin_definition_id         IN NUMBER
        ,pin_lookup_table		IN tabletype_lookup_table_list
		,pin_input_table_list		IN tabletype_input_table_list
        ,pin_input_values_columns		IN TABLETYPE_ID_NAME
        ,pin_earning_entity		IN tabletype_name_map
		,pin_earning_calc_ent		IN TABLETYPE_CPM_ENTITIES
		,pin_use_target			IN NUMBER
		,pin_component_type		IN NUMBER
		,pin_component_subtype		IN NUMBER
		,pin_comision_rate_value	IN NUMBER
		,pin_component_weight_value	IN NUMBER
		,pin_plan_target_earn_val	IN NUMBER
		,pin_comp_target_earn_val	IN NUMBER
        ,pin_cust_form_exp          IN CLOB
        ,pin_cust_form_clauses      IN TABLETYPE_CUST_FORM_CLAUSES
        ,pin_cust_form_ass_ent      IN TABLETYPE_NAME_JOIN_MAP
		,pin_period_column		IN VARCHAR2
		,pin_current_period		IN NUMBER
		,pin_projected_period_column	IN VARCHAR2
		,pin_projected_period		IN NUMBER
		,pin_projected			IN NUMBER
		,pin_no_plan_per_for_comp_per	IN NUMBER
		,pin_no_plan_per_for_target	IN NUMBER
		,pin_no_comp_per_for_target	IN NUMBER
		,pin_no_comp_per_pas_in_sub IN NUMBER
		,pin_component_weight_fields IN tabletype_id_name
		,pin_vld_when			IN CLOB
		,pin_vld_select			IN CLOB
		,pin_vld_from			IN CLOB
		,pin_apply_validations	IN NUMBER
    ,pin_lookup_precision   IN VARCHAR2
	) AS
	v_in_input_table_list		tabletype_input_table_list;
  v_in_lookup_table_list  tabletype_lookup_table_list;
	v_det_earn_table_name		VARCHAR2(30);

	v_ece_column_list		VARCHAR2(32767);
	v_ece_column_list_vld		VARCHAR2(32767);
	v_ece_column_list_sel		VARCHAR2(32767);
	v_ece_column_list_lookup	VARCHAR2(32767);
	v_ece_column_list_join		VARCHAR2(32767);

    v_sql_uival_select_src      VARCHAR2(32767);
    v_sql_uival_select_wo_src   VARCHAR2(32767);
    v_sql_uival_from            VARCHAR2(32767);

	v_earnings			VARCHAR2(32767);

	v_sql_delete_clause		VARCHAR2(32767);
	v_sql_insert_clause		VARCHAR2(32767);
	v_sql_insert_header		VARCHAR2(32767);
	v_sql_insert_to_result          VARCHAR2(32767);
	v_sql_insert_col_list		VARCHAR2(32767);
	v_sql_select_sub_clause		clob;
	v_sql_from_sub_clause		CLOB;
	v_sql_select_clause		VARCHAR2(32767);
	v_sql_from_clause		CLOB;

	v_sql_from_roster		VARCHAR2(32767);

	v_sql_insert_proj		VARCHAR2(32767);
	v_sql_select_proj		VARCHAR2(32767);

	v_sql_insert_lookup		VARCHAR2(32767);
	v_sql_prval_insert_lookup	CLOB;
	v_sql_prval_select_lookup	CLOB;
	v_sql_select_lookup		VARCHAR2(32767);
	v_sql_from_lookup		CLOB;
	v_sql_earnings_lookup		VARCHAR2(32767);

	v_sql_insert_com_rate		VARCHAR2(32767);
	v_sql_insert_com_tr_rate		CLOB;
	v_sql_prval_insert_com_rate	CLOB;
	v_sql_prval_insert_com_tr_rate	CLOB;
	v_sql_prval_select_com_rate	CLOB;
	v_sql_prval_select_com_tr_rate	CLOB;
	v_sql_select_com_rate		VARCHAR2(32767);
	v_sql_select_com_tr_rate		CLOB;
	v_sql_earnings_com_rate		VARCHAR2(32767);
	v_sql_earnings_com_tr_rate		clob;
	v_sql_from_com_rate		CLOB;
	v_sql_from_com_tr_rate		CLOB;
	v_sql_from_i_com_rate		CLOB;
	v_sql_from_i_com_tr_rate		CLOB;
    v_sql_prval_insert_cf   CLOB;
    v_sql_from_cf           CLOB;

	v_sql_insert_target		    VARCHAR2(32767);
	v_sql_prval_insert_target	CLOB;
	v_sql_prval_select_target	CLOB;
	v_sql_select_target 		VARCHAR2(32767);
	v_sql_from_target 		    CLOB;
    v_roster_delete_string	    CLOB;
    v_roster_join_string        CLOB;
	v_sql_insert_in_result_table	CLOB;
    v_hint_loc                  VARCHAR2(2000 CHAR);
	v_hint                      VARCHAR2(2000 CHAR);
	v_stamp					    VARCHAR2(200);
  v_comp_filter       VARCHAR2(32767);

      BEGIN
	v_stamp := 'COMPONENTS_PROCESSING.CREATE_DETAILED_EARNINGS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    /* Step 1 add 'WHERE' to the where clause
	*/
	v_in_input_table_list:=pin_input_table_list;
	FOR i IN v_in_input_table_list.FIRST .. v_in_input_table_list.LAST
	 LOOP
	  v_in_input_table_list(i).where_clause:=CASE WHEN v_in_input_table_list(i).where_clause IS NOT NULL THEN 'WHERE '||v_in_input_table_list(i).where_clause ELSE '' END;
	END LOOP;

  v_in_lookup_table_list:=pin_lookup_table;
  if v_in_lookup_table_list is not empty then
    FOR i IN v_in_lookup_table_list.FIRST .. v_in_lookup_table_list.LAST LOOP
      v_in_lookup_table_list(i).where_clause:=CASE WHEN v_in_lookup_table_list(i).where_clause IS NOT NULL THEN 'WHERE '||v_in_lookup_table_list(i).where_clause ELSE '' END;
    END LOOP;
  end if;
	/* Step 2  get information about input and DETAILED EARNING result tables
	*/
    SELECT TABLE_NAME INTO v_det_earn_table_name FROM TABLE(v_in_input_table_list) WHERE TABLE_TYPE=8;

	/* Step 3 build various sql strings based on entity calculation earning column list
	*/
	FOR c_calc_ent IN (SELECT ENTITY_NAME,ENTITY_ORDER,ENTITY_TYPE,COLUMN_TYPE,ENTITY_TABLE_NAME,ENTITY_FIELD_NAME
							,ROW_NUMBER() OVER (PARTITION BY CASE WHEN ENTITY_TYPE IN (3, 4) THEN 1 ELSE 0 END
                                                ORDER BY ENTITY_ORDER) CALC_ENTITY_ORDER
                            ,F.FLD_DATA_TYPE
						FROM TABLE(pin_earning_calc_ent) P
                            LEFT JOIN FIELDS F ON P.COLUMN_TYPE = 2 AND P.ENTITY_NAME = F.FLD_COLUMN_NAME
                        ORDER BY ENTITY_ORDER)
	LOOP
		v_ece_column_list := v_ece_column_list
			||CASE WHEN v_ece_column_list IS NOT NULL THEN ',' ELSE NULL END||c_calc_ent.ENTITY_NAME;

		v_ece_column_list_vld := v_ece_column_list_vld
			||CASE  WHEN v_ece_column_list_vld IS NOT NULL THEN ',' ELSE NULL END
			||CASE  WHEN c_calc_ent.ENTITY_TYPE = 1 THEN 'EARNING_ENTITY_ID'
					WHEN c_calc_ent.ENTITY_TYPE IN (3, 4) AND c_calc_ent.COLUMN_TYPE = 1 THEN 'CALC_ENTITY_'||TO_CHAR(c_calc_ent.CALC_ENTITY_ORDER)||'_ID'
					WHEN c_calc_ent.ENTITY_TYPE IN (3, 4) AND c_calc_ent.COLUMN_TYPE = 2 THEN 'CALC_ENTITY_'||TO_CHAR(c_calc_ent.CALC_ENTITY_ORDER)||'_VALUE'
					ELSE NULL END;

		v_ece_column_list_sel := v_ece_column_list_sel
			||CASE WHEN v_ece_column_list_sel IS NOT NULL THEN ',' ELSE NULL END||'I.'||c_calc_ent.ENTITY_NAME;

		v_ece_column_list_lookup := v_ece_column_list_lookup
			||CASE WHEN v_ece_column_list_lookup IS NOT NULL THEN ',' ELSE NULL END||'TAB.'||c_calc_ent.ENTITY_NAME;

		v_ece_column_list_join := v_ece_column_list_join
			||CASE  WHEN v_ece_column_list_join IS NOT NULL THEN ' AND ' ELSE NULL END
            ||CASE  WHEN c_calc_ent.ENTITY_TYPE = 1 -- earning entity - values cannot be null
                    THEN '(I2.'||c_calc_ent.ENTITY_NAME||' = I.'||c_calc_ent.ENTITY_NAME||')'
                    WHEN c_calc_ent.ENTITY_TYPE IN (3, 4)
                    THEN COMMONS_UTILS.GET_EQUAL_MATCH_CONDITION    (pin_left_member => 'I2.'||c_calc_ent.ENTITY_NAME
                                                                    ,pin_right_member => 'I.'||c_calc_ent.ENTITY_NAME
                                                                    ,pin_members_col_type => c_calc_ent.COLUMN_TYPE
                                                                    ,pin_members_data_type => c_calc_ent.FLD_DATA_TYPE)
                    ELSE '(I2.'||c_calc_ent.ENTITY_NAME||' = I.'||c_calc_ent.ENTITY_NAME||' OR (I2.'||c_calc_ent.ENTITY_NAME||' IS NULL AND I.'||c_calc_ent.ENTITY_NAME||' IS NULL))'
                    END;

        IF (c_calc_ent.ENTITY_TYPE IN (1, 4) AND c_calc_ent.COLUMN_TYPE = 1)
        THEN
            v_sql_uival_select_src := v_sql_uival_select_src||','||c_calc_ent.ENTITY_NAME||'.'||c_calc_ent.ENTITY_FIELD_NAME;
            v_sql_uival_select_wo_src := v_sql_uival_select_src||','||c_calc_ent.ENTITY_FIELD_NAME;
            v_sql_uival_from := v_sql_uival_from||CASE WHEN c_calc_ent.ENTITY_TYPE = 1 THEN 'INNER' ELSE 'LEFT' END
                ||' JOIN '||c_calc_ent.ENTITY_TABLE_NAME||' '||c_calc_ent.ENTITY_NAME||' ON MAIN_S.'||c_calc_ent.ENTITY_NAME||' = '||c_calc_ent.ENTITY_NAME||'.E_INTERNAL_ID'||CHR(10);
        END IF;
    END LOOP;

	/* Step 5 build roster sql
	*/
	BUILD_SQL_DETAIL_ROSTER
    (   pin_input_table_list   => v_in_input_table_list
       ,pin_component_type	   => pin_component_type
       ,pin_cust_form_clauses  => pin_cust_form_clauses
       ,pin_definition_id      => pin_definition_id
       ,pout_sql_from_roster   => v_sql_from_roster
       ,pout_sql_comp_filter   => v_comp_filter
    );


    	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_comp_filter) ,'v_comp_filter := <value>', v_stamp);



	/* Step 5 build projected sql
	*/
	BUILD_SQL_DETAIL_EARN_PROJ
			   ( pin_projected_period_column => pin_projected_period_column
			    ,pin_projected_period        => pin_projected_period
			    ,pin_projected		 => pin_projected
			    ,pout_sql_proj_insert        => v_sql_insert_proj
			    ,pout_sql_proj_select        => v_sql_select_proj
			    );

	/* Step 6 build lookup sql: pin_component_type=1
	*/
	BUILD_SQL_DETAIL_LOOKUP(
            pin_component_type		      => pin_component_type
            ,pin_component_subtype	    => pin_component_subtype
            ,pin_lookup_table		        => v_in_lookup_table_list
            ,pin_input_table_list	      => v_in_input_table_list
            ,pin_input_values_columns	  => pin_input_values_columns
            ,pin_earning_entity		      => pin_earning_entity
            ,pin_ece_column_list	      => v_ece_column_list
            ,pin_ece_column_list_vld    => v_ece_column_list_vld
            ,pin_ece_column_list_lookup => v_ece_column_list_lookup
            ,pin_from_roster            => v_sql_from_roster
            ,pin_sql_comp_filter        => v_comp_filter
            ,pin_lookup_precision       => pin_lookup_precision
            ,pout_sql_lookup_insert	=> v_sql_insert_lookup
            ,pout_sql_lookup_select	=> v_sql_select_lookup
            ,pout_sql_lookup_earnings	=> v_sql_earnings_lookup
            ,pout_sql_lookup_from	=> v_sql_from_lookup
            ,pout_sql_prval_insert_lookup => v_sql_prval_insert_lookup
            ,pout_sql_prval_select_lookup => v_sql_prval_select_lookup
                    );

	/* Step 7.1 build commision rate sql: pin_component_type=2
	*/
	BUILD_SQL_DETAIL_COM_RATE(
		     pin_component_type		=> pin_component_type
        ,pin_component_subtype	=> pin_component_subtype
		    ,pin_comision_rate_value	=> pin_comision_rate_value
		    ,pin_lookup_table		=> v_in_lookup_table_list
		    ,pin_input_table_list	=> v_in_input_table_list
            ,pin_input_values_columns	  => pin_input_values_columns
		    ,pin_earning_entity		=> pin_earning_entity
		    ,pin_ece_column_list	=> v_ece_column_list
			  ,pin_ece_column_list_vld => v_ece_column_list_vld
		    ,pin_ece_column_list_lookup => v_ece_column_list_lookup
		    ,pin_ece_column_list_join	=> v_ece_column_list_join
        ,pin_from_roster            => v_sql_from_roster
        ,pin_sql_comp_filter        => v_comp_filter
        ,pin_definition_id => pin_definition_id
        ,pin_lookup_precision =>   pin_lookup_precision
                    ,pout_sql_com_rate_insert	=> v_sql_insert_com_rate
                    ,pout_sql_com_rate_select	=> v_sql_select_com_rate
                    ,pout_sql_com_rate_earnings => v_sql_earnings_com_rate
                    ,pout_sql_com_rate_from	=> v_sql_from_com_rate
		    ,pout_sql_prval_insert_com_rate => v_sql_prval_insert_com_rate
		    ,pout_sql_prval_select_com_rate => v_sql_prval_select_com_rate
		    ,pout_sql_com_rate_i_from	=> v_sql_from_i_com_rate
                    );

/* Step 7.2 build commision rate sql: pin_component_type=4
	*/
	BUILD_SQL_DETAIL_COM_RATE_TIER(
		     pin_component_type		 => pin_component_type
		    ,pin_component_subtype => pin_component_subtype
		    ,pin_lookup_table		   => v_in_lookup_table_list
		    ,pin_input_table_list	 => v_in_input_table_list
        ,pin_input_values_column	  => 'METRIC'
		    ,pin_earning_entity		=> pin_earning_entity
		    ,pin_ece_column_list	=> v_ece_column_list
  			,pin_ece_column_list_vld => v_ece_column_list_vld
        ,pin_ece_column_list_join	=> v_ece_column_list_join
        ,pin_sql_comp_filter        => v_comp_filter
        ,pout_sql_com_rate_insert	=> v_sql_insert_com_tr_rate
        ,pout_sql_com_rate_select	=> v_sql_select_com_tr_rate
        ,pout_sql_com_rate_earnings => v_sql_earnings_com_tr_rate
        ,pout_sql_com_rate_from	=> v_sql_from_com_tr_rate
		    ,pout_sql_prval_insert_com_rate => v_sql_prval_insert_com_tr_rate
		    ,pout_sql_prval_select_com_rate => v_sql_prval_select_com_tr_rate
		    ,pout_sql_com_rate_i_from	=> v_sql_from_i_com_tr_rate
                    );

    /* Step 8 build custom formula sql: pin_component_type=3
	*/
    BUILD_SQL_DETAIL_CUST_FORM
    (    pin_component_type         => pin_component_type
        ,pin_earning_entity		    => pin_earning_entity
        ,pin_earning_calc_ent       => pin_earning_calc_ent
        ,pin_input_table_list       => v_in_input_table_list
        ,pin_input_values_column	=> 'METRIC'
        ,pin_cust_form_clauses      => pin_cust_form_clauses
        ,pin_cust_form_ass_ent      => pin_cust_form_ass_ent
        ,pin_ece_column_list        => v_ece_column_list
        ,pin_ece_column_list_vld    => v_ece_column_list_vld
        ,pin_ece_column_list_join	  => v_ece_column_list_join
        ,pin_sql_comp_filter        => v_comp_filter
        ,pio_ece_column_list_sel    => v_ece_column_list_sel
        ,po_sql_from                => v_sql_from_cf
        ,po_sql_sql_prval_insert    => v_sql_prval_insert_cf
    );
	/* Step 8 set earning calculation string
	*/

	v_earnings:=COALESCE(v_sql_earnings_lookup,v_sql_earnings_com_rate,pin_cust_form_exp,v_sql_earnings_com_tr_rate);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_earnings) ,'v_earnings := <value>', v_stamp);

	/* Step 9 apply target
	*/
	BUILD_SQL_DETAIL_TARGET(
			  pin_use_target			=> pin_use_target
		    ,pin_input_table_list		=> v_in_input_table_list
		    ,pin_plan_target_earn_val		=> pin_plan_target_earn_val
		    ,pin_component_weight_value		=> pin_component_weight_value
		    ,pin_no_plan_per_for_comp_per	=> pin_no_plan_per_for_comp_per
		    ,pin_no_plan_per_for_target		=> pin_no_plan_per_for_target
		    ,pin_comp_target_earn_val		=> pin_comp_target_earn_val
		    ,pin_no_comp_per_for_target		=> pin_no_comp_per_for_target
			,pin_no_comp_per_pas_in_sub		=> pin_no_comp_per_pas_in_sub
			,pin_ece_column_list		=> v_ece_column_list
			,pin_ece_column_list_vld	=> v_ece_column_list_vld
		    ,pin_component_weight_fields => pin_component_weight_fields
            ,pin_lookup_precision       => pin_lookup_precision
		    ,pinout_earnings			=> v_earnings
		    ,pout_sql_target_insert		=> v_sql_insert_target
            ,pout_sql_target_select		=> v_sql_select_target
            ,pout_sql_target_from		=> v_sql_from_target
		    ,pout_sql_prval_insert_target	=> v_sql_prval_insert_target
		    ,pout_sql_prval_select_target	=> v_sql_prval_select_target
                    );

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_earnings) ,'v_earnings := <value>', v_stamp);

	/* Step 10 build insert clause
	*/

	v_sql_insert_col_list :=     'ROW_VERSION'||chr(10)||chr(32)
				   ||',PROCESSED_DATE_TIME'||chr(10)||chr(32)
				   ||','||v_ece_column_list||chr(10)||chr(32)
				   ||','||pin_period_column||chr(10)||chr(32)
				   ||v_sql_insert_proj
				   ||v_sql_insert_lookup
				   ||v_sql_insert_com_rate
				   ||v_sql_insert_com_tr_rate
				   ||v_sql_insert_target
				   ||',DETAILED_EARNINGS'||chr(10)||chr(32);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_insert_col_list) ,'v_sql_insert_col_list := <value>', v_stamp);


	v_sql_insert_header :='INSERT ALL '||chr(10);

	v_sql_insert_to_result := ' INTO '||v_det_earn_table_name||'('||chr(10)||chr(32)
						||'ROW_IDENTIFIER'||chr(10)||chr(32)
						||','||v_sql_insert_col_list
						||')'||chr(10)
				||'VALUES ('||chr(10)||chr(32)
						||commons_appframework.get_row_identifier_sequence
                            (pi_table_name => v_det_earn_table_name
                            ,pi_period_id => CASE WHEN pin_projected IS NOT NULL THEN pin_projected_period
                                                  ELSE pin_current_period END
                            ) || '.NEXTVAL'||chr(10)||chr(32)
						||','||v_sql_insert_col_list
						||')';

	v_sql_insert_clause :=	  v_sql_insert_header
				||v_sql_prval_insert_lookup
				||v_sql_prval_insert_com_rate
				||v_sql_prval_insert_com_tr_rate
				||v_sql_prval_insert_target
                ||v_sql_prval_insert_cf
				||CASE WHEN pin_apply_validations = 1 THEN pin_vld_when ELSE NULL END||chr(10)
                ||CASE WHEN v_sql_prval_insert_lookup IS NOT NULL
					    OR v_sql_prval_insert_com_rate IS NOT null
					    OR v_sql_prval_insert_com_tr_rate IS NOT NULL
					    OR v_sql_prval_insert_target IS NOT NULL
              OR v_sql_prval_insert_cf IS NOT NULL
					    OR pin_apply_validations = 1 THEN ' WHEN 1=1 THEN ' ELSE NULL END
				||v_sql_insert_to_result||chr(10);


	/* Step 11 build select subquery clause
	*/
	v_sql_select_sub_clause :='SELECT 0 ROW_VERSION'||chr(10)||chr(32)||
				  ',CAST(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' AS DATE) PROCESSED_DATE_TIME'||chr(10)||chr(32)||
				  ','||v_ece_column_list_sel||chr(10)||chr(32)||
				  ','||pin_current_period||' '||pin_period_column||chr(10)||chr(32)
				   ||v_sql_select_proj
				   ||v_sql_select_lookup
				   ||v_sql_select_com_rate
				   ||v_sql_select_com_tr_rate
				   ||v_sql_select_target
				   ||',CAST('||v_earnings||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('DETAILED_EARNINGS')||') DETAILED_EARNINGS '||chr(10)||chr(32)

                   -- if UI vld are applied on "cust form" then we already have the BK - we have all joins
                   -- because we needed the values in the calculations
                   ||CASE WHEN pin_apply_validations = 1 AND pin_component_type = 3
                          THEN v_sql_uival_select_src||chr(10)
                          ELSE NULL END;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_select_sub_clause) ,'v_sql_select_sub_clause := <value>', v_stamp);


    /* Step 12 build from subquery clause
	*/
        v_hint_loc := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'COMPONENTS_PROCESSING.CREATE_DETAILED_EARNINGS' ,pi_hint_id => 'SEL_EXCLUDE_DUP_EE' ,pi_proc_id => pin_definition_id);
        v_hint :=                  COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'COMPONENTS_PROCESSING.CREATE_DETAILED_EARNINGS' ,pi_hint_id => 'SEL_EXCLUDE_DUP_EE' ,pi_proc_id => pin_definition_id
                                                               ,pi_other_hints => 'CARDINALITY(VDUP '||COMPENSATION_PROCESSING.GET_TABLE_CARDINALITY('TEMP_PROC_VALIDATION_VALUES')||')');

        v_sql_from_sub_clause:=  v_sql_from_roster
				 ||v_sql_from_lookup
				 ||v_sql_from_i_com_rate
				 ||v_sql_from_i_com_tr_rate
				 ||v_sql_from_com_rate
				 ||v_sql_from_com_tr_rate
                 ||v_sql_from_cf
				 ||v_sql_from_target
                 -- adding logic for excluding EE values that previously failed during the input validations with errors for duplicate records
                 ||CHR(10)||'WHERE R.'||pin_earning_entity(1).name1||' NOT IN ('||CHR(10)
                    ||v_hint_loc||CHR(10)
                    ||'SELECT '||v_hint||' EARNING_ENTITY_ID FROM TEMP_PROC_VALIDATION_VALUES VDUP WHERE VALIDATION_ID = 2030)';

	/* Step 13 build select clause
	*/
	v_sql_select_clause := 'SELECT '||chr(10)||chr(32)
				  ||'MAIN_S.'||REPLACE(v_sql_insert_col_list
                                        ||v_sql_prval_select_lookup
                                        ||v_sql_prval_select_com_rate
                                        ||v_sql_prval_select_com_tr_rate
                                        ||v_sql_prval_select_target
                                       ,','
                                       ,',MAIN_S.')  || chr(10)
				  ||CASE WHEN pin_apply_validations = 1
					     THEN CASE WHEN pin_component_type <> 3
					               THEN v_sql_uival_select_src
                                   ELSE REPLACE(v_sql_uival_select_wo_src, ',', ',MAIN_S.')
                                   END||chr(10)
					          ||pin_vld_select||chr(10)
					     ELSE NULL END;

	/* Step 14 build from clause
	*/
	v_sql_from_clause   := 'FROM ('
          --|| case when pin_component_type = 4 then v_sql_earnings_com_tr_rate else null end                              ||chr(10)-- #ADDED
          || v_sql_select_sub_clause                                                                                     ||chr(10)||chr(32)
          || v_sql_from_sub_clause                                                                                       ||chr(10)
          || ') MAIN_S'                                                                                                  ||chr(10)
				  || CASE WHEN pin_apply_validations = 1
					     THEN CASE WHEN pin_component_type <> 3 THEN v_sql_uival_from||chr(10)
                                   ELSE NULL END
                              ||pin_vld_from||chr(10)
					     ELSE NULL END;

	/* Step 15 build delete clause
       if roster has selected records, then delete only those records and then process only those records

       -- notice that in DETAILED_EARNINGS the pout_join_string is not used - the corresponding logic is built in BUILD_SQL_DETAIL_ROSTER
          and is more complicated than in the other 3 steps
       -- for pin_input_table_list use as input also pin_input_table_list, not v_in_input_table_list which has the where_clause modified
          this is in order to keep compatibility with the other 3 steps */
    COMPONENTS_PROCESSING.BUILD_SELECTED_RECS_FILTER
    (    pin_step             => 1
        ,pin_input_table_list => pin_input_table_list
        ,pin_definition_id    => pin_definition_id
        ,pin_src_table_alias  => 'S'
        ,pin_earning_entity   => pin_earning_entity(1).name1
        ,pin_payment_entity   => NULL
        ,pout_delete_string   => v_roster_delete_string
        ,pout_join_string     => v_roster_join_string
    );

    v_sql_delete_clause:=' DELETE FROM '||v_det_earn_table_name||CHR(10)
        ||CASE WHEN v_roster_delete_string IS NOT NULL
                  THEN ' WHERE ' || v_roster_delete_string
                ELSE NULL
           END;

	/* Step 17 build final insert in result table query
	*/
	v_sql_insert_in_result_table:=	 'BEGIN'||chr(10)
					 ||v_sql_insert_clause
					 ||v_sql_select_clause
					 ||v_sql_from_clause
					 ||';'||chr(10)
					 ||'END;';

	/* Step 14 run queries
	*/
    	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_select_clause) ,'v_sql_select_clause := <value>', v_stamp);

	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_delete_clause) ,'v_sql_delete_clause := <value>', v_stamp);
	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql_insert_in_result_table) ,'v_sql_insert_in_result_table := <value>', v_stamp);
	EXECUTE IMMEDIATE v_sql_delete_clause;
	EXECUTE IMMEDIATE v_sql_insert_in_result_table;

	END CREATE_DETAILED_EARNINGS;
    -- ############################# CREATE_DETAILED_EARNINGS END   #############################

	-- ############################# CREATE_AGGREGATED_EARNINGS START   #############################
	/*
	---------------------------------------------------------------------------------------
	Author     : Dumitriu, Cosmin
	Create date: 2011-06-15
	Description:

	---------------------------------------------------------------------------------------
	Input Parameters: Inherit parameters from RUN_COMPONENT

	-----------------------------------------------------------------------------------------
	Result set:

	-----------------------------------------------------------------------------------------
	Example:
	CALL CREATE_AGGREGATED_EARNINGS(
		 pin_input_table_list			=> tabletype_input_table_list(
											 objtype_input_table_list('T_INPUT', '', '', 2, 1)
											,objtype_input_table_list('T1000', '', '', 8, 1)
											,objtype_input_table_list('T2000', '', '', 9, 1)
											)
		,pin_earning_entity				=> tabletype_name_map('E777','F5')
		,pin_aggregation_type			=> 3
		,pin_period_column				=> 'F100'
		,pin_current_period				=> 1002
		,pin_projected_period_column	=> 'F10'
		,pin_projected_period			=> 103
		,pin_projected					=> 1
	);

	-----------------------------------------------------------------------------------------
	*/
	PROCEDURE CREATE_AGGREGATED_EARNINGS
	(	 pin_definition_id              IN NUMBER
        ,pin_input_table_list			IN tabletype_input_table_list
		,pin_earning_entity				IN tabletype_name_map
        ,pin_earning_calc_ent		    IN TABLETYPE_CPM_ENTITIES
		,pin_aggregation_type			IN NUMBER
        ,pin_agg_round_type			    IN NUMBER
        ,pin_agg_round_dec_num			IN NUMBER
		,pin_period_column				IN VARCHAR2
		,pin_current_period				IN NUMBER
		,pin_projected_period_column	IN VARCHAR2
		,pin_projected_period			IN NUMBER
		,pin_projected					IN NUMBER
		,pin_vld_when					IN CLOB
		,pin_vld_select					IN CLOB
		,pin_vld_from					IN CLOB
		,pin_apply_validations			IN NUMBER
        ,pin_mod_apply_option           IN NUMBER
	) IS
		v_source_table_type			NUMBER;
        v_source_column             VARCHAR2(30 CHAR);
        v_dest_table				OBJTYPE_INPUT_TABLE_LIST;
		v_source_table				OBJTYPE_INPUT_TABLE_LIST;
		v_tab_indx					PLS_INTEGER;
		v_roster_delete_string		CLOB;
        v_roster_join_string        CLOB;
		v_ece_column_list           VARCHAR2(32000 CHAR);
        v_sql_uival_select_src      VARCHAR2(32000 CHAR);
        v_sql_uival_from            VARCHAR2(32000 CHAR);
        v_agg_value                 VARCHAR2(2000 CHAR);
        v_round_value               VARCHAR2(2000 CHAR);
		v_delete_string				CLOB;
		v_insert_string				CLOB;
		v_select_string				CLOB;
		v_stamp						VARCHAR2(200);
	BEGIN
		v_stamp := 'COMPONENTS_PROCESSING.CREATE_AGGREGATED_EARNINGS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

        IF (pin_mod_apply_option = 1 or pin_mod_apply_option = 3)
        THEN
            v_source_table_type := 34;
            v_source_column := 'MODIFIED_EARNINGS';
        ELSE
            v_source_table_type := 8;
            v_source_column := 'DETAILED_EARNINGS';
        END IF;

		/* get the source , destination and earning entity table objects */
		v_tab_indx := pin_input_table_list.FIRST;
		WHILE (v_tab_indx IS NOT NULL)
		LOOP
			IF pin_input_table_list(v_tab_indx).TABLE_TYPE = v_source_table_type
			THEN
				v_source_table := pin_input_table_list(v_tab_indx);
			ELSIF pin_input_table_list(v_tab_indx).TABLE_TYPE = 9
			THEN
				v_dest_table := pin_input_table_list(v_tab_indx);
			END IF;

			v_tab_indx := pin_input_table_list.NEXT(v_tab_indx);
		END LOOP;

		/* if roster has selected records, then delete only those records and then process only those records*/
		COMPONENTS_PROCESSING.BUILD_SELECTED_RECS_FILTER
        (    pin_step             => 2
            ,pin_input_table_list => pin_input_table_list
            ,pin_definition_id    => pin_definition_id
            ,pin_src_table_alias  => 'S'
            ,pin_earning_entity   => pin_earning_entity(1).name1
            ,pin_payment_entity   => NULL
            ,pout_delete_string   => v_roster_delete_string
            ,pout_join_string     => v_roster_join_string
        );

        /* build column PECE list and possibile joins */
        FOR c_calc_ent IN (SELECT * FROM TABLE(pin_earning_calc_ent)
                           WHERE ENTITY_TYPE IN (1, 4)
                           ORDER BY ENTITY_ORDER)
        LOOP
            v_ece_column_list := v_ece_column_list
                ||CASE WHEN v_ece_column_list IS NOT NULL THEN ',' ELSE NULL END
                ||'<SRC>'||c_calc_ent.ENTITY_NAME;

            IF (c_calc_ent.COLUMN_TYPE = 1)
            THEN
                v_sql_uival_select_src := v_sql_uival_select_src||','||c_calc_ent.ENTITY_NAME||'.'||c_calc_ent.ENTITY_FIELD_NAME;
                v_sql_uival_from := v_sql_uival_from||CASE WHEN c_calc_ent.ENTITY_TYPE = 1 THEN 'INNER' ELSE 'LEFT' END
                    ||' JOIN '||c_calc_ent.ENTITY_TABLE_NAME||' '||c_calc_ent.ENTITY_NAME||' ON MAIN_S.'||c_calc_ent.ENTITY_NAME||' = '||c_calc_ent.ENTITY_NAME||'.E_INTERNAL_ID'||CHR(10);
            END IF;
        END LOOP;

		/* build strings */
		BEGIN
        v_agg_value := CASE pin_aggregation_type
            WHEN 1 THEN 'SUM'
            WHEN 2 THEN 'AVG'
            WHEN 3 THEN 'MIN'
            WHEN 4 THEN 'MAX'
            END || '('||v_source_column||')';

		v_round_value := CASE pin_agg_round_type
            WHEN 16 THEN 'ROUND('||v_agg_value||', '||TO_CHAR(pin_agg_round_dec_num)||')'
            WHEN 17 THEN  'CEIL('||v_agg_value||' * 1E+'||TO_CHAR(pin_agg_round_dec_num)||') * 1E-'||TO_CHAR(pin_agg_round_dec_num)
            WHEN 18 THEN 'FLOOR('||v_agg_value||' * 1E+'||TO_CHAR(pin_agg_round_dec_num)||') * 1E-'||TO_CHAR(pin_agg_round_dec_num)
            ELSE v_agg_value END;

        v_delete_string := 'DELETE FROM ' || v_dest_table.TABLE_NAME || CHR(10)
                            || CASE WHEN v_roster_delete_string IS NOT NULL
                                      THEN ' WHERE ' || v_roster_delete_string
                                    ELSE NULL
                               END;

		v_insert_string := 'INSERT ALL' || CHR(10)
			|| 'WHEN 1 = 1 THEN' || CHR(10)
			|| 'INTO ' || v_dest_table.TABLE_NAME || '('
				|| REPLACE(v_ece_column_list, '<SRC>', '')
				|| ', ' || pin_period_column
				|| CASE
					WHEN pin_projected IS NOT NULL THEN ', ' || pin_projected_period_column
					ELSE NULL END
				|| CASE
					WHEN pin_projected IS NOT NULL THEN ', PROJECTED'
					ELSE NULL END
				|| ', AGGREGATED_EARNINGS'
				|| ', PROCESSED_DATE_TIME'
				|| ', ROW_IDENTIFIER'
				|| ', ROW_VERSION)' || CHR(10)
			|| 'VALUES ('
				|| REPLACE(v_ece_column_list, '<SRC>', '')
				|| ', ' || pin_period_column
				|| CASE
					WHEN pin_projected IS NOT NULL THEN ', ' || pin_projected_period_column
					ELSE NULL END
				|| CASE
					WHEN pin_projected IS NOT NULL THEN ', PROJECTED'
					ELSE NULL END
				|| ', AGGREGATED_EARNINGS'
				|| ', PROCESSED_DATE_TIME'
				|| ', ' ||commons_appframework.get_row_identifier_sequence
                            (pi_table_name => v_dest_table.TABLE_NAME
                            ,pi_period_id => CASE WHEN pin_projected IS NOT NULL THEN pin_projected_period
                                                  ELSE pin_current_period END
                            ) || '.NEXTVAL'
				|| ', ROW_VERSION)'||chr(10)
			||CASE WHEN pin_apply_validations = 3 THEN pin_vld_when ELSE NULL END||chr(10);

		v_select_string := 'SELECT
				 MAIN_S.*
				,0 ROW_VERSION
				,CAST(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' AS DATE) PROCESSED_DATE_TIME
			       '||CASE  WHEN pin_apply_validations = 3
                            THEN v_sql_uival_select_src||chr(10)
                                 ||pin_vld_select
                            ELSE NULL END||'
			FROM
				(SELECT '
					|| REPLACE(v_ece_column_list, '<SRC>', 'S.')
					|| ', ' || TO_CHAR(pin_current_period) || ' ' || pin_period_column
					|| CASE WHEN pin_projected IS NOT NULL
							THEN ', ' || TO_CHAR(pin_projected_period) || ' ' || pin_projected_period_column
							ELSE NULL END
					|| CASE	WHEN pin_projected IS NOT NULL
							THEN ', ' || TO_CHAR(pin_projected) || ' PROJECTED'
							ELSE NULL END
					-- the result of the aggregation is rounded to (13 + field_precision, field_precision)
					|| ', CAST('||v_round_value||' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('AGGREGATED_EARNINGS')||') AGGREGATED_EARNINGS'||chr(10)
				||'FROM ' || v_source_table.TABLE_NAME ||' S'||CHR(10)
                        -- this string is a filter only for roster with "selected records"
                        ||v_roster_join_string||CHR(10)
				||'GROUP BY ' || REPLACE(v_ece_column_list, '<SRC>', 'S.') || ') MAIN_S'||chr(10)
			|| CASE WHEN pin_apply_validations = 3
				    THEN v_sql_uival_from
				         ||pin_vld_from
				    ELSE NULL END||chr(10);
		END;

		v_insert_string := v_insert_string || CHR(10) || v_select_string;

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_delete_string) ,',v_delete_string => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_insert_string) ,',v_insert_string => <value>', v_stamp);
		EXECUTE IMMEDIATE v_delete_string;
		EXECUTE IMMEDIATE v_insert_string;
	END CREATE_AGGREGATED_EARNINGS;
	-- ############################# CREATE_AGGREGATED_EARNINGS END   #############################

    -- ############################# CREATE_MODIFIED_EARNINGS START   #############################
    /*
    Author     : Dumitriu, Cosmin
    Create date: 2011/08/11
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
        Inherit parameters from RUN_COMPONENT
    -----------------------------------------------------------------------------------------
    Result set:

    -----------------------------------------------------------------------------------------
    Example:

    */
	PROCEDURE CREATE_MODIFIED_EARNINGS
	(	 pin_definition_id          IN NUMBER
        ,pin_input_table_list		IN TABLETYPE_INPUT_TABLE_LIST
		,pin_earning_entity			IN TABLETYPE_NAME_MAP
        ,pin_earning_calc_ent		IN TABLETYPE_CPM_ENTITIES
		,pin_mod_when				IN CLOB
		,pin_mod_select				IN CLOB
		,pin_mod_from				IN CLOB
		,pin_mod_where				IN CLOB
		,pin_vld_when				IN CLOB
		,pin_vld_select				IN CLOB
		,pin_vld_from				IN CLOB
		,pin_apply_validations		IN NUMBER
        ,pin_mod_apply_option		IN NUMBER
	) IS
		v_source_table_type			NUMBER;
		v_dest_table_type			NUMBER;
		v_dest_table				OBJTYPE_INPUT_TABLE_LIST;
		v_source_table				OBJTYPE_INPUT_TABLE_LIST;
		v_tab_indx					PLS_INTEGER;
		v_sql_uival_select_src      VARCHAR2(32000 CHAR);
        v_sql_uival_from            VARCHAR2(32000 CHAR);
		v_roster_delete_string		CLOB;
		v_roster_join_string		CLOB;
		v_delete_string				CLOB;
		v_insert_string				CLOB;
		v_stamp						VARCHAR2(200);
	BEGIN
		v_stamp := 'COMPONENTS_PROCESSING.CREATE_MODIFIED_EARNINGS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

		/* get the source, destination and earning entity table objects */
		v_source_table_type := CASE WHEN pin_mod_apply_option = 1 THEN 8 ELSE 9 END;
		v_dest_table_type := CASE WHEN pin_mod_apply_option = 1 THEN 34 ELSE 10 END;

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_source_table_type) ,'v_source_table_type := <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_dest_table_type) ,'v_dest_table_type := <value>', v_stamp);
		v_tab_indx := pin_input_table_list.FIRST;
		WHILE (v_tab_indx IS NOT NULL)
      LOOP
        IF pin_input_table_list(v_tab_indx).TABLE_TYPE    = v_source_table_type THEN
			v_source_table := pin_input_table_list(v_tab_indx);
        ELSIF pin_input_table_list(v_tab_indx).TABLE_TYPE = v_dest_table_type THEN
			v_dest_table := pin_input_table_list(v_tab_indx);
        END IF;
        v_tab_indx := pin_input_table_list.NEXT(v_tab_indx);
      END LOOP;

        /*  based on when modifiers are applied, the UI validations will need to log a list of either ECEs or PECEs
            if pin_mod_apply_option = 1 - modifiers before aggregation - build list of ECE: earning entity + additional plan calculation fields/ent + component specific fields/ent
            if pin_mod_apply_option = 2 - modifiers after aggregation - build list of PECE: earning entity + additional plan calculation fields/ent */
        FOR c_calc_ent IN (SELECT * FROM TABLE(pin_earning_calc_ent)
                           WHERE COLUMN_TYPE = 1
                                AND (  (pin_mod_apply_option = 1 AND ENTITY_TYPE IN (1, 3, 4))
                                    OR (pin_mod_apply_option = 2 AND ENTITY_TYPE IN (1, 4)))
                           ORDER BY ENTITY_ORDER)
        LOOP
            v_sql_uival_select_src := v_sql_uival_select_src||','||c_calc_ent.ENTITY_NAME||'.'||c_calc_ent.ENTITY_FIELD_NAME;
            v_sql_uival_from := v_sql_uival_from||CASE WHEN c_calc_ent.ENTITY_TYPE = 1 THEN 'INNER' ELSE 'LEFT' END
                ||' JOIN '||c_calc_ent.ENTITY_TABLE_NAME||' '||c_calc_ent.ENTITY_NAME||' ON MAIN_S.'||c_calc_ent.ENTITY_NAME||' = '||c_calc_ent.ENTITY_NAME||'.E_INTERNAL_ID'||CHR(10);
        END LOOP;

		/* if roster has selected records, then join with the roster*/
		COMPONENTS_PROCESSING.BUILD_SELECTED_RECS_FILTER
        (    pin_step             => 3
            ,pin_input_table_list => pin_input_table_list
            ,pin_definition_id    => pin_definition_id
            ,pin_src_table_alias  => 'MAIN_S'
            ,pin_earning_entity   => pin_earning_entity(1).name1
            ,pin_payment_entity   => NULL
            ,pout_delete_string   => v_roster_delete_string
            ,pout_join_string     => v_roster_join_string
        );

		/* build strings */
		BEGIN
          v_delete_string := 'DELETE FROM ' || v_dest_table.TABLE_NAME || CHR(10)
              || CASE WHEN v_roster_delete_string IS NOT NULL
                        THEN ' WHERE ' || v_roster_delete_string
                      ELSE NULL
                 END;

		v_insert_string := 'INSERT ALL' || CHR(10)
			|| pin_mod_when || CHR(10)
			|| CASE WHEN pin_apply_validations = 5 THEN pin_vld_when||chr(10) ELSE NULL END
			|| 'SELECT MAIN_S.* ' || CHR(10)
			|| CASE	WHEN pin_apply_validations = 5
					THEN v_sql_uival_select_src||chr(10)
					     ||pin_vld_select
					ELSE NULL END|| CHR(10)
			|| 'FROM (SELECT ' || pin_mod_select || CHR(10)
					|| 'FROM ' || pin_mod_from || CHR(10)
					|| CASE WHEN pin_mod_where IS NULL THEN '' ELSE 'WHERE ' || pin_mod_where END || ') MAIN_S'|| CHR(10)
				|| v_roster_join_string|| CHR(10)
				|| CASE WHEN pin_apply_validations = 5
					THEN v_sql_uival_from
					     ||pin_vld_from
					ELSE NULL END || chr(10);
		END;

		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_delete_string) ,'v_delete_string := <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_insert_string) ,'v_insert_string := <value>', v_stamp);
		EXECUTE IMMEDIATE v_delete_string;
		EXECUTE IMMEDIATE v_insert_string;

	END CREATE_MODIFIED_EARNINGS;
    -- ############################# CREATE_MODIFIED_EARNINGS END   #############################

    -- ############################# CREATE_COMPONENT_EARNINGS START   #############################
    /*
    Author     : Lazarescu, Bogdan
    Create date: 20110617
    Description:
    ---------------------------------------------------------------------------------------
    Input Parameters:
            Inherit parameters from RUN_COMPONENT
    -----------------------------------------------------------------------------------------
    Result set:

    -----------------------------------------------------------------------------------------
    Example:
    */
	PROCEDURE CREATE_COMPONENT_EARNINGS
	(	 pin_definition_id              IN NUMBER
        ,pin_input_table_list			IN tabletype_input_table_list
        ,pin_input_table_type           IN NUMBER
		,pin_earning_entity				IN tabletype_name_map
        ,pin_earning_calc_ent		    IN TABLETYPE_CPM_ENTITIES
		,pin_payment_entity				IN VARCHAR2
		,pin_period_column				IN VARCHAR2
		,pin_current_period				IN NUMBER
		,pin_projected_period_column	IN VARCHAR2
		,pin_projected_period			IN NUMBER
		,pin_projected					IN NUMBER
	) AS
	v_input_table_list      rtype_table_list;
	v_sql			        CLOB;
    v_roster_delete_string	CLOB;
    v_roster_join_string    CLOB;

	v_eligibility_exists	NUMBER;
	v_eligibility_table	    CLOB;
	v_eligibility_insert	CLOB;
	v_eligibility_select	CLOB;

    v_ece_column_list       VARCHAR2(32000 CHAR);
	v_input_table		    VARCHAR2(30);
	v_output_table		    VARCHAR2(30);
	v_stamp				    VARCHAR2(200);
	BEGIN
	v_stamp := 'COMPONENTS_PROCESSING.CREATE_COMPONENT_EARNINGS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    /***roster***/
    -- roster table is used for two purposes:
    -- * when earning entity <> payment entity we need to expand the earning records to payment level
    -- * when user includes only "selected records" we need to delete and then insert back only those records
    -- sometimes we need to both filter and expand at the same time
    -- sometimes we don't need anything
    COMPONENTS_PROCESSING.BUILD_SELECTED_RECS_FILTER
    (    pin_step             => 4
        ,pin_input_table_list => pin_input_table_list
        ,pin_definition_id    => pin_definition_id
        ,pin_src_table_alias  => 'I'
        ,pin_earning_entity   => pin_earning_entity(1).name1
        ,pin_payment_entity   => pin_payment_entity
        ,pout_delete_string   => v_roster_delete_string
        ,pout_join_string     => v_roster_join_string
    );

    -- get input for component earning - it can be: 8 Detailed earnings; 9 Aggregated Earnings; 10 Modified Earnings
    SELECT table_name into v_input_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE = pin_input_table_type;
    -- get output table
	SELECT table_name INTO v_output_table FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE = 11;

    /* build column PECE list*/
    FOR c_calc_ent IN (SELECT * FROM TABLE(pin_earning_calc_ent)
                       WHERE ENTITY_TYPE IN (1, 4)
                       ORDER BY ENTITY_ORDER)
    LOOP
        v_ece_column_list := v_ece_column_list||'<SRC>'||c_calc_ent.ENTITY_NAME||', ';
    END LOOP;

    /***eligibility***/
    SELECT COUNT(1) into v_eligibility_exists FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE = 7;
    IF v_eligibility_exists = 1
    THEN
        SELECT * INTO v_input_table_list FROM TABLE(pin_input_table_list) WHERE TABLE_TYPE=7;

        v_eligibility_table := ' LEFT JOIN (SELECT * FROM ' || v_input_table_list.table_name
            || CASE WHEN v_input_table_list.where_clause IS NOT NULL
                    THEN ' WHERE ' || v_input_table_list.where_clause
                    ELSE NULL END
            || CASE WHEN v_input_table_list.FROM_CLAUSE IS NOT NULL
                    THEN ') ' || v_input_table_list.FROM_CLAUSE
                    ELSE ') E ON I.' || pin_earning_entity(1).name1 || ' = E.' || pin_earning_entity(1).name1
               END
            || CASE WHEN pin_earning_entity(1).name1 != pin_payment_entity
                            THEN ' AND R.' || pin_payment_entity || ' = E.' || pin_payment_entity
                            ELSE NULL END;

        v_eligibility_insert := 'EARNINGS_BEFORE_ELIGIBILITY, ELIGIBILITY, ';
        v_eligibility_select := 'CAST(' || CASE WHEN pin_input_table_type = 34 THEN 'I.MODIFIED_EARNINGS '
                                                WHEN pin_input_table_type = 10 THEN 'I.MODIFIED_EARNINGS '
                                                 WHEN pin_input_table_type = 9 THEN 'I.AGGREGATED_EARNINGS '
                                                 WHEN pin_input_table_type = 8 THEN 'I.DETAILED_EARNINGS '
                                                 END || ' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('EARNINGS_BEFORE_ELIGIBILITY')||') AS EARNINGS_BEFORE_ELIGIBILITY,
                CAST(COALESCE(E.ELIGIBILITY, 1) AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('ELIGIBILITY')||') AS ELIGIBILITY, ';
    END IF;

	v_sql := '
		  BEGIN
            DELETE FROM ' || v_output_table
                          || CASE WHEN v_roster_delete_string IS NOT NULL
                                    THEN ' WHERE ' || v_roster_delete_string
                                  ELSE NULL
                             END || ';

			 INSERT INTO ' || v_output_table || '('
					 || REPLACE(v_ece_column_list, '<SRC>', '')
					 || CASE WHEN pin_earning_entity(1).name1 != pin_payment_entity THEN pin_payment_entity || ', ' ELSE NULL END
					 || pin_period_column || ', '
					 || CASE WHEN pin_projected_period_column IS NOT NULL THEN pin_projected_period_column || ', ' ELSE NULL END
					 || CASE WHEN pin_projected IS NOT NULL THEN 'PROJECTED, ' ELSE NULL END
					 || 'COMPONENT_EARNINGS, '
					 || v_eligibility_insert
					 || 'PROCESSED_DATE_TIME, ROW_IDENTIFIER, ROW_VERSION)
			   SELECT '||REPLACE(v_ece_column_list, '<SRC>', 'I.')
					  || CASE WHEN pin_earning_entity(1).name1 != pin_payment_entity THEN ' R.' || pin_payment_entity || ', ' ELSE NULL END
					  || ' I.' || pin_period_column || ', '
					  || CASE WHEN pin_projected_period_column IS NOT NULL THEN 'I.' || pin_projected_period_column || ', ' ELSE NULL END
					  || CASE WHEN pin_projected IS NOT NULL THEN 'I.PROJECTED, ' ELSE NULL END

					  || ' CAST('
					  || (CASE WHEN v_eligibility_exists = 0 THEN '' ELSE 'COALESCE(E.ELIGIBILITY, 1) * ' END)
					  || (CASE WHEN pin_input_table_type = 34 THEN 'I.MODIFIED_EARNINGS '
                              WHEN pin_input_table_type = 10 THEN 'I.MODIFIED_EARNINGS '
							  WHEN pin_input_table_type = 9 THEN 'I.AGGREGATED_EARNINGS '
							  WHEN pin_input_table_type = 8 THEN 'I.DETAILED_EARNINGS '
						 END)
					  || ' AS NUMBER'||COMMONS.FIELD_PRECISION_AND_SCALE('COMPONENT_EARNINGS')||') AS COMPONENT_EARNINGS, '

					  || v_eligibility_select
					  || 'CAST(CURRENT_TIMESTAMP AT TIME ZONE ''GMT'' AS DATE) PROCESSED_DATE_TIME, '
					  || commons_appframework.get_row_identifier_sequence
                            (pi_table_name => v_output_table
                            ,pi_period_id => CASE WHEN pin_projected IS NOT NULL THEN pin_projected_period
                                                  ELSE pin_current_period END
                            ) || '.NEXTVAL AS ROW_IDENTIFIER, 0 AS ROW_VERSION
				FROM ' || v_input_table || ' I '||CHR(10)
					   || v_roster_join_string
					   || v_eligibility_table || ';' || CHR(10) || '
		  END; ';

	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql) ,',v_sql => <value>', v_stamp);
	execute immediate v_sql;

	END;
    -- ############################# CREATE_COMPONENT_EARNINGS END   #############################

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

    -- ############################# RUN_COMPONENT START   #############################
    PROCEDURE RUN_COMPONENT
	(	 pin_definition_id              IN NUMBER
     ,pin_lookup_table				IN TABLETYPE_LOOKUP_TABLE_LIST
		,pin_input_table_list			IN TABLETYPE_INPUT_TABLE_LIST
    ,pin_earning_entity				IN TABLETYPE_NAME_MAP
		,pin_payment_entity				IN VARCHAR2
		,pin_earning_calc_ent			IN TABLETYPE_CPM_ENTITIES
		,pin_use_target					IN NUMBER
		,pin_input_values_columns		IN TABLETYPE_ID_NAME
    ,pin_component_type				IN NUMBER
		,pin_component_subtype			IN NUMBER
		,pin_comision_rate_value		IN NUMBER
		,pin_component_weight_value		IN NUMBER
		,pin_plan_target_earn_val		IN NUMBER
		,pin_comp_target_earn_val		IN NUMBER
    ,pin_cust_form_exp              IN CLOB
    ,pin_cust_form_clauses          IN TABLETYPE_CUST_FORM_CLAUSES
    ,pin_cust_form_ass_ent          IN TABLETYPE_NAME_JOIN_MAP
		,pin_aggregation_type			IN NUMBER
    ,pin_agg_round_type			    IN NUMBER
    ,pin_agg_round_dec_num			IN NUMBER
		,pin_period_column				IN VARCHAR2
		,pin_current_period				IN NUMBER
		,pin_projected_period_column	IN VARCHAR2
		,pin_projected_period			IN NUMBER
		,pin_projected					IN NUMBER
		,pin_no_plan_per_for_comp_per	IN NUMBER
		,pin_no_plan_per_for_target		IN NUMBER
		,pin_no_comp_per_for_target		IN NUMBER
		,pin_no_comp_per_pas_in_sub  IN NUMBER
		,pin_component_weight_fields    IN TABLETYPE_ID_NAME
		,pin_vld_when					IN CLOB
		,pin_vld_select					IN CLOB
		,pin_vld_from					IN CLOB
		,pin_vld_get_values				IN CLOB
		,pin_vld_need_to_count			IN NUMBER
		--,pin_mod_apply_option			IN NUMBER DEFAULT 2
	    ,pin_before_mod_when                IN CLOB
        ,pin_before_mod_select              IN CLOB
        ,pin_before_mod_from                IN CLOB
        ,pin_before_mod_where               IN CLOB
        ,pin_after_mod_when                 IN CLOB
        ,pin_after_mod_select               IN CLOB
        ,pin_after_mod_from                 IN CLOB
        ,pin_after_mod_where                IN CLOB
        ,pin_lookup_precision   IN VARCHAR2
		,pout_ee_posted_count			OUT NUMBER
		,pout_vld_results				OUT SYS_REFCURSOR
	) AS
		v_stamp							VARCHAR2(200 CHAR);
        v_input_table_list              TABLETYPE_INPUT_TABLE_LIST;
        v_comp_no_dup_check             TABLETYPE_NUMBER;
        v_comp_in_cnt                   NUMBER;
		v_apply_validations				NUMBER;
        v_mod_apply_option			    NUMBER;
		v_vld_table_type				NUMBER;
		v_vld_table						OBJTYPE_INPUT_TABLE_LIST;
		v_entity_table					OBJTYPE_INPUT_TABLE_LIST;
		v_sel_roster_table				OBJTYPE_INPUT_TABLE_LIST;
        v_roster_select_string          VARCHAR2(32000 CHAR);
        v_roster_join_string            VARCHAR2(32000 CHAR);
	BEGIN
	v_stamp := 'COMPONENTS_PROCESSING.RUN_COMPONENT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log input parameters
	BEGIN
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_definition_id) ,',pin_definition_id => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_lookup_table) ,',pin_lookup_table => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_input_table_list) ,',pin_input_table_list => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_earning_entity) ,',pin_earning_entity => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_payment_entity) ,',pin_payment_entity => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_earning_calc_ent) ,',pin_earning_calc_ent => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_use_target) ,',pin_use_target => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_input_values_columns) ,',pin_input_values_columns => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_component_type) ,',pin_component_type => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_component_subtype) ,',pin_component_subtype => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_comision_rate_value) ,',pin_comision_rate_value => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_component_weight_value) ,',pin_component_weight_value => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_plan_target_earn_val) ,',pin_plan_target_earn_val => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_comp_target_earn_val) ,',pin_comp_target_earn_val => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_cust_form_exp) ,',pin_cust_form_exp => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_cust_form_clauses) ,',pin_cust_form_clauses => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_cust_form_ass_ent) ,',pin_cust_form_ass_ent => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_aggregation_type) ,',pin_aggregation_type => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_agg_round_type) ,',pin_agg_round_type => <value>', v_stamp);
    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_agg_round_dec_num) ,',pin_agg_round_dec_num => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_period_column) ,',pin_period_column => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_current_period) ,',pin_current_period => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pin_projected_period_column) ,',pin_projected_period_column => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projected_period) ,',pin_projected_period => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_projected) ,',pin_projected => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_no_plan_per_for_comp_per) ,',pin_no_plan_per_for_comp_per => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_no_plan_per_for_target) ,',pin_no_plan_per_for_target => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_no_comp_per_for_target) ,',pin_no_comp_per_for_target => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_no_comp_per_pas_in_sub) ,',pin_no_comp_per_pas_in_sub => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pin_component_weight_fields) ,',pin_component_weight_fields => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_vld_when) ,',pin_vld_when => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_vld_select) ,',pin_vld_select => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_vld_from) ,',pin_vld_from => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_vld_get_values) ,',pin_vld_get_values => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_vld_need_to_count) ,',pin_vld_need_to_count => <value>', v_stamp);
		--L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pin_mod_apply_option) ,',pin_mod_apply_option => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_before_mod_when) ,',pin_before_mod_when => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_before_mod_select) ,',pin_before_mod_select => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_before_mod_from) ,',pin_before_mod_from => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_before_mod_where) ,',pin_before_mod_where => <value>', v_stamp);
       	L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_after_mod_when) ,',pin_after_mod_when => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_after_mod_select) ,',pin_after_mod_select => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_after_mod_from) ,',pin_after_mod_from => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_after_mod_where) ,',pin_after_mod_where => <value>', v_stamp);
		L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pin_lookup_precision) ,',pin_lookup_precision => <value>', v_stamp);
	END;

    -- make sure that modifiers applied before aggregation but with no aggregation type are seen as modifiers to apply after
    v_mod_apply_option := CASE
                             WHEN nullif (length (pin_before_mod_when), 0) IS NULL AND nullif (length (pin_after_mod_when), 0) IS NULL THEN 0
                             WHEN pin_before_mod_when IS NOT NULL AND nullif (length (pin_after_mod_when), 0) IS NULL THEN 1
	                         WHEN pin_after_mod_when  IS NOT NULL AND nullif (length (pin_before_mod_when), 0) IS NULL THEN 2
	                         WHEN pin_before_mod_when IS NOT NULL AND pin_after_mod_when  IS NOT NULL THEN 3
                          END;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(v_mod_apply_option) ,',v_mod_apply_option => <value>', v_stamp);

    SELECT COUNT(*) INTO v_comp_in_cnt
    FROM TABLE(pin_input_values_columns) WHERE NAME <> 'METRIC';

    IF (v_comp_in_cnt > 0)
    THEN
        COMPENSATION_PROCESSING.GROUP_PERIODS_FOR_INPUT(pin_input_table_list => pin_input_table_list
                                                       ,pin_earning_calc_ent => pin_earning_calc_ent
                                                       ,pin_input_values_columns => pin_input_values_columns
                                                       ,POUT_DUPS_FOUND => v_comp_no_dup_check
                                                       ,pout_input_table_list => v_input_table_list);
    ELSE
        v_input_table_list := pin_input_table_list;
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(v_input_table_list) ,'v_input_table_list => <value>', v_stamp);

	-- establish if the validations are to be done here and if yes on which query we will add it
	-- on the processing query or on the result table
	WHERE_TO_APPLY_VALIDATIONS
	(	 pin_input_table_list	=> v_input_table_list
		,pin_aggregation_type	=> pin_aggregation_type
        ,pin_mod_apply_option   => v_mod_apply_option
		,pin_vld_when			=> pin_vld_when
		,pout_apply_validations	=> v_apply_validations
	);

    -- create Component Earnings in Tiers if needed
    IF (pin_component_type = 4)
    THEN
      CREATE_DETAILED_EARNINGS_TIER
      (	 pin_definition_id              => pin_definition_id
        ,pin_input_table_list		     => v_input_table_list
        ,pin_input_values_column        => 'METRIC'
        ,pin_lookup_table            => pin_lookup_table
        ,pin_earning_entity			     => pin_earning_entity
        ,pin_earning_calc_ent        => pin_earning_calc_ent
        ,pin_no_plan_per_for_target	 => pin_no_plan_per_for_target
        ,pin_component_subtype		   => pin_component_subtype
        ,pin_period_column			     => pin_period_column
        ,pin_current_period			     => pin_current_period
        ,pin_projected_period_column => pin_projected_period_column
        ,pin_projected_period		     => pin_projected_period
        ,pin_projected				       => pin_projected
      );
    END IF;

	-- insert data into result table Detailed Earnings
	BEGIN
		CREATE_DETAILED_EARNINGS
		(	 pin_definition_id              => pin_definition_id
            ,pin_lookup_table				=> pin_lookup_table
			,pin_input_table_list			=> v_input_table_list
            ,pin_input_values_columns       => pin_input_values_columns
			,pin_earning_entity				=> pin_earning_entity
			,pin_earning_calc_ent			=> pin_earning_calc_ent
			,pin_use_target					=> pin_use_target
			,pin_component_type				=> pin_component_type
			,pin_component_subtype			=> pin_component_subtype
			,pin_comision_rate_value		=> pin_comision_rate_value
			,pin_component_weight_value		=> pin_component_weight_value
			,pin_plan_target_earn_val		=> pin_plan_target_earn_val
			,pin_comp_target_earn_val		=> pin_comp_target_earn_val
            ,pin_cust_form_exp              => pin_cust_form_exp
            ,pin_cust_form_clauses          => pin_cust_form_clauses
            ,pin_cust_form_ass_ent          => pin_cust_form_ass_ent
			,pin_period_column				=> pin_period_column
			,pin_current_period				=> pin_current_period
			,pin_projected_period_column	=> pin_projected_period_column
			,pin_projected_period			=> pin_projected_period
			,pin_projected					=> pin_projected
			,pin_no_plan_per_for_comp_per	=> pin_no_plan_per_for_comp_per
			,pin_no_plan_per_for_target		=> pin_no_plan_per_for_target
			,pin_no_comp_per_for_target		=> pin_no_comp_per_for_target
			,pin_no_comp_per_pas_in_sub => pin_no_comp_per_pas_in_sub
			,pin_component_weight_fields	=> pin_component_weight_fields
			,pin_vld_when					=> pin_vld_when
			,pin_vld_select					=> pin_vld_select
			,pin_vld_from					=> pin_vld_from
			,pin_apply_validations			=> v_apply_validations
      ,pin_lookup_precision   => pin_lookup_precision
		);
		v_vld_table_type := 8;
	END;


    -- if modifiers must be executed before aggregation - insert into result table Modified Earnings
    IF (v_mod_apply_option = 1)  OR  (v_mod_apply_option = 3)
    THEN
        CREATE_MODIFIED_EARNINGS
		(	 pin_definition_id          => pin_definition_id
            ,pin_input_table_list		=> v_input_table_list
			,pin_earning_entity			=> pin_earning_entity
            ,pin_earning_calc_ent       => pin_earning_calc_ent
			,pin_mod_when				=> pin_before_mod_when
			,pin_mod_select				=> pin_before_mod_select
			,pin_mod_from				=> pin_before_mod_from
			,pin_mod_where				=> pin_before_mod_where
			,pin_vld_when				=> pin_vld_when
			,pin_vld_select				=> pin_vld_select
			,pin_vld_from				=> pin_vld_from
			,pin_apply_validations		=> v_apply_validations
            ,pin_mod_apply_option       => 1
		);
    	v_vld_table_type := 34;
    END IF;

    -- detect if we need to agregate then insert data into result table Aggregated Earnings
	IF (pin_aggregation_type IS NOT NULL)
	THEN
		CREATE_AGGREGATED_EARNINGS
		(	 pin_definition_id          => pin_definition_id
            ,pin_input_table_list		=> v_input_table_list
			,pin_earning_entity			=> pin_earning_entity
            ,pin_earning_calc_ent       => pin_earning_calc_ent
			,pin_aggregation_type		=> pin_aggregation_type
            ,pin_agg_round_type         => pin_agg_round_type
            ,pin_agg_round_dec_num      => pin_agg_round_dec_num
			,pin_period_column			=> pin_period_column
			,pin_current_period			=> pin_current_period
			,pin_projected_period_column=> pin_projected_period_column
			,pin_projected_period		=> pin_projected_period
			,pin_projected				=> pin_projected
			,pin_vld_when				=> pin_vld_when
			,pin_vld_select				=> pin_vld_select
			,pin_vld_from				=> pin_vld_from
			,pin_apply_validations		=> v_apply_validations
            ,pin_mod_apply_option       => v_mod_apply_option
		);
		v_vld_table_type := 9;
	END IF;


    -- if modifiers must be executed after aggregation - insert into result table Modified Earnings
    IF (v_mod_apply_option = 2)  OR  (v_mod_apply_option = 3)
	THEN
        CREATE_MODIFIED_EARNINGS
		(	 pin_definition_id          => pin_definition_id
            ,pin_input_table_list		=> v_input_table_list
			,pin_earning_entity			=> pin_earning_entity
            ,pin_earning_calc_ent       => pin_earning_calc_ent
			,pin_mod_when				=> pin_after_mod_when
			,pin_mod_select				=> pin_after_mod_select
			,pin_mod_from				=> pin_after_mod_from
			,pin_mod_where				=> pin_after_mod_where
			,pin_vld_when				=> pin_vld_when
			,pin_vld_select				=> pin_vld_select
			,pin_vld_from				=> pin_vld_from
			,pin_apply_validations		=> v_apply_validations
            ,pin_mod_apply_option       => 2
		);
		v_vld_table_type := 10;
	END IF;

	-- insert data into result table Component Earnings
	BEGIN
		CREATE_COMPONENT_EARNINGS
		(	 pin_definition_id          => pin_definition_id
            ,pin_input_table_list		=> v_input_table_list
            ,pin_input_table_type       => v_vld_table_type
			,pin_earning_entity			=> pin_earning_entity
            ,pin_earning_calc_ent       => pin_earning_calc_ent
			,pin_payment_entity			=> pin_payment_entity
			,pin_period_column			=> pin_period_column
			,pin_current_period			=> pin_current_period
			,pin_projected_period_column=> pin_projected_period_column
			,pin_projected_period		=> pin_projected_period
			,pin_projected				=> pin_projected
		);
	END;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(v_input_table_list) ,'v_input_table_list => <value>', v_stamp);


	-- build helpful clauses
	BEGIN
		v_vld_table := GET_TABLE_BY_TYPE(pin_input_table_list	=> v_input_table_list
										,pin_table_type			=> v_vld_table_type);

		v_entity_table := GET_TABLE_BY_TYPE( pin_input_table_list	=> v_input_table_list
											,pin_table_type			=> 16);

		IF (v_sel_roster_table IS NOT NULL)
		THEN
            COMPONENTS_PROCESSING.BUILD_SELECTED_RECS_FILTER
            (    pin_step             => 1
                ,pin_input_table_list => v_input_table_list
                ,pin_definition_id    => pin_definition_id
                ,pin_src_table_alias  => 'MAIN_S'
                ,pin_earning_entity   => pin_earning_entity(1).name1
                ,pin_payment_entity   => NULL
                ,pout_delete_string   => v_roster_select_string
                ,pout_join_string     => v_roster_join_string
            );
		END IF;
	END;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(v_input_table_list) ,'v_input_table_list => <value>', v_stamp);


	-- delete from the result tables ane EEs which had errros during processes
	DELETE_RES_INVALID_ENT(	 pin_input_table_list	=> v_input_table_list
							,pin_earning_entity		=> pin_earning_entity);

	-- get the flag whether any EEs have been posted to the result tables
	pout_ee_posted_count := GET_POSTED_EE_FLAG(	 pin_result_table	=> v_vld_table
												,pin_sel_roster_sql	=> v_roster_select_string);

	-- if UI vld were done during processing then delete invalid entities
	-- else perform the validations on the result tables
	IF (v_apply_validations IN (1, 3, 5))
	THEN
		DELETE_UIVLD_INVALID_ENT(	 pin_entity_table	=> v_entity_table
									,pin_earning_entity	=> pin_earning_entity);
	ELSIF (v_apply_validations IN (2, 4, 6))
	THEN
		RUN_VALIDATIONS_ON_RES_TABLE
		(	 pin_result_table			=> v_vld_table
			,pin_vld_when				=> pin_vld_when
			,pin_vld_select				=> pin_vld_select
			,pin_vld_from				=> pin_vld_from
			,pin_earning_calc_ent		=> pin_earning_calc_ent
		);
	END IF;

	-- open cursor for the performed validations
	IF (v_apply_validations <> 0)
	THEN
		OUTPUT_VALIDATION_RESULTS
		(	 pin_result_table			=> v_vld_table
			,pin_vld_get_values			=> pin_vld_get_values
			,pin_vld_need_to_count		=> pin_vld_need_to_count
			,pout_vld_results			=> pout_vld_results
		);
	ELSE
		OPEN pout_vld_results FOR
			SELECT
				 NULL VALIDATION_ID
				,NULL VALIDATION_TYPE
				,NULL VALIDATION_ENT_CNT
				,NULL VALIDATION_DETAILS
			FROM DUAL
			WHERE 1 = 0;
	END IF;

	EXCEPTION
	WHEN OTHERS THEN
		L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
		RAISE;
	END RUN_COMPONENT;
    -- ############################# RUN_COMPONENT END   #############################

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END	    *******************************

END COMPONENTS_PROCESSING;
/
