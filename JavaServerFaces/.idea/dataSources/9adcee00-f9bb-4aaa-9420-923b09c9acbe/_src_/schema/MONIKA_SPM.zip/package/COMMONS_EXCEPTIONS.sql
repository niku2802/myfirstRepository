CREATE package commons_exceptions is
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  appframework
  -- Requester    :  Lazar, Lucian
  -- Author    :  Lazar, Lucian
  -- Reviewer    :
  -- Review date    :
  -- Description    :  Used for handling custom errors
  -- ---------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect the caller to raise a custom error using the corresponding error code
     and error message for each custom exception.
     If the error message has placeholders (%1, %2, etc.) we expect the caller to use
     the error_text function when raising the error message with the correct separator (;)
     and the correct number of arguments.
  */
  -- ---------------------------------------------------------------------------
  -- Call example for no placeholders in error message
  -- e_RegularSQLError_msg CONSTANT VARCHAR2(1000) := 'Error during executiong script.';
  /*
  exception
    when exceptions.e_RegularSQLError then
      RAISE_APPLICATION_ERROR(EXCEPTIONS.e_RegularSQLError_code,
                              EXCEPTIONS.e_RegularSQLError_msg);
  */
  -- Resulted error message will be:
  -- 'Error during executiong script.'
  -- ---------------------------------------------------------------------------
  -- Call example for 2 placeholders in error message:
  -- e_DDLRolbackFailed_msg CONSTANT VARCHAR2(1000) :=
  -- 'DDL rollback for transaction %1, index %2 failed. Please check the UNDO DDL table.';
  /*
  exception
    when exceptions.e_DDLRolbackFailed then
      RAISE_APPLICATION_ERROR(EXCEPTIONS.e_DDLRolbackFailed_code,
                              EXCEPTIONS.error_text(EXCEPTIONS.e_DDLRolbackFailed_msg,
                                                    l_UD_TRANSACTION_ID || ';' || l_UD_INDEX));
  */
  -- Resulted error message will be:
  -- 'DDL rollback for transaction 111, index 6 failed. Please check the UNDO DDL table.'
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC FUNCTIONS START       *******************************

  -- ========================================================
  -- Author     : Lazar, Lucian
  -- Create date: 20110202
  -- Description: Used in raising a custom error to build a error message with placeholders
  -----------------------------------------------------------------------------------------
  -- Input Parameters:
  /*
     pi_error_msg IN VARCHAR2 error message for the custom exception (declared in this package)
     pi_string    IN VARCHAR2 string built using the arguments that will replace the placeholders
                              in the error message and the correct separator between them (;)
  */
  -----------------------------------------------------------------------------------------
  -- Assumptions:
  /*
     We expect the caller to use this function when raising a custom exceptions with placeholders
     in the error message (%1, %2, etc.) and to use in the second argument the correct separator (;)
     and the correct number of arguments.
  */
  -----------------------------------------------------------------------------------------
  -- Call example:
  /*
  exception
    when exceptions.e_DDLRolbackFailed then
      RAISE_APPLICATION_ERROR(EXCEPTIONS.e_DDLRolbackFailed_code,
                              EXCEPTIONS.error_text(EXCEPTIONS.e_DDLRolbackFailed_msg,
                                                    l_UD_TRANSACTION_ID || ';' || l_UD_INDEX));
  */
  -----------------------------------------------------------------------------------------
  function error_text(pi_error_msg in varchar2, pi_string in varchar2)
    return varchar2;
  -- ========================================================

  -- *******************************    PUBLIC FUNCTIONS END       *******************************

  -- *******************************    PUBLIC CUSTOM ERRORS START    *******************************

  /* raised for any other errors occurred during executions of a sql code */
  e_RegularSQLError exception;
  /* error code for e_RegularSQLError */
  e_RegularSQLError_code CONSTANT INTEGER := -20001;
  /* error message for e_RegularSQLError */
  e_RegularSQLError_msg CONSTANT VARCHAR2(40 CHAR) := 'Error during execution script.';

  /* raised if the script was already applied */
  e_ScriptAppliedException exception;
  /* error code for e_ScriptAppliedException */
  e_ScriptAppliedException_code CONSTANT INTEGER := -20002;
  /* error message for e_ScriptAppliedException */
  e_ScriptAppliedException_msg CONSTANT VARCHAR2(4000 CHAR) := 'Script %1 was already applied on database %2.';

  /* raised if the ddl rollback was not executed */
  e_DDLRolbackNotExecuted exception;
  /* error code for e_DDLRolbackNotExecuted */
  e_DDLRolbackNotExecuted_code CONSTANT INTEGER := -20003;
  /* error message for e_DDLRolbackNotExecuted */
  e_DDLRolbackNotExecuted_msg CONSTANT VARCHAR2(60 CHAR) := 'DDL rollback was not executed. Please restore your schema.';

  /* raised if the ddl rollback was not executed */
  e_DDLRolbackFailed exception;
  /* error code for e_DDLRolbackFailed */
  e_DDLRolbackFailed_code CONSTANT INTEGER := -20004;
  /* error message for e_DDLRolbackFailed */
  e_DDLRolbackFailed_msg CONSTANT VARCHAR2(4000 CHAR) := 'DDL rollback for run id %1, transaction id %2, index %3 failed because of %4.';

  /* raised if an input parameter for a function/procedure is invalid */
  e_InvalidParam exception;
  /* error code for e_InvalidParam */
  e_InvalidParam_code CONSTANT INTEGER := -20005;
  /* error message for e_InvalidParam */
  e_InvalidParam_msg CONSTANT VARCHAR2(4000 CHAR) := 'Value %1 for parameter %2 is invalid.';

  /* raised if an input parameter for a function/procedure is null */
  e_NullParam exception;
  /* error code for e_NullParam */
  e_NullParam_code CONSTANT INTEGER := -20006;
  /* error message for e_NullParam */
  e_NullParam_msg CONSTANT VARCHAR2(4000 CHAR) := 'Parameter %1 cannot be null.';

  /* raised if two input parameter for a function/procedure are both not null */
  e_NotNullParams exception;
  /* error code for e_NotNullParams */
  e_NotNullParams_code CONSTANT INTEGER := -20007;
  /* error message for e_NotNullParams */
  e_NotNullParams_msg CONSTANT VARCHAR2(4000 CHAR) := 'Parameters %1 and %2 cannot be both not null.';

  /* raised if the ddl rollback was not executed */
  e_DDLRolbackFailedLog exception;
  /* error code for e_DDLRolbackFailedLog */
  e_DDLRolbackFailedLog_code CONSTANT INTEGER := -20008;
  /* error message for e_DDLRolbackFailedLog */
  e_DDLRolbackFailedLog_msg CONSTANT VARCHAR2(4000 CHAR) := 'DDL rollback for %1 at run id %2, transaction id %3, index %4 failed because of %5. The initial error was %6 at %7 at index %8';

  /* raised if the ddl execution crashed */
  e_DDLExecuteFailedLog exception;
  /* error code for e_DDLExecuteFailedLog */
  e_DDLExecuteFailedLog_code CONSTANT INTEGER := -20009;
  /* error message for e_DDLExecuteFailedLog */
  e_DDLExecuteFailedLog_msg CONSTANT VARCHAR2(4000 CHAR) := 'DDL execution for %1 at run id %2, transaction id %3, index %4 failed because of %5';

  /* raised if the ddl execution crashed */
  e_DDLLoggingFailedLog exception;
  /* error code for e_DDLLoggingFailedLog */
  e_DDLLoggingFailedLog_code CONSTANT INTEGER := -20010;
  /* error message for e_DDLLoggingFailedLog */
  e_DDLLoggingFailedLog_msg CONSTANT VARCHAR2(4000 CHAR) := 'DDL logging for %1 at run id %2, transaction id %3, index %4 failed because of %5';

  /* raised if the query has an execution time longer then a treshold */
  e_TerminateQuery exception;
  /* error code for e_TerminateQuery */
  e_TerminateQuery_code CONSTANT INTEGER := -20011;
  /* error message for e_TerminateQuery */
  e_TerminateQuery_msg CONSTANT VARCHAR2(100 CHAR) := 'The DBA high council refuses to allow this query to execute as it exceeds the project resources';

  /* raised if there is no data found in metadata tables*/
  e_NoMetadata exception;
  /* error code for e_TerminateQuery */
  e_NoMetadata_code CONSTANT INTEGER := -20012;
  /* error message for e_TerminateQuery */
  e_NoMetadata_msg CONSTANT VARCHAR2(40 CHAR) := 'No data found in the metadata tables';
-- *******************************    PUBLIC CUSTOM ERRORS END    *********************************

end commons_exceptions;
/
