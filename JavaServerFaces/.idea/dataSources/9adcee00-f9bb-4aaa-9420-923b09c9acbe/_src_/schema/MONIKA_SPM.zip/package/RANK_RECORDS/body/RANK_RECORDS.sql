CREATE PACKAGE BODY RANK_RECORDS IS

  PROCEDURE RUN_RANK_RECORDS(PIN_INPUT_FROM_CLAUSE IN VARCHAR2, -- TABLE IN WHICH THE FIELDS TO BE RANKED ARE (+ ENTITY TABLES)
                             PIN_OUTPUT_TABLE      IN VARCHAR2, -- OUTPUT TABLE FOR RAKING PROCESS (CONTAINS OUTPUT FIELDS, RANK FIELDS AND COUT FIELDS)
                             PIN_OUTPUT_FIELDS     IN TABLETYPE_DT_RR_COL_ALIAS_LIST, -- TABLE OF FIELDS AND ALIASES. ID 1 =  PRIMARY OUTPUT, ID 2 = FINAL OUTPUT.
                             PIN_WHERE_CLAUSE      IN VARCHAR2, -- WHERECLAUSE CONTAINING FLTERING FOR PRIMARY OUTPUT
                             PIN_RANK_OPERATION_ID IN NUMBER,
                             PIN_TABLE_ALIAS       IN VARCHAR2,
                             PIN_INPUT_TABLE_NAME  IN VARCHAR2,
                             POUT_RECORD_COUNT     OUT NUMBER ) IS-- TOTAL COUNT OF RECORDS INSERTED INTO THE RESULT TABLE
    -- OPERATION ID CONTAINING CALCULATIONS
    V_RANKED_FIELD         VARCHAR2(40 CHAR);
    V_GROUPING_COLUMNS     CLOB := '';
    V_INSERT_STMT          CLOB := '';
    V_OUTER_SELECT_STMT    CLOB := '';
    V_INNER_SELECT_STMT    CLOB := '';
    V_FINAL_STMT           CLOB := '';
    V_ALL_FIELDS           CLOB := '';
    V_OUTPUT_FIELDS_SELECT CLOB := '';
    V_OUTPUT_FIELDS_INSERT CLOB := '';
    V_DRIN_ID              NUMBER(10);
    V_DTOUT_ID             NUMBER(10);
    V_CARDINALITY_HINT     VARCHAR2(255);
    V_NO_HINT              NUMBER(1) := 0;
  BEGIN

  BEGIN
    SELECT MAX(DTI.DTIN_ID),
           MAX(DRT.DTRT_DTOUT_ID)
    INTO V_DRIN_ID, V_DTOUT_ID
    FROM DT_INPUTS DTI
    INNER JOIN DT_RESULT_TABLES DRT
      ON DTI.DTIN_DTOUT_ID = DRT.DTRT_DTOUT_ID
    INNER JOIN TABLES T
      ON T.TABLES_ID = DRT.DTRT_TABLES_ID
    WHERE DTI.DTIN_DTOUT_ID IS NOT NULL
     AND T.TABLES_PHYSICAL_NAME = PIN_INPUT_TABLE_NAME;
   EXCEPTION WHEN NO_DATA_FOUND THEN
     V_NO_HINT := 1;
   END;

   IF V_NO_HINT = 0 THEN
    DATA_TRANSFORMATION_PROCESSING.GET_INPUT_CARDINALITY_HINT( V_DRIN_ID,
                                                               V_DTOUT_ID,
                                                               PIN_INPUT_TABLE_NAME,
                                                               PIN_TABLE_ALIAS,
                                                               V_CARDINALITY_HINT);
   END IF;
    FOR C IN (SELECT COLUMN_NAME, -- GET COLUMNS AND COLUMN ALIASES
                     COLUMN_ALIAS,
                     DISPLAY_FINAL_OUTPUT,
                     RANK_OR_COUNT_FLD
                FROM TABLE(PIN_OUTPUT_FIELDS)
                where upper(COLUMN_NAME) not in ('ROW_IDENTIFIER', 'ROW_VERSION')) LOOP
      IF C.RANK_OR_COUNT_FLD = 0 THEN
        V_ALL_FIELDS := V_ALL_FIELDS || C.COLUMN_ALIAS || ',';
      END IF;
      IF C.DISPLAY_FINAL_OUTPUT = 1 THEN
        V_OUTPUT_FIELDS_SELECT := V_OUTPUT_FIELDS_SELECT || C.COLUMN_ALIAS || ',';
        V_OUTPUT_FIELDS_INSERT := V_OUTPUT_FIELDS_INSERT || C.COLUMN_NAME || ',';
      END IF;
      ALIAS_TABLE(upper(C.COLUMN_NAME)) := upper(C.COLUMN_ALIAS);
    END LOOP;

     V_OUTPUT_FIELDS_SELECT := V_OUTPUT_FIELDS_SELECT || PIN_OUTPUT_TABLE||'_ROW_IDENTIFIER_SEQ.NEXTVAL, 0';
     V_OUTPUT_FIELDS_INSERT := V_OUTPUT_FIELDS_INSERT || ' ROW_IDENTIFIER, ROW_VERSION ';

    V_ALL_FIELDS           := SUBSTR(V_ALL_FIELDS,
                                     1,
                                     LENGTH(V_ALL_FIELDS) - 1);

    --
    V_INSERT_STMT       := V_OUTPUT_FIELDS_INSERT;
    V_OUTER_SELECT_STMT := V_OUTPUT_FIELDS_SELECT;
    V_INNER_SELECT_STMT := V_ALL_FIELDS;

    FOR C IN (SELECT DTRRC_ID CALCULATION_ID, -- GET CALCULATION DETAILS
                     MAX(CASE
                           WHEN FLD.FLD_ID = DTRRC_RANK_FLD_ID THEN
                            FLD.FLD_COLUMN_NAME
                           ELSE
                            NULL
                         END) RANKED_FIELD,
                     MAX(CASE
                           WHEN FLD.FLD_ID = DTRRC_TBREAKER_FLD_ID THEN
                            FLD.FLD_COLUMN_NAME
                           ELSE
                            NULL
                         END) TIEBREAKER_FIELD,
                     MAX(CASE
                           WHEN FLD.FLD_ID = DTRRC_RANK_FLD_ID THEN
                            FLD.FLD_DATA_TYPE
                           ELSE
                            NULL
                         END) RANKED_FIELD_DATA_TYPE,
                     MAX(CASE
                           WHEN FLD.FLD_ID = DTRRC_TBREAKER_FLD_ID THEN
                            FLD.FLD_DATA_TYPE
                           ELSE
                            NULL
                         END) TIEBREAKER_FIELD_DATA_TYPE,
                     MAX(CASE
                           WHEN FLD.FLD_ID = DTRRC_RANK_RESULT_FLD_ID THEN
                            FLD.FLD_COLUMN_NAME
                           ELSE
                            NULL
                         END) RANK_RESULT_FLD,
                     MAX(CASE
                           WHEN FLD.FLD_ID = DTRRC_COUNT_FLD_ID THEN
                            FLD.FLD_COLUMN_NAME
                           ELSE
                            NULL
                         END) COUNT_FLD,
                     NVL(DTRRC_RANK_EMPTY_AS_ZERO, 0) EMPTY_AS_ZERO,
                     NVL(DTRRC_RANK_ORDER, 0) RANK_ORDER,
                     NVL(DTRRC_BREAK_TIES, 0) BREAK_TIES,
                     DTRRC_BREAK_WITH BREAK_WITH,
                     NVL(DTRRC_TBREAKER_EMPTY_AS_ZERO, 0) TBREAKER_EMPTY_AS_ZERO,
                     NVL(DTRRC_RANK_BY_GROUPS, 0) RANK_BY_GROUPS,
                     DTRRC_RANK_RESULT_FLD_ID RANK_RESULT_FLD_ID,
                     DTRRC_COUNT_FLD_ID COUNT_FLD_ID
                FROM DT_RR_CALCULATIONS DTRRC, FIELDS FLD
               WHERE DTRRC.DTRRC_DTRR_ID = PIN_RANK_OPERATION_ID
                 AND FLD.FLD_ID IN (DTRRC_RANK_FLD_ID,
                                    DTRRC_TBREAKER_FLD_ID,
                                    DTRRC_COUNT_FLD_ID,
                                    DTRRC_RANK_RESULT_FLD_ID)
               GROUP BY DTRRC_ID,
                        DTRRC_RANK_EMPTY_AS_ZERO,
                        DTRRC_RANK_ORDER,
                        DTRRC_BREAK_TIES,
                        DTRRC_BREAK_WITH,
                        DTRRC_TBREAKER_EMPTY_AS_ZERO,
                        DTRRC_RANK_BY_GROUPS,
                        DTRRC_RANK_RESULT_FLD_ID,
                        DTRRC_COUNT_FLD_ID) LOOP

      V_GROUPING_COLUMNS := '';
      IF C.RANK_BY_GROUPS = 1 THEN
        -- IF RANK BY GROUP OPTION IS SELECTED THEN GET GROUPING FOR CALCULATION
        FOR D IN (SELECT COL_NAMES.COL_NAME COLUMN_NAME
                    FROM DT_RR_GROUPINGS DTTG,

                         (SELECT FLD_ID ID, FLD_COLUMN_NAME COL_NAME
                            FROM FIELDS FLD
                          UNION ALL
                          SELECT ENTITY_ID ID,
                                 'E' || TO_CHAR(ENTITY_ID) COL_NAME
                            FROM ENTITIES) COL_NAMES
                   WHERE DTTG.DTRRG_DTRRC_ID = C.CALCULATION_ID
                     AND COL_NAMES.ID IN (DTRRG_FLD_ID, DTRRG_ENTITY_ID)
                   ORDER BY DTRRG_ORDER) LOOP

          V_GROUPING_COLUMNS := V_GROUPING_COLUMNS ||
                                ALIAS_TABLE(upper(D.COLUMN_NAME)) || ',';
        END LOOP;
        V_GROUPING_COLUMNS := substr(V_GROUPING_COLUMNS,
                                     1,
                                     length(V_GROUPING_COLUMNS) - 1);
      END IF;

      -- BUILD QUERY
      IF V_INNER_SELECT_STMT IS NOT NULL THEN
        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ',';
      END IF;

      IF C.EMPTY_AS_ZERO = 1 AND C.RANKED_FIELD_DATA_TYPE = 6 THEN
        V_RANKED_FIELD := 'NVL(' || ALIAS_TABLE(upper(C.RANKED_FIELD)) ||
                          ',0)';
      ELSE
        V_RANKED_FIELD := ALIAS_TABLE(upper(C.RANKED_FIELD));
      END IF;

      IF C.EMPTY_AS_ZERO = 1 AND C.RANKED_FIELD_DATA_TYPE = 6 THEN
        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ' RANK() OVER( ';
      ELSE
        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || 'CASE WHEN ' ||
                               ALIAS_TABLE(upper(C.RANKED_FIELD)) ||
                               ' IS NOT NULL THEN RANK() OVER( ';
      END IF;
      IF C.RANK_BY_GROUPS = 1 AND V_GROUPING_COLUMNS IS NOT NULL THEN
        -- GROUPING CONTIDION
        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || 'PARTITION BY ' ||
                               V_GROUPING_COLUMNS;
      END IF;

      V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || -- FIELD TO RANK
                             ' ORDER BY ' || V_RANKED_FIELD;

      V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || CASE -- RANK ORDER
                               WHEN C.RANK_ORDER = 0 THEN
                                ' ASC NULLS LAST'
                               ELSE
                                ' DESC NULLS LAST'
                             END;

      IF C.BREAK_TIES = 1 AND C.TIEBREAKER_FIELD IS NOT NULL THEN
        --TIEBREAKER
        IF C.TBREAKER_EMPTY_AS_ZERO = 1 AND
           C.TIEBREAKER_FIELD_DATA_TYPE = 6 THEN
          V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ', NVL(' ||
                                 ALIAS_TABLE(upper(C.TIEBREAKER_FIELD)) ||
                                 ',0)';
        ELSE
          V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ', ' ||
                                 ALIAS_TABLE(upper(C.TIEBREAKER_FIELD));
        END IF;

        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || CASE -- BREAK ORDER
                                 WHEN C.BREAK_WITH = 0 THEN
                                  ' ASC NULLS LAST'
                                 ELSE
                                  ' DESC NULLS LAST'
                               END;

      END IF;
      V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ')';

      IF C.EMPTY_AS_ZERO = 0 OR C.RANKED_FIELD_DATA_TYPE <> 6 THEN
        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ' END ' ||
                               ALIAS_TABLE(upper(C.RANK_RESULT_FLD));
      ELSE
        V_INNER_SELECT_STMT := V_INNER_SELECT_STMT ||
                               ALIAS_TABLE(upper(C.RANK_RESULT_FLD));
      END IF;

      IF C.COUNT_FLD IS NOT NULL THEN
        IF C.EMPTY_AS_ZERO = 1 AND C.RANKED_FIELD_DATA_TYPE = 6 THEN
          V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || -- RECORD COUNT
                                 ',COUNT(' || V_RANKED_FIELD;
          IF V_GROUPING_COLUMNS IS NOT NULL THEN
            V_INNER_SELECT_STMT := V_INNER_SELECT_STMT ||
                                   ') OVER(PARTITION BY ' ||
                                   V_GROUPING_COLUMNS || ') ' ||
                                   ALIAS_TABLE(UPPER(C.COUNT_FLD));
          ELSE
            V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ') OVER() ' ||
                                   ALIAS_TABLE(UPPER(C.COUNT_FLD));
          END IF;

        ELSE
          V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ',CASE WHEN ' ||
                                 ALIAS_TABLE(UPPER(C.RANKED_FIELD)) ||
                                 ' IS NOT NULL THEN COUNT(' ||
                                 ALIAS_TABLE(UPPER(C.RANKED_FIELD));

          IF V_GROUPING_COLUMNS IS NOT NULL THEN
            V_INNER_SELECT_STMT := V_INNER_SELECT_STMT ||
                                   ') OVER(PARTITION BY ' ||
                                   V_GROUPING_COLUMNS || ') END ' ||
                                   ALIAS_TABLE(UPPER(C.COUNT_FLD));
          ELSE
            V_INNER_SELECT_STMT := V_INNER_SELECT_STMT || ') OVER() END ' ||
                                   ALIAS_TABLE(UPPER(C.COUNT_FLD));
          END IF;

        END IF;
      END IF;
    END LOOP;

    V_FINAL_STMT := COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'RANK_RECORDS', pi_hint_id=> 'RR_INS1', pi_proc_id => null)||
                   ' INSERT '
                   || COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'RANK_RECORDS', pi_hint_id=> 'RR_INS1', pi_proc_id => null)
                     || ' INTO '|| PIN_OUTPUT_TABLE || '(' || V_INSERT_STMT || ')'||
                    COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'RANK_RECORDS', pi_hint_id=> 'RR_SEL1', pi_proc_id => null)||
                    ' SELECT ' ||
                    COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'RANK_RECORDS', pi_hint_id=> 'RR_SEL1', pi_proc_id => null)
                     || ' '|| V_OUTER_SELECT_STMT || ' FROM (' ||
                    COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'RANK_RECORDS', pi_hint_id=> 'RR_SEL2', pi_proc_id => null)||
                    ' SELECT ' ||
                    COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'RANK_RECORDS', pi_hint_id=> 'RR_SEL2', pi_proc_id => null, pi_other_hints => V_CARDINALITY_HINT)
                    || ' '||V_INNER_SELECT_STMT || ' FROM (' ||
                    PIN_INPUT_FROM_CLAUSE || '))  PO ';

    V_FINAL_STMT := V_FINAL_STMT || PIN_WHERE_CLAUSE;

    COMMONS_PROCESSING.EXEC_START_PROC_TRANSACTION(    pin_run_id         => NULL
                                                      ,pin_definition_id  => PIN_RANK_OPERATION_ID
                                                    ) ;

    EXECUTE IMMEDIATE V_FINAL_STMT;

    POUT_RECORD_COUNT := SQL%ROWCOUNT;

    COMMONS_PROCESSING.EXEC_END_PROC_TRANSACTION(    pin_run_id         => NULL
                                                      ,pin_definition_id  => PIN_RANK_OPERATION_ID
                                                    ) ;

  END RUN_RANK_RECORDS;
END RANK_RECORDS;
/
