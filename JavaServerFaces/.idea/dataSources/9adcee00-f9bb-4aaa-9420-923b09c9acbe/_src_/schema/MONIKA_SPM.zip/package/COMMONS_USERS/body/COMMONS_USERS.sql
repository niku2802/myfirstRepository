CREATE package body commons_users is
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  users-commons
  -- Requester    :  Irimiciuc, Laura
  -- Author    :  Lazar, Lucian
  -- Reviewer    :  Cozac, Tudor
  -- Review date    :  20120118
  -- Description    :  Used for user management
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC PROCEDURES START       *******************************

  function get_user_table_id return number as
    v_user_table_id number;
  begin
    select tables_id into v_user_table_id from tables where tables_name = 'User Table';
    return v_user_table_id;
  end get_user_table_id;

  procedure validation_clauses_old(pi_source_table    in varchar2,
                               pi_load_mode       in number,
                               pi_append_roles    in number,
                               pi_separator       in varchar2,
                               pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                               po_entities_clause out clob,
                               po_roles_clause    out clob,
                               po_invalid_roles   out clob,
                               po_40_roles_clause out clob) is
    l_number_of_entities      integer := 0;
    l_check_entity_values_sql clob;
    l_number_of_user_entities integer := 0;
    l_user_entity_values_sql  clob;
    l_roles_clause            clob;
    l_invalid_roles           clob;
    l_40_roles_clause         clob;
    l_nls_sort                varchar2(100);
  begin
    -- check parameters
    if pi_source_table is null then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, '<null>' || ';' || 'pi_source_table'));
    end if;
    if pi_load_mode not in (1,2,3,4) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_load_mode || ';' || 'pi_load_mode'));
    end if;
    if pi_append_roles not in (0,1) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_append_roles || ';' || 'pi_append_roles'));
    end if;
    if pi_separator not in (',',';') then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_separator || ';' || 'pi_separator'));
    end if;
    -- check the values on the mapped entity fields
    if pi_columns is not null then
      for i in (select COLUMN_NAME from table(pi_columns) where IS_ENTITY = 1 and IS_MAPPED = 1) loop
        l_number_of_entities := l_number_of_entities + 1;
        l_check_entity_values_sql := l_check_entity_values_sql || 'decode(' || i.COLUMN_NAME || ',null,0,1)+';
      end loop;
    end if;
    if l_number_of_entities >= 1 then
      l_check_entity_values_sql := substr(l_check_entity_values_sql, 1, length(l_check_entity_values_sql) - 1);
    end if;
    -- check the values on the unmapped entity fields; this check does not apply on replace mode
    if pi_load_mode != 1 and pi_columns is not null then
      l_user_entity_values_sql := '(select ';
      for i in (select COLUMN_NAME from table(pi_columns) where IS_ENTITY = 1 and IS_MAPPED = 0) loop
        l_number_of_user_entities := l_number_of_user_entities + 1;
        l_user_entity_values_sql := l_user_entity_values_sql || 'decode(nvl(max(' || i.COLUMN_NAME || '),0),0,0,1)+';
      end loop;
    end if;
    -- build validation clause for entities
    if l_number_of_user_entities >= 1 then
      l_user_entity_values_sql := substr(l_user_entity_values_sql, 1, length(l_user_entity_values_sql) - 1);
      l_user_entity_values_sql := l_user_entity_values_sql || ' from users where upper(login_id) = upper(' || pi_source_table || '.login_id))';
      if l_check_entity_values_sql is null then
        l_check_entity_values_sql := l_user_entity_values_sql;
      else
        l_check_entity_values_sql := l_check_entity_values_sql || '+' || l_user_entity_values_sql;
      end if;
    end if;
    if l_number_of_entities = 0 and l_number_of_user_entities = 0 then
      l_check_entity_values_sql := '1';
    end if;
    if l_check_entity_values_sql is not null then
      po_entities_clause := 'decode(' || l_check_entity_values_sql || ',null,1,0,1,1,1,0)';
    end if;
    -- build validation clauses for roles
      if pi_separator is not null then
      -- get nlssort
      l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
      -- check if all the roles are in the system
      l_roles_clause := 'case
                           when upper(role) in
                                (select upper(role)
                                   from (select role,
                                                regexp_substr(role, ''[^' || nvl(pi_separator,',') || ']+'', 1, level) elm
                                           from ' || pi_source_table || '
                                         connect by regexp_substr(role, ''[^' || nvl(pi_separator,',') || ']+'', 1, level) is not null
                                         )
                                  where upper(trim(elm)) not in (select upper(rol_name)
                                                                   from roles
                                                                  where upper(trim(elm)) = upper(rol_name)
                                                                 )
                                    and trim(elm) is not null
                                 )
                           then 0
                           else 1
                         end';
      -- log the invalid roles
      l_invalid_roles := '(select inl_roles
                             from ' || pi_source_table || ' t2
                             left join (select login_id,
                                              listagg(role_name, '','') within group(order by NLSSORT(role_name,''nls_sort='''''||l_nls_sort||''''''')) inl_roles
                                         from (select distinct login_id, elm role_name
                                                 from (select login_id,
                                                              role,
                                                              regexp_substr(role, ''[^' || nvl(pi_separator,',') || ']+'', 1, level) elm
                                                         from ' || pi_source_table || '
                                                       connect by regexp_substr(role, ''[^' || nvl(pi_separator,',') || ']+'', 1, level) is not null
                                                       )
                                                where not exists (select 1
                                                                    from roles
                                                                   where upper(ROL_NAME) = upper(trim(elm))
                                                                  )
                                                  and elm is not null
                                               )
                                        group by login_id
                                        ) x
                               on upper(t2.login_id) = upper(x.login_id)
                            where upper(t2.login_id) = upper(' || pi_source_table || '.login_id))';
      -- check that a user doesn't get more then 40 roles
      l_40_roles_clause := 'case
                              when (' || pi_load_mode || ' in (1, 2) or
                                   (' || pi_load_mode || ' in (3, 4) and ' || pi_append_roles || ' = 0)) and
                                   regexp_count(role, '','') + 1 > 40 then
                               0
                              when ' || pi_append_roles || ' = 1 and
                                   upper(login_id) in
                                   (select upper(login_id)
                                      from (select login_id, rol_name
                                              from users
                                              join user_roles
                                                on user_id = ur_user_id
                                              join roles
                                                on ur_role_id = rol_id
                                             where upper(login_id) in (select upper(login_id) from ' || pi_source_table || ')
                                            union
                                            select distinct login_id, elm role_name
                                              from (select login_id,
                                                           role,
                                                           regexp_substr(role, ''[^,]+'', 1, level) elm
                                                      from ' || pi_source_table || '
                                                    connect by regexp_substr(role, ''[^,]+'', 1, level) is not null)
                                             where elm is not null)
                                     group by login_id
                                    having count(rol_name) > 40) then
                               0
                              else
                               1
                            end';
    else
      l_roles_clause := '1';
      l_40_roles_clause := '1';
    end if;
    -- return clauses
    po_roles_clause := l_roles_clause;
    po_invalid_roles := l_invalid_roles;
    po_40_roles_clause := l_40_roles_clause;
  end validation_clauses_old;

  procedure validation_clauses(pi_source_table    in varchar2,
                               pi_load_mode       in number,
                               pi_append_roles    in number,
                               pi_separator       in varchar2,
                               pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                               po_entities_clause out clob,
                               po_roles_clause    out clob,
                               po_invalid_roles   out clob,
                               po_40_roles_clause out clob) is
    l_number_of_entities      integer := 0;
    l_check_entity_values_sql clob;
    l_number_of_user_entities integer := 0;
    l_user_entity_values_sql  clob;
    l_roles_clause            clob;
    l_invalid_roles           clob;
    l_40_roles_clause         clob;
    l_nls_sort                varchar2(100);

    l_temp_role_tab dbms_utility.uncl_array;
    l_tablen number;
    l_source_table_clause varchar2(250 char);
    l_source_table_cursor sys_refcursor;
    l_login_id varchar2(250 char);
    l_role_name varchar2(1300 char);
    l_max_role_length number(30);
    l_max_role_clause varchar2(1300 char);

    l_has_double_quotes_clause varchar2(250 char);
    l_has_double_quotes number(1);

    l_has_single_quotes_clause varchar2(250 char);
    l_has_single_quotes number(1);

    l_has_comma_first_clause varchar2(250 char);
    l_has_comma_first number(1);

	begin
    -- check parameters
    if pi_source_table is null then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, '<null>' || ';' || 'pi_source_table'));
    end if;
    if pi_load_mode not in (1,2,3,4) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_load_mode || ';' || 'pi_load_mode'));
    end if;
    if pi_append_roles not in (0,1) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_append_roles || ';' || 'pi_append_roles'));
    end if;
    if pi_separator not in (',',';') then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_separator || ';' || 'pi_separator'));
    end if;
    -- check the values on the mapped entity fields
    if pi_columns is not null then
      for i in (select COLUMN_NAME from table(pi_columns) where IS_ENTITY = 1 and IS_MAPPED = 1) loop
        l_number_of_entities := l_number_of_entities + 1;
        l_check_entity_values_sql := l_check_entity_values_sql || 'decode(' || i.COLUMN_NAME || ',null,0,1)+';
      end loop;
    end if;
    if l_number_of_entities >= 1 then
      l_check_entity_values_sql := substr(l_check_entity_values_sql, 1, length(l_check_entity_values_sql) - 1);
    end if;
    -- check the values on the unmapped entity fields; this check does not apply on replace mode
    if pi_load_mode != 1 and pi_columns is not null then
      l_user_entity_values_sql := '(select ';
      for i in (select COLUMN_NAME from table(pi_columns) where IS_ENTITY = 1 and IS_MAPPED = 0) loop
        l_number_of_user_entities := l_number_of_user_entities + 1;
        l_user_entity_values_sql := l_user_entity_values_sql || 'decode(nvl(max(' || i.COLUMN_NAME || '),0),0,0,1)+';
      end loop;
    end if;
    -- build validation clause for entities
    if l_number_of_user_entities >= 1 then
      l_user_entity_values_sql := substr(l_user_entity_values_sql, 1, length(l_user_entity_values_sql) - 1);
      l_user_entity_values_sql := l_user_entity_values_sql || ' from users where upper(login_id) = upper(' || pi_source_table || '.login_id))';
      if l_check_entity_values_sql is null then
        l_check_entity_values_sql := l_user_entity_values_sql;
      else
        l_check_entity_values_sql := l_check_entity_values_sql || '+' || l_user_entity_values_sql;
      end if;
    end if;
    if l_number_of_entities = 0 and l_number_of_user_entities = 0 then
      l_check_entity_values_sql := '1';
    end if;
    if l_check_entity_values_sql is not null then
      po_entities_clause := 'decode(' || l_check_entity_values_sql || ',null,1,0,1,1,1,0)';
    end if;
    -- build validation clauses for roles
    if pi_separator is not null then
      for c in (select 1 from user_tables where table_name = 'ALL_USER_ROLES') loop
        execute immediate 'truncate table ALL_USER_ROLES';
      end loop;

      for c in (select 1 from user_tables where table_name = 'MISSING_ROLES_VALIDATION') loop
        execute immediate 'truncate table MISSING_ROLES_VALIDATION';
      end loop;

      for c in (select 1 from user_tables where table_name = 'TOO_MANY_ROLES_VALIDATION') loop
        execute immediate 'truncate table TOO_MANY_ROLES_VALIDATION';
      end loop;

      -- get max role length
      l_max_role_clause := 'select max(length(trim(elm)))
                  from (select role src from ' ||
                           pi_source_table || '),
                  xmltable(''r/c'' passing
                    xmltype(''<r><c>'' || replace(src, ''' ||
                           nvl(pi_separator, ',') ||
                           ''', ''</c><c>'') ||
                            ''</c></r>'') columns elm varchar2(1300) path ''.'')';


      l_has_double_quotes_clause := 'select max(decode(instr(role,''"''),0,0,1)) from '|| pi_source_table;
      l_has_single_quotes_clause := 'select max(decode(instr(role,''''''''),0,0,1)) from '|| pi_source_table;
	  l_has_comma_first_clause   := 'select max(decode(substr(role,1,1),'','',1,0)) from '|| pi_source_table;

      execute immediate l_max_role_clause into l_max_role_length;
      execute immediate l_has_double_quotes_clause into l_has_double_quotes;
      execute immediate l_has_single_quotes_clause into l_has_single_quotes;
	  execute immediate l_has_comma_first_clause into l_has_comma_first;

      -- check if separator is ',' and there is no role with length > 30 in order to use comma_to_table utility
      if pi_separator = ',' and l_max_role_length < 30 and l_has_double_quotes = 0 and l_has_single_quotes = 0 and l_has_comma_first = 0 then
        l_source_table_clause := 'select login_id, ''"'' || replace(role, '','',''","'') || ''"'' from ' ||
                                 pi_source_table;
        open l_source_table_cursor for l_source_table_clause;
        loop
          FETCH l_source_table_cursor
            INTO l_login_id, l_role_name;
          EXIT WHEN l_source_table_cursor%NOTFOUND;
          dbms_utility.comma_to_table(l_role_name, l_tablen, l_temp_role_tab);
          for i in 1 .. l_temp_role_tab.count loop
            execute immediate 'insert into ALL_USER_ROLES(role_name, login_id) values (''' ||
                              trim(trim(both '"' from l_temp_role_tab(i))) || ''', ''' || REPLACE(l_login_id,'''','''''') ||
                              ''')';
          end loop;
        end loop;
        close l_source_table_cursor;

        execute immediate 'insert into MISSING_ROLES_VALIDATION
                    select src.role, tmp.login_id, tmp.role_name role
                    from ALL_USER_ROLES tmp inner join ' ||
                          pi_source_table ||
                          ' src
                    on tmp.login_id = src.login_id
                    where upper(tmp.role_name) not in (select upper(rol_name) from roles)';

        execute immediate 'insert into TOO_MANY_ROLES_VALIDATION
                             select upper(login_id) login_id
                               from (select login_id, rol_name
                                       from users
                                       join user_roles
                                         on user_id = ur_user_id
                                       join roles
                                         on ur_role_id = rol_id
                                      where upper(login_id) in (select upper(login_id) from ' ||
                          pi_source_table || ')
                                     union
                                     select distinct login_id, role_name
                                       from ALL_USER_ROLES where role_name is not null)
                              group by login_id
                             having count(rol_name) > 40';

      -- else use xml to extract roles from source table
      else
        execute immediate 'insert into MISSING_ROLES_VALIDATION
                             select upper(role) role, login_id, elm role_name
                                 from (select login_id, role, role src from ' ||
                          pi_source_table || '),
                                 xmltable(''r/c'' passing
                                          xmltype(''<r><c>'' || replace(src, ''' ||
                          nvl(pi_separator, ',') ||
                          ''', ''</c><c>'') ||
                                                  ''</c></r>'') columns elm varchar2(1300) path ''.'')
                              where upper(trim(elm)) not in (select upper(rol_name)
                                                               from roles
                                                              where upper(trim(elm)) = upper(rol_name))
                              and elm is not null';

        execute immediate 'insert into TOO_MANY_ROLES_VALIDATION
                             select upper(login_id) login_id
                               from (select login_id, rol_name
                                       from users
                                       join user_roles
                                         on user_id = ur_user_id
                                       join roles
                                         on ur_role_id = rol_id
                                      where upper(login_id) in (select upper(login_id) from ' ||
                          pi_source_table || ')
                                     union
                                     select distinct login_id, elm role_name
                                       from (select login_id,
                                                    role,
                                                    role src from ' ||
                          pi_source_table || '),
                                                    xmltable(''r/c'' passing
                                          xmltype(''<r><c>'' || replace(src, ''' ||
                          nvl(pi_separator, ',') ||
                          ''', ''</c><c>'') ||
                                                  ''</c></r>'') columns elm varchar2(1300) path ''.'')
                                      where elm is not null)
                              group by login_id
                             having count(rol_name) > 40';

      end if;
      -- get nlssort
      l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
      -- check if all the roles are in the system
      l_roles_clause := 'case
                           when upper(role) in
                                (select upper(role) from MISSING_ROLES_VALIDATION)
                           then 0
                           else 1
                         end';


      -- log the invalid roles
      l_invalid_roles := '(select inl_roles
                             from ' || pi_source_table || ' t2
                             left join (select login_id,
                                              listagg(role_name, '','') within group(order by NLSSORT(role_name,''nls_sort='''''||l_nls_sort||''''''')) inl_roles
                                         from (select distinct login_id, trim(role_name) role_name from MISSING_ROLES_VALIDATION)
                                        group by login_id
                                        ) x
                               on upper(t2.login_id) = upper(x.login_id)
                            where upper(t2.login_id) = upper(' || pi_source_table || '.login_id))';

       -- check that a user doesn't get more then 40 roles
      l_40_roles_clause := 'case
                              when (' || pi_load_mode || ' in (1, 2) or
                                   (' || pi_load_mode || ' in (3, 4) and ' || pi_append_roles || ' = 0)) and
                                   regexp_count(role, '','') + 1 > 40 then
                               0
                              when ' || pi_append_roles || ' = 1 and
                                   upper(login_id) in
                                   (select login_id from TOO_MANY_ROLES_VALIDATION) then
                               0
                              else
                               1
                            end';
    else
      l_roles_clause := '1';
      l_40_roles_clause := '1';
    end if;
    -- return clauses
    po_roles_clause := l_roles_clause;
    po_invalid_roles := l_invalid_roles;
    po_40_roles_clause := l_40_roles_clause;
  end validation_clauses;

  procedure validate_users(pi_source_table    in varchar2,
                           pi_load_mode       in number,
                           pi_append_roles    in number,
                           pi_separator       in varchar2,
                           pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                           po_validations     out sys_refcursor) is
    l_entities_clause    clob;
    l_roles_clause       clob;
    l_invalid_roles      clob;
    l_40_roles_clause    clob;
    l_validations_sql    clob;
  begin
    -- check parameters
    if pi_source_table is null then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, '<null>' || ';' || 'pi_source_table'));
    end if;
    if pi_load_mode not in (1,2,3,4) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_load_mode || ';' || 'pi_load_mode'));
    end if;
    if pi_append_roles not in (0,1) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_append_roles || ';' || 'pi_append_roles'));
    end if;
    if pi_separator not in (',',';') then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_separator || ';' || 'pi_separator'));
    end if;
    -- get validation clauses
    validation_clauses(pi_source_table, pi_load_mode, pi_append_roles, pi_separator, pi_columns, l_entities_clause, l_roles_clause, l_invalid_roles, l_40_roles_clause);
    -- build validation sql
    l_validations_sql := 'select login_id,
                                 ' || l_entities_clause || ' entities_validation,
                                 ' || l_roles_clause || ' roles_validation,
                                 ' || l_invalid_roles || ' invalid_roles,
                                 ' || l_40_roles_clause || ' forty_roles_validation
                            from ' || pi_source_table ||
                         ' where ' || l_entities_clause || ' = 0 or ' || l_roles_clause || ' = 0 or ' || l_40_roles_clause || ' = 0';
    -- execute validation sql
    open po_validations for l_validations_sql;
  end validate_users;

  procedure load_users(pi_source_table    in varchar2,
                       pi_load_mode       in number,
                       pi_append_roles    in number,
                       pi_separator       in varchar2,
                       pi_mapped_roles    in number,
                       pi_pam_server      in number,
                       pi_columns         in TABLETYPE_COLUMN_MAPPED_ENTITY,
                       po_counts_cursor   out sys_refcursor,
                       po_emails_cursor   out sys_refcursor) is
    l_cols_list             varchar2(32767) := 'ROW_IDENTIFIER,LOGIN_ID';
    l_cols_insert_list      varchar2(32767) := 'USERS_ROW_IDENTIFIER_SEQ.NEXTVAL,t.LOGIN_ID';
    l_cols_update_list      varchar2(32767) := 'ROW_IDENTIFIER = USERS_ROW_IDENTIFIER_SEQ.NEXTVAL';
    l_null_cols_list        varchar2(32767);
    l_null_cols_insert_list varchar2(32767);
    l_null_cols_update_list varchar2(32767);
    l_merge_users           varchar2(32767);
    l_merge_users_insert    varchar2(32767);
    l_merge_users_update    varchar2(32767);
    l_delete_user_roles     varchar2(32767);
    l_insert_user_roles     varchar2(32767);
    l_append_user_roles     varchar2(32767);
    l_initial_rows          integer;
    l_changed_rows          integer;
    l_final_rows            integer;
    l_inserted_rows         integer;
    l_updated_rows          integer;
    l_emails_sql            varchar2(32767);
    l_merge_users_recreate  varchar2(32767);
    l_delete_roles          varchar2(32767);
    l_insert_roles          varchar2(32767);
    l_nls_sort              varchar2(100);
    l_delete_dependencies   varchar2(32767);
    l_insert_dependencies   varchar2(32767);
    l_user_table_id         number(10);

    l_temp_role_tab dbms_utility.uncl_array;
    l_tablen number;
    l_source_table_clause varchar2(250 char);
    l_source_table_cursor sys_refcursor;
    l_login_id varchar2(250 char);
    l_role_name varchar2(1300 char);
    l_max_role_length number(30);
    l_max_role_clause varchar2(1300 char);

    l_has_double_quotes_clause varchar2(250 char);
    l_has_double_quotes number(1);

    l_has_single_quotes_clause varchar2(250 char);
    l_has_single_quotes number(1);

    l_has_comma_first_clause varchar2(250 char);
    l_has_comma_first number(1);

  begin
    -- check parameters
    if pi_source_table is null then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, '<null>' || ';' || 'pi_source_table'));
    end if;
    if pi_load_mode not in (1,2,3,4) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_load_mode || ';' || 'pi_load_mode'));
    end if;
    if pi_append_roles not in (0,1) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_append_roles || ';' || 'pi_append_roles'));
    end if;
    if pi_separator not in (',',';') then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_separator || ';' || 'pi_separator'));
    end if;
    if pi_mapped_roles not in (0,1) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_mapped_roles || ';' || 'pi_mapped_roles'));
    end if;
    if pi_pam_server not in (1,2) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_pam_server || ';' || 'pi_pam_server'));
    end if;
    -- get nlssort
    l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
    -- get users table id
    l_user_table_id := get_user_table_id;
    -- for replace, delete existing users; this will delete them from USER_ROLES and USER_CREDENTIALS as well
    if pi_load_mode = 1 then
      execute immediate 'delete DEPENDENCY_METADATA
                          where DM_REFFERED_OBJECT_ID not in (select UR_ROLE_ID
                                                                from USER_ROLES
                                                               where UR_USER_ID in(select u.USER_ID
                                                                                     from (select LOGIN_ID
                                                                                             from ' || pi_source_table ||
                                                                                           ') s
                                                                                      join USERS u
                                                                                        on upper(s.LOGIN_ID) = upper(u.LOGIN_ID)
                                                                                    )
                                                              )
                            and DM_REFFERING_OBJECT_ID = ' || l_user_table_id || '
                            and DM_REFFERING_OBJECT_TYPE = 2
                            and DM_SUBGROUP_KEY = ''USER_ROLES''';
      execute immediate 'delete from USERS where upper(LOGIN_ID) not in (select upper(login_id) from ' || pi_source_table || ')';
      execute immediate 'delete from USER_CREDENTIALS where upper(UC_LOGIN_ID) in (select upper(login_id) from ' || pi_source_table || ')';
    end if;
    -- get the mapped fields
    for i in (select COLUMN_NAME from table(pi_columns) where IS_MAPPED = 1 and COLUMN_NAME != 'LOGIN_ID') loop
      l_cols_list := l_cols_list || ',' || i.COLUMN_NAME;
      l_cols_insert_list := l_cols_insert_list || ',t.' || i.COLUMN_NAME;
      l_cols_update_list := l_cols_update_list || ',' || i.COLUMN_NAME || '=t.' || i.COLUMN_NAME;
    end loop;
    -- get the unmapped fields
    for i in (select COLUMN_NAME from table(pi_columns) where IS_MAPPED = 0 and COLUMN_NAME != 'LOGIN_ID') loop
      l_null_cols_list := l_null_cols_list || ',' || i.COLUMN_NAME;
      l_null_cols_insert_list := l_null_cols_insert_list || ',t.' || i.COLUMN_NAME;
      l_null_cols_update_list := l_null_cols_update_list || ',' || i.COLUMN_NAME || '=t.' || i.COLUMN_NAME;
    end loop;
    -- at update the unmapped fields must retain their values, at replace and append they must be set to null
    if pi_load_mode in (1,2,4) then
      l_cols_list := l_cols_list || l_null_cols_list;
      l_cols_insert_list := l_cols_insert_list || l_null_cols_insert_list;
    end if;
    if pi_load_mode = 1 then
      l_cols_update_list := l_cols_update_list || l_null_cols_update_list;
    end if;
    -- build insert/update clause for the USERS table
    -- preserve USER_ID for existing users and set new id for new records (trigger), ENABLED default 1, HAS_ACCOUNT 0 for internal PAM and null for external PAM
    l_merge_users := 'merge into USERS
                      using (select ' || l_cols_list || ' from ' || pi_source_table ||') t
                      on (upper(t.LOGIN_ID) = upper(USERS.LOGIN_ID))';
    l_merge_users_insert := ' when not matched then
                               insert (' || l_cols_list || ',ROW_VERSION,HAS_ACCOUNT,LOGGED_IN)
                              values (' || l_cols_insert_list || ',0,decode(' || pi_pam_server || ',1,0,2,0),0)'; -- temp fix, when TABLES supports null use null instead of 0 for 2
    l_merge_users_update := ' when matched then
                               update set ' || l_cols_update_list || ',ROW_VERSION = ROW_VERSION + 1';
    l_merge_users_recreate := ',HAS_ACCOUNT = 0, LOGGED_IN = 0';
    -- execute insert/update on USERS return the number of inserted/updated records
    if pi_load_mode = 2 then
      -- if the load mode is APPEND then insert the new users
      execute immediate l_merge_users || l_merge_users_insert;
      l_inserted_rows := sql%rowcount;
    elsif pi_load_mode = 3 then
      -- if the load mode is UPDATE_EXISTING_DATA then update the existing users
      execute immediate l_merge_users || l_merge_users_update;
      l_updated_rows := sql%rowcount;
    elsif pi_load_mode in (1,4) then
      -- if the load mode is REPLACE or UPDATE_EXISTING_DATA_AND_APPEND_NEW_DATA then update the existing users and insert the new users
      select nvl(max(rownum),0) into l_initial_rows from users;
      if pi_load_mode = 1 then
        execute immediate l_merge_users || l_merge_users_insert || l_merge_users_update || l_merge_users_recreate;
      elsif pi_load_mode = 4 then
        execute immediate l_merge_users || l_merge_users_insert || l_merge_users_update;
      end if;
      l_changed_rows := sql%rowcount;
      select nvl(max(rownum),0) into l_final_rows from users;
      l_inserted_rows := l_final_rows - l_initial_rows;
      l_updated_rows := l_changed_rows - l_inserted_rows;
    end if;
    -- delete/insert the roles if the roles column is mapped
    if pi_mapped_roles = 1 then
      -- delete the existing roles if the roles must be replaced
      -- delete dependencies too
      if pi_load_mode in (1,2) or (pi_load_mode in (3,4) and pi_append_roles = 0) then
        l_delete_dependencies := 'delete DEPENDENCY_METADATA
                                   where DM_REFFERED_OBJECT_ID in (select UR_ROLE_ID
                                                                     from USER_ROLES
                                                                    where UR_USER_ID in(select u.USER_ID
                                                                                          from (select LOGIN_ID
                                                                                                  from ' || pi_source_table ||
                                                                                                ') s
                                                                                           join USERS u
                                                                                             on upper(s.LOGIN_ID) = upper(u.LOGIN_ID)
                                                                                         )
                                                                   )
                                     and DM_REFFERING_OBJECT_ID = ' || l_user_table_id || '
                                     and DM_REFFERING_OBJECT_TYPE = 2
                                     and DM_SUBGROUP_KEY = ''USER_ROLES''';
        l_delete_user_roles := 'delete from USER_ROLES where UR_USER_ID in
                                (
                                select u.USER_ID
                                  from (select LOGIN_ID
                                          from ' || pi_source_table ||
                                        ') s
                                   join USERS u
                                     on upper(s.LOGIN_ID) = upper(u.LOGIN_ID)
                                 )';
        execute immediate l_delete_dependencies;
        execute immediate l_delete_user_roles;
      end if;

      for c in (select 1 from user_tables where table_name = 'ALL_USER_ROLES') loop
        execute immediate 'truncate table ALL_USER_ROLES';
      end loop;

      -- insert all the roles if the roles must be replaced
      -- get max role length
      l_max_role_clause := 'select max(length(trim(elm)))
                  from (select role src from ' ||
                           pi_source_table || '),
                  xmltable(''r/c'' passing
                    xmltype(''<r><c>'' || replace(src, ''' ||
                           nvl(pi_separator, ',') ||
                           ''', ''</c><c>'') ||
                            ''</c></r>'') columns elm varchar2(1300) path ''.'')';

      l_has_double_quotes_clause := 'select max(decode(instr(role,''"''),0,0,1)) from '|| pi_source_table;
      l_has_single_quotes_clause := 'select max(decode(instr(role,''''''''),0,0,1)) from '|| pi_source_table;
      l_has_comma_first_clause   := 'select max(decode(substr(role,1,1),'','',1,0)) from '|| pi_source_table;

      execute immediate l_max_role_clause into l_max_role_length;
      execute immediate l_has_double_quotes_clause into l_has_double_quotes;
      execute immediate l_has_single_quotes_clause into l_has_single_quotes;
      execute immediate l_has_comma_first_clause into l_has_comma_first;

      -- check if separator is ',' and there is no role with length > 30 in order to use comma_to_table utility
      if pi_separator = ',' and l_max_role_length < 30 and l_has_double_quotes = 0 and l_has_single_quotes = 0 and l_has_comma_first = 0 then

        l_source_table_clause := 'select login_id, ''"'' || replace(role, '','',''","'') || ''"'' from ' ||
                                 pi_source_table;
        open l_source_table_cursor for l_source_table_clause;
        loop
          FETCH l_source_table_cursor
            INTO l_login_id, l_role_name;
          EXIT WHEN l_source_table_cursor%NOTFOUND;
          dbms_utility.comma_to_table(l_role_name, l_tablen, l_temp_role_tab);
          for i in 1 .. l_temp_role_tab.count loop
            execute immediate 'insert into ALL_USER_ROLES(role_name, login_id) values (''' ||
                              trim(trim(both '"' from l_temp_role_tab(i))) || ''', ''' || REPLACE(l_login_id,'''','''''') ||
                              ''')';
            commit;
          end loop;
        end loop;
        close l_source_table_cursor;

        l_insert_dependencies := 'insert into DEPENDENCY_METADATA(DM_REFFERED_OBJECT_ID,DM_REFFERING_OBJECT_ID,DM_REFFERING_OBJECT_TYPE,DM_SUBGROUP_KEY)
                                  select distinct rol_id, ' || l_user_table_id || ', 2, ''USER_ROLES''
                                    from (select login_id,
                                                 role_name from ALL_USER_ROLES where role_name is not null
                                          ) x
                                    join roles r
                                      on upper(role_name) = upper(r.rol_name)
                                    join users u
                                      on upper(x.login_id) = upper(u.login_id)
                                   where role_name is not null
                                  ';
        -- copy paste Victor Ponta style
        -- this code needs to be refactored
        l_insert_user_roles := 'insert into USER_ROLES (UR_USER_ID, UR_ROLE_ID)
                                  select distinct user_id, rol_id
                                    from (select login_id,
                                                 role_name from ALL_USER_ROLES where role_name is not null
                                          ) x
                                    join roles r
                                      on upper(role_name) = upper(r.rol_name)
                                    join users u
                                      on upper(x.login_id) = upper(u.login_id)
                                   where role_name is not null
                                  ';

        -- else use xml to extract roles from source table
      else

        l_insert_dependencies := 'insert into DEPENDENCY_METADATA(DM_REFFERED_OBJECT_ID,DM_REFFERING_OBJECT_ID,DM_REFFERING_OBJECT_TYPE,DM_SUBGROUP_KEY)
                                  select distinct rol_id, ' || l_user_table_id || ', 2, ''USER_ROLES''
                                    from (select login_id, role, elm
                                    from (select login_id, role, role src from ' ||
                               pi_source_table || '),
                                         xmltable(''r/c'' passing
                                                  xmltype(''<r><c>'' || replace(src, ''' ||
                               nvl(pi_separator, ',') ||
                               ''', ''</c><c>'') ||
                                                          ''</c></r>'') columns elm varchar2(1300) path ''.'')) x
                                    join roles r
                                      on upper(trim(elm)) = upper(r.rol_name)
                                    join users u
                                      on upper(x.login_id) = upper(u.login_id)
                                   where trim(elm) is not null
                                  ';

        l_insert_user_roles := 'insert into USER_ROLES (UR_USER_ID, UR_ROLE_ID)
                                    select distinct user_id, rol_id
                                    from (select login_id, role, elm
                                    from (select login_id, role, role src from ' ||
                               pi_source_table || '),
                                         xmltable(''r/c'' passing
                                                  xmltype(''<r><c>'' || replace(src, ''' ||
                               nvl(pi_separator, ',') ||
                               ''', ''</c><c>'') ||
                                                          ''</c></r>'') columns elm varchar2(1300) path ''.'')) x
                                    join roles r
                                      on upper(trim(elm)) = upper(r.rol_name)
                                    join users u
                                      on upper(x.login_id) = upper(u.login_id)
                                   where trim(elm) is not null
                                  ';

      end if;
      -- insert only the roles that aren't already mapped if the roles must be appended
      if pi_append_roles = 1 then
        l_append_user_roles := ' and r.rol_id not in (select ur_role_id from USER_ROLES where ur_user_id = u.user_id)';
        l_insert_user_roles := l_insert_user_roles || l_append_user_roles;
      end if;
      execute immediate l_insert_dependencies;
      execute immediate l_insert_user_roles;
      -- delete existing roles from users table
      l_delete_roles := 'update users set role = null where upper(login_id) in (select upper(login_id) from ' || pi_source_table || ')';
      execute immediate l_delete_roles;
      -- insert the corresponding roles in the users table
      l_insert_roles := ' merge /*+ NO_MERGE (src) */ into users dst
                          using (select u.user_id,
                                        listagg(r.rol_name, '', '') within group(order by NLSSORT(rol_name,''nls_sort='''''||l_nls_sort||''''''')) role
                                   from users u
                                   join ' || pi_source_table || ' t
                                     on upper(u.login_id) = upper(t.login_id)
                                   join user_roles ur
                                     on u.user_id = ur.ur_user_id
                                   join roles r
                                     on ur.ur_role_id = r.rol_id
                                  group by u.user_id) src
                          on (dst.user_id = src.user_id)
                          when matched then
                            update set dst.role = src.role';
      execute immediate l_insert_roles;
    end if;
    -- return number of inserted/updated users
    open po_counts_cursor for select l_inserted_rows cnt from dual union all select l_updated_rows from dual;
    -- return emails of the updated users with account
    if pi_load_mode in (3,4) then
      l_emails_sql := 'select s.login_id, s.email
                         from ' || pi_source_table || ' s
                         join users u
                           on upper(s.login_id) = upper(u.login_id)
                        where u.has_account = 1';
    else
      l_emails_sql := 'select ''dummy'' login_id, ''dummy'' email from dual where 1 = 0';
    end if;
    open po_emails_cursor for l_emails_sql;
  end load_users;

  procedure set_roles(pi_users_list      in clob,
                      pi_roles_list      in clob,
                      pi_update_mode     in number,
                      po_too_many_roles out number) is
    l_number_of_roles              number;
    l_users_where_clause           clob;
    l_roles_from_clause            clob;
    l_delete_roles_clause          clob;
    l_delete_specific_roles_clause clob;
    l_insert_roles_clause          clob;
    l_select_roles_clause          clob;
    l_insert_specific_roles_clause clob;
    l_check_roles_clause           clob;
    l_max_number_of_roles          number;
  begin
    -- check parameters
    if pi_users_list is null then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, '<null>' || ';' || 'pi_users_list'));
    end if;
    if pi_roles_list is null then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, '<null>' || ';' || 'pi_roles_list'));
    end if;
    if pi_update_mode not in (1,2,3) then
      raise_application_error(commons_exceptions.e_InvalidParam_code,
                              commons_exceptions.error_text(commons_exceptions.e_InvalidParam_msg, pi_update_mode || ';' || 'pi_update_mode'));
    end if;
    l_number_of_roles := regexp_count(pi_roles_list,',') + 1;
    -- build delete and insert clauses
    l_users_where_clause := ' where row_identifier in (' || pi_users_list || ')';
    l_roles_from_clause := ' from table(tabletype_number(' || pi_roles_list || ')) t';
    l_delete_roles_clause := 'delete
                                from user_roles
                               where ur_user_id in (select user_id
                                                      from users' ||
                                                     l_users_where_clause ||
                                                   ')';
    l_delete_specific_roles_clause := ' and ur_role_id in (select column_value rol_id ' || l_roles_from_clause || ')';
    l_select_roles_clause := 'select user_id, ur_role_id
                                from users
                                join user_roles
                                  on user_id = ur_user_id' ||
                               l_users_where_clause ||
                             ' union
                              select user_id, ur_role_id
                                from users
                               cross join (select /*+ CARDINALITY(t ' || l_number_of_roles || ')*/ column_value ur_role_id ' || l_roles_from_clause || ')' ||
                               l_users_where_clause;
    l_insert_roles_clause := 'insert into user_roles(ur_user_id,ur_role_id) select user_id, ur_role_id from ( ' || l_select_roles_clause;
    l_insert_specific_roles_clause := ') where (user_id,ur_role_id) not in (select ur_user_id, ur_role_id
                                                                           from user_roles
                                                                           join users
                                                                             on ur_user_id = user_id' ||
                                                                           l_users_where_clause ||
                                                                         ')';
    -- stop process if a user gets more than 40 roles
    if pi_update_mode = 3 and l_number_of_roles > 40 then
      po_too_many_roles := 1;
    elsif pi_update_mode = 1 then
      l_check_roles_clause := 'select nvl2(max(count(ur_role_id)),1,0)
                                 from (' || l_select_roles_clause ||
                             ') group by user_id having count(ur_role_id) > 40';
      execute immediate l_check_roles_clause into l_max_number_of_roles;
      if l_max_number_of_roles = 1 then
        po_too_many_roles := 1;
      end if;
    end if;
    if po_too_many_roles is null then
      po_too_many_roles := 0;
      -- execute clauses
      -- add specified roles to existing roles
      if pi_update_mode = 1 then
        execute immediate l_insert_roles_clause || l_insert_specific_roles_clause;
      -- remove specified roles from existing roles
      elsif pi_update_mode = 2 then
        execute immediate l_delete_roles_clause || l_delete_specific_roles_clause;
      -- replace existing roles with specified roles
      elsif pi_update_mode = 3 then
        execute immediate l_delete_roles_clause;
        execute immediate l_insert_roles_clause || ')';
      end if;
    end if;
  end set_roles;

  procedure update_roles(pi_roles_list in TABLETYPE_ID_NAME) is
    l_nls_sort varchar2(100);
  begin
    -- get nlssort
    l_nls_sort := commons_appframework.get_nls_property('NLS_SORT');
    -- update roles
    merge into roles dst
    using (select id, name from table(pi_roles_list)) src
    on (dst.rol_id = src.id)
    when matched then
      update set dst.rol_name = src.name;
    -- update users
    merge into users dst
    using (select u.user_id,
                  listagg(r.rol_name, ', ') within group(order by NLSSORT(rol_name,'nls_sort='''||l_nls_sort||'''')) role
             from (select distinct user_id
                     from users
                     join user_roles
                       on user_id = ur_user_id
                     join roles
                       on ur_role_id = rol_id
                     join table(pi_roles_list)
                       on rol_id = id
                   ) u
             join user_roles ur
               on u.user_id = ur.ur_user_id
             join roles r
               on ur.ur_role_id = r.rol_id
            group by u.user_id) src
    on (dst.user_id = src.user_id)
    when matched then
      update set dst.role = src.role;
  end update_roles;

-- *******************************    PUBLIC PROCEDURES END         *******************************

end commons_users;
/
