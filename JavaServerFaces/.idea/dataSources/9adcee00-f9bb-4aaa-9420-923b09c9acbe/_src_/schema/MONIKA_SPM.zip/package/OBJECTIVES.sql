CREATE PACKAGE OBJECTIVES AS

/* VERIFY_ENTITY_APPROVALS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which the appraisals are approved

    ,pi_entity_id               IN NUMBER
        -   NOT NULL
        -   the id of the entity of which the appraisals are viewed

    ,pi_view_mode           IN NUMBER
        -   NOT NULL
        -   the type of : 1 - manager viewing appraisals for a subordinate, 2 - user is viewing his own appraisals.

    ,pi_hierarchy_qry           IN CLOB
        -   NULL - must be populated when pi_view_mode = 1
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from the upper entity (filtered for the specific
            user that is logged in) and going towards the subordinates in the lower entity.
            no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
        -   it must expose at least columns LOWER_VALUE and HLEVEL:
            (SELECT
                 CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                ,TAB.UPPER_VALUE                        UPPER_VALUE
                ,LEVEL                                  HLEVEL
            FROM .......)

-----------------------------------------------------------------------------------------------
Return:

    The function will return a cursor with one row with the following columns:

    ENTITY_STILL_EXISTS         - 0/1 - always populated
    OBJ_APPROVED_AT_ANY_LVL     - 0/1 - populated for pi_view_mode = 2 and appraisal approvals are applicable
    SCR_APPROVED_AT_ANY_LVL     - 0/1 - populated for pi_view_mode = 2
    USER_IS_STILL_MANAGER       - 0/1 - populated for pi_view_mode = 1
    MANAGER_LVL_IS_APPLICABLE   - 0/1 - populated for pi_view_mode = 1
    OBJ_APPROVED_AT_USER_LVL    - 0/1 - populated for pi_view_mode = 1 and appraisal approvals are applicable
    SCR_APPROVED_AT_USER_LVL    - 0/1 - populated for pi_view_mode = 1

-----------------------------------------------------------------------------------------------
*/
FUNCTION VERIFY_ENTITY_APPROVALS
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_id               IN NUMBER
    ,pi_view_mode               IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;


/* ADD_ENTITIES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which the entities are added

    ,pi_hierarchy_qry           IN CLOB
        -   NOT NULL
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from lower entities to upper.
        -   no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
        -   if the hierarchy is effective dated then the query should return only records that are valid for the current period in pi_period_id
        -   it must expose at least columns LOWER_VALUE and HLEVEL:
            (SELECT
                 CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                ,TAB.UPPER_VALUE                        UPPER_VALUE
                ,LEVEL                                  HLEVEL
            FROM .......)

    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
        -   NOT NULL
        -   the source entity table from which the entity ID's are added.
            if the entity table is filtered by a subquery then only the FROM_CLAUSE will be populated with a query enclosed in brackets that exposes E_INTERNAL_ID.
            if the entity table is filtered by a list of entity IDs for IN / NOT IN then the TABLE_NAME and the WHERE_CLAUSE will be populated
        -   members:
            *   TABLE_NAME - VARCHAR2 - NULL : physical table name - "T123"
            *   FROM_CLAUSE - CLOB - NULL : filtering by subquery - "(SELECT E_INTERNAL_ID FROM T123 INNER JOIN ....WHERE...)"
            *   WHERE_CLAUSE - CLOB - NULL : filtering by list - "E_INTERNAL_ID IN / NOT IN (1, 2, 45)"
            *   TABLE_TYPE - NUMBER - NULL
            *   INPUT_NUMBER - NUMBER - NULL

-----------------------------------------------------------------------------------------------
*/
PROCEDURE ADD_ENTITIES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
);


/* UPDATE_ENTITY_TOTALS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which the entities are added

    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
        -   NOT NULL
        -   the source entity table from which the entity ID's are identified for update.
            if the entity table is filtered by a subquery then only the FROM_CLAUSE will be populated with a query enclosed in brackets that exposes E_INTERNAL_ID.
            if the entity table is filtered by a list of entity IDs for IN / NOT IN then the TABLE_NAME and the WHERE_CLAUSE will be populated
        -   members:
            *   TABLE_NAME - VARCHAR2 - NULL : physical table name - "T123"
            *   FROM_CLAUSE - CLOB - NULL : filtering by subquery - "(SELECT E_INTERNAL_ID FROM T123 INNER JOIN ....WHERE...)"
            *   WHERE_CLAUSE - CLOB - NULL : filtering by list - "E_INTERNAL_ID IN / NOT IN (1, 2, 45)"
            *   TABLE_TYPE - NUMBER - NULL
            *   INPUT_NUMBER - NUMBER - NULL

-----------------------------------------------------------------------------------------------
*/
PROCEDURE UPDATE_ENTITY_TOTALS
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
);


/* UPDATE_ENTITY_TOTALS_IND
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
        -   NOT NULL
        -   the source table which identifies the entity ID's and period ID's to be updated.
            if the table is filtered by a subquery then only the FROM_CLAUSE will be populated with a query enclosed in brackets that exposes <period_column>, <entity_column>.
            if the table is filtered by a list of entity IDs and period IDs for IN / NOT IN then the TABLE_NAME and the WHERE_CLAUSE will be populated
        -   members:
            *   TABLE_NAME - VARCHAR2 - NULL : physical table name - "T123"
            *   FROM_CLAUSE - CLOB - NULL : filtering by subquery - "(SELECT E100, F462 FROM T123 INNER JOIN ....WHERE...)"
            *   WHERE_CLAUSE - CLOB - NULL : filtering by list - "(E100, F462) IN / NOT IN ((1, 3))"
            *   TABLE_TYPE - NUMBER - NULL
            *   INPUT_NUMBER - NUMBER - NULL

-----------------------------------------------------------------------------------------------
*/
PROCEDURE UPDATE_ENTITY_TOTALS_IND
(    pi_definition_id           IN NUMBER
    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
);


/* ADJUST_APPROVAL_PROPERTIES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_hierarchy_qry           IN CLOB
        -   NOT NULL
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from lower entities to upper.
            it will be limited to the number of levels specified in the definition.
            no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
            the query must expose at least columns:
                - the period column from the appraisal_entities table (F465)
                - the entity column from the appraisal_entities table (E12345)
                - the level column that is calculated inside the hierarchy = HLEVEL
        Example:
        1. when the hierarchy is not effective dated:
            (select  T.F465
                    ,T.E12345
                    ,HQ.HLEVEL
            from    T200 T -- appraisal_entities table
                    left join
                    (   select   CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                                ,TAB.UPPER_VALUE                        UPPER_VALUE
                                ,LEVEL                                  HLEVEL
                        from    ...
                    ) HQ on HQ.UPPER_ENTITY_ID = 12345 --metadata ID of the employee entity
                             and HQ.LOWER_VALUE = T.E12345
            )

        2. when the hierarchy is effective dated, this is only one possible example
            (select  T.F465
                    ,T.E12345
                    ,HQ.HLEVEL
            from    (   select   F465
                                ,E12345
                                ,TUPR_START_DATE SINGLE_DATE
                        from    T200 -- appraisal_entities table
                                left join TU_PERIODS_RANGE T200.EFF_PERIOD = TUPR.TUPR_ID
                    ) T
                    left join
                    (   select   CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                                ,TAB.UPPER_VALUE                        UPPER_VALUE
                                ,LEVEL                                  HLEVEL
                                ,START_DATE
                                ,END_DATE
                        from    ...
                    ) HQ on HQ.UPPER_ENTITY_ID = 12345 --metadata ID of the employee entity
                             and HQ.LOWER_VALUE = T.E12345
                             and T.SINGLE_DATE BETWEEN HQ.START_DATE AND HQ.END_DATE
            )

    ,pi_add_obj_approval        IN NUMBER
        -   NOT NULL
        -   boolean to show whether the column Appraisal Approval has been added to the Entities table.
            either pi_add_obj_approval = 1 or pi_change_levels = 1. Both cannot be null.
        -   0 - Appraisal Approval has not been added, 1 - Appraisal Approval has been added during the last definition change.

    ,pi_change_levels           IN NUMBER
        -   NOT NULL
        -   boolean to show whether the number of levels to use for approval has been changed or not.
            either pi_add_obj_approval = 1 or pi_change_levels = 1. Both cannot be null.
        -   0 - the number of levels has not been changed, 1 - the number of levels has changed during the last definition change.

    ,pi_period_id               IN NUMBER
        - NULL
        - if this is not null then only do adjustments for records of this period

-----------------------------------------------------------------------------------------------
*/
PROCEDURE ADJUST_APPROVAL_PROPERTIES
(    pi_definition_id           IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
    ,pi_add_obj_approval        IN NUMBER
    ,pi_change_levels           IN NUMBER
    ,pi_period_id               IN NUMBER
);


/* APPROVE_OBJECTIVES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which the appraisals are approved

    ,pi_user_name               IN VARCHAR2
        -   NOT NULL
        -   user name of the logged in user

    ,pi_user_entity_bk          IN VARCHAR2
        -   NULL
        -   the entity business key of the logged in user (if he has the value populated in the user table)

    ,pi_approval_mode           IN NUMBER
        -   NOT NULL
        -   the type of approval: 1 - admin mode, 2 - portal mode.
        -   if pi_approval_mode = 1
                then populate either pi_obj_entity_list
                                  or pi_obj_entity_qry  - expected to expose entity column from OBJ_ENTITY table (E123)
                                                        - can have zero or more filters
        -   if pi_approval_mode = 2
                then populate either pi_obj_entity_list and pi_hierarchy_qry
                                  or  pi_obj_entity_qry - but it is expected that the query contains also the HRC filters and HLEVEL is already calculated at filter time
                                                        - expected to expose entity column from OBJ_ENTITY table (E123)
                                                        - expected to expose column HLEVEL from filtering hierarchy
                                                        - can have zero or more filters

    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
        -   NULL
        -   a collection with the list of entities from the OBJ_ENTITIES_TABLE selected for approval.

    ,pi_obj_entity_qry          IN CLOB
        -   NULL
        -   the subquery (enclosed in brackets) that selects the list of entities to be approved
        -   ex:
            (SELECT  E123
                    [,HLEVEL]               -- optional part to be populated only if pi_approval_mode = 2
            FROM OBJ_ENTITIES_TABLE
                [INNER JOIN HRC ON ]        -- optional part to be populated only if pi_approval_mode = 2
            [WHERE UI_FILTER_CONDITION]     -- if there are UI filters defined
            )

    ,pi_hierarchy_qry           IN CLOB
        -   NULL - must be populated when pi_approval_mode = 2 and pi_obj_entity_list is not null
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from the upper entity (filtered for the specific
            user that is logged in) and going towards the subordinates in the lower entity.
            no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
        -   it must expose at least columns LOWER_VALUE and HLEVEL:
            (SELECT
                 CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                ,TAB.UPPER_VALUE                        UPPER_VALUE
                ,LEVEL                                  HLEVEL
            FROM .......)

Validations:
    a - validation executed in admin
    p - validation executed in portal

    Approve Appraisals
        1001 - ap   - The record no longer exists.
        1002 - ap   - Appraisals have not been entered.
        1003 - ap   - Weights for one or more appraisals are not between <minimum weight> and <maximum weight>.
        1004 - ap   - Weights for the set of appraisals do not sum to 100.
        1013 - p    - You are no longer a manager within the levels of approval for this record.
        1014 - p    - Appraisals have not been approved at all lower levels.
    Approve Scores
        1001 - ap   - The record no longer exists.
        1002 - ap   - Appraisals have not been entered.
        1003 - ap   - Weights for one or more appraisals are not between <minimum weight> and <maximum weight>.
        1004 - ap   - Weights for the set of appraisals do not sum to 100.
        1005 - ap   - Scores have not been entered for one or more appraisals.
        1006 - ap   - Scores for one or more appraisals are not between the <minimum score> and <maximum score>.
        1007 - ap   - Scores for one or more appraisals are not valid.
        1008 - ap   - Ratings for one or more appraisals are not valid.
        1009 - ap   - Participant comments have not been entered for one or more appraisals.
        1010 - ap   - Manager comments have not been entered for one or more appraisals.
        1011 - ap   - Appraisals have not been approved at the highest applicable level.
        1013 - p    - You are no longer a manager within the levels of approval for this record.
        1015 - p    - Scores have not been approved at all lower levels.
    Unapprove appraisals
        1001 - ap   - The record no longer exists.
        1012 - ap   - Scores have already been approved at one or more levels.
        1013 - p    - You are no longer a manager within the levels of approval for this record.
        1016 - p    - Appraisals have already been approved at an upper level.
    Unapprove scores
        1001 - ap   - The record no longer exists.
        1013 - p    - You are no longer a manager within the levels of approval for this record.
        1017 - p    - Scores have already been approved at an upper level.

    At the end of the function will return a refcursor for a query that contains all the entities
    that failed with the correspondent validations that failed for them.

    ENTITY_ID - e_internal_id of the entity that failed the validation
    VALIDATION_ID - id of the validation that failed

    Example of data:
    ENTITY_ID   VALIDATION_ID
    -------------------------
    123         1003
    123         1005
    456         1002

-----------------------------------------------------------------------------------------------
*/
FUNCTION APPROVE_OBJECTIVES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;


/* APPROVE_SCORES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Parameters and validations are the same as for APPROVE_OBJECTIVES
-----------------------------------------------------------------------------------------------
*/
FUNCTION APPROVE_SCORES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;


/* UNAPPROVE_OBJECTIVES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Parameters and validations are the same as for APPROVE_OBJECTIVES
-----------------------------------------------------------------------------------------------
*/
FUNCTION UNAPPROVE_OBJECTIVES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;


/* UNAPPROVE_SCORES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Parameters and validations are the same as for APPROVE_OBJECTIVES
-----------------------------------------------------------------------------------------------
*/
FUNCTION UNAPPROVE_SCORES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;


/* RUN_IMPORT_VALIDATIONS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_import_location         IN NUMBER
        -   NOT NULL
        -   enum to identify where the import takes place
        -   Values:
            1 - validation executed in admin > view entities list
            2 - validation executed in admin > view appraisals form
            3 - validation executed in portal > view entities list
            4 - validation executed in portal > view appraisals form

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which appraisals are imported

    ,pi_entity_internal_id      IN NUMBER
        -   NULL - be populated for pi_import_location = 2, 4
        -   the id of the entity for which appraisals are imported;

    ,pi_temp_table_name         IN VARCHAR2
        -   NOT NULL
        -   the name of the temporary table that holds the information to be imported

    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
        -   NOT NULL
        -   the mapping between column names from the Appraisals table and the corresponding columns from the temporary table
            the mappings do not contain an entry for the period column - this is hardcoded for all records in pi_period_id
            the mappings will contain an entry for the entity column only when pi_import_location = 1, 3
        -   Ex: TABLETYPE_NAME_MAP(  OBJTYPE_NAME_MAP('E1234','COL1')
                                    ,OBJTYPE_NAME_MAP('OBJECTIVE','COL3')
                                    ,OBJTYPE_NAME_MAP('WEIGHT','COL4'))

    ,pi_subordinate_mode        IN NUMBER
        -   NULL - must be populated when pi_import_location = 3
        -   shows what kind of subordinates the view returns.
        -   Values: 2 - direct subordinates only, 1 - all levels of approval

    ,pi_hierarchy_qry           IN CLOB
        -   NULL - must be populated when pi_import_location = 3
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from the upper entity (filtered for the specific
            user that is logged in) and going towards the subordinates in the lower entity.
            no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
        -   if the hierarchy is effective dated then the query should return only records that are valid for the current period in pi_period_id
        -   it must expose at least columns LOWER_VALUE and HLEVEL:
            (SELECT
                 CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                ,TAB.UPPER_VALUE                        UPPER_VALUE
                ,LEVEL                                  HLEVEL
            FROM .......)

Import locations:
    1 - validation executed in admin > view entities list
    2 - validation executed in admin > view appraisals form
    3 - validation executed in portal > view entities list
    4 - validation executed in portal > view appraisals form

Validations:
    1101 - 1234 - all weights are between the minimum weight and maximum weight specified for the definition.
    1102 - 1234 - all scores are within the specified minimum and maximum scores.
    1103 - 1234 - all scores must be in the specified list of scores.
    1104 - 1234 - all ratings must be in the specified list of rating and score combinations.
    1105 - 1234 - all decimal lengths to use for the weight field are as specified for the definition.
    1106 - 1234 - all decimal lengths to use for the score field are as specified for the definition.
    1107 - 34   - all appraisals meet the criteria to be in the view - for entity and period (only if the period(3) or entity/period(4) are in the file).
    1108 - 3    - the user approval level is not marked as not applicable.
    1109 - 3    - the appraisals or scores have not been approved at the user level or higher

    At the end, the function will return a refcursor with all the failed validations:
    VALIDATION_ID - id of the validation that failed

    Example of data:
    VALIDATION_ID
    -------------
    1101
    1105
    1102

-----------------------------------------------------------------------------------------------
*/
FUNCTION RUN_IMPORT_VALIDATIONS
(    pi_definition_id           IN NUMBER
    ,pi_import_location         IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_internal_id      IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pi_subordinate_mode        IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;


/* RUN_IMPORT
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_import_location         IN NUMBER
        -   NOT NULL
        -   enum to identify where the import takes place
        -   Values:
            1 - validation executed in admin > view entities list
            2 - validation executed in admin > view appraisals form
            3 - validation executed in portal > view entities list
            4 - validation executed in portal > view appraisals form

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which appraisals are imported

    ,pi_entity_internal_id      IN NUMBER
        -   NULL - be populated for pi_import_location = 2, 4
        -   the id of the entity for which appraisals are imported;

    ,pi_temp_table_name         IN VARCHAR2
        -   NOT NULL
        -   the name of the temporary table that holds the information to be imported

    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
        -   NOT NULL
        -   the mapping between column names from the Appraisals table and the corresponding columns from the temporary table
            the mappings do not contain an entry for the period column - this is hardcoded for all records in pi_period_id
            the mappings will contain an entry for the entity column only when pi_import_location = 1, 3
        -   Ex: TABLETYPE_NAME_MAP(  OBJTYPE_NAME_MAP('E1234','COL1')
                                    ,OBJTYPE_NAME_MAP('OBJECTIVE','COL3')
                                    ,OBJTYPE_NAME_MAP('WEIGHT','COL4'))

    ,pi_hierarchy_qry           IN CLOB
        -   NULL - must be populated when pi_import_location = 1, 3
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from lower entities to upper.
        -   no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
        -   if the hierarchy is effective dated then the query should return only records that are valid for the current period in pi_period_id
        -   it must expose at least columns LOWER_VALUE and HLEVEL:
            (SELECT
                 CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                ,TAB.UPPER_VALUE                        UPPER_VALUE
                ,LEVEL                                  HLEVEL
            FROM .......)

-----------------------------------------------------------------------------------------------
*/
PROCEDURE RUN_IMPORT
(    pi_definition_id           IN NUMBER
    ,pi_import_location         IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_internal_id      IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pi_hierarchy_qry           IN CLOB
);


/* GET_LOAD_VALIDATION_CLAUSES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_table_type              IN NUMBER
        -   NOT NULL
        -   table type to load into: 1 - appraisal entities table, 2 - appraisals table

    ,pi_temp_table_name         IN VARCHAR2
        -   NOT NULL
        -   the alias used with the temporary table that holds the information to be imported

    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
        -   NOT NULL
        -   the mapping between column names from the Appraisal entities/Appraisals table and the corresponding columns from the temporary table
        -   Ex: TABLETYPE_NAME_MAP(  OBJTYPE_NAME_MAP('E1234','COL1')
                                    ,OBJTYPE_NAME_MAP('OBJECTIVE','COL3')
                                    ,OBJTYPE_NAME_MAP('WEIGHT','COL4'))

    ,pio_validation_clauses     IN OUT TABLETYPE_OBJECTIVE_LOAD_VLD
        -   a collection containing the validation when clauses to be appended in data load/post records
        -   it will be sent with VLD_ID populated and VLD_WHEN_CLAUSE as NULL:

            TABLETYPE_OBJECTIVE_LOAD_VLD
                (OBJTYPE_OBJECTIVE_LOAD_VLD(1201, NULL)
                ,OBJTYPE_OBJECTIVE_LOAD_VLD(1202, NULL))

        -   and will return the same collection but also with the VLD_WHEN_CLAUSE populated:

            TABLETYPE_OBJECTIVE_LOAD_VLD
                (OBJTYPE_OBJECTIVE_LOAD_VLD(1201, 'CASE WHEN NOT EXISTS(SELECT 1 FROM OBJ_PERIODS OP WHERE OP.F123 = TMP_ALIAS.C001) THEN 1 ELSE 0 END')
                ,OBJTYPE_OBJECTIVE_LOAD_VLD(1202, 'CASE WHEN NOT EXISTS() THEN 1 ELSE 0 END'))

        -   possible validations (for different locations - see pi_table_type values on meaning of 1 and 2):
            1201 - 1   - the period value for the appraisal frequency field is in the Appraisal Periods table and is not closed.
            1202 - 2   - the values for the appraisal entity and appraisal frequency field have a record in the Appraisals Entity table for the appraisal definition
            1203 - 2   - all weights are between the minimum weight and maximum weight specified for the definition.
            1204 - 2   - all scores are within the specified minimum and maximum scores.
            1205 - 2   - all scores must be in the specified list of scores.
            1206 - 2   - all ratings must be in the specified list of rating and score combinations.
            1207 - 2   - all decimal lengths to use for the weight field are as specified for the definition.
            1208 - 2   - all decimal lengths to use for the score field are as specified for the definition.

-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_LOAD_VALIDATION_CLAUSES
(    pi_definition_id           IN NUMBER
    ,pi_table_type              IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pio_validation_clauses     IN OUT TABLETYPE_OBJECTIVE_LOAD_VLD
);


/* LOAD_OBJECTIVES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_temp_table_name         IN VARCHAR2
        -   NOT NULL
        -   the alias used with the temporary table that holds the information to be imported

    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
        -   NOT NULL
        -   the mapping between column names from the Appraisal entities/Appraisals table and the corresponding columns from the temporary table
        -   Ex: TABLETYPE_NAME_MAP(  OBJTYPE_NAME_MAP('E1234','COL1')
                                    ,OBJTYPE_NAME_MAP('OBJECTIVE','COL3')
                                    ,OBJTYPE_NAME_MAP('WEIGHT','COL4'))

    ,pi_temp_query              IN VARCHAR2
         -   NOT NULL - IF pi_temp_table_name IS NULL
         -   query provided at load in append mode

    ,pi_load_mode               IN NUMERIC
         -   NOT NULL
         - 1- append mode, 2 - recreate mode

-----------------------------------------------------------------------------------------------
*/
PROCEDURE LOAD_OBJECTIVES
(    pi_definition_id           IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pi_temp_query              IN CLOB
    ,pi_load_mode               IN NUMBER
);


/* GET_STATUS_REPORT
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
Parameters:

     pi_definition_id           IN NUMBER
        -   NOT NULL
        -   the id of the appraisals definition in OBJ_DEFINITIONS

    ,pi_location                IN NUMBER
        -   NOT NULL
        -   where the report is accessed: 1 - admin mode, 2 - portal mode.

    ,pi_period_id               IN NUMBER
        -   NOT NULL
        -   the id of the period for which the appraisals are approved

    ,pi_filter_qry              IN CLOB
        -   NULL
        -   the subquery (enclosed in brackets) that selects the list of entities to be validated
        -   it must expose column ROW_IDENTIFIER / ENTITY + PERIOD

    ,pi_hierarchy_qry           IN CLOB
        -   NULL - must be populated when pi_location = 2
        -   the subquery (enclosed in brackets) that constructs the hierarchy starting from the upper entity (filtered for the specific
            user that is logged in) and going towards the subordinates in the lower entity.
            no need for "distinct" because in an optymyze hierarchy any entity cannot have more than one parent/manager.
        -   it must expose at least columns LOWER_VALUE and HLEVEL:
            (SELECT
                 CONNECT_BY_ROOT TAB.LOWER_ENTITY_ID    LOWER_ENTITY_ID
                ,CONNECT_BY_ROOT TAB.LOWER_VALUE        LOWER_VALUE
                ,TAB.UPPER_ENTITY_ID                    UPPER_ENTITY_ID
                ,TAB.UPPER_VALUE                        UPPER_VALUE
                ,LEVEL                                  HLEVEL
            FROM .......)

Validations:
    a - validation executed in admin
    p - validation executed in portal

    1301 - ap  - Appraisals not entered.
    1302 - ap  - Scores have not been entered for one or more appraisals.
    1303 - ap  - Participant comments have not been entered for one or more appraisals.                     (if participant comments are required on approval)
    1304 - ap  - Manager comments have not been entered for one or more appraisals.                         (if manager comments are required on approval)
    1305 - a   - Appraisals have not been approved at the highest applicable level.                         (if appraisal approvals are required)
    1306 - a   - Scores have not been approved at the highest applicable level.
    1307 - p   - Appraisals have not been approved at all lower levels.                                     (if appraisal approvals are required; if lower level approvals are required before upper level approvals)
    1308 - p   - Scores have not been approved at all lower levels.                                         (if lower level approvals are required before upper level approvals)
    1309 - p   - Appraisals have not been approved at your level.                                           (if appraisal approvals are required)
    1310 - p   - Scores have not been approved at your level.
    1311 - ap  - Weights for one or more appraisals are not between <minimum weight>% and <maximum weight>%.
    1312 - ap  - Weights for the set of appraisals do not sum to 100%.
    1313 - ap  - Scores for one or more appraisals are not between <minimum score> and <maximum score>.
    1314 - ap  - Scores for one or more appraisals are not valid.
    1315 - ap  - Ratings for one or more appraisals are not valid.

-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_STATUS_REPORT
(    pi_definition_id           IN NUMBER
    ,pi_location                IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_filter_qry              IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR;

END OBJECTIVES;
/
