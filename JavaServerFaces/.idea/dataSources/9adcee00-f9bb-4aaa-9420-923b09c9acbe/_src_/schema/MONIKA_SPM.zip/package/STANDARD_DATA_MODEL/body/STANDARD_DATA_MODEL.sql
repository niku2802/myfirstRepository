CREATE PACKAGE BODY STANDARD_DATA_MODEL AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2017 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------

  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS START       *******************************
  type v_tu_type is table of OBJTYPE_CDM_TIME_UNITS;
  type v_tu_periods_type is table of OBJTYPE_CDM_TIME_UNIT_PERIODS;
  type v_tu_corr_type is table of OBJTYPE_CDM_TU_CORR;
  type v_tu_periods_corr_type is table of OBJTYPE_CDM_TU_PERIODS_CORR;
  -- tab to hold the CDM time units
  v_tu_tab v_tu_type := v_tu_type(OBJTYPE_CDM_TIME_UNITS(1,
                                                         'Quarter-Business',
                                                         4,
                                                         2,
                                                         1),
                                  OBJTYPE_CDM_TIME_UNITS(2,
                                                         'Year-Business',
                                                         4,
                                                         2,
                                                         1),
                                  OBJTYPE_CDM_TIME_UNITS(3,
                                                         'Month-Business',
                                                         4,
                                                         2,
                                                         1),
                                  OBJTYPE_CDM_TIME_UNITS(4,
                                                         'Week-Business',
                                                         4,
                                                         2,
                                                         1));
  -- tab to hold the CDM time units Periods
  v_tu_periods_tab v_tu_periods_type := v_tu_periods_type(OBJTYPE_CDM_TIME_UNIT_PERIODS('Quarter 1',
                                                                                        1,
                                                                                        1),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Quarter 2',
                                                                                        1,
                                                                                        2),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Quarter 3',
                                                                                        1,
                                                                                        3),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Quarter 4',
                                                                                        1,
                                                                                        4),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Year',
                                                                                        2,
                                                                                        1),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('January',
                                                                                        3,
                                                                                        1),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('February',
                                                                                        3,
                                                                                        2),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('March',
                                                                                        3,
                                                                                        3),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('April',
                                                                                        3,
                                                                                        4),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('May',
                                                                                        3,
                                                                                        5),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('June',
                                                                                        3,
                                                                                        6),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('July',
                                                                                        3,
                                                                                        7),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('August',
                                                                                        3,
                                                                                        8),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('September',
                                                                                        3,
                                                                                        9),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('October',
                                                                                        3,
                                                                                        10),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('November',
                                                                                        3,
                                                                                        11),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('December',
                                                                                        3,
                                                                                        12),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 1',
                                                                                        4,
                                                                                        1),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 2',
                                                                                        4,
                                                                                        2),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 3',
                                                                                        4,
                                                                                        3),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 4',
                                                                                        4,
                                                                                        4),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 5',
                                                                                        4,
                                                                                        5),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 6',
                                                                                        4,
                                                                                        6),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 7',
                                                                                        4,
                                                                                        7),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 8',
                                                                                        4,
                                                                                        8),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 9',
                                                                                        4,
                                                                                        9),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 10',
                                                                                        4,
                                                                                        10),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 11',
                                                                                        4,
                                                                                        11),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 12',
                                                                                        4,
                                                                                        12),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 13',
                                                                                        4,
                                                                                        13),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 14',
                                                                                        4,
                                                                                        14),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 15',
                                                                                        4,
                                                                                        15),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 16',
                                                                                        4,
                                                                                        16),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 17',
                                                                                        4,
                                                                                        17),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 18',
                                                                                        4,
                                                                                        18),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 19',
                                                                                        4,
                                                                                        19),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 20',
                                                                                        4,
                                                                                        20),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 21',
                                                                                        4,
                                                                                        21),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 22',
                                                                                        4,
                                                                                        22),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 23',
                                                                                        4,
                                                                                        23),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 24',
                                                                                        4,
                                                                                        24),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 25',
                                                                                        4,
                                                                                        25),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 26',
                                                                                        4,
                                                                                        26),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 27',
                                                                                        4,
                                                                                        27),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 28',
                                                                                        4,
                                                                                        28),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 29',
                                                                                        4,
                                                                                        29),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 30',
                                                                                        4,
                                                                                        30),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 31',
                                                                                        4,
                                                                                        31),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 32',
                                                                                        4,
                                                                                        32),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 33',
                                                                                        4,
                                                                                        33),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 34',
                                                                                        4,
                                                                                        34),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 35',
                                                                                        4,
                                                                                        35),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 36',
                                                                                        4,
                                                                                        36),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 37',
                                                                                        4,
                                                                                        37),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 38',
                                                                                        4,
                                                                                        38),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 39',
                                                                                        4,
                                                                                        39),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 40',
                                                                                        4,
                                                                                        40),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 41',
                                                                                        4,
                                                                                        41),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 42',
                                                                                        4,
                                                                                        42),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 43',
                                                                                        4,
                                                                                        43),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 44',
                                                                                        4,
                                                                                        44),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 45',
                                                                                        4,
                                                                                        45),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 46',
                                                                                        4,
                                                                                        46),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 47',
                                                                                        4,
                                                                                        47),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 48',
                                                                                        4,
                                                                                        48),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 49',
                                                                                        4,
                                                                                        49),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 50',
                                                                                        4,
                                                                                        50),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 51',
                                                                                        4,
                                                                                        51),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 52',
                                                                                        4,
                                                                                        52),
                                                          OBJTYPE_CDM_TIME_UNIT_PERIODS('Week-Business 53',
                                                                                        4,
                                                                                        53));
  -- tab to hold the CDM time units Correspondense
  v_tu_corr_tab v_tu_corr_type := v_tu_corr_type(OBJTYPE_CDM_TU_CORR(1,
                                                                     'Quarter-Business',
                                                                     'Year-Business'),
                                                 OBJTYPE_CDM_TU_CORR(2,
                                                                     'Month-Business',
                                                                     'Year-Business'),
                                                 OBJTYPE_CDM_TU_CORR(3,
                                                                     'Month-Business',
                                                                     'Quarter-Business'));
  -- tab to hold the CDM time unit periods Correspondense
  v_tu_periods_corr_tab v_tu_periods_corr_type := v_tu_periods_corr_type(OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'Quarter 1',
                                                                                                     'Year',
                                                                                                     1,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'Quarter 2',
                                                                                                     'Year',
                                                                                                     2,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'Quarter 3',
                                                                                                     'Year',
                                                                                                     3,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'Quarter 4',
                                                                                                     'Year',
                                                                                                     4,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'January',
                                                                                                     'Year',
                                                                                                     1,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'February',
                                                                                                     'Year',
                                                                                                     2,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'March',
                                                                                                     'Year',
                                                                                                     3,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'April',
                                                                                                     'Year',
                                                                                                     4,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'May',
                                                                                                     'Year',
                                                                                                     5,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'June',
                                                                                                     'Year',
                                                                                                     6,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'July',
                                                                                                     'Year',
                                                                                                     7,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'August',
                                                                                                     'Year',
                                                                                                     8,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'September',
                                                                                                     'Year',
                                                                                                     9,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'October',
                                                                                                     'Year',
                                                                                                     10,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'November',
                                                                                                     'Year',
                                                                                                     11,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'December',
                                                                                                     'Year',
                                                                                                     12,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'January',
                                                                                                     'Quarter 1',
                                                                                                     1,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'February',
                                                                                                     'Quarter 1',
                                                                                                     2,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'March',
                                                                                                     'Quarter 1',
                                                                                                     3,
                                                                                                     1,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'April',
                                                                                                     'Quarter 2',
                                                                                                     4,
                                                                                                     2,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'May',
                                                                                                     'Quarter 2',
                                                                                                     5,
                                                                                                     2,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'June',
                                                                                                     'Quarter 2',
                                                                                                     6,
                                                                                                     2,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'July',
                                                                                                     'Quarter 3',
                                                                                                     7,
                                                                                                     3,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'August',
                                                                                                     'Quarter 3',
                                                                                                     8,
                                                                                                     3,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'September',
                                                                                                     'Quarter 3',
                                                                                                     9,
                                                                                                     3,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'October',
                                                                                                     'Quarter 4',
                                                                                                     10,
                                                                                                     4,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'November',
                                                                                                     'Quarter 4',
                                                                                                     11,
                                                                                                     4,
                                                                                                     2),
                                                                         OBJTYPE_CDM_TU_PERIODS_CORR(1,
                                                                                                     'December',
                                                                                                     'Quarter 4',
                                                                                                     12,
                                                                                                     4,
                                                                                                     2));
  -- *******************************    PACKAGE CONSTANTS, VARIABLES, TYPES, EXCEPTIONS END         *******************************

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES START       *******************************

  procedure get_namespace_prefix(pin_namespace_name    varchar2,
                                 pout_namespace_id     out number,
                                 pout_namespace_prefix out varchar2) as
  begin
    select NAMESPACE_ID, NAMESPACE_PREFIX
      into pout_namespace_id, pout_namespace_prefix
      from NAMESPACES
     where NAMESPACE_NAME = pin_namespace_name;
  end get_namespace_prefix;

  function get_system_folder(pin_object_type number) return number as
    v_folder_id number;
  begin
    select FOL_ID
      into v_folder_id
      from FOLDERS
     where FOL_CONTAINED_OBJ_TYPE_ID = pin_object_type
       and FOL_TECHNICAL_NAME = case
             when pin_object_type = 12 then
              'System Entity Tables_Sys'
             when pin_object_type = 10 then
              'System Data Tables_Sys'
             when pin_object_type = 9 then
              'System Assignment Tables_Sys'
             when pin_object_type = 15 then
              'System Hierarchy Tables_Sys'
           end;
    return v_folder_id;
  end get_system_folder;

  function get_new_object_name(pin_fld_business_name varchar2,
                               pin_object_type       number) return varchar2 as
    v_business_name   FIELDS.FLD_BUSINESS_NAME%type;
    v_metadata_table  varchar2(30);
    v_metadata_column varchar2(30);
  begin
    v_business_name := pin_fld_business_name;

    if pin_object_type = 1 then
      v_metadata_table  := 'FIELDS';
      v_metadata_column := 'FLD_BUSINESS_NAME';
    elsif pin_object_type = 12 then
      v_metadata_table  := 'ENTITIES';
      v_metadata_column := 'ENTITY_NAME';
    elsif pin_object_type = 10 then
      v_metadata_table  := 'DATA_TABLES';
      v_metadata_column := 'DT_NAME';
    elsif pin_object_type = 9 then
      v_metadata_table  := 'ENTITY_ASSIGNMENTS';
      v_metadata_column := 'EA_NAME';
    elsif pin_object_type = 15 then
      v_metadata_table  := 'HIERARCHY_TABLES';
      v_metadata_column := 'HT_NAME';
    end if;

    -- if there is another user field with the same business name we rename the new system field
    execute immediate '
    declare
      v_count integer;
      v_business_name varchar2(30) := ''' ||
                      v_business_name || ''';
      v_new_business_name varchar2(30);
    begin
      for c in (select ' || v_metadata_column ||
                      ' from ' || v_metadata_table || ' where upper(' ||
                      v_metadata_column || ') = upper(v_business_name)) loop
        v_new_business_name := v_business_name || '' Sys'';
        for d in (select ' || v_metadata_column ||
                      ' from ' || v_metadata_table || ' where upper(' ||
                      v_metadata_column ||
                      ') = upper(v_new_business_name)) loop
          for i in 1..99 loop
            if i > 1 then
              v_new_business_name := substr(v_new_business_name,1,length(v_new_business_name) - length(to_char(i-1)));
            end if;
            if length(v_new_business_name) >= 30 or (i > 9 and length(v_new_business_name) >= 29) then
              v_new_business_name := substr(v_new_business_name,1,30 - length(to_char(i)));
            end if;
            v_new_business_name := v_new_business_name || to_char(i);
            select count(*) into v_count from ' ||
                      v_metadata_table || ' where upper(' ||
                      v_metadata_column || ') = upper(v_new_business_name);
            if v_count = 0 then
              v_business_name := v_new_business_name;
            end if;
            exit when v_count = 0;
          end loop;
        end loop;
        v_business_name := v_new_business_name;
      end loop;
      :a := v_business_name;
    end;'
      using in out v_business_name;

    return v_business_name;

  end get_new_object_name;

  procedure register_table(pin_table_id            number,
                           pin_table_name          varchar2,
                           pin_table_business_name varchar2,
                           pin_table_type          number, -- 1 entity, 2 data, 3 assignment, 4 hierarchy, 5 audit
                           pin_object_id           number,
                           pin_row_id_seq          varchar2,
                           pin_fields              coltype_tbl_cols_sdm,
                           pin_date_option         number default 1,
                           pin_table_tu_period     number default null) as
  begin
    -- register table
    insert into TABLES
      (TABLES_ID,
       TABLES_NAME,
       TABLES_PHYSICAL_NAME,
       TABLES_IS_PREDEFINED,
       OBJECT_VERSION,
       TABLES_RECORD_DATING_OPTION,
       TABLES_TU_ID,
       TABLES_DEFINITION_ID,
       TABLES_IS_AUDITABLE,
       TABLES_TYPE,
       TABLES_IS_MANAGED,
       TABLES_TABLESPACE,
       TABLES_IS_PARTITIONED,
       TABLES_ROWID_SEQ_NAME,
       TABLES_DESPRIPTION,
       TABLES_LOCATION)
    values
      (pin_table_id,
       pin_table_business_name,
       pin_table_name,
       case pin_table_type when 5 then 0 else 1 end,
       0,
       case pin_table_type when 2 then pin_date_option when 3 then
       pin_date_option when 4 then pin_object_id else 1 end,
       pin_table_tu_period,
       case pin_table_type when 4 then null else pin_object_id end,
       case pin_table_type when 5 then 0 else 1 end,
       case pin_table_type when 1 then 'ENTITY_TABLE' when 2 then
       'DATA_TABLE' when 3 then 'ASSIGNMENT' when 4 then 'HIERARCHY' when 5 then
       'SYSTEM_TABLE' end,
       1,
       2,
       0,
       pin_row_id_seq,
       null,
       0);
    -- register columns
    for c in (select OTCS_TC_COLUMN_TYPE,
                     OTCS_TC_IS_REQUIRED,
                     OTCS_TC_FLD_ID,
                     OTCS_TC_LOGIC_TYPE,
                     OTCS_TC_ORDER,
                     OTCS_TC_PHYSICAL_NAME,
                     OTCS_TC_IS_PREDEFINED,
                     OTCS_TC_ENTITY_ID
                from table(pin_fields)
               order by OTCS_TC_ORDER) loop
      insert into TABLE_COLUMNS
        (TC_ID,
         TC_TABLES_ID,
         TC_COLUMN_TYPE,
         TC_IS_REQUIRED,
         TC_FLD_ID,
         TC_LOGIC_TYPE,
         TC_ORDER,
         TC_PHYSICAL_NAME,
         TC_IS_PREDEFINED,
         TC_ENTITY_ID,
         OBJECT_VERSION,
         TC_DATA_TYPE,
         TC_SORT_FILTER,
         TC_IS_REFERENCE,
         TC_IS_NULLABLE,
         TC_FLD_OVERRIDDEN_LENGTH,
         TC_HAS_SYSTEM_DATA,
         TC_DEF_TYPE_ID,
         TC_ACCESS_MODE,
         TC_SORT_ORDER)
      values
        (uid_sequence.nextval,
         pin_table_id,
         c.OTCS_TC_COLUMN_TYPE,
         c.OTCS_TC_IS_REQUIRED,
         c.OTCS_TC_FLD_ID,
         c.OTCS_TC_LOGIC_TYPE,
         c.OTCS_TC_ORDER,
         c.OTCS_TC_PHYSICAL_NAME,
         c.OTCS_TC_IS_PREDEFINED,
         c.OTCS_TC_ENTITY_ID,
         0,
         case when c.OTCS_TC_COLUMN_TYPE = 3 then 10 end,
         1,
         0,
         case when c.OTCS_TC_COLUMN_TYPE = 3 then 0 when
         c.OTCS_TC_COLUMN_TYPE != 3 and c.OTCS_TC_IS_REQUIRED = 1 then 0 when
         c.OTCS_TC_COLUMN_TYPE != 3 and c.OTCS_TC_IS_REQUIRED = 0 then 1 end,
         null,
         0,
         null,
         3,
         1);
    end loop;
  end register_table;

  procedure register_audit_table(pin_table_id       number,
                                 pin_audit_table_id number) as
  begin
    insert into AUDIT_TABLES -- bagata in register tables
      (AT_ID, AT_AUDITED_TABLES_ID, AT_AUDIT_TABLES_ID)
    values
      (uid_sequence.nextval, pin_table_id, pin_audit_table_id);
  end register_audit_table;

  procedure register_dependencies(pin_definition_id   number,
                                  pin_definition_type number,
                                  pin_fields          coltype_tbl_cols_sdm) as
  begin
    for c in (select OTCS_TC_FLD_ID, OTCS_TC_ENTITY_ID
                from table(pin_fields)
               where OTCS_TC_FLD_ID is not null
                  or OTCS_TC_ENTITY_ID is not null) loop
      insert into DEPENDENCY_METADATA
        (DM_REFFERED_OBJECT_ID,
         DM_REFFERING_OBJECT_ID,
         DM_REFFERING_OBJECT_TYPE,
         DM_SUBGROUP_KEY)
      values
        (coalesce(c.OTCS_TC_FLD_ID, c.OTCS_TC_ENTITY_ID),
         pin_definition_id,
         pin_definition_type,
         null);
    end loop;
  end register_dependencies;

  procedure register_relationship(pin_definition_id        number,
                                  pin_category_id          number,
                                  pin_parent_definition_id number default null) as
  begin
    insert into CATEGORY_RELATIONSHIPS
      (CR_ID, CR_CD_ID, CR_DEFINITION_ID, CR_PARENT_DEFINITION_ID)
    values
      (uid_sequence.nextval,
       pin_category_id,
       pin_definition_id,
       pin_parent_definition_id);
  end register_relationship;

  procedure register_reference(pin_definition_id        number,
                               pin_parent_definition_id number,
                               pin_definition_name      varchar2) as
  begin
    insert into TABLE_REFERENCES
      (TREF_ID,
       TREF_DEFINITION_ID,
       TREF_PARENT_DEFINITION_ID,
       TREF_DEFINITION_NAME,
       TREF_LAST_DELETED_SEED)
    values
      (uid_sequence.nextval,
       pin_definition_id,
       pin_parent_definition_id,
       pin_definition_name,
       0);

  end register_reference;

  procedure build_create_table_clause(pin_table_name       varchar2,
                                      pin_fields           coltype_tbl_cols_sdm,
                                      pout_ddl_clause      out clob,
                                      pout_undo_ddl_clause out clob) as
    v_column_list      clob;
    v_table_parameters clob;
  begin
    for c in (select OTCS_TC_PHYSICAL_NAME,
                     case
                       when nvl(FLD_DATA_TYPE, 0) = 1 then
                        'varchar2(250 char)'
                       when nvl(FLD_DATA_TYPE, 0) = 2 then
                        'number(1)'
                       when nvl(FLD_DATA_TYPE, 0) = 3 then
                        'date'
                       when nvl(FLD_DATA_TYPE, 0) = 4 then
                        'varchar2(1300 char)'
                       when nvl(FLD_DATA_TYPE, 0) = 5 then
                        'timestamp(6)'
                       when nvl(FLD_DATA_TYPE, 0) = 6 then
                        'number'
                       when nvl(FLD_DATA_TYPE, 0) = 8 then
                        'number'
                       when nvl(FLD_DATA_TYPE, 0) = 10 then
                        'xmltype'
                       when nvl(FLD_DATA_TYPE, 0) = 0 and
                            OTCS_TC_PHYSICAL_NAME = 'TABLE_XML_DATA' then
                        'xmltype'
                       when nvl(FLD_DATA_TYPE, 0) = 0 and
                            OTCS_TC_PHYSICAL_NAME in
                            ('ADJUSTED_RECORD_ID', 'AUDIT_ID') then
                        'number'
                       when nvl(FLD_DATA_TYPE, 0) = 0 then
                        'number(10)'
                     end FLD_TYPE,
                     case
                       when OTCS_TC_IS_REQUIRED = 1 or
                            OTCS_TC_COLUMN_TYPE = 3 then
                        ' not null'
                     end FLD_NULL
                from table(pin_fields)
                left join FIELDS
                  on OTCS_TC_FLD_ID = FLD_ID) loop
      v_column_list := v_column_list || c.OTCS_TC_PHYSICAL_NAME || ' ' ||
                       c.FLD_TYPE || c.FLD_NULL || ',';
    end loop;
    v_column_list := rtrim(v_column_list, ',');
    -- check in properties
    v_table_parameters   := ' tablespace ' || user ||
                            '_DTS pctfree 10 initrans 5 maxtrans 255 storage (initial 80K next 1M minextents 1 maxextents unlimited) rowdependencies';
    pout_ddl_clause      := 'create table ' || pin_table_name || '(' ||
                            v_column_list || ')' || v_table_parameters;
    pout_undo_ddl_clause := 'begin
                               for c in (select 1 from user_tables where table_name = ''' ||
                            pin_table_name ||
                            ''') loop
                                 execute immediate ''drop table ' ||
                            pin_table_name || ''';
                               end loop;
                             end;';
  end build_create_table_clause;

  procedure build_create_seq_clause(pin_seq_name         varchar2,
                                    pout_ddl_clause      out clob,
                                    pout_undo_ddl_clause out clob) as
    v_seq_parameters clob;
  begin
    v_seq_parameters     := ' minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 cache 10000 noorder nocycle';
    pout_ddl_clause      := 'create sequence ' || pin_seq_name ||
                            v_seq_parameters;
    pout_undo_ddl_clause := 'begin
                               for c in (select 1 from user_sequences where sequence_name = ''' ||
                            pin_seq_name ||
                            ''') loop
                                 execute immediate ''drop sequence ' ||
                            pin_seq_name || ''';
                               end loop;
                             end;';
  end build_create_seq_clause;

  PROCEDURE PARSE_XML_TO_COLLECTION(PIN_XML_VALUE           IN CLOB,
                                    PIN_TABLE_TYPE          IN NUMBER, -- 0 - DT , 1 - E, 2 - ASGN, 3 - HIE
                                    POUT_TABLES_COLLECTION  OUT COLTYPE_TBL_COLS_SDM,
                                    POUT_INDEXES_COLLECTION OUT COLTYPE_COLS_TO_INDEX

                                    ) IS
  BEGIN
    IF PIN_TABLE_TYPE in (0, 2) THEN
      /*<TableFields>
       <field>
           <technical_name>Acceleratoru_User</technical_name>
           <is_required>1</is_required>
           <field_order>1</field_order>
           <display_order>1</display_order>
           <entity_technical_name></entity_technical_name>
           <logic_type>NONE(0), KEY(1), DATA(2), EFFECTIVE_START_DATE(3), EFFECTIVE_END_DATE(4),
           AUTO_NUMBERED(5), EFFECTIVE_PERIOD_START(6), EFFECTIVE_PERIOD_END(7), EFFECTIVE_PERIOD(8), EFFECTIVE_DATE(9)</logic_type>
       </field>
      </TableFields> */
      SELECT OBJTYPE_TBL_COLS_SDM(UID_SEQUENCE.NEXTVAL,
                                  CASE
                                    WHEN ENTITY_ID IS NOT NULL THEN
                                     1
                                    ELSE
                                     2
                                  END,
                                  NVL(IS_REQUIRED, 0),
                                  FLD_ID,
                                  LOGIC_TYPE,
                                  FIELD_ORDER,
                                  NVL(FLD_COLUMN_NAME, 'E' || ENTITY_ID),
                                  coalesce(FLD_IS_PREDEFINED,
                                           ENTITY_IS_PREDEFINED,
                                           0),
                                  ENTITY_ID,
                                  null,
                                  null,
                                  null),
             OBJTYPE_COLS_TO_INDEX(NVL(FLD_COLUMN_NAME, 'E' || ENTITY_ID),
                                   LOGIC_TYPE,
                                   2,
                                   FLD_DATA_TYPE,
                                   CASE
                                     WHEN NVL(IS_REQUIRED, 0) = 0 THEN
                                      1
                                     ELSE
                                      0
                                   END,
                                   FIELD_ORDER)

        BULK COLLECT
        INTO POUT_TABLES_COLLECTION, POUT_INDEXES_COLLECTION
        FROM XMLTABLE('/TableFields/field' PASSING XMLTYPE(PIN_XML_VALUE)
                      COLUMNS TECHNICAL_NAME VARCHAR2(500 CHAR) PATH
                      'technical_name',
                      IS_REQUIRED NUMBER PATH 'is_required',
                      FIELD_ORDER NUMBER PATH 'field_order',
                      DISPLAY_ORDER NUMBER PATH 'display_order',
                      ENTITY_TECH_NAME VARCHAR2(500 CHAR) PATH
                      'entity_technical_name',
                      LOGIC_TYPE NUMBER PATH 'logic_type')
        LEFT JOIN FIELDS
          ON TECHNICAL_NAME = FLD_TECHNICAL_NAME
        LEFT JOIN ENTITIES
          ON ENTITY_TECHNICAL_NAME = ENTITY_TECH_NAME;

      IF PIN_TABLE_TYPE = 2 THEN
        FOR C IN (SELECT OTCS_TC_PHYSICAL_NAME
                    FROM TABLE(POUT_TABLES_COLLECTION)
                   WHERE OTCS_TC_ENTITY_ID IS NOT NULL) LOOP
          POUT_INDEXES_COLLECTION.EXTEND;
          POUT_INDEXES_COLLECTION(POUT_INDEXES_COLLECTION.LAST) := OBJTYPE_COLS_TO_INDEX(C.OTCS_TC_PHYSICAL_NAME,
                                                                                         2,
                                                                                         1,
                                                                                         NULL,
                                                                                         0,
                                                                                         POUT_INDEXES_COLLECTION.LAST);
        END LOOP;
      END IF;

    ELSIF PIN_TABLE_TYPE = 1 THEN
      /*<EntityFields>
       <field>
           <technical_name>Acceleratoru_User</technical_name>
           <is_required>1</is_required>
           <field_order>1</field_order>
           <display_order>1</display_order>
           <entity_technical_name></entity_technical_name>
           <logic_type>NONE(0), KEY(1), DATA(2), EFFECTIVE_START_DATE(3), EFFECTIVE_END_DATE(4),
           AUTO_NUMBERED(5), EFFECTIVE_PERIOD_START(6), EFFECTIVE_PERIOD_END(7), EFFECTIVE_PERIOD(8), EFFECTIVE_DATE(9)</logic_type>
       </field>
      </EntityFields> */
      SELECT OBJTYPE_TBL_COLS_SDM(UID_SEQUENCE.NEXTVAL,
                                  2,
                                  NVL(IS_REQUIRED, 0),
                                  FLD_ID,
                                  LOGIC_TYPE,
                                  FIELD_ORDER,
                                  FLD_COLUMN_NAME,
                                  FLD_IS_PREDEFINED,
                                  NULL,
                                  DISPLAY_ORDER,
                                  null,
                                  null),
             OBJTYPE_COLS_TO_INDEX(FLD_COLUMN_NAME,
                                   LOGIC_TYPE,
                                   2,
                                   FLD_DATA_TYPE,
                                   CASE
                                     WHEN NVL(IS_REQUIRED, 0) = 0 THEN
                                      1
                                     ELSE
                                      0
                                   END,
                                   FIELD_ORDER)

        BULK COLLECT
        INTO POUT_TABLES_COLLECTION, POUT_INDEXES_COLLECTION
        FROM XMLTABLE('/EntityFields/field' PASSING XMLTYPE(PIN_XML_VALUE)
                      COLUMNS TECHNICAL_NAME VARCHAR2(500 CHAR) PATH
                      'technical_name',
                      IS_REQUIRED NUMBER PATH 'is_required',
                      FIELD_ORDER NUMBER PATH 'field_order',
                      DISPLAY_ORDER NUMBER PATH 'display_order',
                      LOGIC_TYPE NUMBER PATH 'logic_type')
        LEFT JOIN FIELDS
          ON TECHNICAL_NAME = FLD_TECHNICAL_NAME;

      POUT_TABLES_COLLECTION.EXTEND;
      POUT_INDEXES_COLLECTION.EXTEND;
      POUT_TABLES_COLLECTION(POUT_TABLES_COLLECTION.LAST) := OBJTYPE_TBL_COLS_SDM(UID_SEQUENCE.NEXTVAL,
                                                                                  3,
                                                                                  0,
                                                                                  NULL,
                                                                                  0,
                                                                                  POUT_TABLES_COLLECTION.LAST,
                                                                                  'E_INTERNAL_ID',
                                                                                  0,
                                                                                  NULL,
                                                                                  null,
                                                                                  null,
                                                                                  null);
      POUT_INDEXES_COLLECTION(POUT_INDEXES_COLLECTION.LAST) := OBJTYPE_COLS_TO_INDEX('E_INTERNAL_ID',
                                                                                     0,
                                                                                     3,
                                                                                     NULL,
                                                                                     0,
                                                                                     POUT_INDEXES_COLLECTION.LAST);

    ELSIF PIN_TABLE_TYPE in (3) THEN
      /*<HierFields>
       <field>
           <technical_name>Acceleratoru_User</technical_name>
           <is_required>1</is_required>
           <field_order>1</field_order>
           <entity_technical_name></entity_technical_name>
           <category_type></category_type>
           <is_lower></is_lower>
           <is_upper></is_upper>
           <logic_type>NONE(0), KEY(1), DATA(2), EFFECTIVE_START_DATE(3), EFFECTIVE_END_DATE(4),
           AUTO_NUMBERED(5), EFFECTIVE_PERIOD_START(6), EFFECTIVE_PERIOD_END(7), EFFECTIVE_PERIOD(8), EFFECTIVE_DATE(9)</logic_type>
       </field>
           <technical_name></technical_name>
           <is_required></is_required>
           <field_order></field_order>
           <entity_technical_name>Product Category_User</entity_technical_name>
           <category_type>10</category_type>
           <is_lower>1</is_lower>
           <is_upper></is_upper>
           <logic_type></logic_type>
      </HierFields> */
      SELECT OBJTYPE_TBL_COLS_SDM(UID_SEQUENCE.NEXTVAL,
                                  CASE
                                    WHEN ENTITY_ID IS NOT NULL THEN
                                     1
                                    ELSE
                                     2
                                  END,
                                  NVL(IS_REQUIRED, 0),
                                  FLD_ID,
                                  LOGIC_TYPE,
                                  FIELD_ORDER,
                                  NVL(FLD_COLUMN_NAME, 'E' || ENTITY_ID),
                                  FLD_IS_PREDEFINED,
                                  ENTITY_ID,
                                  CATEGORY_TYPE,
                                  IS_LOWER,
                                  IS_UPPER),
             OBJTYPE_COLS_TO_INDEX(NVL(FLD_COLUMN_NAME, 'E' || ENTITY_ID),
                                   LOGIC_TYPE,
                                   2,
                                   FLD_DATA_TYPE,
                                   CASE
                                     WHEN NVL(IS_REQUIRED, 0) = 0 THEN
                                      1
                                     ELSE
                                      0
                                   END,
                                   FIELD_ORDER)

        BULK COLLECT
        INTO POUT_TABLES_COLLECTION, POUT_INDEXES_COLLECTION
        FROM XMLTABLE('/HierFields/field' PASSING XMLTYPE(PIN_XML_VALUE)
                      COLUMNS TECHNICAL_NAME VARCHAR2(500 CHAR) PATH
                      'technical_name',
                      IS_REQUIRED NUMBER PATH 'is_required',
                      FIELD_ORDER NUMBER PATH 'field_order',
                      ENTITY_TECH_NAME VARCHAR2(500 CHAR) PATH
                      'entity_technical_name',
                      CATEGORY_TYPE NUMBER PATH 'category_type',
                      IS_LOWER NUMBER PATH 'is_lower',
                      IS_UPPER NUMBER PATH 'is_upper',
                      LOGIC_TYPE NUMBER PATH 'logic_type')
        LEFT JOIN FIELDS
          ON TECHNICAL_NAME = FLD_TECHNICAL_NAME
        LEFT JOIN ENTITIES
          ON ENTITY_TECHNICAL_NAME = ENTITY_TECH_NAME;
    END IF;

    POUT_TABLES_COLLECTION.EXTEND;
    POUT_INDEXES_COLLECTION.EXTEND;
    POUT_TABLES_COLLECTION(POUT_TABLES_COLLECTION.LAST) := OBJTYPE_TBL_COLS_SDM(UID_SEQUENCE.NEXTVAL,
                                                                                3,
                                                                                0,
                                                                                NULL,
                                                                                0,
                                                                                POUT_TABLES_COLLECTION.LAST,
                                                                                'ROW_IDENTIFIER',
                                                                                0,
                                                                                NULL,
                                                                                null,
                                                                                null,
                                                                                null);
    POUT_INDEXES_COLLECTION(POUT_INDEXES_COLLECTION.LAST) := OBJTYPE_COLS_TO_INDEX('ROW_IDENTIFIER',
                                                                                   0,
                                                                                   3,
                                                                                   NULL,
                                                                                   0,
                                                                                   POUT_INDEXES_COLLECTION.LAST);

    POUT_TABLES_COLLECTION.EXTEND;
    POUT_INDEXES_COLLECTION.EXTEND;
    POUT_TABLES_COLLECTION(POUT_TABLES_COLLECTION.LAST) := OBJTYPE_TBL_COLS_SDM(UID_SEQUENCE.NEXTVAL,
                                                                                3,
                                                                                0,
                                                                                NULL,
                                                                                0,
                                                                                POUT_TABLES_COLLECTION.LAST,
                                                                                'ROW_VERSION',
                                                                                0,
                                                                                NULL,
                                                                                null,
                                                                                null,
                                                                                null);
    POUT_INDEXES_COLLECTION(POUT_INDEXES_COLLECTION.LAST) := OBJTYPE_COLS_TO_INDEX('ROW_VERSION',
                                                                                   0,
                                                                                   3,
                                                                                   NULL,
                                                                                   0,
                                                                                   POUT_INDEXES_COLLECTION.LAST);

  END PARSE_XML_TO_COLLECTION;

  PROCEDURE CREATE_INDEXES(PIN_TABLE_ID           IN NUMBER,
                           PIN_INDEXES_COLLECTION IN COLTYPE_COLS_TO_INDEX,
                           PIN_TRANSACTION_ID     IN VARCHAR2,
                           POUT_LOG_MESSAGE       OUT CLOB

                           ) IS
  BEGIN
    COMMONS_INDEXING.CREATE_CORE_INDEXES(PI_TABLES_ID                 => PIN_TABLE_ID,
                                         PI_TABLE_NAME                => 'T' ||
                                                                         PIN_TABLE_ID,
                                         PI_INDEX_CREATION_COLLECTION => PIN_INDEXES_COLLECTION,
                                         PI_INDEX_TABLESPACE          => 2,
                                         PI_TRANSACTION_ID            => PIN_TRANSACTION_ID,
                                         PO_LOG_MSG                   => POUT_LOG_MESSAGE);

  END CREATE_INDEXES;

  -- *******************************    PRIVATE FUNCTIONS AND PROCEDURES END         *******************************

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************

  function get_equivalent_entity(pin_entity_technical_name  varchar2,
                                 pin_equivalent_entity_name varchar2)
    return varchar2 as
    v_technical_name ENTITIES.ENTITY_TECHNICAL_NAME%type;
  begin
    select entity_technical_name
      into v_technical_name
      from entities
     where entity_base_entity in
           (select entity_id
              from entities
             where entity_technical_name = pin_entity_technical_name)
       and entity_name =
           replace(pin_equivalent_entity_name,
                   '|~ID~|',
                   '|~' || entity_base_entity || '~|');
    return v_technical_name;
  end get_equivalent_entity;

  procedure add_equivalent_entity(pin_entity_technical_name  varchar2,
                                  pin_equivalent_entity_name varchar2) as
    v_base_entity_id     ENTITIES.ENTITY_ID%type;
    v_base_category_type ENTITIES.ENTITY_CATEGORY_TYPE%type;
    v_tables_id          ENTITIES.ENTITY_TABLES_ID%type;
    v_entity_name        ENTITIES.ENTITY_NAME%type;
    v_technical_name     ENTITIES.ENTITY_TECHNICAL_NAME%type;
    v_namespace_id       NAMESPACES.NAMESPACE_ID%type;
    v_namespace_prefix   NAMESPACES.NAMESPACE_PREFIX%type;
  begin
    select ENTITY_ID, ENTITY_CATEGORY_TYPE, ENTITY_TABLES_ID
      into v_base_entity_id, v_base_category_type, v_tables_id
      from ENTITIES
     where ENTITY_TECHNICAL_NAME = pin_entity_technical_name;
    get_namespace_prefix(pin_namespace_name    => 'System',
                         pout_namespace_id     => v_namespace_id,
                         pout_namespace_prefix => v_namespace_prefix);
    v_entity_name    := replace(pin_equivalent_entity_name,
                                '|~ID~|',
                                '|~' || v_base_entity_id || '~|');
    v_technical_name := v_entity_name || '_' || v_namespace_prefix;
    insert into ENTITIES
      (ENTITY_ID,
       ENTITY_NAME,
       ENTITY_CATEGORY_TYPE,
       ENTITY_IS_PREDEFINED,
       ENTITY_TABLES_ID,
       OBJECT_VERSION,
       ENTITY_CUSTOM_VERSION,
       ENTITY_BASE_ENTITY,
       ENTITY_FOL_ID,
       ENTITY_NAMESPACE_ID,
       ENTITY_TECHNICAL_NAME,
       ENTITY_LABEL)
    values
      (uid_sequence.nextval,
       v_entity_name,
       v_base_category_type,
       1,
       v_tables_id,
       0,
       0,
       v_base_entity_id,
       null,
       v_namespace_id,
       v_technical_name,
       v_entity_name);
  end add_equivalent_entity;

  procedure add_system_folder(pin_folder_name    varchar2,
                              pin_object_type_id number,
                              pin_container_id   number,
                              pin_folder_label   varchar2) as
    v_namespace_id          NAMESPACES.NAMESPACE_ID%type;
    v_namespace_prefix      NAMESPACES.NAMESPACE_PREFIX%type;
    v_user_namespace_id     NAMESPACES.NAMESPACE_ID%type;
    v_user_namespace_prefix NAMESPACES.NAMESPACE_PREFIX%type;
    v_definition_type_name  DEFINITION_TYPES.DEF_TYPE_NAME_SINGULAR%type;
    v_technical_name        FOLDERS.FOL_TECHNICAL_NAME%type;
    v_label                 FOLDERS.FOL_LABEL%type;
    v_count                 integer;
    v_folder_id             integer; -- type
  begin
    get_namespace_prefix(pin_namespace_name    => 'System',
                         pout_namespace_id     => v_namespace_id,
                         pout_namespace_prefix => v_namespace_prefix);
    get_namespace_prefix(pin_namespace_name    => 'User',
                         pout_namespace_id     => v_user_namespace_id,
                         pout_namespace_prefix => v_user_namespace_prefix);

    select DEF_TYPE_NAME_SINGULAR
      into v_definition_type_name
      from DEFINITION_TYPES
     where DEF_TYPE_ID = pin_object_type_id;
    v_technical_name := pin_folder_name || ' ' || v_definition_type_name || '_' ||
                        v_namespace_prefix;
    v_label          := nvl(pin_folder_label, pin_folder_name);
    v_folder_id      := uid_sequence.nextval;

    -- raise error if the folder name is longer than 26 characters (in case we may need to add ' SDM')
    if length(pin_folder_name) > 26 then
      raise_application_error(-20001,
                              'Folder ' || pin_folder_name ||
                              ' has a name over 26 characters.');
    end if;

    -- if there is another folder with the same business name we use that one, if not add the new system folder
    select count(*)
      into v_count
      from FOLDERS
     where upper(FOL_NAME) = upper(pin_folder_name);
    if v_count > 0 then
      update FOLDERS
         set FOL_TECHNICAL_NAME = v_technical_name
       where upper(FOL_NAME) = upper(pin_folder_name);
    else
      insert into FOLDERS
        (FOL_ID,
         FOL_NAME,
         FOL_CONTAINED_OBJ_TYPE_ID,
         OBJECT_VERSION,
         FOL_CONTAINER_ID,
         FOL_NAMESPACE_ID,
         FOL_TECHNICAL_NAME,
         FOL_LABEL)
      values
        (v_folder_id,
         pin_folder_name,
         pin_object_type_id,
         0,
         pin_container_id,
         v_namespace_id,
         v_technical_name,
         v_label);
    end if;

  end add_system_folder;

  procedure add_system_field(pin_fld_business_name          varchar2,
                             pin_fld_column_name            varchar2,
                             pin_fld_length                 number,
                             pin_fld_data_type              number,
                             pin_fld_timeunit               number,
                             pin_fld_base_field             number,
                             pin_fld_display_1000_separator number,
                             pin_fld_display_as_percent     number) as
    v_namespace_id     NAMESPACES.NAMESPACE_ID%type;
    v_namespace_prefix NAMESPACES.NAMESPACE_PREFIX%type;
    v_technical_name   FIELDS.FLD_TECHNICAL_NAME%type;
    v_business_name    FIELDS.FLD_BUSINESS_NAME%type;
    v_fld_id           number;
    v_count            integer;
  begin

    -- raise error if the field business name is longer than 26 characters (in case we may need to add ' SDM')
    if length(pin_fld_business_name) > 26 then
      raise_application_error(-20001,
                              'Field ' || pin_fld_business_name ||
                              ' has a name over 26 characters.');
    end if; -- procedura separata

    -- raise error if there is another system field with the same business name
    select count(*)
      into v_count
      from FIELDS
     where upper(FLD_TECHNICAL_NAME) = upper(v_technical_name);
    if v_count > 0 then
      raise_application_error(-20002,
                              'Field ' || pin_fld_business_name ||
                              ' already exists as a system field.');
    end if;

    -- raise error if there is another field with the same column name
    select count(*)
      into v_count
      from FIELDS
     where FLD_COLUMN_NAME = pin_fld_column_name;
    if v_count > 0 then
      raise_application_error(-20002,
                              'Column name ' || pin_fld_column_name ||
                              ' is already in use.');
    end if;

    get_namespace_prefix(pin_namespace_name    => 'System',
                         pout_namespace_id     => v_namespace_id,
                         pout_namespace_prefix => v_namespace_prefix);
    v_business_name  := pin_fld_business_name;
    v_technical_name := v_business_name || '_' || v_namespace_prefix;
    v_fld_id         := uid_sequence.nextval;

    -- if there is another user field with the same business name we rename the new system field
    v_business_name := get_new_object_name(pin_fld_business_name, 1);

    -- add the new system field
    insert into FIELDS
      (FLD_ID,
       FLD_BUSINESS_NAME,
       FLD_COLUMN_NAME,
       FLD_LENGTH,
       FLD_DATA_TYPE,
       FLD_TYPE,
       FLD_TIMEUNIT,
       FLD_IS_PREDEFINED,
       OBJECT_VERSION,
       FLD_BASE_FIELD,
       FLD_DISPLAY_THOUSAND_SEPARATOR,
       FLD_DISPLAY_AS_PERCENT,
       FLD_UNIQUE_INTERNAL_NAME,
       FLD_NAMESPACE_ID,
       FLD_TECHNICAL_NAME,
       FLD_LABEL)
    values
      (v_fld_id,
       v_business_name,
       pin_fld_column_name,
       pin_fld_length,
       pin_fld_data_type,
       1,
       pin_fld_timeunit,
       1,
       0,
       pin_fld_base_field,
       pin_fld_display_1000_separator,
       pin_fld_display_as_percent,
       v_business_name,
       v_namespace_id,
       v_technical_name,
       v_business_name);

  end add_system_field;

  procedure add_system_entity(pin_tx_id                varchar2,
                              pin_entity_name          varchar2,
                              pin_entity_category_type number,
                              pin_entity_fields        clob) as
    v_namespace_id                 NAMESPACES.NAMESPACE_ID%type;
    v_namespace_prefix             NAMESPACES.NAMESPACE_PREFIX%type;
    v_technical_name               ENTITIES.ENTITY_TECHNICAL_NAME%type;
    v_business_name                ENTITIES.ENTITY_NAME%type;
    v_entity_id                    number;
    v_count                        integer;
    v_entity_table_id              number;
    v_entity_table_name            varchar2(30); -- column type
    v_entity_table_business_name   varchar2(30);
    v_create_entity_table_clause   clob;
    v_drop_entity_table_clause     clob; -- varchar2 in loc de clob unde se poate
    v_row_id_seq                   varchar2(30);
    v_create_row_id_seq_clause     clob;
    v_drop_row_id_seq_clause       clob;
    v_entity_id_seq                varchar2(30);
    v_create_entity_id_seq_clause  clob;
    v_drop_entity_id_seq_clause    clob;
    v_entity_audit_id              number;
    v_entity_audit_name            varchar2(30);
    v_entity_audit_business_name   varchar2(30);
    v_create_entity_audit_clause   clob;
    v_drop_entity_audit_clause     clob;
    v_audit_row_id_seq             varchar2(30);
    v_create_aud_row_id_seq_clause clob;
    v_drop_aud_row_id_seq_clause   clob;
    v_entity_fields                coltype_tbl_cols_sdm;
    v_entity_audit_fields          coltype_tbl_cols_sdm;
    v_entity_index_cols            COLTYPE_COLS_TO_INDEX;
    v_entity_audit_index_cols      COLTYPE_COLS_TO_INDEX;
    v_entity_audit_index           tabletype_charmax := tabletype_charmax();
    v_entity_folder                number;
    V_INDEX_LOG                    CLOB;
    v_record_adjustment_type       FIELDS.FLD_ID%type;
    v_audit_order                  integer;
    v_index_status                 number; -- integer sau pls integer
  begin

    v_business_name := pin_entity_name;
    get_namespace_prefix(pin_namespace_name    => 'System',
                         pout_namespace_id     => v_namespace_id,
                         pout_namespace_prefix => v_namespace_prefix);
    v_technical_name := v_business_name || '_' || v_namespace_prefix;
    v_entity_id      := uid_sequence.nextval;
    v_entity_folder  := get_system_folder(12); -- exceptie in functie, get def type, par name

    -- raise error if the entity name is longer than 26 characters (in case we may need to add ' SDM')
    if length(v_business_name) > 26 then
      raise_application_error(-20001,
                              'Entity ' || v_business_name ||
                              ' has a name over 26 characters.');
    end if;

    -- raise error if there is another system entity with the same business name
    select count(*)
      into v_count
      from ENTITIES
     where upper(ENTITY_TECHNICAL_NAME) = upper(v_technical_name);
    if v_count > 0 then
      raise_application_error(-20002,
                              'Entity ' || v_business_name ||
                              ' already exists as a system entity.');
    end if;

    -- if there is another user entity with the same business name we rename the new system entity
    v_business_name := get_new_object_name(v_business_name, 12);

    -- set fields info
    PARSE_XML_TO_COLLECTION(PIN_XML_VALUE           => PIN_ENTITY_FIELDS,
                            PIN_TABLE_TYPE          => 1,
                            POUT_TABLES_COLLECTION  => V_ENTITY_FIELDS,
                            POUT_INDEXES_COLLECTION => V_ENTITY_INDEX_COLS);

    -- create entity table
    v_entity_table_id            := uid_sequence.nextval;
    v_entity_table_name          := 'T' || to_char(v_entity_table_id);
    v_entity_table_business_name := 'ENTITY_' || v_entity_id;
    build_create_table_clause(pin_table_name       => v_entity_table_name,
                              pin_fields           => v_entity_fields,
                              pout_ddl_clause      => v_create_entity_table_clause,
                              pout_undo_ddl_clause => v_drop_entity_table_clause);
    commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                     pi_description    => 'Create entity table for ' ||
                                                          pin_entity_name,
                                     pi_ddl            => v_create_entity_table_clause,
                                     pi_undo_ddl       => v_drop_entity_table_clause);

    -- create sequences for entity table
    v_row_id_seq := v_entity_table_name || '_ROW_IDENTIFIER_SEQ';
    build_create_seq_clause(pin_seq_name         => v_row_id_seq,
                            pout_ddl_clause      => v_create_row_id_seq_clause,
                            pout_undo_ddl_clause => v_drop_row_id_seq_clause);
    commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                     pi_description    => 'Create row identifier sequence for ' ||
                                                          pin_entity_name,
                                     pi_ddl            => v_create_row_id_seq_clause,
                                     pi_undo_ddl       => v_drop_row_id_seq_clause);
    v_entity_id_seq := v_entity_table_name || '_E_INTERNAL_ID_SEQ';
    build_create_seq_clause(pin_seq_name         => v_entity_id_seq,
                            pout_ddl_clause      => v_create_entity_id_seq_clause,
                            pout_undo_ddl_clause => v_drop_entity_id_seq_clause);
    commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                     pi_description    => 'Create entity id sequence for ' ||
                                                          pin_entity_name,
                                     pi_ddl            => v_create_entity_id_seq_clause,
                                     pi_undo_ddl       => v_drop_entity_id_seq_clause);

    -- create indexes for entity table
    create_indexes(pin_table_id           => v_entity_table_id,
                   pin_indexes_collection => v_entity_index_cols,
                   pin_transaction_id     => pin_tx_id,
                   pout_log_message       => v_index_log);

    -- register entity table
    register_table(pin_table_id            => v_entity_table_id,
                   pin_table_name          => v_entity_table_name,
                   pin_table_business_name => v_entity_table_business_name,
                   pin_table_type          => 1,
                   pin_object_id           => v_entity_id,
                   pin_row_id_seq          => v_row_id_seq,
                   pin_fields              => v_entity_fields);

    -- register dependencies for entity table
    register_dependencies(pin_definition_id   => v_entity_id,
                          pin_definition_type => 12,
                          pin_fields          => v_entity_fields);

    -- register relationships for entity table
    register_relationship(pin_definition_id => v_entity_id,
                          pin_category_id   => 3);

    -- register references for entity table
    register_reference(pin_definition_id        => v_entity_id,
                       pin_parent_definition_id => null,
                       pin_definition_name      => null);

    -- create audit table
    v_entity_audit_id            := uid_sequence.nextval;
    v_entity_audit_name          := 'T' || to_char(v_entity_audit_id);
    v_entity_audit_business_name := 'DATA_CHANGE_HISTORY_' ||
                                    v_entity_table_id;

    -- remove E_INTERNAL_ID from audit table
    -- add RECORD_ADJUSTMENT_TYPE, ADJUSTED_RECORD_ID, TABLE_XML_DATA, AUDIT_ID
    -- return exception
    select max(FLD_ID)
      into v_record_adjustment_type
      from FIELDS
     where FLD_COLUMN_NAME = 'RECORD_ADJUSTMENT_TYPE';
    select max(OTCS_TC_ORDER)
      into v_audit_order
      from table(v_entity_fields);

    select OBJTYPE_TBL_COLS_SDM(OTCS_TC_ID,
                                OTCS_TC_COLUMN_TYPE,
                                0,
                                OTCS_TC_FLD_ID,
                                case OTCS_TC_LOGIC_TYPE
                                  when 1 then
                                   2 -- pentru ca audit
                                  else
                                   OTCS_TC_LOGIC_TYPE
                                end,
                                OTCS_TC_ORDER,
                                OTCS_TC_PHYSICAL_NAME,
                                0,
                                OTCS_TC_ENTITY_ID,
                                OTCS_DISPLAY_ORDER,
                                null,
                                null)
      bulk collect
      into v_entity_audit_fields
      from table(v_entity_fields)
     where OTCS_TC_PHYSICAL_NAME != 'E_INTERNAL_ID'
    union all
    select OBJTYPE_TBL_COLS_SDM(null,
                                2,
                                1,
                                v_record_adjustment_type,
                                2,
                                v_audit_order + 1,
                                'RECORD_ADJUSTMENT_TYPE',
                                0,
                                null,
                                null,
                                null,
                                null)
      from dual
    union all
    select OBJTYPE_TBL_COLS_SDM(null,
                                3,
                                0,
                                null,
                                0,
                                v_audit_order + 2,
                                'ADJUSTED_RECORD_ID',
                                0,
                                null,
                                null,
                                null,
                                null)
      from dual
    union all
    select OBJTYPE_TBL_COLS_SDM(null,
                                3,
                                0,
                                null,
                                0,
                                v_audit_order + 3,
                                'TABLE_XML_DATA',
                                0,
                                null,
                                null,
                                null,
                                null)
      from dual
    union all
    select OBJTYPE_TBL_COLS_SDM(null,
                                3,
                                0,
                                null,
                                0,
                                v_audit_order + 4,
                                'AUDIT_ID',
                                0,
                                null,
                                null,
                                null,
                                null)
      from dual;

    build_create_table_clause(pin_table_name       => v_entity_audit_name,
                              pin_fields           => v_entity_audit_fields,
                              pout_ddl_clause      => v_create_entity_audit_clause,
                              pout_undo_ddl_clause => v_drop_entity_audit_clause);
    commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                     pi_description    => 'Create audit table for entity ' ||
                                                          pin_entity_name,
                                     pi_ddl            => v_create_entity_audit_clause,
                                     pi_undo_ddl       => v_drop_entity_audit_clause);

    -- create sequences for audit table
    v_audit_row_id_seq := v_entity_audit_name || '_ROW_IDENTIFIER_SEQ';
    build_create_seq_clause(pin_seq_name         => v_audit_row_id_seq,
                            pout_ddl_clause      => v_create_aud_row_id_seq_clause,
                            pout_undo_ddl_clause => v_drop_aud_row_id_seq_clause);
    commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                     pi_description    => 'Create row identifier sequence for audit table for ' ||
                                                          pin_entity_name,
                                     pi_ddl            => v_create_aud_row_id_seq_clause,
                                     pi_undo_ddl       => v_drop_aud_row_id_seq_clause);

    -- create indexes for audit table -- just on row identifier and (ADJUSTED_RECORD_ID, AUDIT_ID)
    select objtype_cols_to_index(OCTI_TC_PHYSICAL_NAME,
                                 OCTI_TC_LOGIC_TYPE,
                                 OCTI_TC_COLUMN_TYPE,
                                 OCTI_FLD_DATA_TYPE,
                                 OCTI_TC_IS_NULLABLE,
                                 OCTI_TC_ORDER)
      bulk collect
      into v_entity_audit_index_cols
      from table(v_entity_index_cols)
     where OCTI_TC_PHYSICAL_NAME = 'ROW_IDENTIFIER';
    create_indexes(pin_table_id           => v_entity_audit_id,
                   pin_indexes_collection => v_entity_audit_index_cols,
                   pin_transaction_id     => pin_tx_id,
                   pout_log_message       => v_index_log);
    v_entity_audit_index.extend;
    v_entity_audit_index(1) := 'ADJUSTED_RECORD_ID';
    v_entity_audit_index.EXTEND;
    v_entity_audit_index(2) := 'AUDIT_ID';
    commons_indexing.create_app_index(pi_tables_id                  => v_entity_audit_id,
                                      pi_column_list                => v_entity_audit_index,
                                      pi_is_unique                  => 0,
                                      pi_def_id                     => v_entity_audit_id,
                                      pi_business_name              => 'AUDIT',
                                      pi_recreate_index_on_col_drop => 0,
                                      pi_process_id                 => null,
                                      pi_run_id                     => null,
                                      pi_table_name                 => v_entity_audit_name,
                                      pi_transaction_id             => pin_tx_id,
                                      pi_index_tablespace_name      => user ||
                                                                       '_IND',
                                      po_index_creation_status      => v_index_status);

    -- register audit table
    register_table(pin_table_id            => v_entity_audit_id,
                   pin_table_name          => v_entity_audit_name,
                   pin_table_business_name => v_entity_audit_business_name,
                   pin_table_type          => 5,
                   pin_object_id           => null,
                   pin_row_id_seq          => v_audit_row_id_seq,
                   pin_fields              => v_entity_audit_fields);

    register_audit_table(pin_table_id       => v_entity_table_id,
                         pin_audit_table_id => v_entity_audit_id);

    -- register dependencies for audit table
    register_dependencies(pin_definition_id   => v_entity_audit_id,
                          pin_definition_type => 12,
                          pin_fields          => v_entity_audit_fields);

    -- register entity
    insert into ENTITIES
      (ENTITY_ID,
       ENTITY_NAME,
       ENTITY_CATEGORY_TYPE,
       ENTITY_IS_PREDEFINED,
       ENTITY_TABLES_ID,
       OBJECT_VERSION,
       ENTITY_CUSTOM_VERSION,
       ENTITY_BASE_ENTITY,
       ENTITY_FOL_ID,
       ENTITY_NAMESPACE_ID,
       ENTITY_TECHNICAL_NAME,
       ENTITY_LABEL)
    values
      (v_entity_id,
       v_business_name,
       pin_entity_category_type,
       1,
       v_entity_table_id,
       0,
       0,
       null,
       v_entity_folder,
       v_namespace_id,
       v_technical_name,
       v_business_name);

    -- register display fields
    insert into ENTITY_DISPLAY_FIELD
      (EDF_ID, EDF_ENTITY_ID, EDF_FLD_ID, EDF_ORDER)
      select ENTITY_DISPLAY_FIELD_SEQ.nextval,
             v_entity_id,
             OTCS_TC_FLD_ID,
             OTCS_DISPLAY_ORDER
        from table(v_entity_fields)
       where OTCS_DISPLAY_ORDER is not null;

  end add_system_entity;

  procedure add_system_hierarchy(pin_tx_id              varchar2,
                                 pin_hierarchy_name     varchar2,
                                 pin_time_unit_name     varchar2,
                                 pin_effective_dated    number,
                                 pin_hierarchy_elements coltype_hier_cols_sdm) as
    v_namespace_id                 NAMESPACES.NAMESPACE_ID%type;
    v_namespace_prefix             NAMESPACES.NAMESPACE_PREFIX%type;
    v_technical_name               HIERARCHY_TABLES.HT_TECHNICAL_NAME%type;
    v_business_name                HIERARCHY_TABLES.HT_NAME%type;
    v_hierarchy_id                 number;
    v_hierarchy_structure_id       number;
    v_hierarchy_top_node           HIERARCHY_NODE.HN_ID%type;
    v_hierarchy_node               HIERARCHY_NODE.HN_ID%type;
    v_parent_node                  HIERARCHY_NODE.HN_ID%type;
    v_count                        integer;
    v_hierarchy_table_id           number;
    v_hierarchy_table_name         varchar2(30);
    v_hierarchy_table_bus_name     varchar2(250);
    v_create_hier_table_clause     clob;
    v_drop_hierarchy_table_clause  clob;
    v_row_id_seq                   varchar2(30);
    v_create_row_id_seq_clause     clob;
    v_drop_row_id_seq_clause       clob;
    v_hierarchy_audit_id           number;
    v_hierarchy_audit_name         varchar2(30);
    v_hierarchy_audit_bus_name     varchar2(250);
    v_create_hier_audit_clause     clob;
    v_drop_hierarchy_audit_clause  clob;
    v_audit_row_id_seq             varchar2(30);
    v_create_aud_row_id_seq_clause clob;
    v_drop_aud_row_id_seq_clause   clob;
    v_hierarchy_fields             coltype_tbl_cols_sdm;
    v_hierarchy_table_fields       coltype_tbl_cols_sdm;
    v_hierarchy_audit_fields       coltype_tbl_cols_sdm;
    v_hierarchy_index_cols         coltype_cols_to_index;
    v_hierarchy_table_index_cols   coltype_cols_to_index;
    v_hierarchy_audit_index_cols   coltype_cols_to_index;
    v_hierarchy_audit_index        tabletype_charmax := tabletype_charmax();
    v_hierarchy_folder             number;
    v_index_log                    clob;
    v_record_adjustment_type       FIELDS.FLD_ID%type;
    v_audit_order                  integer;
    v_index_status                 number;
    v_base_lower_entity_id         number;
    v_base_upper_entity_id         number;
    v_lower_entity_id              ENTITIES.ENTITY_ID%type;
    v_upper_entity_id              ENTITIES.ENTITY_ID%type;
    v_lower_entity_name            ENTITIES.ENTITY_NAME%type;
    v_upper_entity_name            ENTITIES.ENTITY_NAME%type;
    v_lower_categ_type             ENTITIES.ENTITY_CATEGORY_TYPE%type;
    v_upper_categ_type             ENTITIES.ENTITY_CATEGORY_TYPE%type;
    v_lower_entity_table_id        ENTITIES.ENTITY_TABLES_ID%type;
    v_upper_entity_table_id        ENTITIES.ENTITY_TABLES_ID%type;
    v_time_unit_id                 TIME_UNITS.TU_ID%type;
    v_relationship_id              number;
    v_start_date                   FIELDS.FLD_ID%type;
    v_end_date                     FIELDS.FLD_ID%type;
    v_table_dating_option          TABLES.TABLES_RECORD_DATING_OPTION%type;
  begin

    v_business_name := pin_hierarchy_name;
    get_namespace_prefix(pin_namespace_name    => 'System',
                         pout_namespace_id     => v_namespace_id,
                         pout_namespace_prefix => v_namespace_prefix);
    v_technical_name   := v_business_name || '_' || v_namespace_prefix;
    v_hierarchy_folder := get_system_folder(15);

    -- raise error if the hierarchy name is longer than 26 characters (in case we may need to add ' SDM')
    if length(v_business_name) > 26 then
      raise_application_error(-20001,
                              'hierarchy ' || v_business_name ||
                              ' has a name over 26 characters.');
    end if;

    -- raise error if there is another system hierarchy with the same business name
    select count(*)
      into v_count
      from HIERARCHY_TABLES
     where upper(HT_TECHNICAL_NAME) = upper(v_technical_name);
    if v_count > 0 then
      raise_application_error(-20002,
                              'hierarchy ' || v_business_name ||
                              ' already exists as a system hierarchy.');
    end if;

    -- if there is another user hierarchy with the same business name we rename the new system hierarchy
    v_business_name := get_new_object_name(v_business_name, 15);

    -- register hierarchy
    v_hierarchy_id := uid_sequence.nextval;
    insert into HIERARCHY_TABLES
      (HT_ID,
       HT_NAME,
       HT_FOL_ID,
       OBJECT_VERSION,
       HT_NAMESPACE_ID,
       HT_TECHNICAL_NAME,
       HT_LABEL)
    values
      (v_hierarchy_id,
       v_business_name,
       v_hierarchy_folder,
       0,
       v_namespace_id,
       v_technical_name,
       v_business_name);

    -- register hierarchy structure
    v_hierarchy_structure_id := uid_sequence.nextval;
    if pin_time_unit_name is not null then
      select TU_ID
        into v_time_unit_id
        from TIME_UNITS
       where TU_NAME = pin_time_unit_name;
    end if;
    insert into HIERARCHY_STRUCTURE
      (HS_ID,
       HS_HT_ID,
       HS_IS_DATED,
       HS_TIMEUNIT_ID,
       OBJECT_VERSION,
       HS_IS_AUDITABLE)
    values
      (v_hierarchy_structure_id,
       v_hierarchy_id,
       pin_effective_dated,
       v_time_unit_id,
       0,
       1);

    -- parse all the relationships in the hierarchy
    for c in (select HIER_ORDER, HIER_FIELDS
                from table(pin_hierarchy_elements)
               order by HIER_ORDER) loop

      -- set fields info
      parse_xml_to_collection(pin_xml_value           => c.HIER_FIELDS,
                              pin_table_type          => 3,
                              pout_tables_collection  => v_hierarchy_fields,
                              pout_indexes_collection => v_hierarchy_index_cols);

      -- check if the lower node of the hierarchy has an equivalent entity
      select OTCS_TC_ENTITY_ID, ENTITY_CATEGORY_TYPE, ENTITY_TABLES_ID
        into v_base_lower_entity_id,
             v_lower_categ_type,
             v_lower_entity_table_id
        from table(v_hierarchy_fields)
        join ENTITIES
          on OTCS_TC_ENTITY_ID = ENTITY_ID
       where OTCS_IS_LOWER = 1;
      select count(*)
        into v_count
        from ENTITIES
       where ENTITY_BASE_ENTITY = v_base_lower_entity_id
         and ENTITY_NAME = '|~' || v_base_lower_entity_id || '~| Lower';
      -- if the lower node of the hierarchy does not have an equivalent entity we create it
      if v_count = 0 then
        v_lower_entity_id   := uid_sequence.nextval;
        v_lower_entity_name := '|~' || v_base_lower_entity_id || '~| Lower';
        insert into ENTITIES
          (ENTITY_ID,
           ENTITY_NAME,
           ENTITY_CATEGORY_TYPE,
           ENTITY_IS_PREDEFINED,
           ENTITY_TABLES_ID,
           OBJECT_VERSION,
           ENTITY_CUSTOM_VERSION,
           ENTITY_BASE_ENTITY,
           ENTITY_FOL_ID,
           ENTITY_NAMESPACE_ID,
           ENTITY_TECHNICAL_NAME,
           ENTITY_LABEL)
        values
          (v_lower_entity_id,
           v_lower_entity_name,
           v_lower_categ_type,
           1,
           v_lower_entity_table_id,
           0,
           0,
           v_base_lower_entity_id,
           null,
           v_namespace_id,
           v_lower_entity_name || '_' || v_namespace_prefix,
           v_lower_entity_name);
      else
        select ENTITY_ID
          into v_lower_entity_id
          from ENTITIES
         where ENTITY_BASE_ENTITY = v_base_lower_entity_id
           and ENTITY_NAME = '|~' || v_base_lower_entity_id || '~| Lower';
      end if;

      -- check if the upper node of the hierarchy has an equivalent entity
      select OTCS_TC_ENTITY_ID, ENTITY_CATEGORY_TYPE, ENTITY_TABLES_ID
        into v_base_upper_entity_id,
             v_upper_categ_type,
             v_upper_entity_table_id
        from table(v_hierarchy_fields)
        join ENTITIES
          on OTCS_TC_ENTITY_ID = ENTITY_ID
       where OTCS_IS_UPPER = 1;
      select count(*)
        into v_count
        from ENTITIES
       where ENTITY_BASE_ENTITY = v_base_upper_entity_id
         and ENTITY_NAME = '|~' || v_base_upper_entity_id || '~| Upper';
      -- if the upper node of the hierarchy does not have an equivalent entity we create it
      if v_count = 0 then
        v_upper_entity_id   := uid_sequence.nextval;
        v_upper_entity_name := '|~' || v_base_upper_entity_id || '~| Upper';
        insert into ENTITIES
          (ENTITY_ID,
           ENTITY_NAME,
           ENTITY_CATEGORY_TYPE,
           ENTITY_IS_PREDEFINED,
           ENTITY_TABLES_ID,
           OBJECT_VERSION,
           ENTITY_CUSTOM_VERSION,
           ENTITY_BASE_ENTITY,
           ENTITY_FOL_ID,
           ENTITY_NAMESPACE_ID,
           ENTITY_TECHNICAL_NAME,
           ENTITY_LABEL)
        values
          (v_upper_entity_id,
           v_upper_entity_name,
           v_upper_categ_type,
           1,
           v_upper_entity_table_id,
           0,
           0,
           v_base_upper_entity_id,
           null,
           v_namespace_id,
           v_upper_entity_name || '_' || v_namespace_prefix,
           v_upper_entity_name);
      else
        select ENTITY_ID
          into v_upper_entity_id
          from ENTITIES
         where ENTITY_BASE_ENTITY = v_base_upper_entity_id
           and ENTITY_NAME = '|~' || v_base_upper_entity_id || '~| Upper';
      end if;

      -- register top node
      if c.HIER_ORDER = 1 then
        v_hierarchy_top_node := hierarchy_node_seq.nextval;
        insert into HIERARCHY_NODE
          (HN_ID, HN_HS_ID, HN_PARENT_NODE_ID, HN_ENTITY_ID, HN_ORDER)
        values
          (v_hierarchy_top_node,
           v_hierarchy_structure_id,
           null,
           v_base_upper_entity_id,
           0);
      end if;

      -- register current node
      v_hierarchy_node := hierarchy_node_seq.nextval;
      select max(HN_ID)
        into v_parent_node
        from HIERARCHY_NODE
       where HN_HS_ID = v_hierarchy_structure_id;
      insert into HIERARCHY_NODE
        (HN_ID, HN_HS_ID, HN_PARENT_NODE_ID, HN_ENTITY_ID, HN_ORDER)
      values
        (v_hierarchy_node,
         v_hierarchy_structure_id,
         v_parent_node,
         v_base_lower_entity_id,
         0);

      -- create hierarchy table
      v_hierarchy_table_id       := uid_sequence.nextval;
      v_hierarchy_table_name     := 'T' || v_hierarchy_table_id;
      v_hierarchy_table_bus_name := '|~' || v_base_lower_entity_id ||
                                    '~| to |~' || v_base_upper_entity_id || '~|';

      -- build structure with effective dated fields
      if pin_effective_dated = 1 then
        select FLD_ID
          into v_start_date
          from FIELDS
         where FLD_COLUMN_NAME = 'START_DATE';
        select FLD_ID
          into v_end_date
          from FIELDS
         where FLD_COLUMN_NAME = 'END_DATE';

        -- ce fielduri
        select OBJTYPE_TBL_COLS_SDM(null,
                                    1,
                                    1,
                                    null,
                                    1,
                                    1,
                                    'E' || v_lower_entity_id,
                                    0,
                                    v_lower_entity_id,
                                    null,
                                    1,
                                    null)
          bulk collect
          into v_hierarchy_table_fields
          from dual
        union all
        select OBJTYPE_TBL_COLS_SDM(null,
                                    1,
                                    1,
                                    null,
                                    2,
                                    2,
                                    'E' || v_upper_entity_id,
                                    0,
                                    v_upper_entity_id,
                                    null,
                                    null,
                                    1)
          from dual
        union all
        select OBJTYPE_TBL_COLS_SDM(null,
                                    2,
                                    0,
                                    v_start_date,
                                    3,
                                    3,
                                    'START_DATE',
                                    0,
                                    null,
                                    null,
                                    null,
                                    null)
          from dual
        union all
        select OBJTYPE_TBL_COLS_SDM(null,
                                    2,
                                    0,
                                    v_end_date,
                                    4,
                                    4,
                                    'END_DATE',
                                    0,
                                    null,
                                    null,
                                    null,
                                    null)
          from dual
        union all
        select OBJTYPE_TBL_COLS_SDM(null,
                                    3,
                                    0,
                                    null,
                                    0,
                                    5,
                                    'ROW_IDENTIFIER',
                                    0,
                                    null,
                                    null,
                                    null,
                                    null)
          from dual
        union all
        select OBJTYPE_TBL_COLS_SDM(null,
                                    3,
                                    0,
                                    null,
                                    0,
                                    6,
                                    'ROW_VERSION',
                                    0,
                                    null,
                                    null,
                                    null,
                                    null)
          from dual;
      end if;

      build_create_table_clause(pin_table_name       => v_hierarchy_table_name,
                                pin_fields           => v_hierarchy_table_fields,
                                pout_ddl_clause      => v_create_hier_table_clause,
                                pout_undo_ddl_clause => v_drop_hierarchy_table_clause);
      commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                       pi_description    => 'Create hierarchy table for ' ||
                                                            pin_hierarchy_name,
                                       pi_ddl            => v_create_hier_table_clause,
                                       pi_undo_ddl       => v_drop_hierarchy_table_clause);

      -- create sequences for hierarchy table
      v_row_id_seq := v_hierarchy_table_name || '_ROW_IDENTIFIER_SEQ';
      build_create_seq_clause(pin_seq_name         => v_row_id_seq,
                              pout_ddl_clause      => v_create_row_id_seq_clause,
                              pout_undo_ddl_clause => v_drop_row_id_seq_clause);
      commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                       pi_description    => 'Create row identifier sequence for ' ||
                                                            pin_hierarchy_name,
                                       pi_ddl            => v_create_row_id_seq_clause,
                                       pi_undo_ddl       => v_drop_row_id_seq_clause);

      -- create indexes for hierarchy table
      select objtype_cols_to_index(OCTI_TC_PHYSICAL_NAME,
                                   OCTI_TC_LOGIC_TYPE,
                                   OCTI_TC_COLUMN_TYPE,
                                   OCTI_FLD_DATA_TYPE,
                                   OCTI_TC_IS_NULLABLE,
                                   1)
        bulk collect
        into v_hierarchy_table_index_cols
        from table(v_hierarchy_index_cols)
       where OCTI_TC_PHYSICAL_NAME = 'ROW_IDENTIFIER'
      union all
      select objtype_cols_to_index('E' || v_lower_entity_id,
                                   1,
                                   1,
                                   null,
                                   0,
                                   2)
        from dual
      union all
      select objtype_cols_to_index('E' || v_upper_entity_id,
                                   2,
                                   1,
                                   null,
                                   0,
                                   3)
        from dual
      union all
      select objtype_cols_to_index('E' || v_lower_entity_id,
                                   2,
                                   1,
                                   null,
                                   0,
                                   4)
        from dual
      union all
      select objtype_cols_to_index('START_DATE', 1, 2, null, 0, 5)
        from dual;
      create_indexes(pin_table_id           => v_hierarchy_table_id,
                     pin_indexes_collection => v_hierarchy_table_index_cols,
                     pin_transaction_id     => pin_tx_id,
                     pout_log_message       => v_index_log);

      -- register hierarchy table
      if pin_effective_dated = 1 then
        v_table_dating_option := 4;
      end if;
      register_table(pin_table_id            => v_hierarchy_table_id,
                     pin_table_name          => v_hierarchy_table_name,
                     pin_table_business_name => v_hierarchy_table_bus_name,
                     pin_table_type          => 4,
                     pin_object_id           => v_table_dating_option,
                     pin_row_id_seq          => v_row_id_seq,
                     pin_fields              => v_hierarchy_table_fields);

      -- register dependencies for hierarchy table
      register_dependencies(pin_definition_id   => v_hierarchy_table_id,
                            pin_definition_type => 2,
                            pin_fields          => v_hierarchy_fields);

      -- the hierarchy table also sets in use the equivalent entities
      -- tot in sp-ul clasic
      insert into DEPENDENCY_METADATA
        (DM_REFFERED_OBJECT_ID,
         DM_REFFERING_OBJECT_ID,
         DM_REFFERING_OBJECT_TYPE,
         DM_SUBGROUP_KEY)
      values
        (v_lower_entity_id, v_hierarchy_table_id, 2, null);
      insert into DEPENDENCY_METADATA
        (DM_REFFERED_OBJECT_ID,
         DM_REFFERING_OBJECT_ID,
         DM_REFFERING_OBJECT_TYPE,
         DM_SUBGROUP_KEY)
      values
        (v_upper_entity_id, v_hierarchy_table_id, 2, null);

      -- register references for the hierarchy table
      insert into TABLE_REFERENCES
        (TREF_ID,
         TREF_DEFINITION_ID,
         TREF_PARENT_DEFINITION_ID,
         TREF_DEFINITION_NAME,
         TREF_LAST_DELETED_SEED)
      values
        (uid_sequence.nextval,
         null,
         v_hierarchy_id,
         v_hierarchy_table_bus_name,
         0);

      -- register relationships for hierarchy table
      register_relationship(pin_definition_id        => v_hierarchy_table_id,
                            pin_category_id          => 4,
                            pin_parent_definition_id => v_hierarchy_id);

      -- register hierarchy relationship
      v_relationship_id := uid_sequence.nextval;
      insert into HIERARCHY_RELATIONSHIP
        (HR_ID,
         HR_HS_ID,
         HR_LOWER_ENTITY_ID,
         HR_HIGHER_ENTITY_ID,
         HR_TABLE_ID,
         HR_ORDER)
      values
        (v_relationship_id,
         v_hierarchy_structure_id,
         v_lower_entity_id,
         v_upper_entity_id,
         v_hierarchy_table_id,
         c.HIER_ORDER);

      -- create audit table
      v_hierarchy_audit_id       := uid_sequence.nextval;
      v_hierarchy_audit_name     := 'T' || to_char(v_hierarchy_audit_id);
      v_hierarchy_audit_bus_name := 'DATA_CHANGE_HISTORY_' ||
                                    v_hierarchy_table_id;
      select max(FLD_ID)
        into v_record_adjustment_type
        from FIELDS
       where FLD_COLUMN_NAME = 'RECORD_ADJUSTMENT_TYPE';
      select max(OTCS_TC_ORDER)
        into v_audit_order
        from table(v_hierarchy_table_fields);

      select OBJTYPE_TBL_COLS_SDM(OTCS_TC_ID,
                                  OTCS_TC_COLUMN_TYPE,
                                  OTCS_TC_IS_REQUIRED,
                                  OTCS_TC_FLD_ID,
                                  OTCS_TC_LOGIC_TYPE,
                                  OTCS_TC_ORDER,
                                  OTCS_TC_PHYSICAL_NAME,
                                  OTCS_TC_IS_PREDEFINED,
                                  OTCS_TC_ENTITY_ID,
                                  OTCS_DISPLAY_ORDER,
                                  OTCS_IS_LOWER,
                                  OTCS_IS_UPPER)
        bulk collect
        into v_hierarchy_audit_fields
        from table(v_hierarchy_table_fields)
      union all
      select OBJTYPE_TBL_COLS_SDM(null,
                                  2,
                                  1,
                                  v_record_adjustment_type,
                                  2,
                                  v_audit_order + 1,
                                  'RECORD_ADJUSTMENT_TYPE',
                                  0,
                                  null,
                                  null,
                                  null,
                                  null)
        from dual
      union all
      select OBJTYPE_TBL_COLS_SDM(null,
                                  3,
                                  0,
                                  null,
                                  0,
                                  v_audit_order + 2,
                                  'ADJUSTED_RECORD_ID',
                                  0,
                                  null,
                                  null,
                                  null,
                                  null)
        from dual
      union all
      select OBJTYPE_TBL_COLS_SDM(null,
                                  3,
                                  0,
                                  null,
                                  0,
                                  v_audit_order + 3,
                                  'TABLE_XML_DATA',
                                  0,
                                  null,
                                  null,
                                  null,
                                  null)
        from dual
      union all
      select OBJTYPE_TBL_COLS_SDM(null,
                                  3,
                                  0,
                                  null,
                                  0,
                                  v_audit_order + 4,
                                  'AUDIT_ID',
                                  0,
                                  null,
                                  null,
                                  null,
                                  null)
        from dual;

      build_create_table_clause(pin_table_name       => v_hierarchy_audit_name,
                                pin_fields           => v_hierarchy_audit_fields,
                                pout_ddl_clause      => v_create_hier_audit_clause,
                                pout_undo_ddl_clause => v_drop_hierarchy_audit_clause);
      commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                       pi_description    => 'Create audit table for hierarchy ' ||
                                                            pin_hierarchy_name,
                                       pi_ddl            => v_create_hier_audit_clause,
                                       pi_undo_ddl       => v_drop_hierarchy_audit_clause);

      -- create sequences for audit table
      v_audit_row_id_seq := v_hierarchy_audit_name || '_ROW_IDENTIFIER_SEQ';
      build_create_seq_clause(pin_seq_name         => v_audit_row_id_seq,
                              pout_ddl_clause      => v_create_aud_row_id_seq_clause,
                              pout_undo_ddl_clause => v_drop_aud_row_id_seq_clause);
      commons_ddl_handling.execute_ddl(pi_transaction_id => pin_tx_id,
                                       pi_description    => 'Create row identifier sequence for audit table for ' ||
                                                            pin_hierarchy_name,
                                       pi_ddl            => v_create_aud_row_id_seq_clause,
                                       pi_undo_ddl       => v_drop_aud_row_id_seq_clause);

      -- create indexes for audit table -- just on row identifier and (ADJUSTED_RECORD_ID, AUDIT_ID)
      select objtype_cols_to_index(OCTI_TC_PHYSICAL_NAME,
                                   OCTI_TC_LOGIC_TYPE,
                                   OCTI_TC_COLUMN_TYPE,
                                   OCTI_FLD_DATA_TYPE,
                                   OCTI_TC_IS_NULLABLE,
                                   OCTI_TC_ORDER)
        bulk collect
        into v_hierarchy_audit_index_cols
        from table(v_hierarchy_index_cols)
       where OCTI_TC_PHYSICAL_NAME = 'ROW_IDENTIFIER';
      create_indexes(pin_table_id           => v_hierarchy_audit_id,
                     pin_indexes_collection => v_hierarchy_audit_index_cols,
                     pin_transaction_id     => pin_tx_id,
                     pout_log_message       => v_index_log);
      v_hierarchy_audit_index.extend;
      v_hierarchy_audit_index(1) := 'ADJUSTED_RECORD_ID';
      v_hierarchy_audit_index.EXTEND;
      v_hierarchy_audit_index(2) := 'AUDIT_ID';
      commons_indexing.create_app_index(pi_tables_id                  => v_hierarchy_audit_id,
                                        pi_column_list                => v_hierarchy_audit_index,
                                        pi_is_unique                  => 0,
                                        pi_def_id                     => v_hierarchy_audit_id,
                                        pi_business_name              => 'AUDIT',
                                        pi_recreate_index_on_col_drop => 0,
                                        pi_process_id                 => null,
                                        pi_run_id                     => null,
                                        pi_table_name                 => v_hierarchy_audit_name,
                                        pi_transaction_id             => pin_tx_id,
                                        pi_index_tablespace_name      => user ||
                                                                         '_IND',
                                        po_index_creation_status      => v_index_status);

      -- register audit table
      register_table(pin_table_id            => v_hierarchy_audit_id,
                     pin_table_name          => v_hierarchy_audit_name,
                     pin_table_business_name => v_hierarchy_audit_bus_name,
                     pin_table_type          => 5,
                     pin_object_id           => null,
                     pin_row_id_seq          => v_audit_row_id_seq,
                     pin_fields              => v_hierarchy_audit_fields);

      register_audit_table(pin_table_id       => v_hierarchy_table_id,
                           pin_audit_table_id => v_hierarchy_audit_id);

      -- register dependencies for audit table
      register_dependencies(pin_definition_id   => v_hierarchy_audit_id,
                            pin_definition_type => 12,
                            pin_fields          => v_hierarchy_audit_fields);

    end loop;

  end add_system_hierarchy;

  PROCEDURE ADD_SYSTEM_DATA_TABLE(PIN_TX_ID     VARCHAR2,
                                  PIN_DT_NAME   VARCHAR2,
                                  PIN_DT_FIELDS CLOB) AS

    V_NAMESPACE_ID                 NAMESPACES.NAMESPACE_ID%TYPE;
    V_NAMESPACE_PREFIX             NAMESPACES.NAMESPACE_PREFIX%TYPE;
    V_TECHNICAL_NAME               ENTITIES.ENTITY_TECHNICAL_NAME%TYPE;
    V_BUSINESS_NAME                ENTITIES.ENTITY_NAME%TYPE;
    V_DT_ID                        NUMBER;
    V_COUNT                        INTEGER;
    V_DT_TABLE_ID                  NUMBER;
    V_DT_TABLE_NAME                VARCHAR2(30);
    V_DT_TABLE_BUSINESS_NAME       VARCHAR2(30);
    V_CREATE_DT_TABLE_CLAUSE       CLOB;
    V_DROP_DT_TABLE_CLAUSE         CLOB;
    V_ROW_ID_SEQ                   VARCHAR2(30);
    V_CREATE_ROW_ID_SEQ_CLAUSE     CLOB;
    V_DROP_ROW_ID_SEQ_CLAUSE       CLOB;
    V_DT_AUDIT_ID                  NUMBER;
    V_DT_AUDIT_NAME                VARCHAR2(30);
    V_DT_AUDIT_BUSINESS_NAME       VARCHAR2(30);
    V_CREATE_DT_AUDIT_CLAUSE       CLOB;
    V_DROP_DT_AUDIT_CLAUSE         CLOB;
    V_AUDIT_ROW_ID_SEQ             VARCHAR2(30);
    V_CREATE_AUD_ROW_ID_SEQ_CLAUSE CLOB;
    V_DROP_AUD_ROW_ID_SEQ_CLAUSE   CLOB;
    V_DT_FIELDS                    COLTYPE_TBL_COLS_SDM;
    V_DT_AUDIT_FIELDS              COLTYPE_TBL_COLS_SDM;
    V_DT_INDEX_COLS                COLTYPE_COLS_TO_INDEX;
    V_DT_FOLDER                    NUMBER;
    V_INDEX_LOG                    CLOB;
    V_RECORD_ADJUSTMENT_TYPE       FIELDS.FLD_ID%TYPE;
    V_AUDIT_ORDER                  INTEGER;
    V_DT_AUDIT_INDEX_COLS          COLTYPE_COLS_TO_INDEX;
    V_DT_AUDIT_INDEX               TABLETYPE_CHARMAX := TABLETYPE_CHARMAX();
    V_INDEX_STATUS                 NUMBER;
    V_EFFECTIVE_DATED              NUMBER;
    V_TIMEUNIT                     NUMBER;
  BEGIN

    V_BUSINESS_NAME := PIN_DT_NAME;

    GET_NAMESPACE_PREFIX(PIN_NAMESPACE_NAME    => 'System',
                         POUT_NAMESPACE_ID     => V_NAMESPACE_ID,
                         POUT_NAMESPACE_PREFIX => V_NAMESPACE_PREFIX);

    V_TECHNICAL_NAME := V_BUSINESS_NAME || '_' || V_NAMESPACE_PREFIX;

    -- RAISE ERROR IF THE DATA_TABLE NAME IS LONGER THAN 26 CHARACTERS (IN CASE WE MAY NEED TO ADD ' SDM')
    IF LENGTH(V_BUSINESS_NAME) > 26 THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'data_table ' || V_BUSINESS_NAME ||
                              ' has a name over 26 characters.');
    END IF;

    -- RAISE ERROR IF THERE IS ANOTHER SYSTEM DATA_TABLE WITH THE SAME BUSINESS NAME
    SELECT COUNT(*)
      INTO V_COUNT
      FROM DATA_TABLES
     WHERE UPPER(DT_TECHNICAL_NAME) = UPPER(V_TECHNICAL_NAME);
    IF V_COUNT > 0 THEN
      RAISE_APPLICATION_ERROR(-20002,
                              'data_table ' || V_BUSINESS_NAME ||
                              ' already exists as a system data_table.');
    END IF;

    -- IF THERE IS ANOTHER USER DATA_TABLE WITH THE SAME BUSINESS NAME WE RENAME THE NEW SYSTEM DATA_TABLE
    V_BUSINESS_NAME := GET_NEW_OBJECT_NAME(V_BUSINESS_NAME, 10);

    V_DT_ID     := UID_SEQUENCE.NEXTVAL;
    V_DT_FOLDER := GET_SYSTEM_FOLDER(10);

    -- SET FIELDS INFO
    PARSE_XML_TO_COLLECTION(PIN_XML_VALUE           => PIN_DT_FIELDS,
                            PIN_TABLE_TYPE          => 0,
                            POUT_TABLES_COLLECTION  => V_DT_FIELDS,
                            POUT_INDEXES_COLLECTION => V_DT_INDEX_COLS);

    -- CREATE DATA_TABLE TABLE
    V_DT_TABLE_ID            := UID_SEQUENCE.NEXTVAL;
    V_DT_TABLE_NAME          := 'T' || TO_CHAR(V_DT_TABLE_ID);
    V_DT_TABLE_BUSINESS_NAME := 'DATA_TABLE_' || V_DT_ID;
    BUILD_CREATE_TABLE_CLAUSE(PIN_TABLE_NAME       => V_DT_TABLE_NAME,
                              PIN_FIELDS           => V_DT_FIELDS,
                              POUT_DDL_CLAUSE      => V_CREATE_DT_TABLE_CLAUSE,
                              POUT_UNDO_DDL_CLAUSE => V_DROP_DT_TABLE_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create data_table table for ' ||
                                                          PIN_DT_NAME,
                                     PI_DDL            => V_CREATE_DT_TABLE_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_DT_TABLE_CLAUSE);

    -- CREATE SEQUENCES FOR DATA_TABLE TABLE
    V_ROW_ID_SEQ := V_DT_TABLE_NAME || '_ROW_IDENTIFIER_SEQ';
    BUILD_CREATE_SEQ_CLAUSE(PIN_SEQ_NAME         => V_ROW_ID_SEQ,
                            POUT_DDL_CLAUSE      => V_CREATE_ROW_ID_SEQ_CLAUSE,
                            POUT_UNDO_DDL_CLAUSE => V_DROP_ROW_ID_SEQ_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create row identifier sequence for ' ||
                                                          PIN_DT_NAME,
                                     PI_DDL            => V_CREATE_ROW_ID_SEQ_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_ROW_ID_SEQ_CLAUSE);

    -- CREATE INDEXES FOR DATA_TABLE TABLE
    CREATE_INDEXES(PIN_TABLE_ID           => V_DT_TABLE_ID,
                   PIN_INDEXES_COLLECTION => V_DT_INDEX_COLS,
                   PIN_TRANSACTION_ID     => PIN_TX_ID,
                   POUT_LOG_MESSAGE       => V_INDEX_LOG);
    -- REGISTER DATA_TABLE TABLE

    SELECT NVL(MAX(OTCS_TC_LOGIC_TYPE), 0), MAX(FLD_TIMEUNIT)
      INTO V_EFFECTIVE_DATED, V_TIMEUNIT
      FROM TABLE(V_DT_FIELDS)
      JOIN FIELDS
        ON FLD_ID = OTCS_TC_FLD_ID
     WHERE OTCS_TC_LOGIC_TYPE IN (3, 4, 6, 7, 8, 9);
    --
    REGISTER_TABLE(PIN_TABLE_ID            => V_DT_TABLE_ID,
                   PIN_TABLE_NAME          => V_DT_TABLE_NAME,
                   PIN_TABLE_BUSINESS_NAME => V_DT_TABLE_BUSINESS_NAME,
                   PIN_TABLE_TYPE          => 2,
                   PIN_OBJECT_ID           => V_DT_ID,
                   PIN_ROW_ID_SEQ          => V_ROW_ID_SEQ,
                   PIN_FIELDS              => V_DT_FIELDS,
                   PIN_DATE_OPTION         => CASE
                                                WHEN V_EFFECTIVE_DATED IN
                                                     (3, 4) THEN
                                                 4
                                                WHEN V_EFFECTIVE_DATED IN
                                                     (6, 7) THEN
                                                 5
                                                WHEN V_EFFECTIVE_DATED = 8 THEN
                                                 3
                                                WHEN V_EFFECTIVE_DATED = 9 THEN
                                                 2
                                                ELSE
                                                 1
                                              END,
                   PIN_TABLE_TU_PERIOD     => V_TIMEUNIT);
    -- REGISTER DEPENDENCIES FOR DATA_TABLE TABLE
    REGISTER_DEPENDENCIES(PIN_DEFINITION_ID   => V_DT_ID,
                          PIN_DEFINITION_TYPE => 10,
                          PIN_FIELDS          => V_DT_FIELDS);

    -- REGISTER RELATIONSHIPS FOR DATA_TABLE TABLE
    REGISTER_RELATIONSHIP(PIN_DEFINITION_ID => V_DT_ID,
                          PIN_CATEGORY_ID   => 2);

    -- REGISTER REFERENCES FOR DATA_TABLE TABLE
    REGISTER_REFERENCE(PIN_DEFINITION_ID        => V_DT_ID,
                       PIN_PARENT_DEFINITION_ID => NULL,
                       PIN_DEFINITION_NAME      => NULL);

    -- CREATE AUDIT TABLE
    V_DT_AUDIT_ID            := UID_SEQUENCE.NEXTVAL;
    V_DT_AUDIT_NAME          := 'T' || TO_CHAR(V_DT_AUDIT_ID);
    V_DT_AUDIT_BUSINESS_NAME := 'DATA_CHANGE_HISTORY_' || V_DT_TABLE_ID;

    -- ADD RECORD_ADJUSTMENT_TYPE, ADJUSTED_RECORD_ID, TABLE_XML_DATA, AUDIT_ID
    SELECT MAX(FLD_ID)
      INTO V_RECORD_ADJUSTMENT_TYPE
      FROM FIELDS
     WHERE FLD_COLUMN_NAME = 'RECORD_ADJUSTMENT_TYPE';
    SELECT MAX(OTCS_TC_ORDER) INTO V_AUDIT_ORDER FROM TABLE(V_DT_FIELDS);

    SELECT OBJTYPE_TBL_COLS_SDM(OTCS_TC_ID,
                                OTCS_TC_COLUMN_TYPE,
                                0,
                                OTCS_TC_FLD_ID,
                                CASE OTCS_TC_LOGIC_TYPE
                                  WHEN 1 THEN
                                   2
                                  ELSE
                                   OTCS_TC_LOGIC_TYPE
                                END,
                                OTCS_TC_ORDER,
                                OTCS_TC_PHYSICAL_NAME,
                                0,
                                OTCS_TC_ENTITY_ID,
                                OTCS_DISPLAY_ORDER,
                                NULL,
                                NULL)
      BULK COLLECT
      INTO V_DT_AUDIT_FIELDS
      FROM TABLE(V_DT_FIELDS)
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                2,
                                1,
                                V_RECORD_ADJUSTMENT_TYPE,
                                2,
                                V_AUDIT_ORDER + 1,
                                'RECORD_ADJUSTMENT_TYPE',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                3,
                                0,
                                NULL,
                                0,
                                V_AUDIT_ORDER + 2,
                                'ADJUSTED_RECORD_ID',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                3,
                                0,
                                NULL,
                                0,
                                V_AUDIT_ORDER + 3,
                                'TABLE_XML_DATA',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                3,
                                0,
                                NULL,
                                0,
                                V_AUDIT_ORDER + 4,
                                'AUDIT_ID',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL;

    BUILD_CREATE_TABLE_CLAUSE(PIN_TABLE_NAME       => V_DT_AUDIT_NAME,
                              PIN_FIELDS           => V_DT_AUDIT_FIELDS,
                              POUT_DDL_CLAUSE      => V_CREATE_DT_AUDIT_CLAUSE,
                              POUT_UNDO_DDL_CLAUSE => V_DROP_DT_AUDIT_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create audit table for entity ' ||
                                                          PIN_DT_NAME,
                                     PI_DDL            => V_CREATE_DT_AUDIT_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_DT_AUDIT_CLAUSE);

    -- CREATE SEQUENCES FOR AUDIT TABLE
    V_AUDIT_ROW_ID_SEQ := V_DT_AUDIT_NAME || '_ROW_IDENTIFIER_SEQ';
    BUILD_CREATE_SEQ_CLAUSE(PIN_SEQ_NAME         => V_AUDIT_ROW_ID_SEQ,
                            POUT_DDL_CLAUSE      => V_CREATE_AUD_ROW_ID_SEQ_CLAUSE,
                            POUT_UNDO_DDL_CLAUSE => V_DROP_AUD_ROW_ID_SEQ_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create row identifier sequence for audit table for ' ||
                                                          PIN_DT_NAME,
                                     PI_DDL            => V_CREATE_AUD_ROW_ID_SEQ_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_AUD_ROW_ID_SEQ_CLAUSE);

    -- CREATE INDEXES FOR AUDIT TABLE -- JUST ON ROW IDENTIFIER AND (ADJUSTED_RECORD_ID, AUDIT_ID)
    SELECT OBJTYPE_COLS_TO_INDEX(OCTI_TC_PHYSICAL_NAME,
                                 OCTI_TC_LOGIC_TYPE,
                                 OCTI_TC_COLUMN_TYPE,
                                 OCTI_FLD_DATA_TYPE,
                                 OCTI_TC_IS_NULLABLE,
                                 OCTI_TC_ORDER)
      BULK COLLECT
      INTO V_DT_AUDIT_INDEX_COLS
      FROM TABLE(V_DT_INDEX_COLS)
     WHERE OCTI_TC_PHYSICAL_NAME = 'ROW_IDENTIFIER';
    CREATE_INDEXES(PIN_TABLE_ID           => V_DT_AUDIT_ID,
                   PIN_INDEXES_COLLECTION => V_DT_AUDIT_INDEX_COLS,
                   PIN_TRANSACTION_ID     => PIN_TX_ID,
                   POUT_LOG_MESSAGE       => V_INDEX_LOG);
    V_DT_AUDIT_INDEX.EXTEND;
    V_DT_AUDIT_INDEX(1) := 'ADJUSTED_RECORD_ID';
    V_DT_AUDIT_INDEX.EXTEND;
    V_DT_AUDIT_INDEX(2) := 'AUDIT_ID';
    COMMONS_INDEXING.CREATE_APP_INDEX(PI_TABLES_ID                  => V_DT_AUDIT_ID,
                                      PI_COLUMN_LIST                => V_DT_AUDIT_INDEX,
                                      PI_IS_UNIQUE                  => 0,
                                      PI_DEF_ID                     => V_DT_AUDIT_ID,
                                      PI_BUSINESS_NAME              => 'AUDIT',
                                      PI_RECREATE_INDEX_ON_COL_DROP => 0,
                                      PI_PROCESS_ID                 => NULL,
                                      PI_RUN_ID                     => NULL,
                                      PI_TABLE_NAME                 => V_DT_AUDIT_NAME,
                                      PI_TRANSACTION_ID             => PIN_TX_ID,
                                      PI_INDEX_TABLESPACE_NAME      => USER ||
                                                                       '_IND',
                                      PO_INDEX_CREATION_STATUS      => V_INDEX_STATUS);

    -- REGISTER AUDIT TABLE
    REGISTER_TABLE(PIN_TABLE_ID            => V_DT_AUDIT_ID,
                   PIN_TABLE_NAME          => V_DT_AUDIT_NAME,
                   PIN_TABLE_BUSINESS_NAME => V_DT_AUDIT_BUSINESS_NAME,
                   PIN_TABLE_TYPE          => 5,
                   PIN_OBJECT_ID           => NULL,
                   PIN_ROW_ID_SEQ          => V_AUDIT_ROW_ID_SEQ,
                   PIN_FIELDS              => V_DT_AUDIT_FIELDS);

    REGISTER_AUDIT_TABLE(PIN_TABLE_ID       => V_DT_TABLE_ID,
                         PIN_AUDIT_TABLE_ID => V_DT_AUDIT_ID);

    -- REGISTER DEPENDENCIES FOR AUDIT TABLE
    REGISTER_DEPENDENCIES(PIN_DEFINITION_ID   => V_DT_AUDIT_ID,
                          PIN_DEFINITION_TYPE => 10,
                          PIN_FIELDS          => V_DT_AUDIT_FIELDS);

    INSERT INTO DATA_TABLES
      (DT_ID,
       DT_NAME,
       DT_FOL_ID,
       DT_TABLES_ID,
       OBJECT_VERSION,
       DT_NAMESPACE_ID,
       DT_TECHNICAL_NAME,
       DT_LABEL)
    VALUES
      (V_DT_ID,
       V_BUSINESS_NAME,
       V_DT_FOLDER,
       V_DT_TABLE_ID,
       0,
       V_NAMESPACE_ID,
       V_TECHNICAL_NAME,
       V_BUSINESS_NAME);

  END ADD_SYSTEM_DATA_TABLE;

  PROCEDURE ADD_SYSTEM_ASSIGNMENT(PIN_TX_ID              VARCHAR2,
                                  PIN_ASSIGNMENT_NAME    VARCHAR2,
                                  PIN_ASSIGNMENT_FIELDS  CLOB,
                                  PIN_LEFT_ASGN_ENTITY   VARCHAR2,
                                  PIN_IS_EFFECTIVE_DATED NUMBER) AS

    V_NAMESPACE_ID                 NAMESPACES.NAMESPACE_ID%TYPE;
    V_NAMESPACE_PREFIX             NAMESPACES.NAMESPACE_PREFIX%TYPE;
    V_TECHNICAL_NAME               ENTITIES.ENTITY_TECHNICAL_NAME%TYPE;
    V_BUSINESS_NAME                ENTITIES.ENTITY_NAME%TYPE;
    V_ASSIGNMENT_ID                NUMBER;
    V_COUNT                        INTEGER;
    V_ASSIGNMENT_TABLE_ID          NUMBER;
    V_ASSIGNMENT_TABLE_NAME        VARCHAR2(30);
    V_ASGN_TABLE_BUSINESS_NAME     VARCHAR2(30);
    V_CREATE_ASGN_TABLE_CLAUSE     CLOB;
    V_DROP_ASSIGNMENT_TABLE_CLAUSE CLOB;
    V_ROW_ID_SEQ                   VARCHAR2(30);
    V_CREATE_ROW_ID_SEQ_CLAUSE     CLOB;
    V_DROP_ROW_ID_SEQ_CLAUSE       CLOB;
    V_ASSIGNMENT_AUDIT_ID          NUMBER;
    V_ASSIGNMENT_AUDIT_NAME        VARCHAR2(30);
    V_ASGN_AUDIT_BUSINESS_NAME     VARCHAR2(30);
    V_CREATE_ASGN_AUDIT_CLAUSE     CLOB;
    V_DROP_ASSIGNMENT_AUDIT_CLAUSE CLOB;
    V_AUDIT_ROW_ID_SEQ             VARCHAR2(30);
    V_CREATE_AUD_ROW_ID_SEQ_CLAUSE CLOB;
    V_DROP_AUD_ROW_ID_SEQ_CLAUSE   CLOB;
    V_ASSIGNMENT_FIELDS            COLTYPE_TBL_COLS_SDM;
    V_ASSIGNMENT_AUDIT_FIELDS      COLTYPE_TBL_COLS_SDM;
    V_ASSIGNMENT_INDEX_COLS        COLTYPE_COLS_TO_INDEX;
    V_ASSIGNMENT_FOLDER            NUMBER;
    V_INDEX_LOG                    CLOB;
    V_RECORD_ADJUSTMENT_TYPE       FIELDS.FLD_ID%TYPE;
    V_AUDIT_ORDER                  INTEGER;
    V_ASSIGNMENT_AUDIT_INDEX_COLS  COLTYPE_COLS_TO_INDEX;
    V_ASSIGNMENT_AUDIT_INDEX       TABLETYPE_CHARMAX := TABLETYPE_CHARMAX();
    V_INDEX_STATUS                 NUMBER;
    V_LA_ENTITY_ID                 NUMBER(10);
    V_EFFECTIVE_DATED              NUMBER;
    V_TIMEUNIT                     NUMBER;
  BEGIN

    V_BUSINESS_NAME := PIN_ASSIGNMENT_NAME;
    GET_NAMESPACE_PREFIX(PIN_NAMESPACE_NAME    => 'System',
                         POUT_NAMESPACE_ID     => V_NAMESPACE_ID,
                         POUT_NAMESPACE_PREFIX => V_NAMESPACE_PREFIX);

    V_TECHNICAL_NAME := V_BUSINESS_NAME || '_' || V_NAMESPACE_PREFIX;
    -- RAISE ERROR IF THE DATA_TABLE NAME IS LONGER THAN 26 CHARACTERS (IN CASE WE MAY NEED TO ADD ' SDM')
    IF LENGTH(V_BUSINESS_NAME) > 26 THEN
      RAISE_APPLICATION_ERROR(-20001,
                              'assignment table ' || V_BUSINESS_NAME ||
                              ' has a name over 26 characters.');
    END IF;

    -- RAISE ERROR IF THERE IS ANOTHER SYSTEM DATA_TABLE WITH THE SAME BUSINESS NAME
    SELECT COUNT(*)
      INTO V_COUNT
      FROM DATA_TABLES
     WHERE UPPER(DT_TECHNICAL_NAME) = UPPER(V_TECHNICAL_NAME);
    IF V_COUNT > 0 THEN
      RAISE_APPLICATION_ERROR(-20002,
                              'assignment table ' || V_BUSINESS_NAME ||
                              ' already exists as a system assignment.');
    END IF;

    -- IF THERE IS ANOTHER USER DATA_TABLE WITH THE SAME BUSINESS NAME WE RENAME THE NEW SYSTEM DATA_TABLE
    V_BUSINESS_NAME := GET_NEW_OBJECT_NAME(V_BUSINESS_NAME, 9);

    V_ASSIGNMENT_ID     := UID_SEQUENCE.NEXTVAL;
    V_ASSIGNMENT_FOLDER := GET_SYSTEM_FOLDER(9);

    -- SET FIELDS INFO
    PARSE_XML_TO_COLLECTION(PIN_XML_VALUE           => PIN_ASSIGNMENT_FIELDS,
                            PIN_TABLE_TYPE          => 2,
                            POUT_TABLES_COLLECTION  => V_ASSIGNMENT_FIELDS,
                            POUT_INDEXES_COLLECTION => V_ASSIGNMENT_INDEX_COLS);

    -- CREATE DATA_TABLE TABLE
    V_ASSIGNMENT_TABLE_ID      := UID_SEQUENCE.NEXTVAL;
    V_ASSIGNMENT_TABLE_NAME    := 'T' || TO_CHAR(V_ASSIGNMENT_TABLE_ID);
    V_ASGN_TABLE_BUSINESS_NAME := 'ASSIGNMENT_TABLE' || V_ASSIGNMENT_ID;
    BUILD_CREATE_TABLE_CLAUSE(PIN_TABLE_NAME       => V_ASSIGNMENT_TABLE_NAME,
                              PIN_FIELDS           => V_ASSIGNMENT_FIELDS,
                              POUT_DDL_CLAUSE      => V_CREATE_ASGN_TABLE_CLAUSE,
                              POUT_UNDO_DDL_CLAUSE => V_DROP_ASSIGNMENT_TABLE_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create data_table table for ' ||
                                                          PIN_ASSIGNMENT_NAME,
                                     PI_DDL            => V_CREATE_ASGN_TABLE_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_ASSIGNMENT_TABLE_CLAUSE);

    -- CREATE SEQUENCES FOR DATA_TABLE TABLE
    V_ROW_ID_SEQ := V_ASSIGNMENT_TABLE_NAME || '_ROW_IDENTIFIER_SEQ';
    BUILD_CREATE_SEQ_CLAUSE(PIN_SEQ_NAME         => V_ROW_ID_SEQ,
                            POUT_DDL_CLAUSE      => V_CREATE_ROW_ID_SEQ_CLAUSE,
                            POUT_UNDO_DDL_CLAUSE => V_DROP_ROW_ID_SEQ_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create row identifier sequence for ' ||
                                                          PIN_ASSIGNMENT_NAME,
                                     PI_DDL            => V_CREATE_ROW_ID_SEQ_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_ROW_ID_SEQ_CLAUSE);

    -- CREATE INDEXES FOR DATA_TABLE TABLE
    CREATE_INDEXES(PIN_TABLE_ID           => V_ASSIGNMENT_TABLE_ID,
                   PIN_INDEXES_COLLECTION => V_ASSIGNMENT_INDEX_COLS,
                   PIN_TRANSACTION_ID     => PIN_TX_ID,
                   POUT_LOG_MESSAGE       => V_INDEX_LOG);
    -- REGISTER DATA_TABLE TABLE
    SELECT NVL(MAX(OTCS_TC_LOGIC_TYPE), 0), MAX(FLD_TIMEUNIT)
      INTO V_EFFECTIVE_DATED, V_TIMEUNIT
      FROM TABLE(V_ASSIGNMENT_FIELDS)
      JOIN FIELDS
        ON FLD_ID = OTCS_TC_FLD_ID
     WHERE OTCS_TC_LOGIC_TYPE IN (3, 4, 6, 7, 8, 9);
    --
    REGISTER_TABLE(PIN_TABLE_ID            => V_ASSIGNMENT_TABLE_ID,
                   PIN_TABLE_NAME          => V_ASSIGNMENT_TABLE_NAME,
                   PIN_TABLE_BUSINESS_NAME => V_ASGN_TABLE_BUSINESS_NAME,
                   PIN_TABLE_TYPE          => 3,
                   PIN_OBJECT_ID           => V_ASSIGNMENT_ID,
                   PIN_ROW_ID_SEQ          => V_ROW_ID_SEQ,
                   PIN_FIELDS              => V_ASSIGNMENT_FIELDS,
                   PIN_DATE_OPTION         => CASE
                                                WHEN V_EFFECTIVE_DATED IN
                                                     (3, 4) AND
                                                     PIN_IS_EFFECTIVE_DATED = 1 THEN
                                                 4
                                                WHEN V_EFFECTIVE_DATED IN
                                                     (6, 7) AND
                                                     PIN_IS_EFFECTIVE_DATED = 1 THEN
                                                 5
                                                WHEN V_EFFECTIVE_DATED = 8 AND
                                                     PIN_IS_EFFECTIVE_DATED = 1 THEN
                                                 3
                                                WHEN V_EFFECTIVE_DATED = 9 AND
                                                     PIN_IS_EFFECTIVE_DATED = 1 THEN
                                                 2
                                                ELSE
                                                 1
                                              END,
                   PIN_TABLE_TU_PERIOD     => V_TIMEUNIT);

    -- REGISTER DEPENDENCIES FOR DATA_TABLE TABLE
    REGISTER_DEPENDENCIES(PIN_DEFINITION_ID   => V_ASSIGNMENT_ID,
                          PIN_DEFINITION_TYPE => 9,
                          PIN_FIELDS          => V_ASSIGNMENT_FIELDS);

    -- REGISTER RELATIONSHIPS FOR DATA_TABLE TABLE
    REGISTER_RELATIONSHIP(PIN_DEFINITION_ID => V_ASSIGNMENT_ID,
                          PIN_CATEGORY_ID   => 1);

    -- REGISTER REFERENCES FOR DATA_TABLE TABLE
    REGISTER_REFERENCE(PIN_DEFINITION_ID        => V_ASSIGNMENT_ID,
                       PIN_PARENT_DEFINITION_ID => NULL,
                       PIN_DEFINITION_NAME      => NULL);

    -- CREATE AUDIT TABLE
    V_ASSIGNMENT_AUDIT_ID      := UID_SEQUENCE.NEXTVAL;
    V_ASSIGNMENT_AUDIT_NAME    := 'T' || TO_CHAR(V_ASSIGNMENT_AUDIT_ID);
    V_ASGN_AUDIT_BUSINESS_NAME := 'DATA_CHANGE_HISTORY_' ||
                                  V_ASSIGNMENT_TABLE_ID;

    -- ADD RECORD_ADJUSTMENT_TYPE, ADJUSTED_RECORD_ID, TABLE_XML_DATA, AUDIT_ID
    SELECT MAX(FLD_ID)
      INTO V_RECORD_ADJUSTMENT_TYPE
      FROM FIELDS
     WHERE FLD_COLUMN_NAME = 'RECORD_ADJUSTMENT_TYPE';
    SELECT MAX(OTCS_TC_ORDER)
      INTO V_AUDIT_ORDER
      FROM TABLE(V_ASSIGNMENT_FIELDS);

    SELECT OBJTYPE_TBL_COLS_SDM(OTCS_TC_ID,
                                OTCS_TC_COLUMN_TYPE,
                                0,
                                OTCS_TC_FLD_ID,
                                CASE OTCS_TC_LOGIC_TYPE
                                  WHEN 1 THEN
                                   2
                                  ELSE
                                   OTCS_TC_LOGIC_TYPE
                                END,
                                OTCS_TC_ORDER,
                                OTCS_TC_PHYSICAL_NAME,
                                0,
                                OTCS_TC_ENTITY_ID,
                                OTCS_DISPLAY_ORDER,
                                NULL,
                                NULL)
      BULK COLLECT
      INTO V_ASSIGNMENT_AUDIT_FIELDS
      FROM TABLE(V_ASSIGNMENT_FIELDS)
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                2,
                                1,
                                V_RECORD_ADJUSTMENT_TYPE,
                                2,
                                V_AUDIT_ORDER + 1,
                                'RECORD_ADJUSTMENT_TYPE',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                3,
                                0,
                                NULL,
                                0,
                                V_AUDIT_ORDER + 2,
                                'ADJUSTED_RECORD_ID',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                3,
                                0,
                                NULL,
                                0,
                                V_AUDIT_ORDER + 3,
                                'TABLE_XML_DATA',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL
    UNION ALL
    SELECT OBJTYPE_TBL_COLS_SDM(NULL,
                                3,
                                0,
                                NULL,
                                0,
                                V_AUDIT_ORDER + 4,
                                'AUDIT_ID',
                                0,
                                NULL,
                                NULL,
                                NULL,
                                NULL)
      FROM DUAL;

    BUILD_CREATE_TABLE_CLAUSE(PIN_TABLE_NAME       => V_ASSIGNMENT_AUDIT_NAME,
                              PIN_FIELDS           => V_ASSIGNMENT_AUDIT_FIELDS,
                              POUT_DDL_CLAUSE      => V_CREATE_ASGN_AUDIT_CLAUSE,
                              POUT_UNDO_DDL_CLAUSE => V_DROP_ASSIGNMENT_AUDIT_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create audit table for entity ' ||
                                                          PIN_ASSIGNMENT_NAME,
                                     PI_DDL            => V_CREATE_ASGN_AUDIT_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_ASSIGNMENT_AUDIT_CLAUSE);

    -- CREATE SEQUENCES FOR AUDIT TABLE
    V_AUDIT_ROW_ID_SEQ := V_ASSIGNMENT_AUDIT_NAME || '_ROW_IDENTIFIER_SEQ';
    BUILD_CREATE_SEQ_CLAUSE(PIN_SEQ_NAME         => V_AUDIT_ROW_ID_SEQ,
                            POUT_DDL_CLAUSE      => V_CREATE_AUD_ROW_ID_SEQ_CLAUSE,
                            POUT_UNDO_DDL_CLAUSE => V_DROP_AUD_ROW_ID_SEQ_CLAUSE);
    COMMONS_DDL_HANDLING.EXECUTE_DDL(PI_TRANSACTION_ID => PIN_TX_ID,
                                     PI_DESCRIPTION    => 'Create row identifier sequence for audit table for ' ||
                                                          PIN_ASSIGNMENT_NAME,
                                     PI_DDL            => V_CREATE_AUD_ROW_ID_SEQ_CLAUSE,
                                     PI_UNDO_DDL       => V_DROP_AUD_ROW_ID_SEQ_CLAUSE);

    -- CREATE INDEXES FOR AUDIT TABLE -- JUST ON ROW IDENTIFIER AND (ADJUSTED_RECORD_ID, AUDIT_ID)
    SELECT OBJTYPE_COLS_TO_INDEX(OCTI_TC_PHYSICAL_NAME,
                                 OCTI_TC_LOGIC_TYPE,
                                 OCTI_TC_COLUMN_TYPE,
                                 OCTI_FLD_DATA_TYPE,
                                 OCTI_TC_IS_NULLABLE,
                                 OCTI_TC_ORDER)
      BULK COLLECT
      INTO V_ASSIGNMENT_AUDIT_INDEX_COLS
      FROM TABLE(V_ASSIGNMENT_INDEX_COLS)
     WHERE OCTI_TC_PHYSICAL_NAME = 'ROW_IDENTIFIER';
    CREATE_INDEXES(PIN_TABLE_ID           => V_ASSIGNMENT_AUDIT_ID,
                   PIN_INDEXES_COLLECTION => V_ASSIGNMENT_AUDIT_INDEX_COLS,
                   PIN_TRANSACTION_ID     => PIN_TX_ID,
                   POUT_LOG_MESSAGE       => V_INDEX_LOG);
    V_ASSIGNMENT_AUDIT_INDEX.EXTEND;
    V_ASSIGNMENT_AUDIT_INDEX(1) := 'ADJUSTED_RECORD_ID';
    V_ASSIGNMENT_AUDIT_INDEX.EXTEND;
    V_ASSIGNMENT_AUDIT_INDEX(2) := 'AUDIT_ID';
    COMMONS_INDEXING.CREATE_APP_INDEX(PI_TABLES_ID                  => V_ASSIGNMENT_AUDIT_ID,
                                      PI_COLUMN_LIST                => V_ASSIGNMENT_AUDIT_INDEX,
                                      PI_IS_UNIQUE                  => 0,
                                      PI_DEF_ID                     => V_ASSIGNMENT_AUDIT_ID,
                                      PI_BUSINESS_NAME              => 'AUDIT',
                                      PI_RECREATE_INDEX_ON_COL_DROP => 0,
                                      PI_PROCESS_ID                 => NULL,
                                      PI_RUN_ID                     => NULL,
                                      PI_TABLE_NAME                 => V_ASSIGNMENT_AUDIT_NAME,
                                      PI_TRANSACTION_ID             => PIN_TX_ID,
                                      PI_INDEX_TABLESPACE_NAME      => USER ||
                                                                       '_IND',
                                      PO_INDEX_CREATION_STATUS      => V_INDEX_STATUS);

    -- REGISTER AUDIT TABLE
    REGISTER_TABLE(PIN_TABLE_ID            => V_ASSIGNMENT_AUDIT_ID,
                   PIN_TABLE_NAME          => V_ASSIGNMENT_AUDIT_NAME,
                   PIN_TABLE_BUSINESS_NAME => V_ASGN_AUDIT_BUSINESS_NAME,
                   PIN_TABLE_TYPE          => 5,
                   PIN_OBJECT_ID           => NULL,
                   PIN_ROW_ID_SEQ          => V_AUDIT_ROW_ID_SEQ,
                   PIN_FIELDS              => V_ASSIGNMENT_AUDIT_FIELDS);

    REGISTER_AUDIT_TABLE(PIN_TABLE_ID       => V_ASSIGNMENT_TABLE_ID,
                         PIN_AUDIT_TABLE_ID => V_ASSIGNMENT_AUDIT_ID);

    -- REGISTER DEPENDENCIES FOR AUDIT TABLE
    REGISTER_DEPENDENCIES(PIN_DEFINITION_ID   => V_ASSIGNMENT_AUDIT_ID,
                          PIN_DEFINITION_TYPE => 9,
                          PIN_FIELDS          => V_ASSIGNMENT_AUDIT_FIELDS);

    SELECT ENTITY_ID
      INTO V_LA_ENTITY_ID
      FROM ENTITIES
     WHERE PIN_LEFT_ASGN_ENTITY = ENTITY_TECHNICAL_NAME;

    INSERT INTO ENTITY_ASSIGNMENTS
      (EA_ID,
       EA_FOL_ID,
       EA_NAME,
       EA_ENTITY_ID_LA,
       EA_IS_EFFECTIVE_DATED,
       EA_TABLES_ID,
       OBJECT_VERSION,
       EA_NAMESPACE_ID,
       EA_TECHNICAL_NAME,
       EA_LABEL)
    VALUES
      (V_ASSIGNMENT_ID,
       V_ASSIGNMENT_FOLDER,
       V_BUSINESS_NAME,
       V_LA_ENTITY_ID,
       PIN_IS_EFFECTIVE_DATED,
       V_ASSIGNMENT_TABLE_ID,
       0,
       V_NAMESPACE_ID,
       V_TECHNICAL_NAME,
       V_BUSINESS_NAME);

    INSERT INTO SECONDARY_ASSIGNMENTS
      (SA_ID, SA_EA_ID, SA_ENTITY_ID, SA_ORDER)
      SELECT UID_SEQUENCE.NEXTVAL,
             V_ASSIGNMENT_ID,
             OTCS_TC_ENTITY_ID,
             ROWN - 1
        FROM (SELECT V_ASSIGNMENT_ID, OTCS_TC_ENTITY_ID, ROWNUM ROWN
                FROM TABLE(V_ASSIGNMENT_FIELDS)
               where OTCS_TC_ENTITY_ID IS NOT NULL
                 AND OTCS_TC_ENTITY_ID <> V_LA_ENTITY_ID
               ORDER BY OTCS_TC_ENTITY_ID);

  END ADD_SYSTEM_ASSIGNMENT;

  function get_new_field_name(pin_fld_business_name varchar2) return varchar2 as
    v_business_name   FIELDS.FLD_BUSINESS_NAME%type;
    v_metadata_table  varchar2(30) := 'FIELDS';
    v_metadata_column varchar2(30) := 'FLD_BUSINESS_NAME';
  begin
    v_business_name := pin_fld_business_name;

    -- if there is another user field with the same business name we rename the new system field
    execute immediate '
    declare
      v_count integer;
      v_business_name varchar2(30) := ''' ||
                      v_business_name || ''';
      v_new_business_name varchar2(30);
    begin
      for c in (select ' || v_metadata_column ||
                      ' from ' || v_metadata_table || ' where upper(' ||
                      v_metadata_column || ') = upper(v_business_name)) loop
        v_new_business_name := v_business_name;
        for d in (select ' || v_metadata_column ||
                      ' from ' || v_metadata_table || ' where upper(' ||
                      v_metadata_column ||
                      ') = upper(v_new_business_name)) loop
          for i in 1..99 loop
            if i > 1 then
              v_new_business_name := substr(v_new_business_name,1,length(v_new_business_name) - length(to_char(i-1)));
            end if;
            if length(v_new_business_name) >= 30 or (i > 9 and length(v_new_business_name) >= 29) then
              v_new_business_name := substr(v_new_business_name,1,30 - length(to_char(i)));
            end if;
            v_new_business_name := v_new_business_name || to_char(i);
            select count(*) into v_count from ' ||
                      v_metadata_table || ' where upper(' ||
                      v_metadata_column || ') = upper(v_new_business_name);
            if v_count = 0 then
              v_business_name := v_new_business_name;
            end if;
            exit when v_count = 0;
          end loop;
        end loop;
        v_business_name := v_new_business_name;
      end loop;
      :a := v_business_name;
    end;'
      using in out v_business_name;

    return v_business_name;

  end get_new_field_name;

  -- ========================================================
  PROCEDURE ADD_ENTITY_DISPLAY_FIELDS(pin_entity_qualified_name VARCHAR2,
                                      pin_display_fields_list   CLOB) IS
    v_entity_id        NUMBER;
    v_entity_table_id  NUMBER;
    v_entity_max_order NUMBER;
  BEGIN
    BEGIN
      SELECT ENTITY_ID, ENTITY_TABLES_ID
        INTO v_entity_id, v_entity_table_id
        FROM ENTITIES
       WHERE ENTITY_TECHNICAL_NAME = pin_entity_qualified_name;

      SELECT MAX(EDF_ORDER)
        INTO v_entity_max_order
        FROM ENTITY_DISPLAY_FIELD
       WHERE EDF_ENTITY_ID = v_entity_id;
    EXCEPTION
      WHEN no_data_found THEN
        RAISE_APPLICATION_ERROR(-20001,
                                'Entity ' || pin_entity_qualified_name ||
                                ' has not been found.');
    END;

    FOR c IN (SELECT PDF_TECHNICAL_NAME,
                     PDF_COUNT,
                     F.FLD_ID,
                     TC.TC_FLD_ID,
                     ROW_NUMBER() OVER(PARTITION BY NULL ORDER BY PDF_DISPLAY_ORDER) AS DISPLAY_ORDER
                FROM (SELECT PDF_TECHNICAL_NAME,
                             PDF_DISPLAY_ORDER,
                             COUNT(*) OVER(PARTITION BY PDF_TECHNICAL_NAME) AS PDF_COUNT
                        FROM XMLTABLE('/display_fields/field' PASSING
                                      XMLTYPE(pin_display_fields_list)
                                      COLUMNS PDF_TECHNICAL_NAME
                                      VARCHAR2(200 CHAR) PATH
                                      'technical_name',
                                      PDF_DISPLAY_ORDER NUMBER PATH
                                      'display_order') EDF) PDF
                LEFT JOIN FIELDS F
                  ON PDF.PDF_TECHNICAL_NAME = F.FLD_TECHNICAL_NAME
                LEFT JOIN TABLE_COLUMNS TC
                  ON TC.TC_TABLES_ID = v_entity_table_id
                 AND F.FLD_ID = TC.TC_FLD_ID
               WHERE NOT EXISTS (SELECT 1
                        FROM ENTITY_DISPLAY_FIELD EDF
                       WHERE EDF_ENTITY_ID = v_entity_id
                         AND EDF_FLD_ID = F.FLD_ID)
               ORDER BY PDF_DISPLAY_ORDER) LOOP
      IF (c.PDF_COUNT > 1) THEN
        RAISE_APPLICATION_ERROR(-20001,
                                'Field ' || c.PDF_TECHNICAL_NAME ||
                                ' has been specified more than once.');
      ELSIF (c.FLD_ID IS NULL) THEN
        RAISE_APPLICATION_ERROR(-20001,
                                'Field ' || c.PDF_TECHNICAL_NAME ||
                                ' has not been found.');
      ELSIF (c.TC_FLD_ID IS NULL) THEN
        RAISE_APPLICATION_ERROR(-20001,
                                'Field ' || c.PDF_TECHNICAL_NAME ||
                                ' is not part of the entity structure.');
      ELSE
        INSERT INTO ENTITY_DISPLAY_FIELD
          (EDF_ID, EDF_ENTITY_ID, EDF_FLD_ID, EDF_ORDER)
        VALUES
          (ENTITY_DISPLAY_FIELD_SEQ.NEXTVAL,
           v_entity_id,
           c.FLD_ID,
           v_entity_max_order + c.DISPLAY_ORDER);
      END IF;
    END LOOP;

  END ADD_ENTITY_DISPLAY_FIELDS;
  PROCEDURE ADD_CDM_TIME_UNIT_CORR(PI_TU_NAME VARCHAR2) is
    CURSOR C_GET_TU_LHS(P_TU_NAME varchar2) IS
      SELECT * FROM TIME_UNITS WHERE TU_NAME = P_TU_NAME;

    CURSOR C_GET_TU_RHS(P_TU_NAME varchar2) IS
      SELECT * FROM TIME_UNITS WHERE TU_NAME = P_TU_NAME;

    V_TUP_ID   NUMBER(10);
    V_TUP_NAME VARCHAR(30);

    V_TUP_ID_CORR   NUMBER(10);
    V_TUP_NAME_CORR VARCHAR(30);

    /*V_OFFSET      NUMBER(10);
    V_OFFSET_CORR NUMBER(10);*/

    CURSOR C_GET_TU_PERIOD_LHS(P_TU_ID varchar2) IS
      SELECT TUP_ID, TUP_NAME /*INTO V_TUP_ID,V_TUP_NAME*/
        FROM TU_PERIODS TUP
       WHERE TUP.TUP_TU_ID = P_TU_ID;

    CURSOR C_GET_TU_PERIOD_RHS(P_TU_ID varchar2) IS
      SELECT TUP_ID, TUP_NAME /*INTO V_TUP_ID_CORR,V_TUP_NAME_CORR */
        FROM TU_PERIODS TUP
       WHERE TUP.TUP_TU_ID = P_TU_ID;

    V_TUC_ID    NUMBER(10);
    v_TU_status NUMBER(1) := 0;
    V_TPC_ID    NUMBER(10);
  begin
    FOR C_LHS IN C_GET_TU_LHS(PI_TU_NAME) LOOP
      -----Loop to iterate though the internal collection that defines basic correspondence
      FOR C IN 1 .. v_tu_corr_tab.COUNT LOOP
        v_TU_status := 0;
        -----checking if the TU is a primary

        IF (v_tu_corr_tab(C).OTC_NAME = PI_TU_NAME) THEN

          /* --dbms_output.put_line(v_tu_corr_tab(C).OTC_NAME);*/
          ------if TU is primary then check its correspondance secondary TU is defined in the system
          FOR C_RHS IN C_GET_TU_RHS(v_tu_corr_tab(C).OTC_NAME_CORR) LOOP

            ----take out periods for the primary TU defined in the system
            for C_TU_PERIOD_LHS IN C_GET_TU_PERIOD_LHS(C_LHS.TU_ID) LOOP

              V_TUP_ID   := C_TU_PERIOD_LHS.TUP_ID;
              V_TUP_NAME := C_TU_PERIOD_LHS.TUP_NAME;

              -----take out periods for the secondary TU defined in the system
              for C_TU_PERIOD_RHS IN C_GET_TU_PERIOD_RHS(C_RHS.TU_ID) LOOP
                V_TUP_ID_CORR   := C_TU_PERIOD_RHS.TUP_ID;
                V_TUP_NAME_CORR := C_TU_PERIOD_RHS.TUP_NAME;

                -----iterate through our object structure to find the correct set to insert
                FOR CTP IN 1 .. v_tu_periods_corr_tab.COUNT LOOP

                  IF (v_tu_periods_corr_tab(CTP)
                     .OTPC_NAME = V_TUP_NAME AND v_tu_periods_corr_tab(CTP)
                     .OTPC_CORR_NAME = V_TUP_NAME_CORR /*AND v_tu_periods_corr_tab(CTP)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       .OTPC_START = V_OFFSET AND v_tu_periods_corr_tab(CTP)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       .OTPC_CORR_START = V_OFFSET_CORR*/
                     ) THEN
                    if (v_TU_status = 0) then
                      V_TUC_ID := uid_sequence.Nextval;
                      ----insert tu correspondance
                      insert into TU_CORRESPONDENCE
                        (TUC_ID,
                         TUC_TU_ID,
                         TUC_TU_ID_CORR,
                         TUC_DEFINED_TYPE,
                         OBJECT_VERSION)
                      values
                        (V_TUC_ID, C_LHS.TU_ID, C_RHS.TU_ID, 3, 0);
                      v_TU_status := 1;
                    end if;

                    V_TPC_ID := uid_sequence.Nextval;
                    insert into TU_PERIODS_CORRESPONDENCE
                      (TUPC_ID,
                       TUPC_TUC_ID,
                       TUPC_CORRESPONDENCE_TYPE,
                       TUPC_TUP_ID,
                       TUPC_TUP_ID_CORR,
                       TUPC_YEAR_OFFSET,
                       TUPC_PERIOD_NUMBER,
                       TUPC_PERIOD_NUMBER_CORR,
                       OBJECT_VERSION)
                    values
                      (V_TPC_ID,
                       V_TUC_ID,
                       1,
                       V_TUP_ID,
                       V_TUP_ID_CORR,
                       v_tu_periods_corr_tab(CTP).OTPC_YEAR_OFFSET,
                       null,
                       null,
                       0);
                  END IF;

                END LOOP;
              END LOOP;
            END LOOP;

          END LOOP;

        END IF;

      END LOOP;

    END LOOP;

    FOR C_LHS IN C_GET_TU_LHS(PI_TU_NAME) LOOP
      -----Loop to iterate though the internal collection that defines basic correspondence
      FOR C IN 1 .. v_tu_corr_tab.COUNT LOOP
        v_TU_status := 0;
        -----checking if the TU is a primary

        IF (v_tu_corr_tab(C).OTC_NAME_CORR = PI_TU_NAME) THEN

          /* --dbms_output.put_line(v_tu_corr_tab(C).OTC_NAME);*/
          ------if TU is primary then check its correspondance secondary TU is defined in the system
          FOR C_RHS IN C_GET_TU_RHS(v_tu_corr_tab(C).OTC_NAME) LOOP

            ----take out periods for the primary TU defined in the system
            for C_TU_PERIOD_LHS IN C_GET_TU_PERIOD_LHS(C_RHS.TU_ID) LOOP

              V_TUP_ID   := C_TU_PERIOD_LHS.TUP_ID;
              V_TUP_NAME := C_TU_PERIOD_LHS.TUP_NAME;

              -----take out periods for the secondary TU defined in the system
              for C_TU_PERIOD_RHS IN C_GET_TU_PERIOD_RHS(C_LHS.TU_ID) LOOP
                V_TUP_ID_CORR   := C_TU_PERIOD_RHS.TUP_ID;
                V_TUP_NAME_CORR := C_TU_PERIOD_RHS.TUP_NAME;

                -----iterate through our object structure to find the correct set to insert
                FOR CTP IN 1 .. v_tu_periods_corr_tab.COUNT LOOP

                  IF (v_tu_periods_corr_tab(CTP)
                     .OTPC_NAME = V_TUP_NAME AND v_tu_periods_corr_tab(CTP)
                     .OTPC_CORR_NAME = V_TUP_NAME_CORR) THEN
                    if (v_TU_status = 0) then
                      V_TUC_ID := uid_sequence.Nextval;
                      ----insert tu correspondance
                      insert into TU_CORRESPONDENCE
                        (TUC_ID,
                         TUC_TU_ID,
                         TUC_TU_ID_CORR,
                         TUC_DEFINED_TYPE,
                         OBJECT_VERSION)
                      values
                        (V_TUC_ID, C_RHS.TU_ID, C_LHS.TU_ID, 3, 0);
                      v_TU_status := 1;
                    end if;

                    V_TPC_ID := uid_sequence.Nextval;
                    insert into TU_PERIODS_CORRESPONDENCE
                      (TUPC_ID,
                       TUPC_TUC_ID,
                       TUPC_CORRESPONDENCE_TYPE,
                       TUPC_TUP_ID,
                       TUPC_TUP_ID_CORR,
                       TUPC_YEAR_OFFSET,
                       TUPC_PERIOD_NUMBER,
                       TUPC_PERIOD_NUMBER_CORR,
                       OBJECT_VERSION)
                    values
                      (V_TPC_ID,
                       V_TUC_ID,
                       1,
                       V_TUP_ID,
                       V_TUP_ID_CORR,
                       v_tu_periods_corr_tab(CTP).OTPC_YEAR_OFFSET,
                       null,
                       null,
                       0);
                  END IF;

                END LOOP;
              END LOOP;
            END LOOP;

          END LOOP;

        END IF;

      END LOOP;

    END LOOP;

  end;
  PROCEDURE ADD_CDM_TIME_UNIT(PI_TU_NAME       IN VARCHAR2,
                              PI_YEARS_RANGE   IN v_tu_years_type,
                              PI_PERIODS_RANGE v_TU_PERIODS_RANGE_type) is
    type v_tup_ids is table of number;
    v_tup_ids_tab           v_tup_ids := v_tup_ids();
    v_year                  number(10) := 2010;
    i                       number := 1;
    j                       number := 1;
    v_tu_id                 number;
    v_tu_name               varchar2(50) := PI_TU_NAME;
    v_namespace_id          number;
    v_namespace_prefix      varchar2(50);
    v_user_namespace_id     number;
    v_user_namespace_prefix varchar2(50);
    v_otu_id                number;
    v_tuyr_id               number;
    v_tup_id                number;
    v_counter               number := 0;
    v_tupr_id               number;
    v_tupr_end_date         date;
    v_start_fdl_name        varchar2(50) := 'Start ' || PI_TU_NAME;
    v_end_fdl_name          varchar2(50) := 'End ' || PI_TU_NAME;
    v_fld_id                number;
    v_end_fld_id            number;
    v_start_fld_id          number;
    v_tup_end_date          date;
    v_temp_counter          number;
    v_exists_flag           number(1) := 0;
    v_existing_tu_id        number;
  begin
    /*commons_utils.insert_logs('Count : ' || PI_PERIODS_RANGE.count);*/
    select NAMESPACE_ID, NAMESPACE_PREFIX
      into v_namespace_id, v_namespace_prefix
      from NAMESPACES
     where NAMESPACE_NAME = 'System';

    select NAMESPACE_ID, NAMESPACE_PREFIX
      into v_user_namespace_id, v_user_namespace_prefix
      from NAMESPACES
     where NAMESPACE_NAME = 'User';

    begin
      select 1, tu_id
        into v_exists_flag, v_existing_tu_id
        from time_units
       where upper(tu_name) = upper(v_tu_name || ' User')
         and tu_defined_type = 1;
    exception
      when no_data_found then
        v_exists_flag    := -1;
        v_existing_tu_id := -1;
    end;
    -- renaming field if there exists a filed like "TU User"
    UPDATE fields f
       set fld_business_name        = fld_business_name || '1',
           FLD_UNIQUE_INTERNAL_NAME = fld_business_name || '1',
           fld_label                = fld_business_name || '1',
           FLD_TECHNICAL_NAME       = fld_business_name || '1' || '_' ||
                                      v_user_namespace_prefix
     where UPPER(f.fld_business_name) in
           (upper(v_tu_name || ' User'),
            upper('Start ' ||v_tu_name || ' User'),
            upper('End ' || v_tu_name || ' User'))
       and fld_type = 2
       and (exists (select 1
               from fields
              where fld_business_name = v_tu_name
                and fld_type = 2) or exists (select 1
               from time_units
              where tu_name = v_tu_name
                and tu_defined_type = 1));

    -- checking if the USER TIME_UNIT exists with the same name
    for v_tu_rec in (select *
                       from time_units
                      where upper(tu_name) = upper(v_tu_name)
                        and tu_defined_type = 1) loop
      -- Renaming the user time unit like TU User to TU User1
      if (v_exists_flag = 1) then
        update time_units
           set tu_name           = tu_name || '1',
               tu_technical_name = tu_name || '1' || '_' ||
                                   v_user_namespace_prefix,
               tu_label          = tu_name || '1'
         where tu_id = v_existing_tu_id;
        UPDATE fields f
           set fld_business_name        = fld_business_name || '1',
               FLD_UNIQUE_INTERNAL_NAME = fld_business_name || '1',
               fld_label                = fld_business_name || '1',
               FLD_TECHNICAL_NAME       = fld_business_name || '1' || '_' ||
                                          v_user_namespace_prefix
         where f.fld_timeunit = v_existing_tu_id
           and fld_type = 4;
      end if;
      -- Renaming USER TIME_UNIT with the same name
      update time_units
         set tu_name           = tu_name || ' User',
             tu_technical_name = tu_name || ' User' || '_' ||
                                 v_user_namespace_prefix,
             tu_label          = tu_name || ' User'
       where tu_id = v_tu_rec.tu_id;
      UPDATE fields f
         set fld_business_name        = fld_business_name || ' User',
             FLD_UNIQUE_INTERNAL_NAME = fld_business_name || ' User',
             fld_label                = fld_business_name || ' User',
             FLD_TECHNICAL_NAME       = fld_business_name || ' User' || '_' ||
                                        v_user_namespace_prefix
       where f.fld_timeunit = v_tu_rec.tu_id
         and fld_type = 4;
    end loop;

    -- Renaming the user field with the same name as time unit
    for v_fld_rec in (select *
                        from fields
                       where upper(fld_business_name) in
                             (upper(v_tu_name),
                              upper('Start ' || v_tu_name),
                              upper('End ' || v_tu_name))
                         and fld_type <> 4) loop
      UPDATE fields f
         set fld_business_name        = fld_business_name || ' User',
             FLD_UNIQUE_INTERNAL_NAME = fld_business_name || ' User',
             fld_label                = fld_business_name || ' User',
             FLD_TECHNICAL_NAME       = fld_business_name || ' User' || '_' ||
                                        v_user_namespace_prefix
       where f.fld_id = v_fld_rec.fld_id;
    end loop;

    -- Adding the CDM time unit
    for i in 1 .. v_tu_tab.count loop
      if v_tu_tab(i).OTU_NAME = v_tu_name then
        v_otu_id := v_tu_tab(i).otu_id;
        v_tu_id  := uid_sequence.nextval;
        insert into time_units
          (tu_id,
           tu_name,
           tu_defined_type,
           tu_period_start_type,
           tu_year_format,
           object_version,
           tu_custom_version,
           tu_namespace_id,
           tu_technical_name,
           tu_label)
        values
          (v_tu_id,
           v_tu_tab      (i).OTU_NAME,
           v_tu_tab      (i).OTU_DEFINED_TYPE,
           v_tu_tab      (i).OTU_PERIOD_START_TYPE,
           1,
           0,
           0,
           v_namespace_id,
           v_tu_tab      (i).OTU_NAME || '_' || v_namespace_prefix,
           v_tu_tab      (i).OTU_NAME);
      end if;
    end loop;

    for i in 1 .. v_tu_periods_tab.count loop
      if v_tu_periods_tab(i).otup_tu_id = v_otu_id then
        v_tup_id  := uid_sequence.nextval;
        v_counter := v_counter + 1;
        v_tup_ids_tab.extend;
        v_tup_ids_tab(v_counter) := v_tup_id;
        insert into tu_periods
          (tup_id, tup_name, tup_tu_id, tup_order, object_version)
        values
          (v_tup_id,
           v_tu_periods_tab(i).OTUP_NAME,
           v_tu_id,
           v_tu_periods_tab(i).OTUP_ORDER,
           0);

      end if;
    end loop;
    v_temp_counter := v_counter;
    v_counter      := 1;
    for j in 1 .. PI_YEARS_RANGE.count loop
      v_tuyr_id := uid_sequence.nextval;
      insert into tu_years_range
        (tuyr_id,
         tuyr_tu_id,
         tuyr_year,
         tuyr_start_date,
         tuyr_end_date,
         object_version)
      values
        (v_tuyr_id,
         v_tu_id,
         PI_YEARS_RANGE(j).OTU_YEAR,
         PI_YEARS_RANGE(j).OTU_YEAR_START_DATE,
         PI_YEARS_RANGE(j).OTU_YEAR_END_DATE,
         0);
      v_tupr_end_date := PI_YEARS_RANGE(j).OTU_YEAR_END_DATE;
      v_counter       := v_temp_counter;
      for l in REVERSE 1 .. v_tu_periods_tab.count loop
        if v_tu_periods_tab(l).OTUP_TU_ID = v_otu_id then
          for k in (select *
                      from table(PI_PERIODS_RANGE) t
                     where t.OTUPR_YEAR = PI_YEARS_RANGE(j).OTU_YEAR
                       and t.OTUPR_TUP_NAME = v_tu_periods_tab(l).OTUP_NAME
                     order by t.OTUPR_START_DATE desc) loop
            v_tupr_id := uid_sequence.nextval;

            insert into tu_periods_range
              (tupr_id,
               tupr_tup_id,
               tupr_start_date,
               tupr_end_date,
               tupr_tuyr_id,
               tupr_period_number,
               object_version,
               tupr_year,
               tupr_period_range_name,
               tupr_tu_id)
            values
              (v_tupr_id,
               v_tup_ids_tab(v_counter),
               k.OTUPR_START_DATE,
               v_tupr_end_date,
               v_tuyr_id,
               v_tu_periods_tab(l).OTUP_ORDER,
               0,
               PI_YEARS_RANGE(j).OTU_YEAR,
               v_tu_periods_tab(l)
               .OTUP_NAME || ' ' || PI_YEARS_RANGE(j).OTU_YEAR,
               v_tu_id);
            v_tupr_end_date := k.OTUPR_START_DATE - 1;
          end loop;
          v_counter := v_counter - 1;
        end if;
      end loop;
    end loop;
    -----------------------done inserting into tables related to time units

    ----- Making entries in fields and dependency metadata
    v_fld_id := uid_sequence.nextval;
    -- insert for the time unit fld

    insert into fields
      (fld_id,
       fld_business_name,
       fld_column_name,
       fld_length,
       fld_data_type,
       fld_type,
       fld_timeunit,
       fld_is_predefined,
       object_version,
       fld_base_field,
       fld_display_thousand_separator,
       fld_display_as_percent,
       fld_unique_internal_name,
       fld_namespace_id,
       fld_technical_name,
       fld_label)
    values
      (v_fld_id,
       v_tu_name,
       'F' || v_fld_id,
       null,
       8,
       4,
       v_tu_id,
       1,
       0,
       null,
       null,
       null,
       v_tu_name,
       v_namespace_id,
       v_tu_name || '_' || v_namespace_prefix,
       v_tu_name);
    -- dependency_metadata
    insert into dependency_metadata
      (dm_reffered_object_id,
       dm_reffering_object_id,
       dm_reffering_object_type,
       dm_subgroup_key)
    values
      (v_tu_id, v_fld_id, 1, null);

    -- for start field
    v_start_fld_id := uid_sequence.nextval;

    insert into fields
      (fld_id,
       fld_business_name,
       fld_column_name,
       fld_length,
       fld_data_type,
       fld_type,
       fld_timeunit,
       fld_is_predefined,
       object_version,
       fld_base_field,
       fld_display_thousand_separator,
       fld_display_as_percent,
       fld_unique_internal_name,
       fld_namespace_id,
       fld_technical_name,
       fld_label)
    values
      (v_start_fld_id,
       v_start_fdl_name,
       'F' || v_start_fld_id,
       null,
       8,
       4,
       v_tu_id,
       1,
       0,
       null,
       null,
       null,
       v_start_fdl_name,
       v_namespace_id,
       v_start_fdl_name || '_' || v_namespace_prefix,
       v_start_fdl_name);
    -- dependency_metadata
    insert into dependency_metadata
      (dm_reffered_object_id,
       dm_reffering_object_id,
       dm_reffering_object_type,
       dm_subgroup_key)
    values
      (v_tu_id, v_start_fld_id, 1, null);
    -- for end field
    v_end_fld_id := uid_sequence.nextval;

    insert into fields
      (fld_id,
       fld_business_name,
       fld_column_name,
       fld_length,
       fld_data_type,
       fld_type,
       fld_timeunit,
       fld_is_predefined,
       object_version,
       fld_base_field,
       fld_display_thousand_separator,
       fld_display_as_percent,
       fld_unique_internal_name,
       fld_namespace_id,
       fld_technical_name,
       fld_label)
    values
      (v_end_fld_id,
       v_end_fdl_name,
       'F' || v_end_fld_id,
       null,
       8,
       4,
       v_tu_id,
       1,
       0,
       null,
       null,
       null,
       v_end_fdl_name,
       v_namespace_id,
       v_end_fdl_name || '_' || v_namespace_prefix,
       v_end_fdl_name);
    -- dependency_metadata
    insert into dependency_metadata
      (dm_reffered_object_id,
       dm_reffering_object_id,
       dm_reffering_object_type,
       dm_subgroup_key)
    values
      (v_tu_id, v_end_fld_id, 1, null);
    -- Creating the time unit correspondence
    ADD_CDM_TIME_UNIT_CORR(V_TU_NAME);
  end;

-- *******************************    PUBLIC FUNCTIONS AND PROCEDURES END         *******************************

END STANDARD_DATA_MODEL;
/
