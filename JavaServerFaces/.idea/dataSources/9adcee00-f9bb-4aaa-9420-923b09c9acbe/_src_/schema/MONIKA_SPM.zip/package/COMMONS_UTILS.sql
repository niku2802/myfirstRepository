CREATE PACKAGE commons_utils AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- --------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    : commons
  -- Module      : appframework
  -- Requester    : Agarwal, Ankita
  -- Author     : Rohit, Maxim
  -- Reviewer     : Homeuca, Victor-Stefan
  -- Review date    : 12-april-2011
  -- Description    : This package is a multi-purpose utility package.
  -- ---------------------------------------------------------------------------
  -- *******************************    PUBLIC TYPES START       *******************************
  TYPE type_index_name IS TABLE OF user_indexes.index_name%type INDEX BY PLS_INTEGER;

  TYPE type_constraint_name IS TABLE OF user_constraints.constraint_name%type INDEX BY PLS_INTEGER;

  TYPE type_trigger_name IS TABLE OF User_Triggers.Trigger_name%type INDEX BY PLS_INTEGER;

  TYPE type_index_ddl_comp IS RECORD(
    ddl_stmt   clob,
    index_name varchar2(50));

  TYPE type_index_ddl_composite IS TABLE OF type_index_ddl_comp INDEX BY PLS_INTEGER;

  TYPE type_constraint_ddl_comp IS RECORD(
    ddl_stmt   clob,
    const_name varchar2(50));

  TYPE type_constraint_ddl_composite IS TABLE OF type_constraint_ddl_comp INDEX BY PLS_INTEGER;

  TYPE type_trigger_ddl_comp IS RECORD(
    ddl_stmt     clob,
    trigger_name varchar2(50));

  TYPE type_trigger_ddl_composite IS TABLE OF type_trigger_ddl_comp INDEX BY PLS_INTEGER;

  -- *******************************    PUBLIC TYPES END         *******************************

  -- *******************************    PUBLIC PROCEDURES START         *******************************

  -- Author     : Maxim Rohit
  -- Create date: 13 AUG 2012
  -- Description: This procedure gathers statistic on table by calling suitable sub-procedure based on the mode
  -- Assumptions: NA
  -- Return : NA

  procedure GENERATE_TABLE_STATSISTICS(PI_TABLE IN varchar2,
                                       PI_MODE  IN number);

  -- Author     : Maxim Rohit
  -- Create date: 23 July 2012
  -- Description: This procedure gathers statistic on table after a recreate
  -- Assumptions: NA
  -- Return : NA

  procedure GENERATE_TABLE_STATS_RECREATE(PI_TABLE IN varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 23 July 2012
  -- Description: This procedure gathers statistic on table after a large insert/update,
  --              doesn't gather stats for indexes, as it should be gathered by the index rebuilds
  --              that should happend in teh floew for large insert/update
  -- Assumptions: NA
  -- Return : NA
  procedure GENERATE_TABLE_STATS_MODIFY(PI_TABLE IN varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 23 March 2011
  -- Description: This procedure estimates statistic of table
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA
  procedure GENERATE_TABLE_STATS(PI_TABLE      IN varchar2,
                                 PI_PERCENTAGE IN number);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Description: This procedure estimates statistic (5%smaple)  of table and returns its approx disk space.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA

  --Example
  /* declare
   V_SIZE_DATA               NUMBER;
   begin

  GET_TABLE_SIZE('v_data_table', V_SIZE_DATA);

  end;*/

  PROCEDURE GET_TABLE_SIZE(PI_TABLE IN varchar2, PO_SIZE out number);

  -- Author     : Maxim Rohit
  -- Create date: 14 Feb 2012
  -- Description: This procedure  disables primary key of the given table.
  -- Return : NA

  PROCEDURE Disable_Primary_Key_Cons(PI_TABLE      varchar2,
                                     pi_process_id varchar2,
                                     pio_index     in out integer);

  -- Author     : Maxim Rohit
  -- Create date: 14 Feb 2012
  -- Description: This procedure  enables primary key of the given table.
  -- Return : NA
  PROCEDURE Enable_Primary_Key_Cons(PI_TABLE varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 18 Sep 2012
  -- Description: This procedure drops all unique indexes of the given table ignoring the unique indexes for primary
  -- keys and unique constraints.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA
  PROCEDURE Drop_unique_indexes(PI_TABLE      varchar2,
                                pi_process_id varchar2,
                                pio_index     in out integer);
  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Description: This procedure  disables all indexes of the given table.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA

  PROCEDURE Disable_indexes(PI_TABLE      varchar2,
                            pi_process_id varchar2,
                            pio_index     in out integer);

  -- Author     : Maxim Rohit
  -- Create date: 18 Sep 2012
  -- Description: This procedure  disables all non unique indexes of the given table.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA
  PROCEDURE Disable_nonunique_indexes(PI_TABLE      varchar2,
                                      pi_process_id varchar2,
                                      pio_index     in out integer);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Description: This procedure  Rebuild all indexes of the given table.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA

  PROCEDURE Rebuild_indexes(PI_TABLE varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Description: This procedure  Rebuild all non unique indexes of the given table.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA
  PROCEDURE Rebuild_nonunique_indexes(PI_TABLE varchar2);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Description: This procedure Disable logging on a given table.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA

  PROCEDURE Disable_logging(PI_TABLE      varchar2,
                            pi_process_id varchar2,
                            pio_index     in out integer);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Module     : DATA IMPORT
  -- Description: This procedure Enable logging on a given table.
  -- Assumptions:
  --The table being passed are created by the current user so that they can be
  --accessed by USER_* dictionary
  -- Return : NA

  PROCEDURE Enable_logging(PI_TABLE varchar2);

  --@Deprecated
  /*
          -- Author     : Maxim Rohit
          -- Create date: 15 March 2011
          -- Module     : DATA IMPORT
          -- Description: This procedure returns an object of type commons_utils.type_constraint_ddl_composite which is
          --              two dimensional structure containing all the constraint names and their corresponding ddl of the passed table.


  procedure get_constraint_ddl(pi_table    varchar2,
                               po_cons_ddl out type_constraint_ddl_composite);

          -- Author     : Maxim Rohit
          -- Create date: 15 March 2011
          -- Module     : DATA IMPORT
          -- Description: This procedure returns an object of type commons_utils.type_index_ddl_composite which is
          --              two dimensional structure containing all the indexes names and their corresponding ddl of the passed table.

   procedure get_index_ddl(pi_table   varchar2,
                          po_ind_ddl out type_index_ddl_composite);

          -- Author     : Maxim Rohit
          -- Create date: 15 March 2011
          -- Module     : DATA IMPORT
          -- Description: This procedure returns an object of type commons_utils.type_trigger_ddl_composite which is
          --              two dimensional structure containing all the trigger names and their corresponding ddl of the passed table.


      procedure get_Trigger_ddl(pi_table   varchar2,
                            po_trg_ddl out type_trigger_ddl_composite);
          -- Author     : Maxim Rohit
          -- Create date: 15 March 2011
          -- Module     : DATA IMPORT
          -- Description: this procedure resets teh given sequence to a particular value.

  */

  -- Author     : Maxim Rohit
  -- Create date: appframework
  -- Module     : DATA IMPORT
  -- Description: This procedure returns an object of type commons_utils.type_constraint_ddl_composite which is
  --              two dimensional structure containing all the constraint names and their corresponding ddl of the passed table.

  --Example
  /*

  declare
    -- Non-scalar parameters require additional processing
    po_cons_ddl commons_utils.type_constraint_ddl_composite;
  begin
    -- Call the procedure
    get_constraint_ddl(pi_table => 'TEAT_DATA',
                       pi_where =>'constraint_type in (''C'', ''P'', ''U'', ''R'')',
                       po_cons_ddl => po_cons_ddl);

    for i in 1..po_cons_ddl.count loop
     dbms_output.put_line(po_cons_ddl(i).const_name);
   dbms_output.put_line(po_cons_ddl(i).ddl_stmt);
  end loop;

  end;*/

  procedure get_constraint_ddl(pi_table          varchar2,
                               pi_where_clause   varchar2,
                               po_constraint_ddl out commons_utils.type_constraint_ddl_composite);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Module     : appframework
  -- Description: This procedure returns an object of type commons_utils.type_index_ddl_composite which is
  --              two dimensional structure containing all the indexes names and their corresponding ddl of the passed table.

  --Example
  /*


  declare
    -- Non-scalar parameters require additional processing
    po_ind_ddl commons_utils.type_index_ddl_composite;
  begin
    -- Call the procedure
    get_index_ddl(pi_table => 'TEAT_DATA',
                  pi_where => 'index_name not in
               (SELECT
                 index_name
                  FROM all_cons_columns A
           inner       JOIN  all_constraints C
                    ON A.constraint_name = C.constraint_name
                 WHERE C.table_name = ''TEAT_DATA''
                   AND C.constraint_type in (''P'', ''U''))',
                  po_ind_ddl => po_ind_ddl);

    for i in 1..po_ind_ddl.count loop
     dbms_output.put_line(po_ind_ddl(i).index_name);
   dbms_output.put_line(po_ind_ddl(i).ddl_stmt);
  end loop;

  end;
  */

  procedure get_index_ddl(pi_table        varchar2,
                          pi_where_clause varchar2,
                          po_index_ddl    out commons_utils.type_index_ddl_composite);
  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Module     : appframework
  -- Description: This procedure returns an object of type commons_utils.type_trigger_ddl_composite which is
  --              two dimensional structure containing all the trigger names and their corresponding ddl of the passed table.
  --Example
  /*



    declare
      -- Non-scalar parameters require additional processing
      po_trg_ddl commons_utils.type_trigger_ddl_composite;
    begin
      -- Call the procedure
      get_trigger_ddl(pi_table => 'TEAT_DATA',
                      pi_where => null,
                      po_trg_ddl => po_trg_ddl);

     for i in 1..po_trg_ddl.count loop
       dbms_output.put_line(po_trg_ddl(i).trigger_name);
     dbms_output.put_line(po_trg_ddl(i).ddl_stmt);
    end loop;

    end;
  */

  procedure get_Trigger_ddl(pi_table        varchar2,
                            pi_where_clause varchar2,
                            po_trigger_ddl  out commons_utils.type_trigger_ddl_composite);

  -- Author     : Maxim Rohit
  -- Create date: 15 March 2011
  -- Module     : appframework
  -- Description: this procedure resets teh given sequence to a particular value.

  procedure reset_seq(pi_seq_name       in varchar2,
                      pi_reset_number   number,
                      pi_transaction_id varchar2,
                      pi_run_id         number,
                      pi_reg_undo_ddl_flag   number);
  procedure reset_seq_at(pi_seq_name       varchar2,
                         pi_reset_number   number,
                         pi_transaction_id varchar2,
                         pi_run_id         number,
                         pi_reg_undo_ddl_flag   number);

  /*  PROCEDURE SET_SESSION_NLS_PARAMS
  ========================================================
  Author    : Dumitriu, Cosmin
  Create date  : 2012.02.28
  Description  : This procedure will be executed whenever a new session will be created and will set
        the NLS parameters of that session to whatever exists in the NLS_PARAMETERS table
  ========================================================*/
  PROCEDURE SET_SESSION_NLS_PARAMS;

  -- Author     : Victor Homeuca
  -- Create date: December 3rd, 2012
  -- Module     : appframework
  -- Description: Base 37 3-character-ID-generator using id_gen_x37_seq sequence. Intended to be used for sufixing temp (oracle) object names. The base used is 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_

  function id_gen_x37 return char;

  -- Author     : Maxim Rohit
  -- Create date: 22 Feb 2013
  -- Module     : appframework
  -- Description: wrapper for reset_seq as PRAGMA AUTONOMOUS_TRANSACTION

  FUNCTION TO_SYSTIMESTAMP(PI_TIMESTAMP IN TIMESTAMP,
                           PI_OFFSET    IN VARCHAR2) RETURN TIMESTAMP
    deterministic;

  /*  PROCEDURE SET_SESSION_NLS_PARAMS
  ========================================================
  Author    : Filip, Catalin
  Create date  : 2014.02.20
  Description  : The function transforms the days in the interval in hours returning HH:MI:SS. Ex:  000000000 01:59:49.000000 ->  01:59:49
                                                                                                  -000000001 23:59:48.000000 -> -47:59:48
  ========================================================*/
  FUNCTION FORMAT_INTERVAL(pi_interval INTERVAL DAY TO SECOND)
    RETURN VARCHAR2;

  /* GET_EQUAL_MATCH_CONDITION
  -- Author    : Dumitriu, Cosmin
  -- Create date  :
  -- Reviewer    :
  -- Review date  :
  -- Description  :
  -----------------------------------------------------------------------------------------------
  -- Assumptions:

       pin_left_member    IN CLOB - members can be column names or expressions:
           - E450.F7898
           - 31
           - NULL
           - TO_DATE('31/12/2012', 'DD/MM/YYYY')
      ,pin_right_member    IN CLOB - same as left member

      ,pin_members_col_type  IN NUMBER 1 - entity, 2 - field

      ,pin_members_data_type  IN NUMBER - the same ID's as in FIELDS.FLD_DATA_TYPE
          - boolean   2
          - period    8
          - character 1
          - note      4
          - date      3
          - datetime  5
          - number    6

  -----------------------------------------------------------------------------------------------
  */
  FUNCTION GET_EQUAL_MATCH_CONDITION(pin_left_member       IN CLOB,
                                     pin_right_member      IN CLOB,
                                     pin_members_col_type  IN NUMBER,
                                     pin_members_data_type IN NUMBER)
    RETURN CLOB;


     /* CHECK_EXIST
  -- Author    : Alex Huiban
  -- Create date  : 2017 09 01
  -- Reviewer    : Lazar Lucian
  -- Review date  :
  -- Description  : O function that returns 1 if it finds an object and 0 if it doesn't
  -----------------------------------------------------------------------------------------------
  -- Paramaters:
      pin_object_name    IN VARCHAR2 - thy object who's existence is checked,

      pin_object_type    IN VARCHAR2 - the type of object we look for.
                            Only the following types are available for now:
                              - FUNCTION,
                              - INDEX,
                              - PACKAGE,
                              - PROCEDURE,
                              - SEQUENCE,
                              - TABLE,
                              - TRIGGER,
                              - VIEW,
                              - SYNONYM,
                              - GRANT,
                              - CONSTRAINT.
   -- Usage examples:

  -----------------------------------------------------------------------------------------------
  */
	FUNCTION CHECK_EXIST(pin_object_name IN VARCHAR2,
											 pin_object_type IN VARCHAR2)
  RETURN NUMBER;

  -- *******************************    PUBLIC PROCEDURES END         *******************************

  /* DBA_CALCULATE_TABLE_STATISTICS
  -- =============================================
  -- Author     : Maxim Rohit
  -- Create date: 07 Oct 2014
  -- Module     : appframework
  -- Description: Procedure for DBAs who want to gather stats on particular table apart from usual processing.
  -- =============================================
  -- Assumptions:NA

  -- =============================================
  -- Parameters:-
  -- IN Parameters
  -- pi_table_name        VARCHAR :- Table name for which stats are to be gathered.
  -- =============================================
  example

  declare
  pi_table_name VARCHAR2(30);
  begin
  commons_utils.DBA_CALCULATE_TABLE_STATISTICS(pi_table_name => 'TABLE_NAME');
  end;

  =============================================*/
  procedure DBA_CALCULATE_TABLE_STATISTICS(pi_table_name IN VARCHAR);

  /* CALCULATE_TABLE_STATISTICS
  -- =============================================
  -- Author     : Shriniket Pimparkar
  -- Create date: 27 June 2014
  -- Module     : appframework
  -- Description: Procedure for calculating eligibility of table for stats gathering and gather the stats if eligible.
  -- =============================================
  -- Assumptions:NA

  -- =============================================
  -- Parameters:-
  -- IN Parameters
  -- pi_table_name        VARCHAR :- Table name for which stats are to be gathered.
  -- PI_MODE        NUMBER :- mode in which the post has been made on table. Possible values : 1/2/3/4/5. Details with respect to each value:  RECREATE(1), INSERT(2), UPDATE(3), UPSERT(4), DELETE(5).
  -- OUT Parameter
  -- po_status            NUMBER :- Output parameter sent to calling environment. Possible values : 0/1/2. 0 => stats are not gathered for table because of threshold not crossing,
  --                      1 => stats are gathered on table threshold crossed, 2 => error occured during stats gathering.

  -- =============================================
  example

  declare
  pi_table_name VARCHAR2(30);
  PI_MODE NUMBER;
  po_status NUMBER(1);
  begin
  -- Call the procedure
  commons_utils.CALCULATE_TABLE_STATISTICS(pi_table_name => 'TABLE_NAME',
  PI_MODE => can be either of 1/2/3/4/5,
  po_status => po_status);
  end;

  =============================================*/
  PROCEDURE CALCULATE_TABLE_STATISTICS(pi_table_name IN VARCHAR,
                                       PI_MODE       IN NUMBER,
                                       po_status     OUT NUMBER);

  /*  FUNCTION TABLE_RECREATE_CHECK
  ========================================================
  Author    : pasalkar,snehal
  Create date  : 2014.12.05
  Description  : The procedure recreates table,rebuild underlying indexes and gather statistics
  ========================================================*/
  PROCEDURE TABLE_SHRINK(pi_table_name VARCHAR2);
  /*  FUNCTION TABLE_RECREATE_CHECK
  ========================================================
  Author    : pasalkar,snehal
  Create date  : 2014.12.05
  Description  : The function checks whether table is eligible for recreate or not
  ========================================================*/
  FUNCTION TABLE_SHRINK_CHECK(pi_table_name VARCHAR2) RETURN NUMBER;

  /*  PROCEDURE PERSIST_EXEC_PLAN
  ========================================================
  Author    : Dumitriu, Cosmin
  Create date  : 2015.05.25
  Description  : The procedure just saves the info from the temporary table DBA_UTILS.TEMP_SQL_EXEC_PLAN_TABLE
                 into the permanent SPM.SQL_EXEC_PLAN_TABLE
  ========================================================*/
  PROCEDURE PERSIST_EXEC_PLAN(pi_run_id in number default null);

  FUNCTION Get_Max_Value(PI_TAB_COL IN TABLETYPE_TAB_COL)
    RETURN TABLETYPE_TAB_COL_VALUE;

  FUNCTION get_max_value_single(pi_table_name IN VARCHAR2,
                                pi_col_name   IN VARCHAR2) RETURN NUMBER;

  procedure Async_Plsql_Run(pi_plsql_code     in varchar2,
                            pi_comment        in varchar2,
                            pi_differentiator in number default null);

  /*  PROCEDURE SEND_DB_ALERT
  ====================================================================
  Author    : Macarie, Sabina
  Create date  : 2015.07.29
  Description  : The procedure is a wrapper over the send_db_alert
                  procedure from dba_utils which sends a database alert.
  ===================================================================*/
  PROCEDURE send_db_alert(pi_details VARCHAR2, pi_description VARCHAR2);

  PROCEDURE INSERT_LOGS(PI_CLOB IN CLOB);

  /* UPDATE_OBJ_RES_NAME
  -- =============================================
  -- Author     : Hardika Bhate
  -- Create date: 12 Apr 2016
  -- Module     : appframework
  -- Description: Procedure to update or_resolved_name column of object_registration table.

  =============================================*/

  PROCEDURE UPDATE_OBJ_RES_NAME(pin_or_id IN coltype_id);



   -- =============================================
  -- Author     : Nutan Parulekar
  -- Create date: 11 Jul 2016
  -- Module     : appframework
  -- Description: Procedure SEQ_REMAP_TRANS_LOGS is to maintain the logs
  --2)  Procedure SEQ_REMAP_RECYCLE_PROC is to reset the row_identifier bracket from 1

 /* =============================================*/
PROCEDURE SEQ_REMAP_TRANS_LOGS(
    pin_table_name VARCHAR2 ,
    pin_trans_type VARCHAR2,
    pin_col_list   VARCHAR2,
    pin_col_val    VARCHAR2 ) ;

    PROCEDURE SEQ_REMAP_RECYCLE_PROC ;


END commons_utils;
/
