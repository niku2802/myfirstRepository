CREATE PACKAGE BODY commons_utils AS
  -- -----------------------------------------------------------------------------
  -- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product    :   commons
  -- Module    :  appframework
  -- Requester    : Agarwal, Ankita
  -- Author     : Rohit, Maxim
  -- Reviewer     : Homeuca, Victor-Stefan
  -- Review date    : 12-april-2011
  -- Description    : This package is a multi-purpose utility package.
  -- ---------------------------------------------------------------------------

  -- *******************************    PUBLIC FUNCTIONS AND PROCEDURES START       *******************************


  procedure GENERATE_TABLE_STATS(PI_TABLE      IN varchar2,
                                 PI_PERCENTAGE IN number) as

    V_ddl_query    clob;
    V_TABLE_QUOTES VARCHAR2(30) := UPPER(PI_TABLE);

  BEGIN
    ---compute statistic

    --dbms_output.put_line('time before anlyzing data table= ' || sysdate);
    V_ddl_query := ' analyze table ' || V_TABLE_QUOTES ||
                   ' estimate statistics sample ' || nvl(PI_PERCENTAGE, 5) ||
                   ' percent ';
    --dbms_output.put_line(V_ddl_query);
    commons_ddl_handling.execute_ddl_nolog(V_ddl_query);
    --dbms_output.put_line('time after anlyzing data table= ' || sysdate);

  END GENERATE_TABLE_STATS;

  procedure GENERATE_TABLE_STATSISTICS(PI_TABLE IN varchar2,
                                       PI_MODE  IN number) as
  begin
    if (PI_MODE = 1) then
      GENERATE_TABLE_STATS_RECREATE(PI_TABLE);

    elsif (PI_MODE = 2) then
      GENERATE_TABLE_STATS_MODIFY(PI_TABLE);

    end if;
  END GENERATE_TABLE_STATSISTICS;
  procedure GENERATE_TABLE_STATS_RECREATE(PI_TABLE IN varchar2) as
    V_TABLE VARCHAR2(30) := UPPER(PI_TABLE);
  BEGIN
    ---compute statistic
    -- dbms_output.put_line('time before anlyzing data table= ' || sysdate);

    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME       => user,
                                  TABNAME       => V_TABLE,
                                  CASCADE       => TRUE,
                                  NO_INVALIDATE => FALSE);

    --dbms_output.put_line('time after anlyzing data table= ' || sysdate);
  END GENERATE_TABLE_STATS_RECREATE;

  procedure GENERATE_TABLE_STATS_MODIFY(PI_TABLE IN varchar2) AS
    V_TABLE VARCHAR2(30) := UPPER(PI_TABLE);
  BEGIN
    ---compute statistic
    --dbms_output.put_line('time before anlyzing data table= ' || sysdate);

    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME       => user,
                                  TABNAME       => V_TABLE,
                                  CASCADE       => TRUE,
                                  NO_INVALIDATE => FALSE);

    --dbms_output.put_line('time after anlyzing data table= ' || sysdate);
  END GENERATE_TABLE_STATS_MODIFY;

  procedure GET_TABLE_SIZE(PI_TABLE IN varchar2, PO_SIZE out number) as

    V_BLOCK_SIZE USER_TABLESPACES.BLOCK_SIZE%TYPE;
    /*   V_ddl_query    clob;*/
    V_TABLE VARCHAR2(30) := UPPER(PI_TABLE);
    /* V_TABLE_QUOTES VARCHAR2(30) := '"' || UPPER(PI_TABLE) || '"';*/

    cursor C_SIZE(PI_BLOCK_SIZE USER_TABLESPACES.BLOCK_SIZE%TYPE) is
      select (blocks) * (PI_BLOCK_SIZE - avg_space) / (1024 * 1024)
        from USER_tables
       where table_name = V_TABLE;

    cursor C_BLOCK_SIZE is
      SELECT BLOCK_SIZE
        FROM USER_TABLESPACES
       WHERE TABLESPACE_NAME in
             (select tablespace_name
                from user_tables
               where table_name = V_TABLE);

  BEGIN
    ---compute statistic

    /*  dbms_output.put_line('time before anlyzing data table= ' || sysdate);
    V_ddl_query := ' analyze table ' || V_TABLE_QUOTES ||
                   ' estimate statistics sample 5 percent ';
    commons_ddl_handling.execute_ddl_nolog(V_ddl_query);
    dbms_output.put_line('time after anlyzing data table= ' || sysdate);*/
    commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => V_TABLE,
                                             PI_MODE  => 2);

    OPEN C_BLOCK_SIZE;

    FETCH C_BLOCK_SIZE
      into V_BLOCK_SIZE;

    CLOSE C_BLOCK_SIZE;

    OPEN C_SIZE(V_BLOCK_SIZE);

    FETCH C_SIZE
      into PO_SIZE;

    CLOSE C_SIZE;
    --dbms_output.put_line(PO_SIZE);
  END GET_TABLE_SIZE;

  PROCEDURE Disable_Primary_Key_Cons(PI_TABLE      varchar2,
                                     pi_process_id varchar2,
                                     pio_index     in out integer) as

    V_ddl_query      clob;
    v_undo_ddl_query clob;
    /* V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);*/
    /*  v_get_index_name type_index_name;*/

  begin

    V_ddl_query := 'ALTER TABLE ' || PI_TABLE || ' DISABLE PRIMARY KEY';

    v_undo_ddl_query := 'ALTER TABLE ' || PI_TABLE ||
                        ' ENABLE  PRIMARY KEY';

    commons_ddl_handling.execute_ddl(pi_process_id,
                                     'Disable Primary key',
                                     V_ddl_query,
                                     v_undo_ddl_query,
                                     pio_index);

    pio_index := pio_index + 1;
  END Disable_Primary_Key_Cons;

  PROCEDURE Enable_Primary_Key_Cons(PI_TABLE varchar2) as

    V_ddl_query clob;
    /*   v_undo_ddl_query clob;
    V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);*/
    /* v_get_index_name type_index_name;*/

  begin

    V_ddl_query := 'ALTER TABLE ' || PI_TABLE || ' ENABLE PRIMARY KEY';

    commons_ddl_handling.execute_ddl_nolog(V_ddl_query);

  END Enable_Primary_Key_Cons;

  PROCEDURE Drop_unique_indexes(PI_TABLE      varchar2,
                                pi_process_id varchar2,
                                pio_index     in out integer) as

    V_ddl_query      clob;
    v_undo_ddl_query clob;
    V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);
    v_get_index_name type_index_name;

    Cursor c_get_index_name is
      select index_name
        from USER_indexes
       WHERE table_name = V_TABLE
         AND index_name not in
             (SELECT /*+ FIRST_ROW */
               index_name
                FROM user_constraints C
               WHERE C.table_name = V_TABLE
                 AND C.constraint_type in ('P', 'U'))
         AND uniqueness = 'UNIQUE';

    v_tables_id number;
  begin

    ------mark indexes as unusable-------------------------
    ---get index names
    OPEN c_get_index_name;

    FETCH c_get_index_name BULK COLLECT
      into v_get_index_name;

    CLOSE c_get_index_name;

    select min(TABLES_ID)
      into v_tables_id
      from tables
     where TABLES_PHYSICAL_NAME = PI_TABLE;
    ---call to execute ddl
    FOR c IN 1 .. v_get_index_name.COUNT loop
      V_ddl_query := 'drop index  ' || v_get_index_name(c);

      v_undo_ddl_query := ' begin

     commons_tables.CREATE_UNIQUE_INDEXES(pi_tables_id=>' ||
                          v_tables_id || ');

                          end;';

      commons_ddl_handling.execute_ddl(pi_process_id,
                                       'Drop unique index ' ||
                                       v_get_index_name(c),
                                       V_ddl_query,
                                       v_undo_ddl_query,
                                       pio_index);
      pio_index := pio_index + 1;
    end loop;
    /*    pio_index := pio_index + 1;*/
  END Drop_unique_indexes;

  PROCEDURE Disable_indexes(PI_TABLE      varchar2,
                            pi_process_id varchar2,
                            pio_index     in out integer) as

    V_ddl_query      clob;
    v_undo_ddl_query clob;
    V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);
    v_get_index_name type_index_name;

    Cursor c_get_index_name is
      select index_name
        from USER_indexes
       WHERE table_name = V_TABLE
         AND index_name not in
             (SELECT /*+ FIRST_ROW */
               index_name
                FROM user_constraints C
               WHERE C.table_name = V_TABLE
                 AND C.constraint_type in ('P', 'U'));

  begin

    ------mark indexes as unusable-------------------------
    ---get index names
    OPEN c_get_index_name;

    FETCH c_get_index_name BULK COLLECT
      into v_get_index_name;

    CLOSE c_get_index_name;
    ---call to execute ddl
    FOR c IN 1 .. v_get_index_name.COUNT loop
      V_ddl_query := 'alter index ' || v_get_index_name(c) || ' unusable';

      v_undo_ddl_query := 'alter index ' || v_get_index_name(c) ||
                          ' REBUILD';

      commons_ddl_handling.execute_ddl(pi_process_id,
                                       'Disable index',
                                       V_ddl_query,
                                       v_undo_ddl_query,
                                       pio_index);
      pio_index := pio_index + 1;
    end loop;
    /*  pio_index := pio_index + 1;*/
  END Disable_indexes;

  PROCEDURE Disable_nonunique_indexes(PI_TABLE      varchar2,
                                      pi_process_id varchar2,
                                      pio_index     in out integer) as

    V_ddl_query      clob;
    v_undo_ddl_query clob;
    V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);
    v_get_index_name type_index_name;

    Cursor c_get_index_name is
      select index_name
        from USER_indexes
       WHERE table_name = V_TABLE
         AND uniqueness = 'NONUNIQUE';
    /*  index_name not in
    (SELECT \*+ FIRST_ROW *\
      index_name
       FROM user_constraints C
      WHERE C.table_name = V_TABLE
        AND C.constraint_type in ('P', 'U'))*/

  begin

    ------mark indexes as unusable-------------------------
    ---get index names
    OPEN c_get_index_name;

    FETCH c_get_index_name BULK COLLECT
      into v_get_index_name;

    CLOSE c_get_index_name;
    ---call to execute ddl
    FOR c IN 1 .. v_get_index_name.COUNT loop
      V_ddl_query := 'alter index ' || v_get_index_name(c) || ' unusable';

      v_undo_ddl_query := 'alter index ' || v_get_index_name(c) ||
                          ' REBUILD';

      commons_ddl_handling.execute_ddl(pi_process_id,
                                       'Disable index',
                                       V_ddl_query,
                                       v_undo_ddl_query,
                                       pio_index);

      pio_index := pio_index + 1;
    end loop;
    /* pio_index := pio_index + 1;*/
  END Disable_nonunique_indexes;

  PROCEDURE Rebuild_indexes(PI_TABLE varchar2) as

    V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);
    V_ddl_query      clob;
    v_get_index_name type_index_name;
    Cursor c_get_index_name is
      select index_name
        from USER_indexes
       WHERE table_name = V_TABLE
         AND uniqueness = 'NONUNIQUE';

    /* AND index_name not in
    (SELECT \*+ FIRST_ROW *\
      index_name
       FROM user_constraints C
      WHERE C.table_name = V_TABLE
        AND C.constraint_type in ('P', 'U'))*/

  begin

    ------mark indexes as unusable-------------------------
    ---get index names
    OPEN c_get_index_name;

    FETCH c_get_index_name BULK COLLECT
      into v_get_index_name;

    CLOSE c_get_index_name;
    ---call to execute ddl
    FOR c IN 1 .. v_get_index_name.COUNT loop
      V_ddl_query := 'alter index ' || v_get_index_name(c) || ' REBUILD';

      commons_ddl_handling.execute_ddl_nolog(V_ddl_query);
    end loop;

  END Rebuild_indexes;

  PROCEDURE Rebuild_nonunique_indexes(PI_TABLE varchar2) as

    V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);
    V_ddl_query      clob;
    v_get_index_name type_index_name;
    Cursor c_get_index_name is
      select index_name
        from USER_indexes
       WHERE table_name = V_TABLE
         AND uniqueness = 'NONUNIQUE';

    /*          (SELECT \*+ FIRST_ROW *\
    index_name
     FROM user_constraints C
    WHERE C.table_name = V_TABLE
      AND C.constraint_type in ('P', 'U'));*/

  begin

    ------mark indexes as unusable-------------------------
    ---get index names
    OPEN c_get_index_name;

    FETCH c_get_index_name BULK COLLECT
      into v_get_index_name;

    CLOSE c_get_index_name;
    ---call to execute ddl
    FOR c IN 1 .. v_get_index_name.COUNT loop
      V_ddl_query := 'alter index ' || v_get_index_name(c) || ' REBUILD';

      commons_ddl_handling.execute_ddl_nolog(V_ddl_query);
    end loop;

  END Rebuild_nonunique_indexes;

  PROCEDURE Disable_logging(PI_TABLE      varchar2,
                            pi_process_id varchar2,
                            pio_index     in out integer) as
    V_ddl_query      clob;
    v_undo_ddl_query clob;
    V_TABLE_QUOTES   VARCHAR2(30) := '"' || UPPER(PI_TABLE) || '"';
  begin

    V_ddl_query      := 'ALTER TABLE ' || V_TABLE_QUOTES || ' NOLOGGING';
    v_undo_ddl_query := 'ALTER TABLE ' || V_TABLE_QUOTES || ' LOGGING';
    commons_ddl_handling.execute_ddl(pi_process_id,
                                     'Disable logging',
                                     V_ddl_query,
                                     v_undo_ddl_query,
                                     pio_index);

    pio_index := pio_index + 1;
  end Disable_logging;


/*PROCEDURE Enable_logging(PI_TABLE varchar2) as
    V_ddl_query    clob;
    V_TABLE_QUOTES VARCHAR2(30) := '"' || UPPER(PI_TABLE) || '"';
  begin

    V_ddl_query := 'ALTER TABLE ' || V_TABLE_QUOTES || ' LOGGING';
    commons_ddl_handling.execute_ddl_nolog(V_ddl_query);

exception when others then
      INSERT_LOGS (V_ddl_query||' - '||sqlerrm);
     Enable_logging(PI_TABLE =>PI_TABLE);
  end Enable_logging;
*/
PROCEDURE Enable_logging(PI_TABLE varchar2) as
    V_ddl_query    clob;
    V_TABLE_QUOTES VARCHAR2(30) := '"' || UPPER(PI_TABLE) || '"';
    V_PR_VALUE     varchar2(20);
  begin

    for c in 1 .. 100 loop
      begin
        V_ddl_query := 'ALTER TABLE ' || V_TABLE_QUOTES || ' LOGGING';
        commons_ddl_handling.execute_ddl_nolog(V_ddl_query);
        return;
      exception
        when others then
          SELECT nvl(max(PR_VALUE), 'SPM')
            INTO V_PR_VALUE
            FROM PROPERTIES
           WHERE PR_NAME = 'ENV_NAME';
          if V_PR_VALUE = 'SPM' then
            --DBMS_LOCK.SLEEP(seconds => 10);
            execute immediate 'begin
  DBMS_LOCK.SLEEP(seconds => 10);
  end;';
          end if;
      end;
    end loop;

  end Enable_logging;


  --@Deprecated
  /*procedure get_constraint_ddl(pi_table    varchar2,
                                 po_cons_ddl out type_constraint_ddl_composite) as

      V_TABLE                VARCHAR2(30) := UPPER(pi_table);
      v_get_constraints_name type_constraint_name;

      Cursor c_get_constraints_name is
        select constraint_name
          from user_constraints
         where table_name = V_TABLE
           and constraint_type in ('C', 'P', 'U', 'R');



    begin

      OPEN c_get_constraints_name;

      FETCH c_get_constraints_name BULK COLLECT
        into v_get_constraints_name;

      CLOSE c_get_constraints_name;

      FOR C IN 1 .. v_get_constraints_name.COUNT LOOP
        po_cons_ddl(C).ddl_stmt := dbms_metadata.get_ddl('CONSTRAINT',
                                                         v_get_constraints_name(c));
        po_cons_ddl(C).const_name := v_get_constraints_name(c);
      END LOOP;

    end;
  */

  procedure get_constraint_ddl(pi_table          varchar2,
                               pi_where_clause   varchar2,
                               po_constraint_ddl out commons_utils.type_constraint_ddl_composite) as

    v_get_constraints_name commons_utils.type_constraint_name;
    v_where                clob;
    c_get_constraints_name sys_refcursor;
    v_cons_handle          number;
    v_trans_handle         number;

  begin
    if (pi_table is null) then

      raise_application_error(-20000, 'pi_table can not be null ');

    end if;

    select nvl2(pi_where_clause,
                ' and ' || pi_where_clause,
                pi_where_clause)
      into v_where
      from dual;
    OPEN c_get_constraints_name FOR 'select constraint_name
        from user_constraints where table_name = ''' || pi_table || ''' ' || v_where;

    FETCH c_get_constraints_name BULK COLLECT
      into v_get_constraints_name;

    CLOSE c_get_constraints_name;

    FOR C IN 1 .. v_get_constraints_name.COUNT LOOP
      v_cons_handle  := null;
      v_trans_handle := null;
      v_cons_handle  := dbms_metadata.open('CONSTRAINT');
      dbms_metadata.set_filter(v_cons_handle,
                               'NAME',
                               v_get_constraints_name(c));
      v_trans_handle := dbms_metadata.add_transform(v_cons_handle, 'DDL');
      dbms_metadata.set_transform_param(v_trans_handle, 'TABLESPACE', TRUE);
      dbms_metadata.set_transform_param(v_trans_handle, 'STORAGE', FALSE);
      dbms_metadata.set_transform_param(v_trans_handle, 'PRETTY', false);

      -- po_constraint_ddl(C).ddl_stmt := dbms_metadata.get_ddl('CONSTRAINT',
      --v_get_constraints_name(c));
      po_constraint_ddl(C).ddl_stmt := dbms_metadata.fetch_clob(v_cons_handle);
      po_constraint_ddl(C).const_name := v_get_constraints_name(c);

    END LOOP;

  end;

  -- @Deprecated
  /*
    procedure get_index_ddl(pi_table   varchar2,
                            po_ind_ddl out type_index_ddl_composite) as

      V_TABLE          VARCHAR2(30) := UPPER(PI_TABLE);
      v_get_index_name type_constraint_name;

      Cursor c_get_index_name is
        select index_name
          from USER_indexes
         WHERE table_name = pi_table

           AND index_name not in
               (SELECT \*+ FIRST_ROW *\
                 index_name
                  FROM all_cons_columns A
                  JOIN all_constraints C
                    ON A.constraint_name = C.constraint_name
                 WHERE C.table_name = V_TABLE
                   AND C.constraint_type in ('P', 'U'));

    begin

      OPEN c_get_index_name;

      FETCH c_get_index_name BULK COLLECT
        into v_get_index_name;

      CLOSE c_get_index_name;

      FOR C IN 1 .. v_get_index_name.COUNT LOOP
        po_ind_ddl(C).ddl_stmt := dbms_metadata.get_ddl('INDEX',
                                                        v_get_index_name(c));
        po_ind_ddl(C).index_name := v_get_index_name(c);
      END LOOP;

    end get_index_ddl;

  */

  procedure get_index_ddl(pi_table        varchar2,
                          pi_where_clause varchar2,
                          po_index_ddl    out commons_utils.type_index_ddl_composite) as

    c_get_index_name sys_refcursor;
    v_where          clob;
    v_get_index_name commons_utils.type_constraint_name;
    v_index_handle   number;
    v_trans_handle   number;
  begin
    if (pi_table is null) then

      raise_application_error(-20000, 'pi_table can not be null ');

    end if;
    select nvl2(pi_where_clause,
                ' and ' || pi_where_clause,
                pi_where_clause)
      into v_where
      from dual;
    OPEN c_get_index_name for 'select index_name
        from USER_indexes where table_name = ''' || pi_table || ''' ' || v_where;

    FETCH c_get_index_name BULK COLLECT
      into v_get_index_name;

    CLOSE c_get_index_name;

    FOR C IN 1 .. v_get_index_name.COUNT LOOP

      v_index_handle := null;
      v_trans_handle := null;
      v_index_handle := dbms_metadata.open('INDEX');
      dbms_metadata.set_filter(v_index_handle, 'NAME', v_get_index_name(c));
      v_trans_handle := dbms_metadata.add_transform(v_index_handle, 'DDL');
      dbms_metadata.set_transform_param(v_trans_handle, 'TABLESPACE', TRUE);
      dbms_metadata.set_transform_param(v_trans_handle, 'STORAGE', FALSE);
      dbms_metadata.set_transform_param(v_trans_handle, 'PRETTY', false);

      po_index_ddl(C).ddl_stmt := dbms_metadata.fetch_clob(v_index_handle);
      -- po_index_ddl(C).ddl_stmt := dbms_metadata.get_ddl('INDEX',
      --                                                  v_get_index_name(c));
      po_index_ddl(C).index_name := v_get_index_name(c);
    END LOOP;

  end get_index_ddl;

  --@Deprecated
  /*
    procedure get_Trigger_ddl(pi_table   varchar2,
                              po_trg_ddl out type_trigger_ddl_composite) as

      V_TABLE            VARCHAR2(30) := UPPER(PI_TABLE);
      v_get_trigger_name type_trigger_name;

      Cursor c_get_trigger_name is
        select trigger_name from User_Triggers WHERE table_name = V_TABLE;

    begin

      OPEN c_get_trigger_name;

      FETCH c_get_trigger_name BULK COLLECT
        into v_get_trigger_name;

      CLOSE c_get_trigger_name;

      FOR C IN 1 .. v_get_trigger_name.COUNT LOOP
        po_trg_ddl(C).ddl_stmt := dbms_metadata.get_ddl('TRIGGER',
                                                        v_get_trigger_name(c));
        po_trg_ddl(C).trigger_name := v_get_trigger_name(c);
      END LOOP;

    end;

  */
  procedure get_Trigger_ddl(pi_table        varchar2,
                            pi_where_clause varchar2,
                            po_trigger_ddl  out commons_utils.type_trigger_ddl_composite) as

    v_get_trigger_name commons_utils.type_trigger_name;
    v_where            clob;
    c_get_trigger_name sys_refcursor;
    v_trigger_handle   number;
    v_trans_handle     number;
    --v_temp                    clob;

  begin
    if (pi_table is null) then

      raise_application_error(-20000, 'pi_table can not be null ');

    end if;
    select nvl2(pi_where_clause, ' and ' || pi_where_clause, null)
      into v_where
      from dual;
    OPEN c_get_trigger_name for '
  select trigger_name from User_Triggers where table_name = ''' || pi_table || ''' ' || v_where;

    FETCH c_get_trigger_name BULK COLLECT
      into v_get_trigger_name;

    CLOSE c_get_trigger_name;

    FOR C IN 1 .. v_get_trigger_name.COUNT LOOP
      v_trigger_handle := null;
      v_trans_handle   := null;
      v_trigger_handle := dbms_metadata.open('TRIGGER');
      dbms_metadata.set_filter(v_trigger_handle,
                               'NAME',
                               v_get_trigger_name(c));
      v_trans_handle := dbms_metadata.add_transform(v_trigger_handle, 'DDL');
      dbms_metadata.set_transform_param(v_trans_handle, 'PRETTY', false);
      --v_temp:=dbms_metadata.fetch_clob(v_trigger_handle);
      -- dbms_output.put_line(v_temp);
      -- po_trigger_ddl(C).ddl_stmt := substr (v_temp,1,instr(v_temp,'ALTER TRIGGER')-1);
      po_trigger_ddl(C).ddl_stmt := dbms_metadata.fetch_clob(v_trigger_handle);
      --po_trigger_ddl(C).ddl_stmt := dbms_metadata.get_ddl('TRIGGER',
      --                                                    v_get_trigger_name(c));
      po_trigger_ddl(C).trigger_name := v_get_trigger_name(c);
    END LOOP;

  end;

  procedure reset_seq_reg_undo_ddl(pi_seq_name       varchar2,
                                   pi_transaction_id varchar2,
                                   pi_run_id         number,
                                   pi_reset_value    number) as
    v_ddl      varchar2(1000);
    v_undo_ddl varchar2(1000);
  begin
    v_ddl      := 'begin
      null;
      end;';
    v_undo_ddl := 'begin
   commons_utils.reset_seq_at(pi_seq_name => ''' ||
                  pi_seq_name || ''',pi_reset_number => ' || pi_reset_value ||
                  ',pi_transaction_id => ''' || pi_transaction_id ||
                  ''',pi_run_id => ' ||
                  coalesce(to_char(pi_run_id), 'NULL') || ',pi_reg_undo_ddl_flag => 0);
   end;';

    commons_ddl_handling.execute_ddl(pi_transaction_id => pi_transaction_id,
                                     pi_description    => 'Rollback DDL for RESET_SEQ',
                                     pi_ddl            => v_ddl,
                                     pi_undo_ddl       => v_undo_ddl,
                                     pi_run_id         => pi_run_id,
                                     pi_resource_id    => null);
  end;
  procedure reset_seq_at(pi_seq_name       varchar2,
                         pi_reset_number   number,
                         pi_transaction_id varchar2,
                         pi_run_id         number,
                         pi_reg_undo_ddl_flag   number) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  begin
    reset_seq(pi_seq_name       => pi_seq_name,
              pi_reset_number   => pi_reset_number,
              pi_transaction_id => pi_transaction_id,
              pi_run_id         => pi_run_id,
              pi_reg_undo_ddl_flag   => pi_reg_undo_ddl_flag);
  end;

  procedure reset_seq(pi_seq_name       in varchar2,
                      pi_reset_number   number,
                      pi_transaction_id varchar2,
                      pi_run_id         number,
                      pi_reg_undo_ddl_flag   number) as
    l_val          number;
    l_val_exp      number;
    l_val_in       number;
    v_reset_number number := pi_reset_number - 1;
    v_ddl          varchar2(1000);
    v_undo_ddl     varchar2(1000);
  begin
    if (v_reset_number < 1) then
      v_reset_number := 1;

    end if;

    execute immediate 'select ' || pi_seq_name || '.nextval from dual'
      INTO l_val;
    l_val_in := l_val;

    execute immediate 'alter sequence ' || pi_seq_name || ' increment by -' ||
                      l_val || ' minvalue 0';

    execute immediate 'select ' || pi_seq_name || '.nextval from dual'
      INTO l_val;

    execute immediate 'alter sequence ' || pi_seq_name || ' increment by +' ||
                      v_reset_number || ' minvalue 0';

    /*    execute immediate 'select ' || pi_seq_name || '.nextval from dual'
    INTO l_val;*/
    if (v_reset_number <> 1) then
      execute immediate 'select ' || pi_seq_name || '.nextval from dual'
        INTO l_val;
    end if;
    execute immediate 'alter sequence ' || pi_seq_name ||
                      ' increment by 1 minvalue 0';
    if pi_reg_undo_ddl_flag = 1 then
      reset_seq_reg_undo_ddl(pi_seq_name       => pi_seq_name,
                             pi_transaction_id => pi_transaction_id,
                             pi_run_id         => pi_run_id,
                             pi_reset_value    => l_val_in);
    end if;

  exception
    when others then

      execute immediate 'select ' || pi_seq_name || '.nextval from dual'
        INTO l_val_exp;

      execute immediate 'alter sequence ' || pi_seq_name ||
                        ' increment by -' || l_val_exp || ' minvalue 0';

      execute immediate 'select ' || pi_seq_name || '.nextval from dual'
        INTO l_val_exp;

      execute immediate 'alter sequence ' || pi_seq_name ||
                        ' increment by +' || l_val_in || ' minvalue 0';

      execute immediate 'select ' || pi_seq_name || '.nextval from dual'
        INTO l_val_exp;

      execute immediate 'alter sequence ' || pi_seq_name ||
                        ' increment by 1 minvalue 0';

      raise;
  end;

  /*  PROCEDURE SET_SESSION_NLS_PARAMS*/
  PROCEDURE SET_SESSION_NLS_PARAMS AS
  BEGIN
    FOR C IN (SELECT 1
                FROM DUAL
               WHERE EXISTS (SELECT 1
                        FROM USER_TABLES
                       WHERE TABLE_NAME = 'NLS_PARAMETERS')) LOOP
      FOR CI IN (SELECT PARAMETER, VALUE FROM NLS_PARAMETERS) LOOP
        EXECUTE IMMEDIATE 'ALTER SESSION SET ' || CI.PARAMETER || '=' ||
                          CI.VALUE;
      END LOOP;
    END LOOP;
  END SET_SESSION_NLS_PARAMS;

  function id_gen_x37 return CHAR is
    base   CHAR(37) := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_';
    seq_id SIMPLE_INTEGER := 0;
    v_id   CHAR(3);
  begin
    seq_id := id_gen_x37_seq.nextval;
    return substr(base, trunc(seq_id / power(37, 2)) + 1, 1) || substr(base,
                                                                       trunc(mod(seq_id,
                                                                                 power(37,
                                                                                       2)) / 37) + 1,
                                                                       1) || substr(base,
                                                                                    mod(mod(seq_id,
                                                                                            power(37,
                                                                                                  2)),
                                                                                        37) + 1,
                                                                                    1);
  end;

   FUNCTION TO_SYSTIMESTAMP(PI_TIMESTAMP IN TIMESTAMP,
                           PI_OFFSET    IN VARCHAR2)

   RETURN TIMESTAMP deterministic
   IS
    V_TIMESTAMP date;
  BEGIN
  V_TIMESTAMP:= FROM_TZ(PI_TIMESTAMP,
               '+00:00') AT TIME ZONE PI_OFFSET;


    RETURN V_TIMESTAMP;

  END TO_SYSTIMESTAMP;

  FUNCTION format_interval(pi_interval INTERVAL DAY TO SECOND)
    RETURN VARCHAR2 IS
    v_num_hours          INTEGER := abs(extract(day from pi_interval) * 24 +
                                        extract(hour from pi_interval));
    v_num_min_sec        VARCHAR2(255 char) := substr(substr(pi_interval,
                                                             0,
                                                             instr(pi_interval,
                                                                   '.') - 1),
                                                      instr(pi_interval, ':'));
    v_formatted_interval VARCHAR2(255 CHAR);
  BEGIN
    -- If the number of hours has 1 digit then format it
    IF v_num_hours between 0 and 9 THEN
      v_formatted_interval := to_char(v_num_hours, 'fm00') || v_num_min_sec;
    ELSE
      v_formatted_interval := v_num_hours || v_num_min_sec;
    END IF;

    -- add minus sign if the interval is negative
    IF (pi_interval < to_dsinterval('+000000000 00:00:00.00')) THEN
      v_formatted_interval := '-' || v_formatted_interval;
    END IF;

    RETURN v_formatted_interval;
  END;

  /* CHECK_EXIST
  -- Author    : Alex Huiban
  -- Create date  : 2017 09 01
  -- Reviewer    : Lazar Lucian
  -- Review date  :
  -- Description  : O function that returns 1 if it finds an object and 0 if it doesn't
  -----------------------------------------------------------------------------------------------
  -- History:
    1. 2017.09.01 - Alex Huiban - created
  -----------------------------------------------------------------------------------------------
  */
FUNCTION CHECK_EXIST(pin_object_name IN VARCHAR2,
										 pin_object_type IN VARCHAR2) RETURN NUMBER IS
	  count_obj VARCHAR2(100);
BEGIN
	  EXECUTE IMMEDIATE 'SELECT count(1) from user_' || CASE pin_object_type
											WHEN 'FUNCTION' then
											 'functions'
											WHEN 'INDEX' then
											 'indexes'
											WHEN 'PACKAGE' then
											 'packages'
											WHEN 'PROCEDURE' then
											 'procedures'
											WHEN 'SEQUENCE' then
											 'sequences'
											WHEN 'TABLE' then
											 'tables'
											WHEN 'TRIGGER' then
											 'triggers'
											WHEN 'VIEW' then
											 'views'
											WHEN 'SYNONYM' then
											 'synonyms'
											WHEN 'GRANT' then
											 'grants'
											WHEN 'CONSTRAINT' then
											 'constraints'
											ELSE
											 pin_object_type
										END || ' where ' || pin_object_type || '_NAME = ''' ||
										pin_object_name || ''''
		  INTO count_obj;
	  IF count_obj > 0 THEN
		    RETURN 1;
	  ELSE
		    RETURN 0;
	  END IF;
EXCEPTION
	  WHEN OTHERS THEN
		  RETURN 0;
END CHECK_EXIST;


  /* GET_EQUAL_MATCH_CONDITION
  -- Author   : Dumitriu, Cosmin
  -- Create date  :
  -- Reviewer   :
  -- Review date  :
  -- Description  :
  -----------------------------------------------------------------------------------------------
  -- History:
    1. 2012.12.10 - Dumitriu, Cosmin - created
  -----------------------------------------------------------------------------------------------
  */
  FUNCTION GET_EQUAL_MATCH_CONDITION(pin_left_member       IN CLOB,
                                     pin_right_member      IN CLOB,
                                     pin_members_col_type  IN NUMBER,
                                     pin_members_data_type IN NUMBER)
    RETURN CLOB IS
    v_condition CLOB;
  BEGIN
    -- members can be column names or expressions:
    -- E450.F7898
    -- 31
    -- NULL
    -- TO_DATE('31/12/2012', 'DD/MM/YYYY')
    IF (pin_left_member = 'NULL' AND pin_right_member = 'NULL') THEN
      v_condition := '(1 = 1)';
    ELSIF (pin_left_member = 'NULL') THEN
      v_condition := '(' || pin_right_member || ' IS NULL)';
    ELSIF (pin_right_member = 'NULL') THEN
      v_condition := '(' || pin_left_member || ' IS NULL)';
    ELSE
      -- entity
      IF (pin_members_col_type = 1) THEN
        v_condition := '(NVL(' || pin_left_member || ', 1E38) = NVL(' ||
                       pin_right_member || ', 1E38))';
        -- boolean or period
      ELSIF (pin_members_data_type IN (2, 8)) THEN
        v_condition := '(NVL(' || pin_left_member || ', 1E38) = NVL(' ||
                       pin_right_member || ', 1E38))';
        --character or note
      ELSIF (pin_members_data_type IN (1, 4)) THEN
        v_condition := '(NVL(UPPER(' || pin_left_member ||
                       '), CHR(0)) = NVL(UPPER(' || pin_right_member ||
                       '), CHR(0)))';
        -- date
      ELSIF (pin_members_data_type = 3) THEN
        v_condition := '(NVL(' || pin_left_member ||
                       ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')) = NVL(' ||
                       pin_right_member ||
                       ', TO_DATE(''01/01/1800'', ''DD/MM/YYYY'')))';
        -- datetime
      ELSIF (pin_members_data_type = 5) THEN
        v_condition := '(NVL(' || pin_left_member ||
                       ', TO_TIMESTAMP(''01/01/1800 00:00:00'', ''DD/MM/YYYY HH24:MI:SS'')) = NVL(' ||
                       pin_right_member ||
                       ', TO_TIMESTAMP(''01/01/1800 00:00:00'', ''DD/MM/YYYY HH24:MI:SS'')))';
        -- numeric
      ELSIF (pin_members_data_type = 6) THEN
        v_condition := '(NVL(' || pin_left_member || ', 1E38) = NVL(' ||
                       pin_right_member || ', 1E38))';
        -- anything else
      ELSE
        v_condition := '(' || pin_left_member || ' = ' || pin_right_member ||
                       ' OR (' || pin_left_member || ' IS NULL AND ' ||
                       pin_right_member || ' IS NULL))';
      END IF;
    END IF;

    RETURN v_condition;
  END GET_EQUAL_MATCH_CONDITION;

procedure DBA_CALCULATE_TABLE_STATISTICS(pi_table_name IN VARCHAR) as
    V_DST_TABLE_ID number;
    v_table_name   varchar(30 char) := upper(pi_table_name);
    V_BLOCKS       number;
    v_num_rows     number;
    v_DST_ID       number := DATA_STATISTICS_SEQ.Nextval;
    v_status       number;
  begin

    --get tables_id
    select nvl(max(t.tables_id), -1)
      into V_DST_TABLE_ID
      from tables t
     where upper(t.tables_physical_name) = v_table_name;

    --get num block and avg row
    Select BLOCKS, NUM_ROWS
      into V_BLOCKS, v_num_rows
      from user_tables ut
     where table_name = v_table_name;

    update data_statistics set DST_STATUS = 2 where DST_STATUS = 0 and DST_TABLE_NAME = v_table_name;

    insert into data_statistics
      (DST_ID,
       DST_TABLE_ID,
       DST_TABLE_NAME,
       DST_BLOCKS_NUM_BEFORE,
       DST_RECORDS_NUM_BEFORE,
       DST_PROCESS_TYPE,
       DST_COMPLETION_STATUS,
       DST_OPERATION_TYPE,
       DST_STATUS,
       DST_RECORDS_TIMESTAMP_UTC)
    values
      (v_DST_ID,
       V_DST_TABLE_ID,
       v_table_name,
       V_BLOCKS,
      v_num_rows,
       6,
       1,
       1,
       0,
       SYS_EXTRACT_UTC(SYSTIMESTAMP));

    CALCULATE_TABLE_STATISTICS(pi_table_name => v_table_name,
                               PI_MODE       => 1,
                               po_status     => v_status);



  end;


  procedure UPDATE_SHRINK_STATUS(pi_table_name varchar2)
    is
            v_tab_name varchar2(30 char) := upper(pi_table_name);
    begin
             update data_statistics ds
                      set ds.DST_SHRINK_STATUS = case
                       when DST_RECORDS_TIMESTAMP_UTC =
                           (select max(DST_RECORDS_TIMESTAMP_UTC)
                              from data_statistics dsin
                             where UPPER(dsin.DST_table_name) =v_tab_name
                               and dsin.DST_SHRINK_STATUS = 0) then
                                    1
                        else
                                   2
                        end
                   where  UPPER(ds.DST_table_name) = v_tab_name
                   and ds.DST_SHRINK_STATUS = 0 ;
      end UPDATE_SHRINK_STATUS;

------do not call false recreate , as it will reset the shrink.
  PROCEDURE CALCULATE_TABLE_STATISTICS(pi_table_name IN VARCHAR,
                                       PI_MODE       IN NUMBER,
                                       po_status     OUT NUMBER) is
    v_npercent_threshold NUMBER := 10;
    v_npercent_changed   NUMBER := 0;
    v_cpr_name           properties.pr_name%type := 'DATA_LOAD_STATS_PERCENTAGE';
    v_cexecute_ddl       varchar2(500 char);
    v_nmode              NUMBER(1) := 2;
    v_status             number(1) := 1;
    v_last_analyzed      timestamp;
    v_num_rows           number;
  begin
    po_status := 0;
  for i in ( select 1 from properties where pr_name ='IS_TABLE_STATS_ENABLED' and pr_value='1'
       and not exists (select table_name from table_stats_exceptions where table_name=pi_table_name))
    loop
    po_status := 0;
    IF PI_MODE IN (2, 3, 4, 5) THEN
      -- get the stats threshold value from properties
      BEGIN
        --fetch table wise treshold if configured
        SELECT SPT_PERCENTAGE
          INTO V_NPERCENT_THRESHOLD
          FROM STATS_PERCENT_TABLEWISE
         WHERE UPPER(SPT_TABLE_NAME) = UPPER(PI_TABLE_NAME);
      EXCEPTION
        WHEN OTHERS THEN
		  --get the stats threshold value from properties
          SELECT NVL(MAX(TO_NUMBER(PR_VALUE)), 10)
            INTO V_NPERCENT_THRESHOLD
            FROM PROPERTIES
           WHERE PR_NAME = V_CPR_NAME;
      END;

      BEGIN
        begin
          Select nvl((FROM_TZ(CAST(TO_TIMESTAMP(TO_CHAR(last_analyzed,
                                                        'dd-mm-yyyy hh24:mi:ss'),
                                                'dd-mm-yyyy hh24:mi:ss') AS
                                   TIMESTAMP),
                              TZ_OFFSET(SESSIONTIMEZONE))),
                     to_timestamp('01-01-1900 00:00:00',
                                  'dd-mm-yyyy hh24:mi:ss')) AT TIME ZONE 'UTC' last_analyzed,
                 decode(NUM_ROWS, null, 1, 0, 1, NUM_ROWS) NUM_ROWS
            into v_last_analyzed, v_num_rows
            from user_tables ut
           where table_name = UPPER(pi_table_name);
        EXCEPTION
          when no_data_found then
            po_status := 3;
            return;
        end;
        -- calculate the changes in table after last analyzed of table
        SELECT /*+ INDEX (DATA_STATISTICS DST_TABLE_NAME_STATUS_SI) */
         ((nvl(sum(DST_RECORDS_INSERTED), 0) +
         nvl(sum(DST_RECORDS_UPDATED), 0) +
         nvl(sum(DST_RECORDS_DELETED), 0)) / v_num_rows) * 100
          INTO v_npercent_changed
          FROM data_statistics ds
         WHERE UPPER(dst_table_name) = UPPER(pi_table_name)
           AND dst_status = 0
           and v_last_analyzed < dst_records_timestamp_utc;
        -- if change in the table is more than threshold then gather the stats
        IF NVL(v_npercent_changed, 0) < v_npercent_threshold THEN
          v_status := 0;
        END IF;
       exception
         when others then
          v_status := 1;
           END;



      END IF;
    -- if status = 1 then update DST_STATUS to 1 in data_statistics table against that table name
    IF v_status = 1 THEN
      v_cexecute_ddl := 'begin commons_utils.GENERATE_TABLE_STATSISTICS(PI_TABLE => ''' ||
                        pi_table_name || ''',PI_MODE  => ' || v_nmode ||
                        '); end;';
      begin
        commons_ddl_handling.execute_ddl_nolog(v_cexecute_ddl);
      EXCEPTION
        WHEN OTHERS THEN
          po_status := 2;
          return;
      end;
    END IF;

 if v_status = 1 then
   update data_statistics ds
   set DST_STATUS = case
                      when DST_RECORDS_TIMESTAMP_UTC =
                           (select max(DST_RECORDS_TIMESTAMP_UTC)
                              from data_statistics dsin
                             where UPPER(dsin.DST_table_name) = UPPER(pi_table_name)
                               and dsin.DST_STATUS = 0) then
                       1
                      else
                       2
                    end
   where UPPER(ds.DST_table_name) =  UPPER(pi_table_name)
   and ds.DST_STATUS = 0;



      /*update  data_statistics
         SET DST_STATUS = 2
         WHERE UPPER(dst_table_name) = UPPER(pi_table_name)
         AND DST_STATUS = 0;
     update  data_statistics
         SET DST_STATUS = 1
         WHERE UPPER(dst_table_name) = UPPER(pi_table_name)
         AND DST_STATUS = 0;
    */
    else
     update  data_statistics
         SET DST_STATUS = 2
         WHERE UPPER(dst_table_name) = UPPER(pi_table_name)
         AND DST_STATUS = 0 and dst_records_timestamp_utc < v_last_analyzed;

  end if;


   if (PI_MODE=1) then
     UPDATE_SHRINK_STATUS(pi_table_name);
     end if;

/*   execute immediate '
     UPDATE data_statistics
         SET DST_STATUS = 1
       WHERE ' || Case
                        when v_status = 1 then
                         'UPPER(dst_table_name) = UPPER( ''' || pi_table_name ||
                         ''' ) AND DST_STATUS = 0'
                        else
                         'UPPER(dst_table_name) = UPPER(''' || pi_table_name ||
                         ''') AND DST_STATUS = 0 and dst_records_timestamp_utc <    ''' ||
                         v_last_analyzed || ''''
                      end;*/

    po_status := v_status;
  end loop;
  END CALCULATE_TABLE_STATISTICS;


 function table_shrink_check(pi_table_name VARCHAR2) return number
  is
          v_num_rows number;
          v_percent_deleted number;
          v_rows_deleted number;
          v_percent_inserted number;
          v_rows_inserted number;
          v_delete_threshold number;
          v_insert_threshold number;
          --table_recreate_check varchar2(10);
          v_tab_name varchar2(30 char) := upper(pi_table_name);

  begin
         for i in ( select 1 from properties where pr_name ='IS_DATA_LOAD_TABLE_SHRINK_ENABLED' and pr_value='1'
           and not exists (select table_name from table_shrink_exceptions where table_name=v_tab_name))
         loop
          select  decode(NUM_ROWS, null, 1, 0, 1, NUM_ROWS) into v_num_rows from user_tables where table_name =v_tab_name;
          select PR_VALUE into v_delete_threshold from properties where pr_name ='DATA_LOAD_TABLE_SHRINK_DELETE_PERCENTAGE';
          select pr_value into v_insert_threshold from properties where pr_name ='DATA_LOAD_TABLE_SHRINK_INSERT_PERCENTAGE';
          select sum(dst_records_deleted),sum(dst_records_inserted)  into v_rows_deleted,v_rows_inserted from data_statistics ds where dst_table_name=v_tab_name and dst_shrink_status =0;
          --  dbms_output.put_line('deleted rows '||rows_deleted);
          --        dbms_output.put_line('number of rows '||num_rows);
          v_percent_deleted :=( nvl(v_rows_deleted,0)/v_num_rows)*100;
          --dbms_output.put_line('precent of deleted '||percent_deleted);
           v_percent_inserted := (nvl(v_rows_inserted,0)/v_num_rows)*100;
          --dbms_output.put_line(rows_inserted||'                      '||percent_inserted);

                     if v_percent_deleted > v_delete_threshold and v_percent_inserted > v_insert_threshold then
                                             return 1;
                     end if;

          end loop;
               return 0;
  end table_shrink_check;

 procedure table_shrink(pi_table_name in VARCHAR2)
is
       v_status number(1) :=0;
       v_stat_status number(1):=0;
       v_tab_name varchar2(30 char) := upper(pi_table_name);
        pragma autonomous_transaction;
begin

            commons_ddl_handling.execute_ddl_nolog( 'ALTER TABLE '||v_tab_name||' MOVE');
            --dbms_output.put_line('table moved');

           for ind_rec in (select index_name from user_indexes where table_name =v_tab_name and status!='VALID')
                  loop

                             commons_ddl_handling.execute_ddl_nolog('ALTER INDEX '||ind_rec.index_name||' REBUILD');
                             --dbms_output.put_line(ind_rec.index_name||' rebuild');

                  end loop;
                   begin
                        commons_utils.CALCULATE_TABLE_STATISTICS(pi_table_name=>v_tab_name,
                                                                 PI_MODE => 1,
                                                                 po_status => v_stat_status);
                   exception
                        when others then null;
                   end;
                  -- dbms_output.put_line('stats gathered');
                 /*
                   update data_statistics ds
                      set ds.DST_SHRINK_STATUS = case
                       when DST_RECORDS_TIMESTAMP_UTC =
                           (select max(DST_RECORDS_TIMESTAMP_UTC)
                              from data_statistics dsin
                             where UPPER(dsin.DST_table_name) =v_tab_name
                               and dsin.DST_SHRINK_STATUS = 0) then
                                    1
                        else
                                   2
                        end
                   where  UPPER(ds.DST_table_name) = v_tab_name
                   and ds.DST_SHRINK_STATUS = 0  ;*/
                   -- dbms_output.put_line('recraete status chnaged');
             commit;
end table_shrink;


PROCEDURE PERSIST_EXEC_PLAN(pi_run_id in number default null)
AS
BEGIN

    INSERT INTO sql_execution_stats (ses_id,
                                    ses_sql_id,
                                    ses_run_id,
                                    ses_hash_value,
                                    ses_child_number,
                                    ses_operation,
                                    ses_options,
                                    ses_object_name,
                                    ses_optimizer,
                                    ses_cost,
                                    ses_cardinality,
                                    ses_access_predicates,
                                    ses_timestamp,
                                    ses_order_id,
                                    ses_projection,
                                    ses_filter_predicates)
      SELECT ses_id_seq.NEXTVAL,
             sei_sql_id,
             pi_run_id,
             sei_hash_value,
             sei_child_number,
             sei_operation,
             sei_options,
             sei_object_name,
             sei_optimizer,
             sei_cost,
             sei_cardinality,
             sei_access_predicates,
             sei_timestamp,
             sei_order_id,
             sei_projection,
             sei_filter_predicates
        FROM TEMP_SQL_EXECUTION_STATS;

END PERSIST_EXEC_PLAN;

FUNCTION Get_Max_Value(PI_TABLE_NAME  IN VARCHAR2,
                        PI_COLUMN_NAME IN VARCHAR2,
                        PI_FLAG        IN NUMBER) RETURN NUMBER IS
   V_return number;
begin

   if (PI_FLAG = 1) then

     -- dbms_output.put_line('SELECT /*+ index('||PI_TABLE_NAME||' PK_'||PI_TABLE_NAME||') */ MAX('||PI_COLUMN_NAME||') FROM '||PI_TABLE_NAME );
     execute immediate 'SELECT /*+ index(' || PI_TABLE_NAME || ' PK_' ||
                       PI_TABLE_NAME || ') */ MAX(' || PI_COLUMN_NAME ||
                       ') FROM ' || PI_TABLE_NAME
       into V_return;

   elsif (PI_FLAG = 2) then
     -- dbms_output.put_line( 'SELECT /*+ index('||PI_TABLE_NAME||' '||PI_TABLE_NAME||'_BUSINESSKEY_UI) */ MAX('||PI_COLUMN_NAME||') FROM '||PI_TABLE_NAME);
     execute immediate 'SELECT /*+ index(' || PI_TABLE_NAME || ' ' ||
                       PI_TABLE_NAME || '_BUSINESSKEY_UI) */ MAX(' ||
                       PI_COLUMN_NAME || ') FROM ' || PI_TABLE_NAME
       into V_return;

   end if;

   return V_return;

 end;

 FUNCTION Get_Max_Value(PI_TAB_COL IN TABLETYPE_TAB_COL)
  RETURN TABLETYPE_TAB_COL_VALUE IS
  V_return        NUMBER;
  v_TAB_COL_VALUE TABLETYPE_TAB_COL_VALUE := TABLETYPE_TAB_COL_VALUE();
BEGIN
  v_TAB_COL_VALUE.extend(PI_TAB_COL.count);
  FOR i IN 1 .. PI_TAB_COL.count LOOP
    V_return := get_max_value_single(pi_table_name => PI_TAB_COL(i)
                                                      .table_name,
                                     pi_col_name   => PI_TAB_COL(i).COL_NAME);

    v_TAB_COL_VALUE(i) := OBJTYPE_TAB_COL_VALUE(PI_TAB_COL(i).table_name,
                                                pI_TAB_COL(i).COL_NAME,
                                                V_return);

  END LOOP;
  RETURN v_TAB_COL_VALUE;
END;


FUNCTION get_max_value_single(pi_table_name IN VARCHAR2,
                                                pi_col_name   IN VARCHAR2)
  RETURN NUMBER IS
  po_max_number NUMBER;
  V_index_name  VARCHAR2(30);
  v_bool        NUMBER(1);
BEGIN
  Commons_indexing.get_index_name(PI_TABLE_NAME   => PI_TABLE_NAME,
        PI_COL_LIST     => SYS.HSBLKNAMLST(pi_col_name),
        PO_INDEX_NAME   => V_index_name,
        PO_INDEX_EXISTS => v_bool);

  EXECUTE IMMEDIATE 'SELECT  ' || CASE (v_bool)
                      WHEN 1 THEN
                       '   /*+ index(' || pi_table_name || ' ' ||
                       V_index_name || ') */ '
                    END || 'MAX(' || pi_col_name || ') FROM ' ||
                    pi_table_name
    INTO po_max_number;

  RETURN po_max_number;
END;



procedure Async_Plsql_Run(pi_plsql_code in varchar2, pi_comment in varchar2, pi_differentiator in number default null) as
PRAGMA AUTONOMOUS_TRANSACTION;
v_job_name varchar2(100 char):='APR_'||pi_differentiator||'_'||ASYNC_JOB_SEQ.nextval;
begin
  dbms_scheduler.create_job (
 job_name            => v_job_name,
 job_type            => 'PLSQL_BLOCK',
 job_action          => pi_plsql_code,
 number_of_arguments => 0,
 start_date          => null,
 enabled             => TRUE,
 auto_drop           => TRUE,
 comments            => pi_comment);

/*
DBMS_SCHEDULER.run_job (job_name            => v_job_name,
                          use_current_session => FALSE);*/


end Async_Plsql_Run;


PROCEDURE send_db_alert(pi_details VARCHAR2, pi_description VARCHAR2)
IS
v_is_riemann_enabled NUMBER(1);
BEGIN

  -- check if Riemann is installed
  SELECT CASE WHEN pr.pr_value = 'TRUE' THEN 1 ELSE 0 END
    INTO v_is_riemann_enabled
    FROM properties pr
   WHERE pr.pr_name = 'IS_RIEMANN_ENABLED';

  IF v_is_riemann_enabled = 1 THEN
    dba_utils.send_db_alert(pi_details, pi_description);
  END IF;
END;


PROCEDURE INSERT_LOGS (PI_CLOB IN CLOB)
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO SQL_TABLE (ROW_ID, COL1,CREATION_DATE) VALUES (SQL_TABLE_SEQ.NEXTVAL, PI_CLOB,systimestamp);
  commit;
EXCEPTION
  WHEN OTHERS THEN
    null;
END;


PROCEDURE UPDATE_OBJ_RES_NAME(pin_or_id IN coltype_id)
IS
TYPE v_obj_reg_rec IS RECORD
(v_or_id object_registration.or_id%TYPE,
 v_or_name object_registration.or_name%TYPE,
 v_or_res_name object_registration.or_resolved_name%TYPE
);

TYPE typ_obj_reg_tab IS TABLE OF v_obj_reg_rec;
v_rec typ_obj_reg_tab := typ_obj_reg_tab();

BEGIN

  IF pin_or_id.COUNT > 0 THEN
    SELECT or_id,
      or_name,
      commons_appframework.get_name(or_name) bulk collect
    INTO v_rec
    FROM object_registration START WITH or_id IN
      (select column_value from table(pin_or_id)) CONNECT BY or_name LIKE PRIOR CONCAT('%|~',CONCAT(or_id,'~|%'));

    Forall indx IN 1 .. v_rec.COUNT
    UPDATE object_registration
    SET or_resolved_name = v_rec(indx).v_or_res_name
    WHERE or_id = v_rec(indx).v_or_id;
  END IF;

END UPDATE_OBJ_RES_NAME;

PROCEDURE SEQ_REMAP_TRANS_LOGS(
    pin_table_name VARCHAR2 ,
    pin_trans_type VARCHAR2,
    pin_col_list   VARCHAR2,
    pin_col_val    VARCHAR2 ) -- in case of update statement, the string will be stored here
AS
  pragma autonomous_transaction;
  v_stmt CLOB;
BEGIN
  IF pin_trans_type = 'U' THEN --update
    v_stmt       := ' Update  '||pin_table_name ||' set  '||pin_col_val ;
  ELSE
    v_stmt := ' Insert into  '||pin_table_name || ' (' || pin_col_list ||' )  values  ( '|| pin_col_val || ' ) ' ;
  END IF ;

  EXECUTE immediate v_stmt;
  COMMIT;
END SEQ_REMAP_TRANS_LOGS ;


PROCEDURE SEQ_REMAP_RECYCLE_PROC
AS
  v_today            VARCHAR2(15) ;
  v_exec_switch_flg  VARCHAR2(5) ;
   v_kill_job_flg VARCHAR2(5) ;
  v_diff_value       NUMBER := 0 ;
  v_min_rowid        NUMBER := 0 ;
  v_max_rowid        NUMBER :=0;
  v_child_table_cnt  NUMBER :=0;
  v_child_sql        VARCHAR2(500) ;
  v_child_table_name AUDIT_TABLES.AT_AUDIT_TABLES_ID%TYPE  ;
  v_rowid_col_name   ALL_TAB_COLUMNS.COLUMN_NAME%TYPE;
  v_bkp_table_exists pls_integer   := 0 ;
  v_table_row_cnt pls_integer      := 0 ;
  v_table_name_suffix    VARCHAR2(10) := '_BKP_RR' ; -- backup table suffix
  v_seq_start_val        NUMBER;
  v_ref_no               NUMBER;
  v_lock_id              NUMBER; --locking starts
  v_run_id               NUMBER ;
  v_Transaction_ID       VARCHAR2(100) ;
  v_server_name          VARCHAR2(100) ;
  v_msg                  VARCHAR2(1000) ;
  v_orphan_record_cnt    NUMBER ;
  v_lock_mode            NUMBER := 2 ;
  v_child_table_type     TABLES.TABLES_TYPE%TYPE ;
  v_update_limit         NUMBER ;
  e_custom              EXCEPTION;
  e_exit_parent_loop EXCEPTION;
  v_constraint_name      ALL_CONSTRAINTS.CONSTRAINT_NAME%TYPE;
  v_bracket_changes_flag VARCHAR2(1);
TYPE reftype_child_tab IS  REF  CURSOR;
    v_child_tab_cursor reftype_child_tab ;
TYPE tabletype_orphan_coll IS  TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  v_orphan_coll tabletype_orphan_coll;
TYPE rtype_old_new_coll IS  record  (
    old_rowid NUMBER,
    new_rowid NUMBER );
TYPE tabletype_old_new_coll IS  TABLE OF rtype_old_new_coll;
  v_table_col tabletype_old_new_coll        :=tabletype_old_new_coll();
  v_temp_table_name VARCHAR2(30) := 'SEQ_REMAP_COL_TEMP' ;
  v_cur_stmt CLOB                 := 'select OLD_ROWID , NEW_ROWID   from  '|| v_temp_table_name ||'  ';
  v_old_rowid NUMBER ;
  v_new_rowid NUMBER ;
  v_batch_seq number ;
TYPE coltype_val_coll IS   REF  CURSOR;
    v_coltype_val_coll coltype_val_coll;

    /* Below query provides all the child tables which are dependant on the Parent Data table */
    v_child_table_script CLOB := ' SELECT AT_AUDIT_TABLES_ID , ''ADJUSTED_RECORD_ID'' ,''AUDIT_TABLE''
          FROM tables t
          INNER JOIN audit_tables ad
          ON at_audited_tables_id = TABLES_ID
          and TABLES_ID = :p_table_id
          GROUP BY AT_AUDIT_TABLES_ID ' || ' union ' ||
              ' SELECT REQUEST_TABLES_ID  ,''ASSOCIATED_DATA_RECORD_ID'' ,''WORKFLOW_TABLE''
          FROM
          (SELECT to_number(extractvalue(xmltype(dbms_xmlgen.getxml(''select distinct  table_name c  from (select ''''''
          ||WA_REQUESTS_TABLES_ID
          ||'''''' table_name  from T''
          ||WA_REQUESTS_TABLES_ID
          || '' where ASSOCIATED_TO_DATA_RECORD = 1 ) '' )),''/ROWSET/ROW/C'')) AS REQUEST_TABLES_ID,
          to_number(extractvalue(xmltype(dbms_xmlgen.getxml(''select count(1) c  from ''
          ||''T''
          ||WA_REQUESTS_TABLES_ID
          || '' where ASSOCIATED_TO_DATA_RECORD = 1   '' )),''/ROWSET/ROW/C'')) AS REQUEST_TABLES_CNT
          FROM tables tab ,
          table_references tref ,
          WORKFLOW_APPLICATIONS wa
          WHERE tab.tables_definition_id = tref.tref_definition_id
          AND tref.tref_id               = wa.wa_tref_Id
          AND wa_assoc_with_tbl_recs     =1
          and TABLES_ID = :p_table_id
          )
          WHERE REQUEST_TABLES_CNT > 0   '     ;
    /*********************************************************************************************************************************/
  BEGIN
      select pr_value INTO v_today  from properties where PR_NAME = 'SEQUENCE_REMAPPING_WEEKDAY'  ;

     select pr_value INTO v_exec_switch_flg from properties where PR_NAME = 'SEQUENCE_REMAPPING_EXEC_FLG'  ;


    /* This procedure must be executed on a specific day as configured in properties table */
    IF TO_CHAR(sysdate,'FMDAY') <> v_today OR v_exec_switch_flg = 'N' THEN
      RETURN;
    END IF ;

    FOR i IN
    (
	SELECT user_tab.table_name table_name ,
		  TABLES_NAME,
		  tables_id,
		  tables_definition_id ,
		  tables_type parent_table_type ,
		  tab.tables_rowid_seq_name,
		  tab. TABLES_physical_NAME,
		  user_seq.sequence_name,
		  user_tab.num_rows total_rows_intable,
		  user_seq.LAST_NUMBER
		FROM user_tables user_tab
		JOIN tables tab
		ON user_tab.table_name = tab.TABLES_physical_NAME
		JOIN user_sequences user_seq
		ON user_seq.sequence_name = tab.tables_physical_name
		  || '_ROW_IDENTIFIER_SEQ'
		AND tables_type           = 'DATA_TABLE'
		AND user_seq.LAST_NUMBER >=
		  (SELECT pr_value
		  FROM properties
		  WHERE PR_NAME = 'SEQUENCE_REMAPPING_THRESHOLD'
		  ) -- Configured value to set the limit post which remapping will be executed
		    )
    LOOP



  /* In case v_kill_job_flg is Y, the further execution of proc will be killed */
		  select pr_value INTO v_kill_job_flg  from properties where PR_NAME = 'SEQUENCE_REMAPPING_KILL_JOB_FLG'   ;
			IF v_kill_job_flg = 'Y' THEN
			  EXIT;
			END IF ;


        BEGIN
          /**************************************************************************************************************************************************************/
          /* When request gets deleted from workflow table, the request tables record doesnt gets deleted. Due to which we need to manully nullify those orphan records
          we must do the nullifying process before updating new row_identifiers so that it doesnt pointer to wrong record */
          /*  Child table loop starts: according to the process flag, column name will be stored*/
          v_run_id         := NULL;
          v_Transaction_ID := NULL;
          SELECT uid_sequence.nextval ,
            commons_ddl_handling.get_transaction_id,
            sys_context('USERENV','SERVER_HOST')
          INTO v_run_id ,
            v_Transaction_ID,
            v_server_name
          FROM dual ;

          -- 1 for SHARED, 2 for WX and 3 for FX
          app_locking.Acquire_Lock ( i.table_name,v_server_name , v_lock_mode, v_run_id , v_Transaction_ID , v_lock_id ) ;
          --In case table is alredy in lock state, then skip the table and exit
          IF v_lock_id IS NULL THEN
              v_ref_no := SEQ_REMAP_REF_SEQ.nextval ;


              commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>  'SEQ_REMAP_SUMMARY',
                                                                                    pin_trans_type =>  'I',
                                                                                    pin_col_list   => 'SRS_REF_NO, SRS_TABLE_NAME, SRS_TABLE_BUSINESS_NAME, SRS_TABLE_SEQ_NAME, SRS_PROC_START_TIME',
                                                                                    pin_col_val    => v_ref_no||','''|| i.table_name||''','''|| i.TABLES_NAME||''','''||i.sequence_name||''',current_timestamp' ) ;



              commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>  'SEQ_REMAP_LOGS' ,
                                                                                pin_trans_type =>  'I',
                                                                                pin_col_list   =>  'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE',
                                                                                pin_col_val    => v_ref_no||','''|| i.table_name||''','''||i.parent_table_type ||''',''WARNING'', '' Unable To Acquire Lock on : '||i.table_name ||'. '', current_timestamp '    ) ;

            RAISE e_exit_parent_loop ;

           ELSE
           /* acquire lock on all the child tables. In case any of the child table is already in lock state, skip the current parent and child tables*/
                    OPEN v_child_tab_cursor FOR v_child_table_script USING i.tables_id, i.tables_id ;
                    LOOP
                      FETCH v_child_tab_cursor
                      INTO v_child_table_name,v_rowid_col_name,  v_child_table_type ;
                      EXIT  WHEN v_child_tab_cursor%NOTFOUND;

                      app_locking.Acquire_Lock ( 'T'||v_child_table_name ,v_server_name , v_lock_mode, v_run_id , v_Transaction_ID , v_lock_id ) ;

                      IF v_lock_id IS NULL THEN
                         v_ref_no := SEQ_REMAP_REF_SEQ.nextval  ;


                    commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>  'SEQ_REMAP_SUMMARY',
                                                                                                      pin_trans_type => 'I',
                                                                                                      pin_col_list   =>  ' SRS_REF_NO, SRS_TABLE_NAME, SRS_TABLE_BUSINESS_NAME, SRS_TABLE_SEQ_NAME, SRS_PROC_START_TIME' ,
                                                                                                      pin_col_val    =>  v_ref_no||','''|| i.table_name||''','''|| i.TABLES_NAME||''','''||i.sequence_name||''',current_timestamp' ) ;



                    commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>  'SEQ_REMAP_LOGS' ,
                                                                                                      pin_trans_type =>  'I',
                                                                                                      pin_col_list   => 'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE',
                                                                                                      pin_col_val    =>  v_ref_no||',''T'||v_child_table_name ||''','''||v_child_table_type ||''',''WARNING'', '' Unable To Acquire Lock on : T'||v_child_table_name ||'. '', current_timestamp '  ) ;

                        app_locking.ReleaseLockByRunID (v_run_id);

                        raise e_exit_parent_loop ;
                      END IF ;
                    END LOOP ;
          END IF ;


            select count(1) INTO v_bkp_table_exists from user_tables where table_name = v_temp_table_name ;

            IF v_bkp_table_exists > 0 THEN
              commons_ddl_handling.execute_ddl_nolog(' DROP TABLE '||v_temp_table_name );
            END IF;

            commons_ddl_handling.execute_ddl_nolog( '  create table '||v_temp_table_name ||' as select ROW_IDENTIFIER OLD_ROWID  , rownum  NEW_ROWID  FROM  ( SELECT ROW_IDENTIFIER from ' || i.table_name|| ' ORDER BY ROW_IDENTIFIER )' );

            v_ref_no := SEQ_REMAP_REF_SEQ.nextval  ;

          v_seq_start_val := i.LAST_NUMBER ;


  commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>  'SEQ_REMAP_SUMMARY',
                                                                                    pin_trans_type =>  'I',
                                                                                    pin_col_list   =>  ' SRS_REF_NO, SRS_TABLE_NAME, SRS_TABLE_BUSINESS_NAME, SRS_TABLE_SEQ_NAME, SRS_CHILD_TABLE_CNT, SRS_SEQ_AT_START_VAL, SRS_PROC_START_TIME',
                                                                                    pin_col_val    => v_ref_no||','''|| i.table_name||''','''|| i.TABLES_NAME||''','''||i.sequence_name||''','||v_child_table_cnt||','||v_seq_start_val||',current_timestamp' ) ;


          v_child_table_cnt := 0 ;
          OPEN v_child_tab_cursor FOR v_child_table_script USING i.tables_id,
          i.tables_id ;
          LOOP
            FETCH v_child_tab_cursor
            INTO v_child_table_name,
              v_rowid_col_name,
              v_child_table_type ;
            EXIT
          WHEN v_child_tab_cursor%NOTFOUND;

  commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>   'SEQ_REMAP_LOGS',
                                                                                    pin_trans_type =>   'I',
                                                                                    pin_col_list   => 'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                    pin_col_val    =>   v_ref_no||',''T'||v_child_table_name||''','''||v_child_table_type ||''', ''SUCCESS'' , ''Attempt Orphan Rec'', current_timestamp '  ) ;


            /* Updation of orphan records */
            EXECUTE immediate '  UPDATE '|| ' T' ||v_child_table_name ||'  child_tab SET '||v_rowid_col_name ||'   = '||v_rowid_col_name ||' * (-1)   WHERE '||v_rowid_col_name ||' > 0 and  '||v_rowid_col_name || ' not in   ( SELECT  ROW_IDENTIFIER FROM
  '||i.tables_physical_name ||'
  WHERE  ROW_IDENTIFIER =  child_tab.'||v_rowid_col_name||' )   RETURNING ( select DISTINCT  '||v_rowid_col_name||' from ' || ' T' ||v_child_table_name || ' where  ' ||v_rowid_col_name ||' = child_tab.'||v_rowid_col_name||' )
  into :v_orphan_coll  ' returning bulk collect INTO v_orphan_coll;

            /*Audit for nullified orphan records */
            FOR j IN 1..v_orphan_coll.count
            LOOP
        commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>  'SEQ_REMAP_AUDIT',
                                                                                        pin_trans_type =>      'I' ,
                                                                                        pin_col_list   =>  'SRA_REF_NO, SRA_TABLE_NAME, SRA_OLD_ROW_ID, SRA_NEW_ROW_ID, SRA_RULE_FLAG' ,
                                                                                        pin_col_val    => v_ref_no||',''T'||v_child_table_name||''','||v_orphan_coll(j) || ','||v_orphan_coll(j)||' *(-1) , ''O'''  ) ;

            END LOOP ;

            IF v_orphan_coll.count > 0 THEN

                        commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>   'SEQ_REMAP_LOGS',
                                                                                  pin_trans_type =>      'I',
                                                                                  pin_col_list   =>   'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                  pin_col_val    =>    v_ref_no||',''T'||v_child_table_name||''','''||v_child_table_type ||''',''SUCCESS'', ''Success Orphan Rec'', current_timestamp '  ) ;
            ELSE

                  commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>   'SEQ_REMAP_LOGS',
                                                                                                  pin_trans_type =>   'I',
                                                                                                  pin_col_list   =>  'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                                  pin_col_val    =>   v_ref_no||',''T'||v_child_table_name||''','''||v_child_table_type ||''',''SUCCESS'', ''Orphan Rec Not Found'', current_timestamp '  ) ;

            END IF;

            /*  Child table loop ends*/
            v_child_table_cnt := v_child_table_cnt + 1 ;
          END LOOP;


          /**************************************************************************************************************************************************************/
          /* Below code is for starting the sequence from 1 and updating all the rowids available in the table respectively */
          v_diff_value           := 0 ;
          v_max_rowid            := 0 ;
          v_min_rowid            := 0 ;
          v_bkp_table_exists     := 0 ;
          v_table_row_cnt        := 0 ;
          v_child_table_name     := '';
          v_bracket_changes_flag := '';
           select pr_value INTO v_update_limit from properties where PR_NAME = 'SEQUENCE_REMAPPING_LOOP_LIMIT'   ;

          EXECUTE immediate ' SELECT COUNT(1) ,  NVL (MIN(row_identifier),0) ,  NVL(MAX(row_identifier),0) ,  NVL( MAX(row_identifier),0) - NVL(MIN (row_identifier),0) +1  from  ' || i.table_name INTO v_table_row_cnt ,
          v_min_rowid ,
          v_max_rowid ,
          v_diff_value ;

          IF v_table_row_cnt = 0 THEN
          commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>   'SEQ_REMAP_LOGS',
                                                                                            pin_trans_type =>     'I',
                                                                                            pin_col_list   =>  'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                            pin_col_val    => v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''', ''SUCCESS'' , ''No Records Exists In Table'', current_timestamp '  ) ;


                    /* If total number of rows in table not macthing with the difference between max and min rowid / all the rowids are in one single bracket but bracket does not start with 1  then we will move the bracket from 1*/
          ELSIF ( (v_table_row_cnt <> v_diff_value ) OR (v_min_rowid <> 1 ) ) THEN
                    v_bracket_changes_flag := 'Y' ;

                    BEGIN

                        select count(1)  INTO v_bkp_table_exists from user_tables where table_name = i.table_name||v_table_name_suffix;

                        IF v_bkp_table_exists > 0 THEN
                          commons_ddl_handling.execute_ddl_nolog(' DROP TABLE '||i.table_name||v_table_name_suffix);
                        END IF;
                        commons_ddl_handling.execute_ddl_nolog( ' Create Table '|| i.table_name||v_table_name_suffix || '  as select * from  '|| i.table_name); --backup table creation



          commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>   'SEQ_REMAP_LOGS',
                                                                                            pin_trans_type =>   'I',
                                                                                            pin_col_list   => 'SRL_REF_NO, SRL_LOG_TABLE_NAME, SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE ,  SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                            pin_col_val    =>  v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''SUCCESS'', ''Attempt Bracket'' , current_timestamp  ' ) ;



                      /**************************************************************************************/
                      v_cur_stmt                  := 'select OLD_ROWID , NEW_ROWID   from  '|| v_temp_table_name ||' order by NEW_ROWID  ';

                      v_batch_seq := 1;

                        OPEN v_coltype_val_coll FOR  v_cur_stmt ; --Fetch the old and new rowid in cursor using the configured limit
                        LOOP  --loop bracket updation starts
                          FETCH v_coltype_val_coll bulk collect INTO v_table_col limit v_update_limit ;
                          EXIT
                        WHEN v_table_col.count =0;

                          FORALL  j IN 1..v_table_col.count
                          /* Using the old and new rowids fetched in cursor, update the parent table and also parallaly update the child table */
                          EXECUTE immediate ' update '||i.table_name|| ' set ROW_IDENTIFIER =  : new_rowid where  ROW_IDENTIFIER = :old_rowid ' USING v_table_col(j).new_rowid ,
                          v_table_col(j).old_rowid;

                           OPEN v_child_tab_cursor FOR v_child_table_script USING i.tables_id ,  i.tables_id ; --This loops all the child tables
                           LOOP
                        FETCH v_child_tab_cursor
                        INTO v_child_table_name, v_rowid_col_name ,  v_child_table_type;
                        EXIT
                      WHEN v_child_tab_cursor%NOTFOUND;
                        /* child table script and updation */
                        v_child_sql := '  UPDATE '|| ' T' ||v_child_table_name ||' SET '||v_rowid_col_name ||'    = : new_rowid where  '||v_rowid_col_name||'   =  :old_rowid  ' ;


                          FORALL j IN 1..v_table_col.count
                          EXECUTE immediate v_child_sql USING v_table_col(j).new_rowid , v_table_col(j).old_rowid ;


                      END LOOP; ---Child loop ends here

                      CLOSE v_child_tab_cursor ;

							COMMIT;

                  commons_utils.SEQ_REMAP_TRANS_LOGS (   pin_table_name =>    'SEQ_REMAP_LOGS',
                                            pin_trans_type =>    'I',
                                            pin_col_list   =>  'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                            pin_col_val    =>  v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''SUCCESS'', ''Batch Committed : '||v_batch_seq||''' , current_timestamp '  ) ;

                     v_batch_seq := v_batch_seq + 1 ;

                        END LOOP;   --loop of collection (New/Old Rowid updated) ends
                        CLOSE v_coltype_val_coll;

                    END;

          commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>    'SEQ_REMAP_LOGS',
                                                                                            pin_trans_type =>    'I',
                                                                                            pin_col_list   =>  'SRL_REF_NO,SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE ,  SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                            pin_col_val    =>   v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''SUCCESS'', ''Success Bracket'' , current_timestamp ' ) ;
          END IF; /* Loop of bracket check ends here */

          /* Updating the completion time */
  commons_utils.SEQ_REMAP_TRANS_LOGS (   pin_table_name =>   'SEQ_REMAP_SUMMARY' ,
                                                                                      pin_trans_type =>    'U' ,
                                                                                      pin_col_list   => '',
                                                                                      pin_col_val    =>  'SRS_PROC_END_TIME =    CURRENT_TIMESTAMP   , SRS_CHILD_TABLE_CNT = ' || v_child_table_cnt ||'   Where SRS_REF_NO = ' ||v_ref_no   ) ;

          /*************************************************************************************/
          /* Fails Safe Checks Starts Here */
          v_diff_value        := 0 ;
          v_max_rowid         := 0 ;
          v_min_rowid         := 0 ;
          v_bkp_table_exists  := 0 ;
          v_table_row_cnt     := 0 ;
          v_orphan_record_cnt :=0 ;
          v_constraint_name   := NULL;
          /* There should not be any orphan record exists in child tables */
          OPEN v_child_tab_cursor FOR v_child_table_script USING i.tables_id ,
          i.tables_id;
          LOOP
            FETCH v_child_tab_cursor
            INTO v_child_table_name,
              v_rowid_col_name ,
              v_child_table_type ;
            EXIT
          WHEN v_child_tab_cursor%NOTFOUND;
            EXECUTE immediate ' SELECT count(1)
                                                FROM  T'||v_child_table_name || '  a
                                                WHERE NOT EXISTS
                                                (SELECT ROW_IDENTIFIER
                                                FROM ' || i.table_name || '
                                                WHERE ROW_IDENTIFIER = a.'||v_rowid_col_name ||'
                                                )  and a.'||v_rowid_col_name || ' > 0 ' INTO v_orphan_record_cnt ;
          END LOOP;

          IF v_orphan_record_cnt > 0 THEN -- Orphan record found

    commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>  'SEQ_REMAP_LOGS',
                                                                                      pin_trans_type =>    'I',
                                                                                      pin_col_list   => 'SRL_REF_NO, SRL_LOG_TABLE_NAME,SRL_LOG_TABLE_TYPE ,  SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                      pin_col_val    =>  v_ref_no||','''||i.Table_name||''','''||i.parent_table_type ||''',''ERROR'' , ''Error.Orphan Rec Found'' , current_timestamp '  ) ;

              RAISE e_custom;
          ELSE
            /* If orphan records not exists, then check the total records count in the table should be difference between max and min rowidentifier  and also the bracket  should start from 1 */
            EXECUTE immediate ' select  count(1), NVL(min(row_identifier),0)  , NVL(max(row_identifier),0) , nvl( max(row_identifier),0) - nvl(min (row_identifier),0) +1  from  ' || i.table_name INTO v_table_row_cnt ,
            v_min_rowid ,
            v_max_rowid ,
            v_diff_value ;

            IF ( v_table_row_cnt > 0 AND ( (v_table_row_cnt <> v_diff_value ) OR (v_min_rowid  <>  1 ) ) )THEN --Total count is not maching with diff between max and min rowid OR if the bracket is not staring from 1 then we must rollback

          commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>  'SEQ_REMAP_LOGS',
                                                                                            pin_trans_type =>   'I',
                                                                                            pin_col_list   => 'SRL_REF_NO,SRL_LOG_TABLE_NAME ,SRL_LOG_TABLE_TYPE ,  SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                            pin_col_val    =>   v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''ERROR'', ''Error.Incorrect Bracket'' , current_timestamp ' ) ;
              RAISE e_custom;
            ELSE
              /* Successfully compeleted the proc */
              IF ( ( (v_table_row_cnt = v_diff_value ) AND (v_min_rowid = 1 )) OR v_table_row_cnt = 0 ) THEN --Sucessfully completed the updates

                select count(1)  INTO v_bkp_table_exists from user_tables where table_name =  v_temp_table_name ;

                IF v_bkp_table_exists       > 0 THEN
                  IF v_bracket_changes_flag = 'Y' THEN  -- If process has update the bracket, then maintain the audit of old and new rowid
                           EXECUTE immediate ' INSERT
                          INTO SEQ_REMAP_AUDIT
                          (
                          SRA_REF_NO,
                          SRA_TABLE_NAME,
                          SRA_OLD_ROW_ID,
                          SRA_NEW_ROW_ID,
                          SRA_RULE_FLAG
                          )  select '|| v_ref_no ||'  , '''|| i.table_name ||''',  old_rowid, new_rowid ,  ''B'' from  '||v_temp_table_name ;
                    COMMIT;
                  END IF;
                  commons_ddl_handling.execute_ddl_nolog(' DROP TABLE  '||v_temp_table_name );
                END IF;

                select count(1) INTO v_bkp_table_exists from user_tables where table_name =  i.table_name||v_table_name_suffix  ;

                IF v_bkp_table_exists > 0 THEN
                  commons_ddl_handling.execute_ddl_nolog(' DROP TABLE '||i.table_name||v_table_name_suffix);
                END IF;

                SELECT CASE v_max_rowid WHEN 1 THEN 2 ELSE v_max_rowid END INTO v_max_rowid FROM dual ; -- In case only one record exists in table, the reset sequence API was not updating the next val as 2. To handle, this code is written here
                /* After successfull completion, reset the sequence */
                commons_utils.reset_seq_at(i.sequence_name ,--sequence name
                v_max_rowid +1,                             -- number upto which you want to reset the value of sequence
                v_Transaction_ID , v_run_id, 0              -- pi_reg_undo_ddl_flag
                );

                IF v_run_id IS NOT NULL THEN
                  app_locking.ReleaseLockByRunID (v_run_id);
                END IF ;


              commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>    'SEQ_REMAP_LOGS',
                                                                                    pin_trans_type =>    'I',
                                                                                    pin_col_list   =>   'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                    pin_col_val    =>   v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''SUCCESS'', ''Successful Completion'' , current_timestamp '   ) ;
              ELSE
                /* updates not successfully and we did not get the Exact Reason of failure then log the error  */
              	app_locking.ReleaseLockByRunID (v_run_id);

                commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>    'SEQ_REMAP_LOGS',
                                                                                                  pin_trans_type =>   'I',
                                                                                                  pin_col_list   =>    'SRL_REF_NO,SRL_LOG_TABLE_NAME ,  SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE, SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                                  pin_col_val    =>  v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''ERROR'' , ''Error.Failure in Proc'' , current_timestamp '  ) ;
                RAISE e_custom;
              END IF;

            END IF;
          END IF;
        EXCEPTION
        WHEN e_custom THEN
          /* In case fail safe found any case, we have to update back all the updated transactions with old value. Here we have to disable the primary key constrains of table and then post update enable again*/
             IF v_bracket_changes_flag ='Y' then
          BEGIN
              SELECT all_cons.CONSTRAINT_NAME  INTO v_constraint_name
                      FROM all_constraints all_cons ,
                      ALL_CONS_COLUMNS all_cons_cols
                      WHERE all_cons.table_name     =all_cons_cols.table_name
                      AND all_cons.CONSTRAINT_NAME  = all_cons_cols.CONSTRAINT_NAME
                      AND all_cons_cols.table_name  =i.table_name
                      AND all_cons.CONSTRAINT_TYPE  = 'P'
                      AND all_cons_cols.COLUMN_NAME = 'ROW_IDENTIFIER' ;
          EXCEPTION
          WHEN OTHERS THEN

     commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>    'SEQ_REMAP_LOGS',
                                                                                    pin_trans_type =>    'I',
                                                                                    pin_col_list   =>  'SRL_REF_NO, SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                    pin_col_val    =>  v_ref_no||','''||i.parent_table_type ||''',''WARNING'', '' Unable To Fetch Table Constraint : '||i.table_name ||'. '', current_timestamp ' ) ;

          END ;


          BEGIN  --Rollbacking updates starts here

          IF v_constraint_name IS NOT NULL THEN
            commons_ddl_handling.execute_ddl_nolog(' alter table  '||i.table_name || ' DISABLE constraint   '||v_constraint_name  ) ;
          END IF ;

           v_cur_stmt   := 'select OLD_ROWID , NEW_ROWID   from  '|| v_temp_table_name ||'  order by NEW_ROWID desc ';

          v_batch_seq := 1 ;
             OPEN v_coltype_val_coll FOR  v_cur_stmt ; --Fetch the old and new rowid in cursor using the configured limit
                        LOOP  --loop bracket updation starts
                          FETCH v_coltype_val_coll bulk collect INTO v_table_col limit v_update_limit ;
                          EXIT
                        WHEN v_table_col.count =0;

                          FORALL  j IN 1..v_table_col.count
                          /* Using the old and new rowids fetched in cursor, update the parent table and also parallaly update the child table */

							EXECUTE immediate  ' update '||i.table_name|| ' set ROW_IDENTIFIER =  : old_rowid where  ROW_IDENTIFIER = :new_rowid  '
                          USING v_table_col(j).old_rowid ,
                          v_table_col(j).new_rowid ;

                           OPEN v_child_tab_cursor FOR v_child_table_script USING i.tables_id ,  i.tables_id ; --This loops all the child tables
                           LOOP
                        FETCH v_child_tab_cursor
                        INTO v_child_table_name, v_rowid_col_name ,  v_child_table_type;
                        EXIT
                      WHEN v_child_tab_cursor%NOTFOUND;
                        /* child table script and updation */
                       v_child_sql := '  UPDATE '|| ' T' ||v_child_table_name ||' SET '||v_rowid_col_name ||'    =  :old_rowid where  '||v_rowid_col_name||'   =  :new_rowid  ' ;



                          FORALL j IN 1..v_table_col.count
                          EXECUTE immediate v_child_sql  USING v_table_col(j).old_rowid ,
                          v_table_col(j).new_rowid ;



                      END LOOP; ---Child loop ends here

                      CLOSE v_child_tab_cursor ;

								 COMMIT;

                  commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>  'SEQ_REMAP_LOGS',
                                                                                                    pin_trans_type =>    'I',
                                                                                                    pin_col_list   =>   'SRL_REF_NO, SRL_LOG_TABLE_NAME , SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                                    pin_col_val    => v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''SUCCESS'', ''Batch Rollbacked : '||v_batch_seq||''' , current_timestamp ' ) ;

                     v_batch_seq := v_batch_seq + 1 ;

                        END LOOP;   --loop of collection (New/Old Rowid updated) ends
                        CLOSE v_coltype_val_coll;

          IF v_constraint_name IS NOT NULL THEN
           commons_ddl_handling.execute_ddl_nolog(' alter table  '||i.table_name || ' ENABLE constraint   '||v_constraint_name ) ;
          END IF ;

          app_locking.ReleaseLockByRunID (v_run_id);

  commons_utils.SEQ_REMAP_TRANS_LOGS ( pin_table_name =>  'SEQ_REMAP_LOGS',
                                                                                  pin_trans_type =>  'I',
                                                                                  pin_col_list   => 'SRL_REF_NO,SRL_LOG_TABLE_NAME ,SRL_LOG_TABLE_TYPE ,  SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                  pin_col_val    => v_ref_no||','''||i.table_name||''','''||i.parent_table_type ||''',''SUCCESS'', ''Rollback Executed Successfully'' , current_timestamp ' ) ;


             select count(1) INTO v_bkp_table_exists from user_tables where table_name = v_temp_table_name ;
            IF v_bkp_table_exists > 0 THEN
              commons_ddl_handling.execute_ddl_nolog(' DROP TABLE '||v_temp_table_name );
            END IF;

       Exception when others then
        v_msg := SUBSTR(sqlerrm,1,200) ;

          commons_utils.SEQ_REMAP_TRANS_LOGS (pin_table_name =>  'SEQ_REMAP_LOGS',
                                                                                            pin_trans_type =>      'I',
                                                                                            pin_col_list   => 'SRL_REF_NO ,  SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                            pin_col_val    => v_ref_no||', ''ERROR'' , ''Unable To Rollback '||v_msg||''', current_timestamp ' ) ;
       END ; --  --Rollbacking updates ends here

    ELSE
      app_locking.ReleaseLockByRunID (v_run_id);
     END IF ;
     /* In case any of the child table is already in lock state then skip the complete loop of parent and its respective child tables*/
       WHEN e_exit_parent_loop THEN

                     commons_utils.SEQ_REMAP_TRANS_LOGS (   pin_table_name =>   'SEQ_REMAP_SUMMARY' ,
                                                                                      pin_trans_type =>    'U' ,
                                                                                      pin_col_list   => '',
                                                                                      pin_col_val    =>  'SRS_PROC_END_TIME =    CURRENT_TIMESTAMP   , SRS_CHILD_TABLE_CNT = ' || v_child_table_cnt ||'   Where SRS_REF_NO = ' ||v_ref_no   ) ;

                    commons_utils.SEQ_REMAP_TRANS_LOGS (pin_table_name =>   'SEQ_REMAP_LOGS',
                                                                                                    pin_trans_type =>   'I',
                                                                                                    pin_col_list   => 'SRL_REF_NO, SRL_LOG_TABLE_NAME ,SRL_LOG_TABLE_TYPE , SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                                    pin_col_val    =>  v_ref_no||','''||i.table_name ||''','''||i.parent_table_type ||''',''WARNING'', '' Unable To Acquire Lock.Skipping the Table.'||i.table_name ||''', current_timestamp '  ) ;

        WHEN OTHERS THEN
          app_locking.ReleaseLockByRunID (v_run_id);
          v_msg := SUBSTR(sqlerrm,1,200) ;

            commons_utils.SEQ_REMAP_TRANS_LOGS (pin_table_name =>    'SEQ_REMAP_LOGS',
                                                                                  pin_trans_type =>      'I',
                                                                                  pin_col_list   =>    'SRL_REF_NO ,  SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                  pin_col_val    =>  v_ref_no||', ''ERROR'' , ''Error.Failure in Proc '||v_msg||''', current_timestamp ' ) ;
        END ;

    END LOOP;
  EXCEPTION
  WHEN OTHERS THEN
    v_msg := SUBSTR(sqlerrm,1,200) ;

commons_utils.SEQ_REMAP_TRANS_LOGS (  pin_table_name =>  'SEQ_REMAP_LOGS',
                                                                                  pin_trans_type =>  'I',
                                                                                  pin_col_list   => 'SRL_REF_NO ,  SRL_LOG_TYPE , SRL_LOG_TEXT, SRL_LOG_DATE' ,
                                                                                  pin_col_val    => v_ref_no||', ''ERROR'' , ''Error.Failure in Proc. '||v_msg||''', current_timestamp '  ) ;
  END ;


END commons_utils;
/
