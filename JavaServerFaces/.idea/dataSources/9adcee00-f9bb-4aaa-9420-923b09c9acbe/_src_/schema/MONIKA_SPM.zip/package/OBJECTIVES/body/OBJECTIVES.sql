CREATE PACKAGE BODY OBJECTIVES AS
-- *******************************    PRIVATE METHODS START    *******************************

/* MODIFY_OBJECTIVES_SCORES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- Assumptions:
    pi_operation    = 1 - APPROVE_OBJECTIVES
                    = 2 - APPROVE_SCORES
                    = 3 - UNAPPROVE_OBJECTIVES
                    = 4 - UNAPPROVE_SCORES
-----------------------------------------------------------------------------------------------
-- History:
    2013.12.02 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION MODIFY_OBJECTIVES_SCORES
(    pi_operation               IN NUMBER
    ,pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
    ,pi_stamp                   IN VARCHAR2
) RETURN SYS_REFCURSOR IS
    v_validations               TABLETYPE_OBJECTIVE_VLD;
    v_def_validations           OBJTYPE_OBJECTIVE_VLD;
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    vrec_score_scale            OBJ_SCORE_SCALES%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_ent_table_name            VARCHAR2(200 CHAR);
    v_obj_table_name            VARCHAR2(200 CHAR);
    v_operation_type            VARCHAR2(50 CHAR);
    v_temp                      VARCHAR2(2000 CHAR);
    v_vld_when_sql              CLOB;
    v_vld_outer_select_sql      CLOB;
    v_vld_inner_select_sql      CLOB;
    v_vld_inner_col_list        CLOB;
    v_score_join_sql            CLOB;
    v_init_list_sql             CLOB;
    v_vld_from_sql              CLOB;
    v_upd_exists_sql            CLOB;
    v_hlp_approval_descr        CLOB;
    v_hlp_approval_tech         CLOB;
    v_sql                       CLOB;
    v_operation_prefix          CHAR(1);
    vcur_result                 SYS_REFCURSOR;
BEGIN
    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),        ',pi_definition_id => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),            ',pi_period_id => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_user_name),          ',pi_user_name => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_user_entity_bk),     ',pi_user_entity_bk => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_approval_mode),        ',pi_approval_mode => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_obj_entity_list),  ',pi_obj_entity_list => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_obj_entity_qry),         ',pi_obj_entity_qry => <value>', pi_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),          ',pi_hierarchy_qry => <value>', pi_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_period_id IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which entities need to be added must not be null.'); END IF;
        IF (pi_user_name IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The user name provided must not be null.'); END IF;
        IF (pi_approval_mode NOT IN (1, 2))         THEN RAISE_APPLICATION_ERROR(-20001, 'The approval must come either from admin side or portal side.'); END IF;
        IF (pi_obj_entity_list IS NULL
            AND pi_obj_entity_qry IS NULL)          THEN RAISE_APPLICATION_ERROR(-20001, 'The parameters to identify the entities that need approvals are invalid .'); END IF;
    END;

    -- calculate applicable validations depending on the type of operation
    -- some of the resulting validations will further be filtered depending on the properties of the appraisals definition
    BEGIN
        v_validations := TABLETYPE_OBJECTIVE_VLD
        (--                     OPERATION               ,APPROVAL_MODE  ,FILTER_TYPE    ,ENT_APPROVALS  ,ENT_PROPS  ,OBJ_PROPS                                      ,ADDITIONAL
         OBJTYPE_OBJECTIVE_VLD('APPROVE_OBJECTIVES'     ,'ADMIN'        ,'LIST'         ,''             ,'1001'     ,'1002,1003,1004'                               ,'')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_OBJECTIVES'     ,'ADMIN'        ,'QUERY'        ,''             ,''         ,'1002,1003,1004'                               ,'')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_OBJECTIVES'     ,'PORTAL'       ,'LIST'         ,'1014'         ,'1001'     ,'1002,1003,1004'                               ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_OBJECTIVES'     ,'PORTAL'       ,'QUERY'        ,'1014'         ,''         ,'1002,1003,1004'                               ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_SCORES'         ,'ADMIN'        ,'LIST'         ,'1011'         ,'1001'     ,'1002,1003,1004,1005,1006,1007,1008,1009,1010' ,'')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_SCORES'         ,'ADMIN'        ,'QUERY'        ,'1011'         ,''         ,'1002,1003,1004,1005,1006,1007,1008,1009,1010' ,'')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_SCORES'         ,'PORTAL'       ,'LIST'         ,'1011,1015'    ,'1001'     ,'1002,1003,1004,1005,1006,1007,1008,1009,1010' ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('APPROVE_SCORES'         ,'PORTAL'       ,'QUERY'        ,'1011,1015'    ,''         ,'1002,1003,1004,1005,1006,1007,1008,1009,1010' ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_OBJECTIVES'   ,'ADMIN'        ,'LIST'         ,'1012'         ,'1001'     ,'1002,1003,1004,1005,1006,1007,1008,1009,1010' ,'')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_OBJECTIVES'   ,'ADMIN'        ,'QUERY'        ,'1012'         ,''         ,''                                             ,'')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_OBJECTIVES'   ,'PORTAL'       ,'LIST'         ,'1012,1016'    ,'1001'     ,''                                             ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_OBJECTIVES'   ,'PORTAL'       ,'QUERY'        ,'1012,1016'    ,''         ,''                                             ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_SCORES'       ,'ADMIN'        ,'LIST'         ,''             ,'1001'     ,''                                             ,'')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_SCORES'       ,'ADMIN'        ,'QUERY'        ,''             ,''         ,''                                             ,'')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_SCORES'       ,'PORTAL'       ,'LIST'         ,'1017'         ,'1001'     ,''                                             ,'1013')
        ,OBJTYPE_OBJECTIVE_VLD('UNAPPROVE_SCORES'       ,'PORTAL'       ,'QUERY'        ,'1017'         ,''         ,''                                             ,'1013'));

        SELECT OBJTYPE_OBJECTIVE_VLD(OPERATION,APPROVAL_MODE,FILTER_TYPE,ENT_APPROVALS,ENT_PROPS,OBJ_PROPS,ADDITIONAL)
        INTO v_def_validations
        FROM TABLE(v_validations)
        WHERE OPERATION =       CASE    WHEN pi_operation = 1 THEN 'APPROVE_OBJECTIVES'
                                        WHEN pi_operation = 2 THEN 'APPROVE_SCORES'
                                        WHEN pi_operation = 3 THEN 'UNAPPROVE_OBJECTIVES'
                                        WHEN pi_operation = 4 THEN 'UNAPPROVE_SCORES'
                                        ELSE NULL END
            AND APPROVAL_MODE = CASE    WHEN pi_approval_mode = 1 THEN 'ADMIN'
                                        WHEN pi_approval_mode = 2 THEN 'PORTAL'
                                        ELSE NULL END
            AND FILTER_TYPE =   CASE    WHEN pi_obj_entity_list IS NOT NULL THEN 'LIST'
                                        WHEN pi_obj_entity_qry IS NOT NULL THEN 'QUERY'
                                        ELSE NULL END;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_APPROVAL_NUM_LVLS IS NULL)     THEN RAISE_APPLICATION_ERROR(-20001, 'The maximum number of levels to approve is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
        IF (vrec_def.OBD_OBJECTIVES_TABLES_ID IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The Appraisals table of the appraisal definition is not defined.'); END IF;
        IF (vrec_def.OBD_OVR_SCORE_TYPE = 0
            AND (vrec_def.OBD_OVR_SCORE_WGHT_MIN_VALUE IS NULL
                OR vrec_def.OBD_OVR_SCORE_WGHT_MAX_VALUE IS NULL)) THEN RAISE_APPLICATION_ERROR(-20001, 'The overall score is of type weights but min and max values were not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get appraisal score scale
    BEGIN
        SELECT * INTO vrec_score_scale
        FROM OBJ_SCORE_SCALES
        WHERE OSS_ID = pi_definition_id;

        IF (vrec_score_scale.OSS_SCORE_TYPE = 2
            AND (vrec_score_scale.OSS_WORST_VALUE IS NULL
                OR vrec_score_scale.OSS_BEST_VALUE IS NULL)) THEN RAISE_APPLICATION_ERROR(-20001, 'The score is of type numeric but best and worst values were not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The score type has not been defined.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);
    v_obj_table_name := 'T'||TO_CHAR(vrec_def.OBD_OBJECTIVES_TABLES_ID);

    -- build validation clauses
    /*  tables involved in validations:
            1. initial query/list for determining entities to validate
            2. OBJ_ENTITIES - contains the approval information in XML columns that must be expanded - will end up with multiple records/levels for an entity
            3. OBJ_OBJECTIVES - contains the appraisals data - will end up with multiple records for an entity
        a validation will be applied to data in one of the above tables. the end query will end up though having only one record for each entity.

            a. if there are validations to be done on the approval info:
                INSERT INTO TEMP_OBJECTIVES_VALIDATIONS - if there are problems on the record   -- v_vld_when_sql
                            TEMP_OBJECTIVES_UPDATES - if record is ok and can be updated
                SELECT   ENTITY_ID [,HLEVEL if applicable]
                        ,all columns determined in VALIDATIONS_FOR_APPROVALS                    -- v_vld_inner_col_list
                        ,VALIDATIONS_FOR_OBJECTIVES                                             -- v_vld_outer_select_sql
                FROM    (SELECT  ENTITY_ID [,HLEVEL if applicable]
                                ,VALIDATIONS_FOR_APPROVALS                                      -- v_vld_inner_select_sql
                        FROM    (initial list) LST
                                LEFT JOIN OBJ_ENTITIES
                                XMLTABLE(SCORE_APPROVAL_TECH) S
                                XMLTABLE(OBJECTIVE_APPROVAL_TECH) O
                        GROUP BY ENTITY_ID [,HLEVEL if applicable]
                        ) LST
                        LEFT JOIN OBJ_OBJECTIVES
                GROUP BY ENTITY_ID [,HLEVEL if applicable] ,all columns determined in VALIDATIONS_FOR_APPROVALS

            b. if there are no validations to be done on the approval info:

                INSERT INTO TEMP_OBJECTIVES_VALIDATIONS - if there are problems on the record   -- v_vld_when_sql
                            TEMP_OBJECTIVES_UPDATES - if record is ok and can be updated
                SELECT   ENTITY_ID [,HLEVEL if applicable]
                        ,VALIDATIONS_FOR_OBJECTIVES                                             -- v_vld_outer_select_sql
                FROM    (initial list) LST
                        LEFT JOIN OBJ_ENTITIES - if validation 1001 is to be performed
                        LEFT JOIN OBJ_OBJECTIVES
                        LEFT JOIN TABLE(vtab_scores) - if validations 1007,1008 are to be performed
                GROUP BY ENTITY_ID [,HLEVEL if applicable]
    */
    BEGIN
        -- 1011 - Appraisals have not been approved at the highest applicable level.
        IF (','||v_def_validations.ENT_APPROVALS||',' LIKE '%,1011,%' AND vrec_def.OBD_APPROVAL_TYPE = 1)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN NVL(OBJ_MAX_APPR_LVL, 0) < NVL(OBJ_MAX_APPL_LVL, 0)'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1011)'||CHR(10);
            v_vld_inner_select_sql := v_vld_inner_select_sql||',MAX(CASE WHEN O_APPLICABLE = 1 AND O_USERID IS NOT NULL THEN O_LVLNO ELSE NULL END) OBJ_MAX_APPR_LVL'||CHR(10)
                                                            ||',MAX(CASE WHEN O_APPLICABLE = 1 THEN O_LVLNO ELSE NULL END) OBJ_MAX_APPL_LVL'||CHR(10);
            v_vld_inner_col_list := v_vld_inner_col_list||',OBJ_MAX_APPR_LVL,OBJ_MAX_APPL_LVL';
        END IF;

        -- 1012 - Scores have already been approved at one or more levels.
        IF (','||v_def_validations.ENT_APPROVALS||',' LIKE '%,1012,%')
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN SCR_APPR_ANY_LVL = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1012)'||CHR(10);
            v_vld_inner_select_sql := v_vld_inner_select_sql||',MAX(CASE WHEN S_APPLICABLE = 1 AND S_USERID IS NOT NULL THEN 1 ELSE 0 END) SCR_APPR_ANY_LVL'||CHR(10);
            v_vld_inner_col_list := v_vld_inner_col_list||',SCR_APPR_ANY_LVL';
        END IF;

        -- 1014 - Appraisals have not been approved at all lower levels.
        IF (','||v_def_validations.ENT_APPROVALS||',' LIKE '%,1014,%' AND vrec_def.OBD_APPROVAL_REQ_LOWER_LVL = 1 AND vrec_def.OBD_APPROVAL_TYPE = 1)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN OBJ_NOT_APPR_ALL_LOW_LVLS = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1014)'||CHR(10);
            v_vld_inner_select_sql := v_vld_inner_select_sql||',MAX(CASE WHEN O_APPLICABLE = 1 AND O_LVLNO < HLEVEL AND O_USERID IS NULL THEN 1 ELSE 0 END) OBJ_NOT_APPR_ALL_LOW_LVLS'||CHR(10);
            v_vld_inner_col_list := v_vld_inner_col_list||',OBJ_NOT_APPR_ALL_LOW_LVLS';
        END IF;

        -- 1015 - Scores have not been approved at all lower levels.
        IF (','||v_def_validations.ENT_APPROVALS||',' LIKE '%,1015,%' AND vrec_def.OBD_APPROVAL_REQ_LOWER_LVL = 1)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN SCR_NOT_APPR_ALL_LOW_LVLS = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1015)'||CHR(10);
            v_vld_inner_select_sql := v_vld_inner_select_sql||',MAX(CASE WHEN S_APPLICABLE = 1 AND S_LVLNO < HLEVEL AND S_USERID IS NULL THEN 1 ELSE 0 END) SCR_NOT_APPR_ALL_LOW_LVLS'||CHR(10);
            v_vld_inner_col_list := v_vld_inner_col_list||',SCR_NOT_APPR_ALL_LOW_LVLS';
        END IF;

        -- 1016 - Appraisals have already been approved at an upper level.
        IF (','||v_def_validations.ENT_APPROVALS||',' LIKE '%,1016,%' AND vrec_def.OBD_APPROVAL_TYPE = 1)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN OBJ_APPR_UP_LVL = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1016)'||CHR(10);
            v_vld_inner_select_sql := v_vld_inner_select_sql||',MAX(CASE WHEN O_APPLICABLE = 1 AND O_LVLNO > HLEVEL AND O_USERID IS NOT NULL THEN 1 ELSE 0 END) OBJ_APPR_UP_LVL'||CHR(10);
            v_vld_inner_col_list := v_vld_inner_col_list||',OBJ_APPR_UP_LVL';
        END IF;

        -- 1017 - Scores have already been approved at an upper level.
        IF (','||v_def_validations.ENT_APPROVALS||',' LIKE '%,1017,%')
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN SCR_APPR_UP_LVL = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1017)'||CHR(10);
            v_vld_inner_select_sql := v_vld_inner_select_sql||',MAX(CASE WHEN S_APPLICABLE = 1 AND S_LVLNO > HLEVEL AND S_USERID IS NOT NULL THEN 1 ELSE 0 END) SCR_APPR_UP_LVL'||CHR(10);
            v_vld_inner_col_list := v_vld_inner_col_list||',SCR_APPR_UP_LVL';
        END IF;

        -- 1001 - The record no longer exists.
        IF (','||v_def_validations.ENT_PROPS||',' LIKE '%,1001,%')
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN ENT_NO_LONGER_EXISTS = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1001)'||CHR(10);
            v_temp := ',MAX(CASE WHEN OE.'||v_entity_col||' IS NULL THEN 1 ELSE 0 END) ENT_NO_LONGER_EXISTS'||CHR(10);
            IF (v_vld_inner_col_list IS NOT NULL)
            THEN
                v_vld_inner_select_sql := v_vld_inner_select_sql||v_temp;
                v_vld_inner_col_list := v_vld_inner_col_list||',ENT_NO_LONGER_EXISTS';
            ELSE
                v_vld_outer_select_sql := v_vld_outer_select_sql||v_temp;
            END IF;
        END IF;

        -- 1002 - Appraisals have not been entered.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1002,%')
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER>';
            v_vld_when_sql := v_vld_when_sql||'WHEN ENT_HAS_NO_OBJECTIVES = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1002)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN OO.'||v_entity_col||' IS NULL THEN 1 ELSE 0 END) ENT_HAS_NO_OBJECTIVES'||CHR(10);
        END IF;

        -- 1003 - Weights for one or more appraisals are not between <minimum weight> and <maximum weight>.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1003,%' AND vrec_def.OBD_OVR_SCORE_TYPE = 0)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_WEIGHTS = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1003)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN OO.WEIGHT*100 BETWEEN '||TO_CHAR(vrec_def.OBD_OVR_SCORE_WGHT_MIN_VALUE)
                                                                            ||' AND '||TO_CHAR(vrec_def.OBD_OVR_SCORE_WGHT_MAX_VALUE)||' THEN 0 ELSE 1 END) HAS_INVALID_WEIGHTS'||CHR(10);
        END IF;

        -- 1004 - Weights for the set of appraisals do not sum to 100.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1004,%' AND vrec_def.OBD_OVR_SCORE_TYPE = 0)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN SUM_WEIGHTS_NOT_100 = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1004)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',CASE WHEN SUM(OO.WEIGHT*100) = 100 THEN 0 ELSE 1 END SUM_WEIGHTS_NOT_100'||CHR(10);
        END IF;

        -- 1005 - Scores have not been entered for one or more appraisals.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1005,%')
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_EMPTY_SCORES = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1005)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN OO.SCORE IS NULL THEN 1 ELSE 0 END) HAS_EMPTY_SCORES'||CHR(10);
        END IF;

        -- 1006 - Scores for one or more appraisals are not between the <minimum score> and <maximum score>.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1006,%' AND vrec_score_scale.OSS_SCORE_TYPE = 2)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_NUM_SCORES = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1006)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN OO.SCORE BETWEEN '||TO_CHAR(vrec_score_scale.OSS_WORST_VALUE)
                                                                                        ||' AND '||TO_CHAR(vrec_score_scale.OSS_BEST_VALUE)||' THEN 0 ELSE 1 END) HAS_INVALID_NUM_SCORES'||CHR(10);
        END IF;

        -- 1007 - Scores for one or more appraisals are not valid.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1007,%' AND vrec_score_scale.OSS_SCORE_TYPE = 3)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_CUSTNUM_SCORES = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1007)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN SC.OSCV_VALUE IS NULL THEN 1 ELSE 0 END) HAS_INVALID_CUSTNUM_SCORES'||CHR(10);
            v_score_join_sql := 'LEFT JOIN OBJ_SCORE_CUSTNUM_VALUES SC ON SC.OSCV_OSS_ID = v_definition_id AND OO.SCORE = SC.OSCV_VALUE'||CHR(10);
        END IF;

        -- 1008 - Ratings for one or more appraisals are not valid.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1008,%' AND vrec_score_scale.OSS_SCORE_TYPE = 4)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_RATING_SCORES = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1008)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN SC.OSRV_SCORE_VALUE IS NULL THEN 1 ELSE 0 END) HAS_INVALID_RATING_SCORES'||CHR(10);
            v_score_join_sql := 'LEFT JOIN OBJ_SCORE_RATING_VALUES SC ON SC.OSRV_OSS_ID = v_definition_id AND OO.SCORE = SC.OSRV_SCORE_VALUE AND UPPER(OO.RATING) = UPPER(SC.OSRV_RATING)'||CHR(10);
        END IF;

        -- 1009 - Participant comments have not been entered for one or more appraisals.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1009,%' AND vrec_def.OBD_SCORE_PART_REQ_COMM = 1)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_EMPTY_PART_COMM = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1009)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN OO.PARTICIPANT_COMMENT IS NULL THEN 1 ELSE 0 END) HAS_EMPTY_PART_COMM'||CHR(10);
        END IF;

        -- 1010 - Manager comments have not been entered for one or more appraisals.
        IF (','||v_def_validations.OBJ_PROPS||',' LIKE '%,1010,%' AND vrec_def.OBD_SCORE_MNG_REQ_COMM = 1)
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS><USER_NO_LONGER_MANAGER><ENT_HAS_NO_OBJECTIVES>';
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_EMPTY_MNG_COMM = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1010)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN OO.MANAGER_COMMENT IS NULL THEN 1 ELSE 0 END) HAS_EMPTY_MNG_COMM'||CHR(10);
        END IF;

        -- 1013 - You are no longer a manager within the levels of approval for this record.
        IF (','||v_def_validations.ADDITIONAL||',' LIKE '%,1013,%')
        THEN
            v_temp := '<ENT_NO_LONGER_EXISTS>';
            v_vld_when_sql := v_vld_when_sql||'WHEN USER_NO_LONGER_MANAGER = 1'||v_temp||' THEN INTO TEMP_OBJECTIVES_VALIDATIONS (ENTITY_ID, VALIDATION_ID) VALUES ('||v_entity_col||', 1013)'||CHR(10);
            v_vld_outer_select_sql := v_vld_outer_select_sql||',MAX(CASE WHEN HLEVEL IS NULL THEN 1 ELSE 0 END) USER_NO_LONGER_MANAGER'||CHR(10);
        END IF;

        --  replace the <ENT_EXISTS><USER_STILL_MANAGER><ENT_HAS_OBJECTIVES> with the appropriate conditions
        v_vld_when_sql := REPLACE(v_vld_when_sql, '<ENT_NO_LONGER_EXISTS>', CASE WHEN pi_obj_entity_list IS NOT NULL THEN ' AND ENT_NO_LONGER_EXISTS = 0' ELSE NULL END);
        v_vld_when_sql := REPLACE(v_vld_when_sql, '<ENT_HAS_NO_OBJECTIVES>', ' AND ENT_HAS_NO_OBJECTIVES = 0');
        v_vld_when_sql := REPLACE(v_vld_when_sql, '<USER_NO_LONGER_MANAGER>', CASE WHEN pi_approval_mode = 2 THEN ' AND USER_NO_LONGER_MANAGER = 0' ELSE NULL END);
    END;

    -- expand the XML for all entities in the period and save them in a temporary table
    BEGIN
        v_sql := 'DECLARE'||CHR(10)
            ||'v_period_id          NUMBER;'||CHR(10)
            ||'v_obj_entity_list    TABLETYPE_NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_period_id          := :1;'||CHR(10)
            ||'v_obj_entity_list    := :2;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO TEMP_OBJECTIVES_APPROVALS(ENTITY_ID, PERIOD_ID, S_LVLNO, S_APPLICABLE, S_USERID, S_ENTITYBK, O_LVLNO, O_APPLICABLE, O_USERID, O_ENTITYBK)'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' OE.'||v_entity_col||' ENTITY_ID'||CHR(10)
                ||',OE.'||v_period_col||' PERIOD_ID'||CHR(10)
                ||',S.LVLNO S_LVLNO,S.APPLICABLE S_APPLICABLE,S.USERID S_USERID,S.ENTITYBK S_ENTITYBK'||CHR(10)
                ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                        THEN ',O.LVLNO O_LVLNO,O.APPLICABLE O_APPLICABLE,O.USERID O_USERID,O.ENTITYBK O_ENTITYBK'
                        ELSE ',NULL O_LVLNO,NULL O_APPLICABLE,NULL O_USERID,NULL O_ENTITYBK'
                        END||CHR(10)
            ||'FROM '||v_ent_table_name||' OE'||CHR(10)
            ||'INNER JOIN XMLTABLE(''/s/l'' PASSING OE.SCORE_APPROVAL_TECH COLUMNS'
                ||' LVLNO NUMBER PATH ''ln'''
                ||',APPLICABLE NUMBER PATH ''app'''
                ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') S ON 1 = 1'||CHR(10)
            ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN 'INNER JOIN XMLTABLE(''/o/l'' PASSING OE.APPRAISAL_APPROVAL_TECH COLUMNS'
                            ||' LVLNO NUMBER PATH ''ln'''
                            ||',APPLICABLE NUMBER PATH ''app'''
                            ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                            ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') O ON O.LVLNO = S.LVLNO OR S.LVLNO IS NULL'||CHR(10)
                    ELSE NULL END
            ||'WHERE OE.'||v_period_col||' = v_period_id'||CHR(10)
                ||CASE  WHEN pi_obj_entity_list IS NOT NULL
                        THEN 'AND OE.'||v_entity_col||' IN (SELECT COLUMN_VALUE FROM TABLE(v_obj_entity_list))'||CHR(10)
                        ELSE NULL END
            ||';'||CHR(10)
        ||'END;';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>;',pi_stamp);
        EXECUTE IMMEDIATE v_sql USING pi_period_id, pi_obj_entity_list;
    END;

    -- this is the main list of entities
    v_init_list_sql := CASE WHEN pi_obj_entity_list IS NOT NULL AND pi_approval_mode = 1
                            THEN '(SELECT COLUMN_VALUE '||v_entity_col
                                    ||' FROM TABLE(v_obj_entity_list))'
                            WHEN pi_obj_entity_list IS NOT NULL AND pi_approval_mode = 2
                            THEN '(SELECT COLUMN_VALUE '||v_entity_col||', HRC.HLEVEL HLEVEL'||CHR(10)
                                    ||'FROM TABLE(v_obj_entity_list)'||CHR(10)
                                    ||'LEFT JOIN (SELECT LOWER_VALUE, MAX(HLEVEL) AS HLEVEL FROM '||pi_hierarchy_qry||' GROUP BY LOWER_VALUE) HRC ON COLUMN_VALUE = HRC.LOWER_VALUE)'
                            WHEN pi_obj_entity_qry IS NOT NULL
                            THEN pi_obj_entity_qry
                            ELSE NULL END;

    -- if validations must be executed
    IF (v_vld_when_sql IS NOT NULL)
    THEN
        v_temp := 'LST.'||v_entity_col||CASE WHEN pi_approval_mode = 2 THEN ', LST.HLEVEL' ELSE NULL END;

        IF (v_vld_inner_col_list IS NOT NULL)
        THEN
            v_vld_from_sql := '('||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_VLD_INNER' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||'SELECT '      ||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_VLD_INNER' ,pi_proc_id => pi_definition_id)||CHR(10)
                    ||v_temp||CHR(10)
                    ||v_vld_inner_select_sql
                ||'FROM'||CHR(10)
                ||v_init_list_sql||' LST'||CHR(10)
                ||'LEFT JOIN '||CHR(10)
                            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_TEMP_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
                            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_TEMP_XML' ,pi_proc_id => pi_definition_id)
                            ||' ENTITY_ID '||v_entity_col||', PERIOD_ID '||v_period_col||', S_LVLNO, S_APPLICABLE, S_USERID, S_ENTITYBK, O_LVLNO, O_APPLICABLE, O_USERID, O_ENTITYBK FROM TEMP_OBJECTIVES_APPROVALS'||CHR(10)
                            ||') OE ON LST.'||v_entity_col||' = OE.'||v_entity_col||CHR(10)
                ||'GROUP BY '||v_temp||CHR(10)
                ||') LST'||CHR(10);
        ELSE
            v_vld_from_sql := v_init_list_sql||' LST'||CHR(10);

            IF (v_def_validations.ENT_PROPS IS NOT NULL)
            THEN
                v_vld_from_sql := v_vld_from_sql||'LEFT JOIN '||v_ent_table_name||' OE ON LST.'||v_entity_col||' = OE.'||v_entity_col||' AND OE.'||v_period_col||' = v_period_id'||CHR(10);
            END IF;
        END IF;

        IF (v_vld_outer_select_sql IS NOT NULL)
        THEN
            v_vld_from_sql := v_vld_from_sql||'LEFT JOIN '||v_obj_table_name||' OO ON LST.'||v_entity_col||' = OO.'||v_entity_col||' AND OO.'||v_period_col||' = v_period_id'||CHR(10);
        END IF;

        v_sql := 'DECLARE'||CHR(10)
            ||'v_period_id          NUMBER;'||CHR(10)
            ||'v_obj_entity_list    TABLETYPE_NUMBER;'||CHR(10)
            ||'v_definition_id      NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_period_id          := :1;'||CHR(10)
            ||'v_obj_entity_list    := :2;'||CHR(10)
            ||'v_definition_id      := :3;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'INS_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'INS_VLD' ,pi_proc_id => pi_definition_id)
            ||' ALL'||CHR(10)
            ||v_vld_when_sql
            ||'ELSE INTO TEMP_OBJECTIVES_UPDATES (ENTITY_ID, HLEVEL) VALUES ('||v_entity_col||', '||CASE WHEN pi_approval_mode = 2 THEN 'HLEVEL' ELSE 'NULL' END||')'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_VLD_OUTER' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_VLD_OUTER' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||v_temp
                ||CASE WHEN v_vld_inner_col_list IS NOT NULL THEN v_vld_inner_col_list ELSE NULL END||CHR(10)
                ||CASE WHEN v_vld_outer_select_sql IS NOT NULL THEN v_vld_outer_select_sql ELSE NULL END
            ||'FROM'||CHR(10)
            ||v_vld_from_sql
            ||CASE WHEN v_score_join_sql IS NOT NULL THEN v_score_join_sql ELSE NULL END
            ||'GROUP BY '||v_temp
                         ||CASE WHEN v_vld_inner_col_list IS NOT NULL THEN v_vld_inner_col_list ELSE NULL END||';'||CHR(10)
        ||'END;';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>;',pi_stamp);
        EXECUTE IMMEDIATE v_sql USING pi_period_id, pi_obj_entity_list, pi_definition_id;

        v_upd_exists_sql := 'AND EXISTS ('         ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_UPD_EXISTS_TEMP' ,pi_proc_id => pi_definition_id)
                                       ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_UPD_EXISTS_TEMP' ,pi_proc_id => pi_definition_id)
                                       ||' 1 FROM TEMP_OBJECTIVES_UPDATES LST WHERE LST.ENTITY_ID = OE.'||v_entity_col||')'||CHR(10);
    ELSE
        v_upd_exists_sql := 'AND EXISTS ('         ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_UPD_EXISTS_FLT_QRY' ,pi_proc_id => pi_definition_id)
                                       ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_UPD_EXISTS_FLT_QRY' ,pi_proc_id => pi_definition_id)
                                       ||' 1 FROM '||v_init_list_sql||' LST WHERE LST.'||v_entity_col||' = OE.'||v_entity_col||')'||CHR(10);
    END IF;

    -- depending on approval to be performed build the values to be used for update
    IF (pi_approval_mode = 1)
    THEN
        -- approve scores/appraisals on all levels
        IF (pi_operation IN (1, 2))
        THEN
            v_hlp_approval_descr := 'LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(X.<SRC>_LVLNO)||'': ''||' ELSE NULL END
                ||'CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL THEN X.<SRC>_USERID||CASE WHEN X.<SRC>_ENTITYBK IS NOT NULL THEN '' (''||X.<SRC>_ENTITYBK||'')'' ELSE NULL END
                        WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL THEN v_user_name||CASE WHEN v_user_entity_bk IS NOT NULL THEN '' (''||v_user_entity_bk||'')'' ELSE NULL END
                        ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
            v_hlp_approval_tech := 'LISTAGG(''<l>''
                    ||''<ln>''||TO_CHAR(X.<SRC>_LVLNO)||''</ln>''
                    ||''<app>''||TO_CHAR(X.<SRC>_APPLICABLE)||''</app>''
                    ||''<u>''||CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL THEN X.<SRC>_USERID
                                    WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL THEN v_user_name
                                    ELSE NULL END||''</u>''
                    ||''<e>''||CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL THEN X.<SRC>_ENTITYBK
                                    WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL THEN v_user_entity_bk
                                    ELSE NULL END||''</e>''
                ||''</l>'', '''') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
        -- unapprove scores/appraisals on all levels
        ELSIF (pi_operation IN (3, 4))
        THEN
            v_hlp_approval_descr := 'LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(X.<SRC>_LVLNO)||'': ''||' ELSE NULL END
                ||'CASE WHEN X.<SRC>_APPLICABLE = 1 THEN ''None''
                        ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
            v_hlp_approval_tech := 'LISTAGG(''<l>''
                    ||''<ln>''||TO_CHAR(X.<SRC>_LVLNO)||''</ln>''
                    ||''<app>''||TO_CHAR(X.<SRC>_APPLICABLE)||''</app>''
                    ||''<u></u>''
                    ||''<e></e>''
                ||''</l>'', '''') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
        END IF;
    ELSIF (pi_approval_mode = 2)
    THEN
        -- approve scores/appraisals on user level only
        IF (pi_operation IN (1, 2))
        THEN
            v_hlp_approval_descr := 'LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(X.<SRC>_LVLNO)||'': ''||' ELSE NULL END
                ||'CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL THEN X.<SRC>_USERID||CASE WHEN X.<SRC>_ENTITYBK IS NOT NULL THEN '' (''||X.<SRC>_ENTITYBK||'')'' ELSE NULL END
                        WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL AND U.HLEVEL IS NOT NULL THEN v_user_name||CASE WHEN v_user_entity_bk IS NOT NULL THEN '' (''||v_user_entity_bk||'')'' ELSE NULL END
                        WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL AND U.HLEVEL IS NULL THEN ''None''
                        ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
            v_hlp_approval_tech := 'LISTAGG(''<l>''
                    ||''<ln>''||TO_CHAR(X.<SRC>_LVLNO)||''</ln>''
                    ||''<app>''||TO_CHAR(X.<SRC>_APPLICABLE)||''</app>''
                    ||''<u>''||CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL THEN X.<SRC>_USERID
                                    WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL AND U.HLEVEL IS NOT NULL THEN v_user_name
                                    ELSE NULL END||''</u>''
                    ||''<e>''||CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL THEN X.<SRC>_ENTITYBK
                                    WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL AND U.HLEVEL IS NOT NULL THEN v_user_entity_bk
                                    ELSE NULL END||''</e>''
                ||''</l>'', '''') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
        -- unapprove scores/appraisals on user level only
        ELSIF (pi_operation IN (3, 4))
        THEN
            v_hlp_approval_descr := 'LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(X.<SRC>_LVLNO)||'': ''||' ELSE NULL END
                ||'CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL AND U.HLEVEL IS NULL THEN X.<SRC>_USERID||CASE WHEN X.<SRC>_ENTITYBK IS NOT NULL THEN '' (''||X.<SRC>_ENTITYBK||'')'' ELSE NULL END
                        WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL AND U.HLEVEL IS NOT NULL THEN ''None''
                        WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NULL THEN ''None''
                        ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
            v_hlp_approval_tech := 'LISTAGG(''<l>''
                    ||''<ln>''||TO_CHAR(X.<SRC>_LVLNO)||''</ln>''
                    ||''<app>''||TO_CHAR(X.<SRC>_APPLICABLE)||''</app>''
                    ||''<u>''||CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL AND U.HLEVEL IS NULL THEN X.<SRC>_USERID ELSE NULL END||''</u>''
                    ||''<e>''||CASE WHEN X.<SRC>_APPLICABLE = 1 AND X.<SRC>_USERID IS NOT NULL AND U.HLEVEL IS NULL THEN X.<SRC>_ENTITYBK ELSE NULL END||''</e>''
                ||''</l>'', '''') WITHIN GROUP (ORDER BY X.<SRC>_LVLNO)';
        END IF;
    END IF;

    -- specify whether APPRAISALS or SCORES are modified
    IF (pi_operation IN (1, 3))
    THEN
        v_operation_type := 'APPRAISAL';
        v_operation_prefix := 'O';
        v_hlp_approval_descr := REPLACE(v_hlp_approval_descr, '<SRC>', 'O');
        v_hlp_approval_tech := REPLACE(v_hlp_approval_tech, '<SRC>', 'O');
    ELSIF (pi_operation IN (2, 4))
    THEN
        v_operation_type := 'SCORE';
        v_operation_prefix := 'S';
        v_hlp_approval_descr := REPLACE(v_hlp_approval_descr, '<SRC>', 'S');
        v_hlp_approval_tech := REPLACE(v_hlp_approval_tech, '<SRC>', 'S');
    END IF;

    -- execute update
    BEGIN
        v_sql := 'DECLARE'||CHR(10)
            ||'v_period_id          NUMBER;'||CHR(10)
            ||'v_user_name          VARCHAR2(250 CHAR);'||CHR(10)
            ||'v_user_entity_bk     VARCHAR2(250 CHAR);'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_period_id          := :1;'||CHR(10)
            ||'v_user_name          := :2;'||CHR(10)
            ||'v_user_entity_bk     := :3;'||CHR(10)
                  ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'MRG_MAIN_UPD' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'MERGE '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'MRG_MAIN_UPD' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'INTO '||v_ent_table_name||' D'||CHR(10)
            ||'USING'||CHR(10)
            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_MRG_SRC' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_MRG_SRC' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' OE.'||v_entity_col||CHR(10)
                ||','||v_hlp_approval_descr||' APPROVAL_NEW'||CHR(10)
                ||',XMLTYPE(''<'||LOWER(v_operation_prefix)||'>''||'||v_hlp_approval_tech||'||''</'||LOWER(v_operation_prefix)||'>'') APPROVAL_TECH_NEW'||CHR(10)
            ||'FROM '||v_ent_table_name||' OE'||CHR(10)
            ||'INNER JOIN '||CHR(10)
                        ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_TEMP_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
                        ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.MODIFY_OBJECTIVES_SCORES' ,pi_hint_id=> 'SEL_TEMP_XML' ,pi_proc_id => pi_definition_id)
                        ||' ENTITY_ID '||v_entity_col||', PERIOD_ID '||v_period_col||', S_LVLNO, S_APPLICABLE, S_USERID, S_ENTITYBK, O_LVLNO, O_APPLICABLE, O_USERID, O_ENTITYBK FROM TEMP_OBJECTIVES_APPROVALS'||CHR(10)
                        ||') X ON OE.'||v_entity_col||' = X.'||v_entity_col||CHR(10)
            ||CASE WHEN pi_approval_mode = 2 THEN 'LEFT JOIN TEMP_OBJECTIVES_UPDATES U ON OE.'||v_entity_col||' = U.ENTITY_ID AND X.'||v_operation_prefix||'_LVLNO = U.HLEVEL'||CHR(10) ELSE NULL END
            ||'WHERE OE.'||v_period_col||' = v_period_id'||CHR(10)
            ||v_upd_exists_sql
            ||'GROUP BY OE.'||v_entity_col||CHR(10)
            ||') S'||CHR(10)
            ||'ON (D.'||v_entity_col||' = S.'||v_entity_col||' AND D.'||v_period_col||' = v_period_id)'||CHR(10)
            ||'WHEN MATCHED THEN UPDATE SET D.'||v_operation_type||'_APPROVAL = S.APPROVAL_NEW, D.'||v_operation_type||'_APPROVAL_TECH = S.APPROVAL_TECH_NEW;'||CHR(10)
        ||'END;';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>;',pi_stamp);
        EXECUTE IMMEDIATE v_sql USING pi_period_id, pi_user_name, pi_user_entity_bk;
    END;

    OPEN vcur_result FOR
    WITH T AS
    (   SELECT ENTITY_ID
        FROM (SELECT DISTINCT ENTITY_ID FROM TEMP_OBJECTIVES_VALIDATIONS)
        WHERE ROWNUM <= 1000
    )
    SELECT ENTITY_ID, VALIDATION_ID
    FROM TEMP_OBJECTIVES_VALIDATIONS V
    WHERE EXISTS (SELECT 1 FROM T WHERE V.ENTITY_ID = T.ENTITY_ID);

    RETURN vcur_result;
END MODIFY_OBJECTIVES_SCORES;


/* MAKE_IMPORT_TABLE_BACKUP
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.02.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE MAKE_IMPORT_TABLE_BACKUP
(   pi_temp_table_name VARCHAR2
) IS
    v_sql CLOB;
BEGIN
    v_sql := SUBSTR(pi_temp_table_name, 1, 27)||'_BK';
    v_sql := '
    BEGIN
    FOR C IN (SELECT 1 FROM USER_TABLES WHERE TABLE_NAME = '''||v_sql||''')
    LOOP EXECUTE IMMEDIATE ''DROP TABLE '||v_sql||''';
    END LOOP;
    EXECUTE IMMEDIATE ''CREATE TABLE '||v_sql||' AS SELECT * FROM '||pi_temp_table_name||''';
    END;';
    COMMONS_DDL_HANDLING.EXECUTE_DDL_NOLOG(v_sql);
EXCEPTION
    WHEN OTHERS THEN NULL;
END MAKE_IMPORT_TABLE_BACKUP;

-- *******************************    PRIVATE METHODS END    *******************************
-- *******************************    PUBLIC METHODS START    *******************************

/* VERIFY_ENTITY_APPROVALS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2013.12.09 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION VERIFY_ENTITY_APPROVALS
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_id               IN NUMBER
    ,pi_view_mode               IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_ent_table_name            VARCHAR2(200 CHAR);
    v_sql                       CLOB;
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.VERIFY_ENTITY_APPROVALS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),    ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),        ',pi_period_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_entity_id),        ',pi_entity_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_view_mode),        ',pi_view_mode => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),      ',pi_hierarchy_qry => <value>', v_stamp);

        IF (pi_definition_id IS NULL)       THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_period_id IS NULL)           THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which approvals must be verified must not be null.'); END IF;
        IF (pi_entity_id IS NULL)           THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which approvals must be verified must not be null.'); END IF;
        IF (pi_view_mode NOT IN (1, 2))     THEN RAISE_APPLICATION_ERROR(-20001, 'The approvals to view must be 1 - manager or 2 - user.'); END IF;
        IF (pi_view_mode = 1
            AND pi_hierarchy_qry IS NULL)   THEN RAISE_APPLICATION_ERROR(-20001, 'The hierarchy provided must not be null for manager approval viewing.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);

    v_sql := 'DECLARE'||CHR(10)
        ||'v_period_id NUMBER;'||CHR(10)
        ||'v_entity_id NUMBER;'||CHR(10)
    ||'BEGIN'||CHR(10)
        ||'v_period_id := :1;'||CHR(10)
        ||'v_entity_id := :2;'||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.VERIFY_ENTITY_APPROVALS' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.VERIFY_ENTITY_APPROVALS' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'INTO TEMP_OBJECTIVES_APPROVALS(ENTITY_ID, PERIOD_ID, S_LVLNO, S_APPLICABLE, S_USERID, S_ENTITYBK, O_LVLNO, O_APPLICABLE, O_USERID, O_ENTITYBK)'||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.VERIFY_ENTITY_APPROVALS' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.VERIFY_ENTITY_APPROVALS' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||' OE.'||v_entity_col||' ENTITY_ID'||CHR(10)
            ||',OE.'||v_period_col||' PERIOD_ID'||CHR(10)
            ||',S.LVLNO S_LVLNO,S.APPLICABLE S_APPLICABLE,S.USERID S_USERID,S.ENTITYBK S_ENTITYBK'||CHR(10)
            ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN ',O.LVLNO O_LVLNO,O.APPLICABLE O_APPLICABLE,O.USERID O_USERID,O.ENTITYBK O_ENTITYBK'
                    ELSE ',NULL O_LVLNO,NULL O_APPLICABLE,NULL O_USERID,NULL O_ENTITYBK'
                    END||CHR(10)
        ||'FROM '||v_ent_table_name||' OE'||CHR(10)
        ||'INNER JOIN XMLTABLE(''/s/l'' PASSING OE.SCORE_APPROVAL_TECH COLUMNS'
            ||' LVLNO NUMBER PATH ''ln'''
            ||',APPLICABLE NUMBER PATH ''app'''
            ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
            ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') S ON 1 = 1'||CHR(10)
        ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                THEN 'INNER JOIN XMLTABLE(''/o/l'' PASSING OE.APPRAISAL_APPROVAL_TECH COLUMNS'
                        ||' LVLNO NUMBER PATH ''ln'''
                        ||',APPLICABLE NUMBER PATH ''app'''
                        ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                        ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') O ON O.LVLNO = S.LVLNO OR S.LVLNO IS NULL'||CHR(10)
                ELSE NULL END
        ||'WHERE OE.'||v_period_col||' = v_period_id AND OE.'||v_entity_col||' = v_entity_id;'||CHR(10)

        ||'OPEN :3 FOR '||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.VERIFY_ENTITY_APPROVALS' ,pi_hint_id=> 'SEL_MAIN_CUR' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.VERIFY_ENTITY_APPROVALS' ,pi_hint_id=> 'SEL_MAIN_CUR' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||' CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END ENTITY_STILL_EXISTS'||CHR(10)
        ||','||CASE WHEN pi_view_mode = 2 AND vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN 'NVL(MAX(CASE WHEN O_APPLICABLE = 1 AND O_USERID IS NOT NULL THEN 1 ELSE 0 END), 0)'
                    ELSE 'NULL' END||' OBJ_APPROVED_AT_ANY_LVL'||CHR(10)
        ||','||CASE WHEN pi_view_mode = 2
                    THEN 'NVL(MAX(CASE WHEN S_APPLICABLE = 1 AND S_USERID IS NOT NULL THEN 1 ELSE 0 END), 0)'
                    ELSE 'NULL' END||' SCR_APPROVED_AT_ANY_LVL'||CHR(10)
        ||','||CASE WHEN pi_view_mode = 1
                    THEN 'NVL(MAX(CASE WHEN HRC.LOWER_VALUE IS NOT NULL THEN 1 ELSE 0 END), 0)'
                    ELSE 'NULL' END||' USER_IS_STILL_MANAGER'||CHR(10)
        ||','||CASE WHEN pi_view_mode = 1
                    THEN 'NVL(MAX(CASE WHEN S_LVLNO = HRC.HLEVEL AND S_APPLICABLE = 1 THEN 1 ELSE 0 END), 0)'
                    ELSE 'NULL' END||' MANAGER_LVL_IS_APPLICABLE'||CHR(10)
        ||','||CASE WHEN pi_view_mode = 1 AND vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN 'NVL(MAX(CASE WHEN O_APPLICABLE = 1 AND O_LVLNO >= HRC.HLEVEL AND O_USERID IS NOT NULL THEN 1 ELSE 0 END), 0)'
                    ELSE 'NULL' END||' OBJ_APPROVED_AT_USER_LVL'||CHR(10)
        ||','||CASE WHEN pi_view_mode = 1
                    THEN 'NVL(MAX(CASE WHEN S_APPLICABLE = 1 AND S_LVLNO >= HRC.HLEVEL AND S_USERID IS NOT NULL THEN 1 ELSE 0 END), 0)'
                    ELSE 'NULL' END||' SCR_APPROVED_AT_USER_LVL'||CHR(10)
        ||'FROM TEMP_OBJECTIVES_APPROVALS OE_XML'||CHR(10)
        ||CASE WHEN pi_view_mode = 1 THEN 'LEFT JOIN (SELECT LOWER_VALUE,MAX(HLEVEL) HLEVEL FROM '||pi_hierarchy_qry||' GROUP BY LOWER_VALUE) HRC ON OE_XML.ENTITY_ID = HRC.LOWER_VALUE'||CHR(10) ELSE NULL END
        ||';'||CHR(10)
    ||'END;';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>;',v_stamp);
    EXECUTE IMMEDIATE v_sql USING pi_period_id, pi_entity_id, vcur_result;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END VERIFY_ENTITY_APPROVALS;


/* ADD_ENTITIES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2013.11.19 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE ADD_ENTITIES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_ins_columns               CLOB;
    v_sel_values                CLOB;
    v_sql                       CLOB;
BEGIN
    v_stamp := 'OBJECTIVES.ADD_ENTITIES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),    ',pi_period_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),  ',pi_hierarchy_qry => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pi_entity_table), ',pi_entity_table => <value>', v_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_period_id IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which entities need to be added must not be null.'); END IF;
        IF (pi_hierarchy_qry IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The hierarchy query provided must not be null.'); END IF;
        IF (pi_entity_table.FROM_CLAUSE IS NULL
            AND pi_entity_table.TABLE_NAME IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The entity table provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_APPROVAL_NUM_LVLS IS NULL)     THEN RAISE_APPLICATION_ERROR(-20001, 'The maximum number of levels to approve is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);

    -- build query parts for columns and values to insert
    FOR c IN (SELECT     TC_PHYSICAL_NAME
                        ,TC_COLUMN_TYPE
                        ,TC_LOGIC_TYPE
                        ,TC_FLD_ID
                        ,TC_ENTITY_ID
                FROM    TABLE_COLUMNS
                WHERE   TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID
                ORDER BY TC_ORDER)
    LOOP
        v_ins_columns := v_ins_columns||c.TC_PHYSICAL_NAME||',';
        v_sel_values := v_sel_values
            ||CASE  WHEN c.TC_LOGIC_TYPE IN (1, 5) AND c.TC_COLUMN_TYPE = 1 AND c.TC_ENTITY_ID = vrec_def.OBD_ENTITY_ID THEN 'E_INTERNAL_ID'
                    WHEN c.TC_LOGIC_TYPE = 8 THEN 'v_period_id'
                    WHEN c.TC_PHYSICAL_NAME = 'APPRAISAL_APPROVAL' THEN 'CHAR_COL'
                    WHEN c.TC_PHYSICAL_NAME = 'SCORE_APPROVAL' THEN 'CHAR_COL'
                    WHEN c.TC_PHYSICAL_NAME = 'TOTAL_WEIGHT' THEN 'NULL'
                    WHEN c.TC_PHYSICAL_NAME = 'TOTAL_SCORE' THEN 'NULL'
                    WHEN c.TC_PHYSICAL_NAME = 'APPRAISAL_APPROVAL_TECH' THEN 'XMLTYPE(''<o>''||XML_COL||''</o>'')'
                    WHEN c.TC_PHYSICAL_NAME = 'SCORE_APPROVAL_TECH' THEN 'XMLTYPE(''<s>''||XML_COL||''</s>'')'
                    WHEN c.TC_PHYSICAL_NAME = 'ROW_IDENTIFIER' THEN v_obj_ent_table_name||'_ROW_IDENTIFIER_SEQ.NEXTVAL'
                    WHEN c.TC_PHYSICAL_NAME = 'ROW_VERSION' THEN '0'
                    ELSE 'NULL' END||CHR(10)||',';
    END LOOP;

    -- remove trailing ',' and CHR(10) characters
    v_ins_columns := SUBSTR(v_ins_columns, 1, LENGTH(v_ins_columns)-1);
    v_sel_values := SUBSTR(v_sel_values, 1, LENGTH(v_sel_values)-2);

    v_sql := 'DECLARE'||CHR(10)
        ||'v_period_id NUMBER;'||CHR(10)
        ||'v_lvl_no NUMBER;'||CHR(10)
    ||'BEGIN'||CHR(10)
        ||'v_period_id := :1;'||CHR(10)
        ||'v_lvl_no := :2;'||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'INS_ADD_ENT' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'INS_ADD_ENT' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'INTO '||v_obj_ent_table_name||' ('||v_ins_columns||')'||CHR(10)
                   ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_ADD_ENT' ,pi_proc_id => pi_definition_id)||CHR(10)
        ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_ADD_ENT' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||v_sel_values||CHR(10)
        ||'FROM'||CHR(10)
            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_GET_APPL_LVL' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_GET_APPL_LVL' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' E_INTERNAL_ID'||CHR(10)
                ||',LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(LVL)||'': ''||' ELSE NULL END||'CASE WHEN HLEVEL IS NOT NULL THEN ''None'' ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY LVL) CHAR_COL'||CHR(10)
                ||',LISTAGG(''<l><ln>''||TO_CHAR(LVL)||''</ln><app>''||CASE WHEN HLEVEL IS NOT NULL THEN ''1'' ELSE ''0'' END||''</app><u></u><e></e></l>'', '''') WITHIN GROUP (ORDER BY LVL) XML_COL'||CHR(10)
            ||'FROM'||CHR(10)
                ||CASE WHEN pi_entity_table.FROM_CLAUSE IS NOT NULL THEN pi_entity_table.FROM_CLAUSE ELSE pi_entity_table.TABLE_NAME END||' LE'||CHR(10)
                ||'INNER JOIN ('        ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_CONSTR_LVLS' ,pi_proc_id => pi_definition_id)
                            ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_CONSTR_LVLS' ,pi_proc_id => pi_definition_id)
                            ||' LEVEL LVL FROM DUAL CONNECT BY LEVEL <= v_lvl_no) LVLS ON 1 = 1'||CHR(10)
                ||'LEFT JOIN (SELECT DISTINCT LOWER_VALUE,HLEVEL FROM '||pi_hierarchy_qry||') HRC ON LE.E_INTERNAL_ID = HRC.LOWER_VALUE AND LVLS.LVL = HRC.HLEVEL'||CHR(10)
            ||'WHERE NOT EXISTS ('          ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_ENT_NOT_EXISTS' ,pi_proc_id => pi_definition_id)
                                ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADD_ENTITIES' ,pi_hint_id=> 'SEL_ENT_NOT_EXISTS' ,pi_proc_id => pi_definition_id)
                                ||' 1 FROM '||v_obj_ent_table_name||' IE WHERE IE.'||v_entity_col||' = LE.E_INTERNAL_ID AND IE.'||v_period_col||' = v_period_id)'||CHR(10)
            ||CASE WHEN pi_entity_table.WHERE_CLAUSE IS NOT NULL THEN 'AND '||pi_entity_table.WHERE_CLAUSE||CHR(10) ELSE NULL END
            ||'GROUP BY LE.E_INTERNAL_ID'||CHR(10)
            ||') TAB;'||CHR(10)
    ||'END;';

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    EXECUTE IMMEDIATE v_sql USING pi_period_id, vrec_def.OBD_APPROVAL_NUM_LVLS;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END ADD_ENTITIES;


/* UPDATE_ENTITY_TOTALS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.02.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE UPDATE_ENTITY_TOTALS
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_obj_table_name            VARCHAR2(200 CHAR);
    v_sql                       CLOB;
BEGIN
    v_stamp := 'OBJECTIVES.UPDATE_ENTITY_TOTALS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),    ',pi_period_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pi_entity_table), ',pi_entity_table => <value>', v_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_period_id IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which entities need to be added must not be null.'); END IF;
        IF (pi_entity_table.FROM_CLAUSE IS NULL
            AND pi_entity_table.TABLE_NAME IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The entity table provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
        IF (vrec_def.OBD_OBJECTIVES_TABLES_ID IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The Appraisals table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);
    v_obj_table_name := 'T'||TO_CHAR(vrec_def.OBD_OBJECTIVES_TABLES_ID);

    IF (vrec_def.OBD_CALCULATE_OVERALL_SCORE = 1)
    THEN
        v_sql := 'DECLARE'||CHR(10)
            ||'v_period_id NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_period_id := :1;'||CHR(10)
                      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS' ,pi_hint_id=> 'MRG_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'MERGE '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS' ,pi_hint_id=> 'MRG_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO '||v_obj_ent_table_name||' DEST'||CHR(10)
            ||'USING'||CHR(10)
            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS' ,pi_hint_id=> 'SEL_SOURCE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS' ,pi_hint_id=> 'SEL_SOURCE' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' LE.E_INTERNAL_ID '||v_entity_col||CHR(10)
                ||','||CASE WHEN vrec_def.OBD_OVR_SCORE_TYPE = 0 THEN 'ROUND(SUM(SCORE * WEIGHT), '||TO_CHAR(vrec_def.OBD_OVR_SCORE_NUM_DECS)||')'
                            WHEN vrec_def.OBD_OVR_SCORE_TYPE = 1 THEN 'SUM(SCORE)'
                            ELSE NULL END||' TOTAL_SCORE'||CHR(10)
                ||CASE WHEN vrec_def.OBD_OVR_SCORE_TYPE = 0 THEN ',SUM(WEIGHT) TOTAL_WEIGHT'||CHR(10) ELSE NULL END
            ||'FROM '||CHR(10)
                ||CASE WHEN pi_entity_table.FROM_CLAUSE IS NOT NULL THEN pi_entity_table.FROM_CLAUSE ELSE pi_entity_table.TABLE_NAME END||' LE'||CHR(10)
                ||'LEFT JOIN '||v_obj_table_name||' O ON O.'||v_entity_col||' = LE.E_INTERNAL_ID AND O.'||v_period_col||' = v_period_id'||CHR(10)
                ||CASE WHEN pi_entity_table.WHERE_CLAUSE IS NOT NULL THEN ' WHERE '||pi_entity_table.WHERE_CLAUSE||CHR(10) ELSE NULL END
            ||'GROUP BY LE.E_INTERNAL_ID'||CHR(10)
            ||') SRC'||CHR(10)
            ||' ON (DEST.'||v_entity_col||' = SRC.'||v_entity_col||' AND DEST.'||v_period_col||' = v_period_id)'||CHR(10)
            ||'WHEN MATCHED THEN UPDATE SET DEST.TOTAL_SCORE = SRC.TOTAL_SCORE'
                ||CASE WHEN vrec_def.OBD_OVR_SCORE_TYPE = 0 THEN ', DEST.TOTAL_WEIGHT = SRC.TOTAL_WEIGHT' ELSE NULL END
            ||';'||CHR(10)
        ||'END;';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
        EXECUTE IMMEDIATE v_sql USING pi_period_id;
    END IF;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END UPDATE_ENTITY_TOTALS;


/* UPDATE_ENTITY_TOTALS_IND
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.04.14 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE UPDATE_ENTITY_TOTALS_IND
(    pi_definition_id           IN NUMBER
    ,pi_entity_table            IN OBJTYPE_INPUT_TABLE_LIST
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_obj_table_name            VARCHAR2(200 CHAR);
    v_sql                       CLOB;
BEGIN
    v_stamp := 'OBJECTIVES.UPDATE_ENTITY_TOTALS_IND - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTOBJECT(pi_entity_table), ',pi_entity_table => <value>', v_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_entity_table.FROM_CLAUSE IS NULL
            AND pi_entity_table.TABLE_NAME IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The entity table provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
        IF (vrec_def.OBD_OBJECTIVES_TABLES_ID IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The Appraisals table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);
    v_obj_table_name := 'T'||TO_CHAR(vrec_def.OBD_OBJECTIVES_TABLES_ID);

    IF (vrec_def.OBD_CALCULATE_OVERALL_SCORE = 1)
    THEN
        v_sql :=        COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS_IND' ,pi_hint_id=> 'MRG_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'MERGE '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS_IND' ,pi_hint_id=> 'MRG_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO '||v_obj_ent_table_name||' DEST'||CHR(10)
            ||'USING'||CHR(10)
            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS_IND' ,pi_hint_id=> 'SEL_SOURCE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.UPDATE_ENTITY_TOTALS_IND' ,pi_hint_id=> 'SEL_SOURCE' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' LE.'||v_period_col||CHR(10)
                ||',LE.'||v_entity_col||CHR(10)
                ||','||CASE WHEN vrec_def.OBD_OVR_SCORE_TYPE = 0 THEN 'ROUND(SUM(SCORE * WEIGHT), '||TO_CHAR(vrec_def.OBD_OVR_SCORE_NUM_DECS)||')'
                            WHEN vrec_def.OBD_OVR_SCORE_TYPE = 1 THEN 'SUM(SCORE)'
                            ELSE NULL END||' TOTAL_SCORE'||CHR(10)
                ||CASE WHEN vrec_def.OBD_OVR_SCORE_TYPE = 0 THEN ',SUM(WEIGHT) TOTAL_WEIGHT'||CHR(10) ELSE NULL END
            ||'FROM'||CHR(10)
                ||CASE WHEN pi_entity_table.FROM_CLAUSE IS NOT NULL THEN pi_entity_table.FROM_CLAUSE ELSE pi_entity_table.TABLE_NAME END||' LE'||CHR(10)
                ||'LEFT JOIN '||v_obj_table_name||' O ON O.'||v_period_col||' = LE.'||v_period_col||' AND O.'||v_entity_col||' = LE.'||v_entity_col||CHR(10)
            ||CASE WHEN pi_entity_table.WHERE_CLAUSE IS NOT NULL THEN ' WHERE '||pi_entity_table.WHERE_CLAUSE||CHR(10) ELSE NULL END
            ||'GROUP BY LE.'||v_period_col||', LE.'||v_entity_col||CHR(10)
            ||') SRC'||CHR(10)
            ||' ON (DEST.'||v_entity_col||' = SRC.'||v_entity_col||' AND DEST.'||v_period_col||' = SRC.'||v_period_col||')'||CHR(10)
            ||'WHEN MATCHED THEN UPDATE SET DEST.TOTAL_SCORE = SRC.TOTAL_SCORE'
            ||CASE WHEN vrec_def.OBD_OVR_SCORE_TYPE = 0 THEN ', DEST.TOTAL_WEIGHT = SRC.TOTAL_WEIGHT' ELSE NULL END;

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
        EXECUTE IMMEDIATE v_sql;
    END IF;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END UPDATE_ENTITY_TOTALS_IND;


/* ADJUST_APPROVAL_PROPERTIES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.01.17 - Dumitriu, Cosmin - created
    2015.07.29 - Dumitriu, Cosmin - added parameter pi_period_id
               - when the param is populated then only the hierarchy levels are adjusted for the specified period
-----------------------------------------------------------------------------------------------
*/
PROCEDURE ADJUST_APPROVAL_PROPERTIES
(    pi_definition_id           IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
    ,pi_add_obj_approval        IN NUMBER
    ,pi_change_levels           IN NUMBER
    ,pi_period_id               IN NUMBER
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_hlp_approval_descr        CLOB;
    v_hlp_approval_tech         CLOB;
    v_sql                       CLOB;
BEGIN
    v_stamp := 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),    ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),      ',pi_hierarchy_qry => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_add_obj_approval), ',pi_add_obj_approval => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_change_levels),    ',pi_change_levels => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),        ',pi_period_id => <value>', v_stamp);

        IF (pi_definition_id IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_hierarchy_qry IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The hierarchy query provided must not be null.'); END IF;
        IF (NVL(pi_add_obj_approval, 0) = 0
            AND NVL(pi_change_levels, 0) = 0) THEN RAISE_APPLICATION_ERROR(-20001, 'No modifications have been submitted. Either number of levels or addition of appraisal column should be = 1.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_APPROVAL_NUM_LVLS IS NULL)     THEN RAISE_APPLICATION_ERROR(-20001, 'The maximum number of levels to approve is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);

    IF (NVL(pi_change_levels, 0) = 0)
    THEN
        v_hlp_approval_descr := 'LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(LVLS.LVL)||'': ''||' ELSE NULL END
            ||'CASE WHEN LST.HLEVEL IS NOT NULL THEN ''None''
                    ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY LVLS.LVL)';

        v_hlp_approval_tech := 'LISTAGG(''<l>''
                ||''<ln>''||TO_CHAR(LVLS.LVL)||''</ln>''
                ||''<app>''||CASE WHEN LST.HLEVEL IS NOT NULL THEN ''1'' ELSE ''0'' END||''</app>''
                ||''<u></u>''
                ||''<e></e>''
            ||''</l>'', '''') WITHIN GROUP (ORDER BY LVLS.LVL)';

        v_sql := 'DECLARE'||CHR(10)
            ||'v_lvl_no     NUMBER;'||CHR(10)
            ||'v_period_id  NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_lvl_no := :1;'||CHR(10)
            ||'v_period_id := :2;'||CHR(10)
                      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'MRG_NO_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'MERGE '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'MRG_NO_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO '||v_obj_ent_table_name||' DEST'||CHR(10)
            ||'USING'||CHR(10)
            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_NO_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_NO_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||'OE.'||v_period_col||', OE.'||v_entity_col||CHR(10)
                ||','||v_hlp_approval_descr||' OBJECTIVE_APPROVAL_N'||CHR(10)
                ||',XMLTYPE(''<o>''||'||v_hlp_approval_tech||'||''</o>'') OBJECTIVE_APPROVAL_TECH_N'||CHR(10)
            ||'FROM'||CHR(10)
                ||v_obj_ent_table_name||' OE'||CHR(10)
                ||'INNER JOIN ('        ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_CONSTR_LVLS' ,pi_proc_id => pi_definition_id)
                            ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_CONSTR_LVLS' ,pi_proc_id => pi_definition_id)
                            ||' LEVEL LVL FROM DUAL CONNECT BY LEVEL <= v_lvl_no) LVLS ON 1 = 1'||CHR(10)
                ||'LEFT JOIN (SELECT DISTINCT '||v_period_col||','||v_entity_col||',HLEVEL FROM '||pi_hierarchy_qry||') LST ON OE.'||v_period_col||' = LST.'||v_period_col
                                                    ||' AND OE.'||v_entity_col||' = LST.'||v_entity_col
                                                    ||' AND LVLS.LVL = LST.HLEVEL'||CHR(10)
            ||'GROUP BY OE.'||v_period_col||', OE.'||v_entity_col||CHR(10)
            ||') SRC'||CHR(10)
            ||'ON (DEST.'||v_period_col||' = SRC.'||v_period_col||' AND DEST.'||v_entity_col||' = SRC.'||v_entity_col||')'||CHR(10)
            ||'WHEN MATCHED THEN UPDATE SET DEST.APPRAISAL_APPROVAL = SRC.OBJECTIVE_APPROVAL_N,DEST.APPRAISAL_APPROVAL_TECH = SRC.OBJECTIVE_APPROVAL_TECH_N;'||CHR(10)
        ||'END;';
    ELSE
        /*15.SEP.2015
          Modified here the <u> and <e> to keep previous approvals even if the level is no longer applicable*/
        v_hlp_approval_descr := 'LISTAGG('||CASE WHEN vrec_def.OBD_APPROVAL_NUM_LVLS > 1 THEN '''Level''||TO_CHAR(LVLS.LVL)||'': ''||' ELSE NULL END
            ||'CASE WHEN X.<SRC>_USERID IS NOT NULL
                    THEN X.<SRC>_USERID||CASE WHEN X.<SRC>_ENTITYBK IS NOT NULL THEN '' (''||X.<SRC>_ENTITYBK||'')'' ELSE NULL END
                    WHEN LST.HLEVEL IS NOT NULL
                    THEN ''None''
                    ELSE ''Not Applicable'' END, ''; '') WITHIN GROUP (ORDER BY LVLS.LVL)';

        /*15.SEP.2015
          Modified here the <u> and <e> to keep previous approvals even if the level is no longer applicable*/
        v_hlp_approval_tech := 'LISTAGG(''<l>''
                ||''<ln>''||TO_CHAR(LVLS.LVL)||''</ln>''
                ||''<app>''||CASE WHEN LST.HLEVEL IS NOT NULL THEN ''1'' ELSE ''0'' END||''</app>''
                ||''<u>''||X.<SRC>_USERID||''</u>''
                ||''<e>''||X.<SRC>_ENTITYBK||''</e>''
            ||''</l>'', '''') WITHIN GROUP (ORDER BY LVLS.LVL)';

        v_sql := 'DECLARE'||CHR(10)
            ||'v_lvl_no     NUMBER;'||CHR(10)
            ||'v_period_id  NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_lvl_no := :1;'||CHR(10)
            ||'v_period_id := :2;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO TEMP_OBJECTIVES_APPROVALS(ENTITY_ID, PERIOD_ID, S_LVLNO, S_APPLICABLE, S_USERID, S_ENTITYBK, O_LVLNO, O_APPLICABLE, O_USERID, O_ENTITYBK)'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' OE.'||v_entity_col||' ENTITY_ID'||CHR(10)
                ||',OE.'||v_period_col||' PERIOD_ID'||CHR(10)
                ||',S.LVLNO S_LVLNO,S.APPLICABLE S_APPLICABLE,S.USERID S_USERID,S.ENTITYBK S_ENTITYBK'||CHR(10)
                ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                        THEN ',O.LVLNO O_LVLNO,O.APPLICABLE O_APPLICABLE,O.USERID O_USERID,O.ENTITYBK O_ENTITYBK'
                        ELSE ',NULL O_LVLNO,NULL O_APPLICABLE,NULL O_USERID,NULL O_ENTITYBK'
                        END||CHR(10)
            ||'FROM '||v_obj_ent_table_name||' OE'||CHR(10)
            ||'INNER JOIN XMLTABLE(''/s/l'' PASSING OE.SCORE_APPROVAL_TECH COLUMNS'
                ||' LVLNO NUMBER PATH ''ln'''
                ||',APPLICABLE NUMBER PATH ''app'''
                ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') S ON 1 = 1'||CHR(10)
            ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN 'INNER JOIN XMLTABLE(''/o/l'' PASSING OE.APPRAISAL_APPROVAL_TECH COLUMNS'
                            ||' LVLNO NUMBER PATH ''ln'''
                            ||',APPLICABLE NUMBER PATH ''app'''
                            ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                            ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') O ON O.LVLNO = S.LVLNO OR S.LVLNO IS NULL'||CHR(10)
                    ELSE NULL END
            ||CASE WHEN pi_period_id IS NOT NULL THEN 'WHERE OE.'||v_period_col||' = v_period_id'||CHR(10) ELSE NULL END
            ||';'||CHR(10)

                      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'MRG_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'MERGE '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'MRG_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO '||v_obj_ent_table_name||' DEST'||CHR(10)
            ||'USING'||CHR(10)
            ||'('      ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_LVL_CHANGE' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' OE.'||v_period_col||CHR(10)
                ||',OE.'||v_entity_col||CHR(10)
                ||','||REPLACE(v_hlp_approval_descr, '<SRC>', 'S')||' SCORE_APPROVAL_N'||CHR(10)
                ||',XMLTYPE(''<s>''||'||REPLACE(v_hlp_approval_tech, '<SRC>', 'S')||'||''</s>'') SCORE_APPROVAL_TECH_N'||CHR(10)
                ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                        THEN ','||REPLACE(v_hlp_approval_descr, '<SRC>', 'O')||' OBJECTIVE_APPROVAL_N'||CHR(10)
                           ||',XMLTYPE(''<o>''||'||REPLACE(v_hlp_approval_tech, '<SRC>', 'O')||'||''</o>'') OBJECTIVE_APPROVAL_TECH_N'||CHR(10)
                        ELSE NULL END
            ||'FROM'||CHR(10)
                ||v_obj_ent_table_name||' OE'||CHR(10)
                ||'INNER JOIN ('        ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_CONSTR_LVLS' ,pi_proc_id => pi_definition_id)
                            ||' SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.ADJUST_APPROVAL_PROPERTIES' ,pi_hint_id=> 'SEL_CONSTR_LVLS' ,pi_proc_id => pi_definition_id)
                            ||' LEVEL LVL FROM DUAL CONNECT BY LEVEL <= v_lvl_no) LVLS ON 1 = 1'||CHR(10)
                ||'LEFT JOIN (SELECT DISTINCT '||v_period_col||','||v_entity_col||',HLEVEL FROM '||pi_hierarchy_qry||') LST ON OE.'||v_period_col||' = LST.'||v_period_col||' AND OE.'||v_entity_col||' = LST.'||v_entity_col
                                                    ||' AND LVLS.LVL = LST.HLEVEL'||CHR(10)
                ||'LEFT JOIN TEMP_OBJECTIVES_APPROVALS X ON OE.'||v_period_col||' = X.PERIOD_ID AND OE.'||v_entity_col||' = X.ENTITY_ID'
                                                    ||' AND LVLS.LVL = X.S_LVLNO'||CHR(10)
            ||CASE WHEN pi_period_id IS NOT NULL THEN 'WHERE OE.'||v_period_col||' = v_period_id'||CHR(10) ELSE NULL END
            ||'GROUP BY OE.'||v_period_col||', OE.'||v_entity_col||CHR(10)
            ||') SRC'||CHR(10)
            ||'ON (DEST.'||v_period_col||' = SRC.'||v_period_col||' AND DEST.'||v_entity_col||' = SRC.'||v_entity_col||')'||CHR(10)
            ||'WHEN MATCHED THEN UPDATE SET'||CHR(10)
                ||'DEST.SCORE_APPROVAL = SRC.SCORE_APPROVAL_N,DEST.SCORE_APPROVAL_TECH = SRC.SCORE_APPROVAL_TECH_N'
                ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                        THEN ',DEST.APPRAISAL_APPROVAL = SRC.OBJECTIVE_APPROVAL_N,DEST.APPRAISAL_APPROVAL_TECH = SRC.OBJECTIVE_APPROVAL_TECH_N'
                        ELSE NULL END
                ||';'||CHR(10)
        ||'END;';
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    EXECUTE IMMEDIATE v_sql USING vrec_def.OBD_APPROVAL_NUM_LVLS, pi_period_id;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END ADJUST_APPROVAL_PROPERTIES;


/* APPROVE_OBJECTIVES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2013.12.02 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION APPROVE_OBJECTIVES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.APPROVE_OBJECTIVES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    vcur_result := MODIFY_OBJECTIVES_SCORES( pi_operation       => 1
                                            ,pi_definition_id   => pi_definition_id
                                            ,pi_period_id       => pi_period_id
                                            ,pi_user_name       => pi_user_name
                                            ,pi_user_entity_bk  => pi_user_entity_bk
                                            ,pi_approval_mode   => pi_approval_mode
                                            ,pi_obj_entity_list => pi_obj_entity_list
                                            ,pi_obj_entity_qry  => pi_obj_entity_qry
                                            ,pi_hierarchy_qry   => pi_hierarchy_qry
                                            ,pi_stamp           => v_stamp);

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END APPROVE_OBJECTIVES;


/* APPROVE_SCORES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2013.12.02 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION APPROVE_SCORES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.APPROVE_SCORES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    vcur_result := MODIFY_OBJECTIVES_SCORES( pi_operation       => 2
                                            ,pi_definition_id   => pi_definition_id
                                            ,pi_period_id       => pi_period_id
                                            ,pi_user_name       => pi_user_name
                                            ,pi_user_entity_bk  => pi_user_entity_bk
                                            ,pi_approval_mode   => pi_approval_mode
                                            ,pi_obj_entity_list => pi_obj_entity_list
                                            ,pi_obj_entity_qry  => pi_obj_entity_qry
                                            ,pi_hierarchy_qry   => pi_hierarchy_qry
                                            ,pi_stamp           => v_stamp);

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END APPROVE_SCORES;


/* UNAPPROVE_OBJECTIVES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2013.12.02 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION UNAPPROVE_OBJECTIVES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.UNAPPROVE_OBJECTIVES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    vcur_result := MODIFY_OBJECTIVES_SCORES( pi_operation       => 3
                                            ,pi_definition_id   => pi_definition_id
                                            ,pi_period_id       => pi_period_id
                                            ,pi_user_name       => pi_user_name
                                            ,pi_user_entity_bk  => pi_user_entity_bk
                                            ,pi_approval_mode   => pi_approval_mode
                                            ,pi_obj_entity_list => pi_obj_entity_list
                                            ,pi_obj_entity_qry  => pi_obj_entity_qry
                                            ,pi_hierarchy_qry   => pi_hierarchy_qry
                                            ,pi_stamp           => v_stamp);

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END UNAPPROVE_OBJECTIVES;


/* UNAPPROVE_SCORES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2013.12.02 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION UNAPPROVE_SCORES
(    pi_definition_id           IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_user_name               IN VARCHAR2
    ,pi_user_entity_bk          IN VARCHAR2
    ,pi_approval_mode           IN NUMBER
    ,pi_obj_entity_list         IN TABLETYPE_NUMBER
    ,pi_obj_entity_qry          IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.UNAPPROVE_SCORES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    vcur_result := MODIFY_OBJECTIVES_SCORES( pi_operation       => 4
                                            ,pi_definition_id   => pi_definition_id
                                            ,pi_period_id       => pi_period_id
                                            ,pi_user_name       => pi_user_name
                                            ,pi_user_entity_bk  => pi_user_entity_bk
                                            ,pi_approval_mode   => pi_approval_mode
                                            ,pi_obj_entity_list => pi_obj_entity_list
                                            ,pi_obj_entity_qry  => pi_obj_entity_qry
                                            ,pi_hierarchy_qry   => pi_hierarchy_qry
                                            ,pi_stamp           => v_stamp);

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END UNAPPROVE_SCORES;


/* RUN_IMPORT_VALIDATIONS
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.02.19 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION RUN_IMPORT_VALIDATIONS
(    pi_definition_id           IN NUMBER
    ,pi_import_location         IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_internal_id      IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pi_subordinate_mode        IN NUMBER
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    vrec_score_scale            OBJ_SCORE_SCALES%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_entity_map_col            VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_vld_when_sql              CLOB;
    v_vld_select_sql            CLOB;
    v_score_join_sql            CLOB;
    v_sql                       CLOB;
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.RUN_IMPORT_VALIDATIONS - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),        ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_import_location),      ',pi_import_location => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),            ',pi_period_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_entity_internal_id),   ',pi_entity_internal_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temp_table_name),    ',pi_temp_table_name => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_column_mapping),   ',pi_column_mapping => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_subordinate_mode),     ',pi_subordinate_mode => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),          ',pi_hierarchy_qry => <value>', v_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (NVL(pi_import_location, 0) NOT IN (1,2,3,4)) THEN RAISE_APPLICATION_ERROR(-20001, 'The import location is invalid.'); END IF;
        IF (pi_period_id IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which appraisals need to be imported must not be null.'); END IF;
        IF (pi_import_location IN (2, 4)
            AND pi_entity_internal_id IS NULL)      THEN RAISE_APPLICATION_ERROR(-20001, 'The entity ID for which appraisals need to be imported must not be null.'); END IF;
        IF (pi_temp_table_name IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The temporary table provided must not be null.'); END IF;
        IF (pi_column_mapping IS NULL)              THEN RAISE_APPLICATION_ERROR(-20001, 'The column mapping provided must not be null.'); END IF;
        IF (pi_import_location = 3
            AND NVL(pi_subordinate_mode, 0) NOT IN (1, 2)) THEN RAISE_APPLICATION_ERROR(-20001, 'The subordinate mode provided for the Appraisal form view is invalid.'); END IF;
        IF (pi_import_location = 3
            AND pi_hierarchy_qry IS NULL)           THEN RAISE_APPLICATION_ERROR(-20001, 'The hierarchy query provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get appraisal score scale
    BEGIN
        SELECT * INTO vrec_score_scale
        FROM OBJ_SCORE_SCALES
        WHERE OSS_ID = pi_definition_id;

        IF (vrec_score_scale.OSS_SCORE_TYPE = 2
            AND (vrec_score_scale.OSS_WORST_VALUE IS NULL
                OR vrec_score_scale.OSS_BEST_VALUE IS NULL)) THEN RAISE_APPLICATION_ERROR(-20001, 'The score is of type numeric but best and worst values were not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The score type has not been defined.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);

    -- build validations
    FOR C IN
    (   SELECT  NAME1, NAME2
        FROM    TABLE(pi_column_mapping)
    )
    LOOP
        IF (C.NAME1 = 'WEIGHT' AND vrec_def.OBD_OVR_SCORE_TYPE = 0)
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_WEIGHTS = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1101)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' IS NOT NULL AND TMP.'||C.NAME2||'*100 NOT BETWEEN '||TO_CHAR(vrec_def.OBD_OVR_SCORE_WGHT_MIN_VALUE)
                                                                                                                    ||' AND '||TO_CHAR(vrec_def.OBD_OVR_SCORE_WGHT_MAX_VALUE)||' THEN 1 ELSE 0 END HAS_INVALID_WEIGHTS'||CHR(10);

            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_WEIGHT_DEC = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1105)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' IS NOT NULL AND LENGTH(TO_CHAR(MOD(ABS(TMP.'||C.NAME2||'), 1))) - 1 > '||TO_CHAR((vrec_def.OBD_OVR_SCORE_WGHT_NUM_DECS+2))||' THEN 1 ELSE 0 END HAS_INVALID_WEIGHT_DEC'||CHR(10);

        ELSIF (C.NAME1 = 'SCORE' AND vrec_score_scale.OSS_SCORE_TYPE = 2)
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_NUM_SCORES = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1102)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' IS NOT NULL AND TMP.'||C.NAME2||' NOT BETWEEN '||TO_CHAR(vrec_score_scale.OSS_WORST_VALUE)
                                                                                                                    ||' AND '||TO_CHAR(vrec_score_scale.OSS_BEST_VALUE)||' THEN 1 ELSE 0 END HAS_INVALID_NUM_SCORES'||CHR(10);

            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_NUM_SCR_DEC = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1106)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' IS NOT NULL AND LENGTH(TO_CHAR(MOD(ABS(TMP.'||C.NAME2||'), 1))) - 1 > '||TO_CHAR(vrec_score_scale.OSS_NUM_DECS)||' THEN 1 ELSE 0 END HAS_INVALID_NUM_SCR_DEC'||CHR(10);

        ELSIF (C.NAME1 = 'SCORE' AND vrec_score_scale.OSS_SCORE_TYPE = 3)
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_CUSTNUM_SCORES = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1103)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' IS NOT NULL AND SC.OSCV_VALUE IS NULL THEN 1 ELSE 0 END HAS_INVALID_CUSTNUM_SCORES'||CHR(10);
            v_score_join_sql := 'LEFT JOIN OBJ_SCORE_CUSTNUM_VALUES SC ON SC.OSCV_OSS_ID = v_definition_id AND TMP.'||C.NAME2||' = SC.OSCV_VALUE'||CHR(10);

        ELSIF (C.NAME1 = 'RATING' AND vrec_score_scale.OSS_SCORE_TYPE = 4)
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_RATING_SCORES = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1104)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' IS NOT NULL AND SC.OSRV_SCORE_VALUE IS NULL THEN 1 ELSE 0 END HAS_INVALID_RATING_SCORES'||CHR(10);
            v_score_join_sql := 'LEFT JOIN OBJ_SCORE_RATING_VALUES SC ON SC.OSRV_OSS_ID = v_definition_id AND UPPER(TMP.'||C.NAME2||') = UPPER(SC.OSRV_RATING)'||CHR(10);

        ELSIF (C.NAME1 = v_period_col AND pi_import_location IN (3, 4))
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_PERIOD = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1107)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' <> '||TO_CHAR(pi_period_id)||' THEN 1 ELSE 0 END HAS_INVALID_PERIOD'||CHR(10);

        ELSIF (C.NAME1 = v_entity_col AND pi_import_location = 3)
        THEN
            v_entity_map_col := C.NAME2;

        ELSIF (C.NAME1 = v_entity_col AND pi_import_location = 4)
        THEN
            v_vld_when_sql := v_vld_when_sql||'WHEN HAS_INVALID_ENTITY = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1107)'||CHR(10);
            v_vld_select_sql := v_vld_select_sql||',CASE WHEN TMP.'||C.NAME2||' <> '||TO_CHAR(pi_entity_internal_id)||' THEN 1 ELSE 0 END HAS_INVALID_ENTITY'||CHR(10);
        END IF;
    END LOOP;

    -- remove first comma
    v_vld_select_sql := SUBSTR(v_vld_select_sql, 2, LENGTH(v_vld_select_sql));

    IF (v_vld_when_sql IS NOT NULL)
    THEN
        v_sql := 'DECLARE'||CHR(10)
            ||'v_definition_id NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_definition_id := :1;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'INS_OBJ_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'INS_OBJ_VLD' ,pi_proc_id => pi_definition_id)
            ||' ALL'||CHR(10)
            ||v_vld_when_sql
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'SEL_OBJ_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'SEL_OBJ_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' '||v_vld_select_sql
            ||'FROM '||pi_temp_table_name||' TMP'||CHR(10)
                ||v_score_join_sql||';'||CHR(10)
        ||'END;';

        -- for debug purposes make a backup of the temporary table
        -- in production this should be commented
        -- OBJECTIVES.MAKE_IMPORT_TABLE_BACKUP(pi_temp_table_name);

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
        EXECUTE IMMEDIATE v_sql USING pi_definition_id;
    END IF;

    IF (pi_import_location = 3)
    THEN
        v_sql := 'DECLARE'||CHR(10)
            ||'v_period_id NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_period_id := :1;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'INS_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO TEMP_OBJECTIVES_APPROVALS(ENTITY_ID, PERIOD_ID, S_LVLNO, S_APPLICABLE, S_USERID, S_ENTITYBK, O_LVLNO, O_APPLICABLE, O_USERID, O_ENTITYBK)'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'SEL_EXPAND_OE_XML' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' OE.'||v_entity_col||' ENTITY_ID'||CHR(10)
                ||',OE.'||v_period_col||' PERIOD_ID'||CHR(10)
                ||',S.LVLNO S_LVLNO,S.APPLICABLE S_APPLICABLE,S.USERID S_USERID,S.ENTITYBK S_ENTITYBK'||CHR(10)
                ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                        THEN ',O.LVLNO O_LVLNO,O.APPLICABLE O_APPLICABLE,O.USERID O_USERID,O.ENTITYBK O_ENTITYBK'
                        ELSE ',NULL O_LVLNO,NULL O_APPLICABLE,NULL O_USERID,NULL O_ENTITYBK'
                        END||CHR(10)
            ||'FROM '||v_obj_ent_table_name||' OE'||CHR(10)
            ||'INNER JOIN XMLTABLE(''/s/l'' PASSING OE.SCORE_APPROVAL_TECH COLUMNS'
                ||' LVLNO NUMBER PATH ''ln'''
                ||',APPLICABLE NUMBER PATH ''app'''
                ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') S ON 1 = 1'||CHR(10)
            ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN 'INNER JOIN XMLTABLE(''/o/l'' PASSING OE.APPRAISAL_APPROVAL_TECH COLUMNS'
                            ||' LVLNO NUMBER PATH ''ln'''
                            ||',APPLICABLE NUMBER PATH ''app'''
                            ||',USERID VARCHAR2(200 CHAR) PATH ''u'''
                            ||',ENTITYBK VARCHAR2(200 CHAR) PATH ''e'') O ON O.LVLNO = S.LVLNO OR S.LVLNO IS NULL'||CHR(10)
                    ELSE NULL END
            ||'WHERE OE.'||v_period_col||' = v_period_id'||CHR(10)
                ||'AND OE.'||v_entity_col||' IN (SELECT DISTINCT '||v_entity_map_col||' FROM '||pi_temp_table_name||');'||CHR(10)

                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'INS_APPROVAL_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'INS_APPROVAL_VLD' ,pi_proc_id => pi_definition_id)
            ||' ALL'||CHR(10)
            ||'WHEN HAS_INVALID_ENTITY = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1107)'||CHR(10)
            ||'WHEN USER_LVL_NOT_APPLICABLE = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1108)'||CHR(10)
            ||'WHEN SCR_APPROVED_AT_USER_LVL = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1109)'||CHR(10)
            ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                    THEN 'WHEN OBJ_APPROVED_AT_USER_LVL = 1 THEN INTO TEMP_OBJECTIVES_VALIDATIONS (VALIDATION_ID) VALUES (1109)'||CHR(10)
                    ELSE NULL END
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'SEL_APPROVAL_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT_VALIDATIONS' ,pi_hint_id=> 'SEL_APPROVAL_VLD' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' CASE WHEN HRC.LOWER_VALUE IS NULL THEN 1 ELSE 0 END HAS_INVALID_ENTITY'||CHR(10)
                ||',CASE WHEN X.S_LVLNO = HRC.HLEVEL AND X.S_APPLICABLE = 0 THEN 1 ELSE 0 END USER_LVL_NOT_APPLICABLE'||CHR(10)
                ||',CASE WHEN X.S_APPLICABLE = 1 AND X.S_LVLNO >= HRC.HLEVEL AND X.S_USERID IS NOT NULL THEN 1 ELSE 0 END SCR_APPROVED_AT_USER_LVL'||CHR(10)
                ||CASE  WHEN vrec_def.OBD_APPROVAL_TYPE = 1
                        THEN ',CASE WHEN X.O_APPLICABLE = 1 AND X.O_LVLNO >= HRC.HLEVEL AND X.O_USERID IS NOT NULL THEN 1 ELSE 0 END OBJ_APPROVED_AT_USER_LVL'||CHR(10)
                        ELSE NULL END
            ||'FROM'||CHR(10)
            ||'(SELECT DISTINCT '||v_entity_map_col||' FROM '||pi_temp_table_name||') TMP'||CHR(10)
            ||'LEFT JOIN (SELECT LOWER_VALUE,MAX(HLEVEL) AS HLEVEL FROM '||pi_hierarchy_qry||' GROUP BY LOWER_VALUE) HRC ON TMP.'||v_entity_map_col||' = HRC.LOWER_VALUE'||CHR(10)
            ||'LEFT JOIN TEMP_OBJECTIVES_APPROVALS X ON TMP.'||v_entity_map_col||' = X.ENTITY_ID;'||CHR(10)
        ||'END;';

        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql),'v_sql := <value>;',v_stamp);
        EXECUTE IMMEDIATE v_sql USING pi_period_id;
    END IF;

    OPEN vcur_result FOR
    SELECT DISTINCT VALIDATION_ID FROM TEMP_OBJECTIVES_VALIDATIONS;

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END RUN_IMPORT_VALIDATIONS;


/* RUN_IMPORT
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.02.21 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE RUN_IMPORT
(    pi_definition_id           IN NUMBER
    ,pi_import_location         IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_entity_internal_id      IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pi_hierarchy_qry           IN CLOB
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_entity_map_col            VARCHAR2(200 CHAR);
    v_rating_map_col            VARCHAR2(200 CHAR);
    v_obj_table_name            VARCHAR2(200 CHAR);
    v_ins_columns               CLOB;
    v_sel_values                CLOB;
    v_score_join_sql            CLOB;
    vrec_score_scale            OBJ_SCORE_SCALES%ROWTYPE;
    v_entity_table              OBJTYPE_INPUT_TABLE_LIST;
    v_sql                       CLOB;
BEGIN
    v_stamp := 'OBJECTIVES.RUN_IMPORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),        ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_import_location),      ',pi_import_location => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),            ',pi_period_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_entity_internal_id),   ',pi_entity_internal_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temp_table_name),    ',pi_temp_table_name => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_column_mapping),   ',pi_column_mapping => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),          ',pi_hierarchy_qry => <value>', v_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (NVL(pi_import_location, 0) NOT IN (1,2,3,4)) THEN RAISE_APPLICATION_ERROR(-20001, 'The import location is invalid.'); END IF;
        IF (pi_period_id IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which appraisals need to be imported must not be null.'); END IF;
        IF (pi_import_location IN (2, 4)
            AND pi_entity_internal_id IS NULL)      THEN RAISE_APPLICATION_ERROR(-20001, 'The entity ID for which appraisals need to be imported must not be null.'); END IF;
        IF (pi_temp_table_name IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The temporary table provided must not be null.'); END IF;
        IF (pi_column_mapping IS NULL)              THEN RAISE_APPLICATION_ERROR(-20001, 'The column mapping provided must not be null.'); END IF;
        IF (pi_import_location IN (1, 3)
            AND pi_hierarchy_qry IS NULL)           THEN RAISE_APPLICATION_ERROR(-20001, 'The hierarchy query provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_ENTITY_ID IS NULL)             THEN RAISE_APPLICATION_ERROR(-20001, 'The entity for which the appraisals are set is not defined.'); END IF;
        IF (vrec_def.OBD_ENTITIES_TABLES_ID IS NULL)    THEN RAISE_APPLICATION_ERROR(-20001, 'The Entities table of the appraisal definition is not defined.'); END IF;
        IF (vrec_def.OBD_OBJECTIVES_TABLES_ID IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The Appraisals table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_table_name := 'T'||TO_CHAR(vrec_def.OBD_OBJECTIVES_TABLES_ID);

    -- get appraisal score scale
    BEGIN
        SELECT * INTO vrec_score_scale
        FROM OBJ_SCORE_SCALES
        WHERE OSS_ID = pi_definition_id;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The score type has not been defined.');
    END;

    -- get mapping column from temp table for RATING column
    BEGIN
    SELECT NAME2 INTO v_rating_map_col FROM TABLE(pi_column_mapping) WHERE NAME1 = 'RATING';
    EXCEPTION WHEN OTHERS THEN NULL;
    END;

    -- for each column in the Appraisals table build the insert clauses
    FOR C IN
    (   SELECT   TC_PHYSICAL_NAME
                ,MP.NAME2 TEMP_MAPPING_COL
        FROM    TABLE_COLUMNS TC
                LEFT JOIN TABLE(pi_column_mapping) MP ON TC.TC_PHYSICAL_NAME = MP.NAME1
        WHERE   TC_TABLES_ID = vrec_def.OBD_OBJECTIVES_TABLES_ID
        ORDER BY TC_ORDER
    )
    LOOP
        v_ins_columns := v_ins_columns||','||c.TC_PHYSICAL_NAME;
        v_sel_values := v_sel_values||','
            ||CASE  WHEN C.TC_PHYSICAL_NAME = v_period_col THEN 'v_period_id'
                    WHEN C.TC_PHYSICAL_NAME = v_entity_col AND pi_import_location IN (1, 3) THEN 'TMP.'||C.TEMP_MAPPING_COL
                    WHEN C.TC_PHYSICAL_NAME = v_entity_col AND pi_import_location IN (2, 4) THEN 'v_entity_internal_id'
                    WHEN C.TC_PHYSICAL_NAME = 'ROW_IDENTIFIER' THEN v_obj_table_name||'_ROW_IDENTIFIER_SEQ.NEXTVAL'
                    WHEN C.TC_PHYSICAL_NAME = 'ROW_VERSION' THEN '0'
                    WHEN C.TC_PHYSICAL_NAME = 'WEIGHT' AND C.TEMP_MAPPING_COL IS NOT NULL THEN 'TMP.'||C.TEMP_MAPPING_COL
                    WHEN C.TC_PHYSICAL_NAME = 'SCORE' AND vrec_score_scale.OSS_SCORE_TYPE = 4 AND v_rating_map_col IS NOT NULL THEN 'SC.OSRV_SCORE_VALUE'
                    WHEN C.TEMP_MAPPING_COL IS NOT NULL THEN 'TMP.'||C.TEMP_MAPPING_COL
                    ELSE 'NULL' END||CHR(10);

        IF (C.TC_PHYSICAL_NAME = v_entity_col)
        THEN
            v_entity_map_col := C.TEMP_MAPPING_COL;
        END IF;

        -- if scores are of type RATING values for SCORE field will be taken from metadata based on RATING values in temp table
        IF (C.TC_PHYSICAL_NAME = 'SCORE' AND vrec_score_scale.OSS_SCORE_TYPE = 4 AND v_rating_map_col IS NOT NULL)
        THEN
            v_score_join_sql := 'LEFT JOIN OBJ_SCORE_RATING_VALUES SC ON SC.OSRV_OSS_ID = v_definition_id AND UPPER(TMP.'||v_rating_map_col||') = UPPER(SC.OSRV_RATING)'||CHR(10);
        END IF;
    END LOOP;

    v_ins_columns := SUBSTR(v_ins_columns, 2, LENGTH(v_ins_columns));
    v_sel_values := SUBSTR(v_sel_values, 2, LENGTH(v_sel_values));

    -- build the query that will be passed to ADD_ENTITIES and UPDATE_ENTITY_TOTALS
    IF (pi_import_location IN (1, 3))
    THEN
        v_entity_table := OBJTYPE_INPUT_TABLE_LIST(  pi_temp_table_name
                                                    ,'(SELECT DISTINCT '||v_entity_map_col||' E_INTERNAL_ID FROM '||pi_temp_table_name||')'
                                                    ,NULL
                                                    ,NULL
                                                    ,NULL);
    ELSIF (pi_import_location IN (2, 4))
    THEN
        v_entity_table := OBJTYPE_INPUT_TABLE_LIST(  pi_temp_table_name
                                                    ,'(SELECT '||TO_CHAR(pi_entity_internal_id)||' E_INTERNAL_ID FROM DUAL)'
                                                    ,NULL
                                                    ,NULL
                                                    ,NULL);
    END IF;

    v_sql := 'DECLARE'||CHR(10)
            ||'v_period_id          NUMBER;'||CHR(10)
            ||'v_entity_internal_id NUMBER;'||CHR(10)
            ||'v_definition_id      NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_period_id          := :1;'||CHR(10)
            ||'v_entity_internal_id := :2;'||CHR(10)
            ||'v_definition_id      := :3;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT' ,pi_hint_id=> 'INS_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT' ,pi_hint_id=> 'INS_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO '||v_obj_table_name||' ('||v_ins_columns||')'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.RUN_IMPORT' ,pi_hint_id=> 'SEL_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.RUN_IMPORT' ,pi_hint_id=> 'SEL_MAIN' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' '||v_sel_values
            ||'FROM '||pi_temp_table_name||' TMP'||CHR(10)
                ||v_score_join_sql||';'||CHR(10)
        ||'END;';

    -- for debug purposes make a backup of the temporary table
    -- in production this should be commented
    -- OBJECTIVES.MAKE_IMPORT_TABLE_BACKUP(pi_temp_table_name);

    -- if import is made for more than one entity - then make sure all are added to the Appraisal entities table
    IF (pi_import_location IN (1, 3))
    THEN
        OBJECTIVES.ADD_ENTITIES
        (    pi_definition_id   => pi_definition_id
            ,pi_period_id       => pi_period_id
            ,pi_hierarchy_qry   => pi_hierarchy_qry
            ,pi_entity_table    => v_entity_table);
    END IF;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    EXECUTE IMMEDIATE v_sql USING pi_period_id, pi_entity_internal_id, pi_definition_id;

    -- update the TOTAL_SCORE and TOTAL_WEIGHT fields in the parent Appraisal entity records
    OBJECTIVES.UPDATE_ENTITY_TOTALS
    (    pi_definition_id   => pi_definition_id
        ,pi_period_id       => pi_period_id
        ,pi_entity_table    => v_entity_table);

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END RUN_IMPORT;


/* GET_LOAD_VALIDATION_CLAUSES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.03.04 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE GET_LOAD_VALIDATION_CLAUSES
(    pi_definition_id           IN NUMBER
    ,pi_table_type              IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pio_validation_clauses     IN OUT TABLETYPE_OBJECTIVE_LOAD_VLD
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    vrec_score_scale            OBJ_SCORE_SCALES%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_period_map_col            VARCHAR2(200 CHAR);
    v_entity_map_col            VARCHAR2(200 CHAR);
    v_score_map_col             VARCHAR2(200 CHAR);
    v_weight_map_col            VARCHAR2(200 CHAR);
    v_obj_per_table_name        VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_idx                       PLS_INTEGER;
BEGIN
    v_stamp := 'OBJECTIVES.GET_LOAD_VALIDATION_CLAUSES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),            ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_table_type),               ',pi_table_type => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temp_table_name),        ',pi_temp_table_name => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_column_mapping),       ',pi_column_mapping => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pio_validation_clauses),  ',pio_validation_clauses => <value>', v_stamp);

        IF (pi_definition_id IS NULL)   THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_table_type IS NULL)      THEN RAISE_APPLICATION_ERROR(-20001, 'The table type provided must not be null.'); END IF;
        IF (pi_temp_table_name IS NULL) THEN RAISE_APPLICATION_ERROR(-20001, 'The temporary table provided must not be null.'); END IF;
        IF (pi_column_mapping IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The column mapping provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get appraisal score scale
    BEGIN
        SELECT * INTO vrec_score_scale
        FROM OBJ_SCORE_SCALES
        WHERE OSS_ID = pi_definition_id;

        IF (vrec_score_scale.OSS_SCORE_TYPE = 2
            AND (vrec_score_scale.OSS_WORST_VALUE IS NULL
                OR vrec_score_scale.OSS_BEST_VALUE IS NULL)) THEN RAISE_APPLICATION_ERROR(-20001, 'The score is of type numeric but best and worst values were not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The score type has not been defined.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_per_table_name := 'T'||TO_CHAR(vrec_def.OBD_PERIODS_TABLES_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);

    -- store mapping columns
    v_idx := pi_column_mapping.FIRST;
	WHILE (v_idx IS NOT NULL)
    LOOP
        IF (pi_column_mapping(v_idx).NAME1 = v_period_col)    THEN v_period_map_col := pi_column_mapping(v_idx).NAME2;
        ELSIF (pi_column_mapping(v_idx).NAME1 = v_entity_col) THEN v_entity_map_col := pi_column_mapping(v_idx).NAME2;
        ELSIF (pi_column_mapping(v_idx).NAME1 = 'WEIGHT')     THEN v_weight_map_col := pi_column_mapping(v_idx).NAME2;
        ELSIF (pi_column_mapping(v_idx).NAME1 = 'SCORE')      THEN v_score_map_col := pi_column_mapping(v_idx).NAME2;
        END IF;

        v_idx := pi_column_mapping.NEXT(v_idx);
	END LOOP;

    -- build validations
    v_idx := pio_validation_clauses.FIRST;
	WHILE (v_idx IS NOT NULL)
	LOOP
        IF (pio_validation_clauses(v_idx).VLD_ID = 1201)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN NOT EXISTS(SELECT 1 FROM '||v_obj_per_table_name||' OP'
                                                                                ||' WHERE OP.'||v_period_col||' = '||pi_temp_table_name||'.'||v_period_map_col
                                                                                ||' AND UPPER(OP.STATUS) = ''OPEN'') THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1202)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN NOT EXISTS(SELECT 1 FROM '||v_obj_ent_table_name||' OE'
                                                                                ||' WHERE OE.'||v_period_col||' = '||pi_temp_table_name||'.'||v_period_map_col
                                                                                ||' AND OE.'||v_entity_col||' = '||pi_temp_table_name||'.'||v_entity_map_col||') THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1203)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN '||pi_temp_table_name||'.'||v_weight_map_col||' IS NOT NULL'
                                                                   ||' AND '||pi_temp_table_name||'.'||v_weight_map_col||'*100 NOT BETWEEN '||TO_CHAR(vrec_def.OBD_OVR_SCORE_WGHT_MIN_VALUE)
                                                                                                                    ||' AND '||TO_CHAR(vrec_def.OBD_OVR_SCORE_WGHT_MAX_VALUE)||' THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1204)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN '||pi_temp_table_name||'.'||v_score_map_col||' IS NOT NULL'
                                                                   ||' AND '||pi_temp_table_name||'.'||v_score_map_col||' NOT BETWEEN '||TO_CHAR(vrec_score_scale.OSS_WORST_VALUE)
                                                                                                                    ||' AND '||TO_CHAR(vrec_score_scale.OSS_BEST_VALUE)||' THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1205)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN '||pi_temp_table_name||'.'||v_score_map_col||' IS NOT NULL'
                                                                   ||' AND '||pi_temp_table_name||'.'||v_score_map_col||' NOT IN '
                                                                   ||'(SELECT OSCV_VALUE FROM OBJ_SCORE_CUSTNUM_VALUES WHERE OSCV_OSS_ID = '||TO_CHAR(pi_definition_id)||') THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1206)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN '||pi_temp_table_name||'.'||v_score_map_col||' IS NOT NULL'
                                                                   ||' AND '||pi_temp_table_name||'.'||v_score_map_col||' NOT IN '
                                                                   ||'(SELECT OSRV_SCORE_VALUE FROM OBJ_SCORE_RATING_VALUES WHERE OSRV_OSS_ID = '||TO_CHAR(pi_definition_id)||') THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1207)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN '||pi_temp_table_name||'.'||v_weight_map_col||' IS NOT NULL'
                                                                   ||' AND LENGTH(TO_CHAR(MOD(ABS('||pi_temp_table_name||'.'||v_weight_map_col||'), 1))) - 1 > '||TO_CHAR((vrec_def.OBD_OVR_SCORE_WGHT_NUM_DECS+2))||' THEN 0 ELSE 1 END';

        ELSIF (pio_validation_clauses(v_idx).VLD_ID = 1208)
        THEN
            pio_validation_clauses(v_idx).VLD_WHEN_CLAUSE := 'CASE WHEN '||pi_temp_table_name||'.'||v_score_map_col||' IS NOT NULL'
                                                                   ||' AND LENGTH(TO_CHAR(MOD(ABS('||pi_temp_table_name||'.'||v_score_map_col||'), 1))) - 1 > '||TO_CHAR(vrec_score_scale.OSS_NUM_DECS)||' THEN 0 ELSE 1 END';
        END IF;

        v_idx := pio_validation_clauses.NEXT(v_idx);
	END LOOP;

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pio_validation_clauses),  'pio_validation_clauses := <value>;', v_stamp);
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_LOAD_VALIDATION_CLAUSES;


/* LOAD_OBJECTIVES
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.03.11 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
PROCEDURE LOAD_OBJECTIVES
(    pi_definition_id           IN NUMBER
    ,pi_temp_table_name         IN VARCHAR2
    ,pi_column_mapping          IN TABLETYPE_NAME_MAP
    ,pi_temp_query              IN CLOB
    ,pi_load_mode               IN NUMBER
) IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    vrec_score_scale            OBJ_SCORE_SCALES%ROWTYPE;
    v_entity_col                VARCHAR2(200 CHAR);
    v_entity_map_col            VARCHAR2(200 CHAR);
    v_period_col                VARCHAR2(200 CHAR);
    v_period_map_col            VARCHAR2(200 CHAR);
    v_score_map_col             VARCHAR2(200 CHAR);
    v_obj_table_name            VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_temp_table_name           CLOB;
    v_ins_columns               CLOB;
    v_sel_values                CLOB;
    v_score_join_sql            CLOB;
    v_entity_table              OBJTYPE_INPUT_TABLE_LIST;
    v_sql                       CLOB;
BEGIN
    v_stamp := 'OBJECTIVES.LOAD_OBJECTIVES - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),        ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTVARCHAR2(pi_temp_table_name),    ',pi_temp_table_name => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCOLLECTION(pi_column_mapping),   ',pi_column_mapping => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_temp_query),             ',pi_temp_query => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_load_mode),            ',pi_load_mode => <value>', v_stamp);

        IF (pi_definition_id IS NULL)   THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (pi_temp_table_name IS NULL and pi_temp_query is null) THEN RAISE_APPLICATION_ERROR(-20001, 'The temporary table provided must not be null.'); END IF;
        IF (pi_column_mapping IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The column mapping provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;

        IF (vrec_def.OBD_OBJECTIVES_TABLES_ID IS NULL)  THEN RAISE_APPLICATION_ERROR(-20001, 'The Appraisals table of the appraisal definition is not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    v_temp_table_name := NVL(pi_temp_table_name, '('||pi_temp_query||')');

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_table_name := 'T'||TO_CHAR(vrec_def.OBD_OBJECTIVES_TABLES_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);

    -- get appraisal score scale
    BEGIN
        SELECT * INTO vrec_score_scale
        FROM OBJ_SCORE_SCALES
        WHERE OSS_ID = pi_definition_id;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The score type has not been defined.');
    END;

    -- get mapping columns
    FOR C IN (SELECT NAME1 DEST_COL, NAME2 TEMP_MAPPING_COL FROM TABLE(pi_column_mapping) MP)
    LOOP
        IF (C.DEST_COL = v_entity_col)  THEN v_entity_map_col := C.TEMP_MAPPING_COL; END IF;
        IF (C.DEST_COL = v_period_col)  THEN v_period_map_col := C.TEMP_MAPPING_COL; END IF;
        IF (C.DEST_COL = 'SCORE')       THEN v_score_map_col := C.TEMP_MAPPING_COL; END IF;
    END LOOP;

    -- for each column in the Appraisals table build the insert clauses
    FOR C IN
    (   SELECT   TC_PHYSICAL_NAME
                ,MP.NAME2 TEMP_MAPPING_COL
        FROM    TABLE_COLUMNS TC
                LEFT JOIN TABLE(pi_column_mapping) MP ON TC.TC_PHYSICAL_NAME = MP.NAME1
        WHERE   TC_TABLES_ID = vrec_def.OBD_OBJECTIVES_TABLES_ID
        ORDER BY TC_ORDER
    )
    LOOP
        v_ins_columns := v_ins_columns||','||c.TC_PHYSICAL_NAME;
        v_sel_values := v_sel_values||','
            ||CASE  WHEN C.TC_PHYSICAL_NAME = 'ROW_IDENTIFIER' THEN v_obj_table_name||'_ROW_IDENTIFIER_SEQ.NEXTVAL'
                    WHEN C.TC_PHYSICAL_NAME = 'ROW_VERSION' THEN '0'
                    WHEN C.TC_PHYSICAL_NAME = 'WEIGHT' AND C.TEMP_MAPPING_COL IS NOT NULL THEN 'TMP.'||C.TEMP_MAPPING_COL
                    WHEN C.TC_PHYSICAL_NAME = 'RATING' AND v_score_map_col IS NOT NULL THEN 'SC.OSRV_RATING'
                    WHEN C.TEMP_MAPPING_COL IS NOT NULL THEN 'TMP.'||C.TEMP_MAPPING_COL
                    ELSE 'NULL' END||CHR(10);

        -- if scores are of type RATING values for SCORE field will be taken from metadata based on RATING values in temp table
        IF (C.TC_PHYSICAL_NAME = 'RATING' AND v_score_map_col IS NOT NULL)
        THEN
            v_score_join_sql := 'LEFT JOIN OBJ_SCORE_RATING_VALUES SC ON TMP.'||v_score_map_col||' = SC.OSRV_SCORE_VALUE AND SC.OSRV_OSS_ID = v_definition_id'||CHR(10);
        END IF;
    END LOOP;

    v_ins_columns := SUBSTR(v_ins_columns, 2, LENGTH(v_ins_columns));
    v_sel_values := SUBSTR(v_sel_values, 2, LENGTH(v_sel_values));

    v_sql := 'DECLARE'||CHR(10)
            ||'v_definition_id NUMBER;'||CHR(10)
        ||'BEGIN'||CHR(10)
            ||'v_definition_id := :1;'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.LOAD_OBJECTIVES' ,pi_hint_id=> 'INS_LO' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INSERT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.LOAD_OBJECTIVES' ,pi_hint_id=> 'INS_LO' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'INTO '||v_obj_table_name||' ('||v_ins_columns||')'||CHR(10)
                       ||COMMONS_PROCESSING.GET_HINT_LOCATION_NAME(pi_module_id => 'OBJECTIVES.LOAD_OBJECTIVES' ,pi_hint_id=> 'SEL_LO' ,pi_proc_id => pi_definition_id)||CHR(10)
            ||'SELECT '||COMMONS_PROCESSING.GET_HINTS(pi_module_id => 'OBJECTIVES.LOAD_OBJECTIVES' ,pi_hint_id=> 'SEL_LO' ,pi_proc_id => pi_definition_id)||CHR(10)
                ||' '||v_sel_values
            ||'FROM '||v_temp_table_name||' TMP'||CHR(10)
                ||v_score_join_sql||';'||CHR(10)
        ||'END;';

    -- for debug purposes make a backup of the temporary table
    -- in production this should be commented
    -- OBJECTIVES.MAKE_IMPORT_TABLE_BACKUP(v_temp_table_name);

    L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(v_sql), 'v_sql := <value>;', v_stamp);
    EXECUTE IMMEDIATE v_sql USING pi_definition_id;

    -- update the TOTAL_SCORE and TOTAL_WEIGHT fields in the parent Appraisal entity records
    IF (pi_load_mode = 1)
    THEN
        v_entity_table := OBJTYPE_INPUT_TABLE_LIST(NULL
                                                  ,'(SELECT DISTINCT '||v_entity_map_col||' '||v_entity_col
                                                                 ||','||v_period_map_col||' '||v_period_col||' FROM '||v_temp_table_name||')'
                                                  ,NULL
                                                  ,NULL
                                                  ,NULL);
    ELSIF (pi_load_mode = 2)
    THEN
        v_entity_table := OBJTYPE_INPUT_TABLE_LIST(NULL
                                                  ,'(SELECT '||v_entity_col||','||v_period_col||' FROM '||v_obj_ent_table_name||')'
                                                  ,NULL
                                                  ,NULL
                                                  ,NULL);
    END IF;

    OBJECTIVES.UPDATE_ENTITY_TOTALS_IND
    (    pi_definition_id   => pi_definition_id
        ,pi_entity_table    => v_entity_table
    );

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END LOAD_OBJECTIVES;


/* GET_STATUS_REPORT
-- Author       : Dumitriu, Cosmin
-- Create date  :
-- Reviewer     :
-- Review date  :
-- Description  :
-----------------------------------------------------------------------------------------------
-- History:
    2014.02.19 - Dumitriu, Cosmin - created
-----------------------------------------------------------------------------------------------
*/
FUNCTION GET_STATUS_REPORT
(    pi_definition_id           IN NUMBER
    ,pi_location                IN NUMBER
    ,pi_period_id               IN NUMBER
    ,pi_filter_qry              IN CLOB
    ,pi_hierarchy_qry           IN CLOB
) RETURN SYS_REFCURSOR IS
    v_stamp                     VARCHAR2(200 CHAR);
    vrec_def                    OBJ_DEFINITIONS%ROWTYPE;
    vrec_score_scale            OBJ_SCORE_SCALES%ROWTYPE;
    v_period_col                VARCHAR2(200 CHAR);
    v_entity_col                VARCHAR2(200 CHAR);
    v_obj_ent_table_name        VARCHAR2(200 CHAR);
    v_obj_table_name            VARCHAR2(200 CHAR);
    v_sql                       CLOB;
    vcur_result                 SYS_REFCURSOR;
BEGIN
    v_stamp := 'OBJECTIVES.GET_STATUS_REPORT - '||TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD HH24:MI:SSxFF');

    -- log and validate the input parameters
    BEGIN
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_definition_id),    ',pi_definition_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_location),         ',pi_location => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTNUMBER(pi_period_id),        ',pi_period_id => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_filter_qry),         ',pi_filter_qry => <value>', v_stamp);
        L4O_LOGGING.LOG_VARIABLE(L4O_LOGGING.LVL_DEBUG, ANYDATA.CONVERTCLOB(pi_hierarchy_qry),      ',pi_hierarchy_qry => <value>', v_stamp);

        IF (pi_definition_id IS NULL)               THEN RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition ID provided must not be null.'); END IF;
        IF (NVL(pi_location, 0) NOT IN (1,2))       THEN RAISE_APPLICATION_ERROR(-20001, 'The location is invalid.'); END IF;
        IF (pi_period_id IS NULL)                   THEN RAISE_APPLICATION_ERROR(-20001, 'The period ID for which appraisals need to be imported must not be null.'); END IF;
        IF (pi_filter_qry IS NULL)                  THEN RAISE_APPLICATION_ERROR(-20001, 'The filter query provided must not be null.'); END IF;
        IF (pi_location = 2
            AND pi_hierarchy_qry IS NULL)           THEN RAISE_APPLICATION_ERROR(-20001, 'The hierarchy query provided must not be null.'); END IF;
    END;

    -- get appraisal definition properties
    BEGIN
        SELECT * INTO vrec_def
        FROM OBJ_DEFINITIONS
        WHERE OBD_ID = pi_definition_id;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The appraisal definition supplied does not exist.');
    END;

    -- get appraisal score scale
    BEGIN
        SELECT * INTO vrec_score_scale
        FROM OBJ_SCORE_SCALES
        WHERE OSS_ID = pi_definition_id;

        IF (vrec_score_scale.OSS_SCORE_TYPE = 2
            AND (vrec_score_scale.OSS_WORST_VALUE IS NULL
                OR vrec_score_scale.OSS_BEST_VALUE IS NULL)) THEN RAISE_APPLICATION_ERROR(-20001, 'The score is of type numeric but best and worst values were not defined.'); END IF;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'The score type has not been defined.');
    END;

    -- get period column name
    BEGIN
        SELECT TC_PHYSICAL_NAME INTO v_period_col
        FROM TABLE_COLUMNS
        WHERE TC_TABLES_ID = vrec_def.OBD_ENTITIES_TABLES_ID AND TC_LOGIC_TYPE = 8;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'The period column name could not be determined.');
    END;

    v_entity_col := 'E'||TO_CHAR(vrec_def.OBD_ENTITY_ID);
    v_obj_ent_table_name := 'T'||TO_CHAR(vrec_def.OBD_ENTITIES_TABLES_ID);
    v_obj_table_name := 'T'||TO_CHAR(vrec_def.OBD_OBJECTIVES_TABLES_ID);

/*  OPEN vcur_result FOR
    SELECT DISTINCT VALIDATION_ID FROM TEMP_OBJECTIVES_VALIDATIONS;*/

    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_DEBUG, 'Done', NULL, NULL, v_stamp);
    RETURN vcur_result;
EXCEPTION
WHEN OTHERS THEN
    L4O_LOGGING.LOG_MESSAGE(L4O_LOGGING.LVL_ERROR, DBMS_UTILITY.FORMAT_ERROR_STACK||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, SQLCODE, SQLERRM, v_stamp);
    RAISE;
END GET_STATUS_REPORT;

-- *******************************    PUBLIC METHODS END    *******************************
END OBJECTIVES;
/
