CREATE PACKAGE REPORTS_GET_DATA AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type  : SPM
-- Product      : reportrepositorymanagement
-- Module      : reportsourcetables
-- Requester    : Budau, Marius
-- Author      : Lazarescu, Bogdan
-- Reviewer   :
-- Review date    :
-- Description    :
-- ---------------------------------------------------------------------------
		-- *******************************    PUBLIC TYPES START       *******************************
		-- *******************************    PUBLIC TYPES END         *******************************

		-- *******************************    PUBLIC CURSORS START       *******************************
		-- *******************************    PUBLIC CURSORS END         *******************************

		-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************
		-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

		-- *******************************    PUBLIC FUNCTIONS START       *******************************
		-- *******************************    PUBLIC FUNCTIONS END         *******************************

		-- *******************************    PUBLIC PROCEDURES START       *******************************
PROCEDURE EXPOSE_DATA_FROM_FILE
  (
  pin_report_schema varchar2
   , pin_table_name varchar2
   , pin_table_type varchar2
  );

PROCEDURE EXPOSE_DATA_FROM_REPORTSOURCE
  (
  pin_report_schema varchar2
   , pin_view_name varchar2
   , pin_query clob
   , pin_partner_schema INTEGER DEFAULT 0
  );

PROCEDURE DROP_DATA_FROM_REPORTSOURCE
  (
  pin_report_schema varchar2
   , pin_view_name varchar2
  );

PROCEDURE CREATE_ROLES
  (
  pin_ahmtd_schema varchar2
   , pin_roles_list TABLETYPE_RD_ROLE
  );

PROCEDURE DELETE_ROLES
  (
  pin_ahmtd_schema varchar2
   , pin_roles_list TABLETYPE_RD_ROLE
  );

PROCEDURE ADD_OBJECT
  (
  pin_ahmtd_schema varchar2
  , pin_object_name varchar2
  , pin_column_list TABLETYPE_RD_FIELD
  );

PROCEDURE DELETE_OBJECT
  (
  pin_ahmtd_schema varchar2
  , pin_object_name varchar2
  );

PROCEDURE GRANT_RIGHTS_TO_ROLE
  (
  pin_ahmtd_schema varchar2
  , pin_role_object_map TABLETYPE_RD_ROLE_OBJECT_MAP
  );

PROCEDURE REVOKE_RIGHTS_TO_ROLE
  (
  pin_ahmtd_schema varchar2
  , pin_role_object_map TABLETYPE_RD_ROLE_OBJECT_MAP
  );
		-- *******************************    PUBLIC PROCEDURES END         *******************************
END REPORTS_GET_DATA;
/
