CREATE PACKAGE TERRITORIES_ADJUSTMENTS AS
-- -----------------------------------------------------------------------------
-- Copyright (c) 2013 - 2014 Optymyze Pte. Ltd. All Rights Reserved.
-- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
-- is not to be divulged or used by parties who have not received written
-- authorization from Optymyze Pte. Ltd.
-- ---------------------------------------------------------------------------
-- Database Type    : SPM
-- Product          : territories_adjustments
-- Module           : territories_adjustments
-- Requester        : Horlescu, Gabriel
-- Author           : Macarie, Sabina
-- Reviewer         :
-- Review date      : 15 MAY 2016
-- Description      : Package used to handle all territories_adjustments processing
-- ---------------------------------------------------------------------------
-- *******************************    PUBLIC TYPES START       *******************************
-- *******************************    PUBLIC TYPES END         *******************************

-- *******************************    PUBLIC CURSORS START       *******************************
-- *******************************    PUBLIC CURSORS END         *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... START       *******************************

-- *******************************    PUBLIC CONSTANTS, VARIABLES, EXCEPTIONS, ETC... END         *******************************

-- *******************************    PUBLIC FUNCTIONS START       *******************************

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160720
-- Description: Calculate impact metrics for start date, when changing the date, when proposing adjustments
--              The metrics can be of type - COUNT - no of acc/reps assigned to each territory
--                                         - SUM - calculates a sum based on an additional data table with metrics
--              The procedure is called when - creating a new snapshot to have impact metric calculated for start date
--                                           - changing the date from the date picker to have impact metrics calculated for that date
--                                           - when making an adjustment (align, assign, etc) to recalculate metrics for the impacted territories
--              The procedure calculates initial value and current value of a impact metric using snapshot tables:
--                  TS_INIT_ASSIGN_TABLE_ID, TS_INIT_USER_ASSIGN_TABLE_ID(for initial values), TS_ASSIGN_TABLE_ID, TS_USER_ASSIGN_TABLE_ID(for current values)
--              It uses 2 types of snapshot - one for keeping inital values and one for modified values because it cannot calculate all initial values
--                  at the beginning for the snapshot interval (since we can have a null end date) and we have to calculate initial values only when
--                  needed, but the assignment tables are modifid at each proposal => the initial values will not be the correct ones
--              Future improvement - use an algorithm to determine initial value based on backtracking proposals
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_snapshot_id          NUMBER            Snapshot ID
   pi_territory_entity_id  NUMBER            Territory entity ID
   pi_account_entity_id    NUMBER            Account entity ID
   pi_rep_entity_id        NUMBER            Rep entity ID
   pi_selected_date        DATE              Selected date for which metrics are calculated
   pi_proposals            TABLETYPE_NUMBER  Used when calculated metrics after an adjutment is made - contains a list of impacted territories

*/
  -----------------------------------------------------------------------------------------
-- Call example:
/*
   calculate_metrics(1, 123, 345, 556, sysdate, tabletype_number(1,2,3));
*/
-----------------------------------------------------------------------------------------
PROCEDURE CALCULATE_METRICS(pi_snapshot_id              NUMBER,
                            pi_territory_entity_id      NUMBER,
                            pi_account_entity_id        NUMBER,
                            pi_rep_entity_id            NUMBER,
                            pi_selected_date            DATE,
                            pi_proposals                TABLETYPE_NUMBER
);


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160510
-- Description: Procedure used at create snapshot - copies data from assignment tables to snapshot tables
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
   pi_table_mapping             TABLETYPE_ID_ID   Mappings between snapshot and assignment tables
   pi_snapshot_id               NUMBER            Snapshot ID
   pi_territory_entity_id       NUMBER            Territory entity ID
   pi_account_entity_id         NUMBER            Account entity ID
   pi_rep_entity_id             NUMBE             Rep entity ID

*/
  -----------------------------------------------------------------------------------------
-- Call example:
/*
   create_snapshot(tabletype_id_id(objtype_id_id(1234, 5678)), 123456,  123, 567, 890)
*/
-----------------------------------------------------------------------------------------
PROCEDURE CREATE_SNAPSHOT(pi_table_mapping             TABLETYPE_ID_ID,
                          pi_snapshot_id               NUMBER,
                          pi_territory_entity_id       NUMBER,
                          pi_account_entity_id         NUMBER,
                          pi_rep_entity_id             NUMBER,
                          pout_inserted_rows_coll      OUT TABLETYPE_ID_ID
);


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160707
-- Description: Get adjustment initial data - procedure used for view display
-----------------------------------------------------------------------------------------
PROCEDURE GET_ADJUSTMENTS_INITIAL_DATA ( pin_assigned_entities_query       IN CLOB,
                                         pin_leaf_entities_validation      IN CLOB,
                                         pin_territories_query             IN CLOB,
                                         pin_count_territories_entities    IN CLOB,
                                         pin_entity_info_query             IN CLOB,
                                         pin_entity_ass_dates_query        IN CLOB,
                                         pout_territory_id_to_key          OUT SYS_REFCURSOR,
                                         pout_territory_to_entities        OUT SYS_REFCURSOR,
                                         pout_entities_assignment_dates    OUT SYS_REFCURSOR,
                                         pout_count_terr_entities          OUT SYS_REFCURSOR
);

-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20160726
-- Description: Procedure that inserts adjustments into proposed adjustment table
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id          NUMBER                      - Snapshot id
    pi_territory_entity_id  NUMBER                      - Territory entity id
    pi_account_entity_id    NUMBER                      - Account entity id
    pi_rep_entity_id        NUMBER                      - Sales rep entity id
    pi_proposals            TABLETYPE_TERRIT_PROPOSALS  - List of proposals
    pi_selected_date        DATE                        - Selected date from date picker
    pout_invalid_entities   OUT TABLETYPE_NUMBER        - Return list of acc/reps on which the adjustment could not be applied
                                                          if no rec updated for reassign/realign or close assignment/alignment for eff dated

*/
  -----------------------------------------------------------------------------------------
PROCEDURE PROPOSE_ADJUSTMENTS(pi_snapshot_id             NUMBER,
                              pi_territory_entity_id     NUMBER,
                              pi_account_entity_id       NUMBER,
                              pi_rep_entity_id           NUMBER,
                              pi_proposals               TABLETYPE_TERRIT_PROPOSALS,
                              pi_selected_date           DATE);




-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20161028
-- Description: Procedure that merges adjustments from snapshot with live data
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id           NUMBER                      - Snapshot id
    pi_territory_entity_id   NUMBER                      - Territory entity id
    pi_account_entity_id     NUMBER                      - Account entity id
    pi_rep_entity_id         NUMBER                      - Sales rep entity id
    pi_proposals             TABLETYPE_TERRIT_PROPOSALS  - List of proposals
    pi_assignment_table      VARCHAR2                    - Assignment table
    pi_user_assignment_table VARCHAR2                    - Alignment table

*/
-----------------------------------------------------------------------------------------
PROCEDURE MERGE_SNAPSHOT_WITH_LIVE (pi_snapshot_id           NUMBER,
                                    pi_territory_entity_id   NUMBER,
                                    pi_account_entity_id     NUMBER,
                                    pi_rep_entity_id         NUMBER,
                                    pi_proposals             TABLETYPE_TERRIT_PROPOSALS,
                                    pi_assignment_table      VARCHAR2,
                                    pi_user_assignment_table VARCHAR2
                                    );


-- ========================================================
-- Author     : Macarie, Sabina
-- Create date: 20170306
-- Description: Procedure that displays proposals on View Mode
-----------------------------------------------------------------------------------------
-- Input Parameters:
/*
    pi_snapshot_id           NUMBER                      - Snapshot id
    pi_territory_entity_id   NUMBER                      - Territory entity id
    pi_account_entity_id     NUMBER                      - Account entity id
    pi_rep_entity_id         NUMBER                      - Sales rep entity id
    pi_territory_disp_field  VARCHAR2                    - Territory display field
    pi_aligned_disp_field    VARCHAR2                    - Account display field
    pi_assigned_disp_field   VARCHAR2                    - Rep display field
    pi_lookup_territory      NUMBER                      - Used to display proposals for specific territory ID (old or new)

*/
-----------------------------------------------------------------------------------------
PROCEDURE GET_PROPOSAL_LIST(pi_snapshot_id          NUMBER,
                            pi_territory_entity_id  NUMBER,
                            pi_aligned_entity_id    NUMBER,
                            pi_assigned_entity_id   NUMBER,
                            pi_territory_disp_field VARCHAR2,
                            pi_aligned_disp_field   VARCHAR2,
                            pi_assigned_disp_field  VARCHAR2,
                            pi_lookup_territory     NUMBER,
                            po_result               OUT SYS_REFCURSOR);
-- *******************************    PUBLIC PROCEDURES END         *******************************

END TERRITORIES_ADJUSTMENTS;
/
