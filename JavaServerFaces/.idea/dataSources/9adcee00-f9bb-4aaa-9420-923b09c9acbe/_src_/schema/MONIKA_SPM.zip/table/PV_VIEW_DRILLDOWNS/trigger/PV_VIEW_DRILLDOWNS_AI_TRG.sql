CREATE TRIGGER PV_VIEW_DRILLDOWNS_AI_TRG
AFTER INSERT
  ON PV_VIEW_DRILLDOWNS
FOR EACH ROW
  BEGIN
                  SYSTEM_DATA.REGISTER_OBJECT
                  (  pi_or_id => :new.PVVD_ID,
                     pi_or_name => :new.PVVD_NAME,
                     pi_or_type => 71,
                     pi_or_container_id => NULL);
                  END;

/
