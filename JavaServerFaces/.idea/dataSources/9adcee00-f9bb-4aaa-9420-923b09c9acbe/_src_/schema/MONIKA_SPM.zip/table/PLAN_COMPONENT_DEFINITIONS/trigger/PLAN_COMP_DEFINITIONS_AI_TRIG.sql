CREATE TRIGGER PLAN_COMP_DEFINITIONS_AI_TRIG
AFTER INSERT
  ON PLAN_COMPONENT_DEFINITIONS
FOR EACH ROW
  BEGIN
			SYSTEM_DATA.register_object(pi_or_id => :new.PCD_ID,
                                         pi_or_name => :new.PCD_NAME,
                                         pi_or_type => 7,
                                         PI_OR_CONTAINER_ID => :new.PCD_VER_OBJECT_ID);
                                           END;
/
