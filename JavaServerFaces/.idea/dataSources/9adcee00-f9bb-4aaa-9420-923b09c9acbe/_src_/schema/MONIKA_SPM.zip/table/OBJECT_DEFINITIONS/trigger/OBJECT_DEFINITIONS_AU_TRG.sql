CREATE TRIGGER OBJECT_DEFINITIONS_AU_TRG
AFTER UPDATE OF OD_NAME, OD_CONTAINER_ID
  ON OBJECT_DEFINITIONS
FOR EACH ROW
  BEGIN
        SYSTEM_DATA.MODIFY_REGISTRATION
        (	pi_or_id => :new.OD_ID,
              pi_or_name => :new.OD_NAME,
              pi_or_container_id => :new.OD_CONTAINER_ID);
      END;
/
