CREATE TRIGGER DATA_LOAD_AU_TRG
AFTER UPDATE OF DL_NAME, DL_FOL_ID
  ON DATA_LOAD
FOR EACH ROW
  BEGIN
	SYSTEM_DATA.MODIFY_REGISTRATION
	(	pi_or_id => :new.DL_ID,
        pi_or_name => :new.DL_NAME,
        pi_or_container_id => :new.DL_FOL_ID);
END ;
/
