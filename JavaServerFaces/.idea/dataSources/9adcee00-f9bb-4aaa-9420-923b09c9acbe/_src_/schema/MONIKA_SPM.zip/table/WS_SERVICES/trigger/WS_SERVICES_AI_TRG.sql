CREATE TRIGGER WS_SERVICES_AI_TRG
AFTER INSERT
  ON WS_SERVICES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.WS_ID,
      pi_or_name => :new.WS_NAME,
      pi_or_type => 108,
	  pi_or_container_id => NULL);
  END;
/
