CREATE TRIGGER TU_CORRESPONDENCE_AI_TRG
AFTER INSERT
  ON TU_CORRESPONDENCE
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.TUC_ID,
      pi_or_name => :new.TUC_RELATIONSHIP_NAME,
      pi_or_type => 96,
	  pi_or_container_id => NULL);
  END;
/
