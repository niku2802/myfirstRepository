CREATE TRIGGER UPDATE_DB_LINK_NAME_TRG
BEFORE INSERT OR UPDATE
  ON DS_ORACLE
FOR EACH ROW
  DECLARE
  v_count           NUMBER;
  v_new_global_name VARCHAR2(100 CHAR);
BEGIN

  FOR i IN (SELECT substr(pr_value,REPLACE(instr(pr_value, '.', 1),0,length(pr_value) + 1),length(pr_value)) global_name
              FROM properties
             WHERE pr_name = 'DB_GLOBAL_NAME') LOOP

    EXECUTE IMMEDIATE ' SELECT COUNT(*) FROM all_db_links WHERE upper(db_link) like ''' || upper(:new.dso_dblink_name) || '%''' INTO v_count;

    IF v_count > 0 THEN
      v_new_global_name := :new.dso_dblink_name || I.global_name;
      FOR J IN (SELECT 1 FROM all_db_links WHERE upper(db_link) = v_new_global_name) LOOP
        :new.dso_dblink_name := :new.dso_dblink_name || I.global_name;
       END LOOP;
    END IF;
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
  NULL;
END;
/
