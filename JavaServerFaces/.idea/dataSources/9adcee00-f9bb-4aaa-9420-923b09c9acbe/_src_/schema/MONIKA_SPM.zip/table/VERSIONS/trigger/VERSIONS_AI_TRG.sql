CREATE TRIGGER VERSIONS_AI_TRG
AFTER INSERT
  ON VERSIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.VER_OBJECT_ID,
      pi_or_name => :new.VER_NAME,
      pi_or_type => :new.VER_DEF_TYPE_ID,
	  pi_or_container_id => NULL);
  END;
/
