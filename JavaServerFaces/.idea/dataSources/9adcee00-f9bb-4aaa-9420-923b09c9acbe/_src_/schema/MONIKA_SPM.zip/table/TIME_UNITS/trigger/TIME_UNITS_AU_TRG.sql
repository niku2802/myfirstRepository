CREATE TRIGGER TIME_UNITS_AU_TRG
AFTER UPDATE OF TU_NAME
  ON TIME_UNITS
FOR EACH ROW
  BEGIN
SYSTEM_DATA.MODIFY_REGISTRATION(pi_or_id => :new.TU_ID,
                                         pi_or_name => :new.TU_NAME);


END ;
/
