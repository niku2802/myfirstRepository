CREATE TRIGGER PLAN_PARAMETERS_DEFS_AU_TRG
AFTER UPDATE OF PPD_NAME, PPD_FOL_ID
  ON PLAN_PARAMETERS_DEFINITIONS
FOR EACH ROW
  BEGIN
							  SYSTEM_DATA.MODIFY_REGISTRATION
							  (	pi_or_id           => :new.PPD_ID,
								pi_or_name         => :new.PPD_NAME,
								pi_or_container_id => :new.PPD_FOL_ID);
							END;
/
