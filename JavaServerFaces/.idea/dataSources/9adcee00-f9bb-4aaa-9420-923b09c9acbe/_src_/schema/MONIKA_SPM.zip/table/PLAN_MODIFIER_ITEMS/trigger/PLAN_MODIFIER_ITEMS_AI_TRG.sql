CREATE TRIGGER PLAN_MODIFIER_ITEMS_AI_TRG
AFTER INSERT
  ON PLAN_MODIFIER_ITEMS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.PMI_ID,
      pi_or_name => :new.PMI_NAME,
      pi_or_type => 24,
	  pi_or_container_id => NULL);
  END;
/
