CREATE TRIGGER EMAIL_DIST_LISTS_AI_TRG
AFTER INSERT
  ON EMAIL_DIST_LISTS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.EDL_ID,
      pi_or_name => :new.EDL_NAME,
      pi_or_type => 38,
	  pi_or_container_id => :new.EDL_FOL_ID);
  END;
/
