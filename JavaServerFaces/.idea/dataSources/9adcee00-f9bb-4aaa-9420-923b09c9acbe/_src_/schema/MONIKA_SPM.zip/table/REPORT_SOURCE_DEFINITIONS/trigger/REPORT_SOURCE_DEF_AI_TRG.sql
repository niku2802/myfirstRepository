CREATE TRIGGER REPORT_SOURCE_DEF_AI_TRG
AFTER INSERT
  ON REPORT_SOURCE_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.RSD_ID,
      pi_or_name => :new.RSD_NAME,
      pi_or_type => 42,
	  pi_or_container_id => :new.RSD_FOL_ID);
  END;
/
