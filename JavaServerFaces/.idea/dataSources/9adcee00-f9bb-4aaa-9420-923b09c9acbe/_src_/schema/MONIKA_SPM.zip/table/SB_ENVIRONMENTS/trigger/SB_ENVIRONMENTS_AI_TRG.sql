CREATE TRIGGER SB_ENVIRONMENTS_AI_TRG
AFTER INSERT
  ON SB_ENVIRONMENTS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.SBE_ID,
      pi_or_name => :new.SBE_NAME,
      pi_or_type => 81,
	  pi_or_container_id => :new.SBE_FOL_ID);
  END;
/
