CREATE TRIGGER OBJECT_REGISTRATION_TRG
INSTEAD OF INSERT OR UPDATE
  ON OBJECT_REGISTRATION
FOR EACH ROW
COMPOUND TRIGGER
	  v_col_tab coltype_id := coltype_id();
	  BEFORE EACH ROW IS
		BEGIN
		  IF inserting THEN
			  v_col_tab.extend();
			  v_col_tab(v_col_tab.LAST) := :NEW.or_id;
		  ELSIF updating THEN
			IF :NEW.or_name <> :OLD.or_name THEN
			  v_col_tab.extend();
			  v_col_tab(v_col_tab.LAST) := :OLD.or_id;
			END IF;
		  END IF;
		END before EACH ROW;
		AFTER STATEMENT IS
		  BEGIN
			IF v_col_tab.count > 0
			Then
			  commons_utils.UPDATE_OBJ_RES_NAME(v_col_tab);
			END IF;
		END AFTER STATEMENT;
	END;
/
