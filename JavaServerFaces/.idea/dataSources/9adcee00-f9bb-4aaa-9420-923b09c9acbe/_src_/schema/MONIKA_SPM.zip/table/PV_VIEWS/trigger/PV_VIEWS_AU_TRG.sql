CREATE TRIGGER PV_VIEWS_AU_TRG
AFTER UPDATE
  ON PV_VIEWS
FOR EACH ROW
  declare
  v_requests_container_id number(10);
  v_tasks_container_id number(10);
  v_id number(10);
begin
  if (:new.PVV_ID is null or :new.PVV_NAME is null) then
    raise_application_error(-20000, 'PVV_ID or PVV_NAME cannot be null ');
  end if;
  if :new.PVV_DEFINITION_TYPE_ID = 61 then
    update OBJECT_REGISTRATION
       set OR_NAME = :new.PVV_NAME || ' (tasks table)',
           OR_CONTAINER_ID = null,
           OR_TYPE = :new.PVV_DEFINITION_TYPE_ID
     where OR_ID = :new.PVV_ID;
    select nvl(max(PVTV_REQ_CONT_ID),0)
      into v_requests_container_id
      from PV_TASK_VIEWS
     where PVTV_PVV_ID = :new.PVV_ID;
    if v_requests_container_id != 0 then
      system_data.modify_registration(pi_or_id           => v_requests_container_id,
                                      pi_or_name         => :new.PVV_NAME || ' (related requests table)',
                                      pi_or_container_id => null);
    end if;
  elsif :new.PVV_DEFINITION_TYPE_ID = 76 then
    update OBJECT_REGISTRATION
       set OR_NAME = :new.PVV_NAME || ' (returned requests table)',
           OR_CONTAINER_ID = null,
           OR_TYPE = :new.PVV_DEFINITION_TYPE_ID
     where OR_ID = :new.PVV_ID;
    select nvl(max(PVRRV_REQ_CONT_ID), 0), nvl(max(PVRRV_TASK_CONT_ID), 0)
      into v_requests_container_id, v_tasks_container_id
      from PV_RETURN_TO_REQUEST_VIEWS
     where PVRRV_PVV_ID = :new.PVV_ID;
    if v_requests_container_id != 0 then
      system_data.modify_registration(pi_or_id           => v_requests_container_id,
                                      pi_or_name         => :new.PVV_NAME || ' (related requests table)',
                                      pi_or_container_id => null);
    end if;
    if v_requests_container_id != 0 then
      system_data.modify_registration(pi_or_id           => v_tasks_container_id,
                                      pi_or_name         => :new.PVV_NAME || ' (related tasks table)',
                                      pi_or_container_id => null);
    end if;

  else
    update OBJECT_REGISTRATION
       set OR_NAME = :new.PVV_NAME,
           OR_CONTAINER_ID = null,
           OR_TYPE = nvl(:new.PVV_DEFINITION_TYPE_ID,93)
     where OR_ID = :new.PVV_ID;
  end if;
end;
/
