CREATE TRIGGER PV_VIEW_DRILLDOWNS_AU_TRG
AFTER UPDATE OF PVVD_NAME
  ON PV_VIEW_DRILLDOWNS
FOR EACH ROW
  BEGIN
                    SYSTEM_DATA.MODIFY_REGISTRATION
                    (	pi_or_id => :new.PVVD_ID,
                          pi_or_name => :new.PVVD_NAME,
                          pi_or_container_id => NULL);
                  END;
/
