CREATE TRIGGER APPLICATIONS_AU_TRG
AFTER UPDATE OF AP_LABEL
  ON APPLICATIONS
FOR EACH ROW
  BEGIN
            SYSTEM_DATA.MODIFY_REGISTRATION
            (     pi_or_id => :new.AP_ID,
                  pi_or_name => :new.AP_LABEL,
                  pi_or_container_id => NULL);
          END;
/
