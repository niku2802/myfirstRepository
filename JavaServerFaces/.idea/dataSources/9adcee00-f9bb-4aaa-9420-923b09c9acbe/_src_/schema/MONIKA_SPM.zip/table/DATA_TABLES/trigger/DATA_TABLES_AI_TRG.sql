CREATE TRIGGER DATA_TABLES_AI_TRG
AFTER INSERT
  ON DATA_TABLES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.DT_ID,
      pi_or_name => :new.DT_NAME,
      pi_or_type => 10,
	  pi_or_container_id => :new.DT_FOL_ID);
  END;
/
