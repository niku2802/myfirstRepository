CREATE TRIGGER APPLICATIONS_AI_TRG
AFTER INSERT
  ON APPLICATIONS
FOR EACH ROW
  BEGIN
                         SYSTEM_DATA.REGISTER_OBJECT
                         (  pi_or_id => :new.AP_ID,
                         pi_or_name => :new.AP_LABEL,
                         pi_or_type => 119,
	                       pi_or_container_id => NULL);
                         END;
/
