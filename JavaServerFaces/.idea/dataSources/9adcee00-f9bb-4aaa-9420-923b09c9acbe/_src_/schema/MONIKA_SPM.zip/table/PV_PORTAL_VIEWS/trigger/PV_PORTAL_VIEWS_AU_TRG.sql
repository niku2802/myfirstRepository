CREATE TRIGGER PV_PORTAL_VIEWS_AU_TRG
AFTER UPDATE
  ON PV_PORTAL_VIEWS
FOR EACH ROW
  BEGIN
                              SYSTEM_DATA.MODIFY_REGISTRATION
                              (  pi_or_id => :new.PVPV_ID,
                                    pi_or_name => :new.PVPV_NAME,
                                    pi_or_container_id => :new.PVPV_PF_ID);
                            END;
/
