CREATE TRIGGER GPACK_INSERT_TRG
AFTER INSERT
  ON GENERATED_PACKAGES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.GPACK_ID,
      pi_or_name => :new.GPACK_NAME,
      pi_or_type => 118,
	  pi_or_container_id => :new.GPACK_FOL_ID);
  END;
/
