CREATE TRIGGER FOLDERS_AI_TRG
AFTER INSERT
  ON FOLDERS
FOR EACH ROW
  BEGIN
                          SYSTEM_DATA.REGISTER_OBJECT
                          (  pi_or_id => :new.FOL_ID,
                            pi_or_name => :new.FOL_NAME,
                            pi_or_type => 3     ,
                            pi_OR_container_id => :new.FOL_CONTAINER_ID);
                        END;
/
