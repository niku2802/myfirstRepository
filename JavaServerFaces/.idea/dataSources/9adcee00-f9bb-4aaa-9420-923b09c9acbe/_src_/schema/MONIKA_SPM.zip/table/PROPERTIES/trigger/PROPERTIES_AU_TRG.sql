CREATE TRIGGER PROPERTIES_AU_TRG
AFTER UPDATE OF PR_VALUE
  ON PROPERTIES
FOR EACH ROW
  BEGIN
        IF (:new.PR_NAME IN ('L4O_LOGGING_LEVEL'
                            ,'L4O_OUTPUT_DEVICE'
                            ,'L4O_INCLUDE_TIMESTAMP'
                            ,'L4O_COLL_INCLUDE_INDEX'
                            ,'PROC_SESSION_STATS_ENABLED'
                            ,'PROC_EXEC_PLAN_ENABLED'
                            ,'VIEWS_EXEC_PLAN_ENABLED'))
        THEN
            DBA_UTILS.SET_CONTEXT_VALUE(p_attribute_name => :new.PR_NAME
                                       ,p_value => :new.PR_VALUE);
        END IF;
    END;
/
