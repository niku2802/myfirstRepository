CREATE TRIGGER REPORT_DEFINITIONS_AI_TRG
AFTER INSERT
  ON REPORT_DEFINITIONS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.REPD_ID,
      pi_or_name => :new.REPD_NAME,
      pi_or_type => 36,
	  pi_or_container_id => :new.REPD_FOL_ID);
  END;
/
