CREATE TRIGGER WS_GROUPS_AI_TRG
AFTER INSERT
  ON WS_GROUPS
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.WSG_ID,
      pi_or_name => :new.WSG_NAME,
      pi_or_type => 45,
	  pi_or_container_id => :new.WSG_FOLDER_ID);
  END;
/
