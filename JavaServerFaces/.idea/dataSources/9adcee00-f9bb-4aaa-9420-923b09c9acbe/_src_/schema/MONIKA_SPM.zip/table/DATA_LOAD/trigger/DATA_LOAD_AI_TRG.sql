CREATE TRIGGER DATA_LOAD_AI_TRG
AFTER INSERT
  ON DATA_LOAD
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.DL_ID,
      pi_or_name => :new.DL_NAME,
      pi_or_type => 22,
	  pi_or_container_id => :new.DL_FOL_ID);
  END;
/
