CREATE TRIGGER DIRECTORIES_AI_TRG
AFTER INSERT
  ON DIRECTORIES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.DIR_ID,
      pi_or_name => :new.DIR_NAME,
      pi_or_type => 59,
	  pi_or_container_id => :new.DIR_FOL_ID);
  END;
/
