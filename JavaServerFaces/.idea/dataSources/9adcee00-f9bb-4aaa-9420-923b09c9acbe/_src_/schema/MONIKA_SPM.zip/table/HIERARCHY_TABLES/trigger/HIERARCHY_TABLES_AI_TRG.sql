CREATE TRIGGER HIERARCHY_TABLES_AI_TRG
AFTER INSERT
  ON HIERARCHY_TABLES
FOR EACH ROW
  BEGIN
    SYSTEM_DATA.REGISTER_OBJECT
    (  pi_or_id => :new.HT_ID,
      pi_or_name => :new.HT_NAME,
      pi_or_type => 15,
	  pi_or_container_id => :new.HT_FOL_ID);
  END;
/
